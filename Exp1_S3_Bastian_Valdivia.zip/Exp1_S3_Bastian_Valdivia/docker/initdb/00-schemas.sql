-- Se ejecuta UNA SOLA VEZ, al crear el volumen de datos.
-- Los dos esquemas deben existir antes de que arranque la aplicacion:
--   banco      -> tablas de negocio (las crea schema-negocio.sql)
--   batch_meta -> tablas internas de Spring Batch (las crea Spring al arrancar,
--                 dirigidas ahi por el parametro currentSchema del datasource)
CREATE SCHEMA IF NOT EXISTS banco;
CREATE SCHEMA IF NOT EXISTS batch_meta;
