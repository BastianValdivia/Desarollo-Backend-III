# Contenido de la entrega

Mapa de qué es cada carpeta y para qué sirve.

> **¿Solo quieres ejecutarlo?** → [`INSTALACION.md`](INSTALACION.md)
> **¿Vas a evaluarlo?** → [`README.md`](README.md)

---

## Los tres entregables que pide el enunciado

| Entregable | Dónde está |
|---|---|
| **1. Código fuente** | `src/` + `pom.xml`, `compose.yaml`, `docker/`, `mvnw` |
| **2. Documentación** | `README.md`, `INSTALACION.md` y `docs/` |
| **3. Evidencia de ejecución** | `evidencias/` y `results/` |

---

## Carpeta por carpeta

### `src/` — el código
El proyecto Java. Dentro de `src/main/java/cl/duoc/bancoxyz/` las clases están agrupadas
por responsabilidad: `config` (los 3 Jobs y sus Steps), `processor` (validaciones),
`tasklet` (steps de resumen y cuadratura), `partition`, `policy`, `listener`, `experiment`
(el banco de pruebas de escalado). En `src/main/resources/` viven los 3 CSV de entrada y
`schema-negocio.sql`, que crea las tablas. En `src/test/` están las 149 pruebas.

### `docs/` — documentación técnica
| Archivo | Qué explica |
|---|---|
| `arquitectura.md` | Diagrama de los 3 Jobs con todos sus Steps |
| `analisis-datos.md` | Qué trae cada CSV y los números esperados de salida |
| `escalado.md` | Comparación de configuraciones y cuál es la óptima |
| `tolerancia-fallos.md` | Los 16 escenarios de fallo y cómo responde el sistema |
| `tutorial-primeros-pasos.md` | Guía paso a paso para quien nunca lo ha ejecutado |
| `referencia-tecnica/` | Material de apoyo sobre Spring Batch 5.2.6 |
| `plan-maestro.md` | Plan de trabajo: qué construir y por qué |

### `evidencias/` — la prueba de que esto se ejecutó
Organizada por criterio de evaluación. Empieza por [`evidencias/INDICE.md`](evidencias/INDICE.md).

| Carpeta | Contiene |
|---|---|
| `01-arquitectura/` | Los Steps registrados en la base, las tablas creadas, versiones del stack |
| `02-ejecucion/` | **Los logs completos de los 3 Jobs** y el detalle de lo que quedó en BD |
| `03-validaciones/` | Estados y motivos de rechazo por Job |
| `04-escalado/` | Tiempos por partición, gráficos y prueba de paralelismo real |
| `05-fallos/` | Un log por cada escenario de fallo provocado |

### `results/` — salidas que genera la aplicación
No son evidencia capturada a mano: las escribe el propio programa al ejecutarse.

| Archivo | Quién lo genera |
|---|---|
| `informe-estados-cuenta-anual.csv` | El Job 3 — es el "informe para auditorías" del enunciado |
| `scaling-results.csv` | El banco de pruebas de escalado: 168 mediciones |
| `scaling-summary.md` | Resumen de esas mediciones |

### `scripts/` — herramientas para reproducir y verificar
No hacen falta para ejecutar el proyecto. Sirven para **comprobar** que funciona.

| Script | Para qué |
|---|---|
| `verificar-entorno.sh` | Comprueba Java, Docker y el puerto 5432 **antes** de empezar. Ejecútalo primero |
| `perfilar-dataset.sh` | Cuenta los defectos de los 3 CSV y publica los números esperados |
| `graficar.py` | Genera los gráficos del benchmark |
| `consultas-sql/` | Consultas SQL de verificación: cuadratura, particiones, comparativa |
| `escenarios-fallo/` | **Seis scripts que provocan un fallo distinto cada uno**, para comprobar la tolerancia a fallos sin fiarse de la palabra de nadie |

### Archivos de construcción (raíz)

Estos **tienen que estar en la raíz**: Maven y Docker los buscan ahí y no funcionan si se
mueven a una subcarpeta. No son relleno, cada uno hace falta.

| Archivo | Para qué sirve | ¿Se puede quitar? |
|---|---|---|
| `pom.xml` | Declara las dependencias y la versión de Java | No: es el proyecto |
| `mvnw` / `mvnw.cmd` | **Maven Wrapper.** Descarga Maven solo, para que no haya que instalarlo | No, salvo que instales Maven a mano |
| `.mvn/wrapper/maven-wrapper.properties` | Un archivo con **una línea**: qué versión de Maven bajar (3.9.16). Es lo que lee `mvnw` | No. Sin él `mvnw` falla con *"cannot read distributionUrl property"* |
| `compose.yaml` | Levanta PostgreSQL 17 en Docker | No: sin él no hay base de datos |
| `docker/initdb/00-schemas.sql` | Crea los esquemas `banco` y `batch_meta` al arrancar el contenedor por primera vez | No: sin él la aplicación no encuentra dónde crear las tablas |

> **¿Por qué `.mvn` empieza por punto?** Es la convención de Unix para "archivo de
> configuración". En Linux y macOS queda oculto; en Windows se ve igual que los demás, y por
> eso llama la atención. Es configuración, no código.

---

## Por dónde empezar

```bash
./scripts/verificar-entorno.sh     # ¿está la máquina lista?
docker compose up -d               # levanta PostgreSQL
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias
```

Y para comprobar el resultado:

```sql
SELECT * FROM banco.v_cuadratura;   -- debe dar 1000 en los tres archivos
```
