-- =====================================================================
-- Banco XYZ - esquema de negocio (PostgreSQL 17)
-- Exp1 S3 - Desarrollo Backend III (PBY2203)
--
-- Se ejecuta en CADA arranque (spring.sql.init.mode=always), por eso todo
-- lleva IF NOT EXISTS: correrlo dos veces no debe romper nada.
--
-- Convenciones:
--   * Dinero  -> NUMERIC(15,2). Agregados -> NUMERIC(18,2). NUNCA float.
--   * De cada campo reparado se conserva el crudo original (*_original),
--     para poder demostrar que habia antes y que quedo despues.
--   * Regla de oro: entrada = negocio + rechazos. Ninguna fila desaparece.
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS banco;
-- Esquema separado para la "contabilidad interna" de Spring Batch.
-- Lo crea este script; las tablas BATCH_* las crea Spring al arrancar,
-- guiado por spring.batch.jdbc.table-prefix en application.yml.
CREATE SCHEMA IF NOT EXISTS batch_meta;


-- ---------------------------------------------------------------------
-- DEAD LETTER - comun a los 3 jobs.
-- Toda fila que no se pudo procesar aterriza aqui, con su motivo y su
-- linea cruda. Es lo que permite demostrar la cuadratura.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS banco.registro_rechazado (
    id                BIGSERIAL     PRIMARY KEY,
    archivo_origen    VARCHAR(40)   NOT NULL,
    job_name          VARCHAR(60)   NOT NULL,
    job_execution_id  BIGINT        NOT NULL,
    step_name         VARCHAR(100)  NOT NULL,
    particion         VARCHAR(40),
    fase              VARCHAR(10)   NOT NULL,
    numero_linea      BIGINT        NOT NULL DEFAULT -1,
    clave_natural     VARCHAR(80),
    motivo            VARCHAR(40)   NOT NULL,
    campo             VARCHAR(40),
    valor_crudo       VARCHAR(200),
    linea_cruda       TEXT          NOT NULL,
    excepcion         VARCHAR(255)  NOT NULL,
    mensaje           TEXT,
    creado_en         TIMESTAMPTZ   NOT NULL DEFAULT now(),
    -- En que momento del chunk se cayo la fila. Sale de los tres metodos
    -- del SkipListener: onSkipInRead / onSkipInProcess / onSkipInWrite.
    CONSTRAINT ck_rechazo_fase   CHECK (fase IN ('READ','PROCESS','WRITE','FILTER')),
    CONSTRAINT ck_rechazo_motivo CHECK (motivo IN (
        'FECHA_INVALIDA','MONTO_AUSENTE','MONTO_NO_NUMERICO','SALDO_AUSENTE',
        'SALDO_NO_NUMERICO','DUPLICADO','CUENTA_INEXISTENTE','TIPO_AUSENTE',
        'LINEA_MALFORMADA','ERROR_ESCRITURA','OTRO'))
);
CREATE INDEX IF NOT EXISTS ix_rechazo_job     ON banco.registro_rechazado(job_execution_id);
CREATE INDEX IF NOT EXISTS ix_rechazo_archivo ON banco.registro_rechazado(archivo_origen, motivo);
CREATE INDEX IF NOT EXISTS ix_rechazo_fase    ON banco.registro_rechazado(step_name, fase);


-- ---------------------------------------------------------------------
-- CONTROL DE CARGA - la cuadratura persistida.
-- La escribe CuadraturaTasklet al final de cada job. La columna "cuadra"
-- la calcula PostgreSQL sola: el evaluador no tiene que fiarse de ti.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS banco.control_carga (
    id                BIGSERIAL    PRIMARY KEY,
    archivo_origen    VARCHAR(40)  NOT NULL,
    job_name          VARCHAR(60)  NOT NULL,
    job_execution_id  BIGINT       NOT NULL,
    filas_entrada     BIGINT       NOT NULL,
    filas_negocio     BIGINT       NOT NULL,
    filas_rechazadas  BIGINT       NOT NULL,
    filas_filtradas   BIGINT       NOT NULL DEFAULT 0,
    cuadra            BOOLEAN      GENERATED ALWAYS AS
                        (filas_entrada = filas_negocio + filas_rechazadas + filas_filtradas) STORED,
    duracion_ms       BIGINT,
    verificado_en     TIMESTAMPTZ  NOT NULL DEFAULT now(),
    CONSTRAINT uq_control UNIQUE (job_execution_id, archivo_origen)
);


-- =====================================================================
-- JOB 1 - Reporte de Transacciones Diarias
-- =====================================================================
CREATE TABLE IF NOT EXISTS banco.transaccion (
    id                BIGINT        PRIMARY KEY,       -- id 1..1000, unico en el CSV
    fecha             DATE          NOT NULL,
    fecha_original    VARCHAR(20)   NOT NULL,
    formato_fecha     VARCHAR(12)   NOT NULL,          -- patron que si parseo
    monto             NUMERIC(15,2) NOT NULL,
    monto_original    VARCHAR(20)   NOT NULL,
    tipo              VARCHAR(12)   NOT NULL,
    tipo_original     VARCHAR(30)   NOT NULL,
    estado            VARCHAR(32)   NOT NULL,          -- excluyente, por precedencia
    anomalias         VARCHAR(160)  NOT NULL DEFAULT '', -- TODAS, separadas por coma
    es_anomala        BOOLEAN       GENERATED ALWAYS AS (estado <> 'VALIDA') STORED,
    numero_linea      BIGINT        NOT NULL DEFAULT -1,
    job_execution_id  BIGINT        NOT NULL,
    procesado_en      TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CONSTRAINT ck_tx_tipo    CHECK (tipo IN ('CREDITO','DEBITO','DESCONOCIDO')),
    -- Los 4 estados verificados sobre transacciones.csv (ver docs/analisis-datos.md §6):
    -- VALIDA 401 | TIPO_DESCONOCIDO 230 | MONTO_NEGATIVO 136 | MONTO_CERO 18 = 785
    CONSTRAINT ck_tx_estado  CHECK (estado IN ('VALIDA','ANOMALA_TIPO_DESCONOCIDO',
                                               'ANOMALA_MONTO_NEGATIVO','ANOMALA_MONTO_CERO')),
    CONSTRAINT ck_tx_formato CHECK (formato_fecha IN
                                    ('yyyy-MM-dd','dd-MM-yyyy','dd/MM/yyyy','yyyy/MM/dd'))
);
CREATE INDEX IF NOT EXISTS ix_tx_fecha  ON banco.transaccion(fecha);
CREATE INDEX IF NOT EXISTS ix_tx_estado ON banco.transaccion(estado);
CREATE INDEX IF NOT EXISTS ix_tx_job    ON banco.transaccion(job_execution_id);


-- El "generar un resumen" que pide literalmente el enunciado para el Job 1.
-- monto_promedio lleva 4 decimales: un promedio es un calculo, no dinero real,
-- y redondearlo a 2 perderia precision.
CREATE TABLE IF NOT EXISTS banco.resumen_diario (
    fecha              DATE          PRIMARY KEY,
    total_operaciones  INTEGER       NOT NULL,
    n_creditos         INTEGER       NOT NULL DEFAULT 0,
    n_debitos          INTEGER       NOT NULL DEFAULT 0,
    n_tipo_desconocido INTEGER       NOT NULL DEFAULT 0,
    monto_total        NUMERIC(18,2) NOT NULL DEFAULT 0,
    monto_creditos     NUMERIC(18,2) NOT NULL DEFAULT 0,
    monto_debitos      NUMERIC(18,2) NOT NULL DEFAULT 0,
    monto_promedio     NUMERIC(18,4) NOT NULL DEFAULT 0,
    monto_maximo       NUMERIC(15,2),
    n_anomalas         INTEGER       NOT NULL DEFAULT 0,
    n_rechazadas       INTEGER       NOT NULL DEFAULT 0,
    job_execution_id   BIGINT        NOT NULL,
    generado_en        TIMESTAMPTZ   NOT NULL DEFAULT now()
);


-- =====================================================================
-- JOB 2 - Calculo de Intereses Mensuales
-- =====================================================================
-- Saldo consolidado por cuenta. periodo_aplicado es la GUARDA DE
-- IDEMPOTENCIA: si el job vuelve a correr el mismo mes, no reaplica
-- el interes. El evaluador VA a ejecutarlo dos veces.
CREATE TABLE IF NOT EXISTS banco.cuenta (
    cuenta_id          INTEGER       PRIMARY KEY,      -- 101..150 (PK obligatoria para ON CONFLICT)
    nombre             VARCHAR(120)  NOT NULL DEFAULT 'DESCONOCIDO',
    tipo_predominante  VARCHAR(14)   NOT NULL DEFAULT 'DESCONOCIDO',
    n_posiciones       INTEGER       NOT NULL DEFAULT 0,
    saldo_inicial      NUMERIC(18,2) NOT NULL DEFAULT 0,
    interes_aplicado   NUMERIC(18,2) NOT NULL DEFAULT 0,
    saldo              NUMERIC(18,2) NOT NULL DEFAULT 0,
    periodo_aplicado   VARCHAR(7),                     -- 'yyyy-MM'
    job_execution_id   BIGINT,
    actualizado_en     TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CONSTRAINT ck_cuenta_tipo  CHECK (tipo_predominante IN
                                      ('AHORRO','PRESTAMO','HIPOTECA','DESCONOCIDO')),
    -- La base impide guardar una cuenta cuya aritmetica no cuadre.
    CONSTRAINT ck_cuenta_saldo CHECK (saldo = saldo_inicial + interes_aplicado)
);


CREATE TABLE IF NOT EXISTS banco.interes_calculado (
    id                BIGSERIAL     PRIMARY KEY,
    periodo           VARCHAR(7)    NOT NULL,          -- 'yyyy-MM'
    cuenta_id         INTEGER       NOT NULL,
    nombre            VARCHAR(120)  NOT NULL,
    nombre_original   VARCHAR(120)  NOT NULL,
    edad              INTEGER,                          -- NULL si vacia o fuera de rango
    edad_original     VARCHAR(10)   NOT NULL DEFAULT '',
    tipo              VARCHAR(14)   NOT NULL,
    tipo_original     VARCHAR(30)   NOT NULL,
    saldo_inicial     NUMERIC(15,2) NOT NULL,
    saldo_original    VARCHAR(20)   NOT NULL,
    tasa              NUMERIC(7,5)  NOT NULL,           -- 0 si el tipo es DESCONOCIDO
    interes           NUMERIC(15,2) NOT NULL,
    saldo_final       NUMERIC(15,2) GENERATED ALWAYS AS (saldo_inicial + interes) STORED,
    estado            VARCHAR(32)   NOT NULL,
    anomalias         VARCHAR(160)  NOT NULL DEFAULT '',
    numero_linea      BIGINT        NOT NULL DEFAULT -1,
    job_execution_id  BIGINT        NOT NULL,
    creado_en         TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CONSTRAINT ck_int_tipo   CHECK (tipo IN ('AHORRO','PRESTAMO','HIPOTECA','DESCONOCIDO')),
    CONSTRAINT ck_int_edad   CHECK (edad IS NULL OR edad BETWEEN 18 AND 99),
    CONSTRAINT ck_int_tasa   CHECK (tasa >= 0 AND tasa < 1),
    -- Estados verificados sobre intereses.csv (ver docs/analisis-datos.md §6):
    -- VALIDA 303 | TIPO_DESC 260 | EDAD_AUSENTE 101 | EDAD_FUERA_RANGO 96 | NOMBRE_DESC 24 = 784
    CONSTRAINT ck_int_estado CHECK (estado IN ('VALIDA','ANOMALA_TIPO_DESCONOCIDO',
                                               'ANOMALA_EDAD_AUSENTE','ANOMALA_EDAD_FUERA_RANGO',
                                               'ANOMALA_NOMBRE_DESCONOCIDO')),
    -- Dispara DuplicateKeyException para las filas 100% repetidas: es uno de
    -- los escenarios de fallo del criterio 5. Se compara por los campos CRUDOS
    -- y todos son NOT NULL, porque en Postgres dos NULL no colisionan en un UNIQUE.
    CONSTRAINT uq_interes_posicion UNIQUE
        (periodo, cuenta_id, nombre_original, saldo_original, edad_original, tipo_original)
);
CREATE INDEX IF NOT EXISTS ix_int_cuenta ON banco.interes_calculado(periodo, cuenta_id);
CREATE INDEX IF NOT EXISTS ix_int_job    ON banco.interes_calculado(job_execution_id);


-- =====================================================================
-- JOB 3 - Estados de Cuenta Anuales
-- =====================================================================
-- Truco de diseno: monto siempre POSITIVO, y el sentido va en "signo".
-- Asi SUM(monto) da el volumen movido y SUM(monto_con_signo) da el saldo
-- neto, sin escribir un solo CASE WHEN.
CREATE TABLE IF NOT EXISTS banco.movimiento_anual (
    id                    BIGSERIAL     PRIMARY KEY,
    cuenta_id             INTEGER       NOT NULL,          -- 101..120
    fecha                 DATE          NOT NULL,
    fecha_original        VARCHAR(20)   NOT NULL,
    formato_fecha         VARCHAR(12)   NOT NULL,
    anio                  INTEGER       GENERATED ALWAYS AS (EXTRACT(YEAR FROM fecha)::INT) STORED,
    transaccion           VARCHAR(12)   NOT NULL,          -- normalizado, sin tildes
    transaccion_original  VARCHAR(30)   NOT NULL,          -- conserva la tilde original
    signo                 SMALLINT      NOT NULL,          -- +1 DEPOSITO ; -1 RETIRO/PAGO/COMPRA
    monto                 NUMERIC(15,2) NOT NULL,          -- valor absoluto
    monto_original        VARCHAR(20)   NOT NULL,
    monto_con_signo       NUMERIC(15,2) GENERATED ALWAYS AS ((signo * monto)::NUMERIC(15,2)) STORED,
    descripcion           VARCHAR(255)  NOT NULL DEFAULT 'SIN DESCRIPCION',
    estado                VARCHAR(32)   NOT NULL,
    anomalias             VARCHAR(160)  NOT NULL DEFAULT '',
    numero_linea          BIGINT        NOT NULL DEFAULT -1,
    job_execution_id      BIGINT        NOT NULL,
    procesado_en          TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CONSTRAINT ck_mov_tipo   CHECK (transaccion IN ('DEPOSITO','RETIRO','PAGO','COMPRA')),
    CONSTRAINT ck_mov_signo  CHECK (signo IN (-1, 1)),
    CONSTRAINT ck_mov_monto  CHECK (monto >= 0),
    CONSTRAINT ck_mov_estado CHECK (estado IN ('VALIDA','ANOMALA_MONTO_NEGATIVO','ANOMALA_MONTO_CERO',
                                               'ANOMALA_SIGNO_CONTRADICTORIO',
                                               'ANOMALA_DESCRIPCION_AUSENTE'))
);
CREATE INDEX IF NOT EXISTS ix_mov_cuenta_anio ON banco.movimiento_anual(cuenta_id, anio);
CREATE INDEX IF NOT EXISTS ix_mov_job         ON banco.movimiento_anual(job_execution_id);


-- El "informe detallado para auditorias" del enunciado.
-- PK compuesta: una cuenta solo puede tener un estado por anio.
CREATE TABLE IF NOT EXISTS banco.estado_cuenta_anual (
    cuenta_id        INTEGER       NOT NULL,
    anio             INTEGER       NOT NULL,
    n_movimientos    INTEGER       NOT NULL DEFAULT 0,
    n_depositos      INTEGER       NOT NULL DEFAULT 0,
    n_retiros        INTEGER       NOT NULL DEFAULT 0,
    n_pagos          INTEGER       NOT NULL DEFAULT 0,
    n_compras        INTEGER       NOT NULL DEFAULT 0,
    total_depositos  NUMERIC(18,2) NOT NULL DEFAULT 0,
    total_retiros    NUMERIC(18,2) NOT NULL DEFAULT 0,
    total_pagos      NUMERIC(18,2) NOT NULL DEFAULT 0,
    total_compras    NUMERIC(18,2) NOT NULL DEFAULT 0,
    saldo_neto       NUMERIC(18,2) NOT NULL DEFAULT 0,
    n_anomalias      INTEGER       NOT NULL DEFAULT 0,
    primera_fecha    DATE,
    ultima_fecha     DATE,
    job_execution_id BIGINT        NOT NULL,
    generado_en      TIMESTAMPTZ   NOT NULL DEFAULT now(),
    PRIMARY KEY (cuenta_id, anio),
    CONSTRAINT ck_eca_saldo CHECK (saldo_neto = total_depositos
                                   - total_retiros - total_pagos - total_compras)
);


-- =====================================================================
-- METRICAS DE ESCALADO (criterio 4)
-- Cada fila es una medicion: "con 4 particiones y chunk 200, tardo X ms".
-- Guardarlo en BD, y no solo en capturas, hace la comparacion consultable.
-- =====================================================================
CREATE TABLE IF NOT EXISTS banco.ejecucion_metrica (
    id                BIGSERIAL    PRIMARY KEY,
    job_name          VARCHAR(60)  NOT NULL,
    fase              VARCHAR(20)  NOT NULL,
    estrategia        VARCHAR(20)  NOT NULL,
    paralelismo       INTEGER      NOT NULL,
    chunk_size        INTEGER      NOT NULL,
    dataset_filas     INTEGER      NOT NULL,
    repeticion        INTEGER      NOT NULL,
    warmup            BOOLEAN      NOT NULL DEFAULT false,
    wall_clock_ms     BIGINT       NOT NULL,
    job_exec_ms       BIGINT,
    read_count        BIGINT       NOT NULL DEFAULT 0,
    write_count       BIGINT       NOT NULL DEFAULT 0,
    filter_count      BIGINT       NOT NULL DEFAULT 0,
    skip_count        BIGINT       NOT NULL DEFAULT 0,
    commit_count      BIGINT       NOT NULL DEFAULT 0,
    rollback_count    BIGINT       NOT NULL DEFAULT 0,
    max_particion_ms  BIGINT,
    sum_particion_ms  BIGINT,
    skew              NUMERIC(6,3),
    ratio_max_min     NUMERIC(6,3),
    hikari_pool_size  INTEGER      NOT NULL,
    cpus              INTEGER      NOT NULL,
    heap_max_mb       INTEGER      NOT NULL,
    batch_status      VARCHAR(20)  NOT NULL,
    job_execution_id  BIGINT,
    creado_en         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    CONSTRAINT ck_metrica_estrategia CHECK (estrategia IN ('SECUENCIAL','MULTI_THREAD','PARTICIONADO'))
);
CREATE INDEX IF NOT EXISTS ix_metrica_celda
    ON banco.ejecucion_metrica(job_name, estrategia, paralelismo, chunk_size, dataset_filas);


-- =====================================================================
-- VISTAS DE VERIFICACION
-- Una vista es una consulta guardada con nombre: no almacena datos, los
-- calcula al consultarla. Son los "botones de evidencia" del evaluador.
--
-- OJO: aqui solo van las vistas que dependen de banco.*. La que lee las
-- tablas BATCH_* vive en scripts/vistas-evidencia.sql, porque esas tablas
-- todavia no existen cuando este script se ejecuta.
-- =====================================================================
CREATE OR REPLACE VIEW banco.v_cuadratura AS
SELECT 'transacciones.csv' AS archivo,
       (SELECT COUNT(*) FROM banco.transaccion)                                                 AS negocio,
       (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='transacciones.csv') AS rechazos,
       (SELECT COUNT(*) FROM banco.transaccion)
     + (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='transacciones.csv') AS total
UNION ALL
SELECT 'intereses.csv',
       (SELECT COUNT(*) FROM banco.interes_calculado),
       (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='intereses.csv'),
       (SELECT COUNT(*) FROM banco.interes_calculado)
     + (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='intereses.csv')
UNION ALL
SELECT 'cuentas_anuales.csv',
       (SELECT COUNT(*) FROM banco.movimiento_anual),
       (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='cuentas_anuales.csv'),
       (SELECT COUNT(*) FROM banco.movimiento_anual)
     + (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='cuentas_anuales.csv');


-- Desglosa la columna "anomalias" (lista separada por comas) en una fila
-- por anomalia. Permite contar cuantas veces aparece cada defecto aunque
-- el estado solo nombre uno.
CREATE OR REPLACE VIEW banco.v_anomalias_transaccion AS
SELECT t.id, t.fecha, t.estado, TRIM(a) AS anomalia
FROM banco.transaccion t,
     LATERAL UNNEST(STRING_TO_ARRAY(NULLIF(t.anomalias,''), ',')) AS a;
