package cl.duoc.bancoxyz.domain;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Una fila YA CONSOLIDADA de banco.estado_cuenta_anual, tal como se lee para
 * exportarla al informe de auditoria.
 *
 * Recorrido de esta clase: la rellena el JdbcCursorItemReader del step de
 * exportacion (con un RowMapper explicito) y la consume el FlatFileItemWriter
 * que escribe el CSV del informe. NUNCA se inserta con ella: quien escribe en
 * estado_cuenta_anual es GenerarEstadosCuentaTasklet, con un INSERT ... SELECT
 * que agrega en la propia base.
 *
 * POR QUE ES DE SOLO LECTURA (todo final, sin setters): un objeto que solo viaja
 * de la base al fichero no tiene ninguna razon para poder mutar. Hacerlo
 * inmutable elimina de raiz la duda de si alguien lo modifica a medio camino.
 *
 * Y POR QUE ENTONCES NO ES UN record: podria serlo. Se deja como clase con
 * getters JavaBean porque el FlatFileItemWriter se configura con
 * .delimited().names(...), y ese extractor de campos busca getXxx() por
 * reflexion igual que .beanMapped(). Con un record (que expone cuentaId() sin
 * el prefijo get) el informe saldria vacio o reventaria en ejecucion. Es la
 * misma trampa que ya documenta MovimientoAnual, en el sentido contrario:
 * alli al escribir en la base, aqui al escribir en el fichero.
 */
public class EstadoCuentaAnual {

    private final int cuentaId;
    private final int anio;
    private final int nMovimientos;
    private final int nDepositos;
    private final int nRetiros;
    private final int nPagos;
    private final int nCompras;
    private final BigDecimal totalDepositos;
    private final BigDecimal totalRetiros;
    private final BigDecimal totalPagos;
    private final BigDecimal totalCompras;
    private final BigDecimal saldoNeto;
    private final int nAnomalias;
    private final LocalDate primeraFecha;
    private final LocalDate ultimaFecha;

    public EstadoCuentaAnual(int cuentaId, int anio, int nMovimientos,
                             int nDepositos, int nRetiros, int nPagos, int nCompras,
                             BigDecimal totalDepositos, BigDecimal totalRetiros,
                             BigDecimal totalPagos, BigDecimal totalCompras,
                             BigDecimal saldoNeto, int nAnomalias,
                             LocalDate primeraFecha, LocalDate ultimaFecha) {
        this.cuentaId = cuentaId;
        this.anio = anio;
        this.nMovimientos = nMovimientos;
        this.nDepositos = nDepositos;
        this.nRetiros = nRetiros;
        this.nPagos = nPagos;
        this.nCompras = nCompras;
        this.totalDepositos = totalDepositos;
        this.totalRetiros = totalRetiros;
        this.totalPagos = totalPagos;
        this.totalCompras = totalCompras;
        this.saldoNeto = saldoNeto;
        this.nAnomalias = nAnomalias;
        this.primeraFecha = primeraFecha;
        this.ultimaFecha = ultimaFecha;
    }

    // Getters JavaBean: son los nombres que busca .delimited().names(...) del
    // FlatFileItemWriter. "nMovimientos" se expone como getNMovimientos().
    public int getCuentaId()                { return cuentaId; }
    public int getAnio()                    { return anio; }
    public int getNMovimientos()            { return nMovimientos; }
    public int getNDepositos()              { return nDepositos; }
    public int getNRetiros()                { return nRetiros; }
    public int getNPagos()                  { return nPagos; }
    public int getNCompras()                { return nCompras; }
    public BigDecimal getTotalDepositos()   { return totalDepositos; }
    public BigDecimal getTotalRetiros()     { return totalRetiros; }
    public BigDecimal getTotalPagos()       { return totalPagos; }
    public BigDecimal getTotalCompras()     { return totalCompras; }
    public BigDecimal getSaldoNeto()        { return saldoNeto; }
    public int getNAnomalias()              { return nAnomalias; }
    public LocalDate getPrimeraFecha()      { return primeraFecha; }
    public LocalDate getUltimaFecha()       { return ultimaFecha; }
}
