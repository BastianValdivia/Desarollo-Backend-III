package cl.duoc.bancoxyz.domain;

import java.math.BigDecimal;

/**
 * La fila de intereses ya limpia y calculada, lista para banco.interes_calculado.
 *
 * NO ES UN RECORD, Y ESO IMPORTA. El writer es un JdbcBatchItemWriter con
 * .beanMapped(), que por dentro usa BeanPropertyItemSqlParameterSourceProvider:
 * para resolver el parametro :cuentaId busca un metodo llamado getCuentaId().
 * Un record expone cuentaId() y NO getCuentaId(), asi que el writer fallaria...
 * en TIEMPO DE EJECUCION, no de compilacion. Es la clase de error que se
 * descubre con el job a medias y la base a medio escribir. Por eso aqui se usan
 * getters al estilo JavaBean, igual que en Transaccion (Job 1).
 *
 * ------------------------------------------------------------------------
 * POR QUE NO EXISTE UN CAMPO saldoFinal
 * ------------------------------------------------------------------------
 * En la tabla, saldo_final esta declarada asi:
 *
 *     saldo_final NUMERIC(15,2) GENERATED ALWAYS AS (saldo_inicial + interes) STORED
 *
 * "GENERATED ALWAYS ... STORED" significa que la calcula PostgreSQL y la guarda
 * fisicamente, y que NADIE puede escribirla: si aparece en la lista de columnas
 * de un INSERT, PostgreSQL rechaza la sentencia ENTERA con
 * "cannot insert a non-DEFAULT value into column saldo_final".
 *
 * Es una buena restriccion, no un estorbo: garantiza que el saldo final SIEMPRE
 * cuadra con sus dos sumandos, aunque el codigo tuviera un bug. La aritmetica
 * vive en un solo sitio (la base) en vez de estar duplicada en Java y en SQL.
 * Como el campo no se puede escribir, tenerlo aqui solo serviria para que
 * alguien lo anadiera al INSERT por descuido.
 *
 * Se conservan tambien los valores ORIGINALES (nombreOriginal, saldoOriginal,
 * edadOriginal, tipoOriginal). Cumplen dos funciones: son la evidencia de que
 * habia antes y que quedo despues de normalizar, y son las columnas sobre las
 * que se define uq_interes_posicion, la restriccion UNIQUE que detecta las
 * filas repetidas.
 */
public class InteresCalculado {

    private String periodo;              // 'yyyy-MM'
    private Integer cuentaId;
    private String nombre;               // canonizado; 'DESCONOCIDO' si venia 'Unknown'
    private String nombreOriginal;
    private Integer edad;                // NULL si venia vacia o fuera de 18..99
    private String edadOriginal;
    private String tipo;                 // AHORRO | HIPOTECA | PRESTAMO | DESCONOCIDO
    private String tipoOriginal;
    private BigDecimal saldoInicial;
    private String saldoOriginal;
    private BigDecimal tasa;             // 0 si el tipo es DESCONOCIDO
    private BigDecimal interes;
    private String estado;
    /** TODAS las anomalias de la fila, separadas por coma. El estado nombra solo una. */
    private String anomalias = "";
    /** Linea fisica del CSV de la que salio esta fila. Sirve para auditar. */
    private Long numeroLinea;
    private Long jobExecutionId;

    public String getPeriodo() { return periodo; }
    public void setPeriodo(String periodo) { this.periodo = periodo; }

    public Integer getCuentaId() { return cuentaId; }
    public void setCuentaId(Integer cuentaId) { this.cuentaId = cuentaId; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getNombreOriginal() { return nombreOriginal; }
    public void setNombreOriginal(String nombreOriginal) { this.nombreOriginal = nombreOriginal; }

    public Integer getEdad() { return edad; }
    public void setEdad(Integer edad) { this.edad = edad; }

    public String getEdadOriginal() { return edadOriginal; }
    public void setEdadOriginal(String edadOriginal) { this.edadOriginal = edadOriginal; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getTipoOriginal() { return tipoOriginal; }
    public void setTipoOriginal(String tipoOriginal) { this.tipoOriginal = tipoOriginal; }

    public BigDecimal getSaldoInicial() { return saldoInicial; }
    public void setSaldoInicial(BigDecimal saldoInicial) { this.saldoInicial = saldoInicial; }

    public String getSaldoOriginal() { return saldoOriginal; }
    public void setSaldoOriginal(String saldoOriginal) { this.saldoOriginal = saldoOriginal; }

    public BigDecimal getTasa() { return tasa; }
    public void setTasa(BigDecimal tasa) { this.tasa = tasa; }

    public BigDecimal getInteres() { return interes; }
    public void setInteres(BigDecimal interes) { this.interes = interes; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getAnomalias() { return anomalias; }
    public void setAnomalias(String anomalias) { this.anomalias = anomalias; }

    public Long getNumeroLinea() { return numeroLinea; }
    public void setNumeroLinea(Long numeroLinea) { this.numeroLinea = numeroLinea; }

    public Long getJobExecutionId() { return jobExecutionId; }
    public void setJobExecutionId(Long jobExecutionId) { this.jobExecutionId = jobExecutionId; }

    /**
     * Reconstruye la linea CRUDA del CSV a partir de los campos *_original.
     *
     * POR QUE ESTE toString() ES IMPRESCINDIBLE Y NO COSMETICO
     * -------------------------------------------------------
     * Cuando una fila se omite en la fase WRITE (las 5 DUPLICADO), Spring Batch
     * llama a SkipListener.onSkipInWrite(item, throwable) pasandole el objeto de
     * SALIDA -este- y no el InteresRaw de entrada, que a esas alturas ya no
     * existe. RechazoListener hace String.valueOf(item) para rellenar
     * linea_cruda, que ademas es NOT NULL en la tabla.
     *
     * Por eso se reconstruye con los valores ORIGINALES y no con los ya
     * normalizados: el dead letter tiene que mostrar lo que venia en el
     * archivo, no lo que el processor hizo con ello. Si aqui saliera
     * 'DESCONOCIDO' donde el CSV decia 'Unknown', el registro de rechazo
     * mentiria sobre el dato de origen y no se podria localizar la fila.
     */
    @Override
    public String toString() {
        return String.join(",",
                cuentaId == null ? "" : String.valueOf(cuentaId),
                nombreOriginal == null ? "" : nombreOriginal,
                saldoOriginal == null ? "" : saldoOriginal,
                edadOriginal == null ? "" : edadOriginal,
                tipoOriginal == null ? "" : tipoOriginal);
    }
}
