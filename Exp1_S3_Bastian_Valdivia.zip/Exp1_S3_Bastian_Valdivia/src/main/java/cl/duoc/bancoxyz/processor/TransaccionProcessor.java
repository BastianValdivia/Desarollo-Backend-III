package cl.duoc.bancoxyz.processor;

import cl.duoc.bancoxyz.domain.EstadoRegistro;
import cl.duoc.bancoxyz.domain.Transaccion;
import cl.duoc.bancoxyz.domain.TransaccionRaw;
import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import cl.duoc.bancoxyz.support.NormalizadorFecha;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import org.springframework.batch.item.ItemProcessor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * EL CORAZÓN DEL EJERCICIO. Aquí se decide qué pasa con cada fila.
 *
 * Es el equivalente a tus transformaciones de PySpark (.withColumn, tus UDF),
 * salvo que aquí llega UNA fila cada vez, no un DataFrame completo.
 *
 * Hay TRES tratamientos posibles, no dos:
 *
 *   REPARAR  -> el dato está mal escrito pero se entiende (4 formatos de fecha)
 *               => se arregla y la fila queda VALIDA
 *   MARCAR   -> el dato es legible pero anómalo (monto negativo, tipo basura)
 *               => se guarda igual, con estado ANOMALA_*. NO se descarta:
 *                  este job se llama "detectar anomalías", o sea que las
 *                  anomalías son el PRODUCTO, no la basura.
 *   RECHAZAR -> el dato es irrecuperable (fecha mes 13, monto vacío)
 *               => se lanza RegistroInvalidoException; el SkipListener la
 *                  guardará en la tabla de rechazados con su motivo.
 *
 * REGLA DE ORO: nunca devolver null sin haber registrado el rechazo.
 * Devolver null aquí FILTRA la fila: no se escribe, no cuenta como error,
 * y desaparece sin dejar rastro. Es la forma más fácil de perder 200 filas.
 */
public class TransaccionProcessor implements ItemProcessor<TransaccionRaw, Transaccion> {

    private final NormalizadorFecha normalizadorFecha;
    private final NormalizadorMonto normalizadorMonto;
    private final NormalizadorTexto normalizadorTexto;
    private final Long jobExecutionId;
    /**
     * Cuantas lineas salta el lector de ESTA particion. Es el desplazamiento
     * que convierte la posicion dentro del lector en linea fisica del archivo.
     * Sin particiones vale 1 (solo la cabecera).
     */
    private final int linesToSkip;

    public TransaccionProcessor(NormalizadorFecha normalizadorFecha,
                                NormalizadorMonto normalizadorMonto,
                                NormalizadorTexto normalizadorTexto,
                                Long jobExecutionId,
                                int linesToSkip) {
        this.normalizadorFecha = normalizadorFecha;
        this.normalizadorMonto = normalizadorMonto;
        this.normalizadorTexto = normalizadorTexto;
        this.jobExecutionId = jobExecutionId;
        this.linesToSkip = linesToSkip;
    }

    @Override
    public Transaccion process(TransaccionRaw raw) {
        String lineaCruda = String.join(",", raw.id(), raw.fecha(), raw.monto(), raw.tipo());

        // ---- PASO 1: fecha. Si ninguno de los 4 patrones sirve, es irrecuperable.
        //      Aquí caen las 55 filas con "2024-13-01" (mes 13).
        Optional<NormalizadorFecha.FechaNormalizada> fecha = normalizadorFecha.normalizar(raw.fecha());
        if (fecha.isEmpty()) {
            throw new RegistroInvalidoException("FECHA_INVALIDA", "fecha", raw.fecha(), lineaCruda);
        }

        // ---- PASO 2: monto. Vacío y "no numérico" son motivos DISTINTOS.
        //      Aquí caen las 168 filas con monto vacío.
        NormalizadorMonto.Resultado monto = normalizadorMonto.normalizar(raw.monto());
        if (monto.ausente()) {
            throw new RegistroInvalidoException("MONTO_AUSENTE", "monto", raw.monto(), lineaCruda);
        }
        if (monto.noNumerico()) {
            throw new RegistroInvalidoException("MONTO_NO_NUMERICO", "monto", raw.monto(), lineaCruda);
        }
        BigDecimal valorMonto = monto.valor().orElseThrow();

        // ---- PASO 3: tipo. Se canoniza siempre; si no es CREDITO ni DEBITO
        //      queda como DESCONOCIDO, pero la fila SE GUARDA.
        String tipoCanonico = normalizadorTexto.canonico(raw.tipo());
        boolean tipoConocido = tipoCanonico.equals("CREDITO") || tipoCanonico.equals("DEBITO");
        if (!tipoConocido) {
            tipoCanonico = "DESCONOCIDO";
        }

        // ---- PASO 4: clasificar el estado, en este orden de precedencia.
        //      El orden importa: define los números que vas a publicar como
        //      "salida esperada". Con este orden, sobre transacciones.csv sale:
        //      VALIDA 401 | ANOMALA_TIPO_DESCONOCIDO 230 | ANOMALA_MONTO_NEGATIVO 136
        //      | ANOMALA_MONTO_CERO 18 | rechazos 215  ->  total 1000
        // ---- PASO 4a: recolectar TODAS las anomalias de la fila.
        //      El estado (paso 4b) nombra solo la de mayor precedencia, pero
        //      aqui no se pierde ninguna: van todas a la columna "anomalias".
        //      Una fila con monto negativo Y tipo desconocido aporta 1 al
        //      estado y 2 a esta lista.
        List<String> anomalias = new ArrayList<>();
        if (valorMonto.signum() <  0) anomalias.add("MONTO_NEGATIVO");
        if (valorMonto.signum() == 0) anomalias.add("MONTO_CERO");
        if (!tipoConocido)            anomalias.add("TIPO_DESCONOCIDO");

        EstadoRegistro estado;
        if (valorMonto.signum() < 0) {
            estado = EstadoRegistro.ANOMALA_MONTO_NEGATIVO;
        } else if (valorMonto.signum() == 0) {
            estado = EstadoRegistro.ANOMALA_MONTO_CERO;
        } else if (!tipoConocido) {
            estado = EstadoRegistro.ANOMALA_TIPO_DESCONOCIDO;
        } else {
            estado = EstadoRegistro.VALIDA;
        }

        // ---- PASO 5: armar la entidad limpia, conservando los valores originales
        Transaccion t = new Transaccion();
        t.setId(Long.parseLong(raw.id().trim()));
        t.setFecha(fecha.get().fecha());
        t.setFechaOriginal(raw.fecha());
        t.setFormatoFecha(fecha.get().patron());
        t.setMonto(valorMonto);
        t.setMontoOriginal(raw.monto());
        t.setTipo(tipoCanonico);
        t.setTipoOriginal(raw.tipo());
        t.setEstado(estado.name());
        t.setAnomalias(String.join(",", anomalias));
        // Linea fisica = lo que salta esta particion + la posicion dentro del lector.
        // particion0: 1 + 1 = 2 (la primera fila de datos, tras la cabecera)
        // particion1: 251 + 1 = 252
        t.setNumeroLinea((long) linesToSkip + raw.itemCount());
        t.setJobExecutionId(jobExecutionId);
        return t;
    }
}
