package cl.duoc.bancoxyz.support;

import org.springframework.core.io.Resource;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Cuenta las filas de DATOS de un CSV (o sea, las lineas menos la cabecera).
 *
 * ------------------------------------------------------------------------
 * POR QUE ESTO MERECE UNA CLASE PROPIA
 * ------------------------------------------------------------------------
 * Este numero es LA VERDAD DE PARTIDA de la Regla de Oro: "entrada = negocio +
 * rechazos". Todo lo demas del proyecto (los contadores de Spring Batch, los
 * COUNT(*) sobre las tablas) son mediciones DE LO QUE EL JOB HIZO. El fichero
 * es lo unico que dice lo que el job DEBERIA haber hecho.
 *
 * Lo usan dos sitios que antes tenian cada uno su copia mental del calculo:
 *
 *   LineRangePartitioner  - para repartir las filas entre las particiones
 *   CuadraturaTasklet     - para comprobar que la tabla contiene TODO el fichero
 *
 * Que los dos usen LA MISMA funcion es lo que impide el fallo clasico: que el
 * repartidor crea que hay 1000 filas y el verificador crea que hay 999, y que
 * la diferencia se interprete como "todo correcto".
 *
 * Analogia SQL: es el equivalente a tener el COUNT(*) de la tabla de origen
 * antes de un INSERT ... SELECT, para poder compararlo con el numero de filas
 * insertadas en vez de fiarte de que la sentencia "parecio ir bien".
 */
public final class ContadorFilasCsv {

    /** Clase de utilidades: no se instancia. */
    private ContadorFilasCsv() {
    }

    /**
     * Filas de datos del recurso. Las lineas en blanco NO cuentan (un CSV suele
     * acabar con un salto de linea final y esa linea vacia no es un registro).
     *
     * @param recurso        el CSV
     * @param lineasCabecera cuantas lineas de cabecera hay que descontar
     * @return numero de filas de datos; nunca negativo
     * @throws IllegalStateException si el fichero no se puede leer. Se prefiere
     *         reventar antes que devolver un numero inventado: un cero silencioso
     *         aqui se propagaria a la cuadratura y la haria pasar por vacuidad.
     */
    public static int contar(Resource recurso, int lineasCabecera) {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(recurso.getInputStream(), StandardCharsets.UTF_8))) {
            int lineas = 0;
            String l;
            while ((l = br.readLine()) != null) {
                if (!l.isBlank()) {
                    lineas++;
                }
            }
            return Math.max(0, lineas - lineasCabecera);
        } catch (IOException e) {
            throw new IllegalStateException(
                    "No se pudo contar las lineas de " + recurso.getDescription(), e);
        }
    }
}
