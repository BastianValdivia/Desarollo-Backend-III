package cl.duoc.bancoxyz.support;

import cl.duoc.bancoxyz.domain.TipoCuenta;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Calcula el interes de un periodo: interes = saldo x tasa, redondeado a
 * dos decimales.
 *
 * Tiene una sola responsabilidad y ninguna dependencia, asi que se puede
 * probar sola con un test de tres lineas y sin levantar ni Spring ni la base.
 * Esa es la razon de que sea una clase propia y no dos lineas metidas dentro
 * del processor: el processor decide QUE le pasa a cada fila (que es donde
 * estan las reglas discutibles), y esto calcula CUANTO, que es aritmetica
 * pura y verificable.
 *
 * ------------------------------------------------------------------------
 * LAS DOS DECISIONES TECNICAS QUE HAY AQUI
 * ------------------------------------------------------------------------
 *
 * 1) BigDecimal y NO double.
 *    Con double, 0.1 + 0.2 no da 0.3 exacto, porque los decimales se guardan
 *    en binario y muchos no son representables. En dinero eso produce
 *    descuadres de centimos que se acumulan sobre 784 filas. BigDecimal
 *    guarda los digitos tal cual, como el NUMERIC de PostgreSQL (y por el
 *    mismo motivo por el que en Spark se usa DecimalType y no DoubleType).
 *
 * 2) setScale(2, HALF_UP).
 *    multiply() devuelve la suma de las escalas de los dos operandos: un saldo
 *    con 2 decimales por una tasa con 5 da un resultado con 7. La columna
 *    interes es NUMERIC(15,2), asi que hay que redondear a 2 SI O SI; si no lo
 *    hicieramos aqui, redondearia PostgreSQL por su cuenta y el numero que
 *    calcula Java dejaria de ser el que hay en la tabla.
 *    HALF_UP es el redondeo "de toda la vida" (0,005 -> 0,01) y es el que se
 *    usa por convencion en importes financieros. NO se usa el de por defecto
 *    de BigDecimal, que es HALF_EVEN, ni se deja sin especificar: sin modo de
 *    redondeo, setScale lanza ArithmeticException en cuanto haya que recortar
 *    un decimal distinto de cero.
 */
@Component
public class CalculadoraInteres {

    /**
     * Interes del periodo para un saldo y un tipo de cuenta.
     *
     * Para DESCONOCIDO la tasa es 0, asi que el resultado es 0.00: la fila se
     * guarda, queda marcada como anomala y NO se le inventa una rentabilidad.
     * Ver la justificacion completa en TipoCuenta.
     */
    public BigDecimal interes(BigDecimal saldo, TipoCuenta tipo) {
        return saldo.multiply(tipo.tasa()).setScale(2, RoundingMode.HALF_UP);
    }
}
