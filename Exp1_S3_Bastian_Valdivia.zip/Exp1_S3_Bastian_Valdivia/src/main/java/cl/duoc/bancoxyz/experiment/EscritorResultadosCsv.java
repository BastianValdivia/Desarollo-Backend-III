package cl.duoc.bancoxyz.experiment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;

/**
 * Vuelca TODAS las ejecuciones a results/scaling-results.csv.
 *
 * "Todas" incluye los calentamientos, marcados con warmup=true, y las
 * ejecuciones que no pasaron el control de filas. Un CSV que solo contuviera
 * lo bonito no seria evidencia, seria un resumen; y un resumen no permite
 * comprobar nada. Aqui esta el dato crudo para que cualquiera pueda rehacer
 * las medianas y verificar que el descarte fue el declarado (las 2 primeras
 * rondas) y no "las que salieron feas".
 *
 * El separador decimal se fuerza a punto con Locale.ROOT: en una JVM con
 * configuracion regional espanola, String.format("%.3f") escribiria "1,234" y
 * el CSV separado por comas quedaria descuadrado. Es un fallo clasico y
 * silencioso.
 */
@Component
@Profile("experiment")
public class EscritorResultadosCsv {

    private static final Logger log = LoggerFactory.getLogger(EscritorResultadosCsv.class);

    private static final String CABECERA = String.join(",",
            "instante", "fase", "estrategia", "paralelismo", "chunk_size", "dataset_filas",
            "ronda", "warmup", "batch_status", "exit_code", "filas_esperadas_ok",
            "wall_clock_ms", "job_execution_ms", "throughput_filas_seg",
            "read_count", "write_count", "filter_count", "skip_count",
            "commit_count", "rollback_count",
            "max_particion_ms", "sum_particion_ms", "skew", "ratio_max_min",
            "hilos_distintos", "hikari_pool_size", "cpus", "heap_max_mb", "job_execution_id");

    public void escribir(Path destino, List<ResultadoExperimento> resultados) throws IOException {
        Files.createDirectories(destino.getParent());
        try (BufferedWriter out = Files.newBufferedWriter(destino, StandardCharsets.UTF_8)) {
            out.write(CABECERA);
            out.newLine();
            for (ResultadoExperimento r : resultados) {
                out.write(fila(r));
                out.newLine();
            }
        }
        log.info("Escritas {} ejecuciones en {}", resultados.size(), destino.toAbsolutePath());
    }

    private String fila(ResultadoExperimento r) {
        CasoExperimento c = r.caso();
        return String.join(",",
                r.instanteIso(),
                c.fase(),
                c.estrategia().name(),
                String.valueOf(c.paralelismo()),
                String.valueOf(c.chunkSize()),
                String.valueOf(c.filasDataset()),
                String.valueOf(r.ronda()),
                String.valueOf(r.calentamiento()),
                r.batchStatus(),
                r.exitCode(),
                String.valueOf(r.filasEsperadasOk()),
                String.valueOf(r.wallClockMs()),
                String.valueOf(r.jobExecutionMs()),
                num(r.throughput()),
                String.valueOf(r.readCount()),
                String.valueOf(r.writeCount()),
                String.valueOf(r.filterCount()),
                String.valueOf(r.skipCount()),
                String.valueOf(r.commitCount()),
                String.valueOf(r.rollbackCount()),
                String.valueOf(r.maxParticionMs()),
                String.valueOf(r.sumParticionMs()),
                num(r.skew()),
                num(r.ratioMaxMin()),
                String.valueOf(r.hilosDistintos()),
                String.valueOf(r.hikariPoolSize()),
                String.valueOf(r.cpus()),
                String.valueOf(r.heapMaxMb()),
                r.jobExecutionId() == null ? "" : String.valueOf(r.jobExecutionId()));
    }

    private static String num(double v) {
        return String.format(Locale.ROOT, "%.3f", v);
    }
}
