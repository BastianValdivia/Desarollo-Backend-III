package cl.duoc.bancoxyz.experiment;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.stream.Collectors;

/**
 * Evidencia de QUE METRICAS Y QUE TAGS existen de verdad en este build.
 *
 *     ./mvnw spring-boot:run -Dspring-boot.run.profiles=metricas
 *
 * ------------------------------------------------------------------------
 * POR QUE ESTO NO SE LEE POR HTTP
 * ------------------------------------------------------------------------
 * La pauta sugiere pegar la salida de GET /actuator/metrics. En este proyecto
 * ESE ENDPOINT NO EXISTE, y decirlo es mas honesto que fingir una captura:
 * hay spring-boot-starter-actuator, pero NO spring-boot-starter-web, asi que
 * no se levanta ningun servidor HTTP y los endpoints web de Actuator no se
 * publican. Es lo correcto para una aplicacion batch, que arranca, trabaja y
 * termina; un servidor web abierto durante 3 segundos no sirve para nada.
 *
 * La informacion es exactamente la misma, leida del MeterRegistry, que es la
 * fuente de la que Actuator la sacaria.
 *
 * ------------------------------------------------------------------------
 * LA TRAMPA QUE ESTE VOLCADO DESTAPA
 * ------------------------------------------------------------------------
 * La documentacion oficial de Spring Batch todavia lista los tags como
 * 'name', 'status', 'job.name'. DESDE 5.0 ESO ES FALSO: los nombres reales
 * van CUALIFICADOS con el prefijo de la metrica
 * ('spring.batch.job.name', 'spring.batch.chunk.write.job.name', ...). Quien
 * copie la tabla de la doc y busque .tag("job.name", ...) recibira null y
 * publicara columnas vacias sin ver ni un error. Este archivo es la prueba
 * de cuales son los tags de verdad EN ESTE build.
 */
@Component
@Profile("metricas")
public class VolcadoMetricasMicrometer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(VolcadoMetricasMicrometer.class);

    private static final Path DESTINO =
            Path.of("evidencias", "04-escalado", "metricas-micrometer.txt");

    private final JobLauncher jobLauncher;
    private final FabricaJobsExperimento fabrica;
    private final MeterRegistry meterRegistry;
    private final SondaEntorno entorno;
    private final JdbcTemplate jdbcTemplate;

    public VolcadoMetricasMicrometer(JobLauncher jobLauncher, FabricaJobsExperimento fabrica,
                                     MeterRegistry meterRegistry, SondaEntorno entorno,
                                     JdbcTemplate jdbcTemplate) {
        this.jobLauncher = jobLauncher;
        this.fabrica = fabrica;
        this.meterRegistry = meterRegistry;
        this.entorno = entorno;
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        // Una sola corrida particionada: sin ejecutar nada, el registro estaria
        // vacio (las metricas se dan de alta la primera vez que se usan).
        CasoExperimento caso = new CasoExperimento(
                EstrategiaEscalado.PARTICIONADO, 4, 500, 1000, "evidencia-metricas");

        jdbcTemplate.execute(
                "TRUNCATE banco.transaccion, banco.registro_rechazado, banco.resumen_diario");

        var montaje = fabrica.construir(caso);
        var ejecucion = jobLauncher.run(montaje.job(), new JobParametersBuilder()
                .addString("estrategia", caso.estrategia().name())
                .addLong("runId", System.nanoTime())
                .toJobParameters());
        montaje.cerrar();

        StringBuilder sb = new StringBuilder();
        sb.append("METRICAS MICROMETER REALMENTE REGISTRADAS EN ESTE BUILD\n");
        sb.append("Spring Boot 3.5.16 / Spring Batch 5.2.6\n");
        sb.append("Entorno: ").append(entorno.descripcion()).append("\n");
        sb.append("Registro: ").append(meterRegistry.getClass().getName()).append("\n");
        sb.append("Job de prueba: ").append(caso.etiqueta())
          .append("  estado=").append(ejecucion.getStatus()).append("\n");
        sb.append("""

                NOTA: no hay endpoint HTTP /actuator/metrics porque el proyecto no
                incluye spring-boot-starter-web (es una aplicacion batch, no un
                servidor). Esto se lee del MeterRegistry, que es exactamente la
                fuente que Actuator expondria.

                Los tags de spring.batch.* van CUALIFICADOS con el prefijo de su
                metrica. La tabla de la documentacion oficial ('job.name',
                'status') esta desactualizada desde Spring Batch 5.0: buscar por
                esos nombres devuelve null en silencio.

                """);

        meterRegistry.getMeters().stream()
                .filter(m -> m.getId().getName().startsWith("spring.batch"))
                .sorted(Comparator.comparing(m -> m.getId().getName()))
                .forEach(m -> sb.append(describir(m)).append("\n"));

        sb.append("\n--- Todos los nombres de metrica presentes en el registro ---\n");
        meterRegistry.getMeters().stream()
                .map(m -> m.getId().getName())
                .distinct().sorted()
                .forEach(n -> sb.append(n).append("\n"));

        Files.createDirectories(DESTINO.getParent());
        Files.writeString(DESTINO, sb.toString(), StandardCharsets.UTF_8);
        log.info("Volcado de metricas escrito en {}", DESTINO.toAbsolutePath());
    }

    private String describir(Meter m) {
        String tags = m.getId().getTags().stream()
                .map(t -> t.getKey() + "=" + t.getValue())
                .collect(Collectors.joining(", "));
        String medidas = java.util.stream.StreamSupport
                .stream(m.measure().spliterator(), false)
                .map(ms -> ms.getStatistic() + "=" + ms.getValue())
                .collect(Collectors.joining(", "));
        return "%-28s tipo=%-14s tags[%s]  %s".formatted(
                m.getId().getName(), m.getId().getType(), tags, medidas);
    }
}
