package cl.duoc.bancoxyz.tasklet;

import cl.duoc.bancoxyz.support.PeriodoIntereses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * PASO DE PREPARACION del Job 2: deja la base como estaba antes de liquidar
 * ESTE periodo.
 *
 * Existe una LimpiezaTasklet generica (la del Job 1), pero no sirve aqui: hace
 * DELETE de la tabla ENTERA, y este job necesita borrar solo el periodo que se
 * va a recalcular. Vaciar interes_calculado entera destruiria la liquidacion
 * de enero al recalcular febrero.
 *
 * ------------------------------------------------------------------------
 * POR QUE EL PRIMER DELETE ES OBLIGATORIO (no es "por limpieza")
 * ------------------------------------------------------------------------
 * banco.interes_calculado tiene esta restriccion:
 *
 *   uq_interes_posicion UNIQUE (periodo, cuenta_id, nombre_original,
 *                               saldo_original, edad_original, tipo_original)
 *
 * Fijate en lo que NO incluye: job_execution_id. Eso es deliberado -es lo que
 * permite detectar las 5 filas repetidas DENTRO de una misma corrida- pero
 * tiene una consecuencia: al relanzar el job con el MISMO periodo, las 784
 * filas chocarian TODAS contra la restriccion. Serian 784 DuplicateKeyException,
 * el skipLimit reventaria y el job quedaria FAILED delante del evaluador, que
 * VA a ejecutarlo dos veces (escenario E16).
 *
 * Borrando primero el periodo, la segunda corrida vuelve a insertar las mismas
 * 784 filas limpiamente. Eso es la IDEMPOTENCIA: correr el proceso dos veces
 * deja el mismo resultado que correrlo una. Es el patron "delete and reload"
 * de las cargas de un data warehouse, acotado por la clave de la carga.
 *
 * ------------------------------------------------------------------------
 * POR QUE TAMBIEN SE BORRAN LOS RECHAZOS, Y QUE SE PIERDE CON ELLO
 * ------------------------------------------------------------------------
 * La vista banco.v_cuadratura -que es parte de la entrega- cuenta los rechazos
 * de intereses.csv SIN filtrar por job_execution_id. Si no se borraran, tras
 * dos corridas mostraria 784 de negocio contra 432 de rechazos y PARECERIA un
 * descuadre gravisimo, cuando en realidad solo estaria sumando la evidencia de
 * dos ejecuciones.
 *
 * DECISION CONSCIENTE Y SU PRECIO: se pierde el historico de rechazos entre
 * corridas; en banco.registro_rechazado solo queda la ultima. Se acepta porque
 * el historico de verdad -el que no se toca nunca- vive en banco.control_carga,
 * que esta clavado por job_execution_id y conserva los cuatro contadores de
 * TODAS las ejecuciones. Ademas CuadraturaTasklet cuenta filtrando por
 * job_execution_id, asi que su veredicto seria correcto aunque esta limpieza
 * no existiera: el borrado es para que la VISTA no confunda a quien la lea.
 *
 * ------------------------------------------------------------------------
 * LA ASIMETRIA DE ALCANCE, DECLARADA: ESTE JOB LIQUIDA UN SOLO PERIODO
 * ------------------------------------------------------------------------
 * Los dos DELETE de abajo NO tienen el mismo alcance, y conviene decirlo en voz
 * alta porque es la clase de detalle que muerde meses despues:
 *
 *   banco.interes_calculado  -> se borra SOLO el periodo en curso (WHERE periodo = ?)
 *   banco.registro_rechazado -> se borra el ARCHIVO ENTERO (WHERE archivo_origen = ?)
 *
 * Y hay un tercer criterio distinto: banco.v_cuadratura hace COUNT(*) sobre
 * banco.interes_calculado ENTERA, sin filtrar por periodo ni por ejecucion.
 *
 * Los tres criterios solo coinciden mientras se liquide UN UNICO periodo, que
 * es exactamente el alcance de esta entrega (PeriodoIntereses.POR_DEFECTO es
 * fijo, '2024-01', y lo es a proposito: un defecto que cambiara solo haria que
 * las dos corridas de la prueba de idempotencia usaran periodos distintos y la
 * prueba "pasaria" sin probar nada).
 *
 * Que pasaria al liquidar un segundo mes: el detalle ACUMULA (784 de enero +
 * 784 de febrero = 1568) mientras los rechazos se REESCRIBEN (216), asi que
 * v_cuadratura mostraria 1568 + 216 = 1784 para un fichero de 1000 filas.
 *
 * POR QUE ESO YA NO PUEDE PASAR EN SILENCIO: la comprobacion (3) de
 * CuadraturaTasklet compara las filas del CSV (1000) contra el contenido real
 * de la tabla mas el dead letter. Con dos periodos cargados daria 1000 != 1784
 * y el job terminaria FAILED con el descuadre escrito en el mensaje. O sea: la
 * limitacion sigue existiendo, pero ha dejado de ser una trampa silenciosa y se
 * ha convertido en un error ruidoso, que es lo que se le puede exigir a un
 * control de cuadratura.
 *
 * COMO SE LEVANTARIA LA LIMITACION (fuera del alcance de esta entrega): habria
 * que dar un alcance de periodo a las tres cosas a la vez -anadir una columna
 * de periodo a banco.registro_rechazado, filtrar por ella este segundo DELETE, y
 * filtrar v_cuadratura por el periodo vigente-. Cambiar solo una de las tres
 * empeora las cosas, porque rompe la coincidencia que hoy si se cumple.
 *
 * ------------------------------------------------------------------------
 * LO QUE ESTE TASKLET NO TOCA, Y ES IGUAL DE IMPORTANTE
 * ------------------------------------------------------------------------
 *   banco.cuenta        -> NO SE TOCA JAMAS. Es la tabla que guarda
 *       periodo_aplicado, o sea LA MEMORIA de que este periodo ya se liquido.
 *       Borrarla convertiria la prueba de idempotencia en una farsa: el job
 *       reaplicaria el interes cada vez y la prueba seguiria "pasando" porque
 *       partiria de cero. La guarda de ConsolidarSaldosTasklet depende
 *       enteramente de que esta tabla sobreviva.
 *   banco.control_carga -> tampoco. Es el historial de evidencia.
 */
public class LimpiezaInteresesTasklet implements Tasklet {

    private static final Logger log = LoggerFactory.getLogger(LimpiezaInteresesTasklet.class);

    private static final String ARCHIVO = "intereses.csv";

    private final JdbcTemplate jdbc;
    private final PeriodoIntereses periodoIntereses;

    public LimpiezaInteresesTasklet(JdbcTemplate jdbc, PeriodoIntereses periodoIntereses) {
        this.jdbc = jdbc;
        this.periodoIntereses = periodoIntereses;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // El periodo se resuelve SIEMPRE por PeriodoIntereses, nunca a mano.
        // Si este DELETE usara un periodo distinto del que sella el processor,
        // la limpieza no limpiaria nada y nadie se enteraria. Ver el comentario
        // de PeriodoIntereses.
        String periodo = periodoIntereses.resolver(chunkContext);

        int intereses = jdbc.update(
                "DELETE FROM banco.interes_calculado WHERE periodo = ?", periodo);
        log.info("Limpieza: {} filas borradas de banco.interes_calculado (periodo={})",
                intereses, periodo);

        // El WHERE es OBLIGATORIO: el dead letter lo comparten los 3 jobs.
        // Sin el, se destruiria la evidencia de transacciones.csv.
        int rechazos = jdbc.update(
                "DELETE FROM banco.registro_rechazado WHERE archivo_origen = ?", ARCHIVO);
        log.info("Limpieza: {} filas borradas de banco.registro_rechazado (archivo_origen={})",
                rechazos, ARCHIVO);

        log.info("Limpieza: banco.cuenta NO se toca (conserva periodo_aplicado, "
                + "que es la guarda de idempotencia del step de consolidacion)");

        // FINISHED = "he terminado, no me vuelvas a llamar". Con CONTINUABLE,
        // Spring Batch ejecutaria el tasklet en bucle.
        return RepeatStatus.FINISHED;
    }
}
