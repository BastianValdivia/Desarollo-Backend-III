package cl.duoc.bancoxyz.experiment;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

/**
 * UNA CELDA de la matriz experimental: la combinacion concreta de parametros
 * que se va a cronometrar. Es inmutable (un record) a proposito: si el caso
 * pudiera mutar entre repeticiones, dos filas del CSV con la misma etiqueta
 * podrian venir en realidad de configuraciones distintas y toda la tabla
 * quedaria sin valor probatorio.
 *
 * @param estrategia    secuencial / multi-hilo / particionado
 * @param paralelismo   hilos (MULTI_THREAD) | gridSize (PARTICIONADO) | 1 (SECUENCIAL)
 * @param chunkSize     filas por COMMIT. Es el primero de los dos parametros barridos
 * @param filasDataset  1000 (dataset real) o el amplificado. Es la ESCALA
 * @param fase          F0-baseline | F1-paralelo | F2-confirmacion
 */
public record CasoExperimento(
        EstrategiaEscalado estrategia,
        int paralelismo,
        int chunkSize,
        int filasDataset,
        String fase) {

    /** Cabecera del CSV amplificado; los originales viven en el classpath. */
    public static final String DIRECTORIO_GENERADO = "data/generated";

    /**
     * Etiqueta corta y unica del caso. Se usa para nombrar Job y Step.
     *
     * OJO CON LA LONGITUD: BATCH_STEP_EXECUTION.STEP_NAME es VARCHAR(100) y en
     * particionado Spring Batch le anade el sufijo ":partitionN". Por eso la
     * etiqueta es abreviada (SEC/MTH/PAR) y no lleva '/' ni espacios.
     */
    public String etiqueta() {
        return "%s-p%d-c%d-n%d".formatted(abreviatura(), paralelismo, chunkSize, filasDataset);
    }

    private String abreviatura() {
        return switch (estrategia) {
            case SECUENCIAL   -> "SEC";
            case MULTI_THREAD -> "MTH";
            case PARTICIONADO -> "PAR";
        };
    }

    /**
     * De donde sale el CSV de esta escala.
     *
     * A 1000 filas se usa el archivo ORIGINAL del enunciado, tal cual vino y
     * sin tocar. A cualquier otra escala se usa el derivado determinista que
     * genera AmplificadorDataset en data/generated/, que NO esta en el
     * classpath precisamente para que quede claro que es un artefacto y no
     * parte del entregable de datos.
     */
    public Resource recurso() {
        if (filasDataset == 1000) {
            return new ClassPathResource("data/transacciones.csv");
        }
        return new FileSystemResource(
                DIRECTORIO_GENERADO + "/transacciones_x" + (filasDataset / 1000) + "k.csv");
    }
}
