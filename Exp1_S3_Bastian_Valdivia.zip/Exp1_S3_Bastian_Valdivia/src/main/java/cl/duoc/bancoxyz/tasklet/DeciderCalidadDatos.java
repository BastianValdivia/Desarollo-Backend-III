package cl.duoc.bancoxyz.tasklet;

import cl.duoc.bancoxyz.support.ControlCargaDao;
import cl.duoc.bancoxyz.support.ControlCargaDao.ContadoresCarga;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

/**
 * EL DECIDER: la bifurcacion del flujo del Job 1.
 *
 * Un JobExecutionDecider no procesa datos; solo devuelve una ETIQUETA
 * (FlowExecutionStatus) y el grafo del job decide a que step ir con ella. Es el
 * equivalente a un IF dentro del flujo, pero declarado en la configuracion del
 * job en vez de escondido dentro de un step.
 *
 * Regla: si la tasa de rechazo supera el umbral, la carga se considera
 * DEGRADADA y se pasa por un step de alerta antes de continuar.
 *
 *   tasa = rechazadas / (negocio + rechazadas)
 *
 * POR QUE ESTE BEAN NO LLEVA @JobScope NI @StepScope:
 * el grafo se construye con .next(decider) y .from(decider), y Spring Batch
 * empareja las transiciones por IDENTIDAD DE OBJETO. Con un scope de por medio
 * Spring inyecta un proxy y esa identidad deja de ser fiable. El umbral, que es
 * lo unico que necesitaria el scope, se lee dentro de decide() directamente de
 * los JobParameters, que ahi si estan disponibles.
 */
public class DeciderCalidadDatos implements JobExecutionDecider {

    private static final Logger log = LoggerFactory.getLogger(DeciderCalidadDatos.class);

    /** Etiquetas del flujo. Publicas y constantes para que el @Bean del Job no repita literales. */
    public static final String CALIDAD_OK = "CALIDAD_OK";
    public static final String CALIDAD_DEGRADADA = "CALIDAD_DEGRADADA";

    /** Umbral por defecto: 0.25. La tasa real de transacciones.csv es 215/1000 = 0.215. */
    public static final double UMBRAL_POR_DEFECTO = 0.25;

    private final ControlCargaDao dao;
    private final String archivoOrigen;
    private final String tablaNegocio;
    private final String prefijoWorker;

    public DeciderCalidadDatos(ControlCargaDao dao, String archivoOrigen,
                               String tablaNegocio, String prefijoWorker) {
        this.dao = dao;
        this.archivoOrigen = archivoOrigen;
        this.tablaNegocio = tablaNegocio;
        this.prefijoWorker = prefijoWorker;
    }

    @Override
    public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {

        // stepExecution puede llegar null cuando el decider es lo primero del
        // flujo. Aqui no deberia pasar, pero un decider que revienta con un NPE
        // dejaria el job en un estado incomprensible: mejor ser defensivo.
        if (stepExecution == null) {
            log.debug("Decider invocado sin StepExecution previa");
        }

        double umbral = jobExecution.getJobParameters()
                .getDouble("umbralRechazo", UMBRAL_POR_DEFECTO);

        ContadoresCarga c = dao.contar(jobExecution, prefijoWorker, tablaNegocio, archivoOrigen);

        long procesadas = c.negocio() + c.rechazadas();
        double tasa = procesadas == 0 ? 0.0 : (double) c.rechazadas() / procesadas;

        // Se guarda en el contexto del JOB (no del step) para que quede visible
        // en los metadatos aunque el step de alerta no llegue a ejecutarse.
        jobExecution.getExecutionContext().putDouble("tasaRechazo", tasa);
        jobExecution.getExecutionContext().putDouble("umbralRechazo", umbral);

        String decision = tasa > umbral ? CALIDAD_DEGRADADA : CALIDAD_OK;

        log.info("Decider calidad: rechazadas={} de {} -> tasa={} umbral={} -> {}",
                c.rechazadas(), procesadas, String.format("%.4f", tasa), umbral, decision);

        return new FlowExecutionStatus(decision);
    }
}
