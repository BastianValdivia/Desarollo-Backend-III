package cl.duoc.bancoxyz.domain;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Una fila LISTA PARA INSERTAR en banco.movimiento_anual.
 *
 * ------------------------------------------------------------------------
 * POR QUE ES UNA CLASE CON getXxx/setXxx Y NO UN `record`
 * ------------------------------------------------------------------------
 * El escritor es un JdbcBatchItemWriter con .beanMapped(). Ese mapeador resuelve
 * el parametro :cuentaId del SQL llamando a getCuentaId() por reflexion, que es
 * la convencion JavaBean. Un record expone cuentaId() (sin el prefijo "get"), y
 * el mapeador NO lo encontraria: fallaria en tiempo de EJECUCION, no de
 * compilacion, que es la peor forma de descubrirlo. Mismo motivo por el que
 * InteresCalculado tampoco es un record.
 *
 * ------------------------------------------------------------------------
 * LO QUE ESTA CLASE NO TIENE, Y ES LO IMPORTANTE
 * ------------------------------------------------------------------------
 * NO hay campo `anio` ni campo `montoConSigno`. En banco.movimiento_anual esas
 * dos columnas son GENERATED ALWAYS AS ... STORED:
 *
 *     anio            = EXTRACT(YEAR FROM fecha)
 *     monto_con_signo = signo * monto
 *
 * PostgreSQL las calcula solo, y si aparecieran en la lista de columnas del
 * INSERT rechazaria la sentencia ENTERA con "cannot insert a non-DEFAULT value
 * into column". Es un error de arranque facil de cometer y dificil de leer.
 * No teniendo los campos, es imposible incluirlos por descuido.
 *
 * CUIDADO CON LA ASIMETRIA: en banco.estado_cuenta_anual la columna `anio` es
 * una columna NORMAL y SI tiene que ir en el INSERT del tasklet de
 * consolidacion. La regla "anio nunca va en un INSERT" es falsa; la regla real
 * es "las columnas GENERATED de ESTA tabla no van".
 *
 * ------------------------------------------------------------------------
 * POR QUE SE GUARDAN LOS VALORES "ORIGINAL"
 * ------------------------------------------------------------------------
 * fechaOriginal, transaccionOriginal y montoOriginal conservan el texto CRUDO
 * del CSV. Es lo que convierte la normalizacion en algo AUDITABLE: sin ellos,
 * una vez guardado "DEPOSITO" nadie podria demostrar que en el fichero ponia
 * "deposito" con tilde, ni que un monto positivo venia escrito como "-100".
 * Es la evidencia del criterio de transformacion de datos.
 */
public class MovimientoAnual {

    private Integer cuentaId;

    /** Fecha ya unificada a partir de los 4 formatos del fichero. */
    private LocalDate fecha;
    /** El texto de la fecha tal cual venia, para poder auditar la conversion. */
    private String fechaOriginal;
    /** Cual de los 4 patrones logro leerla ("dd-MM-yyyy", "yyyy/MM/dd"...). */
    private String formatoFecha;

    /** Tipo canonico, en mayusculas y sin tildes: DEPOSITO/RETIRO/PAGO/COMPRA. */
    private String transaccion;
    /** El tipo tal cual venia, que puede llevar tilde y minusculas. */
    private String transaccionOriginal;

    /** +1 para DEPOSITO, -1 para RETIRO/PAGO/COMPRA. Lo decide el TIPO, nunca el monto. */
    private Integer signo;

    /** SIEMPRE en valor absoluto: ck_mov_monto exige monto >= 0. */
    private BigDecimal monto;
    /** El monto tal cual venia, con su signo crudo si lo traia. */
    private String montoOriginal;

    /** Nunca en blanco: si venia vacia se rellena con 'SIN DESCRIPCION'. */
    private String descripcion;

    /** El estado EXCLUYENTE, uno de los 5 de EstadoMovimiento. */
    private String estado;

    /** TODAS las anomalias detectadas, separadas por coma. Puede ir vacia. */
    private String anomalias;

    /** Linea fisica del CSV de la que salio, para poder rastrearla. */
    private Long numeroLinea;

    /** Que ejecucion la escribio. Es lo que permite consolidar solo esta corrida. */
    private Long jobExecutionId;

    public Integer getCuentaId()             { return cuentaId; }
    public void setCuentaId(Integer v)       { this.cuentaId = v; }

    public LocalDate getFecha()              { return fecha; }
    public void setFecha(LocalDate v)        { this.fecha = v; }

    public String getFechaOriginal()         { return fechaOriginal; }
    public void setFechaOriginal(String v)   { this.fechaOriginal = v; }

    public String getFormatoFecha()          { return formatoFecha; }
    public void setFormatoFecha(String v)    { this.formatoFecha = v; }

    public String getTransaccion()           { return transaccion; }
    public void setTransaccion(String v)     { this.transaccion = v; }

    public String getTransaccionOriginal()       { return transaccionOriginal; }
    public void setTransaccionOriginal(String v) { this.transaccionOriginal = v; }

    public Integer getSigno()                { return signo; }
    public void setSigno(Integer v)          { this.signo = v; }

    public BigDecimal getMonto()             { return monto; }
    public void setMonto(BigDecimal v)       { this.monto = v; }

    public String getMontoOriginal()         { return montoOriginal; }
    public void setMontoOriginal(String v)   { this.montoOriginal = v; }

    public String getDescripcion()           { return descripcion; }
    public void setDescripcion(String v)     { this.descripcion = v; }

    public String getEstado()                { return estado; }
    public void setEstado(String v)          { this.estado = v; }

    public String getAnomalias()             { return anomalias; }
    public void setAnomalias(String v)       { this.anomalias = v; }

    public Long getNumeroLinea()             { return numeroLinea; }
    public void setNumeroLinea(Long v)       { this.numeroLinea = v; }

    public Long getJobExecutionId()          { return jobExecutionId; }
    public void setJobExecutionId(Long v)    { this.jobExecutionId = v; }

    /**
     * Lo usa RechazoListener como linea_cruda si esta fila se cayera en la fase
     * WRITE. En el Job 3 no se esperan rechazos en WRITE (los 48 son de
     * PROCESS), pero si la base rechazara una fila por una restriccion, el dead
     * letter debe poder decir CUAL fue, no "MovimientoAnual@1a2b3c".
     */
    @Override
    public String toString() {
        return "cuenta=" + cuentaId + " fecha=" + fecha + " tipo=" + transaccion
                + " signo=" + signo + " monto=" + monto + " estado=" + estado
                + " linea=" + numeroLinea;
    }
}
