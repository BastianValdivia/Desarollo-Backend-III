package cl.duoc.bancoxyz.config;

import cl.duoc.bancoxyz.domain.EstadoCuentaAnual;
import cl.duoc.bancoxyz.domain.MovimientoAnual;
import cl.duoc.bancoxyz.domain.MovimientoAnualRaw;
import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import cl.duoc.bancoxyz.listener.CabeceraInformeCallback;
import cl.duoc.bancoxyz.listener.ChunkErrorListener;
import cl.duoc.bancoxyz.listener.ParticionListener;
import cl.duoc.bancoxyz.listener.PieInformeCallback;
import cl.duoc.bancoxyz.listener.RechazoListener;
import cl.duoc.bancoxyz.partition.RangoCuentaPartitioner;
import cl.duoc.bancoxyz.processor.MovimientoAnualProcessor;
import cl.duoc.bancoxyz.reader.FiltroRangoCuentaReader;
import cl.duoc.bancoxyz.support.ControlCargaDao;
import cl.duoc.bancoxyz.support.NormalizadorFecha;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import cl.duoc.bancoxyz.tasklet.CuadraturaTasklet;
import cl.duoc.bancoxyz.tasklet.GenerarEstadosCuentaTasklet;
import cl.duoc.bancoxyz.tasklet.PrepararAnualesTasklet;
import cl.duoc.bancoxyz.tasklet.ValidarConsolidadoAnualTasklet;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.FieldExtractor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 * JOB 3 - Estados de Cuenta Anuales, PARTICIONADO POR CUENTA.
 *
 * Estructura:
 *
 *   jobEstadosCuentaAnuales
 *     |-- stepPrepararAnuales              (Tasklet: crea results/ y limpia la corrida anterior)
 *     |-- stepCargarMovimientosManager     (PartitionStep: reparte, no procesa)
 *     |     `-- stepCargarMovimientosWorker  x4, en paralelo
 *     |           reader -> processor -> writer
 *     |-- stepGenerarEstadosCuenta         (Tasklet: el GROUP BY -> estado_cuenta_anual)
 *     |-- stepExportarEstadosCuenta        (chunk: BD -> fichero, el informe de auditoria)
 *     |-- stepValidarCuadraturaAnuales     (Tasklet: entrada = negocio + rechazos)
 *     `-- stepValidarConsolidadoAnual      (Tasklet: el agregado es fiel al detalle)
 *
 * ------------------------------------------------------------------------
 * QUE APORTA ESTE JOB QUE NO APORTABAN LOS DOS ANTERIORES
 * ------------------------------------------------------------------------
 * El Job 1 demuestra particionado por lineas y flujo condicional; el Job 2,
 * particionado por clave de negocio, agregacion e idempotencia. Lo NUEVO aqui:
 *
 *   1. UN STEP DE CHUNK QUE ESCRIBE A UN FICHERO. Los dos jobs anteriores solo
 *      leen ficheros y escriben en la base. stepExportarEstadosCuenta hace el
 *      recorrido contrario (JdbcCursorItemReader -> FlatFileItemWriter), que es
 *      el "informe detallado para auditorias" que pide el enunciado.
 *   2. CABECERA Y PIE CALCULADOS (FlatFileHeaderCallback / FooterCallback).
 *   3. UN SEGUNDO NIVEL DE VALIDACION: no solo "no perdi filas" (cuadratura),
 *      tambien "el resumen es fiel al detalle" (consolidado).
 *
 * ------------------------------------------------------------------------
 * LO QUE SE REUTILIZA TAL CUAL, SIN DUPLICAR UNA LINEA
 * ------------------------------------------------------------------------
 * RangoCuentaPartitioner, FiltroRangoCuentaReader, CuadraturaTasklet,
 * RechazoListener, ParticionListener, ChunkErrorListener, BancoXyzSkipPolicy
 * (via el bean skipPolicyBancoXyz), ControlCargaDao, los tres Normalizadores y
 * el pool de hilos. Todas esas clases se escribieron genericas o parametrizadas
 * en los Jobs 1 y 2 precisamente para este momento.
 *
 * Consecuencia importante para la evaluacion: NINGUN fichero de los Jobs 1 y 2
 * se ha modificado para construir el Job 3. Que el Job 1 siga dando
 * 785 + 215 = 1000 no es algo que haya que comprobar con suerte, es cierto POR
 * CONSTRUCCION.
 *
 * SALIDA CONTRACTUAL (docs/analisis-datos.md seccion 6):
 *   banco.movimiento_anual 952 + rechazos 48 = 1000
 *   estados: VALIDA 524 | MONTO_NEGATIVO 173 | DESCRIPCION_AUSENTE 162
 *          | SIGNO_CONTRADICTORIO 81 | MONTO_CERO 12
 *   rechazos: MONTO_AUSENTE 48 (fase PROCESS)
 *   banco.estado_cuenta_anual: 20 filas (cuentas 101..120, anio 2024)
 */
@Configuration
public class AnualesJobConfig {

    /** Tamano del lote: cada 200 filas se hace un COMMIT.
     *  Se vuelve al 200 del Job 1 (y no al 50 del Job 2) porque aqui NO se
     *  esperan rechazos en fase WRITE: los 48 los detecta el processor, y un
     *  skip en PROCESS no obliga a deshacer el chunk. Sin rollbacks que reparar,
     *  el chunk grande solo tiene ventajas: menos commits y menos viajes a la
     *  base. */
    private static final int CHUNK = 200;

    /** Particiones. 4 tramos de 5 cuentas sobre el rango 101..120. */
    private static final int PARTICIONES = TaskExecutorConfig.PARTICIONES;

    // SOBRE EL LIMITE DE OMISIONES: no se declara aqui ninguna constante. Se
    // reutiliza el bean skipPolicyBancoXyz, cuyo limite (500 por defecto) es
    // configurable con la propiedad banco.tolerancia.limite-omisiones. Crear un
    // segundo BancoXyzSkipPolicy con un limite propio habria duplicado un bean
    // que ya existe y habria dejado ese numero fuera de la configuracion.
    //
    // OJO, EL LIMITE ES POR PARTICION Y NO GLOBAL: cada StepExecution lleva su
    // propio contador de omisiones, asi que con 4 particiones el job entero
    // tolera hasta 2000 rechazos, no 500. Con 48 esperados repartidos (unos 12
    // por particion) sobra margen de sobra.
    //
    // Y conviene tenerlo claro: ese numero NO es lo que garantiza que no se
    // pierden filas; es solo un cortafuegos contra un fichero catastroficamente
    // malo. Quien garantiza la integridad es la cuadratura del final.

    private static final String ARCHIVO = "data/cuentas_anuales.csv";
    private static final String ARCHIVO_ORIGEN = "cuentas_anuales.csv";
    private static final String TABLA_NEGOCIO = "banco.movimiento_anual";

    /** Rango de cuentas que contiene el archivo (verificado sobre el CSV). */
    private static final int CUENTA_MIN = 101;
    private static final int CUENTA_MAX = 120;

    /** Prefijo de los steps worker. Con el se filtran sus StepExecution para
     *  contar la entrada sin sumar tambien el agregado del manager. */
    private static final String PREFIJO_WORKER = "stepCargarMovimientosWorker";

    /** Directorio del informe. Relativo a donde se lanza la aplicacion. */
    private static final String DIRECTORIO_SALIDA = "results";

    // ==================================================================
    // 1. PARTITIONER - reparte las cuentas 101..120 en 4 tramos.
    //
    //    Se REUTILIZA RangoCuentaPartitioner del Job 2 tal cual. Con
    //    gridSize=4 y 20 cuentas, ceil(20/4)=5 da exactamente 4 tramos de 5:
    //    101-105, 106-110, 111-115, 116-120.
    //
    //    NOTA HONESTA PARA EL INFORME DE ESCALADO (criterio 4): el reparto por
    //    cuenta NO queda equilibrado, y es esperable. Medido sobre el fichero,
    //    los tramos llevan 256 / 267 / 236 / 241 filas: hasta un 13% de
    //    diferencia entre el mayor y el menor. Un reparto por lineas saldria
    //    perfecto (250 cada uno), pero repartiria por una posicion fisica que no
    //    significa nada para el negocio.
    //
    //    Y otra nota honesta: como la consolidacion la hace un Tasklet SQL
    //    DESPUES de la carga, repartir por lineas tambien daria el resultado
    //    correcto. Se elige por cuenta porque es la unica variante que SEGUIRIA
    //    siendo correcta si algun dia la agregacion se hiciera dentro del
    //    worker, y porque mantiene la coherencia con el Job 2.
    // ==================================================================
    @Bean
    public RangoCuentaPartitioner movimientoPartitioner() {
        return new RangoCuentaPartitioner(CUENTA_MIN, CUENTA_MAX);
    }

    // ==================================================================
    // 2. LECTOR - uno por particion.
    //
    //    Se REUTILIZA FiltroRangoCuentaReader (el envoltorio generico del Job 2)
    //    cambiando solo las dos funciones que lo parametrizan: de que campo sale
    //    la clave y quien la reclama. Es exactamente el uso para el que se
    //    escribio generico.
    //
    //    EL TIPO DE RETORNO ES LA CLASE CONCRETA, no ItemReader. Con @StepScope
    //    Spring crea un proxy; si el tipo declarado fuera la interfaz ItemReader,
    //    el proxy solo implementaria ItemReader, el step no veria el ItemStream,
    //    no llamaria a open()... y la primera lectura reventaria con "Reader must
    //    be open before it can be read".
    // ==================================================================
    @Bean
    @StepScope
    public FiltroRangoCuentaReader<MovimientoAnualRaw> movimientoAnualReader(
            @Value("#{stepExecutionContext['cuentaMin'] ?: " + CUENTA_MIN + "}") Integer cuentaMin,
            @Value("#{stepExecutionContext['cuentaMax'] ?: " + CUENTA_MAX + "}") Integer cuentaMax,
            @Value("#{stepExecutionContext['esPrimera'] ?: 'true'}") String esPrimera,
            @Value("#{stepExecutionContext['esUltima'] ?: 'true'}") String esUltima,
            @Value("#{stepExecutionContext['partitionName'] ?: 'unica'}") String partitionName) {

        FlatFileItemReader<MovimientoAnualRaw> delegado =
                new FlatFileItemReaderBuilder<MovimientoAnualRaw>()
                        // NOMBRE UNICO POR PARTICION. No es cosmetico: el nombre
                        // es el prefijo de las claves que el lector guarda en el
                        // ExecutionContext para poder reanudarse. Si las 4
                        // particiones usaran el mismo nombre, se pisarian esas
                        // claves entre ellas y un reinicio reanudaria cada una
                        // por donde iba otra.
                        .name("movimientoAnualReader-" + partitionName)
                        .resource(new ClassPathResource(ARCHIVO))
                        // CODIFICACION EXPLICITA. Sin esta linea el lector usa el
                        // charset por defecto de la plataforma. En Java 25 ese
                        // charset ya es UTF-8 (JEP 400), asi que hoy funcionaria
                        // igual... por accidente, no por declaracion. Y aqui
                        // importa de verdad: el fichero trae 52 filas con el
                        // deposito acentuado, y una mala decodificacion las
                        // convertiria en un tipo que ck_mov_tipo rechazaria.
                        // Declararlo cuesta una linea y elimina la dependencia
                        // del entorno.
                        .encoding(StandardCharsets.UTF_8.name())
                        .linesToSkip(1)                 // la cabecera
                        .delimited().delimiter(",")
                        .names("cuenta_id", "fecha", "transaccion", "monto", "descripcion")
                        // Se leen los 5 campos como String, sin convertir nada.
                        // Convertir aqui mataria las 48 filas de monto vacio
                        // dentro del lector, y una fila que muere en READ ya no
                        // se puede clasificar. Ver MovimientoAnualRaw.
                        .fieldSetMapper(fs -> new MovimientoAnualRaw(
                                fs.readString("cuenta_id"),
                                fs.readString("fecha"),
                                fs.readString("transaccion"),
                                fs.readString("monto"),
                                fs.readString("descripcion")))
                        .build();

        // Las banderas viajan como String por el ExecutionContext (no tiene
        // putBoolean); aqui se reconvierten. Son las que cierran el agujero de
        // las filas huerfanas: la primera particion absorbe lo que este por
        // debajo del rango, la ultima lo que este por encima y lo ilegible, asi
        // que toda fila tiene EXACTAMENTE un reclamante.
        boolean primera = Boolean.parseBoolean(esPrimera);
        boolean ultima = Boolean.parseBoolean(esUltima);

        return new FiltroRangoCuentaReader<>(
                delegado,
                MovimientoAnualRaw::cuentaId,
                // La regla de filtrado es LA MISMA FUNCION que usa el partitioner
                // para repartir. Que sean el mismo codigo es lo que impide que se
                // desincronicen y que una fila se pierda o se duplique.
                clave -> RangoCuentaPartitioner.reclama(clave, cuentaMin, cuentaMax, primera, ultima));
    }

    // ==================================================================
    // 3. PROCESADOR. @StepScope para poder leer el jobExecutionId, que no
    //    existe todavia cuando arranca la aplicacion.
    //
    //    Los tres normalizadores son @Component y ya estan en el contexto: se
    //    inyectan y se reutilizan, no se instancian aqui.
    // ==================================================================
    @Bean
    @StepScope
    public MovimientoAnualProcessor movimientoAnualProcessor(
            NormalizadorFecha normalizadorFecha,
            NormalizadorMonto normalizadorMonto,
            NormalizadorTexto normalizadorTexto,
            @Value("#{stepExecution.jobExecutionId}") Long jobExecutionId) {

        return new MovimientoAnualProcessor(normalizadorFecha, normalizadorMonto,
                normalizadorTexto, jobExecutionId);
    }

    // ==================================================================
    // 4. ESCRITOR - inserta el lote en una sola llamada. Es thread-safe, asi
    //    que las 4 particiones pueden compartir la misma instancia.
    //
    //    FIJATE EN LO QUE NO ESTA: anio y monto_con_signo NO aparecen en la
    //    lista de columnas. Son GENERATED ALWAYS AS ... STORED y si se
    //    incluyeran, PostgreSQL rechazaria el INSERT ENTERO con "cannot insert
    //    a non-DEFAULT value into column". Tampoco aparecen id (BIGSERIAL) ni
    //    procesado_en (DEFAULT now()).
    // ==================================================================
    @Bean
    public JdbcBatchItemWriter<MovimientoAnual> movimientoAnualWriter(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<MovimientoAnual>()
                .dataSource(dataSource)
                .sql("""
                     INSERT INTO banco.movimiento_anual
                         (cuenta_id, fecha, fecha_original, formato_fecha,
                          transaccion, transaccion_original, signo,
                          monto, monto_original, descripcion,
                          estado, anomalias, numero_linea, job_execution_id)
                     VALUES
                         (:cuentaId, :fecha, :fechaOriginal, :formatoFecha,
                          :transaccion, :transaccionOriginal, :signo,
                          :monto, :montoOriginal, :descripcion,
                          :estado, :anomalias, :numeroLinea, :jobExecutionId)
                     """)
                // beanMapped() resuelve :cuentaId llamando a getCuentaId(). Por
                // eso MovimientoAnual es una clase con getters JavaBean y no un
                // record: un record expone cuentaId() y esto fallaria en tiempo
                // de EJECUCION.
                .beanMapped()
                .build();
    }

    // ==================================================================
    // 5. LISTENER DE RECHAZOS - el dead letter. Se REUTILIZA la clase generica.
    //
    //    @StepScope A PROPOSITO: guarda en campos el nombre del step en curso, y
    //    con 4 particiones a la vez una instancia compartida se pisaria a si
    //    misma y los rechazos quedarian atribuidos a la particion equivocada.
    //
    //    Se le pasa el PlatformTransactionManager para que el INSERT del dead
    //    letter vaya en transaccion PROPIA (REQUIRES_NEW): la evidencia de un
    //    fallo no puede vivir en la transaccion que ese fallo va a deshacer.
    // ==================================================================
    @Bean
    @StepScope
    public RechazoListener<MovimientoAnualRaw, MovimientoAnual> rechazoListenerAnuales(
            JdbcTemplate jdbcTemplate, PlatformTransactionManager transactionManager) {
        return new RechazoListener<>(jdbcTemplate, transactionManager, ARCHIVO_ORIGEN);
    }

    // ==================================================================
    // 6. WORKER - el step que hace el trabajo real, una vez por particion.
    //
    //    NO lleva politica de reintento, a diferencia del Job 2. Es deliberado:
    //    el reintento sirve para fallos de INFRAESTRUCTURA en la escritura, y
    //    aqui los 48 rechazos son de PROCESS, detectados por el processor antes
    //    de tocar la base. Anadir un retry que nunca se dispara solo agregaria
    //    la trampa de ordenacion del builder que documenta InteresesJobConfig,
    //    sin ningun beneficio. Si el Job 3 empezara a tener fallos de red, se
    //    anadiria entonces, copiando aquel patron.
    // ==================================================================
    @Bean
    public Step stepCargarMovimientosWorker(
            JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            FiltroRangoCuentaReader<MovimientoAnualRaw> movimientoAnualReader,
            MovimientoAnualProcessor movimientoAnualProcessor,
            JdbcBatchItemWriter<MovimientoAnual> movimientoAnualWriter,
            RechazoListener<MovimientoAnualRaw, MovimientoAnual> rechazoListenerAnuales,
            ParticionListener particionListener,
            SkipPolicy skipPolicyBancoXyz,
            ChunkErrorListener chunkErrorListener) {

        return new StepBuilder(PREFIJO_WORKER, jobRepository)
                .<MovimientoAnualRaw, MovimientoAnual>chunk(CHUNK, transactionManager)
                .reader(movimientoAnualReader)
                .processor(movimientoAnualProcessor)
                .writer(movimientoAnualWriter)
                .faultTolerant()

                // ---- OMISION (datos sucios) -------------------------------
                // Se REUTILIZA el bean de politica ya existente, que sabe
                // distinguir un dato sucio (se omite) de un fallo de
                // infraestructura (que el step falle). NO se combina con
                // .skip()/.skipLimit(): mezclar los dos modelos hace que Spring
                // los una con un OR y el veto propio quede anulado.
                .skipPolicy(skipPolicyBancoXyz)

                // Un dato sucio detectado por el processor NO es un fallo de
                // base de datos: la transaccion sigue sana, asi que no hace
                // falta deshacer el lote entero por el. Sin esta linea, cada una
                // de las 48 filas malas provocaria el rollback de su chunk de
                // 200 y el reproceso fila a fila: correcto, pero mucho mas lento
                // y con un log ilegible.
                .noRollback(RegistroInvalidoException.class)

                // ---- LISTENERS --------------------------------------------
                // Los casts NO son decorativos: rechazoListenerAnuales
                // implementa dos interfaces y sin cast el compilador no sabe a
                // que sobrecarga de .listener() te refieres.
                .listener((SkipListener<MovimientoAnualRaw, MovimientoAnual>) rechazoListenerAnuales)
                .listener((StepExecutionListener) rechazoListenerAnuales)
                .listener((StepExecutionListener) particionListener)
                .listener((ChunkListener) chunkErrorListener)
                // ---- REINICIO DE LA MISMA JobInstance ----------------------
                // Igual que en el Job 1: la bandera del WORKER es la que recibe
                // el SimpleStepExecutionSplitter (PartitionStepBuilder.build()
                // hace allow = step.isAllowStartIfComplete() y pisa la del
                // manager), asi que sin ella un reinicio solo relanzaria las
                // particiones FAILED mientras la preparacion ya vacio la tabla
                // entera: recarga parcial y cuadratura "OK" sobre datos a
                // medias. Ver el comentario largo de
                // TransaccionesJobConfig.stepCargarTransaccionesWorker.
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 7. MANAGER - el PartitionStep. No procesa datos: reparte y lanza.
    //
    //    .taskExecutor(...) es OBLIGATORIO. Sin el, Spring usa un ejecutor
    //    SINCRONO sin avisar y las particiones corren una detras de otra:
    //    tendrias un "particionado" que en realidad es secuencial, y encima mas
    //    lento por el trabajo extra de repartir.
    //
    //    Nada de .partitionHandler() explicito: ese metodo SUSTITUYE al handler
    //    por defecto y con el se perderian gridSize y taskExecutor, que es otra
    //    forma sutil de acabar ejecutando en serie.
    //
    //    Aqui gridSize (4) coincide con los hilos del pool (4), asi que las 4
    //    particiones arrancan a la vez de verdad.
    // ==================================================================
    @Bean
    public Step stepCargarMovimientosManager(
            JobRepository jobRepository,
            Step stepCargarMovimientosWorker,
            RangoCuentaPartitioner movimientoPartitioner,
            ThreadPoolTaskExecutor poolParticiones) {

        return new StepBuilder("stepCargarMovimientosManager", jobRepository)
                .partitioner(stepCargarMovimientosWorker.getName(), movimientoPartitioner)
                .step(stepCargarMovimientosWorker)
                .gridSize(PARTICIONES)
                .taskExecutor(poolParticiones)
                // ---- REINICIO DE LA MISMA JobInstance ----------------------
                // Pareja obligatoria del allowStartIfComplete del step de
                // preparacion: si la limpieza se repite en un reinicio, la
                // recarga tiene que repetirse tambien. Sin esto, SimpleStepHandler
                // salta este step por estar COMPLETED, la tabla queda vacia y el
                // job termina COMPLETED mintiendo. Ver el comentario largo de
                // TransaccionesJobConfig.stepCargarTransaccionesManager.
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 8. PREPARACION - crea results/ y limpia la corrida anterior.
    //
    //    Va ANTES del manager. Esto NO contradice la regla "cada job arranca por
    //    su step manager": esa regla dice que la FASE DE CARGA entra por el
    //    manager y nunca directamente por el worker, no que el job no pueda
    //    tener un paso de preparacion previo.
    //
    //    allowStartIfComplete(true) resuelve algo DISTINTO del DELETE: por
    //    defecto, al REINICIAR una JobInstance fallida, un step ya COMPLETED se
    //    salta. Sin esta bandera la limpieza no volveria a ejecutarse y el
    //    reinicio chocaria con las filas que dejo el intento anterior.
    // ==================================================================
    @Bean
    public Step stepPrepararAnuales(JobRepository jobRepository,
                                    PlatformTransactionManager transactionManager,
                                    JdbcTemplate jdbcTemplate) {
        Path salida = Paths.get(DIRECTORIO_SALIDA);
        Tasklet preparar = new PrepararAnualesTasklet(jdbcTemplate, salida);

        return new StepBuilder("stepPrepararAnuales", jobRepository)
                // En Spring Batch 5.2.x la firma vigente es tasklet(tasklet, txManager);
                // tasklet(tasklet) a secas esta deprecada.
                .tasklet(preparar, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 9. CONSOLIDACION - el GROUP BY que llena banco.estado_cuenta_anual.
    // ==================================================================
    @Bean
    public Step stepGenerarEstadosCuenta(JobRepository jobRepository,
                                         PlatformTransactionManager transactionManager,
                                         NamedParameterJdbcTemplate namedJdbcTemplate) {
        Tasklet generar = new GenerarEstadosCuentaTasklet(namedJdbcTemplate);

        return new StepBuilder("stepGenerarEstadosCuenta", jobRepository)
                .tasklet(generar, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 10. LECTOR DEL INFORME - de la base al fichero.
    //
    //     JdbcCursorItemReader mantiene un CURSOR abierto y trae las filas de
    //     una en una, en vez de cargar el resultado entero en memoria. Con 20
    //     filas da igual, pero es el patron correcto y el que aguantaria un
    //     informe de millones de filas sin cambiar nada.
    //
    //     TIPO DE RETORNO CONCRETO, por la misma razon de proxy que el lector
    //     del CSV: con @StepScope y un tipo declarado ItemReader, el step no
    //     veria el ItemStream y el cursor no se abriria.
    //
    //     PARAMETROS POSICIONALES (?) Y NO :nombrados. JdbcCursorItemReader
    //     trabaja con un PreparedStatement de JDBC puro, que solo entiende "?".
    //     Un ":id" no se sustituiria: se enviaria tal cual a PostgreSQL y la
    //     consulta fallaria con un error de sintaxis. Los nombres solo funcionan
    //     con NamedParameterJdbcTemplate, que es lo que usa el tasklet anterior.
    //
    //     ORDER BY cuenta_id: sin un orden explicito, PostgreSQL puede devolver
    //     las filas en cualquier orden. Para un informe que es EVIDENCIA de una
    //     entrega, dos ejecuciones deben producir ficheros identicos.
    // ==================================================================
    @Bean
    @StepScope
    public JdbcCursorItemReader<EstadoCuentaAnual> estadoCuentaReader(
            DataSource dataSource,
            @Value("#{stepExecution.jobExecutionId}") Long jobExecutionId) {

        return new JdbcCursorItemReaderBuilder<EstadoCuentaAnual>()
                .name("estadoCuentaReader")
                .dataSource(dataSource)
                .sql("""
                     SELECT cuenta_id, anio, n_movimientos,
                            n_depositos, n_retiros, n_pagos, n_compras,
                            total_depositos, total_retiros, total_pagos, total_compras,
                            saldo_neto, n_anomalias, primera_fecha, ultima_fecha
                       FROM banco.estado_cuenta_anual
                      WHERE job_execution_id = ?
                      ORDER BY cuenta_id
                     """)
                .preparedStatementSetter(ps -> ps.setLong(1, jobExecutionId))
                .rowMapper(AnualesJobConfig::mapearEstadoCuenta)
                .build();
    }

    /**
     * Convierte una fila del ResultSet en un EstadoCuentaAnual.
     *
     * Se escribe a mano en vez de usar BeanPropertyRowMapper por dos motivos:
     * el objeto es inmutable (no tiene setters que el mapeador automatico
     * pudiera llamar), y asi la correspondencia columna -> campo queda a la
     * vista y no depende de que los nombres coincidan por casualidad.
     *
     * getObject(..., LocalDate.class) y no getDate(): getDate devuelve un
     * java.sql.Date, la clase antigua, que ademas arrastra zona horaria. El
     * driver de PostgreSQL sabe entregar directamente el tipo moderno.
     */
    private static EstadoCuentaAnual mapearEstadoCuenta(ResultSet rs, int fila) throws SQLException {
        return new EstadoCuentaAnual(
                rs.getInt("cuenta_id"),
                rs.getInt("anio"),
                rs.getInt("n_movimientos"),
                rs.getInt("n_depositos"),
                rs.getInt("n_retiros"),
                rs.getInt("n_pagos"),
                rs.getInt("n_compras"),
                rs.getBigDecimal("total_depositos"),
                rs.getBigDecimal("total_retiros"),
                rs.getBigDecimal("total_pagos"),
                rs.getBigDecimal("total_compras"),
                rs.getBigDecimal("saldo_neto"),
                rs.getInt("n_anomalias"),
                rs.getObject("primera_fecha", LocalDate.class),
                rs.getObject("ultima_fecha", LocalDate.class));
    }

    // ==================================================================
    // 11. ESCRITOR DEL INFORME - el fichero de auditoria.
    //
    //     TIPO CONCRETO FlatFileItemWriter y no ItemWriter: es LA causa numero
    //     uno de WriterNotOpenException. Con @StepScope y el tipo declarado como
    //     interfaz, Spring genera un proxy JDK que solo implementa ItemWriter;
    //     el step no ve el ItemStream, nunca llama a open(), y el primer write
    //     revienta con "Writer must be open before it can be written to".
    //
    //     Las otras dos causas de ese mismo error, y como se evitan aqui:
    //       - el directorio no existe -> lo crea stepPrepararAnuales.
    //       - registrar el writer a mano con .stream(...) ademas del
    //         auto-registro de SimpleStepBuilder -> doble open(). Por eso el
    //         step de exportacion NO llama a .stream() sobre reader ni writer.
    //
    //     shouldDeleteIfExists(true): si el fichero de esta ejecucion ya
    //     existiera se sobrescribe. Sin esto, el writer ANADIRIA al final y el
    //     informe acabaria con dos cabeceras y dos pies.
    //
    //     El nombre lleva el jobExecutionId: cada corrida deja su propio
    //     fichero y las evidencias de ejecuciones distintas no se pisan.
    // ==================================================================
    @Bean
    @StepScope
    public FlatFileItemWriter<EstadoCuentaAnual> informeWriter(
            JdbcTemplate jdbcTemplate,
            @Value("#{stepExecution.jobExecutionId}") Long jobExecutionId) {

        Path fichero = Paths.get(DIRECTORIO_SALIDA,
                "estados-cuenta-anual-" + jobExecutionId + ".csv");

        return new FlatFileItemWriterBuilder<EstadoCuentaAnual>()
                .name("informeWriter")
                .resource(new FileSystemResource(fichero.toFile()))
                // Codificacion explicita tambien en la salida: de nada sirve
                // leer bien si luego se escribe con el charset del sistema.
                .encoding(StandardCharsets.UTF_8.name())
                .shouldDeleteIfExists(true)
                .headerCallback(new CabeceraInformeCallback(jobExecutionId))
                .footerCallback(new PieInformeCallback(jdbcTemplate, jobExecutionId))
                .delimited().delimiter(";")
                // FieldExtractor EXPLICITO en vez de .names("cuentaId", ...).
                //
                // El motivo es una trampa real de la convencion JavaBean: para
                // getNMovimientos(), el nombre de propiedad NO es "nMovimientos"
                // sino "NMovimientos", porque la especificacion solo pasa a
                // minuscula la primera letra cuando la SEGUNDA no es mayuscula.
                // Con .names("nMovimientos") el informe fallaria en ejecucion
                // por una propiedad "inexistente". Con una lambda no hay
                // reflexion, no hay convencion que adivinar, y el compilador
                // verifica cada campo.
                .fieldExtractor((FieldExtractor<EstadoCuentaAnual>) e -> new Object[]{
                        e.getCuentaId(), e.getAnio(), e.getNMovimientos(),
                        e.getNDepositos(), e.getNRetiros(), e.getNPagos(), e.getNCompras(),
                        e.getTotalDepositos(), e.getTotalRetiros(),
                        e.getTotalPagos(), e.getTotalCompras(),
                        e.getSaldoNeto(), e.getNAnomalias(),
                        e.getPrimeraFecha(), e.getUltimaFecha()})
                .build();
    }

    // ==================================================================
    // 12. EXPORTACION - el step de chunk que produce el informe.
    //
    //     SIN taskExecutor y SIN particionar, A PROPOSITO: FlatFileItemWriter NO
    //     es thread-safe. Varios hilos escribiendo en el mismo fichero
    //     entrelazarian las lineas y corromperian la salida. Son 20 filas:
    //     paralelizarlo no ahorraria nada y solo podria romperlo.
    //
    //     Es el contraejemplo util del criterio 4: particionar no siempre suma.
    //     Se paraleliza donde el trabajo es divisible y el destino lo soporta
    //     (la carga a la base), y se deja en serie donde el destino es un
    //     recurso unico y secuencial (un fichero).
    //
    //     chunk(20): un solo commit para el informe entero.
    // ==================================================================
    @Bean
    public Step stepExportarEstadosCuenta(
            JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            JdbcCursorItemReader<EstadoCuentaAnual> estadoCuentaReader,
            FlatFileItemWriter<EstadoCuentaAnual> informeWriter) {

        return new StepBuilder("stepExportarEstadosCuenta", jobRepository)
                .<EstadoCuentaAnual, EstadoCuentaAnual>chunk(20, transactionManager)
                .reader(estadoCuentaReader)
                // Sin processor: la fila se exporta tal como sale de la base.
                // Un processor identidad solo anadiria una llamada por fila.
                .writer(informeWriter)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 13. CUADRATURA - hace FALLAR el job si se perdio alguna fila.
    //
    //     Se REUTILIZA CuadraturaTasklet tal cual, sin tocar una linea: ya
    //     estaba parametrizada (archivo, tabla, prefijo del worker) justo para
    //     esto. Es la ventaja de haberla escrito generica en el Job 1.
    //
    //     El nombre del step lleva el sufijo "Anuales" porque dos StepBuilder
    //     con el mismo nombre se confundirian entre si en BATCH_STEP_EXECUTION.
    // ==================================================================
    @Bean
    public Step stepValidarCuadraturaAnuales(JobRepository jobRepository,
                                             PlatformTransactionManager transactionManager,
                                             ControlCargaDao controlCargaDao) {
        // El CSV de origen y su numero de lineas de cabecera se pasan para que la
        // cuadratura pueda comparar el CONTENIDO REAL de la tabla contra las filas
        // del fichero, y no solo contra lo que hizo esta ejecucion. Ver el javadoc
        // de CuadraturaTasklet, comprobacion (3).
        Tasklet cuadratura = new CuadraturaTasklet(controlCargaDao, ARCHIVO_ORIGEN,
                TABLA_NEGOCIO, PREFIJO_WORKER, new ClassPathResource(ARCHIVO), 1);

        return new StepBuilder("stepValidarCuadraturaAnuales", jobRepository)
                .tasklet(cuadratura, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 14. COHERENCIA DEL CONSOLIDADO - el agregado es fiel al detalle.
    //     Responde una pregunta distinta de la cuadratura; ver la clase.
    // ==================================================================
    @Bean
    public Step stepValidarConsolidadoAnual(JobRepository jobRepository,
                                            PlatformTransactionManager transactionManager,
                                            JdbcTemplate jdbcTemplate) {
        Tasklet validar = new ValidarConsolidadoAnualTasklet(jdbcTemplate);

        return new StepBuilder("stepValidarConsolidadoAnual", jobRepository)
                .tasklet(validar, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 15. JOB - flujo LINEAL.
    //
    //     EL NOMBRE DEL BEAN ES INNEGOCIABLE: LanzadorJobs.archivoDe() ya hace
    //     un switch sobre la cadena exacta "jobEstadosCuentaAnuales", y el
    //     checklist de plan-maestro.md lo exige literalmente.
    //
    //     Se encadena con .next(), que ya implica "solo si el anterior fue
    //     bien". Deliberadamente NO se usa on("*"), porque ese comodin casa
    //     tambien con FAILED: un step roto seguiria hacia adelante y el job
    //     podria acabar COMPLETED mintiendo.
    //
    //     ORDEN DE LOS DOS ULTIMOS STEPS: la exportacion va ANTES de las
    //     validaciones. Puede parecer al reves -validar y luego exportar-, pero
    //     interesa que el informe se escriba aunque despues algo no cuadre: si
    //     el job falla, ese fichero es la evidencia principal para diagnosticar
    //     POR QUE fallo. Validar primero y abortar dejaria el directorio vacio
    //     justo el dia que mas falta hace mirarlo. Es el mismo criterio que
    //     sigue CuadraturaTasklet al guardar la evidencia antes de lanzar.
    //
    //     RunIdIncrementer anade un parametro distinto en cada lanzamiento para
    //     poder ejecutar el job dos veces seguidas. Sin esto, la segunda vez
    //     reventaria con JobInstanceAlreadyCompleteException... y la segunda
    //     ejecucion es justo la que demuestra la idempotencia.
    // ==================================================================
    @Bean
    public Job jobEstadosCuentaAnuales(JobRepository jobRepository,
                                       Step stepPrepararAnuales,
                                       Step stepCargarMovimientosManager,
                                       Step stepGenerarEstadosCuenta,
                                       Step stepExportarEstadosCuenta,
                                       Step stepValidarCuadraturaAnuales,
                                       Step stepValidarConsolidadoAnual) {

        return new JobBuilder("jobEstadosCuentaAnuales", jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(stepPrepararAnuales)
                .next(stepCargarMovimientosManager)
                .next(stepGenerarEstadosCuenta)
                .next(stepExportarEstadosCuenta)
                .next(stepValidarCuadraturaAnuales)
                .next(stepValidarConsolidadoAnual)
                .build();
    }
}
