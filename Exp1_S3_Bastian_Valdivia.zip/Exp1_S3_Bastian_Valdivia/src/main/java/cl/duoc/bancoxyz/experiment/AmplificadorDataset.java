package cl.duoc.bancoxyz.experiment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Genera un CSV amplificado replicando el original N veces.
 *
 * ------------------------------------------------------------------------
 * POR QUE HACE FALTA AMPLIFICAR
 * ------------------------------------------------------------------------
 * Con 1000 filas, el trabajo util cabe en unas decenas de milisegundos y el
 * coste FIJO de arrancar un job (crear el pool de hilos, dar de alta la
 * JobExecution y N StepExecution en la base de metadatos, abrir conexiones)
 * es del mismo orden o mayor. A esa escala el paralelismo no puede ganar por
 * aritmetica, no por mala configuracion. Medir SOLO ahi daria una conclusion
 * verdadera pero incompleta: "el paralelismo no sirve", cuando lo cierto es
 * "el paralelismo no sirve A ESTE VOLUMEN". Con la segunda escala se puede
 * senalar el volumen a partir del cual si compensa.
 *
 * ------------------------------------------------------------------------
 * REGLAS DE LEGITIMIDAD (todas se cumplen y se declaran en docs/escalado.md)
 * ------------------------------------------------------------------------
 *  1. Los CSV originales NO se tocan. Se leen del classpath, de solo lectura.
 *  2. El generador es DETERMINISTA: sin azar, sin semillas, sin fechas. Dos
 *     ejecuciones producen archivos byte a byte identicos.
 *  3. Se preservan las proporciones de defectos: replicar x N mantiene
 *     exactamente 215/1000 rechazos, 136/1000 montos negativos, etc.
 *  4. Se RE-SECUENCIA el id. banco.transaccion tiene id como PRIMARY KEY;
 *     replicar sin tocarlo daria N filas con id=1 y el experimento pasaria a
 *     medir violaciones de restriccion en vez de rendimiento.
 *  5. El derivado vive en data/generated/, fuera del classpath, para que
 *     quede claro que es un artefacto reproducible y no parte del entregable.
 */
public final class AmplificadorDataset {

    private static final Logger log = LoggerFactory.getLogger(AmplificadorDataset.class);

    /** Indice de la columna id en transacciones.csv (id,fecha,monto,tipo). */
    private static final int COLUMNA_ID = 0;

    private AmplificadorDataset() {
    }

    /**
     * @param origen  recurso del classpath con el CSV original (con cabecera)
     * @param destino ruta del archivo derivado
     * @param factor  numero de replicas
     * @return numero de filas de datos escritas
     */
    public static int amplificar(ClassPathResource origen, Path destino, int factor) throws IOException {
        if (Files.exists(destino)) {
            long filas = contarFilasDeDatos(destino);
            log.info("El dataset amplificado ya existe ({} filas): {}", filas, destino);
            return (int) filas;
        }

        List<String> cuerpo = new ArrayList<>();
        String cabecera;
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(origen.getInputStream(), StandardCharsets.UTF_8))) {
            cabecera = br.readLine();
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.isBlank()) {
                    cuerpo.add(linea);
                }
            }
        }

        Files.createDirectories(destino.getParent());
        int escritas = 0;
        try (BufferedWriter out = Files.newBufferedWriter(destino, StandardCharsets.UTF_8)) {
            out.write(cabecera);
            out.newLine();
            long id = 1;
            for (int replica = 0; replica < factor; replica++) {
                for (String linea : cuerpo) {
                    // EL -1 NO ES OPCIONAL. split(",") a secas DESCARTA los campos
                    // vacios del final, asi que una fila como "7,2024-01-01,,credito"
                    // se convertiria en 3 columnas y al recomponerla perderias el
                    // monto vacio. Y los montos vacios son 160 de los 215 rechazos:
                    // sin ellos el dataset amplificado NO tendria la misma
                    // proporcion de defectos y la comparacion entre escalas seria
                    // falsa. El -1 conserva los campos vacios.
                    String[] cols = linea.split(",", -1);
                    cols[COLUMNA_ID] = Long.toString(id++);
                    out.write(String.join(",", cols));
                    out.newLine();
                    escritas++;
                }
            }
        }
        log.info("Dataset amplificado x{} generado: {} filas en {}", factor, escritas, destino);
        return escritas;
    }

    private static long contarFilasDeDatos(Path archivo) throws IOException {
        try (var lineas = Files.lines(archivo, StandardCharsets.UTF_8)) {
            return lineas.filter(l -> !l.isBlank()).count() - 1;   // menos la cabecera
        }
    }
}
