package cl.duoc.bancoxyz.tasklet;

import cl.duoc.bancoxyz.support.ContadorFilasCsv;
import cl.duoc.bancoxyz.support.ControlCargaDao;
import cl.duoc.bancoxyz.support.ControlCargaDao.ContadoresCarga;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.core.io.Resource;

import java.util.ArrayList;
import java.util.List;

/**
 * LA DEFENSA DE LA REGLA DE ORO: entrada = negocio + rechazadas + filtradas.
 *
 * Un proceso batch que pierde filas en silencio es peor que uno que falla: el
 * fallo se ve, la perdida no. Este step convierte "he perdido filas" en un job
 * FAILED, que es un hecho observable en BATCH_JOB_EXECUTION.
 *
 * ------------------------------------------------------------------------
 * LAS TRES COMPROBACIONES, Y POR QUE NINGUNA SOBRA
 * ------------------------------------------------------------------------
 * Durante un tiempo esta clase hizo SOLO la comprobacion (2), y por eso se podia
 * enganar a si misma. Las tres juntas cierran el agujero:
 *
 *  (1) LA ENTRADA SE PUDO MEDIR.
 *      Si ControlCargaDao no encuentra ninguna StepExecution de worker devuelve
 *      ContadoresCarga.NO_MEDIBLE. Antes devolvia 0, y 0 es exactamente el unico
 *      valor que hace pasar la comprobacion (2), porque 0 == 0+0+0 es cierto POR
 *      VACUIDAD. Un fallo de medicion se disfrazaba de carga perfecta.
 *
 *  (2) LO QUE HIZO ESTA EJECUCION CUADRA.
 *      entrada == negocio + rechazadas + filtradas, todo acotado a
 *      job_execution_id. Es la comprobacion clasica y detecta la fila que se
 *      pierde entre el lector y el escritor.
 *
 *  (3) LO QUE CONTIENE LA TABLA ES EL FICHERO ENTERO.  &lt;-- la que faltaba
 *      filas del CSV == COUNT(*) de la tabla de negocio + COUNT(*) del dead
 *      letter para este archivo, SIN filtrar por job_execution_id.
 *
 *      Por que hace falta: el step de preparacion borra con un alcance (la tabla
 *      entera, el archivo entero) que NO es el alcance de los contadores (una
 *      ejecucion). Mientras la cuadratura solo validaba "lo que hizo esta
 *      ejecucion", salia coherente consigo misma y FALSA. Dos casos reales:
 *
 *        - Reinicio en el que la limpieza se repite y la recarga no: la tabla
 *          queda VACIA, y 0 == 0+0+0 daba "OK".
 *        - Reinicio en el que solo se relanza la particion que fallo: la tabla
 *          queda con unas 250 filas de 1000, y 250 == 196+54 daba "OK".
 *
 *      La comprobacion (3) no se puede enganar asi porque su referencia no es el
 *      job: es el FICHERO, que es lo unico que dice cuantas filas TENDRIA que
 *      haber. Es el mismo numero que usa LineRangePartitioner para repartir, via
 *      ContadorFilasCsv, para que repartidor y verificador no puedan discrepar.
 *
 * ------------------------------------------------------------------------
 * ORDEN DE LAS OPERACIONES (sigue siendo lo importante de esta clase)
 * ------------------------------------------------------------------------
 *   1. contar
 *   2. ESCRIBIR la fila de control_carga en una transaccion PROPIA (REQUIRES_NEW)
 *   3. y SOLO DESPUES, si algo no cuadra, lanzar la excepcion
 * Si se hiciera al reves, el rollback provocado por la excepcion borraria la
 * fila de control_carga: el job fallaria sin dejar rastro de por que. Guardar
 * primero la evidencia y romper despues es el patron correcto.
 *
 * Se acumulan TODOS los problemas y se lanza UNA excepcion con todos dentro, en
 * vez de cortar en el primero: si fallan dos cosas, cortar en la primera obliga
 * a reejecutar el job entero para enterarse de la segunda.
 *
 * La clase esta PARAMETRIZADA (archivo, tabla, prefijo del worker, recurso de
 * origen) para poder reutilizarla tal cual en los tres Jobs sin copiar codigo.
 */
public class CuadraturaTasklet implements Tasklet {

    private static final Logger log = LoggerFactory.getLogger(CuadraturaTasklet.class);

    private final ControlCargaDao dao;
    private final String archivoOrigen;
    private final String tablaNegocio;
    private final String prefijoWorker;

    /** El CSV de origen. Es la referencia de la comprobacion (3). */
    private final Resource recursoOrigen;
    private final int lineasCabecera;

    public CuadraturaTasklet(ControlCargaDao dao, String archivoOrigen,
                             String tablaNegocio, String prefijoWorker,
                             Resource recursoOrigen, int lineasCabecera) {
        this.dao = dao;
        this.archivoOrigen = archivoOrigen;
        this.tablaNegocio = tablaNegocio;
        this.prefijoWorker = prefijoWorker;
        this.recursoOrigen = recursoOrigen;
        this.lineasCabecera = lineasCabecera;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        JobExecution jobExecution = chunkContext.getStepContext().getStepExecution().getJobExecution();

        // Contraste explicito: se ven los 4 workers Y el manager con el agregado.
        // Sirve para comprobar de un vistazo que NO estamos sumando el doble.
        dao.volcarContadores(jobExecution);

        ContadoresCarga c = dao.contar(jobExecution, prefijoWorker, tablaNegocio, archivoOrigen);

        long duracionMs = jobExecution.getStartTime() == null ? 0L
                : java.time.Duration.between(jobExecution.getStartTime(),
                        java.time.LocalDateTime.now()).toMillis();

        // PASO 2: la evidencia se confirma ANTES de cualquier posible excepcion.
        dao.upsert(c, jobExecution.getJobInstance().getJobName(), jobExecution.getId(),
                archivoOrigen, duracionMs);

        // ==============================================================
        // PASO 3: las tres comprobaciones. Se acumulan y se lanza al final.
        // ==============================================================
        List<String> problemas = new ArrayList<>();

        // --- (1) la entrada se pudo medir ---
        if (!c.entradaMedible()) {
            problemas.add(String.format(
                    "NO SE PUDO MEDIR LA ENTRADA de %s: no hay ninguna StepExecution con prefijo"
                            + " '%s' en job_execution_id=%d. Esto pasa cuando el step de carga se"
                            + " SALTO por estar ya COMPLETED en un reinicio, o cuando el"
                            + " particionador no genero ninguna particion. No se puede declarar"
                            + " buena una cuadratura que no se ha podido calcular.",
                    archivoOrigen, prefijoWorker, jobExecution.getId()));
        }

        // --- (2) lo que hizo esta ejecucion cuadra ---
        if (c.entradaMedible() && !c.cuadra()) {
            problemas.add(String.format(
                    "CUADRATURA DE LA EJECUCION ROTA en %s: entrada=%d pero negocio=%d +"
                            + " rechazadas=%d + filtradas=%d = %d. Faltan %d filas.",
                    archivoOrigen, c.entrada(), c.negocio(), c.rechazadas(), c.filtradas(),
                    c.negocio() + c.rechazadas() + c.filtradas(),
                    c.entrada() - (c.negocio() + c.rechazadas() + c.filtradas())));
        }

        // --- (3) la tabla contiene el fichero entero ---
        // Se cuenta el fichero AQUI y no antes porque este es el unico numero
        // que no depende de nada que haya hecho el job: es la verdad de partida.
        long filasFichero = ContadorFilasCsv.contar(recursoOrigen, lineasCabecera);
        long negocioTotal = dao.contarNegocioTotal(tablaNegocio);
        long rechazadasTotal = dao.contarRechazadasTotal(archivoOrigen);
        long enBase = negocioTotal + rechazadasTotal;

        if (filasFichero != enBase) {
            problemas.add(String.format(
                    "CONTENIDO INCOMPLETO tras cargar %s: el fichero trae %d filas de datos pero"
                            + " en la base hay %d (%s=%d + registro_rechazado=%d). El alcance que"
                            + " BORRA el step de preparacion es la tabla/archivo entero, asi que"
                            + " el alcance que se verifica tiene que ser el mismo."
                            + " Diferencia: %d filas.",
                    archivoOrigen, filasFichero, enBase, tablaNegocio, negocioTotal,
                    rechazadasTotal, filasFichero - enBase));
        }

        if (!problemas.isEmpty()) {
            throw new IllegalStateException(String.format(
                    "REGLA DE ORO INCUMPLIDA en %s (%d problema(s), job_execution_id=%d): %s",
                    archivoOrigen, problemas.size(), jobExecution.getId(),
                    String.join(" | ", problemas)));
        }

        log.info("CUADRATURA OK en {}: ejecucion {} = {} + {} + {} | contenido real {} = {} + {}"
                        + " (filas del fichero: {})",
                archivoOrigen, c.entrada(), c.negocio(), c.rechazadas(), c.filtradas(),
                enBase, negocioTotal, rechazadasTotal, filasFichero);

        return RepeatStatus.FINISHED;
    }
}
