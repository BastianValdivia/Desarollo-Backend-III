package cl.duoc.bancoxyz.tasklet;

import cl.duoc.bancoxyz.support.PeriodoIntereses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * LA AGREGACION del Job 2: de 784 posiciones individuales a 50 cuentas
 * consolidadas en banco.cuenta.
 *
 * Es el equivalente exacto de un GROUP BY de Spark, y por eso se hace con UNA
 * sentencia SQL y no con un step de chunk que lea, sume en memoria y escriba.
 * Agregar 784 filas trayendolas a Java seria mover los datos hasta el codigo
 * para hacer lo que el motor de base de datos hace mejor y sin transferir
 * nada. La regla practica: si la transformacion se expresa como GROUP BY,
 * que la haga SQL; si necesita logica de negocio fila a fila, que la haga un
 * ItemProcessor.
 *
 * ------------------------------------------------------------------------
 * ANATOMIA DE LA SENTENCIA, CLAUSULA POR CLAUSULA
 * ------------------------------------------------------------------------
 *
 * INSERT INTO ... SELECT ... GROUP BY cuenta_id
 *     Lee de interes_calculado y produce una fila por cuenta.
 *
 * WHERE periodo = ?
 *     IMPRESCINDIBLE. Sin este filtro, al liquidar febrero el SELECT sumaria
 *     tambien las filas de enero y el saldo de cada cuenta saldria DOBLE. Es
 *     el error mas facil de cometer y el mas dificil de ver: los numeros
 *     siguen "cuadrando" entre si, solo que son el doble de lo que deben.
 *
 * saldo = SUM(saldo_inicial) + SUM(interes)
 *     Se calcula asi, y no como una columna aparte, para cumplir POR
 *     CONSTRUCCION la restriccion ck_cuenta_saldo, que exige
 *     saldo = saldo_inicial + interes_aplicado. La base no puede aceptar una
 *     cuenta cuya aritmetica no cuadre.
 *
 * MODE() WITHIN GROUP (ORDER BY NULLIF(col,'DESCONOCIDO'))
 *     MODE() es una funcion de agregado ordenado: devuelve el valor MAS
 *     FRECUENTE del grupo (la "moda" estadistica). Se usa porque una cuenta
 *     puede aparecer con varios nombres o tipos a lo largo del archivo y hay
 *     que elegir uno; el mas repetido es la mejor apuesta.
 *
 *     El NULLIF de dentro es la parte sutil. 331 de las 1000 filas traen el
 *     tipo como '-1' o 'unknown', que el processor convierte en 'DESCONOCIDO'.
 *     Sin NULLIF, 'DESCONOCIDO' seria el valor mas frecuente de casi todas las
 *     cuentas y CASI TODAS quedarian con tipo_predominante='DESCONOCIDO',
 *     tirando a la basura la informacion buena que si tenemos. NULLIF lo
 *     convierte en NULL, y MODE() en PostgreSQL IGNORA los NULL, asi que la
 *     moda se calcula solo entre los valores informativos.
 *
 *     El COALESCE de fuera cubre el caso limite: una cuenta en la que TODAS
 *     las filas fueran desconocidas daria NULL, y la columna es NOT NULL.
 *
 * ------------------------------------------------------------------------
 * LA GUARDA DE IDEMPOTENCIA (escenario E15) - lo mas importante de la clase
 * ------------------------------------------------------------------------
 * ON CONFLICT (cuenta_id) DO UPDATE ... WHERE banco.cuenta.periodo_aplicado
 *                                             IS DISTINCT FROM EXCLUDED.periodo_aplicado
 *
 * ON CONFLICT convierte el INSERT en un "upsert": si la cuenta ya existe, en
 * vez de fallar, actualiza. Pero un upsert a secas seria PELIGROSO aqui: al
 * relanzar el job del mismo mes, sumaria el interes de enero OTRA VEZ sobre un
 * saldo que ya lo incluia. El cliente veria su dinero crecer solo porque
 * alguien reejecuto un proceso.
 *
 * El WHERE del DO UPDATE lo impide: la actualizacion solo se aplica si lo que
 * traemos es DISTINTO de lo que la cuenta ya tiene. Si es identico, PostgreSQL
 * no toca la fila y devuelve 0 filas afectadas. Ese 0 en la segunda corrida es,
 * literalmente, la prueba de la idempotencia.
 *
 * QUE SE COMPARA, Y POR QUE NO BASTA CON EL PERIODO
 * La guarda comparaba SOLO periodo_aplicado, y eso era demasiado poco: sellaba
 * el periodo para siempre. No distinguia "este periodo ya se aplico BIEN" de
 * "este periodo se aplico MAL y hay que rehacerlo"; en los dos casos descartaba
 * el UPDATE y devolvia 0, y el log celebraba ese 0 como idempotencia. Un
 * consolidado incoherente quedaba registrado como comportamiento correcto y ya
 * no habia forma de corregirlo sin tocar la tabla a mano.
 *
 * El caso concreto que lo destapa: si banco.interes_calculado se queda vacia o
 * a medias (un reinicio en el que la limpieza se repite y la recarga no, o un
 * CSV corregido que se reliquida), el INSERT ... SELECT produce agregados
 * distintos -o ninguno- y banco.cuenta deberia cambiar. Con la guarda vieja no
 * cambiaba: se quedaba con los saldos viejos, imposibles ya de reconstruir
 * desde el detalle.
 *
 * Ahora se compara el CONTENIDO (n_posiciones, saldo_inicial, interes_aplicado)
 * ADEMAS del periodo. Dos corridas identicas siguen dando 0 filas afectadas
 * -los agregados son identicos, asi que la idempotencia se conserva intacta-
 * pero una reliquidacion que de numeros distintos SI se aplica. La regla es:
 * la guarda debe comparar el DATO, no la etiqueta del dato.
 *
 * Se usa IS DISTINCT FROM y no <> porque estas columnas admiten NULL, y en
 * SQL "NULL <> '2024-01'" no es verdadero sino NULL, que se comporta como
 * falso y bloquearia la primera actualizacion de una cuenta preexistente.
 * IS DISTINCT FROM trata NULL como un valor mas y compara como uno espera.
 *
 * En el DO UPDATE se asignan saldo_inicial, interes_aplicado Y saldo JUNTOS.
 * Actualizar solo algunos dejaria la fila con una aritmetica incoherente y
 * ck_cuenta_saldo rechazaria la sentencia.
 */
public class ConsolidarSaldosTasklet implements Tasklet {

    private static final Logger log = LoggerFactory.getLogger(ConsolidarSaldosTasklet.class);

    private static final String SQL = """
            INSERT INTO banco.cuenta
                (cuenta_id, nombre, tipo_predominante, n_posiciones,
                 saldo_inicial, interes_aplicado, saldo, periodo_aplicado,
                 job_execution_id, actualizado_en)
            SELECT ic.cuenta_id,
                   COALESCE(MODE() WITHIN GROUP (ORDER BY NULLIF(ic.nombre, 'DESCONOCIDO')),
                            'DESCONOCIDO'),
                   COALESCE(MODE() WITHIN GROUP (ORDER BY NULLIF(ic.tipo, 'DESCONOCIDO')),
                            'DESCONOCIDO'),
                   COUNT(*),
                   SUM(ic.saldo_inicial),
                   SUM(ic.interes),
                   SUM(ic.saldo_inicial) + SUM(ic.interes),
                   ic.periodo,
                   ?,
                   now()
            FROM banco.interes_calculado ic
            WHERE ic.periodo = ?
            GROUP BY ic.cuenta_id, ic.periodo
            ON CONFLICT (cuenta_id) DO UPDATE
               SET nombre            = EXCLUDED.nombre,
                   tipo_predominante = EXCLUDED.tipo_predominante,
                   n_posiciones      = EXCLUDED.n_posiciones,
                   saldo_inicial     = EXCLUDED.saldo_inicial,
                   interes_aplicado  = EXCLUDED.interes_aplicado,
                   saldo             = EXCLUDED.saldo,
                   periodo_aplicado  = EXCLUDED.periodo_aplicado,
                   job_execution_id  = EXCLUDED.job_execution_id,
                   actualizado_en    = now()
             WHERE banco.cuenta.periodo_aplicado  IS DISTINCT FROM EXCLUDED.periodo_aplicado
                OR banco.cuenta.n_posiciones     IS DISTINCT FROM EXCLUDED.n_posiciones
                OR banco.cuenta.saldo_inicial    IS DISTINCT FROM EXCLUDED.saldo_inicial
                OR banco.cuenta.interes_aplicado IS DISTINCT FROM EXCLUDED.interes_aplicado
            """;

    private final JdbcTemplate jdbc;
    private final PeriodoIntereses periodoIntereses;

    public ConsolidarSaldosTasklet(JdbcTemplate jdbc, PeriodoIntereses periodoIntereses) {
        this.jdbc = jdbc;
        this.periodoIntereses = periodoIntereses;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        String periodo = periodoIntereses.resolver(chunkContext);
        long jobExecutionId = chunkContext.getStepContext().getStepExecution().getJobExecutionId();

        int afectadas = jdbc.update(SQL, jobExecutionId, periodo);

        if (afectadas == 0) {
            // OJO: "0 filas afectadas" ya NO se interpreta solo como buena
            // noticia. Significa "no habia nada distinto que escribir", y eso es
            // idempotencia SOLO si de verdad habia detalle que consolidar. Si
            // banco.interes_calculado esta vacia, el SELECT no produce ninguna
            // fila y el 0 significa algo muy distinto: que no se ha consolidado
            // nada. Antes los dos casos se registraban con el mismo mensaje de
            // exito. Se distinguen contando el detalle.
            Integer detalle = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM banco.interes_calculado WHERE periodo = ?",
                    Integer.class, periodo);
            long n = detalle == null ? 0L : detalle;

            if (n == 0L) {
                log.warn("Consolidacion (periodo={}): 0 filas afectadas Y banco.interes_calculado"
                        + " esta VACIA para ese periodo. Esto NO es idempotencia: no habia nada"
                        + " que consolidar. stepValidarConsolidadoIntereses lo convertira en un"
                        + " fallo del job.", periodo);
            } else {
                log.info("Consolidacion (periodo={}): 0 filas afectadas sobre {} filas de detalle."
                        + " El consolidado que ya estaba en banco.cuenta es IDENTICO al que"
                        + " acabamos de calcular, asi que el interes NO se reaplica."
                        + " Esto es la idempotencia funcionando.", periodo, n);
            }
        } else {
            log.info("Consolidacion (periodo={}): {} cuentas insertadas/actualizadas en banco.cuenta",
                    periodo, afectadas);
        }

        return RepeatStatus.FINISHED;
    }
}
