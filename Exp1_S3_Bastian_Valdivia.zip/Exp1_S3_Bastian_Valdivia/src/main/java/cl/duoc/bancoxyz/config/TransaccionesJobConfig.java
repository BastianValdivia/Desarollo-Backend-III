package cl.duoc.bancoxyz.config;

import cl.duoc.bancoxyz.domain.Transaccion;
import cl.duoc.bancoxyz.domain.TransaccionRaw;
import cl.duoc.bancoxyz.listener.ParticionListener;
import cl.duoc.bancoxyz.listener.RechazoListener;
import cl.duoc.bancoxyz.listener.ReintentoRetryListener;
import cl.duoc.bancoxyz.listener.ChunkErrorListener;
import cl.duoc.bancoxyz.partition.LineRangePartitioner;
import cl.duoc.bancoxyz.policy.BancoXyzSkipPolicy;
import cl.duoc.bancoxyz.processor.TransaccionProcessor;
import cl.duoc.bancoxyz.support.NormalizadorFecha;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import cl.duoc.bancoxyz.support.ControlCargaDao;
import cl.duoc.bancoxyz.support.InyectorFallosWriter;
import cl.duoc.bancoxyz.tasklet.AlertaCalidadTasklet;
import cl.duoc.bancoxyz.tasklet.CuadraturaTasklet;
import cl.duoc.bancoxyz.tasklet.DeciderCalidadDatos;
import cl.duoc.bancoxyz.tasklet.LimpiezaTasklet;
import cl.duoc.bancoxyz.tasklet.ResumenDiarioTasklet;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.retry.RetryListener;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.backoff.BackOffPolicy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * JOB 1 - Reporte de Transacciones Diarias, con PARTICIONES.
 *
 * Estructura:
 *
 *   jobTransaccionesDiarias
 *     └── stepCargarTransaccionesManager   (PartitionStep: reparte, no procesa)
 *           └── stepCargarTransaccionesWorker  x4, en paralelo
 *                 reader -> processor -> writer
 *
 * El MANAGER no toca datos: pregunta al Partitioner como repartir el archivo y
 * lanza una copia del WORKER por cada trozo, cada una en su propio hilo.
 *
 * Equivalencia mental:
 *   Job          ~ un DAG completo
 *   Step         ~ una task del DAG
 *   chunk(200)   ~ el lote que se confirma de una vez (ES la transaccion)
 *   Partitioner  ~ el "repartidor" que decide que le toca a cada worker
 */
@Configuration
public class TransaccionesJobConfig {

    /** Tamano del lote. Cada 200 filas se hace un COMMIT. */
    private static final int CHUNK = 200;

    /** Cuantas filas malas toleramos antes de dar el job por fallido. */
    private static final int LIMITE_OMISIONES = 500;

    private static final String ARCHIVO = "data/transacciones.csv";

    /** Prefijo de los steps worker. Con el se filtran sus StepExecution para
     *  contar la entrada sin sumar tambien el agregado del manager. */
    private static final String PREFIJO_WORKER = "stepCargarTransaccionesWorker";

    // ==================================================================
    // 1. PARTITIONER - decide como se reparte el archivo
    // ==================================================================
    @Bean
    public LineRangePartitioner transaccionPartitioner() {
        return new LineRangePartitioner(new ClassPathResource(ARCHIVO), 1);
    }

    // ==================================================================
    // 2. LECTOR - uno por particion.
    //
    //    @StepScope significa "no crees este bean al arrancar la aplicacion,
    //    creal0 cuando empiece el step". Es lo que permite inyectarle valores
    //    de la particion en curso con #{stepExecutionContext[...]}.
    //
    //    El "?: valor" de SpEL es el operador Elvis: si la clave no existe
    //    (porque el step no esta particionado) usa ese valor por defecto.
    //    Asi el mismo bean sirve particionado y sin particionar.
    //
    //    El tipo de retorno es FlatFileItemReader y NO ItemReader a proposito:
    //    el step necesita ver que implementa ItemStream para poder abrirlo y
    //    cerrarlo. Con ItemReader a secas, el fichero nunca se abriria.
    // ==================================================================
    @Bean
    @StepScope
    public FlatFileItemReader<TransaccionRaw> transaccionReader(
            @Value("#{stepExecutionContext['linesToSkip'] ?: 1}") Integer linesToSkip,
            @Value("#{stepExecutionContext['maxItemCount'] ?: 2147483647}") Integer maxItemCount,
            @Value("#{stepExecutionContext['partitionName'] ?: 'unica'}") String partitionName) {

        return new FlatFileItemReaderBuilder<TransaccionRaw>()
                // Nombre UNICO por particion: hace legibles los metadatos que
                // Spring Batch guarda del progreso de cada lector.
                .name("transaccionReader-" + partitionName)
                .resource(new ClassPathResource(ARCHIVO))
                // cabecera + desplazamiento de esta particion
                .linesToSkip(linesToSkip)
                // CUANTAS filas lee esta particion (es un contador, no un indice final)
                .maxItemCount(maxItemCount)
                .delimited().delimiter(",")
                .names("id", "fecha", "monto", "tipo")
                .fieldSetMapper(fs -> new TransaccionRaw(
                        fs.readString("id"),
                        fs.readString("fecha"),
                        fs.readString("monto"),
                        fs.readString("tipo")))
                .build();
    }

    // ==================================================================
    // 3. PROCESADOR - normaliza, clasifica y decide que se rechaza.
    //    Recibe linesToSkip para poder calcular la linea fisica del archivo:
    //    cada particion tiene su propio lector que cuenta desde cero.
    // ==================================================================
    @Bean
    @StepScope
    public TransaccionProcessor transaccionProcessor(
            NormalizadorFecha normalizadorFecha,
            NormalizadorMonto normalizadorMonto,
            NormalizadorTexto normalizadorTexto,
            @Value("#{stepExecution.jobExecutionId}") Long jobExecutionId,
            @Value("#{stepExecutionContext['linesToSkip'] ?: 1}") Integer linesToSkip) {
        return new TransaccionProcessor(normalizadorFecha, normalizadorMonto,
                normalizadorTexto, jobExecutionId, linesToSkip);
    }

    // ==================================================================
    // 4. ESCRITOR - inserta el lote completo en una sola llamada.
    //    Es thread-safe, asi que las 4 particiones pueden compartirlo.
    // ==================================================================
    @Bean
    public JdbcBatchItemWriter<Transaccion> transaccionWriter(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<Transaccion>()
                .dataSource(dataSource)
                .sql("""
                     INSERT INTO banco.transaccion
                         (id, fecha, fecha_original, formato_fecha, monto, monto_original,
                          tipo, tipo_original, estado, anomalias, numero_linea, job_execution_id)
                     VALUES
                         (:id, :fecha, :fechaOriginal, :formatoFecha, :monto, :montoOriginal,
                          :tipo, :tipoOriginal, :estado, :anomalias, :numeroLinea, :jobExecutionId)
                     """)
                .beanMapped()
                .build();
    }

    // ==================================================================
    // 4.b ESCRITOR ENVUELTO POR EL INYECTOR DE FALLOS.
    //
    //     Es el escritor que USA el step. En condiciones normales
    //     (simularFallo=NINGUNO) delega directamente en el de arriba y no
    //     cambia nada; con cualquier otro valor inyecta un fallo reproducible
    //     para poder demostrar las politicas de reintento. Ver
    //     docs/tolerancia-fallos.md.
    //
    //     Va @StepScope por DOS razones:
    //       1) para poder leer #{jobParameters[...]}, que no existen todavia
    //          cuando arranca la aplicacion;
    //       2) para tener una instancia POR PARTICION, de modo que cada una
    //          falle exactamente una vez y la demostracion sea repetible.
    //     (La regla "un Step nunca lleva @StepScope" no aplica: esto es un
    //      writer, no un Step. El scope va justo en reader/processor/writer.)
    //
    //     EL TIPO DE RETORNO ES LA CLASE CONCRETA, NO ItemWriter, A PROPOSITO.
    //     Declarandolo como ItemWriter, Spring Batch avisaba al arrancar:
    //       "org.springframework.batch.item.ItemWriter is an interface. The
    //        implementing class will not be queried for annotation based
    //        listener configurations."
    //     Con @StepScope el bean se sirve tras un proxy, y si lo unico que
    //     Spring conoce es la interfaz, no puede mirar la clase real para ver
    //     si trae anotaciones de listener (@BeforeWrite y compania). Devolver
    //     la clase concreta le da esa informacion y el arranque queda sin WARN.
    //     El step sigue pidiendo un ItemWriter<Transaccion> y encaja igual.
    // ==================================================================
    @Bean
    @StepScope
    public InyectorFallosWriter<Transaccion> transaccionWriterTolerante(
            JdbcBatchItemWriter<Transaccion> transaccionWriter,
            @Value("#{jobParameters['simularFallo'] ?: 'NINGUNO'}") String escenarioFallo,
            @Value("#{stepExecutionContext['partitionName'] ?: 'unica'}") String partitionName) {
        return new InyectorFallosWriter<>(transaccionWriter, escenarioFallo, partitionName);
    }

    // ==================================================================
    // 5. LISTENERS
    //
    //    El de rechazos va @StepScope A PROPOSITO: guarda en campos el nombre
    //    del step en curso, y con 4 particiones corriendo a la vez un unico
    //    objeto compartido se pisaria a si mismo y los rechazos quedarian
    //    atribuidos a la particion equivocada. Con @StepScope cada particion
    //    tiene su propia instancia.
    // ==================================================================
    @Bean
    @StepScope
    public RechazoListener<TransaccionRaw, Transaccion> rechazoListenerTransacciones(
            JdbcTemplate jdbcTemplate, PlatformTransactionManager transactionManager) {
        // El gestor de transacciones se le pasa para que el INSERT del dead
        // letter se confirme en una transaccion PROPIA (REQUIRES_NEW) y no lo
        // borre el rollback del chunk cuando entra un reintento. Ver el
        // comentario de RechazoListener.guardar().
        return new RechazoListener<>(jdbcTemplate, transactionManager, "transacciones.csv");
    }

    @Bean
    public ParticionListener particionListener() {
        return new ParticionListener();
    }

    // ==================================================================
    // 6. WORKER - el step que hace el trabajo real. Se ejecuta una vez por
    //    particion, en paralelo. Aqui viven la tolerancia a fallos.
    // ==================================================================
    @Bean
    public Step stepCargarTransaccionesWorker(
            JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            FlatFileItemReader<TransaccionRaw> transaccionReader,
            TransaccionProcessor transaccionProcessor,
            ItemWriter<Transaccion> transaccionWriterTolerante,
            RechazoListener<TransaccionRaw, Transaccion> rechazoListenerTransacciones,
            ParticionListener particionListener,
            SkipPolicy skipPolicyBancoXyz,
            RetryPolicy retryPolicyInfraestructura,
            BackOffPolicy backOffExponencial,
            ReintentoRetryListener reintentoRetryListener,
            ChunkErrorListener chunkErrorListener) {

        // ------------------------------------------------------------------
        // POR QUE ESTO SE PARTE EN DOS Y NO ES UNA SOLA CADENA DE LLAMADAS
        // ------------------------------------------------------------------
        // Escrito todo seguido, este step compilaba y arrancaba... pero el
        // ReintentoRetryListener NO SE REGISTRABA. Ni un solo log de reintento,
        // aunque los reintentos ocurrian de verdad. Silencioso y bien
        // desagradable de encontrar.
        //
        // El motivo es de tipos, no de Spring. Los .listener(...) devuelven el
        // constructor para poder encadenar, PERO NO SIEMPRE EL MISMO TIPO:
        //
        //   FaultTolerantStepBuilder  ->  tiene listener(RetryListener)
        //   .listener(StepExecutionListener)  esta declarado en StepBuilderHelper
        //        y devuelve AbstractTaskletStepBuilder, NO FaultTolerantStepBuilder
        //   AbstractTaskletStepBuilder -> ya NO tiene listener(RetryListener)
        //
        // Asi que, tras el primer .listener((StepExecutionListener) ...), la
        // llamada .listener((RetryListener) x) ya no encuentra su sobrecarga y
        // Java la resuelve contra listener(Object), que solo busca anotaciones
        // (@BeforeStep y compania) y con un RetryListener NO HACE NADA.
        // Compila, no avisa, y te deja sin auditoria de reintentos.
        //
        // La solucion es guardar el FaultTolerantStepBuilder en una variable y
        // registrar ahi lo que solo el sabe registrar (RetryListener), antes de
        // que el tipo se "degrade" al encadenar. Es tambien la razon de que
        // ChunkErrorListener SI funcionara: listener(ChunkListener) si existe
        // en AbstractTaskletStepBuilder.
        // ------------------------------------------------------------------
        var tolerante = new StepBuilder("stepCargarTransaccionesWorker", jobRepository)
                .<TransaccionRaw, Transaccion>chunk(CHUNK, transactionManager)
                .reader(transaccionReader)
                .processor(transaccionProcessor)
                .writer(transaccionWriterTolerante)
                .faultTolerant();

        // Se registra AQUI, mientras el tipo estatico sigue siendo
        // FaultTolerantStepBuilder y la sobrecarga correcta esta disponible.
        tolerante.listener((RetryListener) reintentoRetryListener);

        return tolerante

                // ---- OMISION (datos sucios) -------------------------------
                // Politica propia. NO se combina con .skip()/.skipLimit(): si mezclas
                // ambos modelos, Spring los une con un OR y tu veto queda anulado.
                // El limite sale de la propiedad banco.tolerancia.limite-omisiones
                // (por defecto LIMITE_OMISIONES = 500), para poder demostrar el
                // escenario del techo de tolerancia sin recompilar.
                .skipPolicy(skipPolicyBancoXyz)

                // ---- REINTENTO (infraestructura) --------------------------
                // Modelo B puro: se entrega la politica ya armada y NO se llama a
                // .retry(), .retryLimit() ni .noRetry(). Mezclar los dos modelos es
                // peligroso: con un retryPolicy explicito, .noRetry(X) solo se tiene
                // en cuenta si ademas hay retryLimit > 0, asi que tu veto se
                // IGNORARIA EN SILENCIO. Por eso el veto a RegistroInvalidoException
                // esta dentro del mapa de RetryPolicies.infraestructura().
                //
                // Consecuencia practica: una fila con la fecha "2024-13-01" NO se
                // reintenta (fallaria igual las 3 veces); se omite en el primer
                // intento y va al dead letter. Una conexion caida SI se reintenta,
                // y NUNCA se omite.
                .retryPolicy(retryPolicyInfraestructura)
                .backOffPolicy(backOffExponencial)

                // El registro es un dato sucio, no un fallo de base de datos:
                // no hace falta deshacer el lote entero por el.
                .noRollback(cl.duoc.bancoxyz.exception.RegistroInvalidoException.class)

                // ---- LISTENERS --------------------------------------------
                // Los casts NO son decorativos: rechazoListenerTransacciones
                // implementa dos interfaces y sin cast el compilador no sabe a
                // que sobrecarga de .listener() te refieres ("reference to
                // listener is ambiguous").
                .listener((SkipListener<TransaccionRaw, Transaccion>) rechazoListenerTransacciones)
                .listener((StepExecutionListener) rechazoListenerTransacciones)
                .listener((StepExecutionListener) particionListener)
                // Auditoria de cada rollback de chunk. El de reintentos ya se
                // registro arriba, sobre el FaultTolerantStepBuilder; ver el
                // comentario largo del principio de este metodo para el porque.
                // Sin estos dos, "reintento bien cableado" y "reintento que no se
                // dispara nunca" se ven exactamente igual desde fuera.
                .listener((ChunkListener) chunkErrorListener)
                // ---- REINICIO DE LA MISMA JobInstance ----------------------
                // allowStartIfComplete(true) AQUI, en el WORKER, NO es una copia
                // de la que lleva el manager: gobierna una cosa DISTINTA.
                //
                // Verificado en el bytecode de PartitionStepBuilder.build() de
                // spring-batch-core 5.2.6, que hace literalmente esto:
                //
                //     boolean allow = isAllowStartIfComplete();            // el MANAGER
                //     if (step != null) {
                //         allow = step.isAllowStartIfComplete();           // el WORKER MANDA
                //     }
                //     splitter.setAllowStartIfComplete(allow);
                //
                // O sea: la bandera que recibe el SimpleStepExecutionSplitter
                // sale del WORKER, no del manager. Y esa bandera es la que decide
                // si, al REINICIAR la JobInstance, el splitter vuelve a generar
                // TODAS las particiones o solo las que quedaron FAILED.
                //
                // Sin ella el fallo es silencioso y de los peores: el step de
                // preparacion borra la tabla ENTERA (con allowStartIfComplete ya
                // puesto), pero la recarga solo repone las particiones que
                // fallaron. Con 3 particiones COMPLETED y 1 FAILED te quedarias
                // con ~250 filas de 1000 y la cuadratura, que cuenta por
                // job_execution_id, diria "OK" sobre esas 250. Un numero
                // coherente consigo mismo y falso, que es exactamente lo que un
                // control de cuadratura tiene que hacer imposible.
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 7. MANAGER - el PartitionStep. No procesa datos: reparte y lanza.
    //
    //    OJO con dos cosas:
    //      * .taskExecutor(...) es OBLIGATORIO. Sin el, Spring usa un ejecutor
    //        sincrono SIN AVISAR y las particiones corren una detras de otra.
    //      * NO se usa .partitionHandler(...) explicito: si lo pusieras,
    //        .gridSize() y .taskExecutor() del builder se ignorarian.
    // ==================================================================
    @Bean
    public Step stepCargarTransaccionesManager(
            JobRepository jobRepository,
            Step stepCargarTransaccionesWorker,
            LineRangePartitioner transaccionPartitioner,
            ThreadPoolTaskExecutor poolParticiones) {

        return new StepBuilder("stepCargarTransaccionesManager", jobRepository)
                .partitioner(stepCargarTransaccionesWorker.getName(), transaccionPartitioner)
                .step(stepCargarTransaccionesWorker)
                .gridSize(TaskExecutorConfig.PARTICIONES)
                .taskExecutor(poolParticiones)
                // ---- REINICIO DE LA MISMA JobInstance ----------------------
                // Esta bandera es la PAREJA OBLIGATORIA de la que lleva
                // stepPrepararTransacciones, y faltaba.
                //
                // El razonamiento: en un reinicio, SimpleStepHandler SALTA todo
                // step que ya este COMPLETED y no tenga allowStartIfComplete. La
                // preparacion si la tenia; el manager no. Resultado: la limpieza
                // (DELETE de la tabla entera) se repetia y la recarga NO. El job
                // terminaba COMPLETED con banco.transaccion vacia.
                //
                // Y el reinicio no es un caso raro, es el camino normal:
                // LanzadorJobs usa JobParametersBuilder.getNextJobParameters(job),
                // que tras una ejecucion FAILED devuelve los MISMOS parametros en
                // vez de incrementar run.id; o sea, reinicia la instancia
                // anterior en lugar de crear una nueva.
                //
                // REGLA GENERAL que conviene recordar: si un step BORRA, el step
                // que RELLENA tiene que tener el mismo comportamiento ante un
                // reinicio. Alcances distintos entre el que limpia y el que
                // repone = perdida de datos silenciosa.
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 7.b PREPARACION - vacia la carga anterior para que el job sea idempotente.
    //
    //     allowStartIfComplete(true) y el DELETE resuelven cosas DISTINTAS:
    //       * el DELETE arregla el DuplicateKeyException al volver a insertar
    //         los mismos ids en una ejecucion NUEVA;
    //       * allowStartIfComplete permite que el step se vuelva a ejecutar al
    //         REINICIAR la misma JobInstance (por defecto un step COMPLETED se
    //         salta en el reinicio, y entonces la limpieza no ocurriria).
    //     Hacen falta los dos.
    // ==================================================================
    @Bean
    public Step stepPrepararTransacciones(JobRepository jobRepository,
                                          PlatformTransactionManager transactionManager,
                                          JdbcTemplate jdbcTemplate) {
        Tasklet limpieza = new LimpiezaTasklet(
                jdbcTemplate,
                "banco.transaccion",
                "transacciones.csv",
                java.util.List.of("banco.resumen_diario"));

        return new StepBuilder("stepPrepararTransacciones", jobRepository)
                // En Spring Batch 5.2.x la firma vigente es tasklet(tasklet, txManager);
                // tasklet(tasklet) a secas esta deprecada.
                .tasklet(limpieza, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 7.c DECIDER - la bifurcacion del flujo.
    //
    //     Es un bean NORMAL: nada de @JobScope/@StepScope. El grafo empareja
    //     .next(decider) con .from(decider) por identidad de objeto, y un proxy
    //     de scope rompe esa identidad. El umbral se lee de los JobParameters
    //     dentro de decide(), donde ya estan disponibles.
    // ==================================================================
    @Bean
    public DeciderCalidadDatos deciderCalidadDatos(ControlCargaDao controlCargaDao) {
        return new DeciderCalidadDatos(controlCargaDao, "transacciones.csv",
                "banco.transaccion", PREFIJO_WORKER);
    }

    // ==================================================================
    // 7.d ALERTA - rama degradada. Avisa, no mata.
    // ==================================================================
    @Bean
    public Step stepAlertaCalidad(JobRepository jobRepository,
                                  PlatformTransactionManager transactionManager,
                                  ControlCargaDao controlCargaDao,
                                  JdbcTemplate jdbcTemplate) {
        Tasklet alerta = new AlertaCalidadTasklet(controlCargaDao, jdbcTemplate,
                "transacciones.csv", "banco.transaccion", PREFIJO_WORKER);

        return new StepBuilder("stepAlertaCalidad", jobRepository)
                .tasklet(alerta, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 7.e RESUMEN DIARIO - la agregacion (GROUP BY) del plan maestro §9.
    // ==================================================================
    @Bean
    public Step stepResumenDiario(JobRepository jobRepository,
                                  PlatformTransactionManager transactionManager,
                                  DataSource dataSource) {
        Tasklet resumen = new ResumenDiarioTasklet(new NamedParameterJdbcTemplate(dataSource));

        return new StepBuilder("stepResumenDiario", jobRepository)
                .tasklet(resumen, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 7.f CUADRATURA - hace FALLAR el job si se perdio alguna fila.
    //
    //     El nombre lleva el sufijo "Transacciones" porque los Jobs 2 y 3
    //     tendran su propio step de cuadratura y dos StepBuilder con el MISMO
    //     nombre se confundirian entre si en BATCH_STEP_EXECUTION.
    // ==================================================================
    @Bean
    public Step stepValidarCuadraturaTransacciones(JobRepository jobRepository,
                                                   PlatformTransactionManager transactionManager,
                                                   ControlCargaDao controlCargaDao) {
        // El CSV de origen y su numero de lineas de cabecera se pasan para que la
        // cuadratura pueda comparar el CONTENIDO REAL de la tabla contra las filas
        // del fichero, y no solo contra lo que hizo esta ejecucion. Ver el javadoc
        // de CuadraturaTasklet, comprobacion (3).
        Tasklet cuadratura = new CuadraturaTasklet(controlCargaDao, "transacciones.csv",
                "banco.transaccion", PREFIJO_WORKER, new ClassPathResource(ARCHIVO), 1);

        return new StepBuilder("stepValidarCuadraturaTransacciones", jobRepository)
                .tasklet(cuadratura, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 8. JOB - flujo CONDICIONAL. Arranca por la preparacion, nunca por el worker.
    //
    //    El grafo:
    //
    //      stepPrepararTransacciones
    //        -> stepCargarTransaccionesManager   (las 4 particiones)
    //        -> deciderCalidadDatos
    //             |-- CALIDAD_DEGRADADA --> stepAlertaCalidad --> stepResumenDiario
    //             `-- (cualquier otra)  --> stepResumenDiario
    //        -> stepValidarCuadraturaTransacciones
    //
    //    Sobre las transiciones:
    //      * on("COMPLETED") entre steps, NO on("*"): el comodin casa tambien
    //        con FAILED, asi que un step roto seguiria hacia adelante y el job
    //        podria acabar COMPLETED mintiendo. El comodin se reserva para la
    //        rama por defecto del decider, donde los unicos valores posibles
    //        son las dos etiquetas que el propio decider devuelve.
    //      * .end() cierra el grafo y devuelve el FlowJobBuilder; sin el no hay
    //        build() que valga.
    //
    //    RunIdIncrementer anade un parametro distinto en cada lanzamiento para
    //    poder ejecutar el job dos veces seguidas. Sin esto, la segunda vez
    //    reventaria con JobInstanceAlreadyCompleteException, y el evaluador
    //    VA a ejecutarlo dos veces.
    // ==================================================================
    @Bean
    public Job jobTransaccionesDiarias(JobRepository jobRepository,
                                       Step stepPrepararTransacciones,
                                       Step stepCargarTransaccionesManager,
                                       DeciderCalidadDatos deciderCalidadDatos,
                                       Step stepAlertaCalidad,
                                       Step stepResumenDiario,
                                       Step stepValidarCuadraturaTransacciones) {

        return new JobBuilder("jobTransaccionesDiarias", jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(stepPrepararTransacciones)
                .next(stepCargarTransaccionesManager)
                // A partir de .next(decider) ya no estamos en un flujo lineal:
                // el builder pasa a ser un JobFlowBuilder y hay que describir
                // las transiciones una a una.
                .next(deciderCalidadDatos)
                    .on(DeciderCalidadDatos.CALIDAD_DEGRADADA).to(stepAlertaCalidad)
                .from(deciderCalidadDatos)
                    .on("*").to(stepResumenDiario)
                .from(stepAlertaCalidad)
                    .on("COMPLETED").to(stepResumenDiario)
                .from(stepResumenDiario)
                    .on("COMPLETED").to(stepValidarCuadraturaTransacciones)
                .end()
                .build();
    }
}
