package cl.duoc.bancoxyz.support;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;

/**
 * UNICO ORIGEN DE VERDAD de los cuatro contadores de la cuadratura.
 *
 * Por que existe una clase para esto y no cada tasklet cuenta lo suyo:
 * el step de alerta y el de cuadratura escriben LA MISMA fila de
 * banco.control_carga (clave unica job_execution_id + archivo_origen). Si cada
 * uno calculase los numeros por su cuenta, el valor final dependeria del orden
 * en que corrieron, que es justo lo que un control de cuadratura no se puede
 * permitir. Con un solo metodo de conteo, los dos escriben lo mismo.
 *
 * Analogia SQL: esto es como una vista; el calculo vive en UN sitio y todos los
 * consumidores leen de ella en vez de repetir el SELECT cada uno a su manera.
 */
@Component
public class ControlCargaDao {

    private static final Logger log = LoggerFactory.getLogger(ControlCargaDao.class);

    private final JdbcTemplate jdbc;
    private final PlatformTransactionManager txManager;

    public ControlCargaDao(JdbcTemplate jdbc, PlatformTransactionManager txManager) {
        this.jdbc = jdbc;
        this.txManager = txManager;
    }

    /**
     * Los cuatro numeros de la Regla de Oro: entrada = negocio + rechazadas + filtradas.
     *
     * "record" es una clase de solo datos: escribes los campos y Java genera
     * solo el constructor, los accesores, equals/hashCode y toString. Aqui
     * interesa porque es inmutable: una vez contados, los numeros no se tocan.
     */
    public record ContadoresCarga(long entrada, long negocio, long rechazadas, long filtradas) {

        /**
         * "No he podido medir la entrada". NO es lo mismo que haber medido cero,
         * y esa distincion es el corazon de esta clase.
         *
         * Antes, cuando el conteo fallaba se devolvia 0... y 0 es justo el unico
         * valor que hace pasar la comprobacion, porque 0 == 0 + 0 + 0 es cierto
         * POR VACUIDAD. Un fallo de medicion se disfrazaba de carga perfecta.
         * Con un centinela negativo el caso "no medible" es imposible de
         * confundir con el caso "medido cero": la aritmetica de la Regla de Oro
         * nunca puede dar un negativo, asi que -1 no colisiona con ningun valor
         * legitimo.
         *
         * (La alternativa academica seria OptionalLong, pero obligaria a cambiar
         * la firma del record y con ella los tres tasklets y el test que ya
         * construyen ContadoresCarga con cuatro numeros. El centinela documentado
         * consigue lo mismo tocando mucho menos.)
         */
        public static final long NO_MEDIBLE = -1L;

        /** true si la entrada se pudo medir de verdad. */
        public boolean entradaMedible() {
            return entrada >= 0;
        }

        public boolean cuadra() {
            // Si no se pudo medir la entrada, NO cuadra. Un control que no ha
            // podido comprobar nada tiene que decir "no", nunca "si".
            return entradaMedible() && entrada == negocio + rechazadas + filtradas;
        }
    }

    // ==================================================================
    // (a) FILAS DE ENTRADA - se cuentan sobre las StepExecution de los WORKERS
    //
    //     TRAMPA: el DefaultStepExecutionAggregator vuelca los contadores de
    //     las 4 particiones en la StepExecution del MANAGER. Si sumaras TODAS
    //     las StepExecution del job contarias cada fila DOS VECES (~2000) y la
    //     cuadratura fallaria siempre. Por eso se filtra por prefijo de nombre.
    //
    //     entrada   = readCount (leidas con exito) + readSkipCount (reventaron
    //                 al leerse y fueron omitidas). Las dos entraron por el
    //                 lector, asi que las dos cuentan como entrada.
    //     filtradas = filterCount (el processor devolvio null a proposito).
    // ==================================================================
    public long contarEntrada(JobExecution jobExecution, String prefijoWorker) {
        List<StepExecution> workers = workers(jobExecution, prefijoWorker);
        if (workers.isEmpty()) {
            return sumarDesdeMetadatos(jobExecution, prefijoWorker, "read_count + read_skip_count");
        }
        return workers.stream().mapToLong(se -> se.getReadCount() + se.getReadSkipCount()).sum();
    }

    /** Filas que el processor descarto devolviendo null. En este proyecto deben ser 0. */
    public long contarFiltradas(JobExecution jobExecution, String prefijoWorker) {
        List<StepExecution> workers = workers(jobExecution, prefijoWorker);
        if (workers.isEmpty()) {
            // Aqui el centinela se NORMALIZA a 0 a proposito: "filtradas" esta en
            // el lado DERECHO de la igualdad de la Regla de Oro, y un -1 ahi
            // falsearia el numero en vez de delatar el problema. Quien tiene que
            // gritar es la entrada, que es el lado izquierdo; ella ya lo hace.
            long n = sumarDesdeMetadatos(jobExecution, prefijoWorker, "filter_count");
            return n < 0 ? 0L : n;
        }
        return workers.stream().mapToLong(StepExecution::getFilterCount).sum();
    }

    private List<StepExecution> workers(JobExecution jobExecution, String prefijoWorker) {
        return jobExecution.getStepExecutions().stream()
                .filter(se -> se.getStepName().startsWith(prefijoWorker))
                .toList();
    }

    /**
     * Plan B. Si las StepExecution de las particiones no estuvieran en el objeto
     * en memoria, se leen de los metadatos que Spring Batch YA persistio. Lo que
     * nunca se hace es devolver el agregado del manager como si fuera la entrada:
     * eso convertiria un fallo de lectura en un numero creible pero falso.
     *
     * Y por la misma razon TAMPOCO se devuelve 0 cuando no hay nada que leer:
     * 0 es precisamente el valor que hace pasar la comprobacion por vacuidad.
     * En ese caso se devuelve ContadoresCarga.NO_MEDIBLE y la cuadratura falla.
     */
    private long sumarDesdeMetadatos(JobExecution jobExecution, String prefijoWorker, String expresion) {
        log.warn("Sin StepExecution en memoria con prefijo '{}': leo BATCH_STEP_EXECUTION", prefijoWorker);

        // PRIMERO se pregunta si EXISTE alguna fila de worker para esta
        // ejecucion, y solo despues se suma. El orden importa: SUM() sobre cero
        // filas devuelve NULL, y el COALESCE lo convertia en un 0 indistinguible
        // de "los workers corrieron y leyeron cero filas". Contando las filas
        // primero, "no hay nada que medir" queda separado de "medi cero".
        Long filas = jdbc.queryForObject(
                "SELECT COUNT(*) FROM batch_meta.BATCH_STEP_EXECUTION"
                        + " WHERE job_execution_id = ? AND step_name LIKE ?",
                Long.class, jobExecution.getId(), prefijoWorker + "%");

        if (filas == null || filas == 0L) {
            log.error("NO SE PUEDE MEDIR la entrada: no existe ninguna StepExecution con prefijo"
                    + " '{}' para job_execution_id={}. Devuelvo NO_MEDIBLE, que hace fallar la"
                    + " cuadratura. Devolver 0 aqui seria un numero creible y FALSO: 0 = 0+0+0"
                    + " haria pasar el control por vacuidad.", prefijoWorker, jobExecution.getId());
            return ContadoresCarga.NO_MEDIBLE;
        }

        Long n = jdbc.queryForObject(
                "SELECT COALESCE(SUM(" + expresion + "), 0) FROM batch_meta.BATCH_STEP_EXECUTION"
                        + " WHERE job_execution_id = ? AND step_name LIKE ?",
                Long.class, jobExecution.getId(), prefijoWorker + "%");
        return n == null ? ContadoresCarga.NO_MEDIBLE : n;
    }

    /**
     * Deja en el log TODAS las StepExecution con sus contadores. No es adorno:
     * es la prueba visual de que el filtro por prefijo mira los 4 workers y no
     * el agregado del manager (que muestra los mismos numeros sumados otra vez).
     */
    public void volcarContadores(JobExecution jobExecution) {
        log.info("--- contadores por StepExecution (job_execution_id={}) ---", jobExecution.getId());
        for (StepExecution se : jobExecution.getStepExecutions()) {
            log.info(String.format("  %-42s read=%-5d readSkip=%-4d write=%-5d filter=%-4d estado=%s",
                    se.getStepName(), se.getReadCount(), se.getReadSkipCount(),
                    se.getWriteCount(), se.getFilterCount(), se.getStatus()));
        }
    }

    // ==================================================================
    // (b) FILAS DE NEGOCIO Y RECHAZADAS - por SQL, sobre lo que REALMENTE
    //     quedo en la base, no sobre lo que el job cree que escribio. Si el
    //     writer mintiera, el conteo por SQL lo delata.
    // ==================================================================
    public long contarNegocio(long jobExecutionId, String tablaNegocio) {
        // tablaNegocio es un literal del codigo (nunca entrada de usuario), asi
        // que concatenarlo no abre una inyeccion SQL. El resto va parametrizado.
        Long n = jdbc.queryForObject(
                "SELECT COUNT(*) FROM " + tablaNegocio + " WHERE job_execution_id = ?",
                Long.class, jobExecutionId);
        return n == null ? 0L : n;
    }

    public long contarRechazadas(long jobExecutionId, String archivoOrigen) {
        Long n = jdbc.queryForObject(
                "SELECT COUNT(*) FROM banco.registro_rechazado"
                        + " WHERE job_execution_id = ? AND archivo_origen = ?",
                Long.class, jobExecutionId, archivoOrigen);
        return n == null ? 0L : n;
    }

    // ==================================================================
    // (b bis) EL CONTENIDO REAL DE LA TABLA, SIN FILTRAR POR EJECUCION
    //
    //     Los dos contadores de arriba responden "que hizo ESTA ejecucion".
    //     Estos dos responden "que contiene la tabla AHORA MISMO". Son
    //     preguntas distintas y las dos hacen falta, porque el step de
    //     preparacion borra con un alcance (la tabla entera / el archivo
    //     entero) que NO coincide con el alcance de los contadores
    //     (job_execution_id).
    //
    //     Ese desajuste de alcances es lo que permitia el peor de los fallos:
    //     tras un reinicio, la limpieza borraba las 1000 filas y la recarga se
    //     saltaba, pero la cuadratura -que solo miraba su propia ejecucion-
    //     comparaba 0 contra 0 y declaraba OK. Comparando ADEMAS el contenido
    //     real contra las filas del fichero, ese caso se convierte en un fallo
    //     ruidoso.
    // ==================================================================

    /** COUNT(*) de la tabla de negocio ENTERA, sin filtro de ejecucion. */
    public long contarNegocioTotal(String tablaNegocio) {
        Long n = jdbc.queryForObject("SELECT COUNT(*) FROM " + tablaNegocio, Long.class);
        return n == null ? 0L : n;
    }

    /** COUNT(*) del dead letter para ESTE archivo, sin filtro de ejecucion. */
    public long contarRechazadasTotal(String archivoOrigen) {
        Long n = jdbc.queryForObject(
                "SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen = ?",
                Long.class, archivoOrigen);
        return n == null ? 0L : n;
    }

    /** Junta los cuatro contadores en un solo objeto. */
    public ContadoresCarga contar(JobExecution jobExecution, String prefijoWorker,
                                  String tablaNegocio, String archivoOrigen) {
        long id = jobExecution.getId();
        return new ContadoresCarga(
                contarEntrada(jobExecution, prefijoWorker),
                contarNegocio(id, tablaNegocio),
                contarRechazadas(id, archivoOrigen),
                contarFiltradas(jobExecution, prefijoWorker));
    }

    // ==================================================================
    // (c) UPSERT en banco.control_carga, en TRANSACCION PROPIA.
    //
    //     PROPAGATION_REQUIRES_NEW significa "abre una transaccion nueva,
    //     suspende la que haya en curso y confirmala por separado". Es
    //     imprescindible: un Tasklet corre dentro de la transaccion del step,
    //     asi que si CuadraturaTasklet insertase aqui y despues lanzase la
    //     excepcion que hace fallar el job, el rollback del step se llevaria
    //     por delante la propia evidencia de POR QUE fallo. Con REQUIRES_NEW la
    //     fila ya esta confirmada cuando llega el throw.
    //
    //     La columna "cuadra" es GENERATED ALWAYS AS ... STORED: la calcula
    //     PostgreSQL y NO puede aparecer en la lista de columnas del INSERT.
    // ==================================================================
    public void upsert(ContadoresCarga c, String jobName, long jobExecutionId,
                       String archivoOrigen, Long duracionMs) {

        TransactionTemplate plantilla = new TransactionTemplate(txManager);
        plantilla.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);

        plantilla.executeWithoutResult(status -> jdbc.update(
                "INSERT INTO banco.control_carga"
                        + " (archivo_origen, job_name, job_execution_id, filas_entrada,"
                        + "  filas_negocio, filas_rechazadas, filas_filtradas, duracion_ms, verificado_en)"
                        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, now())"
                        + " ON CONFLICT (job_execution_id, archivo_origen) DO UPDATE"
                        + "    SET filas_entrada    = EXCLUDED.filas_entrada,"
                        + "        filas_negocio    = EXCLUDED.filas_negocio,"
                        + "        filas_rechazadas = EXCLUDED.filas_rechazadas,"
                        + "        filas_filtradas  = EXCLUDED.filas_filtradas,"
                        + "        duracion_ms      = EXCLUDED.duracion_ms,"
                        + "        verificado_en    = now()",
                archivoOrigen, jobName, jobExecutionId,
                c.entrada(), c.negocio(), c.rechazadas(), c.filtradas(), duracionMs));

        log.info("control_carga [{}] entrada={} negocio={} rechazadas={} filtradas={} cuadra={}",
                archivoOrigen, c.entrada(), c.negocio(), c.rechazadas(), c.filtradas(), c.cuadra());
    }
}
