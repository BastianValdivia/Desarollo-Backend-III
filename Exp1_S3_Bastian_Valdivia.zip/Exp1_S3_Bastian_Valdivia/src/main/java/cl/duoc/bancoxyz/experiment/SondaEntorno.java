package cl.duoc.bancoxyz.experiment;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

/**
 * Captura el CONTEXTO de la maquina en la que se midio.
 *
 * Por que importa tanto que esto vaya en CADA FILA del CSV y no en un pie de
 * pagina: "particionado con gridSize=8 es lo mejor" es una frase sin sentido
 * si no se dice sobre cuantos nucleos y con que pool de conexiones. Un mismo
 * numero de particiones puede ser optimo en una maquina y contraproducente en
 * otra. Con estas columnas, quien reproduzca el experimento en otro equipo
 * puede seguir interpretando la comparacion.
 *
 * El tamano del pool de Hikari es especialmente critico: si el pool es MENOR
 * que el numero de particiones, las particiones sobrantes se quedan esperando
 * una conexion libre y lo que estarias midiendo es el pool, no el paralelismo.
 * Regla que se aplica en application-experiment.yml: pool >= paralelismo + 2.
 */
@Component
public class SondaEntorno {

    private final int hikariPoolSize;

    public SondaEntorno(DataSource dataSource) {
        // unwrap y no un cast directo: Spring puede envolver el DataSource en
        // proxies (transacciones, trazas) y un cast a HikariDataSource fallaria.
        int tamano = -1;
        try {
            if (dataSource.isWrapperFor(HikariDataSource.class)) {
                tamano = dataSource.unwrap(HikariDataSource.class).getMaximumPoolSize();
            }
        } catch (Exception e) {
            tamano = -1;   // se declara como desconocido, nunca se inventa
        }
        this.hikariPoolSize = tamano;
    }

    public int hikariPoolSize() {
        return hikariPoolSize;
    }

    public int cpus() {
        return Runtime.getRuntime().availableProcessors();
    }

    public int heapMaxMb() {
        return (int) (Runtime.getRuntime().maxMemory() / (1024 * 1024));
    }

    public String descripcion() {
        return "cpus=%d heapMax=%d MB jvm=%s os=%s pool=%d".formatted(
                cpus(), heapMaxMb(),
                System.getProperty("java.version"),
                System.getProperty("os.name") + " " + System.getProperty("os.arch"),
                hikariPoolSize);
    }
}
