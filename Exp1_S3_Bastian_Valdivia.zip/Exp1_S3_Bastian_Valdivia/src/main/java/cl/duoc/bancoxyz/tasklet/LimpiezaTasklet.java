package cl.duoc.bancoxyz.tasklet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

/**
 * PASO DE PREPARACION del Job 1: deja la base como estaba antes de la carga.
 *
 * POR QUE existe (no es cosmetico, arregla un bug real):
 * banco.transaccion tiene el id del CSV como PRIMARY KEY. La primera ejecucion
 * inserta los ids 1..1000; la SEGUNDA intenta insertar los mismos y PostgreSQL
 * responde con DuplicateKeyException, asi que el job falla. Un proceso batch
 * tiene que ser IDEMPOTENTE: correrlo dos veces debe dejar el mismo resultado
 * que correrlo una. La forma mas simple de conseguirlo cuando el job es el
 * dueno unico de la tabla es vaciarla antes de recargar ("truncate and load",
 * el patron clasico de las cargas diarias de un data warehouse).
 *
 * OJO con el alcance de cada DELETE:
 *   - banco.transaccion  -> se vacia ENTERA: es propiedad exclusiva del Job 1.
 *   - banco.registro_rechazado -> SOLO las filas de este archivo. El "dead
 *     letter" lo comparten los tres jobs; borrarlo sin WHERE destruiria la
 *     evidencia de intereses.csv y cuentas_anuales.csv.
 *   - banco.resumen_diario -> se vacia entera: si quedaran fechas de una
 *     corrida vieja, SUM(total_operaciones) saldria por encima de 785 aunque
 *     el ON CONFLICT hubiera actualizado bien las fechas nuevas.
 *   - banco.control_carga  -> NO SE TOCA. Esta clavada por job_execution_id y
 *     es el historial de evidencia de todas las ejecuciones.
 */
public class LimpiezaTasklet implements Tasklet {

    private static final Logger log = LoggerFactory.getLogger(LimpiezaTasklet.class);

    private final JdbcTemplate jdbc;
    private final String tablaNegocio;
    private final String archivoOrigen;
    /** Tablas derivadas que hay que vaciar enteras (agregados recalculables). */
    private final List<String> tablasDerivadas;

    public LimpiezaTasklet(JdbcTemplate jdbc, String tablaNegocio, String archivoOrigen,
                           List<String> tablasDerivadas) {
        this.jdbc = jdbc;
        this.tablaNegocio = tablaNegocio;
        this.archivoOrigen = archivoOrigen;
        this.tablasDerivadas = tablasDerivadas;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // Primero las derivadas: si alguna tuviera clave foranea hacia la tabla
        // de negocio, borrar el "hijo" antes que el "padre" evita el error.
        for (String derivada : tablasDerivadas) {
            int n = jdbc.update("DELETE FROM " + derivada);
            log.info("Limpieza: {} filas borradas de {}", n, derivada);
        }

        int negocio = jdbc.update("DELETE FROM " + tablaNegocio);
        log.info("Limpieza: {} filas borradas de {}", negocio, tablaNegocio);

        // El WHERE es OBLIGATORIO: el dead letter es compartido por los 3 jobs.
        int rechazos = jdbc.update(
                "DELETE FROM banco.registro_rechazado WHERE archivo_origen = ?", archivoOrigen);
        log.info("Limpieza: {} filas borradas de banco.registro_rechazado (archivo_origen={})",
                rechazos, archivoOrigen);

        // RepeatStatus.FINISHED = "he terminado, no me vuelvas a llamar".
        // Si devolvieras CONTINUABLE, Spring Batch ejecutaria el tasklet en
        // bucle hasta que dijeras FINISHED.
        return RepeatStatus.FINISHED;
    }
}
