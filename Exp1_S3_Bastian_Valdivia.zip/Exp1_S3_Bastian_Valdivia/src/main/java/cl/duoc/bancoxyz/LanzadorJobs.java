package cl.duoc.bancoxyz;

import cl.duoc.bancoxyz.support.PeriodoIntereses;
import cl.duoc.bancoxyz.tasklet.DeciderCalidadDatos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Lanza el job que le pidas por línea de comandos:
 *
 *     ./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias
 *
 * Existe porque tendremos TRES jobs y hay que poder elegir cuál correr.
 * Por eso en application.yml está spring.batch.job.enabled=false: si lo dejas
 * en true, Spring Boot intenta lanzarlos todos al arrancar.
 */
@Component
public class LanzadorJobs implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(LanzadorJobs.class);

    private final JobLauncher jobLauncher;
    private final JobExplorer jobExplorer;
    private final ApplicationContext contexto;

    public LanzadorJobs(JobLauncher jobLauncher, JobExplorer jobExplorer, ApplicationContext contexto) {
        this.jobLauncher = jobLauncher;
        this.jobExplorer = jobExplorer;
        this.contexto = contexto;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        List<String> pedidos = args.getOptionValues("job");
        Map<String, Job> disponibles = contexto.getBeansOfType(Job.class);

        if (pedidos == null || pedidos.isEmpty()) {
            log.warn("No indicaste ningún job. Usa --job=<nombre>. Disponibles: {}", disponibles.keySet());
            return;
        }

        String nombre = pedidos.get(0);
        Job job = disponibles.get(nombre);
        if (job == null) {
            log.error("No existe el job '{}'. Disponibles: {}", nombre, disponibles.keySet());
            return;
        }

        // getNextJobParameters aplica el JobParametersIncrementer del Job
        // (aqui RunIdIncrementer: anade run.id = 1, 2, 3...) y recupera los
        // parametros de la ejecucion anterior.
        //
        // Sin esto, el segundo lanzamiento con los mismos parametros revienta con
        // JobInstanceAlreadyCompleteException, porque Spring Batch lo ve como
        // "esta ejecucion ya la hiciste y termino bien".
        //
        // El incrementer declarado en el @Bean del Job NO se aplica solo:
        // hay que pedirlo aqui explicitamente.
        JobParameters parametros = new JobParametersBuilder(jobExplorer)
                .getNextJobParameters(job)
                .addString("archivo", archivoDe(nombre))
                // El umbral se anade SIEMPRE, aunque no lo pases por linea de
                // comandos. Esto NO es opcional y la razon es sutil:
                // getNextJobParameters ARRASTRA los parametros de la ejecucion
                // anterior (solo cambia run.id). Si el umbral se anadiera "solo
                // si viene el argumento", despues de un lanzamiento con
                // --umbral=0.10 el siguiente lanzamiento SIN argumento heredaria
                // el 0.10 y seguiria yendo por la rama degradada, en silencio.
                // Anadiendolo siempre, cada ejecucion declara su umbral y queda
                // registrado en BATCH_JOB_EXECUTION_PARAMS.
                .addDouble("umbralRechazo", umbralDe(args))
                // Escenario de fallo SIMULADO que debe inyectar el writer.
                // Se anade SIEMPRE, por exactamente la misma razon sutil que el
                // umbral: getNextJobParameters ARRASTRA los parametros de la
                // ejecucion anterior. Si se anadiera solo cuando viene el
                // argumento, la corrida siguiente a un
                // --simular-fallo=BD_CAIDA_PERMANENTE heredaria el escenario en
                // silencio y volveria a fallar sin que nadie lo pidiera. El
                // sintoma pareceria un bug de datos y no lo seria.
                // Anadiendolo siempre, cada ejecucion DECLARA su escenario
                // (NINGUNO cuando no se pide nada) y queda escrito en
                // BATCH_JOB_EXECUTION_PARAMS como evidencia.
                .addString("simularFallo", escenarioDe(args))
                // Periodo a liquidar en el Job 2 (formato yyyy-MM). Se anade
                // SIEMPRE por la misma razon sutil que el umbral y el escenario
                // de fallo: getNextJobParameters ARRASTRA los parametros de la
                // ejecucion anterior, asi que si solo se anadiera cuando viene
                // el argumento, la corrida siguiente a un --periodo=2024-02
                // heredaria febrero en silencio. Anadiendolo siempre, cada
                // ejecucion DECLARA su periodo y queda escrito en
                // BATCH_JOB_EXECUTION_PARAMS como evidencia.
                //
                // El valor por defecto NO se escribe aqui: lo pone
                // PeriodoIntereses, que es la fuente unica de ese dato.
                .addString(PeriodoIntereses.PARAMETRO, periodoDe(args))
                .toJobParameters();

        log.info("=== Lanzando {} ===", nombre);
        JobExecution ejecucion = jobLauncher.run(job, parametros);
        log.info("=== {} terminó con estado {} ===", nombre, ejecucion.getStatus());
    }

    /**
     * Lee --umbral=<numero> de la linea de comandos; si no viene, 0.25.
     *
     * Para que sirve: la tasa de rechazo real de transacciones.csv es
     * 215/1000 = 0.215, por debajo de 0.25, asi que la ejecucion normal va por
     * la rama CALIDAD_OK. Con --umbral=0.10 se fuerza la rama CALIDAD_DEGRADADA
     * y stepAlertaCalidad se ejecuta de verdad, que es lo que hay que poder
     * demostrar en BATCH_STEP_EXECUTION.
     */
    private static double umbralDe(ApplicationArguments args) {
        List<String> valores = args.getOptionValues("umbral");
        if (valores == null || valores.isEmpty()) {
            return DeciderCalidadDatos.UMBRAL_POR_DEFECTO;
        }
        try {
            return Double.parseDouble(valores.get(0));
        } catch (NumberFormatException e) {
            log.warn("--umbral='{}' no es un numero; uso el valor por defecto {}",
                    valores.get(0), DeciderCalidadDatos.UMBRAL_POR_DEFECTO);
            return DeciderCalidadDatos.UMBRAL_POR_DEFECTO;
        }
    }

    /**
     * Lee --simular-fallo=<ESCENARIO> de la linea de comandos; si no viene,
     * NINGUNO (comportamiento normal, cero coste).
     *
     * Para que sirve: es la forma REPRODUCIBLE de demostrar las politicas de
     * tolerancia sin tener que apagar Docker con el cronometro en la mano. El
     * valor viaja como JobParameter hasta InyectorFallosWriter, que envuelve al
     * escritor real y lanza la excepcion fingida que toque.
     *
     * Escenarios validos (ver InyectorFallosWriter y docs/tolerancia-fallos.md):
     *   NINGUNO              - no inyecta nada
     *   BD_TRANSITORIA       - fallo pasajero de la base: RETRY y se recupera
     *   BLOQUEO              - contencion de cerrojo: RETRY y se recupera
     *   BD_CAIDA_PERMANENTE  - la base no vuelve: se agotan los 3 intentos y FALLA
     *   ESCRITURA_FATAL      - integridad violada: ni retry ni skip, FALLA
     *
     * Se normaliza a mayusculas aqui para que --simular-fallo=bd_transitoria
     * funcione igual: el que reproduce un escenario no deberia perder cinco
     * minutos por un shift.
     */
    private static String escenarioDe(ApplicationArguments args) {
        List<String> valores = args.getOptionValues("simular-fallo");
        if (valores == null || valores.isEmpty() || valores.get(0) == null || valores.get(0).isBlank()) {
            return "NINGUNO";
        }
        return valores.get(0).trim().toUpperCase();
    }

    /**
     * Lee --periodo=yyyy-MM de la linea de comandos; si no viene, el valor por
     * defecto de PeriodoIntereses.
     *
     * Para que sirve: permite liquidar otro mes sin recompilar
     * (--periodo=2024-02) y, sobre todo, permite DEMOSTRAR la idempotencia
     * lanzando el job dos veces con el MISMO periodo y comprobando que
     * banco.cuenta no reaplica el interes.
     *
     * Que el defecto sea FIJO es esencial para esa demostracion: con un
     * defecto que cambiara solo (el mes actual, por ejemplo), las dos corridas
     * usarian periodos distintos, nada chocaria y la prueba "pasaria" sin
     * probar nada.
     */
    private static String periodoDe(ApplicationArguments args) {
        List<String> valores = args.getOptionValues(PeriodoIntereses.PARAMETRO);
        if (valores == null || valores.isEmpty()) {
            return PeriodoIntereses.POR_DEFECTO;
        }
        // Se delega en la misma clase que resuelve el periodo en el resto del
        // job, para no tener dos ideas distintas de "valor utilizable".
        return new PeriodoIntereses().resolver(valores.get(0));
    }

    /** El CSV que consume cada job. Solo informativo: queda en los metadatos. */
    private static String archivoDe(String nombreJob) {
        return switch (nombreJob) {
            case "jobInteresesMensuales"    -> "data/intereses.csv";
            case "jobEstadosCuentaAnuales"  -> "data/cuentas_anuales.csv";
            default                          -> "data/transacciones.csv";
        };
    }
}
