package cl.duoc.bancoxyz.policy;

import org.springframework.retry.backoff.BackOffPolicy;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;

/**
 * FABRICA DE POLITICAS DE ESPERA ENTRE REINTENTOS (backoff).
 *
 * "Backoff" es cuanto se espera antes de volver a intentarlo. Sin backoff, los
 * tres intentos ocurren en el mismo milisegundo: si la base se cayo, los tres
 * fallan igual y el reintento no ha servido para nada. Peor aun, si el motivo
 * era saturacion, machacarla sin pausa la hunde mas (la "tormenta de
 * reintentos").
 *
 * BACKOFF EXPONENCIAL: la espera se multiplica en cada intento.
 *
 *   intento 1 falla -> espera 200 ms
 *   intento 2 falla -> espera 400 ms   (200 x 2.0)
 *   intento 3 falla -> se rinde: la excepcion sube y el step FALLA
 *
 * El tope (maxInterval) existe para que la progresion no se dispare: con
 * muchos intentos, 200, 400, 800, 1600... crece sin freno. Aqui se corta en 5 s.
 *
 * Por que exponencial y no fijo: un fallo transitorio corto se resuelve con la
 * primera espera minima (no penalizas el caso comun), y uno mas largo recibe
 * esperas progresivamente mayores, que es justo lo que necesita. Un backoff
 * fijo obliga a elegir entre "corto y no sirve para cortes largos" o "largo y
 * penaliza todos los fallos".
 */
public final class BackOffPolicies {

    /** Espera del primer reintento, en milisegundos. */
    public static final long ESPERA_INICIAL_MS = 200L;

    /** Cada espera es el doble de la anterior. */
    public static final double MULTIPLICADOR = 2.0;

    /** Ninguna espera pasa de 5 segundos, por mucho que crezca la progresion. */
    public static final long ESPERA_MAXIMA_MS = 5_000L;

    private BackOffPolicies() {
        // clase de utilidad: no se instancia
    }

    public static BackOffPolicy exponencial() {
        ExponentialBackOffPolicy politica = new ExponentialBackOffPolicy();
        politica.setInitialInterval(ESPERA_INICIAL_MS);
        politica.setMultiplier(MULTIPLICADOR);
        politica.setMaxInterval(ESPERA_MAXIMA_MS);
        return politica;
    }
}
