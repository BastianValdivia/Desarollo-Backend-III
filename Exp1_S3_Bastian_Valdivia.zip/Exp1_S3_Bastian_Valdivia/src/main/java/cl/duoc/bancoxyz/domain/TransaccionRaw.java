package cl.duoc.bancoxyz.domain;

import org.springframework.batch.item.ItemCountAware;

/**
 * La fila del CSV TAL CUAL viene, con TODOS los campos como String.
 *
 * ¿Por qué String y no LocalDate/BigDecimal? Porque si le pides al lector que
 * convierta la fecha, revienta con FlatFileParseException al toparse con
 * "2024/10/15" y esa fila MUERE antes de que podamos repararla.
 * Leemos crudo y reparamos después, en el processor.
 *
 * ANTES esto era un `record` (clase inmutable de sólo datos). Ahora es una
 * clase normal porque implementa ItemCountAware, y esa interfaz obliga a
 * tener un campo mutable.
 *
 * ItemCountAware es un gancho de Spring Batch: si el objeto que devuelve el
 * lector implementa esta interfaz, el propio lector le inyecta el número de
 * orden del elemento leído. Es la forma limpia de saber "esta fila era la
 * número 347 del archivo" sin llevar un contador a mano, que además se
 * rompería en cuanto haya particiones leyendo en paralelo.
 */
public class TransaccionRaw implements ItemCountAware {

    private final String id;
    private final String fecha;
    private final String monto;
    private final String tipo;

    /** Lo rellena el propio FlatFileItemReader al leer. Empieza en 1. */
    private int itemCount;

    public TransaccionRaw(String id, String fecha, String monto, String tipo) {
        this.id = id;
        this.fecha = fecha;
        this.monto = monto;
        this.tipo = tipo;
    }

    // Getters con el estilo de los records (id(), fecha()...) para no tener
    // que tocar el resto del código que ya los usaba así.
    public String id()    { return id; }
    public String fecha() { return fecha; }
    public String monto() { return monto; }
    public String tipo()  { return tipo; }

    @Override
    public void setItemCount(int count) {
        this.itemCount = count;
    }

    /**
     * Posición de este elemento DENTRO DE SU LECTOR (el primero es el 1).
     *
     * OJO: no es el número de línea del archivo. Con particiones, cada una
     * tiene su propio lector que empieza a contar en cero, así que la
     * partición que lee las filas 251-500 devolvería aquí 1, 2, 3...
     * La línea física se calcula en el processor sumando el linesToSkip
     * de la partición, que es el único que conoce el desplazamiento.
     */
    public int itemCount() {
        return itemCount;
    }

    @Override
    public String toString() {
        return String.join(",", id, fecha, monto, tipo);
    }
}
