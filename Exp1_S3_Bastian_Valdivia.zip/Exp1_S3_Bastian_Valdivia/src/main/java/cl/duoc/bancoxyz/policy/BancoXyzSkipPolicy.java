package cl.duoc.bancoxyz.policy;

import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.dao.DuplicateKeyException;

/**
 * Política PERSONALIZADA de omisión: decide, ante cada error, si la fila se
 * omite y el proceso sigue, o si el step debe morir.
 *
 * La distinción clave de todo el trabajo:
 *   - DATO SUCIO        -> se omite y se registra. El proceso continúa.
 *   - FALLO DE INFRAESTRUCTURA -> NO se omite. Si falta el archivo o se cayó la
 *     base de datos, tragárselo haría que el job "termine bien" con 0 filas.
 *
 * OJO CON LA FIRMA: es shouldSkip(Throwable, long). Con "int" (como en versiones
 * antiguas) NO estarías sobrescribiendo el método y tu política nunca se ejecutaría.
 *
 * OJO CON skipCount < 0: Spring Batch llama al método en "modo sonda" con un
 * contador negativo, sólo para preguntar si la excepción es omitible. Si en ese
 * caso lanzas la excepción de límite, rompes el mecanismo.
 */
public class BancoXyzSkipPolicy implements SkipPolicy {

    private final long limite;

    public BancoXyzSkipPolicy(long limite) {
        this.limite = limite;
    }

    @Override
    public boolean shouldSkip(Throwable t, long skipCount) throws SkipLimitExceededException {
        boolean esOmitible = esDatoSucio(t);

        // modo sonda: sólo responder si es omitible, sin evaluar el límite
        if (skipCount < 0) {
            return esOmitible;
        }
        if (!esOmitible) {
            return false;   // infraestructura: que falle el step
        }
        if (skipCount >= limite) {
            // Tolerancia sin techo es negligencia: superado el límite, el job falla a propósito.
            throw new SkipLimitExceededException(limite, t);
        }
        return true;
    }

    /**
     * Recorre la cadena de causas, porque Spring suele envolver las excepciones.
     *
     * ------------------------------------------------------------------
     * POR QUE DuplicateKeyException CUENTA COMO "DATO SUCIO"
     * ------------------------------------------------------------------
     * Es la unica de las tres que NO nace en el processor sino en la fase
     * WRITE, cuando PostgreSQL rechaza el INSERT por violar una restriccion
     * UNIQUE. La restriccion en cuestion es uq_interes_posicion, y salta con
     * las filas de intereses.csv que estan repetidas AL 100% (mismo
     * cuenta_id, nombre, saldo, edad y tipo).
     *
     * Una fila duplicada es un DATO MALO, no un fallo de la base: la base
     * esta funcionando perfectamente, precisamente por eso detecta el
     * duplicado. Reintentarla fallaria las tres veces igual (el dato no
     * cambia entre intentos), asi que lo correcto es omitirla y mandarla al
     * dead letter con motivo DUPLICADO. Por eso tampoco esta en el mapa de
     * RetryPolicies.infraestructura(), donde el valor por defecto es false.
     *
     * SE ANOTA LA CLASE HIJA, NUNCA EL PADRE. DuplicateKeyException hereda de
     * DataIntegrityViolationException, y esa PADRE es justo la que lanza a
     * proposito el escenario ESCRITURA_FATAL de InyectorFallosWriter para
     * demostrar un fallo que NO se debe tragar (ver docs/tolerancia-fallos.md).
     * Si aqui pusieramos el padre, ese escenario pasaria de "el step muere,
     * como debe" a "se omite en silencio", y romperiamos EscenariosFalloTest.
     * Un "violacion de integridad" generica puede significar cualquier cosa
     * (una FK rota, un CHECK incumplido por un bug nuestro) y ante la duda un
     * proceso batch tiene que parar, no seguir.
     *
     * Para el Job 1 esta linea es inerte: transacciones.csv no tiene ids
     * repetidos, asi que la excepcion nunca llega a producirse alli.
     */
    private boolean esDatoSucio(Throwable t) {
        Throwable actual = t;
        while (actual != null) {
            if (actual instanceof RegistroInvalidoException
                    || actual instanceof FlatFileParseException
                    || actual instanceof DuplicateKeyException) {
                return true;
            }
            actual = actual.getCause();
        }
        return false;
    }
}
