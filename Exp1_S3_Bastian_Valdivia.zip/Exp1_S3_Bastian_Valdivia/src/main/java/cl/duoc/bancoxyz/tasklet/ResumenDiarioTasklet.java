package cl.duoc.bancoxyz.tasklet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

/**
 * AGREGACION del Job 1: una fila de banco.resumen_diario por cada fecha
 * distinta presente en banco.transaccion.
 *
 * POR QUE UN TASKLET Y NO UN STEP DE CHUNK:
 * un chunk step lee fila a fila y escribe fila a fila. Aqui no hay nada que
 * leer fila a fila: el trabajo es un GROUP BY que la base hace muchisimo mas
 * rapido que Java, y ademas en UNA sola sentencia (es decir, atomica). Cuando
 * el trabajo entero cabe en un SQL, un Tasklet es la herramienta correcta.
 *
 * ON CONFLICT (fecha) DO UPDATE es el "UPSERT" de PostgreSQL: si ya existe una
 * fila con esa fecha, en vez de reventar por clave duplicada la actualiza. Es
 * lo que hace este step repetible.
 *
 * n_rechazadas queda en 0 A PROPOSITO: una fila rechazada por FECHA_INVALIDA no
 * tiene fecha valida por la que agrupar, asi que no pertenece a ningun dia. El
 * recuento de rechazos vive en banco.registro_rechazado y en control_carga.
 */
public class ResumenDiarioTasklet implements Tasklet {

    private static final Logger log = LoggerFactory.getLogger(ResumenDiarioTasklet.class);

    /** SQL literal del plan maestro §9. */
    private static final String SQL = """
            INSERT INTO banco.resumen_diario
                  (fecha, total_operaciones, n_creditos, n_debitos, n_tipo_desconocido,
                   monto_total, monto_creditos, monto_debitos, monto_promedio, monto_maximo,
                   n_anomalas, n_rechazadas, job_execution_id, generado_en)
            SELECT t.fecha,
                   COUNT(*),
                   COUNT(*) FILTER (WHERE t.tipo='CREDITO'),
                   COUNT(*) FILTER (WHERE t.tipo='DEBITO'),
                   COUNT(*) FILTER (WHERE t.tipo='DESCONOCIDO'),
                   SUM(t.monto),
                   COALESCE(SUM(t.monto) FILTER (WHERE t.tipo='CREDITO'), 0),
                   COALESCE(SUM(t.monto) FILTER (WHERE t.tipo='DEBITO'), 0),
                   ROUND(AVG(t.monto), 4),
                   MAX(t.monto),
                   COUNT(*) FILTER (WHERE t.es_anomala),
                   0,
                   :jobExecutionId, now()
              FROM banco.transaccion t
             WHERE t.job_execution_id = :jobExecutionId
             GROUP BY t.fecha
            ON CONFLICT (fecha) DO UPDATE
               SET total_operaciones = EXCLUDED.total_operaciones,
                   n_creditos = EXCLUDED.n_creditos, n_debitos = EXCLUDED.n_debitos,
                   n_tipo_desconocido = EXCLUDED.n_tipo_desconocido,
                   monto_total = EXCLUDED.monto_total, monto_creditos = EXCLUDED.monto_creditos,
                   monto_debitos = EXCLUDED.monto_debitos, monto_promedio = EXCLUDED.monto_promedio,
                   monto_maximo = EXCLUDED.monto_maximo, n_anomalas = EXCLUDED.n_anomalas,
                   job_execution_id = EXCLUDED.job_execution_id, generado_en = now()
            """;

    private final NamedParameterJdbcTemplate jdbc;

    /**
     * NamedParameterJdbcTemplate y no JdbcTemplate a secas porque el SQL usa
     * parametros CON NOMBRE (:jobExecutionId) en vez de interrogantes. Con el
     * JdbcTemplate normal habria que repetir el mismo valor dos veces y en el
     * orden exacto; con nombres, se pasa una vez y no hay forma de equivocarse.
     * Nota: t.es_anomala es una columna GENERATED, pero aqui solo se LEE dentro
     * del FILTER, que es perfectamente legal; lo prohibido es insertarla.
     */
    public ResumenDiarioTasklet(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        Long jobExecutionId = chunkContext.getStepContext().getStepExecution().getJobExecutionId();

        int filas = jdbc.update(SQL, new MapSqlParameterSource("jobExecutionId", jobExecutionId));

        log.info("resumen_diario: {} filas insertadas/actualizadas (job_execution_id={})",
                filas, jobExecutionId);

        // Se deja el conteo en el ExecutionContext del step: asi queda persistido
        // en los metadatos de Spring Batch y es evidencia consultable despues.
        chunkContext.getStepContext().getStepExecution()
                .getExecutionContext().putInt("filasResumenDiario", filas);

        return RepeatStatus.FINISHED;
    }
}
