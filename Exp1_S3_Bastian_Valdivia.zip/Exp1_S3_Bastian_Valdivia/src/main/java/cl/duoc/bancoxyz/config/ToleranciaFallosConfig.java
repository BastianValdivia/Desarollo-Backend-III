package cl.duoc.bancoxyz.config;

import cl.duoc.bancoxyz.listener.ChunkErrorListener;
import cl.duoc.bancoxyz.listener.ReintentoRetryListener;
import cl.duoc.bancoxyz.policy.BackOffPolicies;
import cl.duoc.bancoxyz.policy.BancoXyzSkipPolicy;
import cl.duoc.bancoxyz.policy.RetryPolicies;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.backoff.BackOffPolicy;

/**
 * TODA LA TOLERANCIA A FALLOS EN UN SOLO SITIO.
 *
 * Los tres jobs (transacciones, intereses, cuentas anuales) comparten la misma
 * doctrina de fallos, asi que las politicas viven aqui como beans y cada job se
 * limita a inyectarlas. Si manana se decide subir de 3 a 4 intentos, se cambia
 * en UN sitio y cambia en los tres jobs. Si estuviera escrito dentro de cada
 * JobConfig, cambiaria en el que uno se acuerde de tocar.
 *
 * --------------------------------------------------------------------------
 * EL RESUMEN DE LA DOCTRINA, EN CUATRO LINEAS
 * --------------------------------------------------------------------------
 *   Dato malo irreparable  -> SKIP + dead letter.  NUNCA retry.
 *   Dato degradado         -> se GUARDA marcado.   Ni skip ni retry.
 *   Fallo de infraestructura -> RETRY con backoff. NUNCA skip.
 *   Nada de lo anterior    -> FAIL FAST: el step muere y se ve el motivo.
 *
 * La cuarta linea es tan importante como las otras tres: un
 * .skip(Exception.class) se tragaria un "archivo no encontrado" y el job
 * terminaria COMPLETED con cero filas cargadas. Un job que miente es peor que
 * un job que falla.
 */
@Configuration
public class ToleranciaFallosConfig {

    /**
     * Politica de REINTENTO. Solo infraestructura. Ver RetryPolicies para el
     * detalle de por que el veto a los datos sucios viaja dentro del mapa y no
     * en un .noRetry() del builder.
     */
    @Bean
    public RetryPolicy retryPolicyInfraestructura() {
        return RetryPolicies.infraestructura();
    }

    /** Espera creciente entre reintentos: 200 ms, 400 ms, ... con tope de 5 s. */
    @Bean
    public BackOffPolicy backOffExponencial() {
        return BackOffPolicies.exponencial();
    }

    /** Deja constancia en el log de cada intento fallido. Sin el, los reintentos son invisibles. */
    @Bean
    public ReintentoRetryListener reintentoRetryListener() {
        return new ReintentoRetryListener();
    }

    /** Deja constancia de cada rollback de chunk, con la excepcion que lo causo. */
    @Bean
    public ChunkErrorListener chunkErrorListener() {
        return new ChunkErrorListener();
    }

    /**
     * Politica de OMISION, parametrizable desde fuera.
     *
     * El limite se lee de la propiedad banco.tolerancia.limite-omisiones, que
     * por defecto vale 500. Se hace asi para poder DEMOSTRAR el escenario del
     * techo de tolerancia sin tocar codigo ni fabricar un CSV envenenado:
     *
     *   --banco.tolerancia.limite-omisiones=10
     *
     * Con 10, las 215 filas rechazadas de transacciones.csv (unas 54 por
     * particion) revientan el limite y el job FALLA a proposito con
     * SkipLimitExceededException. Tolerar sin techo no es tolerancia, es
     * negligencia: si el 90% del archivo esta mal, lo correcto es parar y
     * avisar, no cargar el 10% y declarar exito.
     *
     * MATIZ QUE HAY QUE DECLARAR (trampa clasica del step particionado):
     * el limite es POR StepExecution, es decir POR PARTICION. Con 4 particiones
     * y limite 500, el job entero tolera hasta 2000 omisiones, no 500. La
     * cuadratura final (entrada = negocio + rechazos) es la que de verdad
     * garantiza que no se perdio nada.
     *
     * NOTA: se declara como bean prototype implicito -cada job pide el suyo-
     * porque SkipPolicy no guarda estado (el contador lo aporta el framework),
     * asi que compartir la instancia entre los tres jobs tambien seria correcto.
     */
    @Bean
    public SkipPolicy skipPolicyBancoXyz(
            @Value("${banco.tolerancia.limite-omisiones:500}") long limiteOmisiones) {
        return new BancoXyzSkipPolicy(limiteOmisiones);
    }
}
