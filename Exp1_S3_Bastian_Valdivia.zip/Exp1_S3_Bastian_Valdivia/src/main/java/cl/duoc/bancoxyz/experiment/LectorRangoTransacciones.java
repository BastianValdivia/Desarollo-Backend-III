package cl.duoc.bancoxyz.experiment;

import cl.duoc.bancoxyz.domain.TransaccionRaw;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.core.io.Resource;

import java.util.concurrent.atomic.AtomicReference;

/**
 * El lector del banco de pruebas. Sirve para las TRES estrategias con un solo
 * objeto, y esa es toda su razon de ser.
 *
 * ------------------------------------------------------------------------
 * EL PROBLEMA QUE RESUELVE
 * ------------------------------------------------------------------------
 * En el Job 1 "de verdad" el lector es un @Bean @StepScope: Spring crea una
 * instancia por particion y le inyecta linesToSkip/maxItemCount con SpEL
 * (#{stepExecutionContext[...]}). Aqui no podemos hacer eso, porque los Job y
 * los Step del experimento NO son beans: se construyen a mano en
 * FabricaJobsExperimento para poder variar el chunkSize, que se fija en
 * tiempo de construccion del step y no admite cambiarse despues.
 *
 * ------------------------------------------------------------------------
 * COMO LO RESUELVE: el propio contrato de ItemStream
 * ------------------------------------------------------------------------
 * ItemStream.open(ExecutionContext) recibe EXACTAMENTE el mismo mapa que
 * @StepScope leeria con SpEL: el ExecutionContext DEL STEP EN CURSO, que en
 * un step particionado es el que el Partitioner rellena para esa particion.
 * Asi que en vez de pedirle a Spring que nos inyecte el rango, lo leemos
 * nosotros del contexto que el framework ya nos esta pasando.
 *
 * ------------------------------------------------------------------------
 * POR QUE UN ThreadLocal Y NO UN CAMPO NORMAL
 * ------------------------------------------------------------------------
 * Este UNICO objeto lo comparten las N particiones, que corren a la vez en
 * hilos distintos. Un campo 'delegate' normal seria pisado por la ultima
 * particion en abrirse y todas acabarian leyendo el mismo rango: contarias
 * N veces las mismas filas y creerias que va rapidisimo. Con un ThreadLocal
 * cada hilo de particion tiene su propio lector sobre su propio rango.
 *
 * El 'respaldo' cubre el caso MULTI_THREAD, donde open() ocurre en el hilo
 * principal pero los read() llegan desde los hilos del pool, que nunca
 * ejecutaron open() y por tanto tienen el ThreadLocal vacio. Ahi solo hay UN
 * lector (el fichero entero) y compartirlo es correcto... siempre que el
 * acceso este serializado, que es justo lo que hace el
 * SynchronizedItemStreamReader que lo envuelve en esa estrategia.
 */
public class LectorRangoTransacciones implements ItemStreamReader<TransaccionRaw> {

    private final Resource recurso;
    private final int lineasCabecera;

    /** Un lector por hilo: es lo que hace correcto el modo PARTICIONADO. */
    private final ThreadLocal<FlatFileItemReader<TransaccionRaw>> porHilo = new ThreadLocal<>();

    /** Ultimo lector abierto. Solo lo usan hilos que no ejecutaron open(): MULTI_THREAD. */
    private final AtomicReference<FlatFileItemReader<TransaccionRaw>> respaldo = new AtomicReference<>();

    public LectorRangoTransacciones(Resource recurso, int lineasCabecera) {
        this.recurso = recurso;
        this.lineasCabecera = lineasCabecera;
    }

    @Override
    public void open(ExecutionContext ctx) throws ItemStreamException {
        // Operador "si no esta la clave, usa esto": el mismo papel que el Elvis
        // de SpEL en el Job 1. Sin particiones estas claves no existen y el
        // lector se queda con "todo el fichero desde la cabecera".
        int saltar = ctx.containsKey("linesToSkip") ? ctx.getInt("linesToSkip") : lineasCabecera;
        int cuantas = ctx.containsKey("maxItemCount") ? ctx.getInt("maxItemCount") : Integer.MAX_VALUE;
        String particion = ctx.containsKey("partitionName") ? ctx.getString("partitionName") : "unica";

        FlatFileItemReader<TransaccionRaw> lector = new FlatFileItemReaderBuilder<TransaccionRaw>()
                // Nombre unico por particion: es el prefijo con el que el lector
                // guarda su progreso en el ExecutionContext. Repetirlo entre
                // particiones mezclaria los estados de reinicio.
                .name("lectorExperimento-" + particion)
                .resource(recurso)
                .linesToSkip(saltar)
                // maxItemCount es un CONTADOR de filas a leer, no un indice final.
                .maxItemCount(cuantas)
                .delimited().delimiter(",")
                .names("id", "fecha", "monto", "tipo")
                .fieldSetMapper(fs -> new TransaccionRaw(
                        fs.readString("id"),
                        fs.readString("fecha"),
                        fs.readString("monto"),
                        fs.readString("tipo")))
                .build();

        lector.open(ctx);
        porHilo.set(lector);
        respaldo.set(lector);
    }

    @Override
    public TransaccionRaw read() throws Exception {
        return activo().read();
    }

    @Override
    public void update(ExecutionContext ctx) throws ItemStreamException {
        FlatFileItemReader<TransaccionRaw> lector = porHilo.get();
        if (lector != null) {
            lector.update(ctx);
        }
    }

    @Override
    public void close() throws ItemStreamException {
        FlatFileItemReader<TransaccionRaw> lector = porHilo.get();
        if (lector != null) {
            lector.close();
        }
        // LIMPIAR EL ThreadLocal NO ES OPCIONAL. Los hilos del pool se reutilizan
        // entre repeticiones y entre casos; si dejaramos el lector viejo dentro,
        // la siguiente repeticion que cayera en ese hilo leeria el rango de la
        // anterior. Seria un error silencioso y los tiempos saldrian absurdos.
        porHilo.remove();
        respaldo.set(null);
    }

    private FlatFileItemReader<TransaccionRaw> activo() {
        FlatFileItemReader<TransaccionRaw> lector = porHilo.get();
        if (lector == null) {
            lector = respaldo.get();
        }
        if (lector == null) {
            throw new IllegalStateException("El lector del experimento se uso sin abrir");
        }
        return lector;
    }
}
