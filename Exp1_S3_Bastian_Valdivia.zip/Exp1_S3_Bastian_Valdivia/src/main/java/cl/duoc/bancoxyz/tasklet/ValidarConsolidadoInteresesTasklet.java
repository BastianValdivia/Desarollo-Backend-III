package cl.duoc.bancoxyz.tasklet;

import cl.duoc.bancoxyz.support.PeriodoIntereses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Controles de COHERENCIA DEL CONSOLIDADO del Job 2.
 *
 * Es el gemelo de ValidarConsolidadoAnualTasklet, que el Job 3 ya tenia y el
 * Job 2 no. Esa ausencia era el agujero: en el Job 3, si el consolidado se
 * desviaba del detalle, ValidarConsolidadoAnualTasklet lo cazaba y el job
 * quedaba FAILED. En el Job 2 no habia NADA que contrastara banco.cuenta contra
 * banco.interes_calculado, asi que un consolidado incoherente terminaba
 * COMPLETED y en silencio.
 *
 * ------------------------------------------------------------------------
 * POR QUE NO BASTA CON CuadraturaTasklet
 * ------------------------------------------------------------------------
 * No se solapan: responden preguntas distintas y las dos hacen falta.
 *
 *   CuadraturaTasklet responde "no se ha perdido ninguna fila de ENTRADA":
 *       1000 = 784 de negocio + 216 rechazadas + 0 filtradas.
 *
 *   Esta clase responde "el AGREGADO es fiel a lo que agrega":
 *       las 50 filas de banco.cuenta dicen la verdad sobre las 784 de
 *       banco.interes_calculado.
 *
 * Es la diferencia entre "no perdi datos al cargar" y "no me equivoque al
 * resumir". Un consolidado que se quedo con los saldos de una corrida anterior
 * pasaria la primera comprobacion sin despeinarse.
 *
 * ------------------------------------------------------------------------
 * EL CASO CONCRETO QUE ESTE STEP CONVIERTE EN FALLO
 * ------------------------------------------------------------------------
 * Reinicio de la JobInstance en el que stepPrepararIntereses borra las 784
 * filas del periodo y la recarga no se repite. banco.interes_calculado queda
 * VACIA, ConsolidarSaldosTasklet no tiene nada que insertar (0 filas afectadas)
 * y banco.cuenta conserva 50 filas cuyo n_posiciones suma 784 e incluye un
 * interes que ya no se puede reconstruir desde ningun detalle. El CONTROL 1 de
 * abajo compara justo esos dos numeros y hace fallar el job.
 *
 * ------------------------------------------------------------------------
 * POR QUE SE RECOGEN TODOS LOS FALLOS ANTES DE LANZAR
 * ------------------------------------------------------------------------
 * Mismo criterio que en el Job 3: se ejecutan todas las comprobaciones, se
 * acumulan los problemas y se lanza UNA excepcion con todos dentro. Cortar en
 * el primero obligaria a reejecutar el job entero -varios minutos- por cada
 * problema. Acumulando, el primer fallo ya trae el diagnostico completo.
 *
 * Y se lanza una excepcion en vez de dejar un WARN en el log porque un WARN no
 * lo lee nadie: FAILED es un hecho observable en BATCH_JOB_EXECUTION y en el
 * codigo de salida del proceso. Un batch nunca debe terminar COMPLETED
 * diciendo una mentira.
 */
public class ValidarConsolidadoInteresesTasklet implements Tasklet {

    private static final Logger log =
            LoggerFactory.getLogger(ValidarConsolidadoInteresesTasklet.class);

    private final JdbcTemplate jdbc;
    private final PeriodoIntereses periodoIntereses;

    public ValidarConsolidadoInteresesTasklet(JdbcTemplate jdbc, PeriodoIntereses periodoIntereses) {
        this.jdbc = jdbc;
        this.periodoIntereses = periodoIntereses;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // El periodo se resuelve SIEMPRE por PeriodoIntereses, como en la
        // limpieza y en la consolidacion. Tres sitios con tres ideas distintas
        // del periodo serian tres bugs esperando su turno.
        String periodo = periodoIntereses.resolver(chunkContext);

        List<String> problemas = new ArrayList<>();

        // ==============================================================
        // CONTROL 1: SUM(n_posiciones) del consolidado == COUNT(*) del detalle.
        //
        // Es LA comprobacion que faltaba. Detecta a la vez el error de
        // agregacion clasico (un JOIN que duplica filas da de mas, un WHERE que
        // se deja filas fuera da de menos) y el caso del reinicio, en el que el
        // detalle desaparece y el consolidado se queda con numeros huerfanos.
        // ==============================================================
        long consolidado = contar(
                "SELECT COALESCE(SUM(n_posiciones), 0) FROM banco.cuenta WHERE periodo_aplicado = ?",
                periodo);
        long detalle = contar(
                "SELECT COUNT(*) FROM banco.interes_calculado WHERE periodo = ?", periodo);

        if (consolidado != detalle) {
            problemas.add("SUM(n_posiciones)=" + consolidado + " en banco.cuenta no coincide con"
                    + " las " + detalle + " filas de banco.interes_calculado del periodo "
                    + periodo + ". El consolidado NO se puede reconstruir desde el detalle.");
        }

        // ==============================================================
        // CONTROL 2: el detalle no puede estar vacio.
        //
        // Se comprueba aparte del CONTROL 1 aunque parezca redundante: si el
        // consolidado tambien estuviera vacio, 0 == 0 pasaria el control 1 por
        // vacuidad. Es el mismo fallo por vacuidad que tenia la cuadratura, y
        // aqui se cierra de la misma forma: con el fichero de origen como
        // referencia, no con los propios numeros del job.
        // ==============================================================
        if (detalle == 0) {
            problemas.add("banco.interes_calculado NO tiene ninguna fila del periodo " + periodo
                    + ". El job habria consolidado la nada; no se puede dar por bueno.");
        }

        // ==============================================================
        // CONTROL 3: la aritmetica de cada cuenta se reconstruye desde el
        // detalle, cuenta por cuenta.
        //
        // El control 1 compara un total; este compara fila a fila. Un total
        // puede cuadrar por compensacion (una cuenta de mas y otra de menos) y
        // seguir siendo incorrecto en las dos.
        //
        // IS DISTINCT FROM y no <>: con <>, comparar contra NULL da NULL (que no
        // es TRUE), asi que una fila con saldo_inicial NULL NO se contaria como
        // descuadrada y el control la dejaria pasar.
        // ==============================================================
        long descuadradas = contar("""
                SELECT COUNT(*)
                  FROM banco.cuenta c
                  JOIN (SELECT cuenta_id,
                               COUNT(*)             AS n,
                               SUM(saldo_inicial)   AS si,
                               SUM(interes)         AS ia
                          FROM banco.interes_calculado
                         WHERE periodo = ?
                         GROUP BY cuenta_id) d
                    ON d.cuenta_id = c.cuenta_id
                 WHERE c.n_posiciones     IS DISTINCT FROM d.n
                    OR c.saldo_inicial    IS DISTINCT FROM d.si
                    OR c.interes_aplicado IS DISTINCT FROM d.ia
                """, periodo);
        if (descuadradas > 0) {
            problemas.add(descuadradas + " cuentas de banco.cuenta tienen n_posiciones,"
                    + " saldo_inicial o interes_aplicado que no se pueden reconstruir desde"
                    + " banco.interes_calculado del periodo " + periodo);
        }

        // ==============================================================
        // CONTROL 4: ninguna cuenta con detalle se quedo sin consolidar.
        //
        // Los controles 1-3 miran las filas que SI existen. Este mira las que
        // FALTAN, y ademas dice CUALES son, que es lo que ahorra tiempo al
        // diagnosticar.
        // ==============================================================
        List<Integer> sinConsolidar = jdbc.queryForList("""
                SELECT DISTINCT i.cuenta_id
                  FROM banco.interes_calculado i
                 WHERE i.periodo = ?
                   AND NOT EXISTS (SELECT 1 FROM banco.cuenta c
                                    WHERE c.cuenta_id = i.cuenta_id
                                      AND c.periodo_aplicado = i.periodo)
                 ORDER BY 1
                """, Integer.class, periodo);
        if (!sinConsolidar.isEmpty()) {
            problemas.add("cuentas con interes calculado pero SIN consolidar en banco.cuenta"
                    + " para el periodo " + periodo + ": " + sinConsolidar);
        }

        // ==============================================================
        // VEREDICTO
        // ==============================================================
        if (!problemas.isEmpty()) {
            throw new IllegalStateException(
                    "CONSOLIDADO DE INTERESES INCOHERENTE (periodo=" + periodo + ", "
                            + problemas.size() + " problemas): " + String.join(" | ", problemas));
        }

        BigDecimal saldo = jdbc.queryForObject(
                "SELECT COALESCE(SUM(saldo), 0) FROM banco.cuenta WHERE periodo_aplicado = ?",
                BigDecimal.class, periodo);

        log.info("CONSOLIDADO DE INTERESES OK (periodo={}): SUM(n_posiciones)={} = {} filas de"
                        + " detalle, 0 cuentas descuadradas, saldo consolidado={}",
                periodo, consolidado, detalle, saldo);

        return RepeatStatus.FINISHED;
    }

    /** Atajo para los COUNT/SUM: JdbcTemplate devuelve Long y aqui nunca es null. */
    private long contar(String sql, Object... args) {
        Long n = jdbc.queryForObject(sql, Long.class, args);
        return n == null ? 0L : n;
    }
}
