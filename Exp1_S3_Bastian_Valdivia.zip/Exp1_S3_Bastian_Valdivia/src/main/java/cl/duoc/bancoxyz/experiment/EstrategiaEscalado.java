package cl.duoc.bancoxyz.experiment;

/**
 * Las tres formas de ejecutar el MISMO trabajo. Son lo que se compara en el
 * criterio 4: no basta con "implementar particiones", hay que medir varias
 * configuraciones y decir cual gana Y EN QUE CONDICIONES.
 *
 * SECUENCIAL
 *   Un solo step, un solo hilo. Lee el archivo entero de principio a fin.
 *   Es la BASE de comparacion: cualquier speedup se mide contra el mejor
 *   secuencial, nunca contra "el particionado con 2 hilos".
 *
 * MULTI_THREAD
 *   UN solo step al que se le da un TaskExecutor: los chunks se procesan en
 *   paralelo, pero TODOS comparten el mismo lector. Como FlatFileItemReader
 *   NO es thread-safe, hay que envolverlo en SynchronizedItemStreamReader, y
 *   eso SERIALIZA la lectura: solo se paralelizan processor y writer.
 *   Consecuencia honesta: si el cuello de botella es leer el fichero, esta
 *   estrategia no puede ganar por construccion.
 *
 * PARTICIONADO
 *   Un step MANAGER reparte el archivo en N rangos disjuntos y lanza N copias
 *   del step WORKER, cada una con SU PROPIO lector sobre su rango. No hay
 *   cerrojo compartido, asi que aqui si se paraleliza la lectura tambien.
 *   El precio es el reparto (cada particion reabre el fichero) y el alta de
 *   N StepExecution en la base de metadatos.
 */
public enum EstrategiaEscalado {
    SECUENCIAL,
    MULTI_THREAD,
    PARTICIONADO
}
