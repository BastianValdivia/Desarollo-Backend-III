package cl.duoc.bancoxyz.domain;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * La transacción ya limpia, lista para guardar en la base de datos.
 *
 * Esto NO es un record sino una clase normal con getters, porque el writer
 * (JdbcBatchItemWriter con .beanMapped()) busca métodos getXxx() para mapear
 * cada campo a su columna. Un record expone "fecha()" y no "getFecha()".
 *
 * Fíjate que guardamos también los valores ORIGINALES (fechaOriginal,
 * montoOriginal...). Eso permite demostrarle al evaluador qué había antes
 * y qué quedó después de normalizar.
 */
public class Transaccion {

    private Long id;
    private LocalDate fecha;
    private String fechaOriginal;
    private String formatoFecha;
    private BigDecimal monto;
    private String montoOriginal;
    private String tipo;            // CREDITO | DEBITO | DESCONOCIDO
    private String tipoOriginal;
    private String estado;
    /** TODAS las anomalias detectadas, separadas por coma. El estado nombra solo una. */
    private String anomalias = "";
    /** Linea fisica del CSV de la que salio esta fila. Sirve para auditar. */
    private Long numeroLinea;
    private Long jobExecutionId;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public String getFechaOriginal() { return fechaOriginal; }
    public void setFechaOriginal(String fechaOriginal) { this.fechaOriginal = fechaOriginal; }

    public String getFormatoFecha() { return formatoFecha; }
    public void setFormatoFecha(String formatoFecha) { this.formatoFecha = formatoFecha; }

    public BigDecimal getMonto() { return monto; }
    public void setMonto(BigDecimal monto) { this.monto = monto; }

    public String getMontoOriginal() { return montoOriginal; }
    public void setMontoOriginal(String montoOriginal) { this.montoOriginal = montoOriginal; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getTipoOriginal() { return tipoOriginal; }
    public void setTipoOriginal(String tipoOriginal) { this.tipoOriginal = tipoOriginal; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public Long getJobExecutionId() { return jobExecutionId; }
    public void setJobExecutionId(Long jobExecutionId) { this.jobExecutionId = jobExecutionId; }

    public String getAnomalias() { return anomalias; }
    public void setAnomalias(String anomalias) { this.anomalias = anomalias; }

    public Long getNumeroLinea() { return numeroLinea; }
    public void setNumeroLinea(Long numeroLinea) { this.numeroLinea = numeroLinea; }
}
