package cl.duoc.bancoxyz.tasklet;

import cl.duoc.bancoxyz.support.ControlCargaDao;
import cl.duoc.bancoxyz.support.ControlCargaDao.ContadoresCarga;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

/**
 * RAMA DEGRADADA del flujo: se ejecuta solo cuando el decider dice que la tasa
 * de rechazo supero el umbral.
 *
 * NO LANZA EXCEPCION a proposito. Una alerta AVISA; matar el proceso es tarea
 * de la cuadratura, que es la unica condicion que de verdad invalida la carga.
 * Un dataset sucio pero completo sigue siendo una carga valida: lo que no es
 * aceptable es perder filas. Por eso este step termina COMPLETED y el flujo
 * continua hacia stepResumenDiario.
 *
 * Escribe la MISMA fila de banco.control_carga que escribira despues la
 * cuadratura (clave job_execution_id + archivo_origen, ON CONFLICT DO UPDATE) y
 * con los MISMOS contadores, porque los dos los piden a ControlCargaDao. Asi el
 * valor final no depende de cual de los dos corrio antes.
 */
public class AlertaCalidadTasklet implements Tasklet {

    private static final Logger log = LoggerFactory.getLogger(AlertaCalidadTasklet.class);

    private final ControlCargaDao dao;
    private final JdbcTemplate jdbc;
    private final String archivoOrigen;
    private final String tablaNegocio;
    private final String prefijoWorker;

    public AlertaCalidadTasklet(ControlCargaDao dao, JdbcTemplate jdbc, String archivoOrigen,
                                String tablaNegocio, String prefijoWorker) {
        this.dao = dao;
        this.jdbc = jdbc;
        this.archivoOrigen = archivoOrigen;
        this.tablaNegocio = tablaNegocio;
        this.prefijoWorker = prefijoWorker;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        JobExecution jobExecution = chunkContext.getStepContext().getStepExecution().getJobExecution();

        double tasa = jobExecution.getExecutionContext().getDouble("tasaRechazo", 0.0);
        double umbral = jobExecution.getExecutionContext()
                .getDouble("umbralRechazo", DeciderCalidadDatos.UMBRAL_POR_DEFECTO);

        ContadoresCarga c = dao.contar(jobExecution, prefijoWorker, tablaNegocio, archivoOrigen);

        log.warn("=========================================================");
        log.warn("CALIDAD DEGRADADA en {}: tasa de rechazo {} > umbral {}",
                archivoOrigen, String.format("%.4f", tasa), umbral);
        log.warn("  entrada={} negocio={} rechazadas={} filtradas={}",
                c.entrada(), c.negocio(), c.rechazadas(), c.filtradas());

        // GROUP BY motivo ORDER BY 2 DESC: el "top" de causas. Sin esto la
        // alerta diria QUE hay un problema pero no POR QUE, que es lo unico
        // accionable para quien recibe el aviso.
        List<Map<String, Object>> motivos = jdbc.queryForList(
                "SELECT motivo, COUNT(*) AS n FROM banco.registro_rechazado"
                        + " WHERE job_execution_id = ? AND archivo_origen = ?"
                        + " GROUP BY motivo ORDER BY 2 DESC",
                jobExecution.getId(), archivoOrigen);

        log.warn("  motivos de rechazo (de mas a menos frecuente):");
        motivos.forEach(m -> log.warn("    {} -> {}", m.get("motivo"), m.get("n")));
        log.warn("=========================================================");

        // Deja la evidencia persistida ya, no solo en el log: los logs se pierden.
        dao.upsert(c, jobExecution.getJobInstance().getJobName(), jobExecution.getId(),
                archivoOrigen, null);

        return RepeatStatus.FINISHED;
    }
}
