package cl.duoc.bancoxyz.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.scope.context.ChunkContext;

import java.util.concurrent.atomic.AtomicLong;

/**
 * VIGILANTE DEL CHUNK: registra cada vez que un lote completo hace ROLLBACK.
 *
 * Recordatorio de por que importa: el chunk ES la transaccion. Con chunk=200,
 * cuando el escritor falla no se pierde una fila, se deshacen las 200 del lote.
 * Despues Spring Batch vuelve a intentarlo (politica de reintento) y, si el
 * fallo persiste y es omitible, entra el "chunk scanning": reprocesa el lote
 * de uno en uno para localizar al culpable. Un chunk fallido puede convertirse
 * en 200 mini-transacciones, y eso explica cualquier cifra rara de tiempo.
 *
 * Sin este listener el rollback no deja ningun rastro legible.
 *
 * LA CLAVE TECNICA: afterChunkError NO recibe la excepcion como parametro.
 * Spring Batch la deja guardada en el ChunkContext bajo la clave
 * ChunkListener.ROLLBACK_EXCEPTION_KEY. Si no se sabe eso, se acaba escribiendo
 * un log inutil del tipo "hubo un error en el chunk" sin decir cual.
 */
public class ChunkErrorListener implements ChunkListener {

    private static final Logger log = LoggerFactory.getLogger(ChunkErrorListener.class);

    private final AtomicLong chunksFallidos = new AtomicLong();

    @Override
    public void afterChunkError(ChunkContext chunkContext) {
        long n = chunksFallidos.incrementAndGet();

        // Aqui esta la excepcion que provoco el rollback del lote.
        Object causa = chunkContext.getAttribute(ChunkListener.ROLLBACK_EXCEPTION_KEY);

        String step = chunkContext.getStepContext().getStepExecution().getStepName();
        long escritas = chunkContext.getStepContext().getStepExecution().getWriteCount();

        if (causa instanceof Throwable t) {
            log.error("CHUNK ROLLBACK | step={} | hilo={} | chunks fallidos aqui={} | "
                            + "escritas hasta ahora={} | causa={}: {}",
                    step, Thread.currentThread().getName(), n, escritas,
                    t.getClass().getName(), t.getMessage());
        } else {
            // Puede pasar si el fallo ocurre fuera del alcance del atributo.
            log.error("CHUNK ROLLBACK | step={} | hilo={} | chunks fallidos aqui={} | "
                            + "sin excepcion en ROLLBACK_EXCEPTION_KEY",
                    step, Thread.currentThread().getName(), n);
        }
    }

    /** Para afirmarlo en un test. */
    public long getChunksFallidos() {
        return chunksFallidos.get();
    }
}
