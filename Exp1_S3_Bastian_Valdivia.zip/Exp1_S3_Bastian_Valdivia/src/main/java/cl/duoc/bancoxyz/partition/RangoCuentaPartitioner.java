package cl.duoc.bancoxyz.partition;

import org.springframework.batch.core.partition.support.PartitionNameProvider;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Reparte el trabajo del Job 2 POR RANGOS DE cuenta_id (101..150), no por
 * rangos de linea.
 *
 * ------------------------------------------------------------------------
 * POR QUE UNA ESTRATEGIA DISTINTA A LA DEL JOB 1
 * ------------------------------------------------------------------------
 * El Job 1 usa LineRangePartitioner: "tu lees de la linea 251 a la 500". Es lo
 * mas simple y reparte perfectamente equilibrado, pero reparte por POSICION
 * FISICA, que es un criterio sin ningun significado de negocio.
 *
 * El Job 2 consolida saldos POR CUENTA, y eso cambia lo que interesa: aqui la
 * unidad natural de trabajo es la cuenta, no la linea. Repartir por cuenta_id
 * garantiza que TODAS las filas de la cuenta 137 las procesa la MISMA
 * particion. Ventajas concretas:
 *
 *   - Las dos copias de una fila duplicada caen siempre en la misma particion,
 *     asi que el rechazo por DUPLICADO se atribuye a una particion predecible
 *     y la evidencia es reproducible entre corridas.
 *   - Es el reparto que se usaria de verdad si la consolidacion se hiciera en
 *     memoria por particion en vez de con un GROUP BY en SQL.
 *   - Como estrategia, es la que se traduce sin cambios a una tabla
 *     ("WHERE cuenta_id BETWEEN 101 AND 110"), que es el caso habitual.
 *
 * Precio a pagar, y hay que decirlo: el reparto queda DESEQUILIBRADO. Las
 * cuentas no tienen el mismo numero de filas, asi que las particiones salen de
 * tamanos distintos en vez de 200 exactas. Se ve en los tiempos por particion
 * y es material de analisis del criterio 4.
 *
 * ------------------------------------------------------------------------
 * EL INVARIANTE QUE PROTEGE LA REGLA DE ORO
 * ------------------------------------------------------------------------
 * "Entrada = negocio + rechazos. Ninguna fila desaparece en silencio."
 *
 * Un particionado por rango tiene un agujero mortal: las filas que NO caen en
 * ningun rango. Si el archivo trae un cuenta_id 999, o vacio, o 'abc', y cada
 * particion solo reclama "lo suyo", esa fila NO LA LEE NADIE. El job termina
 * COMPLETED, la cuadratura da 999 en vez de 1000, y no hay ni un error en el
 * log que explique por que.
 *
 * La regla que lo cierra, y que implementa reclama():
 *
 *   - la PRIMERA particion reclama ademas todo lo que este POR DEBAJO del rango
 *   - la ULTIMA particion reclama ademas todo lo que este POR ENCIMA del rango,
 *     y tambien todo lo ILEGIBLE (vacio, no numerico)
 *
 * Asi CADA fila tiene EXACTAMENTE UN reclamante: ni cero (se perderia) ni dos
 * (se duplicaria). RangoCuentaPartitionerTest afirma justo eso, caso por caso.
 * Es el test mas importante del Job 2.
 *
 * ------------------------------------------------------------------------
 * POR QUE IMPLEMENTA TAMBIEN PartitionNameProvider
 * ------------------------------------------------------------------------
 * Sin esta interfaz, al REINICIAR un job fallido, SimpleStepExecutionSplitter
 * vuelve a llamar a partition() para averiguar los nombres, es decir,
 * RECALCULA el reparto. Si algo hubiera cambiado, los nombres no casarian con
 * las StepExecution ya guardadas y el reinicio se ensuciaria. Con
 * PartitionNameProvider, Spring pregunta los nombres por separado y reutiliza
 * el reparto anterior (escenario E14 del plan).
 *
 * OJO: los dos metodos DEBEN estar de acuerdo. Spring llama a
 * getPartitionNames(gridSize) y luego busca ESAS claves exactas en el mapa que
 * devuelve partition(gridSize); cualquier discrepancia en el numero o en el
 * nombre da un fallo en tiempo de EJECUCION, no de compilacion. Por eso los dos
 * salen del mismo metodo privado tramos(): es imposible que difieran.
 */
public class RangoCuentaPartitioner implements Partitioner, PartitionNameProvider {

    private final int cuentaMin;
    private final int cuentaMax;

    public RangoCuentaPartitioner(int cuentaMin, int cuentaMax) {
        this.cuentaMin = cuentaMin;
        this.cuentaMax = cuentaMax;
    }

    /** Un tramo contiguo de cuentas, con su nombre y su posicion en el reparto. */
    private record Tramo(String nombre, int desde, int hasta, boolean primera, boolean ultima) {
    }

    /**
     * Calcula el reparto UNA sola vez. Lo usan tanto partition() como
     * getPartitionNames(), que es lo que garantiza que ambos coincidan.
     */
    private List<Tramo> tramos(int gridSize) {
        int n = Math.max(1, gridSize);
        int totalCuentas = cuentaMax - cuentaMin + 1;
        // Nunca mas particiones que cuentas: una particion vacia no aportaria
        // nada y solo ensuciaria los metadatos.
        n = Math.min(n, Math.max(1, totalCuentas));

        // Techo de la division: preferimos que la ultima particion lleve menos
        // antes que dejar cuentas fuera del reparto.
        int tamano = (int) Math.ceil((double) totalCuentas / n);

        List<Tramo> lista = new ArrayList<>();
        int numero = 0;
        for (int desde = cuentaMin; desde <= cuentaMax; desde += tamano) {
            int hasta = Math.min(desde + tamano - 1, cuentaMax);
            lista.add(new Tramo("partition" + numero, desde, hasta, false, false));
            numero++;
        }

        // Se marcan la primera y la ultima DESPUES de conocer el tamano real de
        // la lista: son las que absorben lo que se sale del rango.
        int ultimo = lista.size() - 1;
        Tramo p = lista.get(0);
        lista.set(0, new Tramo(p.nombre(), p.desde(), p.hasta(), true, ultimo == 0));
        Tramo u = lista.get(ultimo);
        lista.set(ultimo, new Tramo(u.nombre(), u.desde(), u.hasta(), ultimo == 0, true));
        return lista;
    }

    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {
        // LinkedHashMap y no HashMap: conserva el orden de insercion, asi los
        // logs salen partition0, partition1... y no en orden aleatorio.
        Map<String, ExecutionContext> particiones = new LinkedHashMap<>();

        for (Tramo t : tramos(gridSize)) {
            ExecutionContext ctx = new ExecutionContext();
            ctx.putInt("cuentaMin", t.desde());
            ctx.putInt("cuentaMax", t.hasta());
            // Las dos banderas que cierran el agujero de las filas huerfanas.
            // Se guardan como String y no como boolean porque el ExecutionContext
            // solo tiene putString/putInt/putLong/putDouble; el reader las
            // reconvierte con Boolean.parseBoolean().
            ctx.putString("esPrimera", String.valueOf(t.primera()));
            ctx.putString("esUltima", String.valueOf(t.ultima()));
            ctx.putString("partitionName", t.nombre());
            particiones.put(t.nombre(), ctx);
        }
        return particiones;
    }

    @Override
    public Collection<String> getPartitionNames(int gridSize) {
        return tramos(gridSize).stream().map(Tramo::nombre).toList();
    }

    /**
     * Decide si le toca a esta particion la fila con este cuenta_id CRUDO.
     *
     * Es estatico y publico a proposito: lo usa FiltroRangoCuentaReader en
     * tiempo de ejecucion y lo verifica el test caso por caso. Que la regla de
     * reparto y la regla de filtrado sean LITERALMENTE LA MISMA FUNCION es lo
     * que impide que se desincronicen.
     *
     * @param crudo      el cuenta_id tal cual viene del CSV (puede ser vacio o basura)
     * @param cuentaMin  primera cuenta de este tramo
     * @param cuentaMax  ultima cuenta de este tramo
     * @param esPrimera  este tramo absorbe ademas todo lo que este por debajo
     * @param esUltima   este tramo absorbe ademas lo que este por encima Y lo ilegible
     */
    public static boolean reclama(String crudo, int cuentaMin, int cuentaMax,
                                  boolean esPrimera, boolean esUltima) {
        Integer id = aEntero(crudo);

        if (id == null) {
            // Vacio o no numerico: se lo queda la ultima. NO se descarta jamas.
            // Llegara al processor, que decidira si es rechazo o no; lo que no
            // puede pasar es que no la lea nadie.
            return esUltima;
        }
        if (id < cuentaMin) {
            return esPrimera;   // por debajo del rango global -> la primera
        }
        if (id > cuentaMax) {
            return esUltima;    // por encima del rango global -> la ultima
        }
        return true;            // dentro de este tramo
    }

    /** Devuelve null si el texto no es un entero. Null significa "ilegible". */
    private static Integer aEntero(String crudo) {
        if (crudo == null || crudo.isBlank()) {
            return null;
        }
        try {
            return Integer.valueOf(crudo.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
