package cl.duoc.bancoxyz.tasklet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.Map;

/**
 * LA CONSOLIDACION del Job 3: convierte las 952 filas de movimiento_anual en las
 * 20 filas de estado_cuenta_anual (una por cuenta y anio).
 *
 * ------------------------------------------------------------------------
 * POR QUE UN TASKLET CON SQL Y NO UN STEP DE CHUNK
 * ------------------------------------------------------------------------
 * Agregar es exactamente lo que una base de datos relacional sabe hacer mejor.
 * Hacerlo con un chunk significaria traerse 952 filas a memoria, agruparlas en
 * Java y devolver 20: mas codigo, mas memoria y mas lento, para obtener el
 * mismo resultado que un GROUP BY.
 *
 * Y hay una razon de correccion, no solo de eficiencia: al ser UNA SOLA
 * sentencia, las 20 filas se calculan y se escriben de golpe, dentro de la
 * transaccion del step. No existe un estado intermedio en el que la tabla tenga
 * 8 cuentas consolidadas y 12 a medias.
 *
 * ------------------------------------------------------------------------
 * POR QUE EL WHERE POR job_execution_id ES IMPRESCINDIBLE
 * ------------------------------------------------------------------------
 * Sin el, el GROUP BY agregaria tambien los movimientos de corridas anteriores
 * que aun estuvieran en la tabla. Aqui el paso de preparacion ya la vacia, asi
 * que hoy seria equivalente... pero depender de eso significaria que quitar el
 * DELETE de otro fichero corromperia silenciosamente los totales de este. Cada
 * sentencia declara de que datos habla.
 *
 * ------------------------------------------------------------------------
 * LA TRAMPA ASIMETRICA DE LAS COLUMNAS GENERADAS
 * ------------------------------------------------------------------------
 * En banco.movimiento_anual, anio y monto_con_signo son GENERATED ALWAYS AS
 * ... STORED y NO pueden ir en la lista de columnas de un INSERT (por eso
 * MovimientoAnual ni siquiera tiene esos campos).
 *
 * PERO AQUI ES AL REVES. En banco.estado_cuenta_anual, anio es una columna
 * NORMAL y TIENE que ir en el INSERT. Aplicar "la regla de las generadas" a
 * ciegas en esta tabla romperia el tasklet con un NOT NULL violado.
 *
 * Fijate ademas en el uso que se hace de ellas en el SELECT: m.anio y
 * m.monto_con_signo se LEEN sin problema. La prohibicion es escribirlas, no
 * consultarlas; de hecho saldo_neto = SUM(m.monto_con_signo) se apoya justo en
 * una columna generada, que es lo que garantiza que el saldo y los movimientos
 * no puedan discrepar.
 *
 * ------------------------------------------------------------------------
 * POR QUE ON CONFLICT DO UPDATE Y NO UN INSERT A SECAS
 * ------------------------------------------------------------------------
 * La clave primaria es (cuenta_id, anio). Al relanzar el job, esas 20 claves ya
 * existirian y un INSERT normal fallaria. Con ON CONFLICT DO UPDATE la sentencia
 * es idempotente por si misma, independientemente de la limpieza previa.
 *
 * ATENCION AL DETALLE MAS FACIL DE PASAR POR ALTO: el SET incluye
 * job_execution_id = EXCLUDED.job_execution_id. Si se omitiera, al actualizar
 * una fila existente esta CONSERVARIA el id de la ejecucion vieja; el lector
 * del step de exportacion, que filtra por el job_execution_id de la corrida
 * actual, no encontraria ninguna fila y el informe saldria con cabecera y pie
 * pero SIN datos. El job terminaria COMPLETED entregando un informe vacio.
 *
 * No puede haber "cardinality violation" (dos filas de origen chocando contra
 * la misma fila destino) porque el GROUP BY ya garantiza que cada par
 * (cuenta_id, anio) aparece una sola vez en el SELECT.
 */
public class GenerarEstadosCuentaTasklet implements Tasklet {

    private static final Logger log = LoggerFactory.getLogger(GenerarEstadosCuentaTasklet.class);

    /** Clave con la que se deja el numero de filas en el ExecutionContext del step. */
    public static final String CLAVE_FILAS = "estadosCuentaGenerados";

    /**
     * El SQL es literalmente el de docs/plan-maestro.md seccion 9. Se transcribe
     * sin "mejoras" a proposito: ese documento es la especificacion, y una
     * variacion silenciosa aqui obligaria a revisar los dos textos cada vez que
     * alguien quisiera saber que se consolida.
     *
     * COUNT(*) FILTER (WHERE ...) es sintaxis estandar de PostgreSQL: cuenta
     * solo las filas que cumplen la condicion, dentro del mismo GROUP BY. Es lo
     * que permite sacar los 4 contadores por tipo y los 4 totales en UNA
     * pasada, en lugar de cuatro subconsultas correlacionadas.
     *
     * n_anomalias = COUNT(*) FILTER (WHERE m.estado <> 'VALIDA') cuenta FILAS
     * con algun problema (428 esperadas), no instancias de anomalia (486). Son
     * dos preguntas distintas y esta columna responde la primera; la segunda se
     * responde con UNNEST sobre movimiento_anual.anomalias.
     *
     * COALESCE(..., 0) en los totales: SUM() sobre cero filas devuelve NULL, no
     * 0. Sin el COALESCE, una cuenta sin ningun PAGO tendria total_pagos NULL,
     * y la restriccion ck_eca_saldo -que compara saldo_neto con una resta de los
     * cuatro totales- se evaluaria a NULL. Una restriccion CHECK que da NULL se
     * considera SATISFECHA, asi que la fila entraria con el saldo descuadrado y
     * sin avisar. Es el fallo silencioso mas peligroso de esta sentencia.
     */
    private static final String SQL = """
            INSERT INTO banco.estado_cuenta_anual
                  (cuenta_id, anio, n_movimientos, n_depositos, n_retiros, n_pagos, n_compras,
                   total_depositos, total_retiros, total_pagos, total_compras, saldo_neto,
                   n_anomalias, primera_fecha, ultima_fecha, job_execution_id, generado_en)
            SELECT m.cuenta_id, m.anio, COUNT(*),
                   COUNT(*) FILTER (WHERE m.transaccion='DEPOSITO'),
                   COUNT(*) FILTER (WHERE m.transaccion='RETIRO'),
                   COUNT(*) FILTER (WHERE m.transaccion='PAGO'),
                   COUNT(*) FILTER (WHERE m.transaccion='COMPRA'),
                   COALESCE(SUM(m.monto) FILTER (WHERE m.transaccion='DEPOSITO'), 0),
                   COALESCE(SUM(m.monto) FILTER (WHERE m.transaccion='RETIRO'),   0),
                   COALESCE(SUM(m.monto) FILTER (WHERE m.transaccion='PAGO'),     0),
                   COALESCE(SUM(m.monto) FILTER (WHERE m.transaccion='COMPRA'),   0),
                   SUM(m.monto_con_signo),
                   COUNT(*) FILTER (WHERE m.estado <> 'VALIDA'),
                   MIN(m.fecha), MAX(m.fecha), :jobExecutionId, now()
              FROM banco.movimiento_anual m
             WHERE m.job_execution_id = :jobExecutionId
             GROUP BY m.cuenta_id, m.anio
            ON CONFLICT (cuenta_id, anio) DO UPDATE
               SET n_movimientos = EXCLUDED.n_movimientos, n_depositos = EXCLUDED.n_depositos,
                   n_retiros = EXCLUDED.n_retiros, n_pagos = EXCLUDED.n_pagos,
                   n_compras = EXCLUDED.n_compras,
                   total_depositos = EXCLUDED.total_depositos,
                   total_retiros = EXCLUDED.total_retiros,
                   total_pagos = EXCLUDED.total_pagos,
                   total_compras = EXCLUDED.total_compras,
                   saldo_neto = EXCLUDED.saldo_neto, n_anomalias = EXCLUDED.n_anomalias,
                   primera_fecha = EXCLUDED.primera_fecha, ultima_fecha = EXCLUDED.ultima_fecha,
                   job_execution_id = EXCLUDED.job_execution_id, generado_en = now()
            """;

    private final NamedParameterJdbcTemplate jdbc;

    public GenerarEstadosCuentaTasklet(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // El id de ESTA ejecucion. Es lo que ata la consolidacion a los
        // movimientos que acaba de cargar el step anterior, y no a los de otra
        // corrida. NamedParameterJdbcTemplate (y no el JdbcTemplate normal)
        // porque asi el mismo :jobExecutionId se liga en los dos sitios donde
        // aparece; con los "?" posicionales habria que pasarlo dos veces y en
        // el orden correcto, que es justo el tipo de detalle que se rompe al
        // editar el SQL.
        Long jobExecutionId = chunkContext.getStepContext().getStepExecution().getJobExecutionId();

        int filas = jdbc.update(SQL, new MapSqlParameterSource(
                Map.of("jobExecutionId", jobExecutionId)));

        // Se deja el numero en el ExecutionContext del STEP para que quede en
        // los metadatos de Spring Batch (BATCH_STEP_EXECUTION_CONTEXT) y pueda
        // consultarse despues sin volver a la tabla de negocio.
        chunkContext.getStepContext().getStepExecution()
                .getExecutionContext().putInt(CLAVE_FILAS, filas);

        log.info("Consolidacion: {} filas escritas en banco.estado_cuenta_anual "
                + "(job_execution_id={})", filas, jobExecutionId);

        return RepeatStatus.FINISHED;
    }
}
