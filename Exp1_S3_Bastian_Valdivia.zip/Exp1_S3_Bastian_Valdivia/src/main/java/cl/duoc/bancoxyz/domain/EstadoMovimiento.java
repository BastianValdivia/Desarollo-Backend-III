package cl.duoc.bancoxyz.domain;

/**
 * Los 5 estados EXCLUYENTES que puede tener una fila de banco.movimiento_anual.
 *
 * ------------------------------------------------------------------------
 * POR QUE UN ENUM NUEVO Y NO AMPLIAR EstadoRegistro (el del Job 1)
 * ------------------------------------------------------------------------
 * Anadir valores a EstadoRegistro habria sido una linea de codigo, pero
 * significaria TOCAR un fichero del Job 1 que ya esta verificado y entregado.
 * Con un enum aparte, la afirmacion "el Job 1 no se ha modificado" es
 * demostrable con un `git diff` en vez de con una re-ejecucion. En un trabajo
 * cuyo criterio numero uno es "no romper lo que funciona", esa separacion vale
 * mas que el ahorro de un fichero.
 *
 * Ademas los dominios NO son el mismo: una transaccion puede ser
 * ANOMALA_TIPO_DESCONOCIDO, un movimiento anual no (aqui un tipo desconocido es
 * un RECHAZO, no una anomalia, porque ck_mov_tipo solo admite los 4 tipos
 * validos). Compartir un enum entre dos dominios distintos habria permitido
 * escribir un estado que la restriccion ck_mov_estado rechazaria en el INSERT.
 *
 * ------------------------------------------------------------------------
 * EL ORDEN DE DECLARACION ES LA REGLA DE PRECEDENCIA
 * ------------------------------------------------------------------------
 * Los valores estan escritos de MAS grave a MENOS grave, y ese orden NO es
 * decorativo: MovimientoAnualProcessor recorre este enum de arriba abajo y se
 * queda con el primero que aplique. La documentacion de la regla y su
 * implementacion son el mismo dato, asi que no pueden desincronizarse.
 *
 * SIGNO_CONTRADICTORIO va POR ENCIMA de MONTO_NEGATIVO a proposito, y es la
 * decision mas delicada del Job 3. Un "deposito" con monto -100 es a la vez un
 * monto negativo y una contradiccion de signo; si ganara MONTO_NEGATIVO, la
 * anomalia de signo no se registraria NUNCA (saldria 0) y el reparto seria
 * 254/0 en vez del 173/81 que exige el contrato. Verificado simulando las
 * reglas sobre el CSV real: con este orden salen exactamente
 * 524 / 173 / 162 / 81 / 12 = 952.
 *
 * OJO: estos 5 nombres deben coincidir LETRA POR LETRA con la restriccion
 * ck_mov_estado de schema-negocio.sql. El esquema real NO admite
 * 'ANOMALA_MULTIPLE' aunque plan-maestro.md lo mencione: el estado es siempre
 * uno y solo uno, y la multiplicidad se expresa en la columna 'anomalias'.
 */
public enum EstadoMovimiento {

    /** Deposito con monto negativo: el signo del tipo contradice el del monto. */
    ANOMALA_SIGNO_CONTRADICTORIO,

    /** Monto negativo en un tipo que ya resta (RETIRO, PAGO, COMPRA). */
    ANOMALA_MONTO_NEGATIVO,

    /** Movimiento de importe 0: no mueve saldo, pero ocupa una fila. */
    ANOMALA_MONTO_CERO,

    /** Descripcion en blanco; se rellena con 'SIN DESCRIPCION'. */
    ANOMALA_DESCRIPCION_AUSENTE,

    /** Ninguna anomalia. Es el ultimo porque es el caso por defecto. */
    VALIDA
}
