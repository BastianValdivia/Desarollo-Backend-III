package cl.duoc.bancoxyz.support;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.stereotype.Component;

/**
 * FUENTE UNICA DEL VALOR "periodo" (el mes que se esta liquidando, 'yyyy-MM').
 *
 * ------------------------------------------------------------------------
 * POR QUE ESTO MERECE UNA CLASE ENTERA PARA DEVOLVER UN STRING
 * ------------------------------------------------------------------------
 * El periodo lo necesitan TRES sitios del Job 2, y los tres tienen que estar
 * de acuerdo o la idempotencia se rompe EN SILENCIO:
 *
 *   1. LimpiezaInteresesTasklet   -> DELETE ... WHERE periodo = ?
 *   2. InteresProcessor           -> sella cada fila con ese periodo
 *   3. ConsolidarSaldosTasklet    -> agrega WHERE periodo = ? y lo compara
 *                                    contra banco.cuenta.periodo_aplicado
 *
 * Imagina que cada uno lo resolviera por su cuenta y uno de ellos usara un
 * valor distinto (un @Value con otro default, o peor, LocalDate.now() que
 * cambia de mes solo). Entonces el limpiador borraria el periodo A, el
 * processor insertaria el periodo B, y como uq_interes_posicion incluye el
 * periodo, NO habria choque de claves: el job terminaria COMPLETED, la tabla
 * tendria 1568 filas en vez de 784 y la guarda de idempotencia de
 * ConsolidarSaldos nunca se activaria. Nadie veria un error. Ese es
 * exactamente el tipo de fallo que este proyecto intenta hacer imposible.
 *
 * Centralizarlo aqui convierte "los tres tienen que coincidir" en "solo hay
 * un sitio donde puede estar mal". Es la misma idea que ControlCargaDao en el
 * Job 1: si un numero lo consumen varios, se calcula UNA vez.
 *
 * ------------------------------------------------------------------------
 * POR QUE EL DEFECTO ES FIJO Y NO EL MES ACTUAL
 * ------------------------------------------------------------------------
 * La tentacion es devolver YearMonth.now(). Seria un error de diseno: la
 * prueba de idempotencia (escenario E15) consiste en lanzar el job DOS VECES
 * con el mismo periodo y comprobar que el interes no se reaplica. Con un
 * defecto que cambia solo, las dos corridas usarian periodos distintos, la
 * segunda insertaria 784 filas nuevas y aplicaria el interes otra vez... y la
 * prueba pasaria igualmente porque nada choca. Una prueba que no puede fallar
 * no demuestra nada. Con un valor FIJO, dos corridas seguidas son de verdad
 * la misma liquidacion repetida.
 */
@Component
public class PeriodoIntereses {

    /** Nombre del JobParameter que permite liquidar otro mes: --periodo=2024-02 */
    public static final String PARAMETRO = "periodo";

    /** Periodo por defecto. FIJO a proposito (ver el comentario de la clase). */
    public static final String POR_DEFECTO = "2024-01";

    /**
     * LA UNICA REGLA, y todo lo demas delega aqui: si viene un valor utilizable
     * se usa; si no, el defecto fijo.
     */
    public String resolver(String crudo) {
        return (crudo == null || crudo.isBlank()) ? POR_DEFECTO : crudo.trim();
    }

    /** Resuelve el periodo a partir de los JobParameters. */
    public String resolver(JobParameters parametros) {
        return resolver(parametros == null ? null : parametros.getString(PARAMETRO));
    }

    /**
     * Version para los Tasklet, que no reciben JobParameters sino un
     * ChunkContext. Delega en la de arriba para que la regla siga viviendo en
     * UN solo metodo: si manana el defecto cambia, cambia para todos.
     */
    public String resolver(ChunkContext contexto) {
        return resolver(contexto.getStepContext().getStepExecution()
                .getJobExecution().getJobParameters());
    }
}
