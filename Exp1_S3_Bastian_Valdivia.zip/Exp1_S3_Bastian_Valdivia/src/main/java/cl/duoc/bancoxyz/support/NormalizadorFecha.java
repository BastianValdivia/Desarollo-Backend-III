package cl.duoc.bancoxyz.support;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Convierte las fechas del CSV a LocalDate, probando los 4 formatos que aparecen mezclados.
 *
 * Medido sobre los datos reales de transacciones.csv:
 *   yyyy-MM-dd  294 filas (de las cuales 55 son "2024-13-01", mes 13 = IRRECUPERABLE)
 *   dd-MM-yyyy  250
 *   dd/MM/yyyy  234
 *   yyyy/MM/dd  222
 *
 * MUY IMPORTANTE: en los formatos con barra/guion el primer número es el DÍA.
 * Lo comprobamos: hay ~300 filas con el primer componente > 12 ("24-07-2024")
 * y CERO con el segundo > 12. Si asumieras MM/dd/yyyy romperías 300 filas.
 *
 * Usamos ResolverStyle.STRICT con patrón "uuuu" (no "yyyy") para que fechas
 * imposibles como 2024-02-30 se rechacen en vez de corregirse en silencio a 2024-02-29.
 *
 * @Component = "Spring, crea una instancia de esto y tenla disponible para inyectar".
 */
@Component
public class NormalizadorFecha {

    /** Guarda el nombre del patrón junto al formateador, para poder reportar cuál se usó. */
    private static final Map<String, DateTimeFormatter> PATRONES = new LinkedHashMap<>();

    static {
        PATRONES.put("yyyy-MM-dd", DateTimeFormatter.ofPattern("uuuu-MM-dd").withResolverStyle(ResolverStyle.STRICT));
        PATRONES.put("dd-MM-yyyy", DateTimeFormatter.ofPattern("dd-MM-uuuu").withResolverStyle(ResolverStyle.STRICT));
        PATRONES.put("dd/MM/yyyy", DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT));
        PATRONES.put("yyyy/MM/dd", DateTimeFormatter.ofPattern("uuuu/MM/dd").withResolverStyle(ResolverStyle.STRICT));
    }

    /**
     * Devuelve un Optional: "puede que haya resultado, puede que no".
     * Es el equivalente a devolver None en Python, pero el compilador te obliga
     * a comprobarlo, así que no se te olvida.
     */
    public Optional<FechaNormalizada> normalizar(String crudo) {
        if (crudo == null || crudo.isBlank()) {
            return Optional.empty();
        }
        String limpio = crudo.trim();
        for (Map.Entry<String, DateTimeFormatter> e : PATRONES.entrySet()) {
            try {
                LocalDate fecha = LocalDate.parse(limpio, e.getValue());
                return Optional.of(new FechaNormalizada(fecha, e.getKey()));
            } catch (DateTimeParseException ignorada) {
                // este patrón no era; probamos el siguiente
            }
        }
        return Optional.empty();   // ningún patrón sirvió -> irrecuperable
    }

    /** La fecha ya convertida, junto al nombre del patrón con que se logró leer. */
    public record FechaNormalizada(LocalDate fecha, String patron) {
    }
}
