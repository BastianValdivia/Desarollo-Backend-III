package cl.duoc.bancoxyz.support;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.TransientDataAccessResourceException;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * INYECTOR DE FALLOS SIMULADOS: la forma REPRODUCIBLE de demostrar la
 * tolerancia a fallos sin tener que apagar Docker a mano en el momento justo.
 *
 * Es un DECORADOR (patron Decorator): implementa la misma interfaz que el
 * escritor real, lo envuelve, y antes de delegar decide si lanza una excepcion
 * fingida. Si el escenario es NINGUNO no hace absolutamente nada: el coste en
 * la ejecucion normal es una comparacion de cadenas por chunk.
 *
 * Analogia con SQL: es como un TRIGGER BEFORE INSERT que solo se activa cuando
 * una variable de sesion esta puesta; el resto del tiempo la tabla se comporta
 * exactamente igual.
 *
 * --------------------------------------------------------------------------
 * POR QUE UN FALLO POR PARTICION Y NO UN CONTADOR GLOBAL
 * --------------------------------------------------------------------------
 * Este bean se declara @StepScope, asi que hay UNA instancia por particion (por
 * StepExecution). Cada una tiene su propio "yaFalle", y por tanto CADA particion
 * falla exactamente una vez. Con un contador compartido entre los 4 hilos, la
 * particion que llegase primero se comeria el presupuesto de fallos y las otras
 * tres no reintentarian nunca: la evidencia saldria distinta en cada corrida.
 * Una demostracion que no se puede repetir no es una demostracion.
 *
 * --------------------------------------------------------------------------
 * POR QUE FALLA UNA SOLA VEZ (y no dos)
 * --------------------------------------------------------------------------
 * La politica permite 3 intentos TOTALES. Fallar 2 veces y acertar a la tercera
 * deja la demostracion justo en el limite: cualquier diferencia de un intento
 * en como se cuenta el primero convierte el exito en un step FAILED. Fallando
 * una vez hay margen, y la evidencia (un reintento en el log + un rollback de
 * chunk + los 1000 registros intactos) es exactamente la misma.
 *
 * Para demostrar el caso contrario -que agotar los reintentos SI mata el step-
 * existe el escenario BD_CAIDA_PERMANENTE, que falla siempre.
 */
public class InyectorFallosWriter<T> implements ItemWriter<T> {

    private static final Logger log = LoggerFactory.getLogger(InyectorFallosWriter.class);

    // ---- Catalogo de escenarios ------------------------------------------
    /** Comportamiento normal: no se inyecta nada. Es el valor por defecto. */
    public static final String NINGUNO = "NINGUNO";
    /** Fallo transitorio de la base: se reintenta y se recupera. */
    public static final String BD_TRANSITORIA = "BD_TRANSITORIA";
    /** Contencion de bloqueo (deadlock / cerrojo ocupado): se reintenta. */
    public static final String BLOQUEO = "BLOQUEO";
    /** La base no vuelve: se agotan los 3 intentos y el step FALLA a proposito. */
    public static final String BD_CAIDA_PERMANENTE = "BD_CAIDA_PERMANENTE";
    /** Violacion de integridad: ni se reintenta ni se omite. El step FALLA. */
    public static final String ESCRITURA_FATAL = "ESCRITURA_FATAL";

    private final ItemWriter<? super T> delegado;
    private final String escenario;
    private final String particion;

    /**
     * compareAndSet garantiza que, incluso si dos hilos entrasen a la vez en la
     * misma instancia, solo uno lanzaria el fallo. No deberia ocurrir con
     * @StepScope, pero un inyector de fallos que introduce fallos propios seria
     * una ironia cara de depurar.
     */
    private final AtomicBoolean yaFalle = new AtomicBoolean(false);

    public InyectorFallosWriter(ItemWriter<? super T> delegado, String escenario, String particion) {
        this.delegado = delegado;
        this.escenario = escenario == null || escenario.isBlank() ? NINGUNO : escenario.trim().toUpperCase();
        this.particion = particion;
    }

    @Override
    public void write(Chunk<? extends T> chunk) throws Exception {
        if (!NINGUNO.equals(escenario)) {
            inyectar(chunk.size());
        }
        // Si la excepcion se lanza ARRIBA, el escritor real ni se entera: no se
        // escribe nada, y al reintentar el chunk se escribe una sola vez. Si se
        // inyectara DESPUES de delegar, el reintento insertaria los mismos ids
        // otra vez y el fallo simulado se convertiria en corrupcion real.
        delegado.write(chunk);
    }

    private void inyectar(int filasDelChunk) {
        switch (escenario) {
            case BD_CAIDA_PERMANENTE -> {
                log.warn("FALLO SIMULADO [{}] particion={} chunk={} filas -> siempre falla, "
                        + "los 3 intentos se agotaran", escenario, particion, filasDelChunk);
                throw new TransientDataAccessResourceException(
                        "FALLO SIMULADO: la base de datos no responde (escenario " + escenario + ")");
            }
            case ESCRITURA_FATAL -> {
                // Solo el primer chunk, para que el mensaje de fallo sea legible.
                if (yaFalle.compareAndSet(false, true)) {
                    log.warn("FALLO SIMULADO [{}] particion={} -> NO es reintentable ni omitible",
                            escenario, particion);
                    throw new DataIntegrityViolationException(
                            "FALLO SIMULADO: violacion de integridad al escribir (escenario " + escenario + ")");
                }
            }
            case BD_TRANSITORIA -> {
                if (yaFalle.compareAndSet(false, true)) {
                    log.warn("FALLO SIMULADO [{}] particion={} chunk={} filas -> se espera 1 reintento",
                            escenario, particion, filasDelChunk);
                    throw new TransientDataAccessResourceException(
                            "FALLO SIMULADO: conexion perdida con la base (escenario " + escenario + ")");
                }
            }
            case BLOQUEO -> {
                if (yaFalle.compareAndSet(false, true)) {
                    log.warn("FALLO SIMULADO [{}] particion={} chunk={} filas -> se espera 1 reintento",
                            escenario, particion, filasDelChunk);
                    throw new CannotAcquireLockException(
                            "FALLO SIMULADO: no se pudo obtener el cerrojo de la fila (escenario " + escenario + ")");
                }
            }
            default -> log.warn("Escenario de fallo desconocido '{}': no se inyecta nada. "
                    + "Validos: {}, {}, {}, {}, {}", escenario,
                    NINGUNO, BD_TRANSITORIA, BLOQUEO, BD_CAIDA_PERMANENTE, ESCRITURA_FATAL);
        }
    }
}
