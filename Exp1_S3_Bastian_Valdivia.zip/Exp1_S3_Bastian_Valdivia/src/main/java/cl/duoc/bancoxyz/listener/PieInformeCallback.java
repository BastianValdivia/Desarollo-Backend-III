package cl.duoc.bancoxyz.listener;

import org.springframework.batch.item.file.FlatFileFooterCallback;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Escribe el PIE del informe: los totales de la ejecucion.
 *
 * ------------------------------------------------------------------------
 * ES LO QUE CONVIERTE UN VOLCADO DE TABLA EN UN INFORME
 * ------------------------------------------------------------------------
 * Las 20 filas de datos ya estaban en la base; exportarlas a un fichero no
 * anade informacion. Lo que el enunciado pide -un "informe detallado para
 * auditorias"- necesita ademas los numeros que permiten VALIDAR el fichero sin
 * abrir la base: cuantas filas entraron, cuantas se rechazaron, que suman, y
 * como se reparten por estado.
 *
 * Puesto de otro modo: el cuerpo del informe dice QUE paso con cada cuenta; el
 * pie dice si se puede confiar en el cuerpo. La linea de cuadratura
 * (952 + 48 = 1000) es la Regla de Oro impresa dentro del propio entregable.
 *
 * ------------------------------------------------------------------------
 * FlatFileFooterCallback: cuando se ejecuta y por que importa
 * ------------------------------------------------------------------------
 * El writer lo invoca UNA vez, al CERRAR el fichero, despues de la ultima fila.
 * Esto tiene una consecuencia util: cuando este metodo corre, los movimientos y
 * el consolidado ya estan escritos y confirmados en la base, asi que las
 * consultas de aqui ven los datos definitivos de la corrida.
 *
 * ------------------------------------------------------------------------
 * POR QUE SE CONSULTA LA BASE Y NO SE VAN SUMANDO LAS FILAS EXPORTADAS
 * ------------------------------------------------------------------------
 * Seria mas barato llevar un acumulador mientras el writer escribe. Se hace por
 * SQL a proposito: asi el pie es una comprobacion INDEPENDIENTE del camino que
 * produjo el fichero. Si el reader del informe se dejara filas fuera, un
 * contador interno mentiria igual que el cuerpo -serian el mismo error contado
 * dos veces-, mientras que el SQL delataria la discrepancia.
 * Es el mismo principio por el que ControlCargaDao cuenta las filas de negocio
 * con un COUNT(*) y no se fia de lo que el writer dice haber escrito.
 */
public class PieInformeCallback implements FlatFileFooterCallback {

    private final JdbcTemplate jdbc;
    private final Long jobExecutionId;

    public PieInformeCallback(JdbcTemplate jdbc, Long jobExecutionId) {
        this.jdbc = jdbc;
        this.jobExecutionId = jobExecutionId;
    }

    @Override
    public void writeFooter(Writer writer) throws IOException {

        long movimientos = contar("SELECT COUNT(*) FROM banco.movimiento_anual");
        long rechazos = contar("SELECT COUNT(*) FROM banco.registro_rechazado"
                + " WHERE archivo_origen = 'cuentas_anuales.csv'");
        long cuentas = contar("SELECT COUNT(*) FROM banco.estado_cuenta_anual");

        BigDecimal saldoGlobal = jdbc.queryForObject(
                "SELECT COALESCE(SUM(saldo_neto), 0) FROM banco.estado_cuenta_anual",
                BigDecimal.class);

        // OJO: el pie NO empieza con salto de linea. El FlatFileItemWriter ya
        // escribe el separador de linea DESPUES del ultimo registro, asi que un
        // "\n" aqui dejaria una linea en blanco entre los datos y el resumen.
        writer.write("#");
        writer.write("\n# ---------------- RESUMEN DE LA EJECUCION ----------------");
        writer.write("\n# job_execution_id      : " + jobExecutionId);
        writer.write("\n# cuentas consolidadas  : " + cuentas);
        writer.write("\n# movimientos cargados  : " + movimientos);
        writer.write("\n# filas rechazadas      : " + rechazos);
        // LA REGLA DE ORO, impresa. Si esta linea no diera 1000, el informe
        // estaria denunciando su propia carga.
        writer.write("\n# CUADRATURA            : " + movimientos + " + " + rechazos
                + " = " + (movimientos + rechazos) + " filas de entrada");
        writer.write("\n# saldo neto global     : " + saldoGlobal);

        // ---- reparto por estado -----------------------------------------
        // ORDER BY 2 DESC: el estado mas frecuente arriba. Es como se lee un
        // informe de calidad de datos, de lo mas comun a lo mas raro.
        writer.write("\n#");
        writer.write("\n# reparto de movimientos por estado:");
        List<Map<String, Object>> porEstado = jdbc.queryForList(
                "SELECT estado, COUNT(*) AS n FROM banco.movimiento_anual"
                        + " GROUP BY estado ORDER BY 2 DESC");
        for (Map<String, Object> fila : porEstado) {
            writer.write("\n#   " + pad(String.valueOf(fila.get("estado"))) + " " + fila.get("n"));
        }

        // ---- reparto de rechazos ----------------------------------------
        writer.write("\n#");
        writer.write("\n# reparto de rechazos por motivo y fase:");
        List<Map<String, Object>> porMotivo = jdbc.queryForList(
                "SELECT motivo, fase, COUNT(*) AS n FROM banco.registro_rechazado"
                        + " WHERE archivo_origen = 'cuentas_anuales.csv'"
                        + " GROUP BY motivo, fase ORDER BY 3 DESC");
        if (porMotivo.isEmpty()) {
            writer.write("\n#   (ninguno)");
        }
        for (Map<String, Object> fila : porMotivo) {
            writer.write("\n#   " + pad(fila.get("motivo") + " (" + fila.get("fase") + ")")
                    + " " + fila.get("n"));
        }

        writer.write("\n# --------------------------------------------------------");
    }

    /** Alinea la columna de numeros para que el pie se lea como una tabla. */
    private static String pad(String texto) {
        return String.format("%-34s", texto);
    }

    private long contar(String sql) {
        Long n = jdbc.queryForObject(sql, Long.class);
        return n == null ? 0L : n;
    }
}
