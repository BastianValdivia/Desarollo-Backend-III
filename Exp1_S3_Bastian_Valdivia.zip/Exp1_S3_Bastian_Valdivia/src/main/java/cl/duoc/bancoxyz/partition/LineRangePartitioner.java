package cl.duoc.bancoxyz.partition;

import cl.duoc.bancoxyz.support.ContadorFilasCsv;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.core.io.Resource;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Reparte UN archivo plano (CSV) en N rangos de lineas.
 *
 * Una tabla se parte facil: "WHERE id BETWEEN 1 AND 250". Un archivo plano no
 * tiene indices, solo se puede leer desde el principio. Asi que el reparto se
 * expresa con las dos propiedades que entiende FlatFileItemReader:
 *
 *   linesToSkip  = cabeceras + desplazamiento de esta particion
 *   maxItemCount = CUANTAS filas lee esta particion (es un CONTADOR, no un indice final)
 *
 * Con 1000 filas, 1 cabecera y gridSize=4 produce:
 *
 *   partition0 -> linesToSkip=1    maxItemCount=250   (filas 1..250)
 *   partition1 -> linesToSkip=251  maxItemCount=250   (filas 251..500)
 *   partition2 -> linesToSkip=501  maxItemCount=250   (filas 501..750)
 *   partition3 -> linesToSkip=751  maxItemCount=250   (filas 751..1000)
 *
 * COSTE HONESTO: cada particion reabre el fichero y lo lee desde el principio
 * descartando sus linesToSkip primeras lineas. Con 4 particiones el fichero se
 * lee 4 veces (coste O(n*p)). Para 1000 filas es irrelevante; para millones
 * habria que trocear el fichero y usar MultiResourcePartitioner.
 */
public class LineRangePartitioner implements Partitioner {

    private final Resource recurso;
    private final int lineasCabecera;

    public LineRangePartitioner(Resource recurso, int lineasCabecera) {
        this.recurso = recurso;
        this.lineasCabecera = lineasCabecera;
    }

    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {
        int totalFilas = contarFilasDeDatos();

        // ==============================================================
        // GUARDA: un fichero sin filas de datos es un ERROR, no un caso
        // limite que se despache devolviendo un mapa vacio.
        //
        // Con totalFilas == 0 el bucle de abajo NO ITERA y esta funcion
        // devolvia un Map vacio. Consecuencia en cadena: el PartitionStep no
        // lanza ningun worker y termina COMPLETED (no ha fallado nada, sencilla-
        // mente no hizo nada); la cuadratura no encuentra ninguna StepExecution
        // de worker; y el job declara EXITO habiendo cargado cero filas.
        //
        // El caso real que lo dispara no es exotico: basta con que el CSV se
        // trunque a la cabecera, o que se copie a medias, o que el volumen de
        // Docker monte un directorio vacio. Fallar aqui, en el sitio donde el
        // dato se puede diagnosticar de un vistazo, es infinitamente mejor que
        // un COMPLETED silencioso tres steps mas adelante.
        // ==============================================================
        if (totalFilas <= 0) {
            throw new IllegalStateException(
                    "El fichero " + recurso.getDescription() + " no tiene ninguna fila de datos"
                            + " (solo " + lineasCabecera + " linea(s) de cabecera). No se generan"
                            + " particiones: un job que no lee nada NO puede terminar COMPLETED.");
        }

        int n = Math.max(1, gridSize);
        // Techo de la division: con 1000 filas y 3 particiones da 334, 334 y 332.
        // Preferimos que sobre en la ultima antes que dejar filas fuera.
        int tamano = (int) Math.ceil((double) totalFilas / n);

        // LinkedHashMap y no HashMap: conserva el orden de insercion y hace que
        // los logs salgan partition0, partition1... en vez de en orden aleatorio.
        Map<String, ExecutionContext> particiones = new LinkedHashMap<>();
        int numero = 0;
        for (int inicio = 0; inicio < totalFilas; inicio += tamano) {
            int cuantas = Math.min(tamano, totalFilas - inicio);
            String nombre = "partition" + numero;

            ExecutionContext ctx = new ExecutionContext();
            // minValue/maxValue es la convencion oficial de Spring Batch
            // (la usa ColumnRangePartitioner en los samples). Aqui son indices
            // de fila 0-based, y sirven para dejar rastro legible en la evidencia.
            ctx.putInt("minValue", inicio);
            ctx.putInt("maxValue", inicio + cuantas - 1);
            // Estas dos son las que consume de verdad el reader:
            ctx.putInt("linesToSkip", lineasCabecera + inicio);
            ctx.putInt("maxItemCount", cuantas);
            ctx.putString("partitionName", nombre);

            particiones.put(nombre, ctx);
            numero++;
        }
        return particiones;
    }

    /**
     * Cuenta las lineas del CSV sin la cabecera. Ignora lineas en blanco.
     *
     * Se DELEGA en ContadorFilasCsv en vez de contar aqui, porque
     * CuadraturaTasklet necesita exactamente el mismo numero para comprobar que
     * la tabla contiene el fichero entero. Dos implementaciones del mismo conteo
     * acabarian discrepando en algun detalle (la linea en blanco final, el BOM)
     * y esa discrepancia se leeria como un descuadre inexistente... o taparia
     * uno real.
     */
    private int contarFilasDeDatos() {
        return ContadorFilasCsv.contar(recurso, lineasCabecera);
    }
}
