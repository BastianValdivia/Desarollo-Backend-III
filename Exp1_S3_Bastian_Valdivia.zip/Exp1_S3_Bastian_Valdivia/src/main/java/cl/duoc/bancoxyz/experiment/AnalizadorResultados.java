package cl.duoc.bancoxyz.experiment;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Convierte las ejecuciones crudas en la tabla comparativa.
 *
 * ------------------------------------------------------------------------
 * POR QUE MEDIANA Y NO MEDIA
 * ------------------------------------------------------------------------
 * Un benchmark en una maquina de escritorio tiene valores atipicos por causas
 * ajenas al codigo: una pausa del recolector de basura, el antivirus, el
 * compilador JIT recompilando un metodo caliente. La MEDIA se los traga y
 * desplaza el resultado; la MEDIANA los ignora. Reportar solo la media es la
 * forma mas comun de publicar un numero que nadie puede reproducir.
 *
 * ------------------------------------------------------------------------
 * POR QUE ADEMAS HACE FALTA LA DISPERSION
 * ------------------------------------------------------------------------
 * "412 ms contra 389 ms" no significa NADA si los dos rangos intercuartilicos
 * se solapan: la diferencia esta dentro del ruido de medicion y afirmar que
 * uno es mas rapido seria inventar. Por eso cada celda lleva P25-P75 (el IQR:
 * donde cae la mitad central de las medidas) y el CV% (desviacion tipica
 * dividida por la media: cuanto ruido hay en proporcion al valor). Un CV por
 * encima del 15% es una senal de que esa celda no es concluyente.
 *
 * Cuantiles calculados por interpolacion lineal sobre la muestra ordenada
 * (el metodo 7 de Hyndman-Fan, el mismo que usan R y numpy por defecto).
 */
@Component
@Profile("experiment")
public class AnalizadorResultados {

    /** Estadisticos de UNA celda de la matriz, a partir de sus repeticiones validas. */
    public record ResumenCelda(
            CasoExperimento caso,
            int repeticionesValidas,
            double medianaMs,
            double p25Ms,
            double p75Ms,
            double cvPorcentaje,
            double throughputMediano,
            long commitCountMediano,
            long readCount,
            double skewMediano,
            int hilosDistintos) {

        public double iqrMs() {
            return p75Ms - p25Ms;
        }

        /** Los IQR se solapan si ninguno de los dos queda enteramente a un lado del otro. */
        public boolean solapaCon(ResumenCelda otra) {
            return this.p25Ms <= otra.p75Ms && otra.p25Ms <= this.p75Ms;
        }
    }

    /**
     * Agrupa por celda y calcula estadisticos. Solo entran las repeticiones que
     * NO son calentamiento, terminaron COMPLETED y leyeron todas las filas.
     */
    public List<ResumenCelda> resumir(List<ResultadoExperimento> crudos) {
        Map<CasoExperimento, List<ResultadoExperimento>> porCelda = crudos.stream()
                .filter(ResultadoExperimento::cuentaParaElAnalisis)
                .collect(Collectors.groupingBy(ResultadoExperimento::caso,
                        LinkedHashMap::new, Collectors.toList()));

        return porCelda.entrySet().stream()
                .map(e -> resumirCelda(e.getKey(), e.getValue()))
                .sorted(Comparator
                        .comparingInt((ResumenCelda r) -> r.caso().filasDataset())
                        .thenComparing(r -> r.caso().fase())
                        .thenComparing(r -> r.caso().estrategia())
                        .thenComparingInt(r -> r.caso().paralelismo())
                        .thenComparingInt(r -> r.caso().chunkSize()))
                .toList();
    }

    private ResumenCelda resumirCelda(CasoExperimento caso, List<ResultadoExperimento> reps) {
        double[] ms = reps.stream().mapToDouble(ResultadoExperimento::wallClockMs).sorted().toArray();
        double media = java.util.Arrays.stream(ms).average().orElse(0);
        double varianza = java.util.Arrays.stream(ms).map(v -> (v - media) * (v - media)).sum()
                / Math.max(1, ms.length - 1);   // n-1: varianza MUESTRAL, no poblacional
        double cv = media == 0 ? 0 : Math.sqrt(varianza) / media * 100;

        return new ResumenCelda(
                caso,
                reps.size(),
                cuantil(ms, 0.50),
                cuantil(ms, 0.25),
                cuantil(ms, 0.75),
                cv,
                mediana(reps.stream().mapToDouble(ResultadoExperimento::throughput).sorted().toArray()),
                (long) mediana(reps.stream().mapToDouble(ResultadoExperimento::commitCount).sorted().toArray()),
                reps.get(0).readCount(),
                mediana(reps.stream().mapToDouble(ResultadoExperimento::skew).sorted().toArray()),
                reps.stream().mapToInt(ResultadoExperimento::hilosDistintos).max().orElse(0));
    }

    private static double mediana(double[] ordenados) {
        return cuantil(ordenados, 0.50);
    }

    private static double cuantil(double[] ordenados, double q) {
        if (ordenados.length == 0) {
            return 0;
        }
        if (ordenados.length == 1) {
            return ordenados[0];
        }
        double pos = q * (ordenados.length - 1);
        int bajo = (int) Math.floor(pos);
        int alto = (int) Math.ceil(pos);
        double peso = pos - bajo;
        return ordenados[bajo] * (1 - peso) + ordenados[alto] * peso;
    }

    /**
     * LA BASE DEL SPEEDUP, DECLARADA UNA SOLA VEZ Y APLICADA A TODAS LAS FILAS.
     *
     * Es el MEJOR secuencial de esa escala, no "el secuencial con chunk=200" ni
     * "el Job 1 real". Motivo: comparar contra un secuencial mal configurado
     * regalaria un speedup que en realidad mide lo mal elegido que estaba el
     * chunk, no lo que aporta el paralelismo. Un speedup honesto se mide contra
     * la mejor alternativa de un solo hilo.
     */
    public Optional<ResumenCelda> baseSpeedup(List<ResumenCelda> resumenes, int filas) {
        return resumenes.stream()
                .filter(r -> r.caso().filasDataset() == filas)
                .filter(r -> r.caso().estrategia() == EstrategiaEscalado.SECUENCIAL)
                .min(Comparator.comparingDouble(ResumenCelda::medianaMs));
    }

    /** Tabla en Markdown lista para pegar en docs/escalado.md. */
    public String tablaMarkdown(List<ResumenCelda> resumenes, int filas) {
        Optional<ResumenCelda> base = baseSpeedup(resumenes, filas);
        double msBase = base.map(ResumenCelda::medianaMs).orElse(Double.NaN);

        StringBuilder sb = new StringBuilder();
        sb.append("| Fase | Estrategia | Paralelismo | chunk | n | Mediana (ms) | P25-P75 (ms) | IQR | CV % | Speedup | Throughput (filas/s) | COMMIT | skew | hilos |\n");
        sb.append("|---|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|\n");
        for (ResumenCelda r : resumenes) {
            if (r.caso().filasDataset() != filas) {
                continue;
            }
            // Locale.ROOT NO ES OPCIONAL. String.formatted() usa la configuracion
            // regional de la JVM: en una maquina en espanol, "%.1f" escribe
            // "1203,0" con COMA decimal. En una tabla Markdown queda feo pero se
            // lee; en el CSV de al lado destrozaria las columnas. Y aqui ademas
            // producia una inconsistencia visible: los tiempos con coma y los
            // speedup (que ya usaban Locale.ROOT) con punto, en la misma fila.
            // Se detecto en la primera corrida completa del banco de pruebas.
            sb.append(String.format(Locale.ROOT,
                    "| %s | %s | %d | %d | %d | %.1f | %.1f-%.1f | %.1f | %.1f | %s | %.0f | %d | %.2f | %d |%n",
                            r.caso().fase(),
                            r.caso().estrategia().name(),
                            r.caso().paralelismo(),
                            r.caso().chunkSize(),
                            r.repeticionesValidas(),
                            r.medianaMs(),
                            r.p25Ms(), r.p75Ms(),
                            r.iqrMs(),
                            r.cvPorcentaje(),
                            Double.isNaN(msBase) ? "-" : String.format(Locale.ROOT, "%.2fx", msBase / r.medianaMs()),
                            r.throughputMediano(),
                            r.commitCountMediano(),
                            r.skewMediano(),
                            r.hilosDistintos()));
        }
        base.ifPresent(b -> sb.append(String.format(Locale.ROOT,
                "%nBase de speedup declarada (unica para toda la tabla): %s, paralelismo=%d, chunk=%d, n=%d filas, mediana %.1f ms.%n",
                b.caso().estrategia().name(), b.caso().paralelismo(),
                b.caso().chunkSize(), filas, b.medianaMs())));
        return sb.toString();
    }
}
