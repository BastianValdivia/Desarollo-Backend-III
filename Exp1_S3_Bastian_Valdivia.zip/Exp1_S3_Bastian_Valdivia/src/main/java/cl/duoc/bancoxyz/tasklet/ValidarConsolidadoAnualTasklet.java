package cl.duoc.bancoxyz.tasklet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * Controles de COHERENCIA DEL CONSOLIDADO del Job 3.
 *
 * ------------------------------------------------------------------------
 * POR QUE ESTE TASKLET EXISTE SI YA ESTA CuadraturaTasklet
 * ------------------------------------------------------------------------
 * No se solapan: responden preguntas distintas y las dos hacen falta.
 *
 *   CuadraturaTasklet (se REUTILIZA tal cual, es generica desde el Job 1)
 *       responde "no se ha perdido ninguna fila de ENTRADA":
 *       1000 = 952 de negocio + 48 rechazadas + 0 filtradas.
 *
 *   Esta clase responde "el AGREGADO es fiel a lo que agrega":
 *       las 20 filas de estado_cuenta_anual dicen la verdad sobre las 952 de
 *       movimiento_anual.
 *
 * Es la diferencia entre "no perdi datos al cargar" y "no me equivoque al
 * resumir". Un GROUP BY mal escrito -un JOIN que duplica, un WHERE que se deja
 * filas fuera- pasaria la primera comprobacion sin despeinarse y produciria un
 * estado de cuenta incorrecto. Que es, precisamente, el documento que el banco
 * le ensena al cliente.
 *
 * ------------------------------------------------------------------------
 * POR QUE SE RECOGEN TODOS LOS FALLOS ANTES DE LANZAR LA EXCEPCION
 * ------------------------------------------------------------------------
 * La tentacion es lanzar en cuanto una comprobacion falla. Se hace al reves: se
 * ejecutan las cuatro, se acumulan los problemas en una lista y se lanza UNA
 * excepcion con todos dentro.
 *
 * Motivo practico: si fallan tres cosas y el tasklet corta en la primera, hacen
 * falta tres ejecuciones del job -varios minutos cada una- para enterarse de
 * las tres. Acumulando, el primer fallo ya trae el diagnostico completo.
 *
 * ------------------------------------------------------------------------
 * POR QUE UNA EXCEPCION Y NO UN AVISO EN EL LOG
 * ------------------------------------------------------------------------
 * Un WARN en el log lo lee nadie. Lanzar deja el job en FAILED, que es un hecho
 * observable en BATCH_JOB_EXECUTION y en el codigo de salida del proceso. La
 * regla es que un proceso batch nunca debe terminar COMPLETED diciendo una
 * mentira: es preferible un fallo ruidoso a un exito falso.
 */
public class ValidarConsolidadoAnualTasklet implements Tasklet {

    private static final Logger log = LoggerFactory.getLogger(ValidarConsolidadoAnualTasklet.class);

    /** El fichero trae las cuentas 101..120: 20 cuentas, todas con movimientos. */
    private static final int CUENTA_MIN = 101;
    private static final int CUENTA_MAX = 120;
    private static final int CUENTAS_ESPERADAS = CUENTA_MAX - CUENTA_MIN + 1;

    private final JdbcTemplate jdbc;

    public ValidarConsolidadoAnualTasklet(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        List<String> problemas = new ArrayList<>();

        // ==============================================================
        // CONTROL 1: hay exactamente una fila por cuenta, y son las 20 del
        // fichero. Si alguna fecha cayera en otro anio, el GROUP BY
        // (cuenta_id, anio) produciria mas de 20 filas: este control lo caza.
        // ==============================================================
        int filas = contar("SELECT COUNT(*) FROM banco.estado_cuenta_anual");
        if (filas != CUENTAS_ESPERADAS) {
            problemas.add("banco.estado_cuenta_anual tiene " + filas
                    + " filas y deberia tener " + CUENTAS_ESPERADAS
                    + " (una por cuenta " + CUENTA_MIN + ".." + CUENTA_MAX + ")");
        }

        int fuera = contar("SELECT COUNT(*) FROM banco.estado_cuenta_anual"
                + " WHERE cuenta_id NOT BETWEEN ? AND ?", CUENTA_MIN, CUENTA_MAX);
        if (fuera > 0) {
            problemas.add(fuera + " filas de estado_cuenta_anual tienen un cuenta_id"
                    + " fuera del rango " + CUENTA_MIN + ".." + CUENTA_MAX);
        }

        // ==============================================================
        // CONTROL 2: el consolidado cuenta EXACTAMENTE los mismos movimientos
        // que hay en la tabla de detalle. Es la comprobacion que detecta el
        // error clasico de agregacion: un JOIN que duplica filas (SUM daria de
        // mas) o un WHERE que se deja algunas fuera (daria de menos).
        // ==============================================================
        int sumaConsolidado = contar(
                "SELECT COALESCE(SUM(n_movimientos), 0) FROM banco.estado_cuenta_anual");
        int detalle = contar("SELECT COUNT(*) FROM banco.movimiento_anual");
        if (sumaConsolidado != detalle) {
            problemas.add("SUM(n_movimientos)=" + sumaConsolidado
                    + " no coincide con las " + detalle + " filas de banco.movimiento_anual");
        }

        // ==============================================================
        // CONTROL 3: LA CUADRATURA CONTABLE, cuenta por cuenta.
        //
        // Recalcula el agregado desde el detalle y lo compara con lo que se
        // guardo. Que salga 0 significa que, para TODAS las cuentas, el saldo
        // neto y el numero de movimientos del estado de cuenta se pueden
        // reconstruir desde los movimientos. Es la definicion de "el informe no
        // miente".
        //
        // IS DISTINCT FROM y no <>: con <>, una comparacion contra NULL da NULL
        // (que no es TRUE), asi que una fila con saldo_neto NULL NO se contaria
        // como descuadrada y el control la dejaria pasar. IS DISTINCT FROM
        // trata NULL como un valor mas y si la detecta.
        // ==============================================================
        int descuadradas = contar("""
                SELECT COUNT(*)
                  FROM banco.estado_cuenta_anual e
                  JOIN (SELECT cuenta_id, anio,
                               SUM(monto_con_signo) AS saldo,
                               COUNT(*)             AS n
                          FROM banco.movimiento_anual
                         GROUP BY cuenta_id, anio) m
                    ON m.cuenta_id = e.cuenta_id AND m.anio = e.anio
                 WHERE e.saldo_neto    IS DISTINCT FROM m.saldo
                    OR e.n_movimientos IS DISTINCT FROM m.n
                """);
        if (descuadradas > 0) {
            problemas.add(descuadradas + " cuentas tienen un saldo_neto o un n_movimientos"
                    + " que no se puede reconstruir desde banco.movimiento_anual");
        }

        // ==============================================================
        // CONTROL 4: ninguna cuenta con movimientos se quedo sin consolidar.
        //
        // Los controles 1-3 miran las filas que SI existen. Este mira las que
        // FALTAN, que es un agujero distinto: si una cuenta entera se cayera del
        // GROUP BY, el control 2 tambien lo detectaria, pero este dice CUAL es,
        // que es lo que de verdad ahorra tiempo al diagnosticar.
        // ==============================================================
        List<Integer> sinConsolidar = jdbc.queryForList("""
                SELECT DISTINCT m.cuenta_id
                  FROM banco.movimiento_anual m
                 WHERE NOT EXISTS (SELECT 1 FROM banco.estado_cuenta_anual e
                                    WHERE e.cuenta_id = m.cuenta_id AND e.anio = m.anio)
                 ORDER BY 1
                """, Integer.class);
        if (!sinConsolidar.isEmpty()) {
            problemas.add("cuentas con movimientos pero SIN fila en estado_cuenta_anual: "
                    + sinConsolidar);
        }

        // ==============================================================
        // VEREDICTO
        // ==============================================================
        if (!problemas.isEmpty()) {
            throw new IllegalStateException(
                    "CONSOLIDADO ANUAL INCOHERENTE (" + problemas.size() + " problemas): "
                            + String.join(" | ", problemas));
        }

        log.info("CONSOLIDADO OK: {} cuentas, SUM(n_movimientos)={} = {} filas de detalle,"
                + " 0 cuentas descuadradas", filas, sumaConsolidado, detalle);

        return RepeatStatus.FINISHED;
    }

    /** Atajo para los COUNT: JdbcTemplate devuelve Integer y aqui nunca es null. */
    private int contar(String sql, Object... args) {
        Integer n = jdbc.queryForObject(sql, Integer.class, args);
        return n == null ? 0 : n;
    }
}
