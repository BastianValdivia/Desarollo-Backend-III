package cl.duoc.bancoxyz.listener;

import org.springframework.batch.item.file.FlatFileHeaderCallback;

import java.io.IOException;
import java.io.Writer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Escribe la CABECERA del informe de auditoria del Job 3.
 *
 * FlatFileHeaderCallback es el gancho que el FlatFileItemWriter invoca UNA vez,
 * justo despues de abrir el fichero y antes de la primera fila de datos. Es la
 * forma correcta de poner una cabecera: escribirla a mano antes de arrancar el
 * step dejaria el fichero abierto por dos sitios, y el writer lo truncaria al
 * abrirlo (shouldDeleteIfExists) borrando lo ya escrito.
 *
 * ------------------------------------------------------------------------
 * QUE LLEVA Y POR QUE
 * ------------------------------------------------------------------------
 * Un informe de auditoria tiene que poder responder, sin salir del fichero,
 * "de donde salio esto". Por eso la cabecera no es solo la fila de nombres de
 * columna: lleva tambien el job_execution_id y la marca de tiempo.
 *
 * El job_execution_id es la pieza clave: es lo que permite ir a
 * BATCH_JOB_EXECUTION y a banco.control_carga y reconstruir la corrida entera
 * -cuantas filas entraron, cuantas se rechazaron, cuanto tardo- a partir de un
 * fichero que alguien encontro suelto en un directorio seis meses despues. Sin
 * el, el informe es un volcado anonimo.
 *
 * Las lineas de contexto van prefijadas con '#' para que sigan un convenio
 * reconocible de comentario, de modo que un lector de CSV configurado para
 * ignorar comentarios pueda cargar el fichero como una tabla.
 */
public class CabeceraInformeCallback implements FlatFileHeaderCallback {

    /** ISO local, sin zona: legible por una persona y ordenable por una maquina. */
    private static final DateTimeFormatter MARCA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Los nombres de columna del CSV de salida. DEBEN ir en el mismo orden que
     * los campos que extrae el writer; si los dos ordenes se separaran, el
     * informe tendria las etiquetas cambiadas de sitio y nadie lo notaria
     * mirando solo los numeros.
     */
    public static final String COLUMNAS = String.join(";",
            "cuenta_id", "anio", "n_movimientos",
            "n_depositos", "n_retiros", "n_pagos", "n_compras",
            "total_depositos", "total_retiros", "total_pagos", "total_compras",
            "saldo_neto", "n_anomalias", "primera_fecha", "ultima_fecha");

    private final Long jobExecutionId;

    public CabeceraInformeCallback(Long jobExecutionId) {
        this.jobExecutionId = jobExecutionId;
    }

    @Override
    public void writeHeader(Writer writer) throws IOException {
        // OJO: NO se escribe el salto de linea final. El FlatFileItemWriter
        // anade el separador de linea DESPUES de la cabecera por su cuenta; si
        // lo pusieramos aqui, el informe saldria con una linea en blanco entre
        // la cabecera y los datos.
        writer.write("# INFORME DE ESTADOS DE CUENTA ANUALES - Banco XYZ\n");
        writer.write("# job: jobEstadosCuentaAnuales | job_execution_id: " + jobExecutionId + "\n");
        writer.write("# generado: " + LocalDateTime.now().format(MARCA) + "\n");
        writer.write("# origen: banco.estado_cuenta_anual (consolidado de banco.movimiento_anual)\n");
        writer.write("#\n");
        writer.write(COLUMNAS);
    }
}
