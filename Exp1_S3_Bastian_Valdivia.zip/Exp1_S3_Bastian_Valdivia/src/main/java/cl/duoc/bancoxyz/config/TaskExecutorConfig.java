package cl.duoc.bancoxyz.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * El pool de hilos que ejecuta las particiones en paralelo.
 *
 * Un TaskExecutor es "quien presta los hilos". Sin el, Spring Batch usa un
 * SyncTaskExecutor que ejecuta las particiones UNA DETRAS DE OTRA sin avisar:
 * tendrias un "particionado" que en realidad es secuencial, y encima mas lento
 * por el trabajo extra de repartir. Es la trampa numero uno del criterio 4.
 */
@Configuration
public class TaskExecutorConfig {

    /** Numero de particiones por defecto. Se compara con otros valores en el criterio 4. */
    public static final int PARTICIONES = 4;

    @Bean
    public ThreadPoolTaskExecutor poolParticiones() {
        ThreadPoolTaskExecutor pool = new ThreadPoolTaskExecutor();

        // core == max: el pool nace con todos sus hilos y no crece ni encoge.
        // Si core < max, el pool solo crea hilos nuevos CUANDO LA COLA SE LLENA,
        // asi que con una cola grande nunca pasaria de "core" hilos y estarias
        // midiendo un paralelismo menor del que crees.
        pool.setCorePoolSize(PARTICIONES);
        pool.setMaxPoolSize(PARTICIONES);

        // Cola sin limite practico. Si la cola fuera mas pequena que el numero de
        // particiones, las sobrantes serian RECHAZADAS y sus steps quedarian en
        // FAILED en silencio, con el mensaje "TaskExecutor rejected the task".
        pool.setQueueCapacity(Integer.MAX_VALUE);

        // Prefijo reconocible en los logs: es la prueba visual de que cada
        // particion corre en un hilo distinto.
        pool.setThreadNamePrefix("particion-");

        // Espera a que las particiones terminen antes de apagar la aplicacion,
        // con un limite para no colgarse si alguna se atasca.
        pool.setWaitForTasksToCompleteOnShutdown(true);
        pool.setAwaitTerminationSeconds(60);

        // DAEMON: sin esto la aplicacion NO TERMINA nunca.
        // Los hilos de un pool son "no-daemon" por defecto, y la JVM se niega a
        // salir mientras quede uno vivo. Como el pool mantiene sus hilos base
        // indefinidamente, el job acaba bien pero el proceso queda colgado para
        // siempre: la JVM espera a los hilos, y los hilos esperan a que la JVM
        // dispare el cierre. Un bloqueo mutuo.
        //
        // Marcandolos daemon, la JVM puede iniciar el cierre; entonces se ejecuta
        // el hook de Spring, que apaga el pool ordenadamente esperando (hasta 60 s)
        // a que las particiones en curso terminen.
        pool.setDaemon(true);

        pool.initialize();
        return pool;
    }
}
