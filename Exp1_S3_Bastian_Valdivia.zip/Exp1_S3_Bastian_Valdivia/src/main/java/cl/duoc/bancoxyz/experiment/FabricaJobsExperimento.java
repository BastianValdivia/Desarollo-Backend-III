package cl.duoc.bancoxyz.experiment;

import cl.duoc.bancoxyz.domain.Transaccion;
import cl.duoc.bancoxyz.domain.TransaccionRaw;
import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import cl.duoc.bancoxyz.listener.RechazoListener;
import cl.duoc.bancoxyz.partition.LineRangePartitioner;
import cl.duoc.bancoxyz.policy.BackOffPolicies;
import cl.duoc.bancoxyz.policy.BancoXyzSkipPolicy;
import cl.duoc.bancoxyz.policy.RetryPolicies;
import cl.duoc.bancoxyz.support.NormalizadorFecha;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.observation.ObservationRegistry;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.support.SynchronizedItemStreamReader;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * Construye, para cada celda de la matriz, un Job COMPLETO y desechable.
 *
 * ------------------------------------------------------------------------
 * POR QUE UNA FACTORY IMPERATIVA Y NO @Bean
 * ------------------------------------------------------------------------
 * El chunkSize se fija en StepBuilder.chunk(n, tx), es decir EN TIEMPO DE
 * CONSTRUCCION del step. Para barrer {10, 50, 100, 500} harian falta cuatro
 * steps distintos, o un Step con @JobScope leyendo #{jobParameters['chunk']}.
 * Lo segundo esta PROHIBIDO por la regla 7 del proyecto (un bean de tipo Step
 * nunca lleva scope: el proxy rompe la identidad de objeto que usa el grafo
 * del job) y ademas metaeria resolucion SpEL dentro de la ventana cronometrada.
 * Una factory que devuelve objetos frescos es mas simple y no contamina la
 * medicion.
 *
 * ------------------------------------------------------------------------
 * EL PRECIO DE ESA DECISION, Y COMO SE PAGA
 * ------------------------------------------------------------------------
 * Las metricas de Spring Batch (spring.batch.job, spring.batch.step, ...) las
 * cablea BatchObservabilityBeanPostProcessor, que es un BeanPostProcessor: solo
 * actua sobre Job y Step que sean BEANS DE SPRING. Los de esta factory no lo
 * son, asi que su ObservationRegistry se quedaria en NOOP y todas las metricas
 * saldrian vacias SIN NINGUN ERROR. Por eso CADA JobBuilder y CADA StepBuilder
 * de aqui -manager y worker incluidos- recibe explicitamente
 * .observationRegistry(...) y .meterRegistry(...).
 */
@Component
// La barra vertical es un OR de perfiles: la fabrica la usan tanto el banco de
// pruebas completo (perfil "experiment") como el volcado de metricas de
// Micrometer (perfil "metricas"), que solo lanza un job de ejemplo.
@Profile("experiment | metricas")
public class FabricaJobsExperimento {

    /** Nombre del job de pruebas. Se mantiene fijo para poder agrupar en SQL. */
    public static final String NOMBRE_JOB = "jobExperimentoTransacciones";

    private static final String ARCHIVO_ORIGEN = "transacciones.csv";
    private static final int LINEAS_CABECERA = 1;

    private final JobRepository jobRepository;
    private final PlatformTransactionManager txManager;
    private final ObservationRegistry observationRegistry;
    private final MeterRegistry meterRegistry;
    private final DataSource dataSource;
    private final JdbcTemplate jdbcTemplate;
    private final NormalizadorFecha normalizadorFecha;
    private final NormalizadorMonto normalizadorMonto;
    private final NormalizadorTexto normalizadorTexto;

    public FabricaJobsExperimento(JobRepository jobRepository,
                                  PlatformTransactionManager txManager,
                                  ObservationRegistry observationRegistry,
                                  MeterRegistry meterRegistry,
                                  DataSource dataSource,
                                  JdbcTemplate jdbcTemplate,
                                  NormalizadorFecha normalizadorFecha,
                                  NormalizadorMonto normalizadorMonto,
                                  NormalizadorTexto normalizadorTexto) {
        this.jobRepository = jobRepository;
        this.txManager = txManager;
        this.observationRegistry = observationRegistry;
        this.meterRegistry = meterRegistry;
        this.dataSource = dataSource;
        this.jdbcTemplate = jdbcTemplate;
        this.normalizadorFecha = normalizadorFecha;
        this.normalizadorMonto = normalizadorMonto;
        this.normalizadorTexto = normalizadorTexto;
    }

    /**
     * Lo que devuelve la factory: el Job listo para lanzar, mas los dos objetos
     * que hay que consultar o cerrar despues.
     *
     * @param procesador para preguntarle cuantos HILOS DISTINTOS trabajaron
     * @param pool       hay que apagarlo tras la ejecucion; null si es SECUENCIAL
     */
    public record JobExperimento(Job job, ProcesadorExperimento procesador, ThreadPoolTaskExecutor pool) {
        public void cerrar() {
            if (pool != null) {
                pool.shutdown();
            }
        }
    }

    public JobExperimento construir(CasoExperimento caso) {
        return switch (caso.estrategia()) {
            case SECUENCIAL   -> secuencial(caso);
            case MULTI_THREAD -> multiHilo(caso);
            case PARTICIONADO -> particionado(caso);
        };
    }

    // ==================================================================
    // ESTRATEGIA 1 - SECUENCIAL. La base de comparacion.
    // ==================================================================
    private JobExperimento secuencial(CasoExperimento caso) {
        ProcesadorExperimento procesador = nuevoProcesador();

        Step step = pasoChunk("s-" + caso.etiqueta(), caso, procesador,
                new LectorRangoTransacciones(caso.recurso(), LINEAS_CABECERA))
                .build();

        return new JobExperimento(job(caso).start(step).build(), procesador, null);
    }

    // ==================================================================
    // ESTRATEGIA 2 - MULTI_THREAD. Un step, varios hilos, UN SOLO lector.
    // ==================================================================
    private JobExperimento multiHilo(CasoExperimento caso) {
        ProcesadorExperimento procesador = nuevoProcesador();
        ThreadPoolTaskExecutor pool = pool(caso.paralelismo(), "mth-");

        // FlatFileItemReader NO es thread-safe: dos hilos leyendo a la vez se
        // saltan lineas o repiten. SynchronizedItemStreamReader pone un cerrojo
        // alrededor de read().
        //
        // HAY QUE DECIRLO CLARO EN EL INFORME: ese cerrojo SERIALIZA LA LECTURA.
        // En esta estrategia solo se paralelizan processor y writer; leer el CSV
        // sigue siendo un embudo de un hilo. Es una limitacion estructural, no
        // un defecto de implementacion, y explica por que MULTI_THREAD nunca
        // podra acercarse al speedup ideal en un job dominado por la lectura.
        SynchronizedItemStreamReader<TransaccionRaw> lectorSeguro = new SynchronizedItemStreamReader<>();
        lectorSeguro.setDelegate(new LectorRangoTransacciones(caso.recurso(), LINEAS_CABECERA));

        Step step = pasoChunk("m-" + caso.etiqueta(), caso, procesador, lectorSeguro)
                .taskExecutor(pool)
                // ------------------------------------------------------------
                // TRAMPA QUE INVALIDA LA FILA ENTERA SI SE OLVIDA
                // ------------------------------------------------------------
                // throttleLimit limita cuantos chunks pueden estar EN VUELO a la
                // vez, y su valor por defecto es 4 (TaskExecutorRepeatTemplate.
                // DEFAULT_THROTTLE_LIMIT). Sin esta linea, la celda "8 hilos"
                // usaria de verdad 4 y la tabla mostraria una saturacion FALSA
                // en 4 que en realidad seria un tope hardcodeado del framework.
                // Esta deprecado en 5.x -desaparecera en 6.x-, pero en 5.2.6 es
                // el unico mecanismo disponible, asi que se usa y se declara.
                .throttleLimit(caso.paralelismo())
                .build();

        return new JobExperimento(job(caso).start(step).build(), procesador, pool);
    }

    // ==================================================================
    // ESTRATEGIA 3 - PARTICIONADO. N rangos disjuntos, N lectores.
    // ==================================================================
    private JobExperimento particionado(CasoExperimento caso) {
        ProcesadorExperimento procesador = nuevoProcesador();
        ThreadPoolTaskExecutor pool = pool(caso.paralelismo(), "particion-");

        Step worker = pasoChunk("w-" + caso.etiqueta(), caso, procesador,
                new LectorRangoTransacciones(caso.recurso(), LINEAS_CABECERA))
                .build();

        Step manager = new StepBuilder("g-" + caso.etiqueta(), jobRepository)
                .observationRegistry(observationRegistry)   // el manager TAMBIEN lo necesita
                .meterRegistry(meterRegistry)
                .partitioner(worker.getName(),
                        new LineRangePartitioner(caso.recurso(), LINEAS_CABECERA))
                .step(worker)
                .gridSize(caso.paralelismo())
                // Sin .taskExecutor(...) Spring cae a un SyncTaskExecutor SIN AVISAR:
                // tendrias un "particionado" que corre las particiones una detras de
                // otra y encima paga el coste de repartir. Es la trampa numero uno
                // del criterio. La prueba de que NO cayo ahi esta en la columna
                // hilos_distintos del CSV.
                .taskExecutor(pool)
                // NO se usa .partitionHandler(...): si se pusiera, .gridSize() y
                // .taskExecutor() del builder se ignorarian y el handler por defecto
                // arrancaria con gridSize 1.
                .build();

        return new JobExperimento(job(caso).start(manager).build(), procesador, pool);
    }

    // ==================================================================
    // PIEZAS COMPARTIDAS
    // ==================================================================

    /** Todos los jobs del experimento comparten este cableado de observabilidad. */
    private JobBuilder job(CasoExperimento caso) {
        return new JobBuilder(NOMBRE_JOB, jobRepository)
                .observationRegistry(observationRegistry)
                .meterRegistry(meterRegistry);
    }

    /**
     * El step chunk-oriented comun a las tres estrategias. Es DELIBERADAMENTE
     * el mismo cableado del Job 1 real (mismo processor, mismo writer, misma
     * politica de omision, mismo dead letter): si el banco de pruebas midiera
     * una version aligerada, los tiempos no dirian nada sobre el job que de
     * verdad se ejecuta.
     */
    private org.springframework.batch.core.step.builder.FaultTolerantStepBuilder<TransaccionRaw, Transaccion>
            pasoChunk(String nombre, CasoExperimento caso, ProcesadorExperimento procesador,
                      org.springframework.batch.item.ItemStreamReader<TransaccionRaw> lector) {

        var builder = new StepBuilder(nombre, jobRepository)
                .observationRegistry(observationRegistry)
                .meterRegistry(meterRegistry)
                .<TransaccionRaw, Transaccion>chunk(caso.chunkSize(), txManager)
                .reader(lector)
                .processor(procesador)
                .writer(escritor())
                .faultTolerant()
                // El limite de omisiones se pone en el tamano del dataset a
                // proposito: en el banco de pruebas NO queremos que el techo de
                // tolerancia dispare, porque una SkipLimitExceededException
                // abortaria la celda y dejaria un hueco en la tabla. El techo
                // real (500, configurable) se demuestra en el criterio 5.
                .skipPolicy(new BancoXyzSkipPolicy(caso.filasDataset()))
                .retryPolicy(RetryPolicies.infraestructura())
                .backOffPolicy(BackOffPolicies.exponencial())
                .noRollback(RegistroInvalidoException.class);

        // El dead letter se incluye A PROPOSITO aunque encarezca la medicion:
        // sin el, las filas omitidas desaparecerian y el experimento estaria
        // midiendo un trabajo MENOR que el real (215 INSERT menos por corrida a
        // escala 1000). Un benchmark de un job que no es el job no vale nada.
        //
        // Matiz honesto: RechazoListener guarda el nombre del step en un campo,
        // asi que con varias particiones compartiendo la instancia la columna
        // step_name puede quedar atribuida a otra particion. No afecta a los
        // TIEMPOS, que es lo que aqui se mide, ni al conteo total de rechazos.
        RechazoListener<TransaccionRaw, Transaccion> deadLetter =
                new RechazoListener<>(jdbcTemplate, txManager, ARCHIVO_ORIGEN);

        builder.listener((SkipListener<TransaccionRaw, Transaccion>) deadLetter);
        builder.listener((StepExecutionListener) deadLetter);
        builder.listener((StepExecutionListener) procesador);

        return builder;
    }

    private JdbcBatchItemWriter<Transaccion> escritor() {
        // Es el MISMO INSERT del Job 1. Nota: las columnas GENERATED ALWAYS AS
        // (es_anomala) no pueden aparecer aqui; PostgreSQL las calcula solo.
        JdbcBatchItemWriter<Transaccion> writer = new JdbcBatchItemWriterBuilder<Transaccion>()
                .dataSource(dataSource)
                .sql("""
                     INSERT INTO banco.transaccion
                         (id, fecha, fecha_original, formato_fecha, monto, monto_original,
                          tipo, tipo_original, estado, anomalias, numero_linea, job_execution_id)
                     VALUES
                         (:id, :fecha, :fechaOriginal, :formatoFecha, :monto, :montoOriginal,
                          :tipo, :tipoOriginal, :estado, :anomalias, :numeroLinea, :jobExecutionId)
                     """)
                .beanMapped()
                .build();

        // ------------------------------------------------------------------
        // ESTA LINEA NO ES DECORATIVA: SIN ELLA EL WRITER REVIENTA.
        // ------------------------------------------------------------------
        // JdbcBatchItemWriter implementa InitializingBean, y es afterPropertiesSet()
        // quien analiza el SQL, detecta que lleva parametros con nombre (:id, :fecha...)
        // y activa la bandera 'usingNamedParameters'. El BUILDER NO LO LLAMA.
        //
        // En el Job 1 esto no se nota porque el writer es un @Bean y Spring
        // invoca afterPropertiesSet() por su cuenta durante el arranque. Aqui,
        // al construirlo a mano, nadie lo hace, la bandera se queda en false, y
        // el writer intenta usar la ruta de PreparedStatementSetter posicional:
        //   NullPointerException: "this.itemPreparedStatementSetter" is null
        // en el primer chunk. Se detecto exactamente asi en la primera corrida
        // del banco de pruebas.
        //
        // Es un buen ejemplo de por que salir del contenedor de Spring tiene un
        // precio: lo que el framework hacia por ti hay que hacerlo a mano.
        try {
            writer.afterPropertiesSet();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo inicializar el writer del experimento", e);
        }
        return writer;
    }

    private ProcesadorExperimento nuevoProcesador() {
        return new ProcesadorExperimento(normalizadorFecha, normalizadorMonto, normalizadorTexto);
    }

    /**
     * Un pool NUEVO por cada ejecucion, y se apaga al terminar.
     *
     * Por que no reutilizar uno global: el COSTE DE ARRANCAR EL POOL es
     * precisamente una de las cosas que el experimento quiere medir. Si el pool
     * ya estuviera caliente de la celda anterior, el particionado saldria mejor
     * de lo que sale cuando el job arranca de cero, que es como corre en
     * produccion. Reutilizarlo seria maquillar.
     */
    private ThreadPoolTaskExecutor pool(int hilos, String prefijo) {
        ThreadPoolTaskExecutor pool = new ThreadPoolTaskExecutor();
        // core == max: el pool nace con todos sus hilos. Si core < max, solo se
        // crean hilos nuevos CUANDO LA COLA SE LLENA, asi que con una cola
        // grande nunca pasarias de "core" y mediras menos paralelismo del que crees.
        pool.setCorePoolSize(hilos);
        pool.setMaxPoolSize(hilos);
        // Cola sin limite practico. Si fuera menor que el numero de particiones,
        // las sobrantes se RECHAZAN y sus steps quedan FAILED en silencio con
        // "TaskExecutor rejected the task for this step".
        pool.setQueueCapacity(Integer.MAX_VALUE);
        pool.setThreadNamePrefix(prefijo);
        pool.setWaitForTasksToCompleteOnShutdown(true);
        pool.setAwaitTerminationSeconds(120);
        // DAEMON: sin esto la JVM no termina nunca (los hilos de un pool son
        // no-daemon por defecto y la JVM espera a que mueran; ellos esperan al
        // cierre de la JVM: bloqueo mutuo).
        pool.setDaemon(true);
        pool.initialize();
        return pool;
    }
}
