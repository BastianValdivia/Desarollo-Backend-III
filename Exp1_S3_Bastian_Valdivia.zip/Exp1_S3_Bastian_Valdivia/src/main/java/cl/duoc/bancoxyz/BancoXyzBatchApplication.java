package cl.duoc.bancoxyz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada de la aplicación. El equivalente a tu "if __name__ == '__main__'".
 *
 * @SpringBootApplication le dice a Spring: "escanea este paquete y los de abajo,
 * encuentra todo lo que esté marcado como componente y conéctalo solo".
 * Eso es la "inyección de dependencias": tú declaras las piezas y Spring las arma.
 */
@SpringBootApplication
public class BancoXyzBatchApplication {

    public static void main(String[] args) {
        SpringApplication.run(BancoXyzBatchApplication.class, args);
    }
}
