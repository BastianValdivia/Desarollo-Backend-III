package cl.duoc.bancoxyz.experiment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Persiste cada ejecucion en banco.ejecucion_metrica.
 *
 * Por que ademas del CSV: el criterio 2 exige que la salida este EN LA BASE.
 * Un CSV en results/ lo puede editar cualquiera con un bloc de notas; una
 * tabla que se cruza con BATCH_JOB_EXECUTION por job_execution_id, no. Tener
 * los dos permite ademas la verificacion cruzada: si la mediana calculada
 * desde el CSV y la calculada desde la tabla coinciden, las mediciones son
 * solidas.
 *
 * IMPORTANTE: se insertan TAMBIEN las filas de calentamiento, con warmup=true.
 * El filtrado se hace al consultar (WHERE warmup = false), nunca al escribir.
 */
@Component
@Profile("experiment")
public class RepositorioMetricasExperimento {

    private static final Logger log = LoggerFactory.getLogger(RepositorioMetricasExperimento.class);

    /**
     * La lista de columnas NO incluye ninguna GENERATED ALWAYS AS ... STORED,
     * porque PostgreSQL las rechaza en un INSERT: las calcula el propio motor.
     * En esta tabla no hay ninguna, pero la regla se respeta en todo el proyecto.
     */
    private static final String INSERT = """
            INSERT INTO banco.ejecucion_metrica
                (job_name, fase, estrategia, paralelismo, chunk_size, dataset_filas,
                 repeticion, warmup, wall_clock_ms, job_exec_ms,
                 read_count, write_count, filter_count, skip_count,
                 commit_count, rollback_count,
                 max_particion_ms, sum_particion_ms, skew, ratio_max_min,
                 hikari_pool_size, cpus, heap_max_mb, batch_status, job_execution_id)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """;

    private final JdbcTemplate jdbcTemplate;

    public RepositorioMetricasExperimento(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /** Borra las metricas de corridas anteriores del banco de pruebas. */
    public void limpiar() {
        int borradas = jdbcTemplate.update("DELETE FROM banco.ejecucion_metrica WHERE job_name = ?",
                FabricaJobsExperimento.NOMBRE_JOB);
        log.info("Metricas anteriores borradas: {}", borradas);
    }

    public void guardar(ResultadoExperimento r) {
        CasoExperimento c = r.caso();
        try {
            jdbcTemplate.update(INSERT,
                    FabricaJobsExperimento.NOMBRE_JOB,
                    c.fase(),
                    c.estrategia().name(),
                    c.paralelismo(),
                    c.chunkSize(),
                    c.filasDataset(),
                    r.ronda(),
                    r.calentamiento(),
                    r.wallClockMs(),
                    r.jobExecutionMs(),
                    r.readCount(),
                    r.writeCount(),
                    r.filterCount(),
                    r.skipCount(),
                    r.commitCount(),
                    r.rollbackCount(),
                    r.maxParticionMs(),
                    r.sumParticionMs(),
                    r.skew(),
                    r.ratioMaxMin(),
                    r.hikariPoolSize(),
                    r.cpus(),
                    r.heapMaxMb(),
                    r.batchStatus(),
                    r.jobExecutionId());
        } catch (RuntimeException e) {
            // Que falle el registro de una metrica NO debe abortar el experimento:
            // se perderia todo lo medido hasta ese momento. Se deja constancia y
            // se sigue; el CSV mantiene la copia completa.
            log.warn("No se pudo guardar la metrica de {}: {}", c.etiqueta(), e.getMessage());
        }
    }
}
