package cl.duoc.bancoxyz.experiment;

import cl.duoc.bancoxyz.domain.Transaccion;
import cl.duoc.bancoxyz.domain.TransaccionRaw;
import cl.duoc.bancoxyz.processor.TransaccionProcessor;
import cl.duoc.bancoxyz.support.NormalizadorFecha;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Envoltorio que le da al TransaccionProcessor real lo que necesita para
 * funcionar fuera de Spring: el id de ejecucion y el desplazamiento de linea
 * de la particion en curso.
 *
 * Es EL MISMO processor del Job 1, no una copia simplificada. Eso es
 * deliberado: si el banco de pruebas midiera un processor mas ligero, los
 * tiempos no dirian nada sobre el job que de verdad se ejecuta en produccion,
 * y la comparacion seria decorativa.
 *
 * El patron ThreadLocal + respaldo es el mismo de LectorRangoTransacciones y
 * por la misma razon: beforeStep() se ejecuta EN EL HILO DE LA PARTICION
 * cuando el step esta particionado (ahi cada particion necesita su propio
 * linesToSkip para calcular bien el numero de linea), pero en MULTI_THREAD
 * se ejecuta una sola vez en el hilo principal y los process() llegan desde
 * los hilos del pool. TransaccionProcessor no guarda estado mutable, asi que
 * compartir una instancia entre hilos es seguro.
 *
 * De paso este listener recoge los NOMBRES DE HILO distintos que han
 * ejecutado steps. Ese conjunto es la unica prueba objetiva de que el
 * paralelismo fue real y no un SyncTaskExecutor disfrazado.
 */
public class ProcesadorExperimento
        implements ItemProcessor<TransaccionRaw, Transaccion>, StepExecutionListener {

    private final NormalizadorFecha normalizadorFecha;
    private final NormalizadorMonto normalizadorMonto;
    private final NormalizadorTexto normalizadorTexto;

    private final ThreadLocal<TransaccionProcessor> porHilo = new ThreadLocal<>();
    private final AtomicReference<TransaccionProcessor> respaldo = new AtomicReference<>();

    /** newKeySet() = un Set concurrente. Varias particiones escriben a la vez. */
    private final Set<String> hilosVistos = ConcurrentHashMap.newKeySet();

    public ProcesadorExperimento(NormalizadorFecha normalizadorFecha,
                                 NormalizadorMonto normalizadorMonto,
                                 NormalizadorTexto normalizadorTexto) {
        this.normalizadorFecha = normalizadorFecha;
        this.normalizadorMonto = normalizadorMonto;
        this.normalizadorTexto = normalizadorTexto;
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        hilosVistos.add(Thread.currentThread().getName());

        var ctx = stepExecution.getExecutionContext();
        int linesToSkip = ctx.containsKey("linesToSkip") ? ctx.getInt("linesToSkip") : 1;

        TransaccionProcessor real = new TransaccionProcessor(
                normalizadorFecha, normalizadorMonto, normalizadorTexto,
                stepExecution.getJobExecutionId(), linesToSkip);

        porHilo.set(real);
        respaldo.set(real);
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        porHilo.remove();   // ver el comentario de close() en LectorRangoTransacciones
        return null;        // null = "no cambio el ExitStatus"
    }

    @Override
    public Transaccion process(TransaccionRaw item) throws Exception {
        hilosVistos.add(Thread.currentThread().getName());
        TransaccionProcessor real = porHilo.get();
        if (real == null) {
            real = respaldo.get();
        }
        return real.process(item);
    }

    /** Cuantos hilos DISTINTOS tocaron el trabajo. 1 = no hubo paralelismo real. */
    public int hilosDistintos() {
        return hilosVistos.size();
    }

    public Set<String> nombresDeHilo() {
        return Set.copyOf(hilosVistos);
    }
}
