package cl.duoc.bancoxyz.domain;

import org.springframework.batch.item.ItemCountAware;

/**
 * La fila de cuentas_anuales.csv TAL CUAL viene, con los 5 campos como String.
 *
 * Mismo criterio que TransaccionRaw (Job 1) e InteresRaw (Job 2), y por la misma
 * razon: si le pidieramos al lector que convirtiera "monto" a BigDecimal, las 48
 * filas con el monto vacio reventarian con FlatFileParseException DENTRO del
 * lector. Una fila que muere en la fase READ ya no se puede clasificar ni
 * explicar: llegaria al dead letter como LINEA_MALFORMADA en vez de como
 * MONTO_AUSENTE, que es lo que el contrato exige poder contar.
 *
 * Se lee crudo y se decide despues, en el processor, que es donde vive la
 * logica de negocio.
 *
 * Es clase y no `record` porque implementa ItemCountAware, y esa interfaz exige
 * un campo mutable (setItemCount). ItemCountAware es un gancho de Spring Batch:
 * si el objeto que devuelve el lector la implementa, el propio lector le
 * inyecta el numero de orden del elemento leido. Evita llevar un contador a
 * mano, que ademas se romperia con varias particiones leyendo a la vez.
 */
public class MovimientoAnualRaw implements ItemCountAware {

    private final String cuentaId;
    private final String fecha;
    private final String transaccion;
    private final String monto;
    private final String descripcion;

    /** Lo rellena el propio FlatFileItemReader al leer. El primero es el 1. */
    private int itemCount;

    public MovimientoAnualRaw(String cuentaId, String fecha, String transaccion,
                              String monto, String descripcion) {
        this.cuentaId = cuentaId;
        this.fecha = fecha;
        this.transaccion = transaccion;
        this.monto = monto;
        this.descripcion = descripcion;
    }

    // Getters con estilo corto (al modo de los records). Esta clase solo entra
    // al processor, nunca al writer, asi que NO necesita getters JavaBean: el
    // que si los necesita es MovimientoAnual, porque lo mapea .beanMapped().
    public String cuentaId()    { return cuentaId; }
    public String fecha()       { return fecha; }
    public String transaccion() { return transaccion; }
    public String monto()       { return monto; }
    public String descripcion() { return descripcion; }

    @Override
    public void setItemCount(int count) {
        this.itemCount = count;
    }

    /**
     * Posicion de esta fila DENTRO DEL ARCHIVO (la primera fila de datos es la 1).
     *
     * OJO A LA DIFERENCIA CON EL JOB 1. Alli cada particion leia un TROZO del
     * fichero (linesToSkip distinto por particion), asi que itemCount era una
     * posicion RELATIVA y habia que sumarle el desplazamiento de la particion
     * para obtener la linea fisica.
     *
     * Aqui NO hay que sumar nada: el particionado del Job 3 es POR cuenta_id, y
     * para conseguirlo cada particion lee el fichero ENTERO descartando las
     * filas que no son suyas (ver FiltroRangoCuentaReader). Como quien cuenta es
     * el FlatFileItemReader delegado, que pasa por todas las filas, este numero
     * YA es la posicion real dentro del archivo. La linea fisica del CSV es
     * itemCount + 1, por la cabecera. Sumar tambien un offset de particion daria
     * numeros de linea inventados.
     */
    public int itemCount() {
        return itemCount;
    }

    /**
     * Reconstruye la linea del CSV de la que salio esta fila.
     *
     * No es un toString "de adorno": es EXACTAMENTE lo que RechazoListener
     * guarda en la columna linea_cruda cuando se omite una fila en la fase
     * PROCESS (las 48 de MONTO_AUSENTE). Sin el, el dead letter diria
     * "MovimientoAnualRaw@6f2b958e" y no serviria para auditar nada.
     */
    @Override
    public String toString() {
        return String.join(",", cuentaId, fecha, transaccion, monto, descripcion);
    }
}
