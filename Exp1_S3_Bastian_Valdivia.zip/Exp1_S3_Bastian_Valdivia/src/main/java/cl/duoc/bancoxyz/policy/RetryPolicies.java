package cl.duoc.bancoxyz.policy;

import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.dao.RecoverableDataAccessException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.dao.TransientDataAccessResourceException;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * FABRICA DE POLITICAS DE REINTENTO.
 *
 * Es una clase de utilidad (constructor privado, metodos estaticos): no guarda
 * estado, solo arma objetos. Se separa de la configuracion del Job para poder
 * reutilizar la MISMA politica en los Jobs 2 y 3 sin copiar y pegar.
 *
 * ------------------------------------------------------------------------
 * LA DISTINCION QUE JUSTIFICA TODA ESTA CLASE
 * ------------------------------------------------------------------------
 *
 *   DATO MALO IRREPARABLE  -> SKIP (dead letter). NUNCA se reintenta.
 *       Reintentar una fila cuya fecha es "2024-13-01" fallara las tres veces
 *       exactamente igual: el dato no cambia entre intentos. Lo unico que se
 *       consigue es multiplicar por 3 el trabajo y sumar el backoff. Con 215
 *       filas malas eso son 645 intentos inutiles y minutos de espera.
 *
 *   FALLO DE INFRAESTRUCTURA -> RETRY con backoff. NUNCA se hace skip.
 *       Una conexion caida, un deadlock o un timeout son PASAJEROS: el mismo
 *       dato, bueno, escrito medio segundo despues, entra sin problema. Hacer
 *       skip aqui seria tirar a la basura datos correctos por un hipo de red,
 *       y ademas el job terminaria "COMPLETED" mintiendo.
 *
 * ------------------------------------------------------------------------
 * POR QUE SimpleRetryPolicy CON MAPA Y NO .retry(Clase) EN EL BUILDER
 * ------------------------------------------------------------------------
 *
 * FaultTolerantStepBuilder tiene dos modelos y NO conviene mezclarlos:
 *
 *   Modelo A: .retry(X.class) + .retryLimit(3) + .noRetry(Y.class)
 *             El builder construye por dentro un SimpleRetryPolicy.
 *   Modelo B: .retryPolicy(politica)  <- el que usamos
 *             Le entregas la politica ya armada.
 *
 * TRAMPA REAL: si eliges el Modelo B y ademas llamas a .noRetry(Y.class), tu
 * veto SE IGNORA EN SILENCIO. El codigo de createRetryOperations() solo
 * combina las dos configuraciones si ademas hay retryLimit > 0, y retryLimit
 * vale 0 mientras no lo declares. Resultado: crees que has prohibido reintentar
 * Y, y no has prohibido nada.
 *
 * Por eso el veto viaja DENTRO del mapa, con valor false.
 *
 * ------------------------------------------------------------------------
 * LOS TRES ARGUMENTOS DE SimpleRetryPolicy
 * ------------------------------------------------------------------------
 *   maxAttempts    = 3   -> intentos TOTALES (1 normal + 2 reintentos), no "3 reintentos".
 *   retryableExceptions  -> el mapa Clase -> true/false.
 *   traverseCauses = true -> IMPRESCINDIBLE. Spring envuelve las excepciones:
 *                    lo que llega al step no es CannotAcquireLockException sino
 *                    algo que la lleva dentro como causa. Sin recorrer la cadena
 *                    de causas, la politica no reconoceria NUNCA el fallo real
 *                    y no se reintentaria jamas.
 *
 * El cuarto argumento (defaultValue) del constructor de tres es false: todo lo
 * que NO este en el mapa es NO reintentable. Esa es la postura segura: se
 * reintenta lo que se ha decidido conscientemente reintentar, nada mas.
 */
public final class RetryPolicies {

    /** Intentos totales, no reintentos: 1 ejecucion normal + 2 repeticiones. */
    public static final int INTENTOS = 3;

    private RetryPolicies() {
        // clase de utilidad: no se instancia
    }

    /**
     * Politica para fallos de infraestructura.
     *
     * Sobre la jerarquia de excepciones (detalle que conviene tener claro):
     * CannotAcquireLockException hereda de PessimisticLockingFailureException,
     * que hereda de ConcurrencyFailureException, que hereda de
     * TransientDataAccessException. Es UNA sola rama, no tres familias
     * independientes. Con declarar la raiz TransientDataAccessException bastaria,
     * porque el clasificador de Spring Retry tambien recorre las superclases;
     * las hijas se listan igualmente porque el mapa es documentacion ejecutable:
     * dice al lector QUE fallos concretos esperamos en este proyecto.
     */
    public static RetryPolicy infraestructura() {
        // LinkedHashMap: conserva el orden en que se escriben las entradas, asi
        // el mapa se lee como una lista de decisiones y no como un revoltijo.
        Map<Class<? extends Throwable>, Boolean> mapa = new LinkedHashMap<>();

        // ---- SI se reintenta: infraestructura, fallo pasajero ----------------
        // Raiz de todos los fallos de acceso a datos que "puede que funcionen si
        // lo vuelves a intentar". Cubre por herencia a las tres siguientes.
        mapa.put(TransientDataAccessException.class, true);
        // La base no responde o la conexion se corto a mitad (escenario BD caida).
        mapa.put(TransientDataAccessResourceException.class, true);
        // Deadlock o cerrojo ocupado: dos hilos tocando la misma fila.
        mapa.put(CannotAcquireLockException.class, true);
        mapa.put(PessimisticLockingFailureException.class, true);
        // La consulta tardo mas de lo permitido.
        mapa.put(QueryTimeoutException.class, true);
        // Postgres avisa explicitamente de que la operacion es recuperable.
        mapa.put(RecoverableDataAccessException.class, true);

        // ---- NO se reintenta: el dato esta mal y seguira mal ------------------
        // Aunque el defaultValue ya es false, se declaran EXPLICITAMENTE para
        // que quede escrito en el codigo (y no en un comentario) que la decision
        // de no reintentar datos sucios es deliberada.
        mapa.put(RegistroInvalidoException.class, false);
        mapa.put(FlatFileParseException.class, false);

        return new SimpleRetryPolicy(INTENTOS, mapa, true);
    }
}
