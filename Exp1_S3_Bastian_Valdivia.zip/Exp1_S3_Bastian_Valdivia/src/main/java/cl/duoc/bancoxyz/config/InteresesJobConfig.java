package cl.duoc.bancoxyz.config;

import cl.duoc.bancoxyz.domain.InteresCalculado;
import cl.duoc.bancoxyz.domain.InteresRaw;
import cl.duoc.bancoxyz.listener.ChunkErrorListener;
import cl.duoc.bancoxyz.listener.ParticionListener;
import cl.duoc.bancoxyz.listener.RechazoListener;
import cl.duoc.bancoxyz.listener.ReintentoRetryListener;
import cl.duoc.bancoxyz.partition.RangoCuentaPartitioner;
import cl.duoc.bancoxyz.processor.InteresProcessor;
import cl.duoc.bancoxyz.reader.FiltroRangoCuentaReader;
import cl.duoc.bancoxyz.support.CalculadoraInteres;
import cl.duoc.bancoxyz.support.ControlCargaDao;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import cl.duoc.bancoxyz.support.PeriodoIntereses;
import cl.duoc.bancoxyz.tasklet.ConsolidarSaldosTasklet;
import cl.duoc.bancoxyz.tasklet.CuadraturaTasklet;
import cl.duoc.bancoxyz.tasklet.LimpiezaInteresesTasklet;
import cl.duoc.bancoxyz.tasklet.ValidarConsolidadoInteresesTasklet;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.retry.RetryListener;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.backoff.BackOffPolicy;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * JOB 2 - Calculo de Intereses Mensuales, PARTICIONADO POR CUENTA.
 *
 * Estructura:
 *
 *   jobInteresesMensuales
 *     |-- stepPrepararIntereses            (Tasklet: limpieza idempotente del periodo)
 *     |-- stepCalcularInteresesManager     (PartitionStep: reparte, no procesa)
 *     |     `-- stepCalcularInteresesWorker  x5, en paralelo
 *     |           reader -> processor -> writer
 *     |-- stepConsolidarSaldos             (Tasklet: el GROUP BY -> banco.cuenta)
 *     `-- stepValidarCuadraturaIntereses   (Tasklet: entrada = negocio + rechazos)
 *
 * ------------------------------------------------------------------------
 * EN QUE SE DIFERENCIA DEL JOB 1 (y por que se hizo distinto a proposito)
 * ------------------------------------------------------------------------
 * Copiar el Job 1 cambiando los nombres habria sido lo comodo, pero no
 * demostraria nada nuevo. Las diferencias son deliberadas:
 *
 *   1. PARTICIONADO POR CLAVE DE NEGOCIO (cuenta_id) en vez de por rango de
 *      lineas. Ver RangoCuentaPartitioner: reparte por algo que SIGNIFICA algo.
 *   2. AGREGACION con un GROUP BY en SQL (stepConsolidarSaldos) en vez de un
 *      flujo condicional con decider.
 *   3. IDEMPOTENCIA DE VERDAD, con una guarda en la base (periodo_aplicado) y
 *      no solo un "borra y recarga".
 *   4. RECHAZOS EN FASE WRITE. El Job 1 solo rechaza en PROCESS; aqui los 5
 *      duplicados solo los descubre PostgreSQL al intentar el INSERT, que es
 *      un camino de codigo completamente distinto (rollback del chunk y
 *      reproceso fila a fila).
 *
 * Lo que SI se reutiliza tal cual, sin duplicar una linea: RechazoListener,
 * BancoXyzSkipPolicy, las politicas de reintento y backoff, ParticionListener,
 * ChunkErrorListener, ControlCargaDao, CuadraturaTasklet, los Normalizadores y
 * el pool de hilos.
 *
 * SALIDA CONTRACTUAL (docs/analisis-datos.md seccion 6):
 *   banco.interes_calculado 784 + rechazos 216 = 1000
 *   rechazos: SALDO_AUSENTE 211 (fase PROCESS) + DUPLICADO 5 (fase WRITE)
 *   banco.cuenta: 50 filas (cuentas 101..150)
 */
@Configuration
public class InteresesJobConfig {

    /** Tamano del lote: cada 50 filas se hace un COMMIT.
     *  Mas pequeno que el del Job 1 (200) a proposito: cuando un duplicado
     *  hace fallar un chunk, Spring Batch lo deshace y lo reprocesa fila a
     *  fila. Cuanto mas grande el chunk, mas caro sale ese reproceso. Con
     *  rechazos en fase WRITE, un chunk mas pequeno es mas barato de reparar. */
    private static final int CHUNK = 50;

    /** Particiones. Son 5 y no 4 para que el reparto de 50 cuentas salga en
     *  tramos exactos de 10 (101-110, 111-120, ...). */
    private static final int PARTICIONES = 5;

    /** Filas malas toleradas ANTES DE DAR EL STEP POR FALLIDO.
     *  OJO: el limite es POR StepExecution, es decir POR PARTICION. Con 5
     *  particiones el job entero tolera hasta 2500 omisiones, no 500. Como
     *  cada particion rechaza unas 43 filas, estamos muy por debajo. Lo que de
     *  verdad garantiza que no se perdio nada no es este numero sino la
     *  cuadratura final. */
    private static final int LIMITE_OMISIONES = 500;

    private static final String ARCHIVO = "data/intereses.csv";
    private static final String ARCHIVO_ORIGEN = "intereses.csv";
    private static final String TABLA_NEGOCIO = "banco.interes_calculado";

    /** Rango de cuentas que contiene el archivo. */
    private static final int CUENTA_MIN = 101;
    private static final int CUENTA_MAX = 150;

    /** Prefijo de los steps worker. Con el se filtran sus StepExecution para
     *  contar la entrada sin sumar tambien el agregado del manager. */
    private static final String PREFIJO_WORKER = "stepCalcularInteresesWorker";

    // ==================================================================
    // 1. PARTITIONER - reparte las cuentas 101..150 en 5 tramos.
    // ==================================================================
    @Bean
    public RangoCuentaPartitioner interesPartitioner() {
        return new RangoCuentaPartitioner(CUENTA_MIN, CUENTA_MAX);
    }

    // ==================================================================
    // 2. LECTOR - uno por particion.
    //
    //    @StepScope: el bean no se crea al arrancar la aplicacion sino cuando
    //    empieza el step, que es lo que permite inyectarle los valores de la
    //    particion en curso con #{stepExecutionContext[...]}. El "?: valor" de
    //    SpEL es el operador Elvis: si la clave no existe (step sin
    //    particionar) usa el valor por defecto, asi el mismo bean sirve para
    //    los dos casos.
    //
    //    El tipo de retorno es FiltroRangoCuentaReader (clase concreta) y no
    //    ItemReader: el step tiene que VER que implementa ItemStream para
    //    abrirlo y cerrarlo. Con ItemReader a secas el fichero no se abriria.
    // ==================================================================
    @Bean
    @StepScope
    public FiltroRangoCuentaReader<InteresRaw> interesReader(
            @Value("#{stepExecutionContext['cuentaMin'] ?: " + CUENTA_MIN + "}") Integer cuentaMin,
            @Value("#{stepExecutionContext['cuentaMax'] ?: " + CUENTA_MAX + "}") Integer cuentaMax,
            @Value("#{stepExecutionContext['esPrimera'] ?: 'true'}") String esPrimera,
            @Value("#{stepExecutionContext['esUltima'] ?: 'true'}") String esUltima,
            @Value("#{stepExecutionContext['partitionName'] ?: 'unica'}") String partitionName) {

        // El delegado lee el fichero ENTERO. El filtrado lo pone el envoltorio.
        FlatFileItemReader<InteresRaw> delegado = new FlatFileItemReaderBuilder<InteresRaw>()
                // NOMBRE UNICO POR PARTICION. No es cosmetico: el nombre es el
                // prefijo de las claves que el lector guarda en el
                // ExecutionContext para poder reanudarse. Si las 5 particiones
                // usaran el mismo nombre, se pisarian esas claves entre ellas y
                // un reinicio reanudaria cada una por donde iba otra.
                .name("interesReader-" + partitionName)
                .resource(new ClassPathResource(ARCHIVO))
                .linesToSkip(1)                 // la cabecera
                .delimited().delimiter(",")
                .names("cuenta_id", "nombre", "saldo", "edad", "tipo")
                .fieldSetMapper(fs -> new InteresRaw(
                        fs.readString("cuenta_id"),
                        fs.readString("nombre"),
                        fs.readString("saldo"),
                        fs.readString("edad"),
                        fs.readString("tipo")))
                .build();

        // Las banderas viajan como String por el ExecutionContext (no tiene
        // putBoolean); aqui se reconvierten.
        boolean primera = Boolean.parseBoolean(esPrimera);
        boolean ultima = Boolean.parseBoolean(esUltima);

        return new FiltroRangoCuentaReader<>(
                delegado,
                InteresRaw::cuentaId,
                // La regla de filtrado es LA MISMA FUNCION que usa el
                // partitioner para repartir. Que sean el mismo codigo es lo que
                // garantiza que toda fila tenga exactamente un reclamante.
                clave -> RangoCuentaPartitioner.reclama(clave, cuentaMin, cuentaMax, primera, ultima));
    }

    // ==================================================================
    // 3. PROCESADOR - normaliza, clasifica y calcula. @StepScope para poder
    //    leer el jobExecutionId y los JobParameters, que no existen todavia
    //    cuando arranca la aplicacion.
    // ==================================================================
    @Bean
    @StepScope
    public InteresProcessor interesProcessor(
            NormalizadorTexto normalizadorTexto,
            NormalizadorMonto normalizadorMonto,
            CalculadoraInteres calculadoraInteres,
            PeriodoIntereses periodoIntereses,
            // Se inyecta el parametro CRUDO (puede llegar null si no se paso
            // --periodo) y quien decide el valor final es PeriodoIntereses.
            // Deliberadamente NO se pone aqui un "?: '2024-01'" con el operador
            // Elvis: eso escribiria el valor por defecto en un SEGUNDO sitio, y
            // el dia que cambiara habria que acordarse de tocar los dos. El
            // defecto vive en una sola constante.
            @Value("#{jobParameters['periodo']}") String periodoCrudo,
            @Value("#{stepExecution.jobExecutionId}") Long jobExecutionId) {

        // El periodo se resuelve por PeriodoIntereses, igual que en los dos
        // tasklets. Es la unica forma de garantizar que los tres coinciden.
        return new InteresProcessor(normalizadorTexto, normalizadorMonto, calculadoraInteres,
                periodoIntereses.resolver(periodoCrudo), jobExecutionId);
    }

    // ==================================================================
    // 4. ESCRITOR - inserta el lote en una sola llamada. Es thread-safe, asi
    //    que las 5 particiones pueden compartir la misma instancia.
    //
    //    FIJATE EN LO QUE NO ESTA: saldo_final NO aparece en la lista de
    //    columnas. Es GENERATED ALWAYS AS (saldo_inicial + interes) STORED, y
    //    si se incluyera, PostgreSQL rechazaria el INSERT ENTERO con
    //    "cannot insert a non-DEFAULT value into column saldo_final".
    //    Tampoco aparecen id (BIGSERIAL) ni creado_en (DEFAULT now()).
    // ==================================================================
    @Bean
    public JdbcBatchItemWriter<InteresCalculado> interesWriter(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<InteresCalculado>()
                .dataSource(dataSource)
                .sql("""
                     INSERT INTO banco.interes_calculado
                         (periodo, cuenta_id, nombre, nombre_original, edad, edad_original,
                          tipo, tipo_original, saldo_inicial, saldo_original, tasa, interes,
                          estado, anomalias, numero_linea, job_execution_id)
                     VALUES
                         (:periodo, :cuentaId, :nombre, :nombreOriginal, :edad, :edadOriginal,
                          :tipo, :tipoOriginal, :saldoInicial, :saldoOriginal, :tasa, :interes,
                          :estado, :anomalias, :numeroLinea, :jobExecutionId)
                     """)
                // beanMapped() resuelve :cuentaId llamando a getCuentaId().
                // Por eso InteresCalculado es una clase con getters JavaBean y
                // no un record: un record expone cuentaId() y esto fallaria en
                // tiempo de EJECUCION.
                .beanMapped()
                .build();
    }

    // ==================================================================
    // 5. LISTENER DE RECHAZOS - el dead letter.
    //
    //    @StepScope A PROPOSITO: guarda en campos el nombre del step en curso,
    //    y con 5 particiones a la vez una instancia compartida se pisaria a si
    //    misma y los rechazos quedarian atribuidos a la particion equivocada.
    //
    //    Se le pasa el PlatformTransactionManager para que el INSERT del dead
    //    letter vaya en transaccion PROPIA (REQUIRES_NEW). Aqui eso es
    //    CRITICO, mas que en el Job 1: un skip en fase WRITE ocurre DESPUES de
    //    que el chunk haya hecho rollback, asi que sin transaccion propia los
    //    5 DUPLICADO se irian por el desague junto con el chunk y la cuadratura
    //    daria 784 + 211 = 995. Ver el comentario largo de RechazoListener.
    // ==================================================================
    @Bean
    @StepScope
    public RechazoListener<InteresRaw, InteresCalculado> rechazoListenerIntereses(
            JdbcTemplate jdbcTemplate, PlatformTransactionManager transactionManager) {
        return new RechazoListener<>(jdbcTemplate, transactionManager, ARCHIVO_ORIGEN);
    }

    // ==================================================================
    // 6. WORKER - el step que hace el trabajo real, una vez por particion.
    // ==================================================================
    @Bean
    public Step stepCalcularInteresesWorker(
            JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            FiltroRangoCuentaReader<InteresRaw> interesReader,
            InteresProcessor interesProcessor,
            JdbcBatchItemWriter<InteresCalculado> interesWriter,
            RechazoListener<InteresRaw, InteresCalculado> rechazoListenerIntereses,
            ParticionListener particionListener,
            SkipPolicy skipPolicyBancoXyz,
            RetryPolicy retryPolicyInfraestructura,
            BackOffPolicy backOffExponencial,
            ReintentoRetryListener reintentoRetryListener,
            ChunkErrorListener chunkErrorListener) {

        // Se guarda el FaultTolerantStepBuilder en una variable ANTES de
        // encadenar. Motivo (documentado en detalle en TransaccionesJobConfig):
        // .listener(StepExecutionListener) devuelve AbstractTaskletStepBuilder,
        // que YA NO tiene la sobrecarga listener(RetryListener). Si se
        // encadenara todo seguido, la llamada con el RetryListener se
        // resolveria contra listener(Object), que solo busca anotaciones, y el
        // listener NO SE REGISTRARIA. Compila, no avisa, y te deja sin
        // auditoria de reintentos.
        var tolerante = new StepBuilder("stepCalcularInteresesWorker", jobRepository)
                .<InteresRaw, InteresCalculado>chunk(CHUNK, transactionManager)
                .reader(interesReader)
                .processor(interesProcessor)
                .writer(interesWriter)
                .faultTolerant();

        tolerante.listener((RetryListener) reintentoRetryListener);

        return tolerante

                // ---- OMISION (datos sucios) -------------------------------
                // La misma politica que el Job 1, ahora con DuplicateKeyException
                // dentro: un duplicado es un dato repetido, no un fallo de la
                // base. NO se combina con .skip()/.skipLimit(): mezclar los dos
                // modelos hace que Spring los una con un OR y el veto propio
                // quede anulado.
                .skipPolicy(skipPolicyBancoXyz)

                // ---- REINTENTO (infraestructura) --------------------------
                // Modelo B puro: politica ya armada, sin .retry()/.retryLimit().
                // DuplicateKeyException no esta en el mapa, y el valor por
                // defecto del mapa es false, asi que NO se reintenta: reintentar
                // una fila repetida fallaria las tres veces igual.
                .retryPolicy(retryPolicyInfraestructura)
                .backOffPolicy(backOffExponencial)

                // Un dato sucio detectado por el processor no es un fallo de
                // base de datos: no hace falta deshacer el lote entero por el.
                //
                // OJO: aqui NO se anade noRollback para DuplicateKeyException, y
                // es deliberado. Ese error SI lo produce la base, y cuando
                // PostgreSQL aborta una sentencia, la transaccion queda en
                // estado invalido: hay que deshacerla si o si. Marcarla como
                // "no rollback" dejaria la conexion inservible para el resto
                // del chunk. El rollback y el reproceso fila a fila son
                // exactamente el mecanismo que aisla al duplicado de sus 49
                // companeros de lote, que se reescriben sin problema.
                .noRollback(cl.duoc.bancoxyz.exception.RegistroInvalidoException.class)

                // ---- LISTENERS --------------------------------------------
                // Los casts NO son decorativos: rechazoListenerIntereses
                // implementa dos interfaces y sin cast el compilador no sabe a
                // que sobrecarga de .listener() te refieres.
                .listener((SkipListener<InteresRaw, InteresCalculado>) rechazoListenerIntereses)
                .listener((StepExecutionListener) rechazoListenerIntereses)
                .listener((StepExecutionListener) particionListener)
                .listener((ChunkListener) chunkErrorListener)
                // ---- REINICIO DE LA MISMA JobInstance ----------------------
                // Igual que en el Job 1: la bandera del WORKER es la que recibe
                // el SimpleStepExecutionSplitter (PartitionStepBuilder.build()
                // hace allow = step.isAllowStartIfComplete() y pisa la del
                // manager), asi que sin ella un reinicio solo relanzaria las
                // particiones FAILED mientras la preparacion ya vacio la tabla
                // entera: recarga parcial y cuadratura "OK" sobre datos a
                // medias. Ver el comentario largo de
                // TransaccionesJobConfig.stepCargarTransaccionesWorker.
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 7. MANAGER - el PartitionStep. No procesa datos: reparte y lanza.
    //
    //    .taskExecutor(...) es OBLIGATORIO. Sin el, Spring usa un ejecutor
    //    SINCRONO sin avisar y las particiones corren una detras de otra:
    //    tendrias un "particionado" que en realidad es secuencial.
    //
    //    NOTA HONESTA SOBRE EL DIMENSIONAMIENTO: gridSize son 5 pero el pool
    //    (compartido con el Job 1) tiene 4 hilos, asi que la quinta particion
    //    espera a que se libere alguno. No es un defecto silencioso: la cola
    //    del pool es ilimitada, asi que ninguna tarea se rechaza, y el efecto
    //    se ve en los tiempos por particion del log. Se prefiere no tocar
    //    TaskExecutorConfig para no arriesgar el Job 1, que ya esta verificado.
    // ==================================================================
    @Bean
    public Step stepCalcularInteresesManager(
            JobRepository jobRepository,
            Step stepCalcularInteresesWorker,
            RangoCuentaPartitioner interesPartitioner,
            ThreadPoolTaskExecutor poolParticiones) {

        return new StepBuilder("stepCalcularInteresesManager", jobRepository)
                .partitioner(stepCalcularInteresesWorker.getName(), interesPartitioner)
                .step(stepCalcularInteresesWorker)
                .gridSize(PARTICIONES)
                .taskExecutor(poolParticiones)
                // ---- REINICIO DE LA MISMA JobInstance ----------------------
                // Pareja obligatoria del allowStartIfComplete del step de
                // preparacion: si la limpieza se repite en un reinicio, la
                // recarga tiene que repetirse tambien. Sin esto, SimpleStepHandler
                // salta este step por estar COMPLETED, la tabla queda vacia y el
                // job termina COMPLETED mintiendo. Ver el comentario largo de
                // TransaccionesJobConfig.stepCargarTransaccionesManager.
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 8. PREPARACION - limpieza idempotente del periodo.
    //
    //    allowStartIfComplete(true) y el DELETE resuelven cosas DISTINTAS:
    //      * el DELETE evita el choque contra uq_interes_posicion al relanzar
    //        el job con el mismo periodo (ejecucion NUEVA);
    //      * allowStartIfComplete permite que el step se vuelva a ejecutar al
    //        REINICIAR la misma JobInstance (por defecto un step COMPLETED se
    //        salta en el reinicio, y entonces la limpieza no ocurriria y el
    //        reinicio chocaria con las filas que dejo el intento anterior).
    //    Hacen falta los dos.
    // ==================================================================
    @Bean
    public Step stepPrepararIntereses(JobRepository jobRepository,
                                      PlatformTransactionManager transactionManager,
                                      JdbcTemplate jdbcTemplate,
                                      PeriodoIntereses periodoIntereses) {
        Tasklet limpieza = new LimpiezaInteresesTasklet(jdbcTemplate, periodoIntereses);

        return new StepBuilder("stepPrepararIntereses", jobRepository)
                // En Spring Batch 5.2.x la firma vigente es tasklet(tasklet, txManager);
                // tasklet(tasklet) a secas esta deprecada.
                .tasklet(limpieza, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 9. CONSOLIDACION - el GROUP BY que llena banco.cuenta.
    // ==================================================================
    @Bean
    public Step stepConsolidarSaldos(JobRepository jobRepository,
                                     PlatformTransactionManager transactionManager,
                                     JdbcTemplate jdbcTemplate,
                                     PeriodoIntereses periodoIntereses) {
        Tasklet consolidar = new ConsolidarSaldosTasklet(jdbcTemplate, periodoIntereses);

        return new StepBuilder("stepConsolidarSaldos", jobRepository)
                .tasklet(consolidar, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 10. CUADRATURA - hace FALLAR el job si se perdio alguna fila.
    //
    //     Se REUTILIZA CuadraturaTasklet tal cual, sin tocar ni una linea: ya
    //     estaba parametrizada (archivo, tabla, prefijo del worker) justo para
    //     esto. Es la ventaja de haberla escrito generica en el Job 1.
    //
    //     El nombre del step lleva el sufijo "Intereses" porque dos StepBuilder
    //     con el mismo nombre se confundirian entre si en BATCH_STEP_EXECUTION,
    //     y el Job 3 tendra el suyo.
    // ==================================================================
    @Bean
    public Step stepValidarCuadraturaIntereses(JobRepository jobRepository,
                                               PlatformTransactionManager transactionManager,
                                               ControlCargaDao controlCargaDao) {
        // El CSV de origen y su numero de lineas de cabecera se pasan para que la
        // cuadratura pueda comparar el CONTENIDO REAL de la tabla contra las filas
        // del fichero, y no solo contra lo que hizo esta ejecucion. Ver el javadoc
        // de CuadraturaTasklet, comprobacion (3).
        Tasklet cuadratura = new CuadraturaTasklet(controlCargaDao, ARCHIVO_ORIGEN,
                TABLA_NEGOCIO, PREFIJO_WORKER, new ClassPathResource(ARCHIVO), 1);

        return new StepBuilder("stepValidarCuadraturaIntereses", jobRepository)
                .tasklet(cuadratura, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 10.b VALIDACION DEL CONSOLIDADO - el gemelo del Job 3, que aqui faltaba.
    //
    //      CuadraturaTasklet (arriba) comprueba que no se perdio ninguna fila de
    //      ENTRADA. Este step comprueba algo distinto: que banco.cuenta es fiel a
    //      banco.interes_calculado. Sin el, un consolidado que se hubiera quedado
    //      con los saldos de una corrida anterior -o que hubiera consolidado una
    //      tabla de detalle vacia- terminaba COMPLETED y en silencio.
    //
    //      Va DESPUES de la cuadratura porque son controles independientes y
    //      conviene que el mas barato y general (no perder filas) hable primero.
    // ==================================================================
    @Bean
    public Step stepValidarConsolidadoIntereses(JobRepository jobRepository,
                                                PlatformTransactionManager transactionManager,
                                                JdbcTemplate jdbcTemplate,
                                                PeriodoIntereses periodoIntereses) {
        Tasklet validar = new ValidarConsolidadoInteresesTasklet(jdbcTemplate, periodoIntereses);

        return new StepBuilder("stepValidarConsolidadoIntereses", jobRepository)
                .tasklet(validar, transactionManager)
                .allowStartIfComplete(true)
                .build();
    }

    // ==================================================================
    // 11. JOB - flujo LINEAL. Arranca por la preparacion, nunca por el worker.
    //
    //     Se usa on("COMPLETED") entre steps y NO on("*"): el comodin casa
    //     tambien con FAILED, asi que un step roto seguiria hacia adelante y el
    //     job podria acabar COMPLETED mintiendo. Aqui basta con .next(), que ya
    //     implica "solo si el anterior fue bien".
    //
    //     RunIdIncrementer anade un parametro distinto en cada lanzamiento para
    //     poder ejecutar el job dos veces seguidas. Sin esto, la segunda vez
    //     reventaria con JobInstanceAlreadyCompleteException... y la segunda
    //     ejecucion es justo la que demuestra la idempotencia.
    // ==================================================================
    @Bean
    public Job jobInteresesMensuales(JobRepository jobRepository,
                                     Step stepPrepararIntereses,
                                     Step stepCalcularInteresesManager,
                                     Step stepConsolidarSaldos,
                                     Step stepValidarCuadraturaIntereses,
                                     Step stepValidarConsolidadoIntereses) {

        return new JobBuilder("jobInteresesMensuales", jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(stepPrepararIntereses)
                .next(stepCalcularInteresesManager)
                .next(stepConsolidarSaldos)
                .next(stepValidarCuadraturaIntereses)
                // El ultimo control, igual que en el Job 3: que el consolidado de
                // banco.cuenta sea reconstruible desde banco.interes_calculado.
                .next(stepValidarConsolidadoIntereses)
                .build();
    }
}
