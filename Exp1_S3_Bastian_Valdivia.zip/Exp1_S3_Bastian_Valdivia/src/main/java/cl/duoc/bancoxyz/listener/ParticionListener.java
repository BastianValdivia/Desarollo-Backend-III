package cl.duoc.bancoxyz.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

/**
 * Deja constancia en el log de QUE HILO ejecuta cada particion.
 *
 * No es decorativo: es la evidencia del criterio 4. Si el particionado
 * estuviera mal configurado, todas las particiones saldrian con el MISMO
 * nombre de hilo (normalmente "main"), y eso significa que corren en serie.
 * Ver 4 nombres de hilo distintos es la prueba de que el paralelismo es real.
 */
public class ParticionListener implements StepExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(ParticionListener.class);

    @Override
    public void beforeStep(StepExecution stepExecution) {
        var ctx = stepExecution.getExecutionContext();
        log.info("PARTICION inicia | step={} | hilo={} | linesToSkip={} | maxItemCount={} | filas {}..{}",
                stepExecution.getStepName(),
                Thread.currentThread().getName(),
                ctx.containsKey("linesToSkip")  ? ctx.getInt("linesToSkip")  : "-",
                ctx.containsKey("maxItemCount") ? ctx.getInt("maxItemCount") : "-",
                ctx.containsKey("minValue")     ? ctx.getInt("minValue") + 1 : "-",
                ctx.containsKey("maxValue")     ? ctx.getInt("maxValue") + 1 : "-");
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        long ms = (stepExecution.getStartTime() != null && stepExecution.getEndTime() != null)
                ? java.time.Duration.between(stepExecution.getStartTime(), stepExecution.getEndTime()).toMillis()
                : -1;
        log.info("PARTICION termina | step={} | hilo={} | leidas={} escritas={} omitidas={} | {} ms",
                stepExecution.getStepName(),
                Thread.currentThread().getName(),
                stepExecution.getReadCount(),
                stepExecution.getWriteCount(),
                stepExecution.getSkipCount(),
                ms);
        return stepExecution.getExitStatus();
    }
}
