package cl.duoc.bancoxyz.domain;

import org.springframework.batch.item.ItemCountAware;

/**
 * La fila de intereses.csv TAL CUAL viene, con TODOS los campos como String.
 *
 * Mismo criterio que TransaccionRaw en el Job 1: si le pidieramos al lector que
 * convirtiera "saldo" a BigDecimal o "edad" a int, las filas con el campo vacio
 * reventarian con FlatFileParseException DENTRO del lector, y una fila que
 * muere en la fase READ ya no se puede clasificar ni explicar. Leemos crudo y
 * decidimos despues, en el processor, que es donde vive la logica de negocio.
 *
 * Es clase y no `record` porque implementa ItemCountAware, y esa interfaz
 * exige un campo mutable (setItemCount).
 *
 * ItemCountAware es un gancho de Spring Batch: si el objeto que devuelve el
 * lector implementa esta interfaz, el propio lector le inyecta el numero de
 * orden del elemento leido. Evita llevar un contador a mano, que ademas se
 * romperia con varias particiones leyendo a la vez.
 */
public class InteresRaw implements ItemCountAware {

    private final String cuentaId;
    private final String nombre;
    private final String saldo;
    private final String edad;
    private final String tipo;

    /** Lo rellena el propio FlatFileItemReader al leer. El primero es el 1. */
    private int itemCount;

    public InteresRaw(String cuentaId, String nombre, String saldo, String edad, String tipo) {
        this.cuentaId = cuentaId;
        this.nombre = nombre;
        this.saldo = saldo;
        this.edad = edad;
        this.tipo = tipo;
    }

    // Getters con estilo corto (al modo de los records). Esta clase solo entra
    // al processor, nunca al writer, asi que NO necesita getters JavaBean:
    // el que si los necesita es InteresCalculado, porque lo mapea .beanMapped().
    public String cuentaId() { return cuentaId; }
    public String nombre()   { return nombre; }
    public String saldo()    { return saldo; }
    public String edad()     { return edad; }
    public String tipo()     { return tipo; }

    @Override
    public void setItemCount(int count) {
        this.itemCount = count;
    }

    /**
     * Posicion de esta fila DENTRO DEL ARCHIVO (la primera fila de datos es la 1).
     *
     * OJO A LA DIFERENCIA CON EL JOB 1. Alli cada particion leia un TROZO del
     * fichero (linesToSkip distinto por particion), asi que itemCount era una
     * posicion relativa y habia que sumarle el desplazamiento de la particion
     * para obtener la linea fisica.
     *
     * Aqui NO: el particionado del Job 2 es POR cuenta_id, y para conseguirlo
     * cada particion lee el fichero ENTERO y descarta las filas que no son
     * suyas (ver FiltroRangoCuentaReader). Como el delegado que cuenta es el
     * FlatFileItemReader, que lee todas las filas, este numero YA es la
     * posicion real dentro del archivo. La linea fisica del CSV es
     * itemCount + 1, por la cabecera.
     */
    public int itemCount() {
        return itemCount;
    }

    /**
     * Reconstruye la linea del CSV de la que salio esta fila.
     *
     * No es un toString "de adorno": es EXACTAMENTE lo que RechazoListener
     * guarda en la columna linea_cruda cuando se omite una fila en la fase
     * PROCESS (las 211 de SALDO_AUSENTE). Sin el, el dead letter diria
     * "InteresRaw@6f2b958e" y no serviria para auditar nada.
     */
    @Override
    public String toString() {
        return String.join(",", cuentaId, nombre, saldo, edad, tipo);
    }
}
