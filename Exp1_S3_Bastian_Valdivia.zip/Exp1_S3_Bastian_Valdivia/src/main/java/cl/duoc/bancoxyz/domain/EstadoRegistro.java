package cl.duoc.bancoxyz.domain;

/**
 * Los estados posibles de un registro ya procesado.
 * Un "enum" es una lista cerrada de valores permitidos, como un Enum de Python.
 *
 * VALIDA        -> la fila no tenía ningún defecto
 * ANOMALA_*     -> la fila es utilizable pero tiene algo raro que hay que REPORTAR
 *                  (ojo: NO se descarta; las anomalías son el producto del Job 1)
 */
public enum EstadoRegistro {
    VALIDA,
    ANOMALA_TIPO_DESCONOCIDO,
    ANOMALA_MONTO_NEGATIVO,
    ANOMALA_MONTO_CERO
}
