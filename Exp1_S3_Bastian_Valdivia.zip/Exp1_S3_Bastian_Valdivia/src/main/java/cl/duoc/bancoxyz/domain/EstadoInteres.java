package cl.duoc.bancoxyz.domain;

/**
 * Los estados posibles de una fila de intereses.csv YA PROCESADA.
 *
 * Un "enum" es una lista cerrada de valores permitidos: el compilador impide
 * escribir uno que no este aqui. Es la version en Java de un CHECK de SQL, y
 * de hecho estos cinco valores son EXACTAMENTE los que acepta la restriccion
 * ck_int_estado de banco.interes_calculado. Que las dos listas coincidan no es
 * casualidad: si el codigo pudiera producir un sexto valor, el INSERT
 * reventaria en tiempo de ejecucion en vez de en tiempo de compilacion.
 *
 * POR QUE UN ENUM NUEVO Y NO AMPLIAR EstadoRegistro (el del Job 1)
 * -----------------------------------------------------------------
 * Tentacion natural: "ya tengo un enum de estados, le anado tres valores".
 * Mala idea, por dos razones:
 *
 *   1. Cada tabla tiene su propio CHECK. EstadoRegistro refleja el de
 *      banco.transaccion (VALIDA, TIPO_DESCONOCIDO, MONTO_NEGATIVO,
 *      MONTO_CERO) y este refleja el de banco.interes_calculado. Un unico
 *      enum compartido permitiria asignarle a una transaccion el estado
 *      ANOMALA_EDAD_AUSENTE, que no significa nada y que la base rechazaria.
 *      Tipos separados = errores imposibles, no errores detectados.
 *
 *   2. El Job 1 ya funciona y esta verificado (785+215=1000). Tocar un tipo
 *      que el Job 1 usa es arriesgar una regresion a cambio de nada.
 *
 * Es el mismo criterio por el que en una base de datos no se comparte una
 * tabla de "codigos" entre dominios que no tienen nada que ver.
 *
 * Reparto verificado sobre intereses.csv (docs/analisis-datos.md seccion 6):
 *   VALIDA 303 | TIPO_DESCONOCIDO 260 | EDAD_AUSENTE 101
 *   | EDAD_FUERA_RANGO 96 | NOMBRE_DESCONOCIDO 24   ->  784 filas de negocio
 */
public enum EstadoInteres {

    /** La fila no tenia ningun defecto. */
    VALIDA,

    /** El tipo de cuenta no es AHORRO, PRESTAMO ni HIPOTECA (viene '-1' o 'unknown'). */
    ANOMALA_TIPO_DESCONOCIDO,

    /** La columna edad venia vacia. Se guarda como NULL. */
    ANOMALA_EDAD_AUSENTE,

    /** La edad existe pero no es creible para un titular (fuera de 18..99: 100 y 150). */
    ANOMALA_EDAD_FUERA_RANGO,

    /** El titular figura como 'Unknown'. */
    ANOMALA_NOMBRE_DESCONOCIDO
}
