package cl.duoc.bancoxyz.support;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Optional;

/**
 * Convierte el monto del CSV a BigDecimal.
 *
 * BigDecimal y NO double: con double, 0.1 + 0.2 no da 0.3 exacto. En dinero eso
 * es inaceptable y un evaluador de backend lo detecta de inmediato.
 * Es el mismo motivo por el que en Spark usarías DecimalType y no DoubleType.
 *
 * Distinguimos "vacío" de "no numérico" porque son motivos de rechazo distintos
 * y hay que poder contarlos por separado.
 */
@Component
public class NormalizadorMonto {

    public Resultado normalizar(String crudo) {
        if (crudo == null || crudo.isBlank()) {
            return new Resultado(Optional.empty(), true, false);
        }
        try {
            return new Resultado(Optional.of(new BigDecimal(crudo.trim())), false, false);
        } catch (NumberFormatException e) {
            return new Resultado(Optional.empty(), false, true);
        }
    }

    public record Resultado(Optional<BigDecimal> valor, boolean ausente, boolean noNumerico) {
    }
}
