package cl.duoc.bancoxyz.tasklet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.UncheckedIOException;

/**
 * PASO DE PREPARACION del Job 3. Hace dos cosas sin relacion aparente entre si,
 * pero las dos son condiciones para que el resto del job funcione.
 *
 * ------------------------------------------------------------------------
 * (a) CREAR EL DIRECTORIO results/
 * ------------------------------------------------------------------------
 * FlatFileItemWriter NO crea los directorios padre de su fichero de salida.
 * Si results/ no existe, el writer falla al abrirse y el step de exportacion
 * revienta con un error que parece de permisos y no lo es. Es el motivo mas
 * frecuente de fallo de un step de exportacion, y cuesta una linea evitarlo.
 *
 * Se hace AQUI y no en el writer porque el writer se construye una vez por step
 * y esta comprobacion es una precondicion del JOB entero: el sitio natural de
 * una precondicion es el primer step.
 *
 * ------------------------------------------------------------------------
 * (b) BORRAR LO QUE DEJO LA EJECUCION ANTERIOR (idempotencia)
 * ------------------------------------------------------------------------
 * Sin esto, la SEGUNDA ejecucion del job daria 1904 filas en la cuadratura en
 * vez de 1000, y pareceria un descuadre gravisimo cuando en realidad solo
 * estaria sumando dos corridas.
 *
 * El motivo exacto: la vista banco.v_cuadratura cuenta
 *
 *     SELECT COUNT(*) FROM banco.movimiento_anual
 *
 * SIN filtrar por job_execution_id. Es deliberado (esa vista responde "que hay
 * ahora mismo en la tabla"), pero obliga a que la tabla contenga UNA sola
 * corrida. Eso es el patron "delete and reload" de las cargas de un data
 * warehouse: correr el proceso dos veces deja el mismo resultado que correrlo
 * una. Eso es la IDEMPOTENCIA.
 *
 * ------------------------------------------------------------------------
 * LOS TRES DELETE, UNO A UNO, Y POR QUE EL SEGUNDO LLEVA WHERE
 * ------------------------------------------------------------------------
 *   1. DELETE FROM banco.movimiento_anual
 *      Sin WHERE, y es CORRECTO: esta tabla es propiedad EXCLUSIVA del Job 3.
 *      Ningun otro job escribe en ella, asi que vaciarla no puede danar a nadie.
 *
 *   2. DELETE FROM banco.registro_rechazado WHERE archivo_origen = 'cuentas_anuales.csv'
 *      EL WHERE ES OBLIGATORIO Y NO ES OPCIONAL. El dead letter lo COMPARTEN
 *      los tres jobs. Sin ese WHERE, este tasklet borraria los 215 rechazos de
 *      transacciones.csv y los 216 de intereses.csv, y las cuadraturas de los
 *      Jobs 1 y 2 dejarian de cerrar. Seria destruir el trabajo ya entregado
 *      desde el job nuevo, que es exactamente el fallo que la Regla de Oro
 *      pretende hacer imposible.
 *
 *   3. DELETE FROM banco.estado_cuenta_anual
 *      Sin WHERE, tambien propiedad exclusiva del Job 3. Podria parecer
 *      innecesario, porque el INSERT del tasklet de consolidacion lleva
 *      ON CONFLICT DO UPDATE y reescribiria las 20 filas igualmente. Se hace de
 *      todos modos por una razon concreta: si una corrida futura produjera
 *      MENOS cuentas que la anterior (por ejemplo con un fichero recortado),
 *      el ON CONFLICT actualizaria las que coinciden pero dejaria las sobrantes
 *      de la corrida vieja como fantasmas, y el control "deben ser 20 filas"
 *      pasaria sin que los datos fueran de esta ejecucion. Vaciar primero hace
 *      que la tabla no pueda contener nada que este job no haya escrito hoy.
 *
 * ------------------------------------------------------------------------
 * LO QUE ESTE TASKLET NO TOCA
 * ------------------------------------------------------------------------
 *   banco.control_carga -> NUNCA. Es el historial de evidencia de TODAS las
 *       ejecuciones de los tres jobs, clavado por job_execution_id. Es lo que
 *       permite reconstruir que paso en una corrida pasada aunque las tablas de
 *       negocio ya se hayan recargado.
 *   Las tablas de los Jobs 1 y 2 -> tampoco, evidentemente.
 */
public class PrepararAnualesTasklet implements Tasklet {

    private static final Logger log = LoggerFactory.getLogger(PrepararAnualesTasklet.class);

    /** El WHERE del segundo DELETE. Es la frontera que protege a los otros jobs. */
    private static final String ARCHIVO = "cuentas_anuales.csv";

    private final JdbcTemplate jdbc;
    private final Path directorioSalida;

    public PrepararAnualesTasklet(JdbcTemplate jdbc, Path directorioSalida) {
        this.jdbc = jdbc;
        this.directorioSalida = directorioSalida;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // ---- (a) el directorio del informe -------------------------------
        // createDirectories NO falla si ya existe (a diferencia de createDirectory,
        // en singular, que lanzaria FileAlreadyExistsException en la segunda
        // corrida). Es justo la semantica que hace falta en un paso idempotente.
        try {
            Files.createDirectories(directorioSalida);
            log.info("Preparacion: directorio de salida listo en {}",
                    directorioSalida.toAbsolutePath());
        } catch (IOException e) {
            // Se envuelve en una excepcion no comprobada para que el step falle
            // de verdad. Tragarse este error dejaria que el job siguiera hasta
            // reventar mucho mas tarde, en la exportacion, con un mensaje que ya
            // no apuntaria a la causa.
            throw new UncheckedIOException(
                    "No se pudo crear el directorio de salida " + directorioSalida, e);
        }

        // ---- (b) limpieza idempotente ------------------------------------
        int movimientos = jdbc.update("DELETE FROM banco.movimiento_anual");
        log.info("Preparacion: {} filas borradas de banco.movimiento_anual", movimientos);

        // EL WHERE PROTEGE A LOS JOBS 1 Y 2. Ver el comentario de la clase.
        int rechazos = jdbc.update(
                "DELETE FROM banco.registro_rechazado WHERE archivo_origen = ?", ARCHIVO);
        log.info("Preparacion: {} filas borradas de banco.registro_rechazado (archivo_origen={})",
                rechazos, ARCHIVO);

        int estados = jdbc.update("DELETE FROM banco.estado_cuenta_anual");
        log.info("Preparacion: {} filas borradas de banco.estado_cuenta_anual", estados);

        log.info("Preparacion: banco.control_carga NO se toca (es el historial de evidencia)");

        // FINISHED = "he terminado, no me vuelvas a llamar". Con CONTINUABLE,
        // Spring Batch ejecutaria el tasklet en bucle.
        return RepeatStatus.FINISHED;
    }
}
