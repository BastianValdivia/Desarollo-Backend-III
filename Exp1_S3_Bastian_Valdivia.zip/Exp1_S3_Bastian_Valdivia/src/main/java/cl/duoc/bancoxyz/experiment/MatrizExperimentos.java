package cl.duoc.bancoxyz.experiment;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Que celdas se miden y en que orden.
 *
 * ------------------------------------------------------------------------
 * POR QUE ESCALONADO Y NO FACTORIAL COMPLETO
 * ------------------------------------------------------------------------
 * El cruce completo seria 4 chunks x 3 paralelismos x 3 estrategias x 2
 * escalas = 72 celdas, y con 7 repeticiones cada una, 504 ejecuciones. Eso no
 * cabe en el tiempo disponible, y la mayor parte del cruce no aporta
 * informacion: el efecto del chunkSize se mide mucho mejor SIN ruido de
 * paralelismo.
 *
 * El diseno escalonado es el clasico de "un factor cada vez":
 *
 *   F0  baseline secuencial: chunkSize in {10, 50, 100, 500}, 1 hilo.
 *       Aisla el efecto del tamano de lote. De aqui sale chunk*.
 *   F1  paralelismo: fijado chunk*, se cruzan {MULTI_THREAD, PARTICIONADO}
 *       x {2, 4, 8}. Aisla el efecto del numero de hilos/particiones.
 *   F2  confirmacion cruzada: la mejor celda de F1 se vuelve a medir con los
 *       DOS mejores chunkSize de F0.
 *
 * F2 existe para responder a la critica obvia del diseno escalonado:
 * "asumiste que chunkSize y paralelismo no interactuan". Si el mejor chunk en
 * paralelo fuera otro distinto que en secuencial, F2 lo destapa; si coincide,
 * queda demostrado que la suposicion era razonable.
 *
 * RESULTADO: 4 + 6 + 2 = 12 celdas por escala, 24 en total.
 */
@Component
@Profile("experiment")
public class MatrizExperimentos {

    /** Primer parametro barrido: 4 niveles. */
    public static final int[] CHUNKS = {10, 50, 100, 500};

    /** Segundo parametro barrido: 3 niveles. Cubre por debajo, en y por encima de los 8 nucleos. */
    public static final int[] PARALELISMOS = {2, 4, 8};

    /** Fase 0 - solo secuencial: aisla el efecto del chunkSize. */
    public List<CasoExperimento> fase0(int filas) {
        List<CasoExperimento> casos = new ArrayList<>();
        for (int c : CHUNKS) {
            casos.add(new CasoExperimento(EstrategiaEscalado.SECUENCIAL, 1, c, filas, "F0-baseline"));
        }
        return casos;
    }

    /** Fase 1 - necesita el chunk ganador de la fase 0. */
    public List<CasoExperimento> fase1(int filas, int mejorChunk) {
        List<CasoExperimento> casos = new ArrayList<>();
        for (EstrategiaEscalado e : List.of(EstrategiaEscalado.MULTI_THREAD,
                                            EstrategiaEscalado.PARTICIONADO)) {
            for (int p : PARALELISMOS) {
                casos.add(new CasoExperimento(e, p, mejorChunk, filas, "F1-paralelo"));
            }
        }
        return casos;
    }

    /** Fase 2 - confirmacion cruzada de la mejor celda de F1 contra otros chunks. */
    public List<CasoExperimento> fase2(int filas, EstrategiaEscalado mejorEstrategia,
                                       int mejorParalelismo, int... chunks) {
        return Arrays.stream(chunks)
                .mapToObj(c -> new CasoExperimento(mejorEstrategia, mejorParalelismo, c,
                                                   filas, "F2-confirmacion"))
                .toList();
    }
}
