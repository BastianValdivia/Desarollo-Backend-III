package cl.duoc.bancoxyz.reader;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemStreamReader;

import java.util.function.Function;
import java.util.function.Predicate;

/**
 * ENVOLTORIO de lectura que deja pasar solo las filas de SU particion.
 *
 * ------------------------------------------------------------------------
 * EL PROBLEMA QUE RESUELVE
 * ------------------------------------------------------------------------
 * El Job 2 se particiona por cuenta_id, pero un CSV no es una tabla: no tiene
 * indices y no se le puede decir "damelas WHERE cuenta_id BETWEEN 101 AND 110".
 * Un archivo plano solo se sabe leer de principio a fin.
 *
 * La solucion es la mas simple que funciona: cada particion lee el fichero
 * ENTERO y descarta lo que no es suyo. Este envoltorio hace exactamente eso,
 * envolviendo al FlatFileItemReader de verdad (el "delegado").
 *
 * COSTE HONESTO: con 5 particiones el fichero se lee 5 veces (O(n*p)). Para
 * 1000 filas es irrelevante. Para millones habria que trocear el fichero antes
 * o cargarlo a una tabla temporal y particionar por columna. Es el mismo
 * compromiso que ya documenta LineRangePartitioner en el Job 1.
 *
 * ------------------------------------------------------------------------
 * LAS DOS MECANICAS QUE HAY QUE HACER BIEN O TODO FALLA EN SILENCIO
 * ------------------------------------------------------------------------
 *
 * 1) IMPLEMENTA ItemStreamReader, NO ItemReader A SECAS.
 *    ItemStreamReader = ItemReader + ItemStream (open/update/close). Un
 *    FlatFileItemReader necesita que ALGUIEN le llame a open() para abrir el
 *    fichero y a close() para cerrarlo, y el step solo hace esas llamadas si ve
 *    que su reader implementa ItemStream. Si esta clase implementara solo
 *    ItemReader, el step no abriria nada y la primera lectura reventaria con
 *    "Reader must be open before it can be read". Ademas update() es lo que
 *    guarda la posicion en el ExecutionContext: sin delegarlo, un reinicio
 *    empezaria el fichero desde cero y duplicaria lo ya escrito.
 *    Por eso los tres metodos se DELEGAN uno a uno.
 *
 * 2) EL BUCLE HACE `continue`, NUNCA `return`.
 *    Este es el bug clasico de esta clase y no da ningun error:
 *
 *        while ((item = delegado.read()) != null) {
 *            if (!esMia(item)) return null;   // <-- CATASTROFE
 *            return item;
 *        }
 *
 *    Devolver null significa "FIN DE LOS DATOS" para Spring Batch. Con ese
 *    codigo, la particion terminaria en la PRIMERA fila ajena -la segunda linea
 *    del archivo- y procesaria 1 fila en vez de 200. El job diria COMPLETED,
 *    sin errores, con 800 filas menos en la base.
 *    Lo correcto es SEGUIR LEYENDO (continue implicito en el while) hasta
 *    encontrar una fila propia, y devolver null SOLO cuando el delegado
 *    devuelve null, que es el verdadero fin de fichero.
 *
 * ------------------------------------------------------------------------
 * EFECTO SECUNDARIO DESEADO: READ_COUNT SUMA 1000 Y FILTER_COUNT ES 0
 * ------------------------------------------------------------------------
 * El step cuenta como "leida" cada llamada a read() que devuelve algo distinto
 * de null, y aqui quien responde es este envoltorio, no el delegado. Asi que
 * cada particion suma solo SUS filas y las 5 juntas dan 1000 exactas.
 *
 * Y filter_count queda en 0, que es justo lo que se quiere: filtrar aqui NO es
 * lo mismo que filtrar en el processor. Si el descarte se hiciera devolviendo
 * null desde el ItemProcessor, esas filas contarian como FILTRADAS y la
 * cuadratura tendria que explicar 4000 filas filtradas de 5000 leidas. Al
 * descartarlas en la lectura, sencillamente nunca entran, y CuadraturaTasklet
 * ve la verdad: 1000 de entrada, 784 de negocio, 216 rechazadas, 0 filtradas.
 *
 * ------------------------------------------------------------------------
 * POR QUE ES GENERICO
 * ------------------------------------------------------------------------
 * No sabe nada de intereses ni de cuentas: recibe el delegado, una funcion que
 * extrae la clave de reparto del item, y un predicado que dice si esa clave es
 * suya. El Job 3 puede reutilizarlo tal cual cambiando esas dos funciones.
 *
 * @param <T> el tipo de fila cruda que devuelve el delegado
 */
public class FiltroRangoCuentaReader<T> implements ItemStreamReader<T> {

    /** El lector de verdad: lee el fichero ENTERO, de la primera a la ultima fila. */
    private final ItemStreamReader<T> delegado;

    /** Saca del item la clave por la que se reparte (aqui, el cuenta_id crudo). */
    private final Function<T, String> extractorClave;

    /** Responde "esta fila es de mi particion". */
    private final Predicate<String> reclamaEstaParticion;

    public FiltroRangoCuentaReader(ItemStreamReader<T> delegado,
                                   Function<T, String> extractorClave,
                                   Predicate<String> reclamaEstaParticion) {
        this.delegado = delegado;
        this.extractorClave = extractorClave;
        this.reclamaEstaParticion = reclamaEstaParticion;
    }

    /**
     * Devuelve la siguiente fila QUE PERTENECE a esta particion, o null cuando
     * el fichero se ha terminado de verdad.
     *
     * Fijate en la forma del bucle: no hay ningun `return null` dentro. El
     * unico null que sale de aqui es el de la ultima linea, y solo se alcanza
     * cuando el delegado ya ha devuelto null.
     */
    @Override
    public T read() throws Exception {
        T item;
        while ((item = delegado.read()) != null) {
            String clave = extractorClave.apply(item);
            if (reclamaEstaParticion.test(clave)) {
                return item;            // es mia: la entrego
            }
            // No es mia: NO devuelvo nada, sigo leyendo. El `continue` esta
            // implicito aqui, y es toda la diferencia entre procesar 200 filas
            // y procesar 1. Ver el comentario largo de la clase.
        }
        return null;                    // fin de fichero real
    }

    // ------------------------------------------------------------------
    // Los tres metodos de ItemStream: se delegan tal cual.
    // Sin open() el fichero nunca se abre; sin update() no hay reinicio
    // posible; sin close() el descriptor de fichero queda abierto.
    // ------------------------------------------------------------------

    @Override
    public void open(ExecutionContext executionContext) throws ItemStreamException {
        delegado.open(executionContext);
    }

    @Override
    public void update(ExecutionContext executionContext) throws ItemStreamException {
        delegado.update(executionContext);
    }

    @Override
    public void close() throws ItemStreamException {
        delegado.close();
    }
}
