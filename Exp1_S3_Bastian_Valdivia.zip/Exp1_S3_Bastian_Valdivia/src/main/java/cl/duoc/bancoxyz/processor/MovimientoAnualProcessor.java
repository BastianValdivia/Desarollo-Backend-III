package cl.duoc.bancoxyz.processor;

import cl.duoc.bancoxyz.domain.EstadoMovimiento;
import cl.duoc.bancoxyz.domain.MovimientoAnual;
import cl.duoc.bancoxyz.domain.MovimientoAnualRaw;
import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import cl.duoc.bancoxyz.support.NormalizadorFecha;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import org.springframework.batch.item.ItemProcessor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * EL CORAZON DEL JOB 3: convierte una fila cruda del CSV en una fila de negocio,
 * o la RECHAZA si es irrecuperable.
 *
 * ------------------------------------------------------------------------
 * LAS DOS SALIDAS POSIBLES, Y POR QUE NUNCA HAY UNA TERCERA
 * ------------------------------------------------------------------------
 *   1. devuelve un MovimientoAnual     -> la fila va a banco.movimiento_anual
 *   2. lanza RegistroInvalidoException -> la fila va al dead letter
 *
 * Lo que este processor NO hace JAMAS es devolver null. Devolver null en Spring
 * Batch significa "filtra esta fila", y la fila desaparece: no va a negocio, no
 * va a rechazos, solo incrementa un contador (filterCount) que nadie mira. Eso
 * romperia la REGLA DE ORO (entrada = negocio + rechazos) y, peor, la romperia
 * en SILENCIO. Por eso toda fila sale por una de las dos puertas y filterCount
 * debe quedar en 0.
 *
 * ------------------------------------------------------------------------
 * RECHAZO (excluye la fila) vs ANOMALIA (la fila entra, marcada)
 * ------------------------------------------------------------------------
 * Es la distincion central del diseno, y la frontera es esta: se RECHAZA cuando
 * el dato es IRRECUPERABLE, es decir, cuando no se puede construir una fila que
 * respete las restricciones de la tabla. Sin monto no hay importe que guardar y
 * la columna monto es NOT NULL: no hay nada que inventar, es rechazo. En cambio
 * un monto negativo SI se puede guardar (en valor absoluto, con su anomalia
 * anotada): la fila es util para el estado de cuenta aunque el dato venga sucio.
 *
 * Rechazar de menos infla los totales con basura; rechazar de mas pierde
 * informacion que el negocio necesita.
 *
 * ------------------------------------------------------------------------
 * ORDEN DE LAS COMPROBACIONES (importa, y mucho)
 * ------------------------------------------------------------------------
 * fecha -> monto -> tipo -> signo -> valor absoluto -> descripcion -> estado.
 *
 * Los rechazos van PRIMERO porque una fila rechazada no debe llegar a acumular
 * anomalias que nunca se van a guardar. Consecuencia observable y verificada:
 * de las 230 filas con descripcion vacia, 10 tienen ademas el monto vacio y se
 * rechazan antes de llegar a la comprobacion de descripcion. Por eso en la tabla
 * quedan 220 filas con 'SIN DESCRIPCION' y no 230. No es una perdida: esas 10
 * estan en banco.registro_rechazado.
 */
public class MovimientoAnualProcessor implements ItemProcessor<MovimientoAnualRaw, MovimientoAnual> {

    /**
     * LISTA BLANCA de tipos. Es la unica forma de que un tipo llegue a la tabla.
     *
     * Por que una lista blanca y no un "si no lo reconozco lo dejo pasar":
     * ck_mov_tipo solo admite estos 4 valores. Si un fallo de codificacion
     * convirtiera un "deposito" acentuado en algo como DEPA3SITO, ese texto
     * violaria la restriccion EN EL WRITE. Y un fallo de restriccion NO es un
     * dato sucio: BancoXyzSkipPolicy no lo omite, asi que se caeria el chunk
     * ENTERO de 200 filas y con el, el step.
     *
     * Atrapandolo aqui, en el PROCESS, el problema se degrada de "el job
     * revienta" a "una fila al dead letter con motivo TIPO_AUSENTE". Es una red
     * de seguridad: sobre el fichero real se esperan 0 ocurrencias.
     */
    private static final Set<String> TIPOS_VALIDOS = Set.of("DEPOSITO", "RETIRO", "PAGO", "COMPRA");

    /** El unico tipo que SUMA al saldo. Todos los demas restan. */
    private static final String DEPOSITO = "DEPOSITO";

    /** Con lo que se rellena una descripcion en blanco (la columna es NOT NULL). */
    public static final String DESCRIPCION_POR_DEFECTO = "SIN DESCRIPCION";

    private final NormalizadorFecha normalizadorFecha;
    private final NormalizadorMonto normalizadorMonto;
    private final NormalizadorTexto normalizadorTexto;
    private final Long jobExecutionId;

    public MovimientoAnualProcessor(NormalizadorFecha normalizadorFecha,
                                    NormalizadorMonto normalizadorMonto,
                                    NormalizadorTexto normalizadorTexto,
                                    Long jobExecutionId) {
        this.normalizadorFecha = normalizadorFecha;
        this.normalizadorMonto = normalizadorMonto;
        this.normalizadorTexto = normalizadorTexto;
        this.jobExecutionId = jobExecutionId;
    }

    @Override
    public MovimientoAnual process(MovimientoAnualRaw raw) {

        String lineaCruda = raw.toString();

        // ==============================================================
        // 1. FECHA. Los 4 formatos mezclados del fichero los resuelve el
        //    NormalizadorFecha ya existente (se REUTILIZA, no se duplica).
        //    Sobre cuentas_anuales.csv se esperan 0 fechas invalidas, pero la
        //    comprobacion se hace igual: un dato de entrada no se supone, se
        //    verifica. Si algun dia el fichero cambiara, esto lo caza en vez de
        //    dejar reventar un NullPointerException tres lineas mas abajo.
        // ==============================================================
        Optional<NormalizadorFecha.FechaNormalizada> fecha = normalizadorFecha.normalizar(raw.fecha());
        if (fecha.isEmpty()) {
            throw new RegistroInvalidoException("FECHA_INVALIDA", "fecha", raw.fecha(), lineaCruda);
        }

        // ==============================================================
        // 2. MONTO. Aqui estan los 48 rechazos esperados.
        //
        //    Se distingue AUSENTE de NO NUMERICO porque son motivos distintos y
        //    el contrato exige poder contarlos por separado: 48 son
        //    MONTO_AUSENTE (celda vacia) y 0 son MONTO_NO_NUMERICO. Meterlos en
        //    un solo motivo "monto malo" perderia esa distincion.
        // ==============================================================
        NormalizadorMonto.Resultado montoRes = normalizadorMonto.normalizar(raw.monto());
        if (montoRes.ausente()) {
            throw new RegistroInvalidoException("MONTO_AUSENTE", "monto", raw.monto(), lineaCruda);
        }
        if (montoRes.noNumerico()) {
            throw new RegistroInvalidoException("MONTO_NO_NUMERICO", "monto", raw.monto(), lineaCruda);
        }
        BigDecimal montoCrudo = montoRes.valor().orElseThrow();

        // ==============================================================
        // 3. TIPO. canonico() quita tildes (NFD) y pasa a mayusculas, asi las
        //    dos grafias del deposito acaban siendo el MISMO valor. Es la
        //    transformacion que pide el enunciado y la que evita que las 52
        //    filas acentuadas se pierdan como si fueran un tipo distinto.
        //
        //    Despues, la lista blanca: ver el comentario de TIPOS_VALIDOS.
        // ==============================================================
        String tipo = normalizadorTexto.canonico(raw.transaccion());
        if (!TIPOS_VALIDOS.contains(tipo)) {
            throw new RegistroInvalidoException("TIPO_AUSENTE", "transaccion",
                    raw.transaccion(), lineaCruda);
        }

        // ==============================================================
        // 4. SIGNO POR TIPO, MONTO EN VALOR ABSOLUTO.
        //
        //    Esta es LA decision contable del Job 3 y conviene entenderla:
        //    el signo lo decide UNICAMENTE el tipo de transaccion, nunca el
        //    signo con que venia escrito el monto.
        //
        //    Por que no "respetar" el monto negativo de un deposito: la tabla
        //    banco.estado_cuenta_anual tiene esta restriccion
        //
        //        ck_eca_saldo: saldo_neto = total_depositos - total_retiros
        //                                   - total_pagos - total_compras
        //
        //    donde saldo_neto se calcula como SUM(monto_con_signo) y los
        //    totales como SUM(monto) por tipo. Esa igualdad SOLO se sostiene si
        //    monto es siempre positivo y el signo depende solo del tipo. Si un
        //    deposito contradictorio se guardara con signo -1, saldo_neto
        //    dejaria de cuadrar con la resta de totales y el INSERT del tasklet
        //    de consolidacion fallaria... a 20 filas del final del job.
        //
        //    La contradiccion NO se resuelve alterando el signo: se REGISTRA
        //    como anomalia. El dato contable queda coherente y el problema de
        //    calidad queda documentado. Es lo que se hace en un banco de verdad.
        // ==============================================================
        int signo = DEPOSITO.equals(tipo) ? 1 : -1;
        BigDecimal montoAbsoluto = montoCrudo.abs();

        // ==============================================================
        // 5. ANOMALIAS. La fila entra igual; solo queda marcada.
        // ==============================================================
        List<String> anomalias = new ArrayList<>();

        // EL BOOLEANO QUE CONCENTRA LA DECISION MAS DISCUTIBLE DEL JOB.
        //
        // "contradictorio" es un deposito (signo +1) cuyo monto venia negativo.
        // Se aisla en una sola variable con nombre para que la regla se lea de
        // un vistazo y para que cambiar de criterio sea UNA linea.
        boolean contradictorio = signo == 1 && montoCrudo.signum() < 0;

        // EL else ES LA CLAVE, Y ES DELIBERADO: un deposito negativo se marca
        // SOLO como SIGNO_CONTRADICTORIO, NO ademas como MONTO_NEGATIVO. Es UN
        // defecto descrito de dos maneras, no dos defectos.
        //
        // Se verifico simulando estas reglas sobre el CSV real ANTES de escribir
        // el codigo. Con el else:
        //     estados    524 / 173 / 162 / 81 / 12 = 952   <- el contrato
        //     anomalias  DESCRIPCION 220, NEGATIVO 173, SIGNO 81, CERO 12
        //     por fila   0 anomalias 524 | 1 anomalia 370 | 2 anomalias 58
        // Sumando las dos anomalias en vez de elegir una, MONTO_NEGATIVO daria
        // 254 y apareceria una fila con 3 anomalias: ninguno de los dos numeros
        // casa con el contrato de docs/analisis-datos.md.
        if (contradictorio) {
            anomalias.add(EstadoMovimiento.ANOMALA_SIGNO_CONTRADICTORIO.name());
        } else if (montoCrudo.signum() < 0) {
            anomalias.add(EstadoMovimiento.ANOMALA_MONTO_NEGATIVO.name());
        }

        // signum() y no equals(BigDecimal.ZERO): "0.00" y "0" son el mismo
        // numero pero NO son equals entre si (equals compara tambien la escala).
        // Es un error clasico de BigDecimal y aqui dejaria filas sin marcar.
        if (montoCrudo.signum() == 0) {
            anomalias.add(EstadoMovimiento.ANOMALA_MONTO_CERO.name());
        }

        // ==============================================================
        // 6. DESCRIPCION. La columna es NOT NULL, asi que un blanco hay que
        //    rellenarlo con ALGO. Se rellena con un valor explicito y se marca
        //    la anomalia: asi queda claro que el texto lo puso el proceso y no
        //    venia en el fichero. Rellenar sin marcar seria inventar un dato.
        // ==============================================================
        String descripcion = raw.descripcion() == null ? "" : raw.descripcion().trim();
        if (descripcion.isBlank()) {
            descripcion = DESCRIPCION_POR_DEFECTO;
            anomalias.add(EstadoMovimiento.ANOMALA_DESCRIPCION_AUSENTE.name());
        }

        // ==============================================================
        // 7. ESTADO EXCLUYENTE. La tabla guarda UN estado (ck_mov_estado no
        //    admite 'ANOMALA_MULTIPLE'), pero la columna anomalias guarda
        //    TODAS. Dos preguntas distintas, dos columnas distintas:
        //      - "cuantas filas son problematicas"  -> GROUP BY estado
        //      - "cuantas veces aparece este fallo" -> UNNEST de anomalias
        // ==============================================================
        MovimientoAnual m = new MovimientoAnual();
        m.setCuentaId(Integer.valueOf(raw.cuentaId().trim()));
        m.setFecha(fecha.get().fecha());
        m.setFechaOriginal(raw.fecha().trim());
        m.setFormatoFecha(fecha.get().patron());
        m.setTransaccion(tipo);
        m.setTransaccionOriginal(raw.transaccion().trim());
        m.setSigno(signo);
        m.setMonto(montoAbsoluto);
        m.setMontoOriginal(raw.monto().trim());
        m.setDescripcion(descripcion);
        m.setEstado(estadoExcluyente(anomalias).name());
        m.setAnomalias(String.join(",", anomalias));
        // +1 por la cabecera: itemCount ya es la posicion fisica real, porque
        // el lector delegado recorre el fichero entero (ver MovimientoAnualRaw).
        m.setNumeroLinea((long) raw.itemCount() + 1);
        m.setJobExecutionId(jobExecutionId);
        return m;
    }

    /**
     * Elige UN estado entre las anomalias detectadas, por orden de gravedad.
     *
     * No hay una cadena de if-else con el orden escrito a mano: se recorre el
     * enum EstadoMovimiento, cuyos valores ESTAN DECLARADOS de mas grave a menos
     * grave. Asi la regla de precedencia vive en UN solo sitio (el enum) y es
     * imposible que el orden documentado y el aplicado se contradigan.
     */
    private static EstadoMovimiento estadoExcluyente(List<String> anomalias) {
        for (EstadoMovimiento candidato : EstadoMovimiento.values()) {
            if (anomalias.contains(candidato.name())) {
                return candidato;
            }
        }
        return EstadoMovimiento.VALIDA;
    }
}
