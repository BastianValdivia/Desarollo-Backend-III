package cl.duoc.bancoxyz.processor;

import cl.duoc.bancoxyz.domain.EstadoInteres;
import cl.duoc.bancoxyz.domain.InteresCalculado;
import cl.duoc.bancoxyz.domain.InteresRaw;
import cl.duoc.bancoxyz.domain.TipoCuenta;
import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import cl.duoc.bancoxyz.support.CalculadoraInteres;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import org.springframework.batch.item.ItemProcessor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * EL CORAZON DEL JOB 2. Aqui se decide que pasa con cada fila de intereses.csv.
 *
 * Mismos tres tratamientos que en el Job 1, porque la doctrina del proyecto es
 * una sola:
 *
 *   REPARAR  -> el dato se entiende aunque venga mal escrito ('prestamo' en
 *               minusculas) => se canoniza y la fila queda VALIDA
 *   MARCAR   -> el dato es legible pero anomalo (edad 150, tipo '-1')
 *               => se GUARDA con estado ANOMALA_*. No se descarta: detectar
 *                  anomalias es el producto, no la basura.
 *   RECHAZAR -> el dato es irrecuperable (saldo vacio: sin saldo no hay
 *               interes que calcular) => se lanza RegistroInvalidoException y
 *               RechazoListener la guarda en el dead letter.
 *
 * REGLA DE ORO: este metodo NUNCA devuelve null. Devolver null FILTRA la fila:
 * no se escribe, no cuenta como error y desaparece sin dejar rastro.
 *
 * ------------------------------------------------------------------------
 * ESTE PROCESSOR NO TIENE EFECTOS SECUNDARIOS, Y ES OBLIGATORIO QUE ASI SEA
 * ------------------------------------------------------------------------
 * process() se puede llamar MAS DE UNA VEZ para la misma fila. Cuando una
 * escritura falla (los 5 duplicados), Spring Batch deshace el chunk y lo
 * REPROCESA fila a fila para averiguar cual era la culpable. Si aqui se
 * llevara un contador, se escribiera en una tabla o se acumulara algo en un
 * campo, esos efectos se aplicarian dos veces. Todo lo que hace este metodo es
 * leer su parametro y construir un objeto nuevo: es una funcion pura, y por eso
 * es seguro reprocesarla.
 */
public class InteresProcessor implements ItemProcessor<InteresRaw, InteresCalculado> {

    /** Edad minima y maxima creibles para un titular. Fuera de aqui, se anula. */
    private static final int EDAD_MIN = 18;
    private static final int EDAD_MAX = 99;

    /** Como viene en el CSV el titular sin identificar (50 filas). */
    private static final String NOMBRE_DESCONOCIDO = "DESCONOCIDO";

    private final NormalizadorTexto normalizadorTexto;
    private final NormalizadorMonto normalizadorMonto;
    private final CalculadoraInteres calculadora;
    private final String periodo;
    private final Long jobExecutionId;

    public InteresProcessor(NormalizadorTexto normalizadorTexto,
                            NormalizadorMonto normalizadorMonto,
                            CalculadoraInteres calculadora,
                            String periodo,
                            Long jobExecutionId) {
        this.normalizadorTexto = normalizadorTexto;
        this.normalizadorMonto = normalizadorMonto;
        this.calculadora = calculadora;
        this.periodo = periodo;
        this.jobExecutionId = jobExecutionId;
    }

    @Override
    public InteresCalculado process(InteresRaw raw) {
        String lineaCruda = raw.toString();

        // ==============================================================
        // PASO 1: SALDO. Es lo unico verdaderamente irrecuperable.
        //
        // Sin saldo no hay nada que multiplicar por la tasa. No se puede
        // suponer cero: un saldo cero es una afirmacion ("esta cuenta no
        // tiene dinero") y un saldo ausente es una ignorancia ("no sabemos
        // cuanto tiene"). Confundirlas falsearia el balance del banco.
        //
        // Aqui caen las 211 filas de SALDO_AUSENTE, en fase PROCESS.
        // Se reutiliza NormalizadorMonto del Job 1 en vez de escribir otro
        // parseador: distingue "vacio" de "no numerico", que son motivos de
        // rechazo distintos y hay que poder contarlos por separado.
        // ==============================================================
        NormalizadorMonto.Resultado saldo = normalizadorMonto.normalizar(raw.saldo());
        if (saldo.ausente()) {
            throw new RegistroInvalidoException("SALDO_AUSENTE", "saldo", raw.saldo(), lineaCruda);
        }
        if (saldo.noNumerico()) {
            // Hoy son 0 filas en intereses.csv, pero el motivo existe y se
            // distingue: si manana el archivo trae "N/A" en el saldo, el dead
            // letter dira SALDO_NO_NUMERICO y no un generico SALDO_AUSENTE.
            throw new RegistroInvalidoException("SALDO_NO_NUMERICO", "saldo", raw.saldo(), lineaCruda);
        }
        BigDecimal saldoInicial = saldo.valor().orElseThrow();

        // ==============================================================
        // NOTA SOBRE EL DUPLICADO Y LA PRECEDENCIA
        //
        // El plan pide "saldo ausente antes que duplicado". Aqui NO hay ni una
        // linea que detecte duplicados, y sin embargo la precedencia se cumple
        // sola. El motivo es elegante: el rechazo por saldo ocurre en la fase
        // PROCESS (aqui mismo), mientras que el duplicado solo se descubre en
        // la fase WRITE, cuando PostgreSQL rechaza el INSERT por violar
        // uq_interes_posicion. Una fila rechazada aqui NUNCA llega al writer.
        //
        // Por eso el archivo tiene 9 filas repetidas al 100% pero solo salen
        // 5 DUPLICADO: a las otras 4 les falta ademas el saldo y mueren en
        // este paso. No es un error de conteo, es la precedencia funcionando.
        // ==============================================================

        // ==============================================================
        // PASO 2: canonizacion de los campos legibles pero sucios.
        // Ninguno de estos rechaza la fila: todos la marcan.
        // ==============================================================

        // -- tipo de cuenta: '-1' (279) y 'unknown' (52) -> DESCONOCIDO
        TipoCuenta tipo = TipoCuenta.desdeCrudo(raw.tipo(), normalizadorTexto);

        // -- nombre: 'Unknown' -> 'DESCONOCIDO'. Se compara sobre el texto ya
        //    canonizado (sin tildes, en mayusculas) para que 'unknown' y
        //    'Unknown' sean lo mismo.
        String nombreCanonico = normalizadorTexto.canonico(raw.nombre());
        boolean nombreDesconocido = nombreCanonico.equals("UNKNOWN") || nombreCanonico.isEmpty();
        if (nombreDesconocido) {
            nombreCanonico = NOMBRE_DESCONOCIDO;
        }

        // -- edad: vacia o fuera de 18..99 -> null.
        //    Los dos casos se anulan igual pero se CUENTAN distinto, porque
        //    significan cosas distintas: "no nos dijeron la edad" frente a
        //    "nos dijeron una edad imposible" (el archivo trae 100 y 150).
        //    Son mutuamente excluyentes por construccion: si el campo esta
        //    vacio no puede estar ademas fuera de rango.
        Integer edad = null;
        boolean edadAusente = false;
        boolean edadFueraRango = false;
        String edadCruda = raw.edad() == null ? "" : raw.edad().trim();
        if (edadCruda.isEmpty()) {
            edadAusente = true;
        } else {
            try {
                int valor = Integer.parseInt(edadCruda);
                if (valor < EDAD_MIN || valor > EDAD_MAX) {
                    edadFueraRango = true;      // se anula: la base lo exige
                } else {
                    edad = valor;               // edad creible: se conserva
                }
            } catch (NumberFormatException e) {
                // Una edad no numerica es tan poco fiable como una imposible.
                edadFueraRango = true;
            }
        }

        // ==============================================================
        // PASO 3: TODAS las anomalias de la fila, sin excluirse entre si.
        //
        // El estado (paso 4) nombra UNA sola por precedencia, pero aqui no se
        // pierde ninguna. Una fila con tipo '-1' Y edad 150 aporta 1 al estado
        // y 2 a esta lista. Por eso las dos cuentas no suman igual:
        //   estados     -> 303 + 260 + 101 + 96 + 24 = 784
        //   anomalias   -> TIPO 260, EDAD_AUSENTE 151, EDAD_FUERA_RANGO 137,
        //                  NOMBRE_DESCONOCIDO 45
        // ==============================================================
        List<String> anomalias = new ArrayList<>();
        if (!tipo.esConocido()) anomalias.add("TIPO_DESCONOCIDO");
        if (edadFueraRango)     anomalias.add("EDAD_FUERA_RANGO");
        if (edadAusente)        anomalias.add("EDAD_AUSENTE");
        if (nombreDesconocido)  anomalias.add("NOMBRE_DESCONOCIDO");

        // ==============================================================
        // PASO 4: el estado EXCLUYENTE, por orden de precedencia.
        //
        // El orden no es arbitrario: va de mas grave a menos grave desde el
        // punto de vista del dinero.
        //   1. TIPO_DESCONOCIDO   -> es el peor: sin tipo no hay tasa, asi que
        //                            el interes de esa fila es 0. Afecta al
        //                            importe, no solo a la ficha del cliente.
        //   2. EDAD_FUERA_RANGO   -> el dato existe pero es falso.
        //   3. EDAD_AUSENTE       -> el dato simplemente falta (menos grave:
        //                            no hay informacion incorrecta, hay hueco).
        //   4. NOMBRE_DESCONOCIDO -> no afecta a ningun calculo, solo a la
        //                            identificacion del titular.
        //   5. VALIDA
        //
        // Este orden es el que produce los numeros publicados como salida
        // esperada (docs/analisis-datos.md seccion 6):
        //   VALIDA 303 | TIPO_DESCONOCIDO 260 | EDAD_AUSENTE 101
        //   | EDAD_FUERA_RANGO 96 | NOMBRE_DESCONOCIDO 24
        // ==============================================================
        EstadoInteres estado;
        if (!tipo.esConocido()) {
            estado = EstadoInteres.ANOMALA_TIPO_DESCONOCIDO;
        } else if (edadFueraRango) {
            estado = EstadoInteres.ANOMALA_EDAD_FUERA_RANGO;
        } else if (edadAusente) {
            estado = EstadoInteres.ANOMALA_EDAD_AUSENTE;
        } else if (nombreDesconocido) {
            estado = EstadoInteres.ANOMALA_NOMBRE_DESCONOCIDO;
        } else {
            estado = EstadoInteres.VALIDA;
        }

        // ==============================================================
        // PASO 5: el calculo. Delegado en CalculadoraInteres para que la
        // aritmetica se pueda probar por separado de las reglas de arriba.
        // ==============================================================
        BigDecimal interes = calculadora.interes(saldoInicial, tipo);

        // ==============================================================
        // PASO 6: armar la entidad, conservando SIEMPRE los valores originales.
        // Son la evidencia del "antes y despues" y ademas son las columnas
        // sobre las que se define uq_interes_posicion.
        // ==============================================================
        InteresCalculado ic = new InteresCalculado();
        ic.setPeriodo(periodo);
        ic.setCuentaId(Integer.valueOf(raw.cuentaId().trim()));
        ic.setNombre(nombreCanonico);
        ic.setNombreOriginal(raw.nombre());
        ic.setEdad(edad);
        ic.setEdadOriginal(edadCruda);
        ic.setTipo(tipo.name());
        ic.setTipoOriginal(raw.tipo());
        ic.setSaldoInicial(saldoInicial);
        ic.setSaldoOriginal(raw.saldo());
        ic.setTasa(tipo.tasa());
        ic.setInteres(interes);
        ic.setEstado(estado.name());
        ic.setAnomalias(String.join(",", anomalias));
        // Linea fisica del CSV = posicion de la fila + 1 por la cabecera.
        // Aqui la suma es directa, sin el desplazamiento de particion que
        // necesitaba el Job 1, porque cada particion del Job 2 lee el fichero
        // COMPLETO (ver FiltroRangoCuentaReader) y por tanto itemCount ya es
        // la posicion real dentro del archivo.
        ic.setNumeroLinea((long) raw.itemCount() + 1L);
        ic.setJobExecutionId(jobExecutionId);
        return ic;
    }
}
