package cl.duoc.bancoxyz.listener;

import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

/**
 * El "dead letter": cada fila rechazada se guarda en banco.registro_rechazado
 * con su motivo, su campo, su línea original y LA FASE en la que se cayó.
 *
 * Sin esto las filas omitidas desaparecen y la cuadratura
 * (entrada = negocio + rechazos = 1000) no cierra.
 *
 * <I> es el tipo que ENTRA al processor (TransaccionRaw) y <O> el que SALE
 * (Transaccion). Se hace genérico para reutilizarlo en los Jobs 2 y 3.
 *
 * Implementa DOS interfaces:
 *   SkipListener          -> avisa cada vez que se omite una fila
 *   StepExecutionListener -> permite capturar el id de ejecución al empezar
 */
public class RechazoListener<I, O> implements SkipListener<I, O>, StepExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(RechazoListener.class);

    /**
     * Motivos que la restricción ck_rechazo_motivo acepta en la base.
     * Cualquier otro se guarda como 'OTRO': si no filtráramos, un fallo
     * inesperado haría reventar el propio INSERT del dead letter, que es
     * justo la red de seguridad que no puede fallar.
     */
    private static final Set<String> MOTIVOS_VALIDOS = Set.of(
            "FECHA_INVALIDA", "MONTO_AUSENTE", "MONTO_NO_NUMERICO", "SALDO_AUSENTE",
            "SALDO_NO_NUMERICO", "DUPLICADO", "CUENTA_INEXISTENTE", "TIPO_AUSENTE",
            "LINEA_MALFORMADA", "ERROR_ESCRITURA", "OTRO");

    private final JdbcTemplate jdbcTemplate;
    private final String archivoOrigen;

    /**
     * Plantilla que ejecuta el INSERT del dead letter en una transaccion PROPIA.
     * Ver el comentario largo de guardar() para el porque; es, con diferencia,
     * lo mas importante de esta clase.
     */
    private final TransactionTemplate txPropia;

    private final AtomicLong contador = new AtomicLong();
    private Long jobExecutionId;
    private String stepName;
    private String jobName;

    public RechazoListener(JdbcTemplate jdbcTemplate, PlatformTransactionManager txManager,
                           String archivoOrigen) {
        this.jdbcTemplate = jdbcTemplate;
        this.archivoOrigen = archivoOrigen;
        this.txPropia = new TransactionTemplate(txManager);
        this.txPropia.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        this.jobExecutionId = stepExecution.getJobExecutionId();
        this.stepName = stepExecution.getStepName();
        this.jobName = stepExecution.getJobExecution().getJobInstance().getJobName();
        this.contador.set(0);
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        log.info("Step '{}': leídas={} escritas={} omitidas={} rechazos_guardados={}",
                stepExecution.getStepName(),
                stepExecution.getReadCount(),
                stepExecution.getWriteCount(),
                stepExecution.getSkipCount(),
                contador.get());
        return stepExecution.getExitStatus();
    }

    // -----------------------------------------------------------------
    // Los tres momentos en que Spring Batch puede omitir una fila.
    // Cada uno pasa su propia FASE: es de donde sale la columna "fase",
    // y permite demostrar en qué punto del chunk se cayó cada registro.
    // -----------------------------------------------------------------

    /** La línea del CSV ni siquiera se pudo partir en columnas. */
    @Override
    public void onSkipInRead(Throwable t) {
        guardar(t, null, "READ");
    }

    /** El processor lanzó la excepción. Es el caso habitual aquí. */
    @Override
    public void onSkipInProcess(I item, Throwable t) {
        guardar(t, String.valueOf(item), "PROCESS");
    }

    /** El fallo ocurrió al escribir en la base de datos. */
    @Override
    public void onSkipInWrite(O item, Throwable t) {
        guardar(t, String.valueOf(item), "WRITE");
    }

    private void guardar(Throwable t, String lineaCrudaFallback, String fase) {
        RegistroInvalidoException rie = extraer(t);

        // ------------------------------------------------------------------
        // EL DUPLICADO NO VIENE DEL PROCESSOR, VIENE DE POSTGRESQL
        // ------------------------------------------------------------------
        // Los demas rechazos los decide TransaccionProcessor/InteresProcessor
        // lanzando RegistroInvalidoException, que ya trae dentro el motivo, el
        // campo y la linea cruda. El duplicado es distinto: lo detecta la BASE
        // al violarse la restriccion UNIQUE uq_interes_posicion, y lo que llega
        // aqui es un DuplicateKeyException pelado, sin motivo ni campo.
        //
        // Si no lo clasificaramos, caeria en el "OTRO" de mas abajo y las 5
        // filas repetidas de intereses.csv quedarian etiquetadas como un fallo
        // generico, indistinguibles de un bug de verdad. El contrato pide
        // poder contarlas: motivo='DUPLICADO' y fase='WRITE'.
        //
        // Se busca RECORRIENDO LA CADENA DE CAUSAS, igual que hace extraer():
        // un instanceof sobre el throwable de primer nivel NO la veria, porque
        // Spring Batch envuelve lo que sale del writer.
        boolean duplicado = rie == null && esDuplicado(t);

        String motivo = rie != null ? rie.getMotivo() : (duplicado ? "DUPLICADO" : "OTRO");
        if (!MOTIVOS_VALIDOS.contains(motivo)) {
            motivo = "OTRO";
        }
        // El "campo" de un duplicado no es una columna concreta sino la fila
        // entera: es la COMBINACION de valores la que ya existia en la tabla.
        String campo = rie != null ? rie.getCampo() : (duplicado ? "linea" : null);
        String valor = rie != null ? rie.getValorCrudo() : null;
        String linea = rie != null ? rie.getLineaCruda() : lineaCrudaFallback;
        // linea_cruda es NOT NULL en la base: nunca puede quedar sin valor.
        if (linea == null) {
            linea = "(sin linea disponible)";
        }
        // excepcion también es NOT NULL. Guardamos el nombre completo de la
        // clase, que es lo que de verdad identifica el fallo.
        String excepcion = t.getClass().getName();
        String mensaje = t.getMessage();

        // ------------------------------------------------------------------
        // POR QUE ESTE INSERT VA EN SU PROPIA TRANSACCION (REQUIRES_NEW)
        // ------------------------------------------------------------------
        // PROPAGATION_REQUIRES_NEW significa "abre una transaccion nueva,
        // suspende la que haya en curso, y confirmala por separado".
        //
        // Sin esto el dead letter es MENTIRA en cuanto aparece un reintento, y
        // se midio: con el escenario BD_TRANSITORIA, este listener se ejecuta
        // las 215 veces que debe (los cuatro workers suman 57+40+53+65=215)
        // pero en banco.registro_rechazado solo quedaban 42 filas. Faltaban 173.
        //
        // El motivo: los SkipListener se ejecutan DENTRO de la transaccion del
        // chunk. Cuando el escritor falla, el chunk entero hace ROLLBACK, y ese
        // rollback se lleva por delante tanto las filas de negocio -que se
        // reescriben al reintentar, asi que no pasa nada- como los rechazos ya
        // guardados, que NO se vuelven a insertar porque el rollback no
        // devuelve el reloj atras para el listener. Resultado: filas que
        // desaparecen en silencio y la cuadratura (entrada = negocio +
        // rechazos) deja de cerrar.
        //
        // Es exactamente el mismo problema, y la misma solucion, que ya lleva
        // ControlCargaDao.upsert(): la EVIDENCIA de un fallo no puede vivir en
        // la transaccion que ese fallo va a deshacer.
        //
        // Y no, esto no duplica filas al reintentar: el listener solo es
        // notificado cuando Spring Batch registra la omision, y una omision ya
        // registrada no se vuelve a notificar. Comprobado: tras el arreglo, el
        // escenario BD_TRANSITORIA da 215 exactas, no 216.
        // ------------------------------------------------------------------
        final String fMotivo = motivo, fCampo = campo, fValor = valor, fLinea = linea;
        txPropia.executeWithoutResult(status -> jdbcTemplate.update("""
                INSERT INTO banco.registro_rechazado
                    (archivo_origen, job_name, job_execution_id, step_name, fase,
                     motivo, campo, valor_crudo, linea_cruda, excepcion, mensaje)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                archivoOrigen, jobName, jobExecutionId, stepName, fase,
                fMotivo, fCampo, fValor, fLinea, excepcion, mensaje));
        contador.incrementAndGet();
    }

    /**
     * ¿Hay un DuplicateKeyException en algún punto de la cadena de causas?
     *
     * Mismo recorrido que extraer(), y por el mismo motivo: la excepción llega
     * envuelta por Spring Batch. Se comprueba la clase HIJA y no su padre
     * DataIntegrityViolationException, en coherencia con BancoXyzSkipPolicy:
     * un duplicado es un dato repetido, mientras que una violación de
     * integridad genérica es un fallo que no se debe disfrazar de dato sucio.
     */
    private boolean esDuplicado(Throwable t) {
        Throwable actual = t;
        while (actual != null) {
            if (actual instanceof org.springframework.dao.DuplicateKeyException) {
                return true;
            }
            actual = actual.getCause();
        }
        return false;
    }

    /** Spring envuelve las excepciones, así que hay que recorrer la cadena de causas. */
    private RegistroInvalidoException extraer(Throwable t) {
        Throwable actual = t;
        while (actual != null) {
            if (actual instanceof RegistroInvalidoException rie) {
                return rie;
            }
            actual = actual.getCause();
        }
        return null;
    }
}
