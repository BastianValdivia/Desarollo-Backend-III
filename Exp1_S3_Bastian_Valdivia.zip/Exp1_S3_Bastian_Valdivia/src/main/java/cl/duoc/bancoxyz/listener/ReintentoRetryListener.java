package cl.duoc.bancoxyz.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.RetryListener;

import java.util.concurrent.atomic.AtomicLong;

/**
 * AUDITORIA DE REINTENTOS: deja constancia en el log de cada intento fallido.
 *
 * Sin este listener los reintentos son INVISIBLES. Si la politica funciona, el
 * job termina COMPLETED y no hay ninguna senal de que por dentro hubo tres
 * intentos y dos esperas. Y si la politica esta mal cableada (por ejemplo, sin
 * traverseCauses), tambien termina COMPLETED... simplemente sin haber
 * reintentado nunca. Los dos casos se ven IGUAL desde fuera.
 *
 * Este listener es lo que los distingue, y es la evidencia que se entrega del
 * escenario "caida transitoria de la base de datos".
 *
 * IMPORTANTE SOBRE LA INTERFAZ: se implementa org.springframework.retry.RetryListener
 * directamente. NO se extiende RetryListenerSupport, que esta deprecada en
 * Spring Retry 2.x: en la interfaz moderna todos los metodos son "default", asi
 * que basta con sobrescribir los que interesan.
 *
 * Los tres momentos:
 *   open()    -> empieza un bloque susceptible de reintento (una vez por bloque)
 *   onError() -> un intento ha fallado. AQUI esta la informacion util.
 *   close()   -> el bloque termino, con exito o rendido tras agotar intentos.
 */
public class ReintentoRetryListener implements RetryListener {

    private static final Logger log = LoggerFactory.getLogger(ReintentoRetryListener.class);

    /**
     * Tope de intentos que declara RetryPolicies.INTENTOS. Se usa SOLO para
     * redactar el log de cierre; la politica de verdad la aplica Spring Retry.
     * Se referencia la constante en vez de escribir un 3 a pelo para que, si
     * manana el tope sube a 4, el mensaje no empiece a mentir.
     */
    private static final int MAX_INTENTOS_ESPERADOS = cl.duoc.bancoxyz.policy.RetryPolicies.INTENTOS;

    /** Cuantos intentos fallidos ha visto este listener en toda la ejecucion. */
    private final AtomicLong intentosFallidos = new AtomicLong();

    /**
     * Se llama DESPUES de cada intento fallido, antes de la espera del backoff.
     *
     * context.getRetryCount() es el numero de intentos ya realizados: vale 1 la
     * primera vez que entra aqui (fallo el intento inicial), 2 la segunda, etc.
     * Con maxAttempts=3, ver un "intento 3" en el log significa que se agotaron
     * los reintentos y la excepcion va a subir para hacer fallar el step.
     */
    @Override
    public <T, E extends Throwable> void onError(RetryContext context,
                                                 RetryCallback<T, E> callback,
                                                 Throwable throwable) {
        long total = intentosFallidos.incrementAndGet();
        log.warn("REINTENTO | hilo={} | intento {} fallido (total acumulado {}) | {}: {}",
                Thread.currentThread().getName(),
                context.getRetryCount(),
                total,
                throwable.getClass().getSimpleName(),
                throwable.getMessage());
    }

    /**
     * Cierre del bloque de reintentos.
     *
     * CUIDADO CON LO QUE SE PUEDE AFIRMAR AQUI. La tentacion es escribir
     * "si throwable == null -> RECUPERADO, si no -> AGOTADO". Es FALSO en un
     * step de Spring Batch, y se comprobo: con el escenario BD_CAIDA_PERMANENTE,
     * que falla siempre y acaba matando el job, este metodo recibia igualmente
     * throwable == null y el log cantaba "RECUPERADO tras 3 intentos" mientras
     * el job terminaba FAILED. Evidencia que miente, que es peor que no tener
     * evidencia.
     *
     * El motivo: en el reintento CON ESTADO que usa Batch, cuando se agotan los
     * intentos no se propaga la excepcion por aqui, sino que se entra en la
     * "ruta de recuperacion" (el RecoveryCallback), que es quien decide si la
     * fila se omite o si el step muere. Desde el listener ese desenlace no se
     * ve, asi que no se puede afirmar.
     *
     * Por eso este log se limita a los HECHOS que si constan -cuantos intentos
     * se gastaron y si se llego al tope- y deja el desenlace a quien si lo
     * sabe: el estado final del step y el mensaje de ExhaustedRetryException.
     */
    @Override
    public <T, E extends Throwable> void close(RetryContext context,
                                               RetryCallback<T, E> callback,
                                               Throwable throwable) {
        int intentos = context.getRetryCount();
        if (intentos == 0) {
            return;   // no hubo ningun fallo: nada que contar
        }

        if (intentos >= MAX_INTENTOS_ESPERADOS) {
            // Se llego al tope. El desenlace lo dicta la ruta de recuperacion:
            // si la excepcion no es omitible, el step FALLA.
            log.warn("REINTENTO | TOPE ALCANZADO: {} intento(s) gastados en este bloque. "
                            + "Si el fallo no era omitible, el step va a FALLAR "
                            + "(NUNCA se hace skip de un fallo de infraestructura).",
                    intentos);
        } else {
            log.info("REINTENTO | bloque cerrado tras {} intento(s) fallido(s) sin llegar al tope de {}.",
                    intentos, MAX_INTENTOS_ESPERADOS);
        }
    }

    /** Para poder afirmarlo en un test, no solo verlo en el log. */
    public long getIntentosFallidos() {
        return intentosFallidos.get();
    }
}
