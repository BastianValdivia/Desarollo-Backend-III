package cl.duoc.bancoxyz.experiment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.TreeSet;

/**
 * EL BANCO DE PRUEBAS. Orquesta, mide, repite y guarda.
 *
 * Se activa SOLO con el perfil "experiment":
 *
 *     ./mvnw spring-boot:run -Dspring-boot.run.profiles=experiment
 *
 * ------------------------------------------------------------------------
 * PROTOCOLO DE MEDICION (esto es lo que hace creible la tabla)
 * ------------------------------------------------------------------------
 * 1. POR RONDAS, NO POR CELDA. En vez de medir 7 veces seguidas la celda A y
 *    luego 7 veces la B, se hace una pasada por todas las celdas, y otra, y
 *    otra. Si la maquina se calienta o el sistema operativo decide indexar el
 *    disco a mitad del experimento, la deriva se reparte entre TODAS las
 *    celdas en vez de castigar a la que tocara en ese momento.
 * 2. ORDEN ALEATORIZADO dentro de cada ronda, con SEMILLA FIJA (42 + ronda).
 *    Aleatorizar rompe el sesgo de orden; la semilla fija hace que el
 *    experimento sea reproducible ejecucion tras ejecucion.
 * 3. CALENTAMIENTO DECLARADO: las 2 primeras rondas se marcan warmup=true y
 *    se excluyen del analisis, pero SE ESCRIBEN igual en el CSV y en la tabla.
 *    La JVM interpreta el bytecode las primeras veces y solo despues lo
 *    compila a codigo maquina; sin descartar esas rondas estarias midiendo al
 *    compilador JIT, no a tu codigo. Descartarlas EN SILENCIO seria peor: nadie
 *    podria comprobar cuantas ni cuales.
 * 4. LIMPIEZA FUERA DEL CRONOMETRO. El TRUNCATE previo no se cuenta.
 * 5. CONTROL DE INTEGRIDAD. Cada ejecucion comprueba que leyo exactamente las
 *    filas del dataset. Ver el comentario de limpiar() para el porque, que es
 *    la trampa mas peligrosa de todo el montaje.
 */
@Component
@Profile("experiment")
public class EjecutorExperimentos implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(EjecutorExperimentos.class);

    /** Rondas descartadas. Se ESCRIBEN en el CSV marcadas, no se ocultan. */
    private static final int RONDAS_CALENTAMIENTO = 2;

    /** Rondas que si entran en las medianas. El minimo exigido por la pauta es 5. */
    private static final int RONDAS_MEDIDAS = 5;

    /** Escala 1: el dataset real del enunciado, tal cual. */
    private static final int FILAS_BASE = 1000;

    /** Escala 2: replicas del original. Se declara en docs/escalado.md. */
    private static final int FACTOR_AMPLIFICACION = 20;

    private static final Path CSV_RESULTADOS = Path.of("results", "scaling-results.csv");
    private static final Path MD_RESUMEN = Path.of("results", "scaling-summary.md");
    private static final Path LOG_HILOS = Path.of("evidencias", "04-escalado", "hilos-particionado.txt");

    private final JobLauncher jobLauncher;
    private final FabricaJobsExperimento fabrica;
    private final MatrizExperimentos matriz;
    private final EscritorResultadosCsv csv;
    private final RepositorioMetricasExperimento repositorio;
    private final AnalizadorResultados analizador;
    private final SondaEntorno entorno;
    private final JdbcTemplate jdbcTemplate;

    private final List<ResultadoExperimento> todos = new ArrayList<>();
    private final StringBuilder evidenciaHilos = new StringBuilder();

    public EjecutorExperimentos(JobLauncher jobLauncher, FabricaJobsExperimento fabrica,
                                MatrizExperimentos matriz, EscritorResultadosCsv csv,
                                RepositorioMetricasExperimento repositorio,
                                AnalizadorResultados analizador, SondaEntorno entorno,
                                JdbcTemplate jdbcTemplate) {
        this.jobLauncher = jobLauncher;
        this.fabrica = fabrica;
        this.matriz = matriz;
        this.csv = csv;
        this.repositorio = repositorio;
        this.analizador = analizador;
        this.entorno = entorno;
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        Instant inicio = Instant.now();
        log.info("=== BANCO DE PRUEBAS DE ESCALADO ===");
        log.info("Entorno: {}", entorno.descripcion());

        if (entorno.hikariPoolSize() < 10) {
            // 8 particiones + el manager + la transaccion REQUIRES_NEW del dead
            // letter pueden pedir mas de una conexion por hilo a la vez. Con un
            // pool pequeno, lo que se mediria es la espera por conexion.
            log.warn("Pool de conexiones = {}: DEMASIADO PEQUENO para gridSize=8. "
                    + "Los tiempos de las celdas con mas paralelismo no serian validos.",
                    entorno.hikariPoolSize());
        }

        int filasAmplificadas = AmplificadorDataset.amplificar(
                new ClassPathResource("data/transacciones.csv"),
                Path.of(CasoExperimento.DIRECTORIO_GENERADO,
                        "transacciones_x" + (FILAS_BASE * FACTOR_AMPLIFICACION / 1000) + "k.csv"),
                FACTOR_AMPLIFICACION);

        repositorio.limpiar();

        for (int filas : new int[]{FILAS_BASE, filasAmplificadas}) {
            ejecutarEscala(filas);
        }

        csv.escribir(CSV_RESULTADOS, todos);
        escribirResumen();
        Files.createDirectories(LOG_HILOS.getParent());
        Files.writeString(LOG_HILOS, evidenciaHilos.toString(), StandardCharsets.UTF_8);

        log.info("=== EXPERIMENTO TERMINADO en {} - {} ejecuciones ===",
                Duration.between(inicio, Instant.now()), todos.size());
        log.info("Resultados crudos:  {}", CSV_RESULTADOS.toAbsolutePath());
        log.info("Tablas resumidas:   {}", MD_RESUMEN.toAbsolutePath());
        log.info("Prueba de hilos:    {}", LOG_HILOS.toAbsolutePath());
    }

    // ==================================================================
    // EL DISENO ESCALONADO: F0 -> elige chunk -> F1 -> elige config -> F2
    // ==================================================================
    private void ejecutarEscala(int filas) throws Exception {
        log.info("--- ESCALA {} filas ---", filas);

        List<ResultadoExperimento> f0 = ejecutarFase(matriz.fase0(filas));
        int mejorChunk = mejorChunkDe(f0);
        log.info("F0 terminada. Mejor chunkSize secuencial a {} filas: {}", filas, mejorChunk);

        List<ResultadoExperimento> f1 = ejecutarFase(matriz.fase1(filas, mejorChunk));
        Optional<AnalizadorResultados.ResumenCelda> mejorParalela =
                analizador.resumir(f1).stream()
                        .min(Comparator.comparingDouble(AnalizadorResultados.ResumenCelda::medianaMs));

        if (mejorParalela.isEmpty()) {
            log.warn("F1 no dejo ninguna celda valida a {} filas; se omite F2", filas);
            return;
        }
        CasoExperimento ganadora = mejorParalela.get().caso();
        log.info("F1 terminada. Mejor configuracion paralela: {} p={} ({} ms mediana)",
                ganadora.estrategia(), ganadora.paralelismo(), mejorParalela.get().medianaMs());

        // F2 vuelve a medir la ganadora con los DOS mejores chunk de F0. Si el
        // chunk optimo en paralelo fuera otro, aqui se veria: es la defensa
        // contra la critica "asumiste que los dos factores no interactuan".
        int[] dosMejores = dosMejoresChunksDe(f0);
        ejecutarFase(matriz.fase2(filas, ganadora.estrategia(), ganadora.paralelismo(), dosMejores));
    }

    private List<ResultadoExperimento> ejecutarFase(List<CasoExperimento> casos) throws Exception {
        List<ResultadoExperimento> deLaFase = new ArrayList<>();
        int totalRondas = RONDAS_CALENTAMIENTO + RONDAS_MEDIDAS;

        for (int ronda = 0; ronda < totalRondas; ronda++) {
            List<CasoExperimento> barajados = new ArrayList<>(casos);
            // Semilla FIJA que depende de la ronda: aleatorio pero reproducible.
            Collections.shuffle(barajados, new Random(42L + ronda));
            boolean calentamiento = ronda < RONDAS_CALENTAMIENTO;

            for (CasoExperimento caso : barajados) {
                ResultadoExperimento r = ejecutarUnaVez(caso, ronda, calentamiento);
                deLaFase.add(r);
                todos.add(r);
                repositorio.guardar(r);
            }
        }
        return deLaFase;
    }

    // ==================================================================
    // UNA EJECUCION CRONOMETRADA
    // ==================================================================
    private ResultadoExperimento ejecutarUnaVez(CasoExperimento caso, int ronda, boolean calentamiento)
            throws Exception {

        limpiar();                    // FUERA del cronometro
        System.gc();                  // sugerencia, no orden: ver comentario abajo
        Thread.sleep(150);            // deja que el flush del TRUNCATE y el GC se asienten

        FabricaJobsExperimento.JobExperimento montaje = fabrica.construir(caso);

        // Todos los parametros son IDENTIFICANTES: cada ejecucion es una
        // JobInstance distinta y la configuracion queda escrita en
        // BATCH_JOB_EXECUTION_PARAMS. Eso permite reconstruir esta misma tabla
        // con SQL puro (sql/verificacion/05-comparativa.sql) como verificacion
        // cruzada del CSV: si coinciden, las mediciones son solidas.
        //
        // 'runId' con nanoTime es OBLIGATORIO: sin un parametro unico, la
        // segunda repeticion de la misma celda reventaria con
        // JobInstanceAlreadyCompleteException.
        JobParameters parametros = new JobParametersBuilder()
                .addString("estrategia", caso.estrategia().name())
                .addLong("paralelismo", (long) caso.paralelismo())
                .addLong("chunkSize", (long) caso.chunkSize())
                .addLong("datasetFilas", (long) caso.filasDataset())
                .addLong("ronda", (long) ronda)
                .addString("fase", caso.fase())
                .addString("warmup", String.valueOf(calentamiento))
                .addLong("runId", System.nanoTime())
                .toJobParameters();

        long t0 = System.nanoTime();
        JobExecution ejecucion = jobLauncher.run(montaje.job(), parametros);
        long wallClock = System.nanoTime() - t0;

        montaje.cerrar();   // apaga el pool de esta ejecucion

        ResultadoExperimento resultado = medir(caso, ronda, calentamiento, wallClock,
                ejecucion, montaje.procesador());

        if (!resultado.filasEsperadasOk()) {
            log.error("CELDA INVALIDA {} ronda {}: se leyeron {} filas de {} esperadas. "
                            + "Se marca y se EXCLUYE del analisis, no se oculta.",
                    caso.etiqueta(), ronda, resultado.readCount(), caso.filasDataset());
        } else {
            log.info("{} ronda {}{} -> {} ms  status={} hilos={}",
                    caso.etiqueta(), ronda, calentamiento ? " (calentamiento)" : "",
                    resultado.wallClockMs(), resultado.batchStatus(), resultado.hilosDistintos());
        }

        if (caso.estrategia() == EstrategiaEscalado.PARTICIONADO && !calentamiento) {
            evidenciaHilos.append("%s ronda %d -> %d hilos distintos: %s%n".formatted(
                    caso.etiqueta(), ronda, montaje.procesador().hilosDistintos(),
                    new TreeSet<>(montaje.procesador().nombresDeHilo())));
        }
        return resultado;
    }

    /**
     * Vacia las tablas de negocio ANTES de cada repeticion, y fuera del reloj.
     *
     * ESTO NO ES COSMETICA, ES LA RED DE SEGURIDAD DEL EXPERIMENTO ENTERO.
     * banco.transaccion tiene 'id' como PRIMARY KEY, y BancoXyzSkipPolicy
     * clasifica DuplicateKeyException como DATO SUCIO OMITIBLE (con razon: una
     * fila repetida es un dato malo, no un fallo de la base). Si no se
     * limpiara, la segunda repeticion de cada celda chocaria contra las filas
     * de la primera, omitiria practicamente todo, terminaria COMPLETED... y
     * seria MUY RAPIDA, porque no escribiria nada. Tendrias una tabla entera de
     * numeros falsos con aspecto de exito.
     *
     * Por eso ademas cada resultado comprueba readCount == filas del dataset.
     */
    private void limpiar() {
        // banco.transaccion y banco.resumen_diario SI se pueden truncar: son de
        // uso exclusivo del Job 1 y del experimento, que cargan lo mismo
        // (transacciones.csv). TRUNCATE es ademas mucho mas rapido que DELETE
        // porque no genera filas muertas que luego haya que aspirar.
        jdbcTemplate.execute("TRUNCATE banco.transaccion, banco.resumen_diario");

        // banco.registro_rechazado NO. Es el DEAD LETTER COMPARTIDO por los tres
        // jobs, y truncarlo se llevaba por delante las 216 filas de intereses.csv
        // y las 48 de cuentas_anuales.csv, que ningun job del experimento vuelve
        // a generar. Resultado observado: al terminar el banco de pruebas,
        // banco.v_cuadratura pasaba a decir "intereses.csv 784 + 0 = 784" y
        // "cuentas_anuales.csv 952 + 0 = 952", o sea la Regla de Oro rota en dos
        // de los tres archivos, y solo recuperable reejecutando los Jobs 2 y 3.
        //
        // Es exactamente lo que LimpiezaTasklet documenta como prohibido. Aqui se
        // habia colado porque TRUNCATE admite varias tablas a la vez y es comodo.
        //
        // TRUNCATE NO ADMITE WHERE (borra la tabla entera por definicion; esa es
        // justamente la razon de que sea tan rapido), asi que el borrado acotado
        // tiene que hacerse con DELETE. Se filtra por job_name y no solo por
        // archivo_origen para aislar del todo el experimento del Job 1 real: si
        // alguien acaba de cargar el Job 1 y lanza el banco de pruebas, su
        // evidencia tampoco se toca.
        int rechazos = jdbcTemplate.update(
                "DELETE FROM banco.registro_rechazado WHERE archivo_origen = ? AND job_name = ?",
                "transacciones.csv", FabricaJobsExperimento.NOMBRE_JOB);
        log.debug("Limpieza del experimento: {} rechazos borrados (solo los del job {})",
                rechazos, FabricaJobsExperimento.NOMBRE_JOB);
    }

    // ==================================================================
    // EXTRACCION DE METRICAS DE LA EJECUCION
    // ==================================================================
    private ResultadoExperimento medir(CasoExperimento caso, int ronda, boolean calentamiento,
                                       long wallClockNanos, JobExecution ejecucion,
                                       ProcesadorExperimento procesador) {

        List<StepExecution> todosLosSteps = new ArrayList<>(ejecucion.getStepExecutions());

        // En un step particionado, Spring Batch AGREGA los contadores de las
        // particiones hijas dentro del StepExecution del manager. Sumar manager
        // e hijas contaria TODO DOS VECES. Por eso, si hay hijas (su nombre
        // lleva el sufijo ":partitionN"), solo se suman las hijas.
        List<StepExecution> hojas = todosLosSteps.stream()
                .filter(se -> se.getStepName().contains(":partition"))
                .toList();
        if (hojas.isEmpty()) {
            hojas = todosLosSteps;
        }

        long read = hojas.stream().mapToLong(StepExecution::getReadCount).sum();
        long write = hojas.stream().mapToLong(StepExecution::getWriteCount).sum();
        long filter = hojas.stream().mapToLong(StepExecution::getFilterCount).sum();
        long skip = hojas.stream().mapToLong(StepExecution::getSkipCount).sum();
        long commit = hojas.stream().mapToLong(StepExecution::getCommitCount).sum();
        long rollback = hojas.stream().mapToLong(StepExecution::getRollbackCount).sum();

        List<Long> duraciones = hojas.stream().map(EjecutorExperimentos::duracionMs).toList();
        long maxParticion = duraciones.stream().mapToLong(Long::longValue).max().orElse(0);
        long sumParticion = duraciones.stream().mapToLong(Long::longValue).sum();
        long minParticion = duraciones.stream().mapToLong(Long::longValue).min().orElse(0);

        // SKEW = fila mas cargada / carga media. 1.0 es reparto perfecto.
        // NO es lo mismo que ratioMaxMin (dispersion de DURACIONES): una
        // particion puede tener las mismas filas y tardar el doble porque le
        // tocaron mas filas sucias, y eso solo lo ve el ratio.
        double mediaFilas = hojas.isEmpty() ? 0 : (double) read / hojas.size();
        double skew = mediaFilas == 0 ? 1
                : hojas.stream().mapToLong(StepExecution::getReadCount).max().orElse(0) / mediaFilas;
        double ratioMaxMin = minParticion == 0 ? 0 : (double) maxParticion / minParticion;

        long jobMs = 0;
        LocalDateTime ini = ejecucion.getStartTime();
        LocalDateTime fin = ejecucion.getEndTime();
        if (ini != null && fin != null) {
            jobMs = Duration.between(ini, fin).toMillis();
        }

        return new ResultadoExperimento(
                caso, ronda, calentamiento, wallClockNanos, jobMs,
                ejecucion.getStatus().name(),
                ejecucion.getExitStatus().getExitCode(),
                read, write, filter, skip, commit, rollback,
                maxParticion, sumParticion, skew, ratioMaxMin,
                procesador.hilosDistintos(),
                read == caso.filasDataset(),
                entorno.hikariPoolSize(), entorno.cpus(), entorno.heapMaxMb(),
                LocalDateTime.now().toString(),
                ejecucion.getId());
    }

    private static long duracionMs(StepExecution se) {
        if (se.getStartTime() == null || se.getEndTime() == null) {
            return 0;
        }
        return Duration.between(se.getStartTime(), se.getEndTime()).toMillis();
    }

    // ==================================================================
    // SELECCION DE GANADORES ENTRE FASES
    // ==================================================================
    private int mejorChunkDe(List<ResultadoExperimento> f0) {
        return analizador.resumir(f0).stream()
                .min(Comparator.comparingDouble(AnalizadorResultados.ResumenCelda::medianaMs))
                .map(r -> r.caso().chunkSize())
                .orElse(100);
    }

    private int[] dosMejoresChunksDe(List<ResultadoExperimento> f0) {
        List<Integer> ordenados = analizador.resumir(f0).stream()
                .sorted(Comparator.comparingDouble(AnalizadorResultados.ResumenCelda::medianaMs))
                .map(r -> r.caso().chunkSize())
                .toList();
        if (ordenados.size() >= 2) {
            return new int[]{ordenados.get(0), ordenados.get(1)};
        }
        return new int[]{100, 500};
    }

    // ==================================================================
    // SALIDA RESUMIDA
    // ==================================================================
    private void escribirResumen() throws java.io.IOException {
        List<AnalizadorResultados.ResumenCelda> resumenes = analizador.resumir(todos);
        StringBuilder sb = new StringBuilder();
        sb.append("# Resultados del banco de pruebas de escalado\n\n");
        sb.append("Generado automaticamente por EjecutorExperimentos. No editar a mano.\n\n");
        sb.append("Entorno: ").append(entorno.descripcion()).append("\n\n");
        sb.append("Protocolo: %d rondas de calentamiento DESCARTADAS del analisis (presentes en el CSV con warmup=true) + %d rondas medidas por celda; orden aleatorizado por rondas con semilla fija 42+ronda; TRUNCATE fuera del cronometro.%n%n"
                .formatted(RONDAS_CALENTAMIENTO, RONDAS_MEDIDAS));

        for (int filas : todos.stream().map(r -> r.caso().filasDataset()).distinct().sorted().toList()) {
            sb.append("## Escala ").append(filas).append(" filas\n\n");
            sb.append(analizador.tablaMarkdown(resumenes, filas)).append("\n");
        }

        long invalidas = todos.stream().filter(r -> !r.calentamiento() && !r.filasEsperadasOk()).count();
        sb.append("\nEjecuciones medidas descartadas por no leer todas las filas: ")
          .append(invalidas).append("\n");

        Files.createDirectories(MD_RESUMEN.getParent());
        Files.writeString(MD_RESUMEN, sb.toString(), StandardCharsets.UTF_8);
    }
}
