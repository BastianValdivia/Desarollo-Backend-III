package cl.duoc.bancoxyz.domain;

import cl.duoc.bancoxyz.support.NormalizadorTexto;

import java.math.BigDecimal;

/**
 * Los productos que ofrece el banco, cada uno con SU TASA DE INTERES MENSUAL.
 *
 * Un enum en Java puede llevar datos y metodos, no solo un nombre. Aqui cada
 * constante lleva pegada su tasa, asi que "el tipo de cuenta" y "cuanto renta"
 * son inseparables: es imposible tener un tipo sin tasa o una tasa huerfana.
 * En SQL seria una tabla de parametros con clave = tipo y valor = tasa; la
 * diferencia es que aqui el compilador garantiza que estan todas.
 *
 * ------------------------------------------------------------------------
 * POR QUE ESTAS TASAS Y NO OTRAS (decision de negocio, plan-maestro E5)
 * ------------------------------------------------------------------------
 * El enunciado no fija las tasas, asi que hay que elegirlas y JUSTIFICARLAS.
 * El criterio es el riesgo, que es como se fija el precio del dinero:
 *
 *   AHORRO   0,250% mensual (~3,0% anual)  -> es lo que el banco PAGA al
 *       cliente por dejarle su dinero. Es un COSTE para el banco, asi que es
 *       la mas baja de las tres.
 *
 *   HIPOTECA 0,400% mensual (~4,9% anual)  -> es lo que el banco COBRA, pero
 *       el prestamo esta GARANTIZADO por el inmueble: si el cliente no paga,
 *       el banco se queda la casa. Poco riesgo, luego credito barato.
 *
 *   PRESTAMO 1,500% mensual (~19,6% anual) -> credito de consumo SIN garantia.
 *       Si el cliente no paga no hay nada que embargar, asi que el banco cobra
 *       una prima por ese riesgo. Es, con diferencia, la mas cara.
 *
 *   DESCONOCIDO 0,000% -> las 331 filas cuyo tipo viene como '-1' o 'unknown'.
 *       NO SE INVENTA UNA TASA. Aplicarles la del ahorro seria regalar dinero
 *       y aplicarles la del prestamo seria cobrarlo sin contrato: las dos
 *       cosas son falsear un estado financiero. Tasa 0 significa "no se puede
 *       poner precio a un producto que no se sabe cual es"; la fila SE GUARDA
 *       igual, marcada como ANOMALA_TIPO_DESCONOCIDO, para que alguien la
 *       revise y la corrija. Es la version contable de "ante la duda, no
 *       toques el dinero del cliente".
 *
 * Sobre el tipo BigDecimal y la escala 5: la columna es NUMERIC(7,5) y su
 * CHECK exige 0 <= tasa < 1. "0.00250" tiene exactamente 5 decimales, asi que
 * entra sin que PostgreSQL tenga que redondear nada. Se construye desde un
 * String y NO desde un double a proposito: new BigDecimal(0.0025) guarda
 * 0.00249999999999999... porque 0,0025 no es representable en binario, y en
 * dinero ese arrastre es inaceptable.
 */
public enum TipoCuenta {

    AHORRO(new BigDecimal("0.00250")),
    HIPOTECA(new BigDecimal("0.00400")),
    PRESTAMO(new BigDecimal("0.01500")),
    DESCONOCIDO(new BigDecimal("0.00000"));

    private final BigDecimal tasa;

    TipoCuenta(BigDecimal tasa) {
        this.tasa = tasa;
    }

    /** Tasa mensual aplicable a este producto. */
    public BigDecimal tasa() {
        return tasa;
    }

    /** True para los tres productos reales; false solo para DESCONOCIDO. */
    public boolean esConocido() {
        return this != DESCONOCIDO;
    }

    /**
     * Traduce el texto crudo del CSV a uno de los cuatro tipos.
     *
     * El archivo trae 'ahorro', 'hipoteca' y 'prestamo' en minusculas, mas
     * '-1' (279 veces) y 'unknown' (52 veces). Se canoniza con el mismo
     * NormalizadorTexto que ya usa el Job 1 -quita tildes y pasa a mayusculas-
     * para no tener DOS reglas distintas de "que significa que dos textos sean
     * el mismo" en el mismo proyecto.
     *
     * TODO lo que no encaje cae en DESCONOCIDO. Es deliberado: un valor nuevo e
     * inesperado ('leasing', por ejemplo) NO debe reventar el job ni colarse
     * como si fuera ahorro; debe quedar marcado y visible en la columna estado.
     */
    public static TipoCuenta desdeCrudo(String crudo, NormalizadorTexto normalizador) {
        String canonico = normalizador.canonico(crudo);
        return switch (canonico) {
            case "AHORRO"   -> AHORRO;
            case "HIPOTECA" -> HIPOTECA;
            case "PRESTAMO" -> PRESTAMO;
            default         -> DESCONOCIDO;
        };
    }
}
