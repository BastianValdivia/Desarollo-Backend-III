package cl.duoc.bancoxyz.exception;

/**
 * Excepción propia para una fila IRRECUPERABLE (fecha imposible, monto ausente...).
 *
 * Lanzarla desde el processor es la forma de decirle a Spring Batch
 * "esta fila no sirve". La política de skip decidirá si se omite y sigue,
 * y el SkipListener la guardará en la tabla de rechazados.
 *
 * Lleva dentro el motivo, el campo y el valor crudo para poder auditarla.
 * En Python heredarías de Exception; en Java se hereda con "extends".
 */
public class RegistroInvalidoException extends RuntimeException {

    private final String motivo;
    private final String campo;
    private final String valorCrudo;
    private final String lineaCruda;

    public RegistroInvalidoException(String motivo, String campo, String valorCrudo, String lineaCruda) {
        super(motivo + " en campo '" + campo + "' (valor: '" + valorCrudo + "')");
        this.motivo = motivo;
        this.campo = campo;
        this.valorCrudo = valorCrudo;
        this.lineaCruda = lineaCruda;
    }

    public String getMotivo() { return motivo; }
    public String getCampo() { return campo; }
    public String getValorCrudo() { return valorCrudo; }
    public String getLineaCruda() { return lineaCruda; }
}
