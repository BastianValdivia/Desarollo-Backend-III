package cl.duoc.bancoxyz.support;

import org.springframework.stereotype.Component;

import java.text.Normalizer;
import java.util.Locale;

/**
 * Quita tildes y pasa a mayúsculas, para que "depósito" y "deposito" sean lo mismo.
 * En cuentas_anuales.csv hay 52 filas con "depósito" y 296 con "deposito":
 * son el mismo concepto escrito de dos maneras.
 *
 * Normalizer.Form.NFD separa la letra de su tilde ("ó" -> "o" + "´"),
 * y luego borramos los acentos sueltos con una expresión regular.
 */
@Component
public class NormalizadorTexto {

    public String canonico(String crudo) {
        if (crudo == null) {
            return "";
        }
        String sinTildes = Normalizer.normalize(crudo.trim(), Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        return sinTildes.toUpperCase(Locale.ROOT);
    }
}
