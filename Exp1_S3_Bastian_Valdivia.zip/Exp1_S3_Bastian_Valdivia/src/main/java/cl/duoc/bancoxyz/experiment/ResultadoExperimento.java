package cl.duoc.bancoxyz.experiment;

/**
 * El resultado de UNA ejecucion individual (una repeticion de un caso).
 *
 * DECISION DE HONESTIDAD: 'calentamiento' es una COLUMNA, no un filtro.
 * Las repeticiones de calentamiento se escriben igual en el CSV y en la tabla,
 * marcadas. El descarte se hace en el analisis y queda documentado. Esa es
 * exactamente la diferencia entre REPORTAR y MAQUILLAR: si los calentamientos
 * no aparecen, nadie puede comprobar que se descartaron los dos primeros y no
 * "los tres que salieron feos".
 *
 * 'filasEsperadasOk' es la red de seguridad del experimento. banco.transaccion
 * tiene id como PRIMARY KEY, y BancoXyzSkipPolicy considera DuplicateKeyException
 * un dato sucio OMITIBLE. Si el TRUNCATE previo fallara, la segunda repeticion
 * omitiria casi todas las filas, terminaria COMPLETED y seria MUY RAPIDA: un
 * numero falso con aspecto de exito. Por eso cada ejecucion comprueba que se
 * leyeron exactamente las filas del dataset, y las que no cumplen se excluyen
 * del analisis DECLARANDOLO.
 *
 * Todos los contadores son long: en Spring Batch 5.x los getters de
 * StepExecution devuelven long (en 4.x eran int).
 */
public record ResultadoExperimento(
        CasoExperimento caso,
        int ronda,
        boolean calentamiento,
        /** Reloj primario: nanosegundos medidos alrededor de jobLauncher.run(). */
        long wallClockNanos,
        /** Reloj secundario: END_TIME - START_TIME de JobExecution, en ms. */
        long jobExecutionMs,
        String batchStatus,
        String exitCode,
        long readCount,
        long writeCount,
        long filterCount,
        long skipCount,
        long commitCount,
        long rollbackCount,
        /** Duracion de la particion mas lenta (o del step unico si no hay particiones). */
        long maxParticionMs,
        /** Suma de las duraciones de todas las particiones. sum/max = speedup interno. */
        long sumParticionMs,
        /** max(readCount hija) / media(readCount hija). 1.0 = reparto perfecto. */
        double skew,
        /** max/min de duracion entre particiones. Dispersion, NO es lo mismo que skew. */
        double ratioMaxMin,
        /** Nombres de hilo distintos observados. Es la PRUEBA de paralelismo real. */
        int hilosDistintos,
        boolean filasEsperadasOk,
        int hikariPoolSize,
        int cpus,
        int heapMaxMb,
        String instanteIso,
        Long jobExecutionId) {

    public long wallClockMs() {
        return wallClockNanos / 1_000_000L;
    }

    /** Filas leidas por segundo. Es la magnitud que hay que graficar contra el paralelismo. */
    public double throughput() {
        double segundos = wallClockNanos / 1_000_000_000d;
        return segundos == 0 ? 0 : readCount / segundos;
    }

    /** Solo las repeticiones medidas Y validas entran en las medianas. */
    public boolean cuentaParaElAnalisis() {
        return !calentamiento && filasEsperadasOk && "COMPLETED".equals(batchStatus);
    }
}
