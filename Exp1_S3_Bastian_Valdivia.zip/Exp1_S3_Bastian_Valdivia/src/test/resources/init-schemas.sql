-- Lo ejecuta Testcontainers al arrancar el PostgreSQL de pruebas,
-- ANTES de que la aplicacion se conecte. Equivale a docker/initdb/00-schemas.sql
-- en el entorno real: los dos esquemas deben existir antes que nada.
CREATE SCHEMA IF NOT EXISTS banco;
CREATE SCHEMA IF NOT EXISTS batch_meta;
