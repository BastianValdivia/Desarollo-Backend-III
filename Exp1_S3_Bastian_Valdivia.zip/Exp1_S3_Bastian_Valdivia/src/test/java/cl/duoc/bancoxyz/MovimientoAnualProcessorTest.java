package cl.duoc.bancoxyz;

import cl.duoc.bancoxyz.domain.MovimientoAnual;
import cl.duoc.bancoxyz.domain.MovimientoAnualRaw;
import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import cl.duoc.bancoxyz.processor.MovimientoAnualProcessor;
import cl.duoc.bancoxyz.support.NormalizadorFecha;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.catchThrowableOfType;

/**
 * Pruebas unitarias de MovimientoAnualProcessor: UNA REGLA DE NEGOCIO POR TEST.
 *
 * ------------------------------------------------------------------------
 * POR QUE ESTE TEST NO USA NI SPRING NI BASE DE DATOS
 * ------------------------------------------------------------------------
 * El processor es una funcion pura: entra un MovimientoAnualRaw, sale un
 * MovimientoAnual o una excepcion. No necesita contexto, ni conexion, ni
 * Docker. Los tres normalizadores se instancian con `new` porque no tienen
 * dependencias.
 *
 * La ventaja practica: este test corre en milisegundos, asi que las reglas de
 * negocio quedan fijadas ANTES de montar toda la fontaneria de Spring Batch. Si
 * una regla esta mal, se descubre aqui y no despues de un job de 1000 filas
 * cuyo unico sintoma seria "un COUNT(*) da 172 en vez de 173".
 *
 * Es la base de la piramide de pruebas: muchos tests unitarios rapidos que
 * dicen POR QUE falla algo, y unos pocos de integracion (JobAnualesTest) que
 * dicen QUE el conjunto funciona.
 *
 * ------------------------------------------------------------------------
 * LOS VALORES SON REALES, NO INVENTADOS
 * ------------------------------------------------------------------------
 * Todos los casos salen de cuentas_anuales.csv (tipos, formatos de fecha,
 * montos negativos, descripciones vacias). Un test con datos inventados prueba
 * que el codigo hace lo que el codigo hace; con datos reales prueba que hace lo
 * que el fichero necesita.
 */
@DisplayName("MovimientoAnualProcessor - las reglas del Job 3")
class MovimientoAnualProcessorTest {

    /** jobExecutionId ficticio: aqui no se escribe en ninguna base. */
    private static final long JOB_ID = 999L;

    private final MovimientoAnualProcessor processor = new MovimientoAnualProcessor(
            new NormalizadorFecha(), new NormalizadorMonto(), new NormalizadorTexto(), JOB_ID);

    /** Atajo para construir una fila cruda sin repetir los 5 argumentos. */
    private static MovimientoAnualRaw fila(String cuenta, String fecha, String tipo,
                                           String monto, String descripcion) {
        return new MovimientoAnualRaw(cuenta, fecha, tipo, monto, descripcion);
    }

    // ==================================================================
    @Nested
    @DisplayName("Normalizacion del tipo y asignacion del signo")
    class TipoYSigno {

        /**
         * LA REGLA DE LA TILDE, que es la transformacion estrella del enunciado.
         *
         * En el fichero conviven las dos grafias del deposito. Si no se
         * normalizaran, serian dos tipos distintos: uno violaria ck_mov_tipo y
         * tumbaria su chunk entero.
         */
        @ParameterizedTest(name = "\"{0}\" se canoniza a DEPOSITO con signo +1")
        @ValueSource(strings = {"deposito", "depósito", "DEPOSITO", "Depósito", "  deposito  "})
        void elDepositoSeCanonizaYSuma(String grafia) {
            MovimientoAnual m = processor.process(fila("101", "08-03-2024", grafia, "3000", "Sueldo"));

            assertThat(m.getTransaccion()).isEqualTo("DEPOSITO");
            assertThat(m.getSigno()).as("un deposito SUMA al saldo").isEqualTo(1);
            // El original se conserva SIN normalizar: es la evidencia auditable
            // de que la transformacion ocurrio.
            assertThat(m.getTransaccionOriginal()).isEqualTo(grafia.trim());
        }

        @ParameterizedTest(name = "\"{0}\" -> {1} con signo -1")
        @CsvSource({"retiro,RETIRO", "pago,PAGO", "compra,COMPRA", "COMPRA,COMPRA"})
        void losDemasTiposRestan(String crudo, String esperado) {
            MovimientoAnual m = processor.process(fila("110", "24-07-2024", crudo, "1500", "Varios"));

            assertThat(m.getTransaccion()).isEqualTo(esperado);
            assertThat(m.getSigno()).as("todo lo que no es deposito RESTA").isEqualTo(-1);
        }

        /**
         * LA LISTA BLANCA. Un tipo desconocido NO entra a la tabla: se rechaza.
         *
         * Es la red que impide que un fallo de codificacion llegue al INSERT y
         * viole ck_mov_tipo, lo que tumbaria el chunk entero de 200 filas en vez
         * de perder una sola. Sobre el fichero real se esperan 0 casos.
         */
        @ParameterizedTest(name = "el tipo \"{0}\" se rechaza como TIPO_AUSENTE")
        @ValueSource(strings = {"transferencia", "DEPA3SITO", "", "   ", "xyz"})
        void unTipoDesconocidoSeRechaza(String tipoMalo) {
            RegistroInvalidoException e = catchThrowableOfType(
                    () -> processor.process(fila("101", "08-03-2024", tipoMalo, "100", "d")),
                    RegistroInvalidoException.class);

            assertThat(e).isNotNull();
            assertThat(e.getMotivo()).isEqualTo("TIPO_AUSENTE");
            assertThat(e.getCampo()).isEqualTo("transaccion");
        }
    }

    // ==================================================================
    @Nested
    @DisplayName("Las 4 fechas mezcladas del fichero")
    class Fechas {

        /**
         * En los formatos con barra o guion el PRIMER numero es el DIA. Por eso
         * "24-07-2024" es 24 de julio y no un mes 24 inexistente. Cada caso
         * comprueba ademas que se registra QUE patron lo leyo.
         */
        @ParameterizedTest(name = "{0} ({1}) -> {2}")
        @CsvSource({
                "2024-03-08, yyyy-MM-dd, 2024-03-08",
                "08-03-2024, dd-MM-yyyy, 2024-03-08",
                "08/03/2024, dd/MM/yyyy, 2024-03-08",
                "2024/03/08, yyyy/MM/dd, 2024-03-08",
                "24-07-2024, dd-MM-yyyy, 2024-07-24"
        })
        void losCuatroFormatosSeUnifican(String crudo, String patron, String esperada) {
            MovimientoAnual m = processor.process(fila("101", crudo, "deposito", "100", "d"));

            assertThat(m.getFecha()).hasToString(esperada);
            assertThat(m.getFormatoFecha()).as("se registra con que patron se leyo").isEqualTo(patron);
            assertThat(m.getFechaOriginal()).isEqualTo(crudo);
        }

        /**
         * Sobre cuentas_anuales.csv se esperan 0 fechas invalidas, pero la regla
         * existe igual. "2024-02-30" es el caso interesante: con el resolutor
         * permisivo de Java se corregiria en silencio a 2024-02-29, inventando
         * un dato. NormalizadorFecha usa ResolverStyle.STRICT justo para que no
         * pase.
         */
        @ParameterizedTest(name = "la fecha \"{0}\" se rechaza")
        @ValueSource(strings = {"2024-13-01", "2024-02-30", "no-es-fecha", ""})
        void unaFechaImposibleSeRechaza(String fechaMala) {
            RegistroInvalidoException e = catchThrowableOfType(
                    () -> processor.process(fila("101", fechaMala, "deposito", "100", "d")),
                    RegistroInvalidoException.class);

            assertThat(e).isNotNull();
            assertThat(e.getMotivo()).isEqualTo("FECHA_INVALIDA");
        }
    }

    // ==================================================================
    @Nested
    @DisplayName("Monto: rechazo vs anomalia")
    class Montos {

        /**
         * LOS 48 RECHAZOS DEL CONTRATO. Sin monto no hay importe que guardar y
         * la columna es NOT NULL: es irrecuperable, no una anomalia.
         */
        @ParameterizedTest(name = "el monto \"{0}\" se rechaza como MONTO_AUSENTE")
        @ValueSource(strings = {"", "   "})
        void elMontoVacioSeRechaza(String vacio) {
            RegistroInvalidoException e = catchThrowableOfType(
                    () -> processor.process(fila("103", "08-03-2024", "deposito", vacio, "Sueldo")),
                    RegistroInvalidoException.class);

            assertThat(e).isNotNull();
            assertThat(e.getMotivo()).isEqualTo("MONTO_AUSENTE");
            assertThat(e.getCampo()).isEqualTo("monto");
            // La linea cruda viaja dentro de la excepcion: es lo que
            // RechazoListener guarda en el dead letter para poder auditarla.
            assertThat(e.getLineaCruda()).contains("103").contains("Sueldo");
        }

        @Test
        @DisplayName("Un monto no numerico se rechaza con un motivo DISTINTO al de ausente")
        void elMontoNoNumericoTieneSuPropioMotivo() {
            // Se cuentan por separado a proposito: 48 ausentes y 0 no numericos.
            // Fundirlos en un solo motivo perderia esa distincion.
            assertThatThrownBy(() -> processor.process(
                    fila("103", "08-03-2024", "deposito", "abc", "d")))
                    .isInstanceOf(RegistroInvalidoException.class)
                    .extracting(t -> ((RegistroInvalidoException) t).getMotivo())
                    .isEqualTo("MONTO_NO_NUMERICO");
        }

        /**
         * EL MONTO SE GUARDA SIEMPRE EN VALOR ABSOLUTO.
         *
         * ck_mov_monto exige monto >= 0, y la restriccion ck_eca_saldo del
         * consolidado solo cuadra si el signo depende UNICAMENTE del tipo.
         */
        @Test
        @DisplayName("Un retiro con monto negativo se guarda en positivo y se marca la anomalia")
        void elMontoNegativoSeGuardaEnPositivo() {
            MovimientoAnual m = processor.process(
                    fila("105", "08-03-2024", "retiro", "-500", "Cajero"));

            assertThat(m.getMonto()).isEqualByComparingTo("500");
            assertThat(m.getSigno()).isEqualTo(-1);
            // El signo crudo se conserva para poder auditar la correccion.
            assertThat(m.getMontoOriginal()).isEqualTo("-500");
            assertThat(m.getEstado()).isEqualTo("ANOMALA_MONTO_NEGATIVO");
        }

        @Test
        @DisplayName("Un monto 0 se marca ANOMALA_MONTO_CERO (y no como negativo)")
        void elMontoCeroSeMarca() {
            MovimientoAnual m = processor.process(
                    fila("107", "08-03-2024", "compra", "0", "Compra anulada"));

            assertThat(m.getEstado()).isEqualTo("ANOMALA_MONTO_CERO");
            assertThat(m.getMonto()).isEqualByComparingTo("0");
        }

        @Test
        @DisplayName("\"0.00\" tambien es cero: se compara con signum(), no con equals()")
        void elCeroConDecimalesTambienCuenta() {
            // BigDecimal.equals compara TAMBIEN la escala, asi que "0.00" no es
            // equals a ZERO. Usar equals aqui dejaria filas sin marcar.
            MovimientoAnual m = processor.process(
                    fila("107", "08-03-2024", "compra", "0.00", "Anulada"));

            assertThat(m.getEstado()).isEqualTo("ANOMALA_MONTO_CERO");
        }
    }

    // ==================================================================
    @Nested
    @DisplayName("La regla mas delicada: el signo contradictorio")
    class SignoContradictorio {

        /**
         * ESTE ES EL TEST QUE PROTEGE EL CONTRATO 173 / 81.
         *
         * Un deposito con monto negativo es a la vez "monto negativo" y
         * "contradiccion de signo". Si ganara MONTO_NEGATIVO, la anomalia de
         * signo saldria 0 y el reparto seria 254/0 en vez de 173/81.
         */
        @Test
        @DisplayName("Un deposito con monto negativo es SIGNO_CONTRADICTORIO, no MONTO_NEGATIVO")
        void elDepositoNegativoGanaEnPrecedencia() {
            MovimientoAnual m = processor.process(
                    fila("101", "08-03-2024", "deposito", "-100", "Abono"));

            assertThat(m.getEstado()).isEqualTo("ANOMALA_SIGNO_CONTRADICTORIO");
            // Y ADEMAS: no se anaden las dos. Es UN defecto descrito de dos
            // maneras. Si aqui apareciera tambien MONTO_NEGATIVO, el recuento
            // por UNNEST daria 254 y habria filas con 3 anomalias.
            assertThat(m.getAnomalias()).isEqualTo("ANOMALA_SIGNO_CONTRADICTORIO");
            assertThat(m.getAnomalias()).doesNotContain("ANOMALA_MONTO_NEGATIVO");
        }

        @Test
        @DisplayName("El signo sigue siendo +1 y el monto positivo: es lo que hace cuadrar ck_eca_saldo")
        void laContradiccionNoAlteraElSigno() {
            MovimientoAnual m = processor.process(
                    fila("101", "08-03-2024", "deposito", "-100", "Abono"));

            // Si se guardara con signo -1, saldo_neto (SUM de monto_con_signo)
            // dejaria de cuadrar con la resta de totales por tipo, y el INSERT
            // del consolidado fallaria contra ck_eca_saldo.
            assertThat(m.getSigno()).isEqualTo(1);
            assertThat(m.getMonto()).isEqualByComparingTo("100");
        }

        @Test
        @DisplayName("Un retiro negativo NO es contradictorio: ese tipo ya resta")
        void elRetiroNegativoNoEsContradictorio() {
            MovimientoAnual m = processor.process(
                    fila("105", "08-03-2024", "retiro", "-500", "Cajero"));

            assertThat(m.getAnomalias()).isEqualTo("ANOMALA_MONTO_NEGATIVO");
        }
    }

    // ==================================================================
    @Nested
    @DisplayName("Descripcion ausente")
    class Descripcion {

        @ParameterizedTest(name = "la descripcion \"{0}\" se rellena y se marca")
        @ValueSource(strings = {"", "   "})
        void laDescripcionVaciaSeRellena(String vacia) {
            MovimientoAnual m = processor.process(
                    fila("110", "24-07-2024", "retiro", "1500", vacia));

            // La columna es NOT NULL: hay que poner algo. Se marca la anomalia
            // para que quede claro que el texto lo puso el proceso.
            assertThat(m.getDescripcion()).isEqualTo("SIN DESCRIPCION");
            assertThat(m.getEstado()).isEqualTo("ANOMALA_DESCRIPCION_AUSENTE");
        }

        @Test
        @DisplayName("Una descripcion presente se conserva tal cual y la fila es VALIDA")
        void laDescripcionPresenteSeConserva() {
            MovimientoAnual m = processor.process(
                    fila("103", "08-03-2024", "deposito", "3000", "Retiro parcial"));

            assertThat(m.getDescripcion()).isEqualTo("Retiro parcial");
            assertThat(m.getEstado()).isEqualTo("VALIDA");
            assertThat(m.getAnomalias()).isEmpty();
        }
    }

    // ==================================================================
    @Nested
    @DisplayName("Estado excluyente vs columna de anomalias")
    class EstadoYAnomalias {

        /**
         * LA DIFERENCIA ENTRE LAS DOS COLUMNAS, que es lo que hace que los
         * numeros del contrato cuadren:
         *   estado    -> UNO solo, el mas grave (ck_mov_estado no admite listas)
         *   anomalias -> TODAS, separadas por coma
         */
        @Test
        @DisplayName("Con dos anomalias, el estado es la mas grave pero se registran ambas")
        void elEstadoEsUnoYLasAnomaliasTodas() {
            // Retiro negativo Y sin descripcion: dos defectos independientes.
            MovimientoAnual m = processor.process(
                    fila("105", "08-03-2024", "retiro", "-500", ""));

            assertThat(m.getEstado())
                    .as("MONTO_NEGATIVO es mas grave que DESCRIPCION_AUSENTE")
                    .isEqualTo("ANOMALA_MONTO_NEGATIVO");
            assertThat(m.getAnomalias())
                    .isEqualTo("ANOMALA_MONTO_NEGATIVO,ANOMALA_DESCRIPCION_AUSENTE");
            assertThat(m.getDescripcion()).isEqualTo("SIN DESCRIPCION");
        }

        @Test
        @DisplayName("El estado nunca es ANOMALA_MULTIPLE: ck_mov_estado no lo admite")
        void nuncaSeGuardaUnEstadoCompuesto() {
            MovimientoAnual m = processor.process(
                    fila("101", "08-03-2024", "deposito", "-100", ""));

            // Dos anomalias, un solo estado. Guardar 'ANOMALA_MULTIPLE'
            // provocaria un fallo de restriccion en el WRITE.
            assertThat(m.getEstado()).isEqualTo("ANOMALA_SIGNO_CONTRADICTORIO");
            assertThat(m.getAnomalias()).contains(",");
        }
    }

    // ==================================================================
    @Test
    @DisplayName("numero_linea = itemCount + 1, sin sumar offset de particion")
    void elNumeroDeLineaEsLaPosicionFisica() {
        MovimientoAnualRaw raw = fila("103", "08-03-2024", "deposito", "3000", "Sueldo");
        // Es lo que hace el FlatFileItemReader al leer la fila 1 de datos.
        raw.setItemCount(1);

        MovimientoAnual m = processor.process(raw);

        // 2 = la primera fila de datos del CSV, contando la cabecera. Como cada
        // particion lee el fichero ENTERO (FiltroRangoCuentaReader), itemCount
        // ya es la posicion real: sumar tambien un offset de particion daria
        // numeros de linea inventados.
        assertThat(m.getNumeroLinea()).isEqualTo(2L);
        assertThat(m.getJobExecutionId()).isEqualTo(JOB_ID);
    }
}
