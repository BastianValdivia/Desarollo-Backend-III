package cl.duoc.bancoxyz;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Prueba de integracion del Job 3 contra un PostgreSQL 17 REAL.
 *
 * Testcontainers y no H2, por el mismo motivo que en los Jobs 1 y 2: este job
 * depende de cosas que solo hace PostgreSQL de verdad -columnas GENERATED
 * ALWAYS STORED (anio, monto_con_signo), COUNT(*) FILTER, ON CONFLICT DO
 * UPDATE, restricciones CHECK-. Con una base "parecida" el test pasaria y la
 * ejecucion real fallaria, que es el peor resultado posible.
 *
 * Lo que demuestra, en orden:
 *   - la REGLA DE ORO: 952 + 48 = 1000, ninguna fila se pierde
 *   - el reparto exacto por estado que fija el contrato
 *   - que el particionado por cuenta lee 1000 filas y no 4000
 *   - que el consolidado (20 cuentas) es fiel al detalle
 *   - que el informe de auditoria se escribe y cuadra
 *   - que dos corridas seguidas siguen dando 1000 (idempotencia)
 */
@SpringBootTest
@ActiveProfiles("test")
@Testcontainers
@DisplayName("Job 3 - jobEstadosCuentaAnuales")
class JobAnualesTest {

    @Container
    static final PostgreSQLContainer<?> POSTGRES =
            new PostgreSQLContainer<>("postgres:17-alpine")
                    .withInitScript("init-schemas.sql");

    @DynamicPropertySource
    static void datasource(DynamicPropertyRegistry registro) {
        registro.add("spring.datasource.url", () -> {
            String url = POSTGRES.getJdbcUrl();
            return url + (url.contains("?") ? "&" : "?") + "currentSchema=batch_meta,banco,public";
        });
        registro.add("spring.datasource.username", POSTGRES::getUsername);
        registro.add("spring.datasource.password", POSTGRES::getPassword);
        registro.add("spring.datasource.driver-class-name", () -> "org.postgresql.Driver");
    }

    @Autowired JobLauncher jobLauncher;
    @Autowired Job jobEstadosCuentaAnuales;
    @Autowired JdbcTemplate jdbc;

    // ==================================================================
    // TEST 1: la regla de oro y el reparto exacto
    // ==================================================================
    @Test
    @DisplayName("Procesa las 1000 filas: 952 de negocio + 48 rechazos, sin perder ninguna")
    void procesaLas1000FilasSinPerderNinguna() throws Exception {
        JobExecution ejecucion = jobLauncher.run(jobEstadosCuentaAnuales, parametros(100L));
        assertThat(ejecucion.getStatus()).isEqualTo(BatchStatus.COMPLETED);

        // -- el particionado ocurrio DE VERDAD: 4 workers ademas del manager
        assertThat(particiones(ejecucion).count()).as("particiones ejecutadas").isEqualTo(4);

        // -- LA COMPROBACION DEL ENVOLTORIO DE LECTURA.
        //    Cada particion lee el fichero ENTERO y descarta lo ajeno. Si
        //    FiltroRangoCuentaReader hiciera `return` en vez de `continue`, cada
        //    particion terminaria en su primera fila ajena y esta suma daria 4
        //    en vez de 1000.
        //    Y si el descarte se hiciera en el PROCESSOR devolviendo null, la
        //    suma daria 4000 con 3000 filtradas. Que de 1000 con 0 filtradas es
        //    la prueba de que se filtra en la LECTURA.
        long leidas = particiones(ejecucion).mapToLong(se -> se.getReadCount()).sum();
        long filtradas = particiones(ejecucion).mapToLong(se -> se.getFilterCount()).sum();
        assertThat(leidas).as("SUM(read_count) de las 4 particiones").isEqualTo(1000);
        assertThat(filtradas).as("nada se filtro en silencio").isZero();

        // -- LA REGLA DE ORO, contada sobre lo que de verdad quedo en la base
        int negocio = contar("SELECT COUNT(*) FROM banco.movimiento_anual");
        int rechazos = contar("SELECT COUNT(*) FROM banco.registro_rechazado"
                + " WHERE archivo_origen='cuentas_anuales.csv'");
        assertThat(negocio).isEqualTo(952);
        assertThat(rechazos).isEqualTo(48);
        assertThat(negocio + rechazos).as("REGLA DE ORO").isEqualTo(1000);

        // -- el reparto por estado, valor por valor
        Map<String, Integer> esperado = Map.of(
                "VALIDA", 524,
                "ANOMALA_MONTO_NEGATIVO", 173,
                "ANOMALA_DESCRIPCION_AUSENTE", 162,
                "ANOMALA_SIGNO_CONTRADICTORIO", 81,
                "ANOMALA_MONTO_CERO", 12);
        esperado.forEach((estado, n) -> assertThat(contar(
                "SELECT COUNT(*) FROM banco.movimiento_anual WHERE estado='" + estado + "'"))
                .as("estado " + estado).isEqualTo(n));

        // -- los 48 rechazos son TODOS del mismo motivo y de la fase PROCESS.
        //    La fase importa: significa que los detecto el processor y no la
        //    base de datos al escribir.
        assertThat(contar("SELECT COUNT(*) FROM banco.registro_rechazado"
                + " WHERE archivo_origen='cuentas_anuales.csv'"
                + " AND motivo='MONTO_AUSENTE' AND fase='PROCESS'")).isEqualTo(48);
    }

    // ==================================================================
    // TEST 2: la decision de precedencia mas delicada del job
    // ==================================================================
    @Test
    @DisplayName("SIGNO_CONTRADICTORIO sustituye a MONTO_NEGATIVO, no se suma a el")
    void laPrecedenciaDelSignoSeRespeta() throws Exception {
        assertThat(jobLauncher.run(jobEstadosCuentaAnuales, parametros(150L)).getStatus())
                .isEqualTo(BatchStatus.COMPLETED);

        // Desglosa la columna 'anomalias', que NO es excluyente.
        //
        // SI AQUI MONTO_NEGATIVO DIERA 254, se habria implantado la variante
        // "aditiva" (marcar las dos anomalias en el deposito negativo) y el
        // contrato de docs/analisis-datos.md dejaria de cumplirse.
        Map<String, Integer> instancias = jdbc.queryForList("""
                        SELECT TRIM(a) AS anomalia, COUNT(*) AS n
                          FROM banco.movimiento_anual m,
                               LATERAL UNNEST(STRING_TO_ARRAY(NULLIF(m.anomalias,''),',')) a
                         GROUP BY 1
                        """).stream()
                .collect(java.util.stream.Collectors.toMap(
                        f -> (String) f.get("anomalia"),
                        f -> ((Number) f.get("n")).intValue()));

        assertThat(instancias).containsEntry("ANOMALA_MONTO_NEGATIVO", 173);
        assertThat(instancias).containsEntry("ANOMALA_SIGNO_CONTRADICTORIO", 81);
        assertThat(instancias).containsEntry("ANOMALA_MONTO_CERO", 12);
        // 220 y no 230: 10 de las 230 filas con descripcion vacia tienen ademas
        // el monto vacio y se rechazan ANTES de llegar a esa comprobacion.
        assertThat(instancias).containsEntry("ANOMALA_DESCRIPCION_AUSENTE", 220);

        // Ninguna fila puede llevar 3 anomalias: seria la firma de la variante
        // aditiva. El reparto correcto es 524 / 370 / 58.
        assertThat(contar("""
                SELECT COUNT(*) FROM banco.movimiento_anual
                 WHERE ARRAY_LENGTH(STRING_TO_ARRAY(anomalias,','),1) > 2
                """)).as("ninguna fila con 3 anomalias").isZero();
    }

    // ==================================================================
    // TEST 3: las transformaciones que pide el enunciado
    // ==================================================================
    @Test
    @DisplayName("Normaliza tildes y fechas, y guarda el monto SIEMPRE en positivo")
    void normalizaLosDatosSucios() throws Exception {
        assertThat(jobLauncher.run(jobEstadosCuentaAnuales, parametros(200L)).getStatus())
                .isEqualTo(BatchStatus.COMPLETED);

        // -- LA TILDE: las dos grafias acaban en el mismo tipo canonico.
        //    Si no se normalizara, la grafia acentuada violaria ck_mov_tipo y el
        //    chunk entero se caeria.
        assertThat(contar("SELECT COUNT(DISTINCT transaccion) FROM banco.movimiento_anual"))
                .as("solo 4 tipos canonicos").isEqualTo(4);
        assertThat(contar("SELECT COUNT(*) FROM banco.movimiento_anual"
                + " WHERE transaccion='DEPOSITO' AND transaccion_original <> 'deposito'"))
                .as("depositos que venian escritos con tilde").isEqualTo(52);

        // -- LAS FECHAS: los 4 formatos se unifican y ninguna queda sin leer.
        assertThat(contar("SELECT COUNT(DISTINCT formato_fecha) FROM banco.movimiento_anual"))
                .isEqualTo(4);
        assertThat(contar("SELECT COUNT(*) FROM banco.movimiento_anual WHERE anio <> 2024"))
                .as("todas las fechas caen en 2024").isZero();

        // -- EL MONTO SIEMPRE POSITIVO Y EL SIGNO SIEMPRE POR TIPO.
        //    Es lo que hace que ck_eca_saldo pueda cuadrar en el consolidado.
        assertThat(contar("SELECT COUNT(*) FROM banco.movimiento_anual WHERE monto < 0"))
                .as("ck_mov_monto exige monto >= 0").isZero();
        assertThat(contar("""
                SELECT COUNT(*) FROM banco.movimiento_anual
                 WHERE (transaccion='DEPOSITO' AND signo <> 1)
                    OR (transaccion<>'DEPOSITO' AND signo <> -1)
                """)).as("el signo lo decide el TIPO, nunca el monto").isZero();

        // -- LA DESCRIPCION rellenada, nunca en blanco.
        assertThat(contar("SELECT COUNT(*) FROM banco.movimiento_anual"
                + " WHERE descripcion='SIN DESCRIPCION'")).isEqualTo(220);
        assertThat(contar("SELECT COUNT(*) FROM banco.movimiento_anual"
                + " WHERE TRIM(descripcion)=''")).isZero();
    }

    // ==================================================================
    // TEST 4: el consolidado y el informe de auditoria
    // ==================================================================
    @Test
    @DisplayName("Consolida las 20 cuentas y escribe el informe cuadrado")
    void consolidaYExportaElInforme() throws Exception {
        JobExecution ejecucion = jobLauncher.run(jobEstadosCuentaAnuales, parametros(300L));
        assertThat(ejecucion.getStatus()).isEqualTo(BatchStatus.COMPLETED);

        // -- 20 filas, una por cuenta, y suman los 952 movimientos
        Map<String, Object> t = jdbc.queryForMap("""
                SELECT COUNT(*) AS filas, MIN(cuenta_id) AS mini, MAX(cuenta_id) AS maxi,
                       SUM(n_movimientos) AS movs, SUM(n_anomalias) AS anom
                  FROM banco.estado_cuenta_anual
                """);
        assertThat(((Number) t.get("filas")).intValue()).isEqualTo(20);
        assertThat(((Number) t.get("mini")).intValue()).isEqualTo(101);
        assertThat(((Number) t.get("maxi")).intValue()).isEqualTo(120);
        assertThat(((Number) t.get("movs")).intValue()).isEqualTo(952);
        // n_anomalias cuenta FILAS con algun problema (952 - 524 validas), no
        // instancias de anomalia (que son 486).
        assertThat(((Number) t.get("anom")).intValue()).as("filas no validas").isEqualTo(428);

        // -- LA CUADRATURA CONTABLE: el agregado se puede reconstruir desde el
        //    detalle, cuenta por cuenta. Es lo que separa "exporte una tabla" de
        //    "el informe dice la verdad".
        assertThat(contar("""
                SELECT COUNT(*)
                  FROM banco.estado_cuenta_anual e
                  JOIN (SELECT cuenta_id, anio, SUM(monto_con_signo) s, COUNT(*) n
                          FROM banco.movimiento_anual GROUP BY 1,2) m
                    ON m.cuenta_id=e.cuenta_id AND m.anio=e.anio
                 WHERE e.saldo_neto IS DISTINCT FROM m.s
                    OR e.n_movimientos IS DISTINCT FROM m.n
                """)).as("cuentas descuadradas").isZero();

        // -- EL FICHERO DE AUDITORIA existe y tiene las 20 cuentas.
        Path informe = Paths.get("results",
                "estados-cuenta-anual-" + ejecucion.getId() + ".csv");
        assertThat(informe).exists();

        List<String> lineas = Files.readAllLines(informe, StandardCharsets.UTF_8);

        // Las lineas de datos son las que no son comentario ni estan vacias,
        // descontando la fila de nombres de columna.
        long datos = lineas.stream()
                .filter(l -> !l.startsWith("#") && !l.isBlank())
                .filter(l -> !l.startsWith("cuenta_id;"))
                .count();
        assertThat(datos).as("una linea por cuenta").isEqualTo(20);

        // La cabecera identifica la ejecucion: es lo que permite rastrear el
        // fichero hasta BATCH_JOB_EXECUTION seis meses despues.
        assertThat(lineas.get(1)).contains("job_execution_id: " + ejecucion.getId());

        // Y el pie imprime la Regla de Oro dentro del propio entregable.
        assertThat(String.join("\n", lineas))
                .contains("CUADRATURA            : 952 + 48 = 1000")
                .contains("cuentas consolidadas  : 20");
    }

    // ==================================================================
    // TEST 5: idempotencia
    // ==================================================================
    @Test
    @DisplayName("Dos corridas seguidas siguen dando 1000, no 2000")
    void dosCorridasSeguidasNoDuplicanNada() throws Exception {
        assertThat(jobLauncher.run(jobEstadosCuentaAnuales, parametros(401L)).getStatus())
                .isEqualTo(BatchStatus.COMPLETED);
        JobExecution segunda = jobLauncher.run(jobEstadosCuentaAnuales, parametros(402L));
        assertThat(segunda.getStatus()).isEqualTo(BatchStatus.COMPLETED);

        // Sin la limpieza de stepPrepararAnuales esto daria 1904 y 96: la vista
        // banco.v_cuadratura cuenta la tabla ENTERA, sin filtrar por ejecucion.
        assertThat(contar("SELECT COUNT(*) FROM banco.movimiento_anual")).isEqualTo(952);
        assertThat(contar("SELECT COUNT(*) FROM banco.registro_rechazado"
                + " WHERE archivo_origen='cuentas_anuales.csv'")).isEqualTo(48);
        assertThat(contar("SELECT COUNT(*) FROM banco.estado_cuenta_anual")).isEqualTo(20);

        // TODAS las filas son de la ULTIMA ejecucion. Esto es lo que caza el
        // fallo sutil de un ON CONFLICT DO UPDATE que no refresca
        // job_execution_id: las 20 filas se actualizarian pero conservarian el
        // id viejo, el lector del informe (que filtra por el id actual) no
        // encontraria nada y el informe saldria SIN datos.
        assertThat(jdbc.queryForList("SELECT DISTINCT job_execution_id"
                        + " FROM banco.estado_cuenta_anual", Long.class))
                .as("el consolidado pertenece a la ultima corrida")
                .containsExactly(segunda.getId());

        // Y el informe de la segunda corrida tiene datos de verdad.
        Path informe = Paths.get("results", "estados-cuenta-anual-" + segunda.getId() + ".csv");
        assertThat(informe).exists();
        assertThat(Files.readAllLines(informe, StandardCharsets.UTF_8).stream()
                .filter(l -> !l.startsWith("#") && !l.isBlank())
                .filter(l -> !l.startsWith("cuenta_id;"))
                .count()).as("el informe de la 2a corrida NO esta vacio").isEqualTo(20);

        // La cuadratura global sigue cerrando en la vista de entrega.
        Map<String, Object> v = jdbc.queryForMap(
                "SELECT * FROM banco.v_cuadratura WHERE archivo='cuentas_anuales.csv'");
        assertThat(((Number) v.get("total")).intValue()).isEqualTo(1000);
    }

    // ==================================================================
    // TEST 6: la restriccion contable se sostiene
    // ==================================================================
    @Test
    @DisplayName("saldo_neto = depositos - retiros - pagos - compras, en las 20 cuentas")
    void elSaldoNetoCuadraConLosTotales() throws Exception {
        assertThat(jobLauncher.run(jobEstadosCuentaAnuales, parametros(500L)).getStatus())
                .isEqualTo(BatchStatus.COMPLETED);

        // ck_eca_saldo ya lo garantiza en la base, pero comprobarlo aqui explica
        // POR QUE el monto se guarda en valor absoluto: si el deposito
        // contradictorio se guardara con signo -1, esta igualdad se rompe.
        assertThat(contar("""
                SELECT COUNT(*) FROM banco.estado_cuenta_anual
                 WHERE saldo_neto <> total_depositos - total_retiros
                                     - total_pagos - total_compras
                """)).isZero();

        // El saldo global tambien se puede reconstruir desde el detalle.
        BigDecimal global = jdbc.queryForObject(
                "SELECT SUM(saldo_neto) FROM banco.estado_cuenta_anual", BigDecimal.class);
        BigDecimal detalle = jdbc.queryForObject(
                "SELECT SUM(monto_con_signo) FROM banco.movimiento_anual", BigDecimal.class);
        assertThat(global).isEqualByComparingTo(detalle);
    }

    // ------------------------------------------------------------------
    private java.util.stream.Stream<org.springframework.batch.core.StepExecution> particiones(
            JobExecution ejecucion) {
        return ejecucion.getStepExecutions().stream()
                .filter(se -> se.getStepName().contains(":partition"));
    }

    private int contar(String sql) {
        Integer n = jdbc.queryForObject(sql, Integer.class);
        return n == null ? 0 : n;
    }

    /**
     * run.id distinto en cada llamada: jobLauncher.run() NO aplica el
     * incrementer declarado en el @Bean del Job, asi que con parametros
     * identicos la segunda llamada moriria con
     * JobInstanceAlreadyCompleteException y estariamos "probando" otra cosa.
     */
    private static JobParameters parametros(long runId) {
        return new JobParametersBuilder()
                .addString("archivo", "data/cuentas_anuales.csv")
                .addLong("run.id", runId)
                .toJobParameters();
    }
}
