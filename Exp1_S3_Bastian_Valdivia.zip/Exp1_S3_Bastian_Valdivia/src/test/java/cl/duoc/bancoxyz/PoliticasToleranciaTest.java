package cl.duoc.bancoxyz;

import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import cl.duoc.bancoxyz.policy.BackOffPolicies;
import cl.duoc.bancoxyz.policy.BancoXyzSkipPolicy;
import cl.duoc.bancoxyz.policy.RetryPolicies;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.dao.TransientDataAccessResourceException;
import org.springframework.retry.RetryContext;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;

import java.io.FileNotFoundException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.assertThatCode;

/**
 * PRUEBAS DE LAS POLITICAS DE TOLERANCIA A FALLOS, EN AISLAMIENTO.
 *
 * No levantan Spring ni Docker: instancian las politicas a mano y les hacen
 * preguntas. Tardan milisegundos y por eso se pueden ejecutar en cada compilada.
 *
 * POR QUE HACEN FALTA, si el test de integracion ya pasa:
 * porque una politica MAL CABLEADA es INVISIBLE desde fuera. Si
 * traverseCauses fuese false, el job seguiria terminando COMPLETED con los
 * mismos 785 + 215... simplemente sin haber reintentado jamas. Estos tests
 * miran la decision, no el resultado.
 *
 * Vocabulario para quien no lo tenga fresco:
 *   - SkipPolicy: ante un error en una fila, decide OMITIR (seguir) o MORIR.
 *   - RetryPolicy: ante un error, decide VOLVER A INTENTARLO o rendirse.
 *   Son preguntas distintas y por eso son dos objetos distintos.
 */
@DisplayName("Politicas de tolerancia a fallos (skip / retry / backoff)")
class PoliticasToleranciaTest {

    // Limite generoso para que ningun test choque con el techo por accidente.
    private final SkipPolicy skip = new BancoXyzSkipPolicy(500);

    // =====================================================================
    // BLOQUE 1 - SkipPolicy: que se omite y que NO
    // =====================================================================

    /**
     * E1/E2 - Dato sucio: se omite y el proceso continua.
     *
     * Es el caso de la fecha "2024-13-01" y del monto vacio: la fila no sirve,
     * pero el archivo entero si. Omitir una de mil no es perder datos, es
     * separarlos: el dead letter la guarda en banco.registro_rechazado.
     */
    @Test
    @DisplayName("dato sucio (RegistroInvalidoException) SI se omite")
    void omiteElDatoSucio() {
        Throwable datoMalo = new RegistroInvalidoException(
                "FECHA_INVALIDA", "fecha", "2024-13-01", "7,2024-13-01,100,deposito");

        assertThat(skip.shouldSkip(datoMalo, 0)).isTrue();
    }

    /**
     * LA PRUEBA QUE DE VERDAD IMPORTA EN ESTE BLOQUE: la cadena de causas.
     *
     * Spring casi nunca entrega la excepcion "desnuda": la envuelve. Lo que
     * llega a la politica no es RegistroInvalidoException, sino algo que la
     * lleva DENTRO, a veces a dos o tres niveles de profundidad. Una politica
     * que compare solo el tipo de la excepcion de arriba diria "esto no es un
     * dato sucio" y haria FALLAR el step ante una simple fecha mal escrita.
     *
     * Por eso esDatoSucio() recorre getCause() en bucle, y por eso esto se
     * prueba con DOS envoltorios y no con uno.
     */
    @Test
    @DisplayName("lo detecta aunque venga envuelto a dos niveles de profundidad")
    void recorreLaCadenaDeCausas() {
        Throwable raiz = new RegistroInvalidoException(
                "MONTO_AUSENTE", "monto", "", "12,2024-01-05,,retiro");
        Throwable envueltaUnaVez = new RuntimeException("error procesando el item", raiz);
        Throwable envueltaDosVeces = new IllegalStateException("fallo el chunk", envueltaUnaVez);

        assertThat(skip.shouldSkip(envueltaDosVeces, 0))
                .as("la politica debe mirar DENTRO, no solo el tipo de arriba")
                .isTrue();
    }

    /** Una linea del CSV que ni siquiera se puede partir en columnas tambien es dato sucio. */
    @Test
    @DisplayName("FlatFileParseException (linea ilegible) SI se omite")
    void omiteLaLineaIlegible() {
        assertThat(skip.shouldSkip(new FlatFileParseException("linea corrupta", "a,b"), 0)).isTrue();
    }

    /**
     * E8 - Infraestructura: NO se omite. Este es el corazon de la doctrina.
     *
     * Si la base de datos se cayo, las filas que iban en ese lote estan BIEN.
     * Omitirlas seria tirar datos correctos a la basura por un problema
     * pasajero, y encima el job terminaria COMPLETED mintiendo sobre lo que
     * cargo. Lo correcto es reintentar (lo hace la RetryPolicy) y, si aun asi
     * no hay manera, FALLAR de forma ruidosa.
     */
    @Test
    @DisplayName("fallo de infraestructura NO se omite: debe hacer fallar el step")
    void noOmiteLaInfraestructura() {
        assertThat(skip.shouldSkip(new DataAccessResourceFailureException("BD caida"), 0))
                .as("conexion caida").isFalse();
        assertThat(skip.shouldSkip(new TransientDataAccessResourceException("timeout"), 0))
                .as("recurso transitorio").isFalse();
        assertThat(skip.shouldSkip(new CannotAcquireLockException("deadlock"), 0))
                .as("cerrojo ocupado").isFalse();
        assertThat(skip.shouldSkip(new OptimisticLockingFailureException("version cambiada"), 0))
                .as("bloqueo optimista").isFalse();
    }

    /**
     * E11 - Archivo de entrada ausente: fail-fast.
     *
     * Este es el escenario que demuestra que la politica DISTINGUE. Un
     * .skip(Exception.class) perezoso se tragaria el "archivo no encontrado" y
     * el job terminaria COMPLETED con cero filas cargadas, en silencio. Un job
     * que miente es peor que un job que falla.
     */
    @Test
    @DisplayName("archivo ausente NO se omite: el job debe fallar y decirlo")
    void noOmiteElArchivoAusente() {
        Throwable falta = new RuntimeException("no se pudo abrir el recurso",
                new FileNotFoundException("data/transacciones.csv"));

        assertThat(skip.shouldSkip(falta, 0)).isFalse();
    }

    /**
     * EL MODO SONDA. Trampa numero 3 del plan maestro.
     *
     * Spring Batch llama a shouldSkip con un contador NEGATIVO cuando solo
     * quiere preguntar "por curiosidad, esto seria omitible?", sin que cuente
     * como omision real. Si en ese caso la politica evaluase el limite y
     * lanzase SkipLimitExceededException, romperia el "chunk scanning" (el
     * repaso fila a fila que hace Batch tras un rollback) y el step moriria
     * cuando el framework solo estaba consultando.
     */
    @Test
    @DisplayName("modo sonda (skipCount < 0): responde sin lanzar ni tocar el limite")
    void respetaElModoSonda() {
        Throwable datoMalo = new RegistroInvalidoException("MONTO_AUSENTE", "monto", "", "linea");

        assertThatCode(() -> {
            assertThat(skip.shouldSkip(datoMalo, -1)).isTrue();
            assertThat(skip.shouldSkip(new DataAccessResourceFailureException("BD"), -1)).isFalse();
        }).doesNotThrowAnyException();
    }

    /**
     * E13 - El techo de tolerancia.
     *
     * Tolerar sin limite no es tolerancia, es negligencia: si el 90% del
     * archivo esta mal, lo correcto es parar y avisar, no cargar el 10% y
     * declarar exito. Superado el limite la politica lanza
     * SkipLimitExceededException y el job FALLA a proposito.
     */
    @Test
    @DisplayName("superado el limite de omisiones, el job falla a proposito")
    void aplicaElTechoDeTolerancia() {
        SkipPolicy conTecho = new BancoXyzSkipPolicy(10);
        Throwable datoMalo = new RegistroInvalidoException("FECHA_INVALIDA", "fecha", "x", "linea");

        assertThat(conTecho.shouldSkip(datoMalo, 9)).as("justo por debajo del techo").isTrue();
        assertThatThrownBy(() -> conTecho.shouldSkip(datoMalo, 10))
                .isInstanceOf(SkipLimitExceededException.class);
    }

    // =====================================================================
    // BLOQUE 2 - RetryPolicy: que se reintenta y que no
    // =====================================================================

    /**
     * Pregunta a la politica de reintento igual que lo hace Spring Retry por
     * dentro: se abre un contexto, se le registra la excepcion ocurrida y se le
     * pregunta si cabe otro intento.
     *
     * open(null) crea un contexto raiz (sin padre); registerThrowable es lo que
     * incrementa el contador de intentos, asi que llamarlo N veces simula N
     * fallos consecutivos.
     */
    private static boolean sePuedeReintentar(RetryPolicy politica, Throwable error, int fallosPrevios) {
        RetryContext contexto = politica.open(null);
        for (int i = 0; i <= fallosPrevios; i++) {
            politica.registerThrowable(contexto, error);
        }
        return politica.canRetry(contexto);
    }

    /**
     * LA PRUEBA QUE DEMUESTRA traverseCauses=true.
     *
     * Es la unica forma de comprobar que el tercer argumento de
     * SimpleRetryPolicy hace lo que dice el javadoc. Sin traverseCauses, la
     * excepcion envuelta NO se reconoceria, la politica devolveria "no
     * reintentable" y el reintento no se dispararia NUNCA, sin ningun sintoma
     * visible: el job seguiria terminando COMPLETED en el caso feliz.
     */
    @Test
    @DisplayName("infraestructura envuelta SI se reintenta (esto prueba traverseCauses=true)")
    void reintentaLaInfraestructuraAunqueVengaEnvuelta() {
        RetryPolicy politica = RetryPolicies.infraestructura();

        Throwable desnuda = new CannotAcquireLockException("deadlock");
        Throwable envuelta = new RuntimeException("fallo al escribir el chunk", desnuda);

        assertThat(sePuedeReintentar(politica, desnuda, 0))
                .as("cerrojo, sin envolver").isTrue();
        assertThat(sePuedeReintentar(politica, envuelta, 0))
                .as("cerrojo, envuelto: SIN traverseCauses esto seria false").isTrue();
    }

    /** E8 - la caida transitoria de la base tambien entra en el mapa. */
    @Test
    @DisplayName("caida transitoria de la BD SI se reintenta")
    void reintentaLaCaidaTransitoria() {
        assertThat(sePuedeReintentar(RetryPolicies.infraestructura(),
                new TransientDataAccessResourceException("conexion perdida"), 0)).isTrue();
    }

    /**
     * EL VETO. La otra mitad de la doctrina.
     *
     * Reintentar una fila con la fecha "2024-13-01" fallara las tres veces
     * exactamente igual: el dato no cambia entre intentos. Lo unico que se
     * consigue es multiplicar por 3 el trabajo y sumarle el backoff. Con las
     * 215 filas malas del CSV serian 645 intentos inutiles y minutos de espera
     * para acabar en el mismo sitio.
     */
    @Test
    @DisplayName("dato sucio NUNCA se reintenta")
    void noReintentaElDatoSucio() {
        RetryPolicy politica = RetryPolicies.infraestructura();
        Throwable datoMalo = new RegistroInvalidoException("FECHA_INVALIDA", "fecha", "2024-13-01", "linea");

        assertThat(sePuedeReintentar(politica, datoMalo, 0)).isFalse();
        assertThat(sePuedeReintentar(politica, new RuntimeException("envuelto", datoMalo), 0))
                .as("tampoco envuelto").isFalse();
        assertThat(sePuedeReintentar(politica, new FlatFileParseException("linea corrupta", "a,b"), 0))
                .isFalse();
    }

    /**
     * Postura segura por defecto: lo que NO esta en el mapa NO se reintenta.
     *
     * El cuarto argumento implicito de SimpleRetryPolicy(int, mapa, boolean) es
     * defaultValue=false. Asi se reintenta solo lo que se ha decidido
     * conscientemente reintentar, y una excepcion nueva y desconocida hace
     * fallar el step en vez de entrar en un bucle de esperas.
     */
    @Test
    @DisplayName("una excepcion desconocida NO se reintenta (por defecto, false)")
    void noReintentaLoDesconocido() {
        assertThat(sePuedeReintentar(RetryPolicies.infraestructura(),
                new IllegalArgumentException("bug del programador"), 0)).isFalse();
    }

    /**
     * "3 intentos" significa 3 intentos TOTALES (1 normal + 2 reintentos), no 3
     * reintentos. Confundirlo es el clasico error de contar uno de mas.
     */
    @Test
    @DisplayName("maxAttempts=3 son 3 intentos TOTALES, no 3 reintentos")
    void agotaLosIntentosAlTercero() {
        RetryPolicy politica = RetryPolicies.infraestructura();
        Throwable infra = new TransientDataAccessResourceException("BD caida");

        assertThat(RetryPolicies.INTENTOS).isEqualTo(3);
        assertThat(sePuedeReintentar(politica, infra, 0)).as("tras el 1er fallo, queda intento").isTrue();
        assertThat(sePuedeReintentar(politica, infra, 1)).as("tras el 2do fallo, queda intento").isTrue();
        assertThat(sePuedeReintentar(politica, infra, 2)).as("tras el 3er fallo, se rinde").isFalse();
    }

    // =====================================================================
    // BLOQUE 3 - BackOff: la espera entre reintentos
    // =====================================================================

    /**
     * Sin backoff los tres intentos ocurren en el mismo milisegundo: si la base
     * se cayo, los tres fallan igual y el reintento no ha servido de nada. Peor
     * aun, si el motivo era saturacion, machacarla sin pausa la hunde mas (la
     * "tormenta de reintentos").
     *
     * Aqui solo se comprueba que la politica esta configurada como se documenta;
     * el efecto real (que se espere de verdad) se ve en el log del escenario
     * BD_TRANSITORIA.
     */
    @Test
    @DisplayName("el backoff es exponencial 200ms x2 con tope de 5s")
    void elBackoffEsExponencialYAcotado() {
        ExponentialBackOffPolicy politica = (ExponentialBackOffPolicy) BackOffPolicies.exponencial();

        assertThat(politica.getInitialInterval()).isEqualTo(BackOffPolicies.ESPERA_INICIAL_MS).isEqualTo(200L);
        assertThat(politica.getMultiplier()).isEqualTo(BackOffPolicies.MULTIPLICADOR).isEqualTo(2.0);
        // El tope existe para que la progresion 200, 400, 800, 1600... no se
        // dispare si algun dia se suben los intentos.
        assertThat(politica.getMaxInterval()).isEqualTo(BackOffPolicies.ESPERA_MAXIMA_MS).isEqualTo(5_000L);
    }
}
