package cl.duoc.bancoxyz;

import cl.duoc.bancoxyz.listener.ChunkErrorListener;
import cl.duoc.bancoxyz.listener.ReintentoRetryListener;
import cl.duoc.bancoxyz.support.InyectorFallosWriter;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * ESCENARIOS DE FALLO, EJECUTADOS DE VERDAD CONTRA POSTGRESQL.
 *
 * Los tests de PoliticasToleranciaTest comprueban lo que las politicas
 * DECIDEN. Estos comprueban lo que el job HACE cuando el fallo ocurre de
 * verdad, a mitad de la escritura, con las 4 particiones corriendo en paralelo.
 * Son cosas distintas: una politica puede decidir bien y estar mal cableada al
 * step, y entonces no se aplicaria nunca.
 *
 * COMO SE PROVOCA EL FALLO SIN APAGAR DOCKER:
 * el JobParameter "simularFallo" llega hasta InyectorFallosWriter, un decorador
 * que envuelve al escritor real y lanza la excepcion fingida que toque antes de
 * delegar. Es reproducible al milimetro; apagar el contenedor con el
 * cronometro en la mano no lo es.
 *
 * AVISO SOBRE LOS CONTADORES DE LOS LISTENERS:
 * ReintentoRetryListener y ChunkErrorListener son SINGLETON y @SpringBootTest
 * comparte un unico contexto entre todos los tests de la clase, asi que sus
 * contadores ACUMULAN entre metodos. Ademas JUnit no garantiza el orden de
 * ejecucion. Por eso aqui nunca se afirma un valor absoluto: se lee el contador
 * antes, se lee despues, y se exige que el INCREMENTO sea el esperado.
 */
@SpringBootTest
@ActiveProfiles("test")
@Testcontainers
@DisplayName("Escenarios de fallo del Job 1 (reintento, backoff y fail-fast)")
class EscenariosFalloTest {

    @Container
    static final PostgreSQLContainer<?> POSTGRES =
            new PostgreSQLContainer<>("postgres:17-alpine")
                    .withInitScript("init-schemas.sql");

    @DynamicPropertySource
    static void datasource(DynamicPropertyRegistry registro) {
        registro.add("spring.datasource.url", () -> {
            String url = POSTGRES.getJdbcUrl();
            return url + (url.contains("?") ? "&" : "?") + "currentSchema=batch_meta,banco,public";
        });
        registro.add("spring.datasource.username", POSTGRES::getUsername);
        registro.add("spring.datasource.password", POSTGRES::getPassword);
        registro.add("spring.datasource.driver-class-name", () -> "org.postgresql.Driver");
    }

    @Autowired JobLauncher jobLauncher;
    @Autowired Job jobTransaccionesDiarias;
    @Autowired JdbcTemplate jdbc;
    @Autowired ReintentoRetryListener reintentoRetryListener;
    @Autowired ChunkErrorListener chunkErrorListener;

    // =====================================================================
    // E8 - CAIDA TRANSITORIA DE LA BASE: se reintenta y NO se pierde nada
    // =====================================================================

    /**
     * El escenario que justifica toda la politica de reintento.
     *
     * Cada una de las 4 particiones falla UNA vez al escribir un chunk, con una
     * TransientDataAccessResourceException (la excepcion que Spring usa para
     * "la base no responde ahora mismo"). La politica la reconoce como
     * infraestructura, espera 200 ms y lo vuelve a intentar. El segundo intento
     * pasa.
     *
     * LA ASERCION QUE IMPORTA no es el contador de reintentos, es la
     * INVARIANTE: el job termina COMPLETED y siguen estando las 1000 filas
     * (785 de negocio + 215 rechazadas). Eso es, literalmente, "el reintento se
     * recupero y no se perdio ni una fila". Si en vez de retry se hubiera hecho
     * skip, faltarian hasta 200 filas BUENAS por cada chunk fallido.
     */
    @Test
    @DisplayName("E8: fallo transitorio de BD -> se reintenta, el job COMPLETA y no se pierde ninguna fila")
    void fallosTransitoriosSeReintentanYNoSePierdeNada() throws Exception {
        long reintentosAntes = reintentoRetryListener.getIntentosFallidos();
        long rollbacksAntes = chunkErrorListener.getChunksFallidos();

        JobExecution ejecucion = jobLauncher.run(jobTransaccionesDiarias,
                parametros(301L, InyectorFallosWriter.BD_TRANSITORIA));

        assertThat(ejecucion.getStatus())
                .as("el fallo era pasajero: el reintento tiene que salvar el job")
                .isEqualTo(BatchStatus.COMPLETED);

        // El reintento ocurrio de verdad. Delta, no valor absoluto: el contador
        // es de un singleton compartido entre los tests de esta clase.
        assertThat(reintentoRetryListener.getIntentosFallidos() - reintentosAntes)
                .as("intentos fallidos registrados por ReintentoRetryListener")
                .isGreaterThan(0);
        assertThat(chunkErrorListener.getChunksFallidos() - rollbacksAntes)
                .as("chunks que hicieron rollback")
                .isGreaterThan(0);

        // LA REGLA DE ORO, intacta pese al fallo: entrada = negocio + rechazos.
        Integer negocio = jdbc.queryForObject("SELECT COUNT(*) FROM banco.transaccion", Integer.class);
        Integer rechazos = jdbc.queryForObject(
                "SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='transacciones.csv'",
                Integer.class);

        System.out.printf("[E8 BD_TRANSITORIA] estado=%s negocio=%d rechazos=%d suma=%d "
                        + "reintentos=+%d rollbacks=+%d%n",
                ejecucion.getStatus(), negocio, rechazos, negocio + rechazos,
                reintentoRetryListener.getIntentosFallidos() - reintentosAntes,
                chunkErrorListener.getChunksFallidos() - rollbacksAntes);

        assertThat(negocio).as("filas de negocio pese al fallo transitorio").isEqualTo(785);
        assertThat(rechazos).as("rechazos pese al fallo transitorio").isEqualTo(215);
        assertThat(negocio + rechazos).isEqualTo(1000);
    }

    // =====================================================================
    // E9 - CONTENCION DE BLOQUEO: misma politica, otra excepcion
    // =====================================================================

    /**
     * Un deadlock o un cerrojo ocupado es lo que pasa cuando dos de las cuatro
     * particiones tocan la misma fila a la vez. Tambien es infraestructura y
     * tambien es pasajero: el otro hilo acabara soltando el cerrojo.
     *
     * Se prueba aparte de E8 porque recorre una RAMA DISTINTA del mapa de
     * RetryPolicies (CannotAcquireLockException, no
     * TransientDataAccessResourceException). Que una funcione no demuestra que
     * la otra este declarada.
     */
    @Test
    @DisplayName("E9: contencion de cerrojo -> se reintenta y el job COMPLETA")
    void laContencionDeBloqueoSeReintenta() throws Exception {
        long reintentosAntes = reintentoRetryListener.getIntentosFallidos();

        JobExecution ejecucion = jobLauncher.run(jobTransaccionesDiarias,
                parametros(302L, InyectorFallosWriter.BLOQUEO));

        assertThat(ejecucion.getStatus()).isEqualTo(BatchStatus.COMPLETED);
        assertThat(reintentoRetryListener.getIntentosFallidos() - reintentosAntes)
                .as("el cerrojo tambien tiene que provocar reintentos").isGreaterThan(0);

        Integer negocio = jdbc.queryForObject("SELECT COUNT(*) FROM banco.transaccion", Integer.class);
        assertThat(negocio).as("ninguna fila buena se perdio por el cerrojo").isEqualTo(785);
    }

    // =====================================================================
    // E8-bis - LA BASE NO VUELVE: se agotan los intentos y el job FALLA
    // =====================================================================

    /**
     * La otra mitad de la doctrina, y la que mas facil es olvidar.
     *
     * Reintentar no es tolerar infinitamente. Si tras los 3 intentos el fallo
     * de infraestructura persiste, la excepcion SUBE y el step muere. Lo que NO
     * puede pasar es que se omita: eso convertiria "la base esta caida" en "he
     * cargado 300 filas de 1000 y he terminado COMPLETED", que es la peor
     * salida posible porque nadie se entera del desastre.
     *
     * Aqui se afirma exactamente eso: estado FAILED, no COMPLETED.
     */
    @Test
    @DisplayName("E8-bis: BD caida permanente -> se agotan los 3 intentos y el job FALLA (nunca se omite)")
    void siLaInfraestructuraNoVuelveElJobFalla() throws Exception {
        JobExecution ejecucion = jobLauncher.run(jobTransaccionesDiarias,
                parametros(303L, InyectorFallosWriter.BD_CAIDA_PERMANENTE));

        assertThat(ejecucion.getStatus())
                .as("un fallo de infraestructura que no se resuelve DEBE matar el job, no omitirse")
                .isEqualTo(BatchStatus.FAILED);

        // Y el motivo tiene que ser legible: un job que falla sin decir por que
        // obliga a alguien a leerse el codigo a las 3 de la manana.
        //
        // OJO: la excepcion que sube NO es la simulada. Spring Batch la
        // sustituye por ExhaustedRetryException, y su mensaje es la mejor
        // evidencia posible de la doctrina, porque lo dice el framework y no
        // nuestro log:
        //   "Retry exhausted after last attempt in recovery path,
        //    but exception is not skippable."
        // Es decir: se agotaron los reintentos Y ADEMAS se comprobo que la
        // excepcion no era omitible, asi que el step muere. Las dos mitades de
        // la politica en una sola frase.
        String motivo = ejecucion.getAllFailureExceptions().toString();
        System.out.printf("[E8-bis BD_CAIDA_PERMANENTE] estado=%s motivo=%.200s%n",
                ejecucion.getStatus(), motivo);
        assertThat(motivo)
                .as("el framework debe declarar que agoto los reintentos")
                .contains("Retry exhausted")
                .contains("not skippable");
    }

    // =====================================================================
    // E11 (variante escritura) - FALLO NO CLASIFICADO: fail-fast
    // =====================================================================

    /**
     * Una DataIntegrityViolationException no esta ni en el mapa de reintentos
     * ni en la lista de omitibles. Es el caso "no se lo que es esto": la
     * postura segura es FALLAR.
     *
     * Por que importa demostrarlo: prueba que las politicas tienen un DEFAULT
     * seguro. Un .skip(Exception.class) o un .retry(Exception.class) perezosos
     * se tragarian esto -que casi siempre es un bug del programador, no un dato
     * sucio- y lo esconderian.
     *
     * Ademas se comprueba que NO SE MALGASTAN INTENTOS, y aqui hay un matiz que
     * conviene entender bien porque es facil afirmar de mas:
     *
     * el contador de ReintentoRetryListener NO se queda a cero. Spring Retry
     * llama a onError en CUALQUIER intento fallido y solo DESPUES le pregunta a
     * la politica si cabe otro. Asi que se registra 1 fallo por particion (4 en
     * total) y ahi se acaba.
     *
     * Y eso es justo lo que hay que demostrar: 1 intento por particion frente a
     * los 3 que consume BD_CAIDA_PERMANENTE. La diferencia entre 4 y 12 ES la
     * prueba de que la politica no reintenta lo que no esta en su mapa.
     */
    @Test
    @DisplayName("E11: excepcion no clasificada -> ni retry ni skip, el job FALLA sin gastar intentos extra")
    void loNoClasificadoFallaRapidoYSinReintentar() throws Exception {
        long reintentosAntes = reintentoRetryListener.getIntentosFallidos();

        JobExecution ejecucion = jobLauncher.run(jobTransaccionesDiarias,
                parametros(304L, InyectorFallosWriter.ESCRITURA_FATAL));

        long intentosGastados = reintentoRetryListener.getIntentosFallidos() - reintentosAntes;

        System.out.printf("[E11 ESCRITURA_FATAL] estado=%s intentos gastados=%d "
                        + "(con 4 particiones: 1 por particion, NO 3)%n",
                ejecucion.getStatus(), intentosGastados);

        assertThat(ejecucion.getStatus())
                .as("lo desconocido no se tolera: fail-fast")
                .isEqualTo(BatchStatus.FAILED);

        // 4 particiones x 1 intento = 4 como mucho. Si la politica reintentase
        // lo no clasificado, serian 12 (4 x 3) y esta asercion lo cazaria.
        assertThat(intentosGastados)
                .as("un intento por particion como maximo: no se reintenta lo no clasificado")
                .isLessThanOrEqualTo(4);
    }

    // =====================================================================
    // E16 - RECUPERACION: tras el fallo, una corrida limpia vuelve a cuadrar
    // =====================================================================

    /**
     * EL TEST QUE PROTEGE LA REGLA DE ORO.
     *
     * Se ejecuta a proposito la secuencia que un evaluador produce sin querer:
     * primero se rompe el job, y despues se lanza normal. La segunda corrida
     * tiene que dar 785 + 215 = 1000 exactamente igual que si nunca hubiera
     * habido un fallo.
     *
     * Lo que se esta comprobando de verdad son dos cosas:
     *   1) stepPrepararTransacciones limpia los restos de la corrida abortada,
     *      asi que la corrida buena no arrastra filas a medio escribir;
     *   2) el parametro simularFallo NO se arrastra. Se anade siempre y con
     *      valor NINGUNO por defecto justo por esto: si se anadiera solo cuando
     *      se pide, la corrida posterior a un fallo heredaria el escenario en
     *      silencio y volveria a fallar pareciendo un bug de datos.
     */
    @Test
    @DisplayName("E16: despues de una corrida FALLIDA, la siguiente corrida limpia vuelve a cuadrar 785+215")
    void trasElFalloLaSiguienteCorridaVuelveACuadrar() throws Exception {
        JobExecution rota = jobLauncher.run(jobTransaccionesDiarias,
                parametros(305L, InyectorFallosWriter.BD_CAIDA_PERMANENTE));
        assertThat(rota.getStatus()).as("corrida rota, a proposito").isEqualTo(BatchStatus.FAILED);

        JobExecution limpia = jobLauncher.run(jobTransaccionesDiarias,
                parametros(306L, InyectorFallosWriter.NINGUNO));
        assertThat(limpia.getStatus()).as("corrida de recuperacion").isEqualTo(BatchStatus.COMPLETED);

        Integer negocio = jdbc.queryForObject("SELECT COUNT(*) FROM banco.transaccion", Integer.class);
        Integer rechazos = jdbc.queryForObject(
                "SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='transacciones.csv'",
                Integer.class);

        System.out.printf("[E16 recuperacion] negocio=%d rechazos=%d suma=%d%n",
                negocio, rechazos, negocio + rechazos);

        assertThat(negocio).isEqualTo(785);
        assertThat(rechazos).isEqualTo(215);
        assertThat(negocio + rechazos).isEqualTo(1000);
    }

    /**
     * Parametros de un lanzamiento.
     *
     * run.id distinto en cada llamada porque jobLauncher.run() NO aplica el
     * JobParametersIncrementer declarado en el @Bean del Job: con parametros
     * identicos la segunda llamada moriria con
     * JobInstanceAlreadyCompleteException y estariamos "probando" otra cosa.
     */
    private static JobParameters parametros(long runId, String escenario) {
        return new JobParametersBuilder()
                .addString("archivo", "data/transacciones.csv")
                .addString("simularFallo", escenario)
                .addLong("run.id", runId)
                .toJobParameters();
    }
}
