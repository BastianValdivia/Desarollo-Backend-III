package cl.duoc.bancoxyz;

import cl.duoc.bancoxyz.support.ControlCargaDao;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Prueba de integración del Job 1: lo ejecuta de verdad contra un
 * **PostgreSQL 17 real levantado con Testcontainers** y comprueba que los
 * números coinciden EXACTAMENTE con los que publicamos como "salida esperada".
 *
 * NO es una base en memoria, y la diferencia importa: el esquema usa columnas
 * GENERATED ALWAYS AS ... STORED, MODE() WITHIN GROUP e IS DISTINCT FROM, que
 * H2 no reproduce fielmente. Probar contra el motor real es lo que hace que el
 * test valga algo. El precio es que **Docker Desktop tiene que estar encendido**
 * para ejecutar la suite.
 *
 * Esta prueba es la que demuestra el criterio 2 de la pauta: entrada = 1000,
 * negocio + rechazos = 1000, ninguna fila se pierde.
 */
@SpringBootTest
@ActiveProfiles("test")
@Testcontainers
class JobTransaccionesTest {

    /**
     * PostgreSQL 17 REAL, levantado en Docker solo para este test y apagado
     * al terminar. "static" hace que se comparta entre todos los tests de la
     * clase en vez de arrancar uno por metodo.
     *
     * withInitScript crea los dos esquemas ANTES de que la aplicacion se
     * conecte, igual que hace docker/initdb en el entorno real.
     */
    @Container
    static final PostgreSQLContainer<?> POSTGRES =
            new PostgreSQLContainer<>("postgres:17-alpine")
                    .withInitScript("init-schemas.sql");

    /**
     * Testcontainers asigna un puerto libre al azar en cada ejecucion, asi que
     * la URL no se puede escribir en application-test.yml: hay que inyectarla
     * cuando el contenedor ya esta arriba. Eso hace @DynamicPropertySource.
     */
    @DynamicPropertySource
    static void datasource(DynamicPropertyRegistry registro) {
        registro.add("spring.datasource.url", () -> {
            String url = POSTGRES.getJdbcUrl();
            // currentSchema manda las tablas BATCH_* a batch_meta, igual que en produccion
            return url + (url.contains("?") ? "&" : "?") + "currentSchema=batch_meta,banco,public";
        });
        registro.add("spring.datasource.username", POSTGRES::getUsername);
        registro.add("spring.datasource.password", POSTGRES::getPassword);
        registro.add("spring.datasource.driver-class-name", () -> "org.postgresql.Driver");
    }

    @Autowired JobLauncher jobLauncher;
    @Autowired Job jobTransaccionesDiarias;
    @Autowired JdbcTemplate jdbc;
    @Autowired ControlCargaDao controlCargaDao;
    @Autowired PlatformTransactionManager txManager;

    @Test
    void procesaLas1000FilasSinPerderNinguna() throws Exception {
        JobExecution ejecucion = jobLauncher.run(jobTransaccionesDiarias, parametros(100L));

        assertThat(ejecucion.getStatus()).isEqualTo(BatchStatus.COMPLETED);

        // El job tiene 5 StepExecution: el manager y sus 4 particiones. El orden
        // del iterador NO esta garantizado, asi que hay que pedir el manager por
        // su nombre: es el unico que agrega los contadores de todas las particiones.
        StepExecution step = ejecucion.getStepExecutions().stream()
                .filter(se -> se.getStepName().equals("stepCargarTransaccionesManager"))
                .findFirst()
                .orElseThrow(() -> new AssertionError("No se encontro el step manager"));

        // Prueba de que el particionado ocurrio de verdad: 4 workers ademas del manager.
        long particiones = ejecucion.getStepExecutions().stream()
                .filter(se -> se.getStepName().contains(":partition"))
                .count();
        assertThat(particiones).as("numero de particiones ejecutadas").isEqualTo(4);
        Integer enNegocio = jdbc.queryForObject("SELECT COUNT(*) FROM banco.transaccion", Integer.class);
        Integer rechazadas = jdbc.queryForObject("SELECT COUNT(*) FROM banco.registro_rechazado", Integer.class);

        System.out.println("======================================================");
        System.out.printf("leidas=%d  escritas=%d  omitidas=%d  filtradas=%d%n",
                step.getReadCount(), step.getWriteCount(), step.getSkipCount(), step.getFilterCount());
        System.out.printf("en negocio=%d  rechazadas=%d  SUMA=%d%n",
                enNegocio, rechazadas, enNegocio + rechazadas);
        System.out.println("--- distribucion por estado ---");
        jdbc.queryForList("SELECT estado, COUNT(*) AS n FROM banco.transaccion GROUP BY estado ORDER BY n DESC")
                .forEach(r -> System.out.printf("  %-28s %s%n", r.get("estado"), r.get("n")));
        System.out.println("--- motivos de rechazo ---");
        jdbc.queryForList("SELECT motivo, COUNT(*) AS n FROM banco.registro_rechazado GROUP BY motivo ORDER BY n DESC")
                .forEach(r -> System.out.printf("  %-28s %s%n", r.get("motivo"), r.get("n")));
        System.out.println("--- formatos de fecha reparados ---");
        jdbc.queryForList("SELECT formato_fecha, COUNT(*) AS n FROM banco.transaccion GROUP BY formato_fecha ORDER BY n DESC")
                .forEach(r -> System.out.printf("  %-28s %s%n", r.get("formato_fecha"), r.get("n")));
        System.out.println("======================================================");

        // LA COMPROBACIÓN QUE IMPORTA: ninguna fila desapareció
        assertThat(step.getReadCount()).isEqualTo(1000);
        assertThat(step.getFilterCount()).isZero();          // nada se filtró en silencio
        assertThat(enNegocio + rechazadas).isEqualTo(1000);

        // Distribución esperada, medida sobre los datos reales
        Map<String, Integer> esperado = Map.of(
                "VALIDA", 401,
                "ANOMALA_TIPO_DESCONOCIDO", 230,
                "ANOMALA_MONTO_NEGATIVO", 136,
                "ANOMALA_MONTO_CERO", 18);
        esperado.forEach((estado, n) -> {
            Integer real = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM banco.transaccion WHERE estado = ?", Integer.class, estado);
            assertThat(real).as("estado %s", estado).isEqualTo(n);
        });

        assertThat(jdbc.queryForObject(
                "SELECT COUNT(*) FROM banco.registro_rechazado WHERE motivo='FECHA_INVALIDA'", Integer.class))
                .isEqualTo(55);
        assertThat(jdbc.queryForObject(
                "SELECT COUNT(*) FROM banco.registro_rechazado WHERE motivo='MONTO_AUSENTE'", Integer.class))
                .isEqualTo(160);
    }

    /**
     * LA PRUEBA DEL BUG ARREGLADO.
     *
     * banco.transaccion usa el id del CSV como PRIMARY KEY, asi que antes de
     * stepPrepararTransacciones la SEGUNDA ejecucion moria con
     * DuplicateKeyException al reinsertar los ids 1..1000. Este test lanza el
     * job dos veces seguidas contra la MISMA base, sin borrar nada a mano, y
     * exige que las dos terminen COMPLETED y que los numeros sean identicos.
     *
     * Detalle importante: cada lanzamiento lleva su propio run.id. El
     * JobParametersIncrementer declarado en el @Bean del Job NO lo aplica
     * jobLauncher.run(); con parametros identicos la segunda llamada fallaria
     * con JobInstanceAlreadyCompleteException y estariamos "probando" otra cosa.
     */
    @Test
    void sePuedeEjecutarDosVecesSeguidasSinDuplicados() throws Exception {
        JobExecution primera = jobLauncher.run(jobTransaccionesDiarias, parametros(201L));
        assertThat(primera.getStatus()).as("primera ejecucion").isEqualTo(BatchStatus.COMPLETED);

        JobExecution segunda = jobLauncher.run(jobTransaccionesDiarias, parametros(202L));
        assertThat(segunda.getStatus()).as("segunda ejecucion").isEqualTo(BatchStatus.COMPLETED);

        // El WHERE archivo_origen es el mismo que aplica LimpiezaTasklet: se
        // comprueba justo lo que el job limpia, ni mas ni menos.
        Integer negocio = jdbc.queryForObject("SELECT COUNT(*) FROM banco.transaccion", Integer.class);
        Integer rechazos = jdbc.queryForObject(
                "SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='transacciones.csv'",
                Integer.class);

        assertThat(negocio).as("filas de negocio tras la SEGUNDA ejecucion").isEqualTo(785);
        assertThat(rechazos).as("rechazos tras la SEGUNDA ejecucion").isEqualTo(215);
        assertThat(negocio + rechazos).isEqualTo(1000);

        // La cuadratura quedo persistida y PostgreSQL la dio por buena.
        Boolean cuadra = jdbc.queryForObject(
                "SELECT cuadra FROM banco.control_carga WHERE job_execution_id = ? AND archivo_origen = ?",
                Boolean.class, segunda.getId(), "transacciones.csv");
        assertThat(cuadra).as("control_carga.cuadra de la segunda ejecucion").isTrue();

        // El agregado diario tampoco acumula fechas de la corrida anterior.
        Integer operaciones = jdbc.queryForObject(
                "SELECT SUM(total_operaciones) FROM banco.resumen_diario", Integer.class);
        assertThat(operaciones).as("SUM(resumen_diario.total_operaciones)").isEqualTo(785);
    }

    /**
     * Prueba de que el upsert de control_carga SOBREVIVE a un rollback.
     *
     * Es la razon de ser del PROPAGATION_REQUIRES_NEW de ControlCargaDao: cuando
     * CuadraturaTasklet detecta un descuadre escribe la fila y DESPUES lanza la
     * excepcion que hace fallar el job. Si el upsert compartiera la transaccion
     * del step, el rollback borraria la evidencia y el job fallaria sin dejar
     * rastro de por que. Aqui se simula ese escenario: se escribe dentro de una
     * transaccion que se marca para rollback, y la fila debe seguir ahi.
     */
    @Test
    void laEvidenciaDeCuadraturaSobreviveAlRollback() {
        long idFalso = 999_999L;
        ControlCargaDao.ContadoresCarga descuadrada =
                new ControlCargaDao.ContadoresCarga(1000, 782, 215, 0);   // faltan 3 filas

        TransactionTemplate plantilla = new TransactionTemplate(txManager);
        plantilla.executeWithoutResult(status -> {
            controlCargaDao.upsert(descuadrada, "jobDePrueba", idFalso, "transacciones.csv", 1L);
            status.setRollbackOnly();   // simula el rollback que provoca la excepcion
        });

        Boolean cuadra = jdbc.queryForObject(
                "SELECT cuadra FROM banco.control_carga WHERE job_execution_id = ?",
                Boolean.class, idFalso);
        assertThat(cuadra).as("la fila sobrevivio al rollback y marca el descuadre").isFalse();
    }

    /**
     * Parametros de un lanzamiento. run.id distinto en cada llamada porque
     * jobLauncher.run() no aplica el incrementer del @Bean del Job.
     */
    private static org.springframework.batch.core.JobParameters parametros(long runId) {
        return new JobParametersBuilder()
                .addString("archivo", "data/transacciones.csv")
                .addLong("run.id", runId)
                .toJobParameters();
    }
}
