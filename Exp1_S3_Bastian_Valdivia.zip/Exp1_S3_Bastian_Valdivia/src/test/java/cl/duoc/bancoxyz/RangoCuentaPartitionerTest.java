package cl.duoc.bancoxyz;

import cl.duoc.bancoxyz.partition.RangoCuentaPartitioner;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.batch.item.ExecutionContext;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * EL TEST QUE PROTEGE LA REGLA DE ORO.
 *
 * "Entrada = negocio + rechazos. Ninguna fila desaparece en silencio."
 *
 * Un particionado por rango puede perder filas de la forma mas silenciosa que
 * existe: si un cuenta_id no cae en el tramo de NINGUNA particion, esa fila no
 * la lee nadie. No hay excepcion, no hay log, no hay nada. El job dice
 * COMPLETED y en la base hay 999 filas en vez de 1000.
 *
 * El invariante que hay que sostener es exacto: para CUALQUIER cuenta_id
 * imaginable debe haber EXACTAMENTE UN reclamante.
 *   - cero reclamantes -> la fila se pierde
 *   - dos reclamantes  -> la fila se procesa dos veces y la cuadratura da 1001
 *
 * Por eso las aserciones son isEqualTo(1) y nunca isGreaterThan(0): "al menos
 * uno" dejaria pasar la duplicacion.
 */
@DisplayName("RangoCuentaPartitioner: toda fila tiene exactamente un reclamante")
class RangoCuentaPartitionerTest {

    private static final int CUENTA_MIN = 101;
    private static final int CUENTA_MAX = 150;
    private static final int GRID = 5;

    private final RangoCuentaPartitioner partitioner =
            new RangoCuentaPartitioner(CUENTA_MIN, CUENTA_MAX);

    /**
     * Cuenta cuantas particiones reclaman un cuenta_id dado, preguntandoselo a
     * la MISMA funcion estatica que usa el reader en produccion. Si el test
     * reimplementara la regla, podria estar de acuerdo consigo mismo y en
     * desacuerdo con el codigo que corre de verdad.
     */
    private long reclamantes(String cuentaIdCrudo) {
        Map<String, ExecutionContext> particiones = partitioner.partition(GRID);
        return particiones.values().stream()
                .filter(ctx -> RangoCuentaPartitioner.reclama(
                        cuentaIdCrudo,
                        ctx.getInt("cuentaMin"),
                        ctx.getInt("cuentaMax"),
                        Boolean.parseBoolean(ctx.getString("esPrimera")),
                        Boolean.parseBoolean(ctx.getString("esUltima"))))
                .count();
    }

    // ==================================================================
    // Caso 1: cuentas DENTRO del rango, incluidos los bordes de tramo.
    // 110/111 y 120/121 son fronteras entre particiones: si los tramos se
    // solaparan o dejaran un hueco de una unidad, se veria justo aqui.
    // ==================================================================
    @ParameterizedTest(name = "cuenta_id={0} (dentro del rango)")
    @ValueSource(strings = {"101", "102", "110", "111", "120", "121", "125", "149", "150"})
    void cuentasDentroDelRangoTienenUnUnicoReclamante(String cuentaId) {
        assertThat(reclamantes(cuentaId))
                .as("cuenta_id=%s debe pertenecer a exactamente una particion", cuentaId)
                .isEqualTo(1);
    }

    // ==================================================================
    // Caso 2: cuentas FUERA del rango. Es el escenario E10 del plan.
    // Sin la regla "la primera absorbe lo de abajo y la ultima lo de arriba",
    // estas filas no las leeria nadie y la cuadratura daria 999.
    // ==================================================================
    @ParameterizedTest(name = "cuenta_id={0} (fuera del rango)")
    @ValueSource(strings = {"100", "1", "0", "-5", "151", "999", "2147483647"})
    void cuentasFueraDelRangoTambienTienenUnUnicoReclamante(String cuentaId) {
        assertThat(reclamantes(cuentaId))
                .as("cuenta_id=%s esta fuera de %d..%d y AUN ASI alguien debe leerla",
                        cuentaId, CUENTA_MIN, CUENTA_MAX)
                .isEqualTo(1);
    }

    // ==================================================================
    // Caso 3: cuenta_id ILEGIBLE. Una fila con el identificador vacio o con
    // basura sigue siendo una fila del archivo: tiene que entrar, llegar al
    // processor y acabar en negocio o en el dead letter. Lo que no puede es
    // evaporarse antes de que nadie la mire.
    // ==================================================================
    @ParameterizedTest(name = "cuenta_id='{0}' (ilegible)")
    @ValueSource(strings = {"", "   ", "abc", "12.5", "N/A", "null"})
    void cuentasIlegiblesTambienTienenUnUnicoReclamante(String cuentaId) {
        assertThat(reclamantes(cuentaId))
                .as("cuenta_id='%s' no es numerico, pero la fila NO puede perderse", cuentaId)
                .isEqualTo(1);
    }

    /** null es un caso aparte porque no se puede pasar por @ValueSource. */
    @Test
    void unCuentaIdNuloTampocoSePierde() {
        assertThat(reclamantes(null)).isEqualTo(1);
    }

    // ==================================================================
    // Caso 4: el invariante sobre TODO el espacio de enteros que importa.
    // Los casos de arriba son ejemplos escogidos a mano; este barre un rango
    // amplio de golpe, que es lo que de verdad demuestra que no hay huecos.
    // ==================================================================
    @Test
    @DisplayName("Barrido de 0 a 300: ni un solo hueco ni un solo solape")
    void barridoCompletoSinHuecosNiSolapes() {
        for (int id = 0; id <= 300; id++) {
            assertThat(reclamantes(String.valueOf(id)))
                    .as("cuenta_id=%d", id)
                    .isEqualTo(1);
        }
    }

    // ==================================================================
    // Caso 5: partition() y getPartitionNames() DEBEN coincidir.
    //
    // Spring llama a getPartitionNames(gridSize) y luego busca ESAS claves
    // exactas en el mapa de partition(gridSize). Si difirieran, el fallo
    // aparece en tiempo de EJECUCION y solo al reiniciar un job, que es el
    // peor momento posible para descubrirlo.
    // ==================================================================
    @Test
    void losNombresDeParticionCoincidenConElMapaDeParticiones() {
        Map<String, ExecutionContext> mapa = partitioner.partition(GRID);
        Collection<String> nombres = partitioner.getPartitionNames(GRID);

        assertThat(nombres)
                .as("PartitionNameProvider debe declarar exactamente las mismas claves")
                .containsExactlyInAnyOrderElementsOf(mapa.keySet());
        assertThat(nombres).hasSize(GRID);
    }

    // ==================================================================
    // Caso 6: el reparto cubre las 50 cuentas sin repetir ninguna.
    // ==================================================================
    @Test
    void losTramosCubrenLas50CuentasExactamenteUnaVez() {
        Map<String, ExecutionContext> particiones = partitioner.partition(GRID);

        List<Integer> minimos = particiones.values().stream()
                .map(ctx -> ctx.getInt("cuentaMin")).sorted().toList();
        List<Integer> maximos = particiones.values().stream()
                .map(ctx -> ctx.getInt("cuentaMax")).sorted().toList();

        assertThat(minimos.get(0)).isEqualTo(CUENTA_MIN);
        assertThat(maximos.get(maximos.size() - 1)).isEqualTo(CUENTA_MAX);

        // Los tramos deben ser CONTIGUOS: cada uno empieza justo donde acabo
        // el anterior. Un hueco perderia cuentas; un solape las duplicaria.
        for (int i = 1; i < minimos.size(); i++) {
            assertThat(minimos.get(i))
                    .as("el tramo %d debe empezar justo tras el anterior", i)
                    .isEqualTo(maximos.get(i - 1) + 1);
        }

        // Exactamente una particion marcada como primera y una como ultima:
        // son las que absorben lo que se sale del rango.
        long primeras = particiones.values().stream()
                .filter(c -> Boolean.parseBoolean(c.getString("esPrimera"))).count();
        long ultimas = particiones.values().stream()
                .filter(c -> Boolean.parseBoolean(c.getString("esUltima"))).count();
        assertThat(primeras).as("particiones marcadas como primera").isEqualTo(1);
        assertThat(ultimas).as("particiones marcadas como ultima").isEqualTo(1);
    }

    // ==================================================================
    // Caso 7: el invariante se sostiene con CUALQUIER gridSize, no solo con 5.
    // Incluye gridSize=1 (sin particionar) y gridSize mayor que el numero de
    // cuentas, donde una implementacion ingenua crearia particiones vacias.
    // ==================================================================
    @ParameterizedTest(name = "gridSize={0}")
    @ValueSource(ints = {1, 2, 3, 4, 5, 7, 50, 60})
    void elInvarianteSeSostieneConCualquierGridSize(int gridSize) {
        Map<String, ExecutionContext> particiones = partitioner.partition(gridSize);

        assertThat(particiones).as("nunca se crean particiones vacias").isNotEmpty();
        assertThat(partitioner.getPartitionNames(gridSize))
                .containsExactlyInAnyOrderElementsOf(particiones.keySet());

        for (String cuentaId : List.of("100", "101", "125", "150", "151", "999", "", "abc")) {
            long n = particiones.values().stream()
                    .filter(ctx -> RangoCuentaPartitioner.reclama(
                            cuentaId,
                            ctx.getInt("cuentaMin"), ctx.getInt("cuentaMax"),
                            Boolean.parseBoolean(ctx.getString("esPrimera")),
                            Boolean.parseBoolean(ctx.getString("esUltima"))))
                    .count();
            assertThat(n).as("gridSize=%d, cuenta_id='%s'", gridSize, cuentaId).isEqualTo(1);
        }
    }
}
