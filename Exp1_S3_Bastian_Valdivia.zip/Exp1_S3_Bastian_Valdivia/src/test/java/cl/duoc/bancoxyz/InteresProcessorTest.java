package cl.duoc.bancoxyz;

import cl.duoc.bancoxyz.domain.InteresCalculado;
import cl.duoc.bancoxyz.domain.InteresRaw;
import cl.duoc.bancoxyz.domain.TipoCuenta;
import cl.duoc.bancoxyz.exception.RegistroInvalidoException;
import cl.duoc.bancoxyz.processor.InteresProcessor;
import cl.duoc.bancoxyz.support.CalculadoraInteres;
import cl.duoc.bancoxyz.support.NormalizadorMonto;
import cl.duoc.bancoxyz.support.NormalizadorTexto;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.assertThatCode;

/**
 * Tests unitarios del corazon del Job 2, con VALORES REALES de intereses.csv.
 *
 * Son unitarios de verdad: ni Spring, ni Docker, ni base de datos. El processor
 * es una funcion pura (entra un InteresRaw, sale un InteresCalculado), asi que
 * se puede probar instanciandolo a mano. Eso hace que estos tests tarden
 * milisegundos y se puedan ejecutar en cada guardado, al reves que el test de
 * integracion, que levanta un PostgreSQL entero.
 *
 * Lo que se verifica aqui es la PRECEDENCIA, que es de donde salen los numeros
 * publicados como salida esperada. Si alguien reordena los if del paso 4, los
 * totales cambian sin que nada falle a simple vista; estos tests lo cazan.
 */
@DisplayName("InteresProcessor: precedencia, canonizacion y calculo")
class InteresProcessorTest {

    private static final String PERIODO = "2024-01";
    private static final long JOB_ID = 42L;

    private final InteresProcessor processor = new InteresProcessor(
            new NormalizadorTexto(),
            new NormalizadorMonto(),
            new CalculadoraInteres(),
            PERIODO,
            JOB_ID);

    /** Construye una fila cruda como la que entregaria el lector. */
    private static InteresRaw fila(String cuentaId, String nombre, String saldo,
                                   String edad, String tipo) {
        return new InteresRaw(cuentaId, nombre, saldo, edad, tipo);
    }

    // ==================================================================
    // RECHAZOS - lo unico que NO se guarda
    // ==================================================================
    @Nested
    @DisplayName("Rechazos (fase PROCESS)")
    class Rechazos {

        /**
         * Las 211 filas de SALDO_AUSENTE. Es el unico defecto irrecuperable de
         * este archivo: sin saldo no hay nada que multiplicar por la tasa.
         */
        @Test
        void saldoVacioSeRechazaConMotivoSaldoAusente() {
            assertThatThrownBy(() -> processor.process(
                    fila("114", "Unknown", "", "30", "-1")))
                    .isInstanceOf(RegistroInvalidoException.class)
                    .satisfies(e -> {
                        RegistroInvalidoException rie = (RegistroInvalidoException) e;
                        assertThat(rie.getMotivo()).isEqualTo("SALDO_AUSENTE");
                        assertThat(rie.getCampo()).isEqualTo("saldo");
                        // La linea cruda es lo que acaba en el dead letter:
                        // tiene que ser la fila ORIGINAL, reconstruida entera.
                        assertThat(rie.getLineaCruda()).isEqualTo("114,Unknown,,30,-1");
                    });
        }

        /**
         * Hoy son 0 filas en el archivo, pero el motivo existe y se distingue.
         * Si manana llega "N/A" en el saldo, el dead letter debe decir
         * SALDO_NO_NUMERICO y no un generico SALDO_AUSENTE: son problemas
         * distintos y se corrigen de forma distinta.
         */
        @ParameterizedTest
        @ValueSource(strings = {"N/A", "abc", "1.2.3", "$500"})
        void saldoNoNumericoSeDistingueDelAusente(String saldo) {
            assertThatThrownBy(() -> processor.process(
                    fila("101", "John Doe", saldo, "30", "ahorro")))
                    .isInstanceOf(RegistroInvalidoException.class)
                    .extracting(e -> ((RegistroInvalidoException) e).getMotivo())
                    .isEqualTo("SALDO_NO_NUMERICO");
        }

        /**
         * EL DUPLICADO NO SE DETECTA AQUI, y es importante que quede escrito.
         * Lo detecta PostgreSQL en la fase WRITE contra uq_interes_posicion.
         * Que el processor no sepa nada de duplicados es lo que hace que la
         * precedencia "saldo ausente antes que duplicado" salga gratis: una
         * fila sin saldo muere aqui y nunca llega al writer. Por eso el archivo
         * tiene 9 filas repetidas pero solo salen 5 DUPLICADO.
         */
        @Test
        void elProcessorNoDetectaDuplicados() {
            InteresRaw repetida = fila("137", "Bob Johnson", "7000", "", "prestamo");
            assertThatCode(() -> {
                processor.process(repetida);
                processor.process(repetida);   // la misma fila, dos veces
            }).doesNotThrowAnyException();
        }
    }

    // ==================================================================
    // CANONIZACION - se repara, no se rechaza
    // ==================================================================
    @Nested
    @DisplayName("Canonizacion de campos sucios")
    class Canonizacion {

        /** '-1' (279 filas) y 'unknown' (52) -> DESCONOCIDO con tasa 0. */
        @ParameterizedTest
        @ValueSource(strings = {"-1", "unknown", "Unknown", "UNKNOWN", "leasing", ""})
        void tipoDesconocidoQuedaEnDesconocidoConTasaCero(String tipoCrudo) {
            InteresCalculado r = processor.process(
                    fila("101", "John Doe", "5000", "30", tipoCrudo));

            assertThat(r.getTipo()).isEqualTo("DESCONOCIDO");
            assertThat(r.getTasa()).isEqualByComparingTo("0.00000");
            // La consecuencia economica de no saber el producto: no se le
            // inventa rentabilidad a la cuenta.
            assertThat(r.getInteres()).isEqualByComparingTo("0.00");
            // Pero la fila SE GUARDA: el tipo original se conserva intacto.
            assertThat(r.getTipoOriginal()).isEqualTo(tipoCrudo);
        }

        /** Los tres tipos reales, en minusculas como vienen en el archivo. */
        @ParameterizedTest
        @CsvSource({
                "ahorro,   AHORRO,   0.00250",
                "hipoteca, HIPOTECA, 0.00400",
                "prestamo, PRESTAMO, 0.01500"
        })
        void tiposConocidosSeCanonizanConSuTasa(String crudo, String esperado, String tasa) {
            InteresCalculado r = processor.process(fila("101", "John Doe", "1000", "30", crudo));
            assertThat(r.getTipo()).isEqualTo(esperado);
            assertThat(r.getTasa()).isEqualByComparingTo(tasa);
        }

        /** 'Unknown' como titular (50 filas) -> 'DESCONOCIDO'. */
        @Test
        void nombreUnknownSeCanonizaPeroLaFilaSeGuarda() {
            InteresCalculado r = processor.process(
                    fila("101", "Unknown", "5000", "30", "ahorro"));

            assertThat(r.getNombre()).isEqualTo("DESCONOCIDO");
            assertThat(r.getNombreOriginal()).isEqualTo("Unknown");
            assertThat(r.getEstado()).isEqualTo("ANOMALA_NOMBRE_DESCONOCIDO");
        }

        /** Edad vacia -> NULL. La columna admite NULL; el CHECK exige 18..99 o NULL. */
        @Test
        void edadVaciaSeAnulaYSeMarca() {
            InteresCalculado r = processor.process(
                    fila("137", "Bob Johnson", "7000", "", "prestamo"));

            assertThat(r.getEdad()).isNull();
            assertThat(r.getEstado()).isEqualTo("ANOMALA_EDAD_AUSENTE");
            assertThat(r.getAnomalias()).contains("EDAD_AUSENTE");
        }

        /**
         * Edades imposibles del archivo: 100 (120 filas) y 150 (52 filas).
         * Se anulan porque ck_int_edad solo acepta NULL o 18..99; el saneado
         * vive en el processor y el CHECK es la red de seguridad.
         */
        @ParameterizedTest
        @ValueSource(strings = {"100", "150", "17", "0", "-3", "999", "treinta"})
        void edadFueraDeRangoSeAnulaYSeMarca(String edad) {
            InteresCalculado r = processor.process(
                    fila("101", "John Doe", "5000", edad, "ahorro"));

            assertThat(r.getEdad()).as("edad %s debe anularse", edad).isNull();
            assertThat(r.getEstado()).isEqualTo("ANOMALA_EDAD_FUERA_RANGO");
            // El valor original NO se pierde: queda para auditar.
            assertThat(r.getEdadOriginal()).isEqualTo(edad);
        }

        @ParameterizedTest
        @ValueSource(strings = {"18", "25", "45", "99"})
        void edadesCreiblesSeConservan(String edad) {
            InteresCalculado r = processor.process(
                    fila("101", "John Doe", "5000", edad, "ahorro"));
            assertThat(r.getEdad()).isEqualTo(Integer.valueOf(edad));
        }
    }

    // ==================================================================
    // PRECEDENCIA - de aqui salen los numeros publicados
    // ==================================================================
    @Nested
    @DisplayName("Precedencia del estado: TIPO > EDAD_FUERA > EDAD_AUSENTE > NOMBRE")
    class Precedencia {

        /**
         * Una fila con TODOS los defectos a la vez. El estado nombra solo el de
         * mayor precedencia, pero la columna anomalias los guarda TODOS. Ese es
         * el motivo de que las dos cuentas del informe no sumen igual.
         */
        @Test
        void conTodosLosDefectosGanaElTipoPeroSeRegistranTodos() {
            InteresCalculado r = processor.process(
                    fila("114", "Unknown", "5000", "150", "-1"));

            assertThat(r.getEstado()).isEqualTo("ANOMALA_TIPO_DESCONOCIDO");
            assertThat(r.getAnomalias().split(","))
                    .containsExactlyInAnyOrder(
                            "TIPO_DESCONOCIDO", "EDAD_FUERA_RANGO", "NOMBRE_DESCONOCIDO");
        }

        @Test
        void edadFueraDeRangoGanaAEdadAusenteYANombre() {
            // tipo conocido, para que no lo tape
            InteresCalculado r = processor.process(
                    fila("101", "Unknown", "5000", "100", "ahorro"));
            assertThat(r.getEstado()).isEqualTo("ANOMALA_EDAD_FUERA_RANGO");
        }

        @Test
        void edadAusenteGanaANombreDesconocido() {
            InteresCalculado r = processor.process(
                    fila("101", "Unknown", "5000", "", "ahorro"));
            assertThat(r.getEstado()).isEqualTo("ANOMALA_EDAD_AUSENTE");
        }

        @Test
        void sinNingunDefectoLaFilaEsValida() {
            InteresCalculado r = processor.process(
                    fila("101", "John Doe", "5000", "30", "ahorro"));

            assertThat(r.getEstado()).isEqualTo("VALIDA");
            assertThat(r.getAnomalias()).isEmpty();
        }

        /**
         * Edad ausente y edad fuera de rango son MUTUAMENTE EXCLUYENTES: un
         * campo vacio no puede estar ademas fuera de rango. Si alguna vez
         * aparecieran las dos en la misma fila, los totales del informe
         * (151 + 137) dejarian de cuadrar contra el archivo.
         */
        @ParameterizedTest
        @ValueSource(strings = {"", "30", "150", "abc"})
        void edadAusenteYFueraDeRangoNuncaCoexisten(String edad) {
            InteresCalculado r = processor.process(
                    fila("101", "John Doe", "5000", edad, "ahorro"));

            boolean ausente = r.getAnomalias().contains("EDAD_AUSENTE");
            boolean fuera = r.getAnomalias().contains("EDAD_FUERA_RANGO");
            assertThat(ausente && fuera)
                    .as("edad='%s' no puede ser ausente Y fuera de rango a la vez", edad)
                    .isFalse();
        }
    }

    // ==================================================================
    // CALCULO
    // ==================================================================
    @Nested
    @DisplayName("Calculo del interes")
    class Calculo {

        /** El caso del plan: 8000 en un prestamo al 1,5% mensual = 120,00. */
        @Test
        void prestamoDe8000Rinde120() {
            InteresCalculado r = processor.process(
                    fila("137", "Bob Johnson", "8000", "30", "prestamo"));

            assertThat(r.getSaldoInicial()).isEqualByComparingTo("8000");
            assertThat(r.getInteres()).isEqualByComparingTo("120.00");
            // saldo_final NO es un campo de esta clase: lo calcula PostgreSQL
            // como columna GENERATED. Aqui solo se comprueban sus dos sumandos.
        }

        @ParameterizedTest
        @CsvSource({
                "10000, ahorro,   25.00",
                "10000, hipoteca, 40.00",
                "10000, prestamo, 150.00",
                "10000, -1,       0.00",
                "0,     prestamo, 0.00"
        })
        void interesPorTipoYSaldo(String saldo, String tipo, String esperado) {
            InteresCalculado r = processor.process(fila("101", "John Doe", saldo, "30", tipo));
            assertThat(r.getInteres()).isEqualByComparingTo(esperado);
        }

        /** El interes se redondea SIEMPRE a 2 decimales: la columna es NUMERIC(15,2). */
        @Test
        void elInteresSeRedondeaADosDecimales() {
            InteresCalculado r = processor.process(
                    fila("101", "John Doe", "3333", "30", "hipoteca"));
            // 3333 * 0.004 = 13.332 -> 13.33
            assertThat(r.getInteres()).isEqualByComparingTo("13.33");
            assertThat(r.getInteres().scale()).isEqualTo(2);
        }
    }

    // ==================================================================
    // METADATOS DE AUDITORIA
    // ==================================================================
    @Test
    @DisplayName("Sella periodo, jobExecutionId y la linea fisica del CSV")
    void selaLosMetadatosDeAuditoria() {
        InteresRaw raw = fila("101", "John Doe", "5000", "30", "ahorro");
        // Simula lo que hace el FlatFileItemReader: la fila 1 del archivo.
        raw.setItemCount(1);

        InteresCalculado r = processor.process(raw);

        assertThat(r.getPeriodo()).isEqualTo(PERIODO);
        assertThat(r.getJobExecutionId()).isEqualTo(JOB_ID);
        // linea 2 del fichero: la 1 es la cabecera.
        assertThat(r.getNumeroLinea()).isEqualTo(2L);
    }

    /**
     * REGLA DE ORO a nivel de processor: nunca devolver null. Devolver null
     * FILTRA la fila (no se escribe, no cuenta como error, desaparece).
     */
    @Test
    void nuncaDevuelveNullParaUnaFilaConSaldo() {
        assertThat(processor.process(fila("999", "", "1", "", ""))).isNotNull();
    }

    /** Las tasas del enum, por si alguien las cambia sin querer. */
    @Test
    void lasTasasSonLasDocumentadas() {
        assertThat(TipoCuenta.AHORRO.tasa()).isEqualByComparingTo(new BigDecimal("0.00250"));
        assertThat(TipoCuenta.HIPOTECA.tasa()).isEqualByComparingTo(new BigDecimal("0.00400"));
        assertThat(TipoCuenta.PRESTAMO.tasa()).isEqualByComparingTo(new BigDecimal("0.01500"));
        assertThat(TipoCuenta.DESCONOCIDO.tasa()).isEqualByComparingTo(BigDecimal.ZERO);
        // El CHECK ck_int_tasa exige 0 <= tasa < 1 para todas.
        for (TipoCuenta t : TipoCuenta.values()) {
            assertThat(t.tasa()).isGreaterThanOrEqualTo(BigDecimal.ZERO);
            assertThat(t.tasa()).isLessThan(BigDecimal.ONE);
        }
    }
}
