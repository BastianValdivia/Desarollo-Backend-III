package cl.duoc.bancoxyz;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.math.BigDecimal;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Prueba de integracion del Job 2 contra un PostgreSQL 17 REAL.
 *
 * Testcontainers y no H2 a proposito: este job depende de cosas que solo hace
 * PostgreSQL de verdad -columnas GENERATED ALWAYS STORED, MODE() WITHIN GROUP,
 * ON CONFLICT con WHERE, IS DISTINCT FROM-. Con una base "parecida" el test
 * pasaria y produccion fallaria, que es el peor resultado posible.
 *
 * Demuestra los dos criterios centrales del Job 2:
 *   - la REGLA DE ORO: 784 + 216 = 1000, ninguna fila se pierde
 *   - la IDEMPOTENCIA: dos corridas del mismo periodo no reaplican el interes
 */
@SpringBootTest
@ActiveProfiles("test")
@Testcontainers
@DisplayName("Job 2 - jobInteresesMensuales")
class JobInteresesTest {

    @Container
    static final PostgreSQLContainer<?> POSTGRES =
            new PostgreSQLContainer<>("postgres:17-alpine")
                    .withInitScript("init-schemas.sql");

    @DynamicPropertySource
    static void datasource(DynamicPropertyRegistry registro) {
        registro.add("spring.datasource.url", () -> {
            String url = POSTGRES.getJdbcUrl();
            return url + (url.contains("?") ? "&" : "?") + "currentSchema=batch_meta,banco,public";
        });
        registro.add("spring.datasource.username", POSTGRES::getUsername);
        registro.add("spring.datasource.password", POSTGRES::getPassword);
        registro.add("spring.datasource.driver-class-name", () -> "org.postgresql.Driver");
    }

    private static final String PERIODO = "2024-01";

    @Autowired JobLauncher jobLauncher;
    @Autowired Job jobInteresesMensuales;
    @Autowired JdbcTemplate jdbc;

    // ==================================================================
    // TEST 1: la regla de oro y el reparto exacto
    // ==================================================================
    @Test
    @DisplayName("Procesa las 1000 filas: 784 de negocio + 216 rechazos, sin perder ninguna")
    void procesaLas1000FilasSinPerderNinguna() throws Exception {
        JobExecution ejecucion = jobLauncher.run(jobInteresesMensuales, parametros(100L));
        assertThat(ejecucion.getStatus()).isEqualTo(BatchStatus.COMPLETED);

        // -- el particionado ocurrio de verdad: 5 workers ademas del manager
        long particiones = ejecucion.getStepExecutions().stream()
                .filter(se -> se.getStepName().contains(":partition"))
                .count();
        assertThat(particiones).as("particiones ejecutadas").isEqualTo(5);

        // -- LA COMPROBACION DEL ENVOLTORIO DE LECTURA.
        //    Si FiltroRangoCuentaReader hiciera `return` en vez de `continue`,
        //    cada particion terminaria en su primera fila ajena y esta suma
        //    daria 5 en vez de 1000. Es la red que caza ese bug silencioso.
        long leidas = ejecucion.getStepExecutions().stream()
                .filter(se -> se.getStepName().contains(":partition"))
                .mapToLong(se -> se.getReadCount()).sum();
        long filtradas = ejecucion.getStepExecutions().stream()
                .filter(se -> se.getStepName().contains(":partition"))
                .mapToLong(se -> se.getFilterCount()).sum();
        assertThat(leidas).as("SUM(read_count) de las 5 particiones").isEqualTo(1000);
        assertThat(filtradas).as("nada se filtro en silencio").isZero();

        int negocio = contar("SELECT COUNT(*) FROM banco.interes_calculado");
        int rechazos = contar("SELECT COUNT(*) FROM banco.registro_rechazado "
                + "WHERE archivo_origen='intereses.csv'");

        System.out.println("======================================================");
        System.out.printf("leidas=%d  negocio=%d  rechazos=%d  SUMA=%d%n",
                leidas, negocio, rechazos, negocio + rechazos);
        jdbc.queryForList("SELECT estado, COUNT(*) AS n FROM banco.interes_calculado "
                        + "GROUP BY estado ORDER BY n DESC")
                .forEach(r -> System.out.printf("  %-30s %s%n", r.get("estado"), r.get("n")));
        System.out.println("======================================================");

        assertThat(negocio).isEqualTo(784);
        assertThat(rechazos).isEqualTo(216);
        assertThat(negocio + rechazos).as("REGLA DE ORO").isEqualTo(1000);

        // -- distribucion exacta de estados (docs/analisis-datos.md seccion 6)
        Map<String, Integer> esperado = Map.of(
                "VALIDA", 303,
                "ANOMALA_TIPO_DESCONOCIDO", 260,
                "ANOMALA_EDAD_AUSENTE", 101,
                "ANOMALA_EDAD_FUERA_RANGO", 96,
                "ANOMALA_NOMBRE_DESCONOCIDO", 24);
        esperado.forEach((estado, n) -> assertThat(contar(
                "SELECT COUNT(*) FROM banco.interes_calculado WHERE estado = '" + estado + "'"))
                .as("estado %s", estado).isEqualTo(n));

        // -- los DOS motivos de rechazo, cada uno en SU FASE.
        //    Que DUPLICADO salga en fase WRITE es lo que demuestra que el dead
        //    letter sobrevive al rollback del chunk: sin el REQUIRES_NEW de
        //    RechazoListener aqui habria 211 y no 216.
        assertThat(contar("SELECT COUNT(*) FROM banco.registro_rechazado "
                + "WHERE archivo_origen='intereses.csv' AND motivo='SALDO_AUSENTE' AND fase='PROCESS'"))
                .as("SALDO_AUSENTE en fase PROCESS").isEqualTo(211);
        assertThat(contar("SELECT COUNT(*) FROM banco.registro_rechazado "
                + "WHERE archivo_origen='intereses.csv' AND motivo='DUPLICADO' AND fase='WRITE'"))
                .as("DUPLICADO en fase WRITE (sobrevive al rollback del chunk)").isEqualTo(5);

        // -- ningun rechazo quedo sin su evidencia
        assertThat(contar("SELECT COUNT(*) FROM banco.registro_rechazado "
                + "WHERE archivo_origen='intereses.csv' AND linea_cruda = '(sin linea disponible)'"))
                .as("todos los rechazos conservan su linea cruda").isZero();

        // -- la cuadratura quedo persistida y PostgreSQL la dio por buena
        assertThat(jdbc.queryForObject(
                "SELECT cuadra FROM banco.control_carga WHERE job_execution_id=? AND archivo_origen=?",
                Boolean.class, ejecucion.getId(), "intereses.csv")).isTrue();
    }

    // ==================================================================
    // TEST 2: la consolidacion por cuenta
    // ==================================================================
    @Test
    @DisplayName("Consolida las 784 posiciones en 50 cuentas con la aritmetica cuadrada")
    void consolidaLas50Cuentas() throws Exception {
        assertThat(jobLauncher.run(jobInteresesMensuales, parametros(200L)).getStatus())
                .isEqualTo(BatchStatus.COMPLETED);

        Map<String, Object> t = jdbc.queryForMap(
                "SELECT COUNT(*) AS cuentas, MIN(cuenta_id) AS mini, MAX(cuenta_id) AS maxi,"
                        + " SUM(n_posiciones) AS pos, SUM(saldo_inicial) AS si,"
                        + " SUM(interes_aplicado) AS ia, SUM(saldo) AS s FROM banco.cuenta");

        assertThat(((Number) t.get("cuentas")).intValue()).isEqualTo(50);
        assertThat(((Number) t.get("mini")).intValue()).isEqualTo(101);
        assertThat(((Number) t.get("maxi")).intValue()).isEqualTo(150);
        // Las 784 posiciones de negocio estan TODAS representadas en alguna cuenta.
        assertThat(((Number) t.get("pos")).intValue()).isEqualTo(784);
        assertThat((BigDecimal) t.get("si")).isEqualByComparingTo("6589000.00");
        assertThat((BigDecimal) t.get("ia")).isEqualByComparingTo("31616.00");
        assertThat((BigDecimal) t.get("s")).isEqualByComparingTo("6620616.00");

        // La restriccion ck_cuenta_saldo ya lo garantiza fila a fila, pero se
        // comprueba explicitamente: saldo = saldo_inicial + interes_aplicado.
        assertThat(contar("SELECT COUNT(*) FROM banco.cuenta "
                + "WHERE saldo <> saldo_inicial + interes_aplicado"))
                .as("cuentas con la aritmetica rota").isZero();

        // EL EFECTO DEL NULLIF DENTRO DE MODE(). Sin el, 'DESCONOCIDO' seria el
        // valor mas repetido de casi todas las cuentas (331 de 1000 filas lo
        // traen) y el tipo predominante seria inutil. Con el, la moda se calcula
        // solo entre los tipos informativos.
        assertThat(contar("SELECT COUNT(*) FROM banco.cuenta "
                + "WHERE tipo_predominante = 'DESCONOCIDO'"))
                .as("el NULLIF evita que DESCONOCIDO gane la moda").isZero();

        // Todas las cuentas quedaron selladas con el periodo liquidado: es lo
        // que hara de guarda en la siguiente corrida.
        assertThat(contar("SELECT COUNT(*) FROM banco.cuenta "
                + "WHERE periodo_aplicado = '" + PERIODO + "'")).isEqualTo(50);
    }

    // ==================================================================
    // TEST 3: LA IDEMPOTENCIA (escenario E15)
    // ==================================================================
    @Test
    @DisplayName("Dos corridas del mismo periodo NO reaplican el interes")
    void dosCorridasDelMismoPeriodoNoReaplicanElInteres() throws Exception {
        assertThat(jobLauncher.run(jobInteresesMensuales, parametros(301L)).getStatus())
                .as("primera corrida").isEqualTo(BatchStatus.COMPLETED);

        BigDecimal saldoAntes = jdbc.queryForObject(
                "SELECT SUM(saldo) FROM banco.cuenta", BigDecimal.class);
        int cuentasAntes = contar("SELECT COUNT(*) FROM banco.cuenta");

        // Segunda corrida, MISMO periodo. Sin la guarda del DO UPDATE, aqui el
        // interes se sumaria otra vez sobre un saldo que ya lo incluia y el
        // cliente veria crecer su dinero solo porque alguien reejecuto un job.
        assertThat(jobLauncher.run(jobInteresesMensuales, parametros(302L)).getStatus())
                .as("segunda corrida").isEqualTo(BatchStatus.COMPLETED);

        BigDecimal saldoDespues = jdbc.queryForObject(
                "SELECT SUM(saldo) FROM banco.cuenta", BigDecimal.class);

        assertThat(saldoDespues)
                .as("el interes NO se reaplico: el saldo es identico")
                .isEqualByComparingTo(saldoAntes);
        assertThat(contar("SELECT COUNT(*) FROM banco.cuenta"))
                .as("no se crearon cuentas nuevas").isEqualTo(cuentasAntes);

        // La tabla de detalle tampoco acumula: stepPrepararIntereses borro el
        // periodo antes de recargarlo, asi que siguen siendo 784 y no 1568.
        assertThat(contar("SELECT COUNT(*) FROM banco.interes_calculado")).isEqualTo(784);
        assertThat(contar("SELECT COUNT(*) FROM banco.registro_rechazado "
                + "WHERE archivo_origen='intereses.csv'")).isEqualTo(216);

        // LA PRUEBA DE QUE LOS TRES SITIOS COMPARTEN EL MISMO PERIODO.
        // Si el limpiador borrara un periodo y el processor sellara otro, aqui
        // habria DOS valores distintos y nada mas habria fallado.
        assertThat(jdbc.queryForList(
                "SELECT DISTINCT periodo FROM banco.interes_calculado", String.class))
                .as("un unico periodo tras dos corridas")
                .containsExactly(PERIODO);
    }

    private int contar(String sql) {
        Integer n = jdbc.queryForObject(sql, Integer.class);
        return n == null ? 0 : n;
    }

    /**
     * run.id distinto en cada llamada: jobLauncher.run() NO aplica el
     * incrementer declarado en el @Bean del Job, asi que con parametros
     * identicos la segunda llamada moriria con
     * JobInstanceAlreadyCompleteException y estariamos "probando" otra cosa.
     *
     * El periodo, en cambio, es EL MISMO en todas: es justo lo que hace que la
     * prueba de idempotencia pruebe algo.
     */
    private static JobParameters parametros(long runId) {
        return new JobParametersBuilder()
                .addString("archivo", "data/intereses.csv")
                .addString("periodo", PERIODO)
                .addLong("run.id", runId)
                .toJobParameters();
    }
}
