package cl.duoc.bancoxyz;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.partition.StepExecutionSplitter;
import org.springframework.batch.core.partition.support.PartitionStep;
import org.springframework.batch.core.partition.support.SimpleStepExecutionSplitter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * GUARDA DE REGRESION del fallo mas grave que ha tenido este proyecto: que al
 * REINICIAR una JobInstance la limpieza se repitiera y la recarga no.
 *
 * ------------------------------------------------------------------------
 * QUE PASABA Y POR QUE ERA TAN DIFICIL DE VER
 * ------------------------------------------------------------------------
 * Los steps de preparacion (los que hacen DELETE) llevaban
 * allowStartIfComplete(true); los steps manager que vuelven a llenar la tabla,
 * no. En un reinicio, SimpleStepHandler SALTA todo step que ya este COMPLETED y
 * no tenga esa bandera. Resultado: se borraba y no se reponia.
 *
 * Y el reinicio es el camino NORMAL, no un caso raro: LanzadorJobs usa
 * JobParametersBuilder.getNextJobParameters(job), que tras una ejecucion FAILED
 * devuelve los MISMOS parametros en vez de incrementar run.id.
 *
 * Lo que lo hacia invisible es que la cuadratura contaba filtrando por
 * job_execution_id, o sea validaba "lo que hizo esta ejecucion" y no "lo que
 * deberia contener la tabla": con la tabla vacia daba 0 = 0+0+0 y declaraba OK.
 *
 * ------------------------------------------------------------------------
 * POR QUE HACEN FALTA LAS DOS BANDERAS, Y NO UNA
 * ------------------------------------------------------------------------
 * Esto no se deduce leyendo la documentacion; sale del bytecode de
 * PartitionStepBuilder.build() de spring-batch-core 5.2.6, que hace:
 *
 *     boolean allow = isAllowStartIfComplete();       // la del MANAGER
 *     if (step != null) {
 *         allow = step.isAllowStartIfComplete();      // la del WORKER la PISA
 *     }
 *     splitter.setAllowStartIfComplete(allow);
 *
 * De ahi que cada bandera gobierne una cosa distinta:
 *
 *   la del MANAGER -> que SimpleStepHandler no salte el PartitionStep entero
 *                     (si falta, no se recarga NADA: la tabla queda vacia)
 *   la del WORKER  -> que SimpleStepExecutionSplitter regenere TODAS las
 *                     particiones y no solo las que quedaron FAILED
 *                     (si falta, la recarga es PARCIAL: ~250 filas de 1000)
 *
 * El segundo caso es el peor de los dos, porque produce un numero que cuadra
 * consigo mismo y es falso.
 *
 * ------------------------------------------------------------------------
 * POR QUE SE COMPRUEBA POR REFLEXION Y NO EJECUTANDO UN REINICIO
 * ------------------------------------------------------------------------
 * Provocar un reinicio real exigiria hacer fallar un step tardio de forma
 * reproducible y relanzar con parametros identicos: mucho montaje para
 * verificar, al final, estos mismos tres booleanos. Se comprueba directamente
 * el estado que gobierna el comportamiento, incluido el del splitter, que es
 * privado y es justo el que nadie mira.
 */
@SpringBootTest
@ActiveProfiles("test")
@DisplayName("Reinicio: managers y workers particionados permiten reejecutarse")
class ReinicioParticionesTest {

    @Autowired
    private ApplicationContext ctx;

    @Test
    @DisplayName("Los 3 managers, los 3 workers y sus splitters llevan allowStartIfComplete")
    void losTresJobsSoportanElReinicioDeLaCarga() throws Exception {
        comprobar("stepCargarTransaccionesManager", "stepCargarTransaccionesWorker");
        comprobar("stepCalcularInteresesManager", "stepCalcularInteresesWorker");
        comprobar("stepCargarMovimientosManager", "stepCargarMovimientosWorker");
    }

    private void comprobar(String manager, String worker) throws Exception {
        Step m = ctx.getBean(manager, Step.class);
        Step w = ctx.getBean(worker, Step.class);

        assertThat(m.isAllowStartIfComplete())
                .as("%s debe poder reejecutarse: si no, en un reinicio la limpieza se repite"
                        + " y la recarga no, y la tabla queda VACIA", manager)
                .isTrue();

        assertThat(w.isAllowStartIfComplete())
                .as("%s debe poder reejecutarse: es SU bandera la que recibe el splitter,"
                        + " y sin ella el reinicio solo repone las particiones que fallaron", worker)
                .isTrue();

        // La comprobacion que de verdad importa: que la bandera LLEGO al
        // splitter. Es un campo privado de SimpleStepExecutionSplitter, asi que
        // se lee por reflexion. Sin esto, el test verificaria la intencion
        // (los booleanos de los beans) pero no el efecto.
        Field campoSplitter = ReflectionUtils.findField(PartitionStep.class, "stepExecutionSplitter");
        ReflectionUtils.makeAccessible(campoSplitter);
        StepExecutionSplitter splitter = (StepExecutionSplitter) campoSplitter.get(m);

        assertThat(splitter)
                .as("%s deberia ser un PartitionStep con SimpleStepExecutionSplitter", manager)
                .isInstanceOf(SimpleStepExecutionSplitter.class);

        Field campoAllow = ReflectionUtils.findField(
                SimpleStepExecutionSplitter.class, "allowStartIfComplete");
        ReflectionUtils.makeAccessible(campoAllow);

        assertThat((Boolean) campoAllow.get(splitter))
                .as("el splitter de %s tiene que regenerar TODAS las particiones al reiniciar,"
                        + " no solo las FAILED", manager)
                .isTrue();
    }
}
