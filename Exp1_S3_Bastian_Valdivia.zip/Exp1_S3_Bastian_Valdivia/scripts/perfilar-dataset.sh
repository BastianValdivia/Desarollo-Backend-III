#!/usr/bin/env bash
# =====================================================================
# perfilar-dataset.sh - Perfila los 3 CSV del Banco XYZ y publica los
# repartos esperados que luego se contrastan contra la base de datos.
#
# Uso:   ./scripts/perfilar-dataset.sh
#
# La clasificacion aplica PRECEDENCIA: cada fila cae en una sola casilla,
# la primera regla que se cumple. Ese orden es el mismo que implementan
# los ItemProcessor, y por eso los numeros de aqui deben coincidir
# exactamente con los que quedan en PostgreSQL.
# =====================================================================
set -euo pipefail

DATA="$(cd "$(dirname "$0")/.." && pwd)/src/main/resources/data"
[ -d "$DATA" ] || { echo "No encuentro $DATA" >&2; exit 1; }

read -r -d '' LIB <<'AWKLIB' || true
function dias_mes(a, m,   arr) {
    if (m == 2) return (a % 4 == 0 && (a % 100 != 0 || a % 400 == 0)) ? 29 : 28
    split("31 28 31 30 31 30 31 31 30 31 30 31", arr, " ")
    return arr[m] + 0
}
function fecha_ok(s,   a, m, d, p) {
    if      (s ~ /^[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]$/)   { a=substr(s,1,4); m=substr(s,6,2); d=substr(s,9,2); p="yyyy-MM-dd" }
    else if (s ~ /^[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]$/)   { d=substr(s,1,2); m=substr(s,4,2); a=substr(s,7,4); p="dd-MM-yyyy" }
    else if (s ~ /^[0-9][0-9][0-9][0-9]\/[0-9][0-9]\/[0-9][0-9]$/) { a=substr(s,1,4); m=substr(s,6,2); d=substr(s,9,2); p="yyyy/MM/dd" }
    else if (s ~ /^[0-9][0-9]\/[0-9][0-9]\/[0-9][0-9][0-9][0-9]$/) { d=substr(s,1,2); m=substr(s,4,2); a=substr(s,7,4); p="dd/MM/yyyy" }
    else return ""
    a+=0; m+=0; d+=0
    if (m < 1 || m > 12)             return ""
    if (d < 1 || d > dias_mes(a, m)) return ""
    return p
}
function es_numero(s) { return (s ~ /^-?[0-9]+([.][0-9]+)?$/) }
function limpiar(s)   { gsub(/^[ \t\r]+|[ \t\r]+$/, "", s); return s }
function fila(etq, v) { printf "  %-34s %6d\n", etq, v }
AWKLIB

titulo() { printf '\n=====================================================================\n%s\n=====================================================================\n' "$1"; }

titulo "1. transacciones.csv  ->  banco.transaccion   (Job 1)"
awk -F, -e "$LIB" -e '
NR==1 { next }
{
  total++
  fecha=limpiar($2); monto=limpiar($3); tipo=tolower(limpiar($4))
  # -- RECHAZOS: fila irreparable, va al dead letter --
  if (fecha_ok(fecha) == "") { r["FECHA_INVALIDA"]++;    next }
  if (monto == "")           { r["MONTO_AUSENTE"]++;     next }
  if (!es_numero(monto))     { r["MONTO_NO_NUMERICO"]++; next }
  # -- ESTADO por precedencia: monto ANTES que tipo (asi lo hace el processor) --
  desconocido = (tipo != "credito" && tipo != "debito")
  if      (monto+0 <  0) e["ANOMALA_MONTO_NEGATIVO"]++
  else if (monto+0 == 0) e["ANOMALA_MONTO_CERO"]++
  else if (desconocido)  e["ANOMALA_TIPO_DESCONOCIDO"]++
  else                   e["VALIDA"]++
  # -- ANOMALIAS: todas las que tenga, para la columna "anomalias" --
  if (desconocido)    a["TIPO_DESCONOCIDO"]++
  if (monto+0 <  0)   a["MONTO_NEGATIVO"]++
  if (monto+0 == 0)   a["MONTO_CERO"]++
  fmt[fecha_ok(fecha)]++
}
END {
  print "\n-- ESTADO (excluyente, va a banco.transaccion.estado) --"
  neg=0; for (k in e) { fila(k, e[k]); neg+=e[k] }
  fila("EN NEGOCIO", neg)
  print "\n-- RECHAZOS (van a banco.registro_rechazado) --"
  rec=0; for (k in r) { fila(k, r[k]); rec+=r[k] }
  fila("RECHAZADAS", rec)
  print "\n-- ANOMALIAS detectadas (no excluyentes, columna anomalias) --"
  for (k in a) fila(k, a[k])
  print "\n-- Formatos de fecha reparados --"
  for (k in fmt) fila(k, fmt[k])
  printf "\n  CUADRATURA: %d negocio + %d rechazos = %d   (leidas %d)\n", neg, rec, neg+rec, total
}' "$DATA/transacciones.csv"

titulo "2. intereses.csv  ->  banco.interes_calculado   (Job 2)"
TMPDUP="$(mktemp)"
tail -n +2 "$DATA/intereses.csv" | sed 's/\r$//' | sort | uniq -c \
  | sed -E 's/^[[:space:]]*([0-9]+)[[:space:]]+/\1|/' > "$TMPDUP"
awk -F, -e "$LIB" -e '
NR==FNR { i=index($0,"|"); veces[substr($0,i+1)] = substr($0,1,i-1)+0; next }
FNR==1  { next }
{
  total++; linea=$0; sub(/\r$/,"",linea)
  saldo=limpiar($3); edad=limpiar($4); tipo=tolower(limpiar($5)); nombre=limpiar($2)
  # -- RECHAZOS --
  if (saldo == "")       { r["SALDO_AUSENTE"]++;     next }
  if (!es_numero(saldo)) { r["SALDO_NO_NUMERICO"]++; next }
  if (veces[linea] > 1 && ++visto[linea] > 1) { r["DUPLICADO"]++; next }
  # -- ANOMALIAS (todas) --
  n=0
  desconocido  = (tipo!="ahorro" && tipo!="prestamo" && tipo!="hipoteca")
  fuera_rango  = (edad != "" && (edad+0 < 18 || edad+0 > 99))
  if (desconocido)          { a["TIPO_DESCONOCIDO"]++;   n++ }
  if (edad == "")           { a["EDAD_AUSENTE"]++;       n++ }
  else if (fuera_rango)     { a["EDAD_FUERA_RANGO"]++;   n++ }
  if (nombre == "Unknown")  { a["NOMBRE_DESCONOCIDO"]++; n++ }
  # -- ESTADO por precedencia --
  if      (desconocido)         e["ANOMALA_TIPO_DESCONOCIDO"]++
  else if (fuera_rango)         e["ANOMALA_EDAD_FUERA_RANGO"]++
  else if (edad == "")          e["ANOMALA_EDAD_AUSENTE"]++
  else if (nombre == "Unknown") e["ANOMALA_NOMBRE_DESCONOCIDO"]++
  else                          e["VALIDA"]++
  cuantas[n]++
}
END {
  print "\n-- ESTADO (excluyente) --"
  neg=0; for (k in e) { fila(k, e[k]); neg+=e[k] }
  fila("EN NEGOCIO", neg)
  print "\n-- RECHAZOS --"
  rec=0; for (k in r) { fila(k, r[k]); rec+=r[k] }
  fila("RECHAZADAS", rec)
  print "\n-- ANOMALIAS detectadas (no excluyentes) --"
  for (k in a) fila(k, a[k])
  print "\n-- Anomalias por fila --"
  for (k in cuantas) fila(k " anomalia(s)", cuantas[k])
  printf "\n  CUADRATURA: %d negocio + %d rechazos = %d   (leidas %d)\n", neg, rec, neg+rec, total
}' "$TMPDUP" "$DATA/intereses.csv"
rm -f "$TMPDUP"

titulo "3. cuentas_anuales.csv  ->  banco.movimiento_anual   (Job 3)"
awk -F, -e "$LIB" -e '
NR==1 { next }
{
  total++
  fecha=limpiar($2); monto=limpiar($4); desc=limpiar($5); tr=tolower(limpiar($3))
  # "deposito" y "deposito" con tilde son el mismo tipo: se detecta por prefijo,
  # asi el script no depende de la codificacion del terminal.
  if (tr ~ /^dep/) tr = "deposito"
  # -- RECHAZOS --
  if (fecha_ok(fecha) == "") { r["FECHA_INVALIDA"]++;    next }
  if (monto == "")           { r["MONTO_AUSENTE"]++;     next }
  if (!es_numero(monto))     { r["MONTO_NO_NUMERICO"]++; next }
  if (tr!="deposito" && tr!="retiro" && tr!="pago" && tr!="compra") { r["TIPO_AUSENTE"]++; next }
  fmt[fecha_ok(fecha)]++
  # -- ANOMALIAS (todas) --
  n=0
  suma = (tr == "deposito")    # deposito suma; retiro/pago/compra restan
  if (monto+0 <  0) { a["MONTO_NEGATIVO"]++; n++; if (suma) a["SIGNO_CONTRADICTORIO"]++ }
  if (monto+0 == 0) { a["MONTO_CERO"]++; n++ }
  if (desc == "")   { a["DESCRIPCION_AUSENTE"]++; n++ }
  # -- ESTADO por precedencia --
  if      (monto+0 < 0 && suma) e["ANOMALA_SIGNO_CONTRADICTORIO"]++
  else if (monto+0 <  0)        e["ANOMALA_MONTO_NEGATIVO"]++
  else if (monto+0 == 0)        e["ANOMALA_MONTO_CERO"]++
  else if (desc == "")          e["ANOMALA_DESCRIPCION_AUSENTE"]++
  else                          e["VALIDA"]++
  cuantas[n]++
}
END {
  print "\n-- ESTADO (excluyente) --"
  neg=0; for (k in e) { fila(k, e[k]); neg+=e[k] }
  fila("EN NEGOCIO", neg)
  print "\n-- RECHAZOS --"
  rec=0; for (k in r) { fila(k, r[k]); rec+=r[k] }
  fila("RECHAZADAS", rec)
  print "\n-- ANOMALIAS detectadas (no excluyentes) --"
  for (k in a) fila(k, a[k])
  print "\n-- Anomalias por fila --"
  for (k in cuantas) fila(k " anomalia(s)", cuantas[k])
  print "\n-- Formatos de fecha reparados --"
  for (k in fmt) fila(k, fmt[k])
  printf "\n  CUADRATURA: %d negocio + %d rechazos = %d   (leidas %d)\n", neg, rec, neg+rec, total
}' "$DATA/cuentas_anuales.csv"

printf '\n'
