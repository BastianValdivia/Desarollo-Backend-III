#!/usr/bin/env python3
"""
Dibuja los tres graficos del criterio 4 a partir de results/scaling-results.csv.

    python scripts/graficar.py

POR QUE GENERA SVG A MANO Y NO USA MATPLOTLIB
---------------------------------------------
Este proyecto no declara dependencias de Python, y anadir matplotlib obligaria
al evaluador a instalar medio gigabyte para ver tres graficos. SVG es texto
plano: se abre en cualquier navegador, se ve nitido a cualquier zoom, se
versiona en git y se puede leer con un editor para comprobar que los numeros
del dibujo son los mismos del CSV. Solo se usa la libreria estandar.

REGLA QUE SE RESPETA EN LOS TRES: EL EJE Y EMPIEZA EN CERO.
Un eje truncado convierte una mejora del 3% en una montana visual. Es la forma
mas comun de mentir con un grafico sin escribir un solo numero falso.
"""
import csv
import os
from collections import defaultdict

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV = os.path.join(RAIZ, "results", "scaling-results.csv")
SALIDA = os.path.join(RAIZ, "evidencias", "04-escalado")

ANCHO, ALTO = 760, 420
MARGEN = {"izq": 80, "der": 190, "arr": 50, "aba": 60}

COLORES = {"SECUENCIAL": "#5b6b7a", "MULTI_THREAD": "#c1663f", "PARTICIONADO": "#2f6f8f"}


def mediana(xs):
    ys = sorted(xs)
    n = len(ys)
    if n == 0:
        return 0.0
    m = n // 2
    return ys[m] if n % 2 else (ys[m - 1] + ys[m]) / 2


def cuantil(xs, q):
    """Interpolacion lineal, el mismo metodo que usa AnalizadorResultados.java."""
    ys = sorted(xs)
    if not ys:
        return 0.0
    if len(ys) == 1:
        return ys[0]
    pos = q * (len(ys) - 1)
    bajo, alto = int(pos), min(int(pos) + 1, len(ys) - 1)
    peso = pos - bajo
    return ys[bajo] * (1 - peso) + ys[alto] * peso


def cargar():
    """Solo las repeticiones MEDIDAS y validas. Los calentamientos estan en el
    CSV marcados con warmup=true y se descartan aqui, no en el fichero."""
    celdas = defaultdict(list)
    with open(CSV, newline="", encoding="utf-8") as f:
        for fila in csv.DictReader(f):
            if fila["warmup"] == "true":
                continue
            if fila["batch_status"] != "COMPLETED" or fila["filas_esperadas_ok"] != "true":
                continue
            clave = (int(fila["dataset_filas"]), fila["estrategia"],
                     int(fila["paralelismo"]), int(fila["chunk_size"]))
            celdas[clave].append(fila)
    return celdas


# ---------------------------------------------------------------------
# Utilidades de dibujo
# ---------------------------------------------------------------------
def marco(titulo, etiqueta_y, ymax, xs, etiquetas_x):
    x0, y0 = MARGEN["izq"], ALTO - MARGEN["aba"]
    x1, y1 = ANCHO - MARGEN["der"], MARGEN["arr"]
    p = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{ANCHO}" height="{ALTO}" '
         f'viewBox="0 0 {ANCHO} {ALTO}" font-family="system-ui,sans-serif">',
         f'<rect width="{ANCHO}" height="{ALTO}" fill="#ffffff"/>',
         f'<text x="{ANCHO/2}" y="28" text-anchor="middle" font-size="16" '
         f'font-weight="600" fill="#1a1a1a">{titulo}</text>']

    # Rejilla horizontal y escala. El 0 SIEMPRE esta incluido.
    for i in range(6):
        v = ymax * i / 5
        y = y0 - (y0 - y1) * i / 5
        p.append(f'<line x1="{x0}" y1="{y:.1f}" x2="{x1}" y2="{y:.1f}" '
                 f'stroke="#e3e3e3" stroke-width="1"/>')
        p.append(f'<text x="{x0-10}" y="{y+4:.1f}" text-anchor="end" font-size="11" '
                 f'fill="#555">{v:,.0f}</text>')

    p.append(f'<line x1="{x0}" y1="{y0}" x2="{x1}" y2="{y0}" stroke="#333" stroke-width="1.5"/>')
    p.append(f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y1}" stroke="#333" stroke-width="1.5"/>')
    p.append(f'<text x="18" y="{(y0+y1)/2}" text-anchor="middle" font-size="12" fill="#333" '
             f'transform="rotate(-90 18 {(y0+y1)/2})">{etiqueta_y}</text>')

    for x, etq in zip(xs, etiquetas_x):
        p.append(f'<text x="{x:.1f}" y="{y0+20}" text-anchor="middle" font-size="12" '
                 f'fill="#333">{etq}</text>')
    return p, x0, y0, x1, y1


def leyenda(p, entradas, x1):
    for i, (texto, color) in enumerate(entradas):
        y = MARGEN["arr"] + 14 + i * 20
        p.append(f'<rect x="{x1+18}" y="{y-9}" width="12" height="12" fill="{color}"/>')
        p.append(f'<text x="{x1+36}" y="{y+1}" font-size="12" fill="#333">{texto}</text>')


def guardar(nombre, partes):
    partes.append("</svg>")
    ruta = os.path.join(SALIDA, nombre)
    with open(ruta, "w", encoding="utf-8") as f:
        f.write("\n".join(partes))
    print("escrito", ruta)


# ---------------------------------------------------------------------
# Grafico 1 - throughput contra paralelismo
# ---------------------------------------------------------------------
def grafico_throughput(celdas, filas, chunk):
    puntos = {}
    for (n, estrategia, par, ch), reps in celdas.items():
        if n != filas or ch != chunk:
            continue
        puntos.setdefault(estrategia, {})[par] = mediana(
            [float(r["throughput_filas_seg"]) for r in reps])

    pars = [1, 2, 4, 8]
    ymax = max(v for d in puntos.values() for v in d.values()) * 1.15
    xs = [MARGEN["izq"] + (ANCHO - MARGEN["izq"] - MARGEN["der"]) * i / (len(pars) - 1)
          for i in range(len(pars))]
    p, x0, y0, x1, y1 = marco(
        f"Throughput vs paralelismo ({filas} filas, chunk={chunk})",
        "filas / segundo (mediana)", ymax, xs, [str(v) for v in pars])

    for estrategia, serie in puntos.items():
        camino = []
        for x, par in zip(xs, pars):
            v = serie.get(par)
            if v is None:
                continue
            y = y0 - (y0 - y1) * v / ymax
            camino.append(f"{x:.1f},{y:.1f}")
            p.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" fill="{COLORES[estrategia]}"/>')
            p.append(f'<text x="{x:.1f}" y="{y-10:.1f}" text-anchor="middle" font-size="10" '
                     f'fill="#333">{v:,.0f}</text>')
        if len(camino) > 1:
            p.append(f'<polyline points="{" ".join(camino)}" fill="none" '
                     f'stroke="{COLORES[estrategia]}" stroke-width="2.5"/>')

    p.append(f'<text x="{(x0+x1)/2}" y="{ALTO-16}" text-anchor="middle" font-size="12" '
             f'fill="#333">hilos / gridSize</text>')
    leyenda(p, [(e, COLORES[e]) for e in puntos], x1)
    guardar(f"grafico-throughput-{filas}.svg", p)


# ---------------------------------------------------------------------
# Grafico 2 - speedup real contra el ideal y contra Amdahl
# ---------------------------------------------------------------------
def grafico_speedup(celdas, filas, chunk):
    base = min(mediana([float(r["wall_clock_ms"]) for r in reps])
               for (n, e, par, ch), reps in celdas.items()
               if n == filas and e == "SECUENCIAL")

    reales = {}
    for (n, estrategia, par, ch), reps in celdas.items():
        if n != filas or ch != chunk or estrategia == "SECUENCIAL":
            continue
        reales.setdefault(estrategia, {})[par] = base / mediana(
            [float(r["wall_clock_ms"]) for r in reps])

    pars = [1, 2, 4, 8]
    # p de Amdahl despejada del speedup medido con MAS paralelismo:
    #   S = 1/((1-p) + p/N)  =>  p = (1 - 1/S) / (1 - 1/N)
    s8 = max(d.get(8, 1.0) for d in reales.values())
    pamdahl = (1 - 1 / s8) / (1 - 1 / 8)

    ymax = 8.5
    xs = [MARGEN["izq"] + (ANCHO - MARGEN["izq"] - MARGEN["der"]) * i / (len(pars) - 1)
          for i in range(len(pars))]
    p, x0, y0, x1, y1 = marco(
        f"Speedup real vs ideal vs Amdahl ({filas} filas, chunk={chunk})",
        "speedup sobre el mejor secuencial", ymax, xs, [str(v) for v in pars])

    def curva(valores, color, guiones=""):
        camino = []
        for x, par in zip(xs, pars):
            v = valores(par)
            y = y0 - (y0 - y1) * v / ymax
            camino.append(f"{x:.1f},{y:.1f}")
        p.append(f'<polyline points="{" ".join(camino)}" fill="none" stroke="{color}" '
                 f'stroke-width="2" {guiones}/>')

    curva(lambda n: n, "#9aa5ad", 'stroke-dasharray="6 4"')
    curva(lambda n: 1 / ((1 - pamdahl) + pamdahl / n), "#7a4fa3", 'stroke-dasharray="2 3"')

    for estrategia, serie in reales.items():
        camino = []
        for x, par in zip(xs, pars):
            v = serie.get(par, 1.0 if par == 1 else None)
            if v is None:
                continue
            y = y0 - (y0 - y1) * v / ymax
            camino.append(f"{x:.1f},{y:.1f}")
            p.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" fill="{COLORES[estrategia]}"/>')
            p.append(f'<text x="{x:.1f}" y="{y-10:.1f}" text-anchor="middle" font-size="10" '
                     f'fill="#333">{v:.2f}x</text>')
        p.append(f'<polyline points="{" ".join(camino)}" fill="none" '
                 f'stroke="{COLORES[estrategia]}" stroke-width="2.5"/>')

    p.append(f'<text x="{(x0+x1)/2}" y="{ALTO-16}" text-anchor="middle" font-size="12" '
             f'fill="#333">hilos / gridSize</text>')
    leyenda(p, [("ideal (lineal)", "#9aa5ad"),
                (f"Amdahl p={pamdahl:.3f}", "#7a4fa3")]
            + [(e, COLORES[e]) for e in reales], x1)
    guardar(f"grafico-speedup-{filas}.svg", p)


# ---------------------------------------------------------------------
# Grafico 3 - caja y bigotes de la duracion
# ---------------------------------------------------------------------
def grafico_cajas(celdas, filas):
    seleccion = sorted(
        [(k, v) for k, v in celdas.items() if k[0] == filas and k[3] == 500],
        key=lambda kv: (kv[0][1], kv[0][2]))
    datos = [(f"{e[:3]}-p{par}", [float(r["wall_clock_ms"]) for r in reps], e)
             for (n, e, par, ch), reps in seleccion]

    ymax = max(max(v) for _, v, _ in datos) * 1.12
    paso = (ANCHO - MARGEN["izq"] - MARGEN["der"]) / len(datos)
    xs = [MARGEN["izq"] + paso * (i + 0.5) for i in range(len(datos))]
    p, x0, y0, x1, y1 = marco(
        f"Dispersion de la duracion ({filas} filas, chunk=500, 5 medidas por celda)",
        "milisegundos", ymax, xs, [d[0] for d in datos])

    for x, (etq, valores, estrategia) in zip(xs, datos):
        q1, q2, q3 = cuantil(valores, .25), cuantil(valores, .5), cuantil(valores, .75)
        lo, hi = min(valores), max(valores)
        ey = lambda v: y0 - (y0 - y1) * v / ymax
        ancho = min(paso * 0.5, 40)
        # bigotes = minimo y maximo observados; caja = P25..P75; linea = mediana
        p.append(f'<line x1="{x:.1f}" y1="{ey(lo):.1f}" x2="{x:.1f}" y2="{ey(hi):.1f}" '
                 f'stroke="#666" stroke-width="1"/>')
        p.append(f'<rect x="{x-ancho/2:.1f}" y="{ey(q3):.1f}" width="{ancho:.1f}" '
                 f'height="{max(ey(q1)-ey(q3),1):.1f}" fill="{COLORES[estrategia]}" '
                 f'fill-opacity="0.35" stroke="{COLORES[estrategia]}"/>')
        p.append(f'<line x1="{x-ancho/2:.1f}" y1="{ey(q2):.1f}" x2="{x+ancho/2:.1f}" '
                 f'y2="{ey(q2):.1f}" stroke="{COLORES[estrategia]}" stroke-width="2.5"/>')
        p.append(f'<text x="{x:.1f}" y="{ey(hi)-8:.1f}" text-anchor="middle" font-size="10" '
                 f'fill="#333">{q2:,.0f}</text>')

    leyenda(p, [(e, c) for e, c in COLORES.items()], x1)
    guardar(f"grafico-cajas-{filas}.svg", p)


def main():
    os.makedirs(SALIDA, exist_ok=True)
    celdas = cargar()
    for filas in sorted({k[0] for k in celdas}):
        grafico_throughput(celdas, filas, 500)
        grafico_speedup(celdas, filas, 500)
        grafico_cajas(celdas, filas)


if __name__ == "__main__":
    main()
