#!/usr/bin/env bash
# =====================================================================
# verificar-entorno.sh - Comprueba que esta maquina puede ejecutar el
# proyecto ANTES de intentarlo, y explica como arreglar lo que falte.
#
# Uso:   ./scripts/verificar-entorno.sh
#
# No modifica nada. Solo mira y avisa.
# =====================================================================

ok=0; aviso=0; error=0
OK()    { printf "  [ OK ]    %s\n" "$1"; ok=$((ok+1)); }
AVISO() { printf "  [AVISO]   %s\n" "$1"; aviso=$((aviso+1)); }
ERROR() { printf "  [ERROR]   %s\n" "$1"; error=$((error+1)); }
COMO()  { printf "            -> %s\n" "$1"; }

echo "====================================================================="
echo " Comprobacion de entorno - Banco XYZ (Spring Batch)"
echo "====================================================================="
echo

# ---------------------------------------------------------------------
echo "1. JAVA"
if ! command -v java >/dev/null 2>&1; then
    ERROR "No hay ningun 'java' en el PATH."
    COMO "Instala un JDK 21 o superior (Temurin: https://adoptium.net)"
else
    bruto=$(java -version 2>&1 | head -1)
    # "21.0.2" -> 21 ; "1.8.0_401" -> 8
    ver=$(echo "$bruto" | sed -E 's/.*version "([0-9]+)\.([0-9]+).*/\1 \2/' | awk '{print ($1==1)?$2:$1}')
    if [ -z "$ver" ] || ! [ "$ver" -eq "$ver" ] 2>/dev/null; then
        AVISO "No pude interpretar la version de Java: $bruto"
    elif [ "$ver" -lt 21 ]; then
        ERROR "Java $ver es demasiado antiguo. El proyecto compila contra la API 21."
        COMO "Instala un JDK 21 o superior y ajusta JAVA_HOME"
    else
        OK "Java $ver detectado ($bruto)"
    fi
fi

# ---------------------------------------------------------------------
echo
echo "2. DOCKER"
if ! command -v docker >/dev/null 2>&1; then
    ERROR "El comando 'docker' no existe."
    COMO "Instala Docker Desktop: https://www.docker.com/products/docker-desktop"
elif ! docker info >/dev/null 2>&1; then
    ERROR "Docker esta instalado pero el motor NO responde."
    COMO "Abre Docker Desktop y espera a que el icono de la ballena deje de animarse"
else
    OK "Motor Docker respondiendo (version $(docker version --format '{{.Server.Version}}' 2>/dev/null))"
fi

# ---------------------------------------------------------------------
echo
echo "3. PUERTO 5432 (el fallo mas frecuente al cambiar de maquina)"
ocupado=""
if command -v netstat >/dev/null 2>&1; then
    ocupado=$(netstat -an 2>/dev/null | grep -E '[:.]5432[^0-9]' | grep -iE 'listen' | head -1)
elif command -v ss >/dev/null 2>&1; then
    ocupado=$(ss -ltn 2>/dev/null | grep -E ':5432\b' | head -1)
elif command -v lsof >/dev/null 2>&1; then
    ocupado=$(lsof -iTCP:5432 -sTCP:LISTEN 2>/dev/null | tail -1)
fi
nuestro=$(docker ps --filter "name=bancoxyz-db" --format '{{.Names}}' 2>/dev/null)
if [ -z "$ocupado" ]; then
    OK "Puerto 5432 libre"
elif [ -n "$nuestro" ]; then
    OK "Puerto 5432 ocupado por NUESTRO contenedor (bancoxyz-db). Correcto."
else
    ERROR "Puerto 5432 OCUPADO por otro proceso (PostgreSQL nativo u otro contenedor)."
    COMO "Opcion A: apaga ese servicio."
    COMO "Opcion B: cambia el puerto del HOST (el de la IZQUIERDA) en compose.yaml"
    COMO "          de \"5432:5432\" a \"5433:5432\", y en"
    COMO "          src/main/resources/application.yml pon localhost:5433"
    echo "            Proceso detectado: $ocupado"
fi

# ---------------------------------------------------------------------
echo
echo "4. ARCHIVOS IMPRESCINDIBLES"
raiz="$(cd "$(dirname "$0")/.." && pwd)"
for f in pom.xml compose.yaml mvnw docker/initdb/00-schemas.sql \
         src/main/resources/schema-negocio.sql \
         src/main/resources/data/transacciones.csv \
         src/main/resources/data/intereses.csv \
         src/main/resources/data/cuentas_anuales.csv; do
    if [ -f "$raiz/$f" ]; then OK "$f"; else ERROR "FALTA $f"; fi
done

# ---------------------------------------------------------------------
echo
echo "5. RED (solo hace falta la PRIMERA vez)"
if [ -d "$HOME/.m2/repository/org/springframework/boot" ]; then
    OK "Dependencias de Spring ya en cache local (~/.m2). No necesitas internet."
else
    AVISO "Primera ejecucion: Maven descargara ~150-200 MB. Necesitas internet."
fi
if docker image inspect postgres:17-alpine >/dev/null 2>&1; then
    OK "Imagen postgres:17-alpine ya descargada."
else
    AVISO "Docker descargara la imagen postgres:17-alpine (~110 MB) la primera vez."
fi

# ---------------------------------------------------------------------
echo
echo "====================================================================="
printf " Resultado: %d correctos, %d avisos, %d errores\n" "$ok" "$aviso" "$error"
if [ "$error" -gt 0 ]; then
    echo " NO se puede ejecutar todavia: corrige los ERROR de arriba."
    echo "====================================================================="
    exit 1
fi
echo " Entorno listo. Siguiente paso:"
echo "     docker compose up -d"
echo "     ./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias"
echo "====================================================================="
