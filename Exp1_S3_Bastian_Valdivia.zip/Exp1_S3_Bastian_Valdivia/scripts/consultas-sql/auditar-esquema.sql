-- =====================================================================
-- auditar-esquema.sql - Prueba que el esquema hace lo que promete.
--
-- Parte A: inserta una fila representativa de CADA estado medido en
--          docs/analisis-datos.md. Todas deben entrar.
-- Parte B: intenta insertar filas invalidas. TODAS deben ser rechazadas,
--          y cada una por la restriccion que le corresponde.
--
-- Todo corre dentro de UNA transaccion que termina en ROLLBACK: no deja
-- ni una fila en la base. Se puede ejecutar cuantas veces se quiera.
--
-- ---------------------------------------------------------------------
-- DOS COSAS QUE ANTES ESTABAN MAL Y HACIAN QUE ESTE SCRIPT MINTIERA
-- ---------------------------------------------------------------------
-- 1) CLAVES QUE NO PUEDEN COLISIONAR CON DATOS REALES.
--    La parte A usaba cuenta_id=101, estado_cuenta_anual (101,2024),
--    resumen_diario '2024-06-30' y control_carga job_execution_id=1, que son
--    claves que EXISTEN en una base ya cargada. En PostgreSQL, un error dentro
--    de una transaccion la ABORTA ENTERA: a partir de ahi toda sentencia
--    devuelve "current transaction is aborted". Consecuencia: el script fallaba
--    en el primer duplicado, los SELECT de A2 no se ejecutaban y las 14 pruebas
--    B tampoco... pero como en B se ESPERA un ERROR en cada una, la salida
--    PARECIA correcta. Un arnes de pruebas que da verde sin haber probado nada
--    es peor que no tener arnes.
--    Ahora todo usa valores centinela imposibles en datos reales: cuenta 999,
--    anio 1999, fecha '1999-01-01', periodo '1999-01', job_execution_id 999999.
--
-- 2) ON_ERROR_STOP DISTINTO EN CADA PARTE.
--    En la parte A un error es un FALLO DEL ARNES y hay que parar (on).
--    En la parte B un error es el RESULTADO ESPERADO y hay que continuar (off).
--    Antes estaba en off para las dos, que es justo lo que dejaba pasar los 14
--    falsos verdes.
--
-- Uso:
--   docker exec -i bancoxyz-db psql -U banco -d bancoxyz < scripts/auditar-esquema.sql
-- =====================================================================
-- Parte A: si algo aqui falla es un fallo DEL SCRIPT, no del esquema. Parar.
\set ON_ERROR_STOP on
BEGIN;

\echo '===== A. FILAS LEGITIMAS: deben ENTRAR todas ====='
\echo '-- transaccion: 4 estados x 4 formatos'
INSERT INTO banco.transaccion (id,fecha,fecha_original,formato_fecha,monto,monto_original,tipo,tipo_original,estado,anomalias,numero_linea,job_execution_id) VALUES
 (900001,'2024-06-30','2024-06-30','yyyy-MM-dd', 3000,'3000','CREDITO','credito','VALIDA','',2,1),
 (900002,'2024-04-03','03-04-2024','dd-MM-yyyy',  800,'800','DESCONOCIDO','invalid','ANOMALA_TIPO_DESCONOCIDO','TIPO_DESCONOCIDO',3,1),
 (900003,'2024-05-04','04/05/2024','dd/MM/yyyy', -500,'-500','DEBITO','debito','ANOMALA_MONTO_NEGATIVO','MONTO_NEGATIVO',4,1),
 (900004,'2024-03-18','2024/03/18','yyyy/MM/dd',    0,'0','DESCONOCIDO','invalid','ANOMALA_MONTO_CERO','MONTO_CERO,TIPO_DESCONOCIDO',5,1);

\echo '-- registro_rechazado: 5 motivos, 4 fases'
INSERT INTO banco.registro_rechazado (archivo_origen,job_name,job_execution_id,step_name,fase,motivo,campo,valor_crudo,linea_cruda,excepcion) VALUES
 ('transacciones.csv','jobTransaccionesDiarias',1,'stepX','PROCESS','FECHA_INVALIDA','fecha','2024-13-01','7,2024-13-01,700,debito','X'),
 ('intereses.csv','jobInteresesMensuales',1,'stepX','PROCESS','SALDO_AUSENTE','saldo','','114,Unknown,,30,-1','X'),
 ('intereses.csv','jobInteresesMensuales',1,'stepX','WRITE','DUPLICADO',NULL,NULL,'dup','X'),
 ('cuentas_anuales.csv','jobEstadosCuentaAnuales',1,'stepX','READ','LINEA_MALFORMADA',NULL,NULL,'basura','X'),
 ('transacciones.csv','jobTransaccionesDiarias',1,'stepX','FILTER','OTRO',NULL,NULL,'x','X');

\echo '-- interes_calculado: los 5 estados, edad NULL'
INSERT INTO banco.interes_calculado (periodo,cuenta_id,nombre,nombre_original,edad,edad_original,tipo,tipo_original,saldo_inicial,saldo_original,tasa,interes,estado,anomalias,numero_linea,job_execution_id) VALUES
 ('1999-01',991,'Alice Brown','Alice Brown',35,'35','AHORRO','ahorro',10000,'10000',0.02500,250,'VALIDA','',2,1),
 ('1999-01',992,'Bob Johnson','Bob Johnson',40,'40','DESCONOCIDO','-1',7000,'7000',0.00000,0,'ANOMALA_TIPO_DESCONOCIDO','TIPO_DESCONOCIDO',3,1),
 ('1999-01',993,'Jane Smith','Jane Smith',NULL,'','PRESTAMO','prestamo',12000,'12000',0.01000,120,'ANOMALA_EDAD_AUSENTE','EDAD_AUSENTE',4,1),
 ('1999-01',994,'John Doe','John Doe',NULL,'150','HIPOTECA','hipoteca',8000,'8000',0.03000,240,'ANOMALA_EDAD_FUERA_RANGO','EDAD_FUERA_RANGO',5,1),
 ('1999-01',995,'DESCONOCIDO','Unknown',25,'25','AHORRO','ahorro',5000,'5000',0.02500,125,'ANOMALA_NOMBRE_DESCONOCIDO','NOMBRE_DESCONOCIDO',6,1);

\echo '-- movimiento_anual: los 5 estados, signo +1/-1, tilde conservada'
INSERT INTO banco.movimiento_anual (cuenta_id,fecha,fecha_original,formato_fecha,transaccion,transaccion_original,signo,monto,monto_original,descripcion,estado,anomalias,numero_linea,job_execution_id) VALUES
 (991,'2024-03-08','08-03-2024','dd-MM-yyyy','DEPOSITO','deposito', 1,3000,'3000','Ingreso mensual','VALIDA','',2,1),
 (992,'2024-07-24','24-07-2024','dd-MM-yyyy','RETIRO','retiro',    -1,1500,'1500','SIN DESCRIPCION','ANOMALA_DESCRIPCION_AUSENTE','DESCRIPCION_AUSENTE',3,1),
 (993,'2024-03-18','2024/03/18','yyyy/MM/dd','COMPRA','compra',    -1, 500,'-500','Compra en tienda','ANOMALA_MONTO_NEGATIVO','MONTO_NEGATIVO',4,1),
 (994,'2024-02-26','2024-02-26','yyyy-MM-dd','DEPOSITO','depósito', 1, 500,'-500','Ingreso extra','ANOMALA_SIGNO_CONTRADICTORIO','MONTO_NEGATIVO,SIGNO_CONTRADICTORIO',5,1),
 (995,'2024-06-21','2024/06/21','yyyy/MM/dd','PAGO','pago',        -1,   0,'0','Retiro parcial','ANOMALA_MONTO_CERO','MONTO_CERO',6,1);

\echo '-- cuenta, control_carga, resumen_diario, estado_cuenta_anual, ejecucion_metrica'
INSERT INTO banco.cuenta (cuenta_id,nombre,tipo_predominante,n_posiciones,saldo_inicial,interes_aplicado,saldo,periodo_aplicado,job_execution_id)
 VALUES (999,'Alice Brown','AHORRO',20,10000,250,10250,'1999-01',999999);
INSERT INTO banco.control_carga (archivo_origen,job_name,job_execution_id,filas_entrada,filas_negocio,filas_rechazadas)
 VALUES ('transacciones.csv','jobTransaccionesDiarias',999999,1000,785,215);
INSERT INTO banco.resumen_diario (fecha,total_operaciones,n_creditos,n_debitos,n_tipo_desconocido,monto_total,monto_creditos,monto_debitos,monto_promedio,monto_maximo,n_anomalas,n_rechazadas,job_execution_id)
 VALUES ('1999-01-01',12,7,3,2,25000,15000,8000,2083.3333,5000,4,0,999999);
INSERT INTO banco.estado_cuenta_anual (cuenta_id,anio,n_movimientos,n_depositos,n_retiros,n_pagos,n_compras,total_depositos,total_retiros,total_pagos,total_compras,saldo_neto,n_anomalias,primera_fecha,ultima_fecha,job_execution_id)
 VALUES (199,1999,50,20,10,10,10,60000,15000,10000,20000,15000,7,'1999-01-05','1999-12-30',999999);
INSERT INTO banco.ejecucion_metrica (job_name,fase,estrategia,paralelismo,chunk_size,dataset_filas,repeticion,wall_clock_ms,hikari_pool_size,cpus,heap_max_mb,batch_status)
 VALUES ('jobTransaccionesDiarias','F0-baseline','SECUENCIAL',1,200,1000,1,1240,12,8,4096,'COMPLETED');

\echo ''
\echo '===== A2. COLUMNAS CALCULADAS POR LA BASE ====='
-- Los WHERE aislan las filas del ARNES de los datos reales. Sin ellos, sobre una
-- base cargada estos SELECT devolvian 784 y 952 filas y la evidencia era ilegible.
SELECT id, estado, es_anomala FROM banco.transaccion WHERE id>=900001 ORDER BY id;
SELECT cuenta_id, saldo_inicial, interes, saldo_final FROM banco.interes_calculado
 WHERE periodo='1999-01' ORDER BY cuenta_id;
SELECT cuenta_id, transaccion, signo, monto, monto_con_signo, anio FROM banco.movimiento_anual
 WHERE cuenta_id BETWEEN 991 AND 995 ORDER BY cuenta_id;
SELECT filas_entrada, filas_negocio, filas_rechazadas, cuadra FROM banco.control_carga
 WHERE job_execution_id=999999;

-- Parte B: aqui un ERROR es el RESULTADO ESPERADO, asi que hay que seguir.
\set ON_ERROR_STOP off
\echo '===== B. FILAS INVALIDAS: la base DEBE rechazarlas ====='

\echo ''
\echo '-- B1. tipo inexistente en transaccion (esperado: viola ck_tx_tipo)'
SAVEPOINT s; INSERT INTO banco.transaccion (id,fecha,fecha_original,formato_fecha,monto,monto_original,tipo,tipo_original,estado,numero_linea,job_execution_id)
 VALUES (900010,'2024-01-01','x','yyyy-MM-dd',1,'1','TRANSFER','x','VALIDA',1,1); ROLLBACK TO s;

\echo '-- B2. estado inventado (esperado: viola ck_tx_estado)'
SAVEPOINT s; INSERT INTO banco.transaccion (id,fecha,fecha_original,formato_fecha,monto,monto_original,tipo,tipo_original,estado,numero_linea,job_execution_id)
 VALUES (900011,'2024-01-01','x','yyyy-MM-dd',1,'1','CREDITO','x','ANOMALA_INVENTADA',1,1); ROLLBACK TO s;

\echo '-- B3. formato de fecha no contemplado (esperado: viola ck_tx_formato)'
SAVEPOINT s; INSERT INTO banco.transaccion (id,fecha,fecha_original,formato_fecha,monto,monto_original,tipo,tipo_original,estado,numero_linea,job_execution_id)
 VALUES (900012,'2024-01-01','x','MM-dd-yyyy',1,'1','CREDITO','x','VALIDA',1,1); ROLLBACK TO s;

\echo '-- B4. motivo de rechazo fuera de la lista (esperado: viola ck_rechazo_motivo)'
SAVEPOINT s; INSERT INTO banco.registro_rechazado (archivo_origen,job_name,job_execution_id,step_name,fase,motivo,linea_cruda,excepcion)
 VALUES ('x.csv','jobX',1,'stepX','PROCESS','MOTIVO_RARO','x','X'); ROLLBACK TO s;

\echo '-- B5. fase inexistente (esperado: viola ck_rechazo_fase)'
SAVEPOINT s; INSERT INTO banco.registro_rechazado (archivo_origen,job_name,job_execution_id,step_name,fase,motivo,linea_cruda,excepcion)
 VALUES ('x.csv','jobX',1,'stepX','LIMBO','OTRO','x','X'); ROLLBACK TO s;

\echo '-- B6. linea_cruda nula (esperado: viola NOT NULL, es la red de seguridad)'
SAVEPOINT s; INSERT INTO banco.registro_rechazado (archivo_origen,job_name,job_execution_id,step_name,fase,motivo,linea_cruda,excepcion)
 VALUES ('x.csv','jobX',1,'stepX','READ','OTRO',NULL,'X'); ROLLBACK TO s;

\echo '-- B7. edad fuera de 18..99 (esperado: viola ck_int_edad)'
SAVEPOINT s; INSERT INTO banco.interes_calculado (periodo,cuenta_id,nombre,nombre_original,edad,edad_original,tipo,tipo_original,saldo_inicial,saldo_original,tasa,interes,estado,numero_linea,job_execution_id)
 VALUES ('2024-07',199,'X','X',150,'150','AHORRO','ahorro',1,'1',0.01,0,'VALIDA',1,1); ROLLBACK TO s;

\echo '-- B8. tasa >= 1, o sea 100% de interes (esperado: viola ck_int_tasa)'
SAVEPOINT s; INSERT INTO banco.interes_calculado (periodo,cuenta_id,nombre,nombre_original,edad,edad_original,tipo,tipo_original,saldo_inicial,saldo_original,tasa,interes,estado,numero_linea,job_execution_id)
 VALUES ('2024-07',198,'X','X',30,'30','AHORRO','ahorro',1,'1',1.5,0,'VALIDA',1,1); ROLLBACK TO s;

\echo '-- B9. duplicado exacto (esperado: viola uq_interes_posicion)'
-- AUTOCONTENIDA: la prueba siembra su PROPIA fila y despues intenta la copia.
--
-- Antes dependia de que la parte A hubiera insertado ('2024-06',101,'Alice
-- Brown',...). Era la UNICA prueba del script cuyo resultado esperado no lo
-- producia el esquema sino un dato sembrado por otra seccion, y bastaba con
-- ejecutar B aislada -o con que A fallara- para que el INSERT pasara sin error
-- y uq_interes_posicion se quedara SIN EJERCITAR. Un falso negativo silencioso
-- justo en la restriccion que sostiene los 5 rechazos DUPLICADO del contrato de
-- intereses.csv (216 = 211 SALDO_AUSENTE + 5 DUPLICADO).
--
-- El primer INSERT debe ir bien y el segundo debe reventar. Los dos van dentro
-- del mismo SAVEPOINT, asi que al revertir no queda rastro de ninguno.
SAVEPOINT s;
INSERT INTO banco.interes_calculado (periodo,cuenta_id,nombre,nombre_original,edad,edad_original,tipo,tipo_original,saldo_inicial,saldo_original,tasa,interes,estado,numero_linea,job_execution_id)
 VALUES ('1999-09',997,'SEMILLA B9','SEMILLA B9',35,'35','AHORRO','ahorro',10000,'10000',0.025,250,'VALIDA',1,999999);
INSERT INTO banco.interes_calculado (periodo,cuenta_id,nombre,nombre_original,edad,edad_original,tipo,tipo_original,saldo_inicial,saldo_original,tasa,interes,estado,numero_linea,job_execution_id)
 VALUES ('1999-09',997,'SEMILLA B9','SEMILLA B9',35,'35','AHORRO','ahorro',10000,'10000',0.025,250,'VALIDA',99,999999);
ROLLBACK TO s;

\echo '-- B10. cuenta cuyo saldo no cuadra (esperado: viola ck_cuenta_saldo)'
SAVEPOINT s; INSERT INTO banco.cuenta (cuenta_id,nombre,tipo_predominante,n_posiciones,saldo_inicial,interes_aplicado,saldo,periodo_aplicado,job_execution_id)
 VALUES (199,'X','AHORRO',1,10000,250,99999,'2024-06',1); ROLLBACK TO s;

\echo '-- B11. monto negativo en movimiento_anual (esperado: viola ck_mov_monto)'
SAVEPOINT s; INSERT INTO banco.movimiento_anual (cuenta_id,fecha,fecha_original,formato_fecha,transaccion,transaccion_original,signo,monto,monto_original,descripcion,estado,numero_linea,job_execution_id)
 VALUES (199,'2024-01-01','x','yyyy-MM-dd','DEPOSITO','deposito',1,-500,'-500','x','VALIDA',1,1); ROLLBACK TO s;

\echo '-- B12. signo distinto de +1/-1 (esperado: viola ck_mov_signo)'
SAVEPOINT s; INSERT INTO banco.movimiento_anual (cuenta_id,fecha,fecha_original,formato_fecha,transaccion,transaccion_original,signo,monto,monto_original,descripcion,estado,numero_linea,job_execution_id)
 VALUES (199,'2024-01-01','x','yyyy-MM-dd','DEPOSITO','deposito',0,500,'500','x','VALIDA',1,1); ROLLBACK TO s;

\echo '-- B13. estado de cuenta anual cuyo saldo no cuadra (esperado: viola ck_eca_saldo)'
SAVEPOINT s; INSERT INTO banco.estado_cuenta_anual (cuenta_id,anio,n_movimientos,total_depositos,total_retiros,total_pagos,total_compras,saldo_neto,job_execution_id)
 VALUES (199,2024,1,100,0,0,0,999,1); ROLLBACK TO s;

\echo '-- B14. estrategia de escalado inventada (esperado: viola ck_metrica_estrategia)'
SAVEPOINT s; INSERT INTO banco.ejecucion_metrica (job_name,fase,estrategia,paralelismo,chunk_size,dataset_filas,repeticion,wall_clock_ms,hikari_pool_size,cpus,heap_max_mb,batch_status)
 VALUES ('jobX','F0','CUANTICO',1,200,1000,1,100,12,8,4096,'COMPLETED'); ROLLBACK TO s;

ROLLBACK;
