-- =====================================================================
-- 07 - LA TABLA COMPARATIVA, RECONSTRUIDA DESDE LA BASE
--
-- Que demuestra: que los numeros de docs/escalado.md no salen de un CSV que
-- cualquiera puede editar con el bloc de notas, sino de la propia base.
--
-- Hay DOS caminos independientes y deben coincidir:
--   A) banco.ejecucion_metrica, que escribe el propio banco de pruebas
--   B) BATCH_JOB_EXECUTION + BATCH_JOB_EXECUTION_PARAMS, que escribe
--      Spring Batch por su cuenta y nosotros no tocamos
-- Si A y B dan lo mismo, la medicion es solida.
--
--   docker exec -i bancoxyz-db psql -U banco -d bancoxyz < sql/verificacion/07-comparativa-escalado.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- A) Desde banco.ejecucion_metrica: mediana, cuartiles y CV por celda.
--
-- PERCENTILE_CONT es una funcion de "agregado ordenado": ordena los valores
-- del grupo y devuelve el que cae en el percentil pedido, interpolando entre
-- los dos vecinos si el percentil no cae justo en un valor. 0.5 es la
-- MEDIANA. Se usa mediana y no AVG porque una sola pausa del recolector de
-- basura desplazaria la media y no la mediana.
--
-- WHERE warmup = false: las rondas de calentamiento SI estan guardadas -se
-- ven quitando este filtro-, pero se excluyen del analisis. Se descartan
-- declarandolo, no borrandolo.
-- ---------------------------------------------------------------------
SELECT dataset_filas,
       fase,
       estrategia,
       paralelismo,
       chunk_size,
       COUNT(*)                                                                AS n,
       ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY wall_clock_ms)::numeric, 1) AS mediana_ms,
       ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY wall_clock_ms)::numeric, 1) AS p25_ms,
       ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY wall_clock_ms)::numeric, 1) AS p75_ms,
       -- CV% = desviacion tipica / media. Mide el RUIDO en proporcion al valor:
       -- por encima del 15% la celda no es concluyente.
       ROUND((STDDEV_SAMP(wall_clock_ms) / NULLIF(AVG(wall_clock_ms), 0) * 100)::numeric, 1) AS cv_pct,
       MAX(commit_count)                                                       AS commits,
       ROUND(AVG(skew), 3)                                                     AS skew,
       MAX(hikari_pool_size)                                                   AS pool,
       MAX(cpus)                                                               AS cpus
FROM banco.ejecucion_metrica
WHERE job_name = 'jobExperimentoTransacciones'
  AND warmup = false
  AND batch_status = 'COMPLETED'
GROUP BY dataset_filas, fase, estrategia, paralelismo, chunk_size
ORDER BY dataset_filas, fase, estrategia, paralelismo, chunk_size;


-- ---------------------------------------------------------------------
-- B) Desde los metadatos de Spring Batch, sin usar nuestra tabla.
--
-- Los JobParameters se guardaron como IDENTIFICANTES, asi que la
-- configuracion de cada corrida esta escrita en BATCH_JOB_EXECUTION_PARAMS.
-- El patron MAX(CASE WHEN ... END) es el "pivote" clasico de SQL: convierte
-- filas clave-valor en columnas.
--
-- OJO: en Spring Batch 5.x las columnas se llaman PARAMETER_NAME y
-- PARAMETER_VALUE. En 4.x eran KEY_NAME y STRING_VAL; una consulta copiada
-- de un tutorial viejo fallaria aqui.
-- ---------------------------------------------------------------------
WITH corridas AS (
    SELECT e.JOB_EXECUTION_ID,
           MAX(CASE WHEN p.PARAMETER_NAME = 'estrategia'   THEN p.PARAMETER_VALUE END) AS estrategia,
           MAX(CASE WHEN p.PARAMETER_NAME = 'paralelismo'  THEN p.PARAMETER_VALUE END)::int AS paralelismo,
           MAX(CASE WHEN p.PARAMETER_NAME = 'chunkSize'    THEN p.PARAMETER_VALUE END)::int AS chunk_size,
           MAX(CASE WHEN p.PARAMETER_NAME = 'datasetFilas' THEN p.PARAMETER_VALUE END)::int AS dataset_filas,
           MAX(CASE WHEN p.PARAMETER_NAME = 'warmup'       THEN p.PARAMETER_VALUE END) AS warmup,
           EXTRACT(EPOCH FROM (e.END_TIME - e.START_TIME)) * 1000 AS ms,
           e.STATUS
    FROM batch_meta.BATCH_JOB_EXECUTION e
    JOIN batch_meta.BATCH_JOB_EXECUTION_PARAMS p ON p.JOB_EXECUTION_ID = e.JOB_EXECUTION_ID
    JOIN batch_meta.BATCH_JOB_INSTANCE i ON i.JOB_INSTANCE_ID = e.JOB_INSTANCE_ID
    WHERE i.JOB_NAME = 'jobExperimentoTransacciones'
    GROUP BY e.JOB_EXECUTION_ID, e.START_TIME, e.END_TIME, e.STATUS
)
SELECT dataset_filas, estrategia, paralelismo, chunk_size,
       COUNT(*) AS n,
       ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY ms)::numeric, 1) AS mediana_ms
FROM corridas
WHERE warmup = 'false' AND STATUS = 'COMPLETED'
GROUP BY dataset_filas, estrategia, paralelismo, chunk_size
ORDER BY dataset_filas, estrategia, paralelismo, chunk_size;
