-- =====================================================================
-- 06 - DURACION Y DESBALANCE POR PARTICION
--
-- Que demuestra: que el particionado repartio el trabajo de verdad y en
-- cuantos trozos, cuanto tardo cada uno y cuanto se desviaron entre si.
--
-- Como se usa (sustituye el id por el de una ejecucion particionada, que
-- sale de la columna job_execution_id de results/scaling-results.csv):
--   docker exec -i bancoxyz-db psql -U banco -d bancoxyz \
--     -v id=1234 -f - < sql/verificacion/06-particiones.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- A) Una fila por particion.
--
-- STEP_NAME LIKE '%:partition%' filtra las particiones HIJAS y deja fuera
-- el step MANAGER. Es importante: Spring Batch AGREGA los contadores de las
-- hijas dentro del StepExecution del manager, asi que si no lo excluyeras
-- contarias todas las filas dos veces.
--
-- EXTRACT(EPOCH FROM intervalo) devuelve segundos como numero; multiplicado
-- por 1000 da milisegundos.
-- ---------------------------------------------------------------------
SELECT se.STEP_NAME,
       se.STATUS,
       se.READ_COUNT,
       se.WRITE_COUNT,
       se.COMMIT_COUNT,
       se.ROLLBACK_COUNT,
       se.READ_SKIP_COUNT + se.PROCESS_SKIP_COUNT + se.WRITE_SKIP_COUNT AS skips,
       ROUND(EXTRACT(EPOCH FROM (se.END_TIME - se.START_TIME)) * 1000) AS ms
FROM batch_meta.BATCH_STEP_EXECUTION se
WHERE se.JOB_EXECUTION_ID = :id
  AND se.STEP_NAME LIKE '%:partition%'
ORDER BY ms DESC;


-- ---------------------------------------------------------------------
-- B) Los dos indicadores de calidad del reparto, en una sola fila.
--
--   skew          = max(filas) / media(filas). 1.000 = reparto perfecto.
--                   Mide si a alguna particion le tocaron MAS FILAS.
--   ratio_max_min = duracion mas larga / mas corta. Mide si alguna TARDO
--                   mas, que no es lo mismo: dos particiones con las mismas
--                   filas pueden tardar distinto si una tiene mas filas
--                   sucias (cada rechazo escribe en el dead letter).
--   speedup_interno = suma de duraciones / duracion de la mas lenta. Es el
--                   speedup TEORICO del reparto, sin contar el coste de
--                   arrancar el pool ni el del manager. Comparalo con el
--                   speedup real de docs/escalado.md: la diferencia entre
--                   los dos ES el overhead.
-- ---------------------------------------------------------------------
SELECT COUNT(*)                                          AS particiones,
       SUM(se.READ_COUNT)                                AS filas_totales,
       ROUND(MAX(se.READ_COUNT) / AVG(se.READ_COUNT), 3) AS skew,
       ROUND(MAX(EXTRACT(EPOCH FROM (se.END_TIME - se.START_TIME)) * 1000)
           / NULLIF(MIN(EXTRACT(EPOCH FROM (se.END_TIME - se.START_TIME)) * 1000), 0), 3)
                                                         AS ratio_max_min,
       ROUND(SUM(EXTRACT(EPOCH FROM (se.END_TIME - se.START_TIME)) * 1000)
           / NULLIF(MAX(EXTRACT(EPOCH FROM (se.END_TIME - se.START_TIME)) * 1000), 0), 3)
                                                         AS speedup_interno
FROM batch_meta.BATCH_STEP_EXECUTION se
WHERE se.JOB_EXECUTION_ID = :id
  AND se.STEP_NAME LIKE '%:partition%';
