-- =====================================================================
-- vistas-evidencia.sql
--
-- Vistas que leen las tablas internas de Spring Batch (BATCH_*).
--
-- POR QUE VAN EN UN ARCHIVO APARTE Y NO EN schema-negocio.sql:
-- schema-negocio.sql lo ejecuta Spring ANTES de que Spring Batch cree sus
-- propias tablas. Si la vista se declarara alli, PostgreSQL fallaria con
-- "relation batch_meta.batch_job_execution does not exist" y la aplicacion
-- no arrancaria. Es un problema de ORDEN, no de permisos.
--
-- Se ejecuta UNA VEZ, despues del primer arranque de la aplicacion:
--
--   docker exec -i bancoxyz-db psql -U banco -d bancoxyz < scripts/vistas-evidencia.sql
-- =====================================================================

-- Resumen ejecutivo: una fila por ejecucion de job, con los contadores
-- que Spring Batch lleva solo. Es la evidencia mas rapida de que los jobs
-- corrieron y con que resultado.
CREATE OR REPLACE VIEW banco.v_resumen_ejecutivo AS
SELECT ji.JOB_NAME,
       je.JOB_EXECUTION_ID,
       je.STATUS,
       je.START_TIME,
       EXTRACT(EPOCH FROM (je.END_TIME - je.START_TIME)) * 1000 AS duracion_ms,
       SUM(se.READ_COUNT)   AS leidos,
       SUM(se.WRITE_COUNT)  AS escritos,
       SUM(se.FILTER_COUNT) AS filtrados,
       SUM(se.READ_SKIP_COUNT + se.PROCESS_SKIP_COUNT + se.WRITE_SKIP_COUNT) AS omitidos,
       SUM(se.COMMIT_COUNT)   AS commits,
       SUM(se.ROLLBACK_COUNT) AS rollbacks
FROM batch_meta.BATCH_JOB_EXECUTION je
JOIN batch_meta.BATCH_JOB_INSTANCE  ji USING (JOB_INSTANCE_ID)
JOIN batch_meta.BATCH_STEP_EXECUTION se USING (JOB_EXECUTION_ID)
GROUP BY ji.JOB_NAME, je.JOB_EXECUTION_ID, je.STATUS, je.START_TIME, je.END_TIME
ORDER BY je.JOB_EXECUTION_ID DESC;

-- Detalle por step: util para ver el reparto entre particiones, porque
-- cada worker aparece con el sufijo ":partitionN".
CREATE OR REPLACE VIEW banco.v_steps_ejecutados AS
SELECT ji.JOB_NAME,
       se.JOB_EXECUTION_ID,
       se.STEP_NAME,
       se.STATUS,
       EXTRACT(EPOCH FROM (se.END_TIME - se.START_TIME)) * 1000 AS duracion_ms,
       se.READ_COUNT, se.WRITE_COUNT, se.FILTER_COUNT,
       se.READ_SKIP_COUNT + se.PROCESS_SKIP_COUNT + se.WRITE_SKIP_COUNT AS omitidos,
       se.COMMIT_COUNT, se.ROLLBACK_COUNT
FROM batch_meta.BATCH_STEP_EXECUTION se
JOIN batch_meta.BATCH_JOB_EXECUTION  je USING (JOB_EXECUTION_ID)
JOIN batch_meta.BATCH_JOB_INSTANCE   ji USING (JOB_INSTANCE_ID)
ORDER BY se.JOB_EXECUTION_ID DESC, se.STEP_NAME;
