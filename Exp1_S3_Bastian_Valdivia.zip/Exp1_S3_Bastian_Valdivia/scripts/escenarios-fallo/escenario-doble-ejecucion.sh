#!/usr/bin/env bash
# =====================================================================
# ESCENARIO E16 - RELANZAMIENTO Y RECUPERACION TRAS UN FALLO
#
# Que provoca el problema:
#   Ejecutar el mismo job dos veces seguidas. EL EVALUADOR VA A HACER ESTO.
#   Sin JobParametersIncrementer, la segunda vez revienta con
#   JobInstanceAlreadyCompleteException; y sin limpieza previa, revienta con
#   DuplicateKeyException, porque el id del CSV es la PRIMARY KEY.
#
# Que debe hacer el sistema:
#   RunIdIncrementer da una JobInstance nueva en cada lanzamiento, y
#   stepPrepararTransacciones vacia la carga anterior. Las dos corridas dan
#   785 + 215 = 1000, identicas.
#
# Este script ademas mete un fallo EN MEDIO, que es la secuencia que un
# evaluador produce sin querer: romper el job y volver a lanzarlo. Comprueba
# dos cosas a la vez:
#   1. que la corrida rota no deja restos que descuadren la siguiente;
#   2. que el parametro simularFallo NO SE ARRASTRA. Se anade siempre, con
#      valor NINGUNO por defecto, justo por esto: getNextJobParameters hereda
#      los parametros de la corrida anterior, asi que si solo se anadiera
#      cuando se pide, la corrida siguiente a un fallo lo heredaria en
#      silencio y volveria a fallar pareciendo un bug de datos.
#
# Equivalente automatizado:
#   EscenariosFalloTest#trasElFalloLaSiguienteCorridaVuelveACuadrar
#   JobTransaccionesTest#sePuedeEjecutarDosVecesSeguidasSinDuplicados
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/../.."

echo "=== 1/3: corrida limpia ==="
./mvnw -q spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias

echo "=== 2/3: corrida ROTA a proposito ==="
./mvnw -q spring-boot:run \
  "-Dspring-boot.run.arguments=--job=jobTransaccionesDiarias --simular-fallo=BD_CAIDA_PERMANENTE" || true

echo "=== 3/3: corrida limpia de recuperacion ==="
./mvnw -q spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias

echo
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "
SELECT c.job_execution_id, COALESCE(p.parameter_value, '(sin parametro)') AS escenario,
       e.status, c.filas_negocio, c.filas_rechazadas, c.cuadra
FROM banco.control_carga c
JOIN batch_meta.batch_job_execution e USING (job_execution_id)
LEFT JOIN batch_meta.batch_job_execution_params p
       ON p.job_execution_id = c.job_execution_id AND p.parameter_name = 'simularFallo'
ORDER BY c.job_execution_id DESC LIMIT 3;"

echo "ESPERADO: las corridas 1 y 3 COMPLETED con 785 + 215 y cuadra=t."
echo "          La corrida rota NO aparece: murio antes del step de cuadratura."
