#!/usr/bin/env bash
# =====================================================================
# ESCENARIO E9 - CONTENCION DE BLOQUEO (deadlock / cerrojo ocupado)
#
# Que provoca el fallo:
#   simularFallo=BLOQUEO hace que InyectorFallosWriter lance una
#   CannotAcquireLockException una vez por particion. Es lo que ocurre de
#   verdad cuando dos de los cuatro hilos intentan tocar la misma fila a la vez.
#
# Que debe hacer el sistema:
#   RETRY con backoff, igual que E8, pero recorriendo OTRA rama del mapa de
#   RetryPolicies. Que E8 funcione no demuestra que esta este declarada.
#   Tambien es un fallo pasajero: el otro hilo acabara soltando el cerrojo.
#
# Como se comprueba:
#   1. "REINTENTO | ... CannotAcquireLockException" en el log
#   2. estado COMPLETED y cuadratura 1000 = 785 + 215
#
# Nota de diseno: ademas del reintento, la solucion ESTRUCTURAL en el Job 2
# sera particionar por cuenta_id, que da afinidad hilo-cuenta y hace el
# problema imposible por construccion. Reintentar es la red; particionar bien
# es la cura.
#
# Equivalente automatizado: EscenariosFalloTest#laContencionDeBloqueoSeReintenta
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/../.."

echo "=== E9: contencion de cerrojo -> debe COMPLETAR gracias al reintento ==="
./mvnw -q spring-boot:run \
  "-Dspring-boot.run.arguments=--job=jobTransaccionesDiarias --simular-fallo=BLOQUEO"

echo
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "
SELECT c.job_execution_id, e.status, c.filas_negocio, c.filas_rechazadas, c.cuadra
FROM banco.control_carga c
JOIN batch_meta.batch_job_execution e USING (job_execution_id)
ORDER BY c.job_execution_id DESC LIMIT 1;"

echo "ESPERADO: status=COMPLETED, negocio=785, rechazadas=215, cuadra=t"
