#!/usr/bin/env bash
# =====================================================================
# ESCENARIO E8-bis - LA BASE NO VUELVE: SE AGOTAN LOS REINTENTOS
#
# Que provoca el fallo:
#   simularFallo=BD_CAIDA_PERMANENTE hace que el inyector falle en TODOS los
#   intentos, no solo en el primero.
#
# Que debe hacer el sistema:
#   Gastar los 3 intentos totales (1 + 2 reintentos) con sus esperas y, al
#   agotarlos, MATAR EL STEP. Lo que NO puede hacer es omitir la fila: eso
#   convertiria "la base esta caida" en "he cargado 300 de 1000 y he terminado
#   COMPLETED", que es la peor salida posible porque nadie se entera.
#
# Como se comprueba:
#   1. "REINTENTO | TOPE ALCANZADO: 3 intento(s) gastados"
#   2. el propio Spring Batch lo declara:
#        Retry exhausted after last attempt in recovery path,
#        but exception is not skippable.
#      Las dos mitades de la doctrina en una sola frase: se agotaron los
#      reintentos Y se comprobo que la excepcion no era omitible.
#   3. estado FAILED, y NINGUNA fila en control_carga para esa ejecucion,
#      porque el job murio antes de llegar al step de cuadratura.
#
# Equivalente automatizado: EscenariosFalloTest#siLaInfraestructuraNoVuelveElJobFalla
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/../.."

echo "=== E8-bis: BD caida permanente -> el job DEBE FALLAR (esto es exito) ==="
# El "|| true" esta puesto porque el job falla A PROPOSITO: sin el, set -e
# abortaria el script antes de poder ensenar la evidencia que venimos a ver.
./mvnw -q spring-boot:run \
  "-Dspring-boot.run.arguments=--job=jobTransaccionesDiarias --simular-fallo=BD_CAIDA_PERMANENTE" || true

echo
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "
SELECT e.job_execution_id, p.parameter_value AS escenario, e.status
FROM batch_meta.batch_job_execution e
LEFT JOIN batch_meta.batch_job_execution_params p
       ON p.job_execution_id = e.job_execution_id AND p.parameter_name = 'simularFallo'
ORDER BY e.job_execution_id DESC LIMIT 1;"

echo "ESPERADO: status=FAILED con escenario=BD_CAIDA_PERMANENTE"
