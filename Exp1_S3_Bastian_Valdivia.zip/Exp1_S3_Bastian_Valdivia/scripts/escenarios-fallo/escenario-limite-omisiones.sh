#!/usr/bin/env bash
# =====================================================================
# ESCENARIO E13 - EL TECHO DE TOLERANCIA
#
# Que provoca el fallo:
#   No hace falta ningun CSV envenenado: basta con bajar el limite. La
#   propiedad banco.tolerancia.limite-omisiones (por defecto 500) se pone a 10.
#   transacciones.csv tiene 215 filas irrecuperables, unas 54 por particion,
#   asi que el limite revienta.
#
# Que debe hacer el sistema:
#   Lanzar SkipLimitExceededException y FALLAR A PROPOSITO. Tolerar sin techo
#   no es tolerancia, es negligencia: si el 90% del archivo esta mal, lo
#   correcto es parar y avisar, no cargar el 10% y declarar exito.
#
# MATIZ QUE HAY QUE DECLARAR SIEMPRE (trampa clasica del step particionado):
#   el limite es POR StepExecution, o sea POR PARTICION. Con 4 particiones y
#   limite 500, el job entero tolera hasta 2000 omisiones, no 500. Lo que de
#   verdad garantiza que no se pierde nada es la cuadratura final
#   (entrada = negocio + rechazos), no el limite de omisiones.
#
# Como se comprueba:
#   estado FAILED y SkipLimitExceededException en el log.
#
# Equivalente automatizado (unitario, sin base de datos):
#   PoliticasToleranciaTest#aplicaElTechoDeTolerancia
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/../.."

echo "=== E13: limite de omisiones a 10 con 215 filas malas -> DEBE FALLAR ==="
./mvnw -q spring-boot:run \
  "-Dspring-boot.run.arguments=--job=jobTransaccionesDiarias --banco.tolerancia.limite-omisiones=10" || true

echo
echo "ESPERADO: estado FAILED con SkipLimitExceededException."
