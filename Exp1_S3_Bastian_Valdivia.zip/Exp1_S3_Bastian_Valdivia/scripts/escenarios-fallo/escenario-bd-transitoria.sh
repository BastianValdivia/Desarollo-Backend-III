#!/usr/bin/env bash
# =====================================================================
# ESCENARIO E8 - CAIDA TRANSITORIA DE LA BASE DE DATOS
#
# Que provoca el fallo:
#   El JobParameter simularFallo=BD_TRANSITORIA llega hasta
#   InyectorFallosWriter, que envuelve al escritor real y lanza UNA vez por
#   particion una TransientDataAccessResourceException justo antes de escribir
#   un chunk. Es la excepcion que Spring usa para "la base no responde ahora".
#
# Que debe hacer el sistema:
#   RETRY, nunca skip. La politica reconoce el fallo como infraestructura,
#   espera 200 ms (backoff exponencial) y reintenta el chunk. El segundo
#   intento pasa y NO SE PIERDE NI UNA FILA.
#
# Como se comprueba (lo que hay que ver en pantalla):
#   1. lineas "REINTENTO | ... intento 1 fallido" del ReintentoRetryListener
#   2. lineas "CHUNK ROLLBACK" del ChunkErrorListener
#   3. "CUADRATURA OK en transacciones.csv: 1000 = 785 + 215 + 0"
#   4. "terminó con estado COMPLETED"
#
# Equivalente automatizado: EscenariosFalloTest#fallosTransitoriosSeReintentanYNoSePierdeNada
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/../.."

echo "=== E8: fallo transitorio de BD -> debe COMPLETAR gracias al reintento ==="
./mvnw -q spring-boot:run \
  "-Dspring-boot.run.arguments=--job=jobTransaccionesDiarias --simular-fallo=BD_TRANSITORIA"

echo
echo "--- Comprobacion en la base de datos ---"
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "
SELECT c.job_execution_id, e.status, c.filas_entrada, c.filas_negocio,
       c.filas_rechazadas, c.cuadra
FROM banco.control_carga c
JOIN batch_meta.batch_job_execution e USING (job_execution_id)
ORDER BY c.job_execution_id DESC LIMIT 1;"

echo "ESPERADO: status=COMPLETED, entrada=1000, negocio=785, rechazadas=215, cuadra=t"
