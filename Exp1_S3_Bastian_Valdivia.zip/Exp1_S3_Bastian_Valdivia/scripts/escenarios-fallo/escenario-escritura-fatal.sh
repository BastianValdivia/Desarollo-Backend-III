#!/usr/bin/env bash
# =====================================================================
# ESCENARIO E11 - FALLO NO CLASIFICADO: FAIL-FAST
#
# Que provoca el fallo:
#   simularFallo=ESCRITURA_FATAL lanza una DataIntegrityViolationException,
#   que NO esta en el mapa de reintentos NI en la lista de omitibles.
#
# Que debe hacer el sistema:
#   Fallar de inmediato. Es el caso "no se lo que es esto": la postura segura
#   por defecto es morir, porque una violacion de integridad casi siempre es un
#   BUG DEL PROGRAMADOR y no un dato sucio, y esconderla es la peor opcion.
#
#   Este escenario demuestra que las politicas DISTINGUEN. Un
#   .skip(Exception.class) o un .retry(Exception.class) perezosos se tragarian
#   esto. Es el mismo motivo por el que un "archivo no encontrado" hace fallar
#   el job en vez de terminar COMPLETED con cero filas cargadas.
#
# Como se comprueba:
#   1. estado FAILED
#   2. en el log, UN solo intento por particion (4 en total), NO tres. La
#      diferencia entre 4 y 12 es la prueba de que no se reintenta lo que no
#      esta en el mapa.
#      OJO: el contador NO se queda a cero. Spring Retry avisa del intento
#      fallido ANTES de preguntarle a la politica si cabe otro, asi que se
#      registra 1 por particion y ahi se acaba. Afirmar "cero reintentos"
#      seria afirmar de mas.
#
# Equivalente automatizado: EscenariosFalloTest#loNoClasificadoFallaRapidoYSinReintentar
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/../.."

echo "=== E11: excepcion no clasificada -> el job DEBE FALLAR sin reintentar ==="
./mvnw -q spring-boot:run \
  "-Dspring-boot.run.arguments=--job=jobTransaccionesDiarias --simular-fallo=ESCRITURA_FATAL" || true

echo
echo "ESPERADO: estado FAILED, y como mucho 1 linea REINTENTO por particion (4 en total)."
