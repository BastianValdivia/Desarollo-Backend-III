# Resultados del banco de pruebas de escalado

Generado automaticamente por EjecutorExperimentos. No editar a mano.

Entorno: cpus=8 heapMax=4040 MB jvm=25.0.2 os=Windows 11 amd64 pool=24

Protocolo: 2 rondas de calentamiento DESCARTADAS del analisis (presentes en el CSV con warmup=true) + 5 rondas medidas por celda; orden aleatorizado por rondas con semilla fija 42+ronda; TRUNCATE fuera del cronometro.

## Escala 1000 filas

| Fase | Estrategia | Paralelismo | chunk | n | Mediana (ms) | P25-P75 (ms) | IQR | CV % | Speedup | Throughput (filas/s) | COMMIT | skew | hilos |
|---|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
| F0-baseline | SECUENCIAL | 1 | 10 | 5 | 1088.0 | 1088.0-1124.0 | 36.0 | 2.6 | 0.59x | 919 | 101 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 50 | 5 | 741.0 | 736.0-743.0 | 7.0 | 2.2 | 0.86x | 1348 | 21 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 100 | 5 | 717.0 | 694.0-720.0 | 26.0 | 2.7 | 0.89x | 1395 | 11 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 500 | 5 | 639.0 | 636.0-680.0 | 44.0 | 4.8 | 1.00x | 1563 | 3 | 1.00 | 1 |
| F1-paralelo | MULTI_THREAD | 2 | 500 | 5 | 411.0 | 407.0-412.0 | 5.0 | 3.8 | 1.55x | 2431 | 5 | 1.00 | 3 |
| F1-paralelo | MULTI_THREAD | 4 | 500 | 5 | 303.0 | 272.0-304.0 | 32.0 | 10.8 | 2.11x | 3298 | 5 | 1.00 | 5 |
| F1-paralelo | MULTI_THREAD | 8 | 500 | 5 | 236.0 | 222.0-266.0 | 44.0 | 18.1 | 2.71x | 4234 | 9 | 1.00 | 9 |
| F1-paralelo | PARTICIONADO | 2 | 500 | 5 | 421.0 | 407.0-433.0 | 26.0 | 5.9 | 1.52x | 2375 | 4 | 1.00 | 2 |
| F1-paralelo | PARTICIONADO | 4 | 500 | 5 | 317.0 | 297.0-328.0 | 31.0 | 6.2 | 2.02x | 3152 | 4 | 1.00 | 4 |
| F1-paralelo | PARTICIONADO | 8 | 500 | 5 | 234.0 | 228.0-248.0 | 20.0 | 8.4 | 2.73x | 4259 | 8 | 1.00 | 8 |
| F2-confirmacion | PARTICIONADO | 8 | 100 | 5 | 266.0 | 230.0-268.0 | 38.0 | 9.7 | 2.40x | 3754 | 16 | 1.00 | 8 |
| F2-confirmacion | PARTICIONADO | 8 | 500 | 5 | 253.0 | 239.0-258.0 | 19.0 | 5.8 | 2.53x | 3946 | 8 | 1.00 | 8 |

Base de speedup declarada (unica para toda la tabla): SECUENCIAL, paralelismo=1, chunk=500, n=1000 filas, mediana 639.0 ms.

## Escala 20000 filas

| Fase | Estrategia | Paralelismo | chunk | n | Mediana (ms) | P25-P75 (ms) | IQR | CV % | Speedup | Throughput (filas/s) | COMMIT | skew | hilos |
|---|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
| F0-baseline | SECUENCIAL | 1 | 10 | 5 | 21584.0 | 21204.0-21737.0 | 533.0 | 2.9 | 0.56x | 927 | 2001 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 50 | 5 | 13810.0 | 13710.0-13868.0 | 158.0 | 3.5 | 0.87x | 1448 | 401 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 100 | 5 | 12750.0 | 12725.0-13734.0 | 1009.0 | 4.3 | 0.94x | 1569 | 201 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 500 | 5 | 12010.0 | 11996.0-12857.0 | 861.0 | 5.7 | 1.00x | 1665 | 41 | 1.00 | 1 |
| F1-paralelo | MULTI_THREAD | 2 | 500 | 5 | 7416.0 | 6680.0-9384.0 | 2704.0 | 21.2 | 1.62x | 2697 | 43 | 1.00 | 3 |
| F1-paralelo | MULTI_THREAD | 4 | 500 | 5 | 4199.0 | 4175.0-4341.0 | 166.0 | 20.3 | 2.86x | 4763 | 45 | 1.00 | 5 |
| F1-paralelo | MULTI_THREAD | 8 | 500 | 5 | 2778.0 | 2760.0-2817.0 | 57.0 | 19.9 | 4.32x | 7198 | 49 | 1.00 | 9 |
| F1-paralelo | PARTICIONADO | 2 | 500 | 5 | 6992.0 | 6648.0-7139.0 | 491.0 | 23.6 | 1.72x | 2860 | 42 | 1.00 | 2 |
| F1-paralelo | PARTICIONADO | 4 | 500 | 5 | 4237.0 | 4188.0-4248.0 | 60.0 | 22.3 | 2.83x | 4720 | 44 | 1.00 | 4 |
| F1-paralelo | PARTICIONADO | 8 | 500 | 5 | 2698.0 | 2669.0-2756.0 | 87.0 | 2.8 | 4.45x | 7411 | 48 | 1.00 | 8 |
| F2-confirmacion | PARTICIONADO | 8 | 100 | 5 | 2850.0 | 2811.0-2860.0 | 49.0 | 1.7 | 4.21x | 7015 | 208 | 1.00 | 8 |
| F2-confirmacion | PARTICIONADO | 8 | 500 | 5 | 2689.0 | 2658.0-2725.0 | 67.0 | 2.3 | 4.47x | 7438 | 48 | 1.00 | 8 |

Base de speedup declarada (unica para toda la tabla): SECUENCIAL, paralelismo=1, chunk=500, n=20000 filas, mediana 12010.0 ms.


Ejecuciones medidas descartadas por no leer todas las filas: 0
