# Banco XYZ — Migración batch con Spring Batch

Actividad sumativa **Exp1 Semana 3, Desarrollo Backend III (PBY2203)**, Duoc UC.

> **¿Qué hay en cada carpeta?** → [`CONTENIDO.md`](CONTENIDO.md)
>
> **¿Vas a ejecutarlo en otra máquina?** Empieza por
> **[`INSTALACION.md`](INSTALACION.md)** — requisitos, puesta en marcha paso a paso y los
> problemas frecuentes con su solución. Antes de nada, comprueba el entorno con:
>
> ```bash
> ./scripts/verificar-entorno.sh
> ```
>
> **¿Primera vez en este repo y quieres entenderlo desde cero?** El tutorial didáctico está en
> [`docs/tutorial-primeros-pasos.md`](docs/tutorial-primeros-pasos.md)

Todo lo que este documento afirma sobre la ejecución fue **comprobado ejecutándolo**, no
recordado. Las salidas que se citan están pegadas literalmente de la consola.

---

## 1. Objetivo del proyecto

El Banco XYZ tiene tres procesos batch **legacy**: scripts sueltos, sin control de errores,
sin reinicio y sin trazabilidad. Cuando una fila viene mal, el script o se cae entero o —peor—
la salta en silencio y nadie se entera de que el cierre contable está incompleto.

El objetivo es **migrar esos tres procesos a Spring Batch**, añadiendo lo que el legacy no
tenía: escalado por particiones, políticas explícitas de tolerancia a fallos, persistencia
transaccional en PostgreSQL y una auditoría que permita demostrar, fila a fila, qué pasó.

Los tres procesos leen un CSV de 1.000 filas **con defectos intencionales** (fechas en cuatro
formatos, montos vacíos, tipos desconocidos, filas duplicadas, tildes inconsistentes):

| # | Job | Entrada | Qué produce |
|---|---|---|---|
| 1 | `jobTransaccionesDiarias` | `transacciones.csv` | `banco.transaccion` + `banco.resumen_diario` (agregado por fecha) |
| 2 | `jobInteresesMensuales` | `intereses.csv` | `banco.interes_calculado` + `banco.cuenta` (saldos consolidados) |
| 3 | `jobEstadosCuentaAnuales` | `cuentas_anuales.csv` | `banco.movimiento_anual` + `banco.estado_cuenta_anual` + informe CSV en `results/` |

### La Regla de Oro

El requisito que gobierna todo el diseño: **`entrada = negocio + rechazos`**.

Una fila puede cargarse, marcarse como anómala o rechazarse a un *dead letter*, pero **nunca
desaparecer en silencio**. Un proceso batch que pierde filas calladamente es peor que uno que
falla, porque el fallo se ve y la pérdida no.

No es una buena intención: cada job termina con un step de cuadratura que pone el job en
**FAILED** si la cuenta no cuadra.

---

## 2. Requisitos

| Requisito | Versión | Nota |
|---|---|---|
| **JDK** | 21 o superior | Verificado con **Java 25.0.2**. El `pom.xml` fija `<java.version>21</java.version>`, así que compila contra la API 21 aunque el JDK sea más nuevo. |
| **Docker Desktop** | cualquiera reciente | **Obligatorio**, y no solo para ejecutar: también para `./mvnw test` (ver §3, Paso 3). |
| **Maven** | no hace falta instalarlo | El repo trae el wrapper `mvnw` / `mvnw.cmd`. |
| PostgreSQL | 17 | Lo levanta Docker; no se instala en la máquina. |

La base se llama `bancoxyz`, el usuario y la contraseña son ambos `banco`, y el contenedor
`bancoxyz-db` publica el puerto `5432`.

> **Declaración honesta de versiones.** Spring Boot 3.5.16 y Spring Batch 5.2.6 están en
> soporte al momento de la entrega. Java 21 es LTS. El JDK 25 usado para compilar **no** es
> LTS: se usa porque es el instalado en la máquina de desarrollo, y por eso se compila
> explícitamente contra la API 21, que sí lo es. Nada del código usa API posterior a 21.

---

## 3. Instrucciones de ejecución paso a paso

Todos los comandos se lanzan **desde la raíz del proyecto**. En Windows se usó Git Bash; en
PowerShell cambia `./mvnw` por `.\mvnw.cmd`.

### Paso 1 — Levantar la base de datos

```bash
docker compose up -d
```

Crea el contenedor `bancoxyz-db` con PostgreSQL 17 y ejecuta `docker/initdb/00-schemas.sql`,
que crea los dos esquemas: `banco` (negocio) y `batch_meta` (metadatos de Spring Batch).
Comprueba que está sano antes de seguir:

```bash
docker ps --filter name=bancoxyz-db
```

Debe decir `Up ... (healthy)`.

### Paso 2 — Compilar

```bash
./mvnw -q compile        # verificado: exit code 0
```

Para generar además el jar ejecutable (pasa los 149 tests por el camino, ~1 min):

```bash
./mvnw clean package     # produce target/banco-xyz-batch-1.0.0.jar
```

### Paso 3 — Pasar los tests

```bash
./mvnw test
```

Salida real de la última corrida:

```
[INFO] Tests run: 149, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
[INFO] Total time:  51.602 s
```

> **Docker tiene que estar encendido también aquí.** Los cinco tests de integración
> (`JobTransaccionesTest`, `JobInteresesTest`, `JobAnualesTest`, `EscenariosFalloTest`,
> `ReinicioParticionesTest`) levantan un **PostgreSQL 17 real con Testcontainers**, no una
> base en memoria. Sin Docker fallan al arrancar con `Could not find a valid Docker environment`.

### Paso 4 — Ejecutar los tres Jobs, en este orden

```bash
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobInteresesMensuales
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobEstadosCuentaAnuales
```

Si ya ejecutaste `./mvnw clean package`, el jar sirve igual y arranca más rápido (verificado,
misma cuadratura):

```bash
java -jar target/banco-xyz-batch-1.0.0.jar --job=jobTransaccionesDiarias
```

El orden importa para la evidencia consolidada, no para la corrección: cada job es
independiente e idempotente (se puede relanzar las veces que se quiera y el resultado no
cambia). Cada uno debe cerrar con dos líneas como estas —copiadas de la corrida real:

```
CUADRATURA OK en transacciones.csv:   ejecucion 1000 = 785 + 215 + 0 | contenido real 1000 = 785 + 215 (filas del fichero: 1000)
CUADRATURA OK en intereses.csv:       ejecucion 1000 = 784 + 216 + 0 | contenido real 1000 = 784 + 216 (filas del fichero: 1000)
CUADRATURA OK en cuentas_anuales.csv: ejecucion 1000 = 952 +  48 + 0 | contenido real 1000 = 952 +  48 (filas del fichero: 1000)

=== jobTransaccionesDiarias terminó con estado COMPLETED ===
=== jobInteresesMensuales terminó con estado COMPLETED ===
=== jobEstadosCuentaAnuales terminó con estado COMPLETED ===
```

Y por el camino, la prueba visual de que las particiones corren **en hilos distintos**
(fragmento literal del Job 1):

```
PARTICION termina | step=stepCargarTransaccionesWorker:partition0 | hilo=particion-1 | leidas=250 escritas=210 omitidas=40 | 556 ms
PARTICION termina | step=stepCargarTransaccionesWorker:partition2 | hilo=particion-3 | leidas=250 escritas=197 omitidas=53 | 608 ms
PARTICION termina | step=stepCargarTransaccionesWorker:partition3 | hilo=particion-4 | leidas=250 escritas=193 omitidas=57 | 631 ms
PARTICION termina | step=stepCargarTransaccionesWorker:partition1 | hilo=particion-2 | leidas=250 escritas=185 omitidas=65 | 673 ms
```

### Parámetros opcionales

| Parámetro | Por defecto | Para qué sirve |
|---|---|---|
| `--periodo=yyyy-MM` | `2024-01` | Mes a liquidar en el Job 2. Fijo a propósito: con un defecto variable, dos corridas usarían meses distintos y la prueba de idempotencia pasaría sin probar nada. |
| `--umbral=<0..1>` | `0.25` | Umbral de rechazo del *decider* del Job 1. La tasa real es 215/1000 = 0,215; con `--umbral=0.10` se fuerza la rama `CALIDAD_DEGRADADA`. |
| `--simular-fallo=<E>` | `NINGUNO` | Inyecta un fallo reproducible: `NINGUNO`, `BD_TRANSITORIA`, `BLOQUEO`, `BD_CAIDA_PERMANENTE`, `ESCRITURA_FATAL`. |
| `--banco.tolerancia.limite-omisiones=<n>` | `500` | Techo de omisiones **por partición**. Con `10` se fuerza `SkipLimitExceededException`. |

---

## 4. Verificar el resultado en la base de datos

### 4.1 La cuadratura — la consulta que prueba la Regla de Oro

```bash
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "SELECT * FROM banco.v_cuadratura"
```

Salida real:

```
       archivo       | negocio | rechazos | total
---------------------+---------+----------+-------
 transacciones.csv   |     785 |      215 |  1000
 intereses.csv       |     784 |      216 |  1000
 cuentas_anuales.csv |     952 |       48 |  1000
(3 rows)
```

### 4.2 Distribución por estado — los tres archivos en una consulta

Estos números son **contrato**, no orientativos: salen de `docs/analisis-datos.md` §6 y los
tests fallan si cambian.

```bash
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "
SELECT 'transacciones.csv' AS archivo, estado::text, count(*) FROM banco.transaccion GROUP BY estado
UNION ALL
SELECT 'intereses.csv', estado::text, count(*) FROM banco.interes_calculado GROUP BY estado
UNION ALL
SELECT 'cuentas_anuales.csv', estado::text, count(*) FROM banco.movimiento_anual GROUP BY estado
ORDER BY 1, 3 DESC;"
```

Salida real —las 14 filas coinciden exactamente con el contrato:

```
       archivo       |            estado            | count
---------------------+------------------------------+-------
 cuentas_anuales.csv | VALIDA                       |   524
 cuentas_anuales.csv | ANOMALA_MONTO_NEGATIVO       |   173
 cuentas_anuales.csv | ANOMALA_DESCRIPCION_AUSENTE  |   162
 cuentas_anuales.csv | ANOMALA_SIGNO_CONTRADICTORIO |    81
 cuentas_anuales.csv | ANOMALA_MONTO_CERO           |    12
 intereses.csv       | VALIDA                       |   303
 intereses.csv       | ANOMALA_TIPO_DESCONOCIDO     |   260
 intereses.csv       | ANOMALA_EDAD_AUSENTE         |   101
 intereses.csv       | ANOMALA_EDAD_FUERA_RANGO     |    96
 intereses.csv       | ANOMALA_NOMBRE_DESCONOCIDO   |    24
 transacciones.csv   | VALIDA                       |   401
 transacciones.csv   | ANOMALA_TIPO_DESCONOCIDO     |   230
 transacciones.csv   | ANOMALA_MONTO_NEGATIVO       |   136
 transacciones.csv   | ANOMALA_MONTO_CERO           |    18
(14 rows)
```

Suma por archivo: 785, 784 y 952 — el lado "negocio" de la cuadratura.

### 4.3 El dead letter, por motivo y por fase

```bash
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "
SELECT archivo_origen, motivo, fase, count(*)
FROM banco.registro_rechazado
GROUP BY archivo_origen, motivo, fase
ORDER BY archivo_origen, count(*) DESC;"
```

Salida real:

```
   archivo_origen    |     motivo     |  fase   | count
---------------------+----------------+---------+-------
 cuentas_anuales.csv | MONTO_AUSENTE  | PROCESS |    48
 intereses.csv       | SALDO_AUSENTE  | PROCESS |   211
 intereses.csv       | DUPLICADO      | WRITE   |     5
 transacciones.csv   | MONTO_AUSENTE  | PROCESS |   160
 transacciones.csv   | FECHA_INVALIDA | PROCESS |    55
(5 rows)
```

Suma por archivo: 215, 216 y 48 — el lado "rechazos". La columna `fase` no es decorativa:
dice **dónde** murió la fila. Los `DUPLICADO` aparecen en `WRITE` porque solo la restricción
única de la base puede detectarlos; el resto se detecta en `PROCESS`, antes de tocar la base.

> **Estado excluyente vs. columna `anomalias`.** El `estado` nombra **una sola** anomalía, la
> de mayor precedencia:
> `fecha inválida > monto/saldo ausente > no numérico > duplicado > monto negativo > monto cero > tipo desconocido > resto`.
> La columna `anomalias` guarda **todas**, separadas por coma, para no perder información.
> Por eso los conteos por `estado` suman exacto y no se solapan.

---

## 5. Estructura del código

```
banco-xyz-batch/
├── pom.xml                     Spring Boot 3.5.16 · Spring Batch 5.2.6 · API Java 21
├── compose.yaml                PostgreSQL 17 para desarrollo local
├── docker/initdb/              Los 2 esquemas, creados al primer arranque de la BD
├── docs/                       Documentación (índice en §8)
├── scripts/                    Escenarios de fallo, perfilado y auditoría del esquema
├── scripts/consultas-sql/           Consultas de verificación con su salida capturada
├── results/                    Salidas del benchmark y los informes CSV del Job 3
├── evidencias/                 Evidencia indexada por criterio (INDICE.md)
└── src/
    ├── main/java/cl/duoc/bancoxyz/
    │   ├── config/             Cableado de los 3 Jobs + pool de hilos + políticas
    │   ├── domain/             Entidades *Raw (crudo) y normalizadas + enums de estado
    │   ├── partition/          Particionadores: por rango de líneas y por rango de cuenta
    │   ├── reader/             Lector que filtra por rango de cuenta
    │   ├── processor/          La lógica de negocio de cada job
    │   ├── policy/             Políticas de skip / retry / backoff
    │   ├── listener/           Dead letter y listeners de auditoría
    │   ├── tasklet/            Steps no-chunk: limpieza, consolidación, validaciones
    │   ├── support/            Normalizadores, DAO de cuadratura, inyector de fallos
    │   ├── experiment/         Banco de pruebas de escalado (criterio 4)
    │   └── LanzadorJobs.java   Punto de entrada: elige el job con --job=
    └── main/resources/
        ├── data/               Los 3 CSV del enunciado
        └── schema-negocio.sql  9 tablas + 4 vistas
```

### 5.1 Componente de Spring Batch → clase de este proyecto

La tabla que permite señalar cada pieza del framework en el código. Donde los tres jobs no
coinciden, se dice job por job en vez de fingir uniformidad.

| Componente Spring Batch | Job 1 · Transacciones | Job 2 · Intereses | Job 3 · Anuales |
|---|---|---|---|
| **`Job`** | `jobTransaccionesDiarias`<br>(`TransaccionesJobConfig`) | `jobInteresesMensuales`<br>(`InteresesJobConfig`) | `jobEstadosCuentaAnuales`<br>(`AnualesJobConfig`) |
| **`Step` manager** (`PartitionStep`) | `stepCargarTransaccionesManager` | `stepCalcularInteresesManager` | `stepCargarMovimientosManager` |
| **`Step` worker** (chunk) | `stepCargarTransaccionesWorker` | `stepCalcularInteresesWorker` | `stepCargarMovimientosWorker` |
| **`Partitioner`** | `LineRangePartitioner`<br>(por rango de líneas) | `RangoCuentaPartitioner`<br>(por rango de `cuenta_id`) | `RangoCuentaPartitioner` |
| **`PartitionHandler`** | *implícito* — no hay bean propio: `PartitionStepBuilder` construye internamente un `TaskExecutorPartitionHandler` a partir de `.step()`, `.gridSize()` y `.taskExecutor()` | ídem | ídem |
| **`TaskExecutor`** | `poolParticiones` (`ThreadPoolTaskExecutor`, `TaskExecutorConfig`) — **4 hilos daemon**, compartido por los tres jobs | ídem | ídem |
| **`gridSize`** | 4 | 5 (ver limitación §7.1) | 4 |
| **`ItemReader`** | `FlatFileItemReader<TransaccionRaw>` | `FiltroRangoCuentaReader<InteresRaw>` | `FiltroRangoCuentaReader<MovimientoAnualRaw>`<br>+ `JdbcCursorItemReader<EstadoCuentaAnual>` (step de informe) |
| **`ItemProcessor`** | `TransaccionProcessor` | `InteresProcessor` | `MovimientoAnualProcessor` |
| **`ItemWriter`** | `JdbcBatchItemWriter<Transaccion>`,<br>envuelto por `InyectorFallosWriter` | `JdbcBatchItemWriter<InteresCalculado>` | `JdbcBatchItemWriter<MovimientoAnual>`<br>+ `FlatFileItemWriter<EstadoCuentaAnual>` (informe CSV) |
| **`chunkSize`** | 200 | 50 | 200 |
| **`SkipPolicy`** | `BancoXyzSkipPolicy` (límite 500 **por partición**, configurable) | ídem | ídem |
| **`RetryPolicy`** | `RetryPolicies.infraestructura()` — `SimpleRetryPolicy`, 3 intentos, mapa de excepciones | ídem | **ninguna, a propósito** (§6.8) |
| **`BackOffPolicy`** | `BackOffPolicies.exponencial()` — 200 ms, ×2, tope 5 s | ídem | **ninguna** (§6.8) |
| **`SkipListener`** | `RechazoListener` — el dead letter, con la fase `READ`/`PROCESS`/`WRITE` | ídem | ídem |
| **`RetryListener`** | `ReintentoRetryListener` | ídem | — |
| **`ChunkListener`** | `ChunkErrorListener` — deja constancia de cada rollback | ídem | ídem |
| **`StepExecutionListener`** | `ParticionListener` — imprime hilo, leídas, escritas, omitidas | ídem | ídem |
| **`JobExecutionDecider`** | `DeciderCalidadDatos` — bifurca por tasa de rechazo | — | — |
| **`JobRepository`** | autoconfigurado por Spring Boot sobre las 6 tablas `BATCH_*` del esquema `batch_meta` | ídem | ídem |
| **`Tasklet`** | `LimpiezaTasklet`, `AlertaCalidadTasklet`, `ResumenDiarioTasklet`, `CuadraturaTasklet` | `LimpiezaInteresesTasklet`, `ConsolidarSaldosTasklet`, `CuadraturaTasklet`, `ValidarConsolidadoInteresesTasklet` | `PrepararAnualesTasklet`, `GenerarEstadosCuentaTasklet`, `CuadraturaTasklet`, `ValidarConsolidadoAnualTasklet` |

### 5.2 Flujo de cada Job

```
Job 1  stepPrepararTransacciones
       -> stepCargarTransaccionesManager  (4 workers en paralelo)
       -> deciderCalidadDatos ---- CALIDAD_DEGRADADA --> stepAlertaCalidad --.
                              \--- * -----------------------------------------> stepResumenDiario
       -> stepValidarCuadraturaTransacciones

Job 2  stepPrepararIntereses
       -> stepCalcularInteresesManager    (5 particiones sobre 4 hilos)
       -> stepConsolidarSaldos
       -> stepValidarCuadraturaIntereses
       -> stepValidarConsolidadoIntereses

Job 3  stepPrepararAnuales
       -> stepCargarMovimientosManager    (4 workers en paralelo)
       -> stepGenerarEstadosCuenta
       -> stepExportarEstadosCuenta       (informe CSV en results/)
       -> stepValidarCuadraturaAnuales
       -> stepValidarConsolidadoAnual
```

Los tres jobs entran a la fase de carga por su step **manager**, nunca directamente por el
worker. El step de preparación previo no contradice esa regla: no carga nada, solo limpia.

### 5.3 Responsabilidades, clase por clase

| Clase | Responsabilidad |
|---|---|
| `LanzadorJobs` | Punto de entrada. Traduce `--job` / `--periodo` / `--umbral` / `--simular-fallo` a `JobParameters`. |
| `LineRangePartitioner` | Reparte un CSV en N rangos de líneas vía `linesToSkip` / `maxItemCount`. Falla ruidosamente si el fichero no trae filas. |
| `RangoCuentaPartitioner` | Reparte por rangos de `cuenta_id` (101–150 en el Job 2, 101–120 en el Job 3). **La misma función decide el reparto y el filtrado**, así no pueden desincronizarse y dejar filas huérfanas. |
| `FiltroRangoCuentaReader` | Lector que se queda solo con las filas de su tramo de cuentas. |
| `TransaccionProcessor`<br>`InteresProcessor`<br>`MovimientoAnualProcessor` | Normalización, clasificación por precedencia y cálculo. Es donde vive el negocio. |
| `Normalizador{Fecha,Monto,Texto}` | Los 4 formatos de fecha, montos con basura alrededor, canonización de tildes y mayúsculas. |
| `BancoXyzSkipPolicy` | Decide *dato sucio* (omitir y registrar) vs *infraestructura* (matar el step). |
| `RetryPolicies` / `BackOffPolicies` | Qué se reintenta, cuántas veces (3) y con qué espera (200 ms, ×2, tope 5 s). |
| `RechazoListener` | El dead letter, con la fase (`READ`/`PROCESS`/`WRITE`) en que cayó la fila. Escribe en transacción propia para sobrevivir al rollback del chunk. |
| `ParticionListener` / `ChunkErrorListener` / `ReintentoRetryListener` | Auditoría: hilos, rollbacks y reintentos visibles en el log. |
| `LimpiezaTasklet`<br>`LimpiezaInteresesTasklet`<br>`PrepararAnualesTasklet` | Idempotencia: dejan la base como estaba antes de recargar. |
| `ConsolidarSaldosTasklet`<br>`GenerarEstadosCuentaTasklet` | Las agregaciones (`GROUP BY`), hechas en SQL y no en Java. |
| `CuadraturaTasklet` | **La defensa de la Regla de Oro.** Tres comprobaciones; hace `FAILED` el job si falla alguna. |
| `ValidarConsolidadoInteresesTasklet`<br>`ValidarConsolidadoAnualTasklet` | Que el agregado sea reconstruible desde el detalle. |
| `DeciderCalidadDatos` / `AlertaCalidadTasklet` | Bifurcación del flujo por tasa de rechazo. |
| `ControlCargaDao` | Único origen de verdad de los contadores de cuadratura. |
| `InyectorFallosWriter` | Inyecta fallos reproducibles para los escenarios del criterio 5. |
| `experiment/` (16 clases) | Banco de pruebas de escalado: matriz, ejecutor, métricas y análisis. |

---

## 6. Decisiones de diseño y su porqué

### 6.1 PostgreSQL, y no una base embebida

Spring Batch necesita un `JobRepository` **transaccional** para poder reiniciar un job donde
se quedó. Con una base en memoria, los metadatos mueren con el proceso: el reinicio deja de
existir como concepto, y con él la mitad del criterio de tolerancia a fallos. Además el
proyecto usa cosas que solo una base real tiene: `TIMESTAMPTZ`, `GENERATED ALWAYS AS ... STORED`,
`ON CONFLICT`, `count(*) FILTER (WHERE ...)` y restricciones únicas parciales. PostgreSQL 17
en Docker da todo eso sin instalar nada en la máquina.

### 6.2 `NUMERIC(15,2)` y `BigDecimal`, nunca `float`/`double`

Un `double` no puede representar 0,10 de forma exacta: lo guarda como 0,1000000000000000055…
Sumar diez veces 0,10 da 0,9999999999999999, y un cierre contable que descuadra por un céntimo
es un cierre que no se puede firmar. `NUMERIC` en la base y `BigDecimal` en Java son
**decimales exactos**: no aproximan, y el redondeo ocurre cuando uno lo pide y como uno lo
pide (`HALF_UP`), no cuando al hardware le apetece. Regla general: **dinero jamás en coma
flotante binaria**.

### 6.3 Se conserva siempre el valor original

Cada tabla de negocio guarda el valor crudo junto al normalizado, y el dead letter guarda la
**línea entera** tal como venía (`linea_cruda`). El motivo es de auditoría: una normalización
es una interpretación, y las interpretaciones a veces están mal. Si mañana se descubre que un
quinto formato de fecha se estaba leyendo al revés, con el original guardado se puede
reprocesar; sin él, el dato está perdido para siempre y solo queda volver al fichero fuente
—suponiendo que todavía exista—. Es la misma razón por la que la columna `anomalias` guarda
todas las anomalías y no solo la de mayor precedencia.

### 6.4 Particiones, y no multi-thread simple

El benchmark (§8) dice que en velocidad **empatan**: 4,32× para `MULTI_THREAD` contra 4,47×
para `PARTICIONADO`, con rangos que se solapan. La partición se elige por **corrección
concurrente**, no por rapidez:

- Cada partición tiene su **propio `StepExecution`**, con sus propios contadores y su propio
  `ExecutionContext`. Eso hace que el reinicio funcione a nivel de partición y que la
  auditoría diga qué hizo cada hilo.
- En los Jobs 2 y 3 la partición es **por rango de cuenta**, lo que da afinidad hilo↔cuenta:
  dos hilos no tocan nunca la misma cuenta, y el deadlock por actualización cruzada de saldos
  se vuelve imposible **por construcción**, no por suerte de planificación.
- `MULTI_THREAD` obliga a que reader y writer sean *thread-safe*; con `FlatFileItemReader`
  eso significa sincronizarlo, y el lector se convierte en el cuello de botella.

### 6.5 Esquema `batch_meta` separado de `banco`

Las 6 tablas `BATCH_*` son **infraestructura del framework**, no datos del banco. Mezclarlas
con las 9 tablas de negocio tiene tres costes concretos: un `\dt` deja de ser legible, un
`GRANT` sobre el esquema de negocio le regala al usuario de reporting los metadatos de
ejecución, y un `DROP SCHEMA banco CASCADE` para recargar de cero se llevaría por delante el
historial de ejecuciones. Con esquemas separados se puede vaciar el negocio sin perder la
trazabilidad, y al revés.

### 6.6 Testcontainers, y no H2

H2 tiene un "modo PostgreSQL", pero **imita el dialecto, no el motor**. En cuanto el esquema
usa `GENERATED ALWAYS AS ... STORED`, `TIMESTAMPTZ`, `ON CONFLICT` o `FILTER (WHERE ...)`, la
imitación se rompe. Y el fallo peor no es que reviente, es que **pase**: un test verde contra
un motor distinto del de producción da falsa seguridad, que es peor que no tener test. Con
Testcontainers, `./mvnw test` levanta un PostgreSQL 17 **real** en Docker, corre contra el
mismo esquema que producción y lo apaga al terminar. El precio es honesto y está declarado:
los tests **exigen Docker** y tardan 51,6 s medidos, en vez de los pocos segundos que costaría
una base en memoria.

*(La dependencia de H2 sigue en el `pom.xml` por si hiciera falta una prueba de humo sin
Docker, pero hoy ningún test la usa.)*

### 6.7 Dead letter con la fase, en transacción propia

`RechazoListener` escribe cada rechazo en una **transacción independiente**. Si escribiera en
la del chunk, el rollback que provoca la fila mala se llevaría también el registro de que esa
fila existió: se perdería justo la evidencia que se quiere conservar. Guardar además la fase
(`READ`/`PROCESS`/`WRITE`) es lo que permite afirmar, en §4.3, que los duplicados solo pueden
detectarse en la escritura.

### 6.8 El Job 3 no lleva `RetryPolicy` ni `BackOffPolicy`

Es deliberado, no un olvido. El reintento sirve para fallos de **infraestructura durante la
escritura**: la base parpadea, se reintenta, se recupera. Pero en el Job 3 los 48 rechazos son
todos de fase `PROCESS` —lo demuestra la salida de §4.3, `cuentas_anuales.csv | MONTO_AUSENTE
| PROCESS | 48`—, es decir, los detecta el `ItemProcessor` **antes de tocar la base**. Un
reintento sobre un dato que está mal no lo arregla: lo vuelve a intentar y vuelve a fallar,
tres veces más lento.

Añadir una política que nunca se dispara no sería gratis: importaría la trampa de ordenación
del builder que documenta `InteresesJobConfig` (encadenar `.listener(...)` cambia el tipo
devuelto y hace que el `RetryListener` se registre contra `listener(Object)`, en silencio y
sin efecto) a cambio de cero beneficio. Si el Job 3 empezara a sufrir fallos de red, se
añadiría entonces, copiando el patrón del Job 2. **Configurar solo lo que hace falta también
es una decisión de diseño.**

---

## 7. Limitaciones conocidas

Dichas sin adornos. Un informe que solo tiene virtudes no es un informe.

### 7.1 El Job 2 declara 5 particiones sobre un pool de 4 hilos

`InteresesJobConfig.PARTICIONES = 5`, pero `poolParticiones` tiene `corePoolSize = maxPoolSize = 4`.
La quinta partición **no corre en paralelo**: espera en la cola a que se libere un hilo. Se ve
en el log real de la corrida, donde el hilo `particion-4` ejecuta dos particiones seguidas:

```
PARTICION termina | step=stepCalcularInteresesWorker:partition4 | hilo=particion-4 | ... | 429 ms
PARTICION termina | step=stepCalcularInteresesWorker:partition2 | hilo=particion-4 | ... | 303 ms
```

Es correcto (ninguna fila se pierde y la cuadratura da 784+216) pero **no es "5 workers en
paralelo"**: son 5 particiones sobre 4 hilos. El reparto por rango de cuenta impone un número
natural de tramos que no tiene por qué coincidir con el tamaño del pool. Se deja así, y
documentado, en vez de retocar el pool solo para que la cifra quede bonita.

### 7.2 Particionar un fichero plano cuesta O(n·p)

`LineRangePartitioner` reparte dando a cada worker un `linesToSkip` y un `maxItemCount`. Pero
un `FlatFileItemReader` **no sabe saltar**: para descartar sus `linesToSkip` primeras líneas
tiene que **leerlas y tirarlas**. Con p particiones sobre n líneas, el coste total de lectura
es O(n·p), no O(n): la última partición lee el fichero casi entero antes de procesar su primera
fila. A 1.000 líneas no se nota; a decenas de millones sería el cuello de botella. La solución
real es partir el fichero en trozos físicos, o partir por una clave como hacen los Jobs 2 y 3.

### 7.3 A 1.000 filas, el paralelismo no compensa

Con el dataset del enunciado, cada partición del Job 1 tarda entre 556 y 673 ms, y buena parte
es arranque de contexto, no trabajo útil. El coste fijo de repartir, crear `StepExecution`s y
coordinar hilos se come la ganancia. **El paralelismo aquí está para demostrarlo, no porque a
esta escala rinda.** Por eso el benchmark del criterio 4 usa un dataset amplificado ×20: es la
escala en la que la diferencia deja de ser ruido.

### 7.4 `skipLimit` es por partición, no por job

Con 4 particiones y límite 500, el job entero tolera hasta **2.000** omisiones, no 500. Es
cómo funciona Spring Batch (el contador vive en el `StepExecution`), no un error de
configuración, pero es una trampa clásica al leer la cifra. Lo que de verdad garantiza que no
se perdió nada no es ese número: es la **cuadratura final**.

### 7.5 El benchmark mide una sola máquina

Las cifras de §8 son de un portátil concreto, con Docker y el JDK compartiendo CPU con el
sistema. Los *speedups* relativos son sólidos (misma máquina, orden aleatorizado, 5 rondas
medidas y 2 de calentamiento descartadas), pero los tiempos absolutos no son transferibles.
En otra máquina cambiarían; el óptimo declarado (`PARTICIONADO`, 8, 500) probablemente no.

### 7.6 Alcance no cubierto

- **Escalado remoto** (*remote partitioning* / *remote chunking*) no está implementado: haría
  falta un middleware de mensajería, fuera del alcance de la actividad. Se declara en
  `docs/tolerancia-fallos.md` en vez de insinuar que existe.
- **El repositorio remoto está por detrás del árbol de trabajo** (ver §10).

---

## 8. Escalado (criterio 4)

Banco de pruebas: **2 escalas × 12 configuraciones × 5 rondas medidas**, con 2 rondas de
calentamiento descartadas y orden aleatorizado con semilla fija. Detalle completo en
[`docs/escalado.md`](docs/escalado.md); datos crudos en
[`results/scaling-results.csv`](results/scaling-results.csv).

### Resumen — escala 20.000 filas

| Estrategia | Paralelismo | chunk | Mediana (ms) | CV % | Speedup | Throughput (filas/s) |
|---|---:|---:|---:|---:|---:|---:|
| `SECUENCIAL` | 1 | 10 | 21.584 | 2,9 | 0,56× | 927 |
| `SECUENCIAL` | 1 | 100 | 12.750 | 4,3 | 0,94× | 1.569 |
| `SECUENCIAL` | 1 | 500 | 12.010 | 5,7 | **1,00× (base)** | 1.665 |
| `MULTI_THREAD` | 4 | 500 | 4.199 | 20,3 | 2,86× | 4.763 |
| `MULTI_THREAD` | 8 | 500 | 2.778 | 19,9 | 4,32× | 7.198 |
| `PARTICIONADO` | 4 | 500 | 4.237 | 22,3 | 2,83× | 4.720 |
| **`PARTICIONADO`** | **8** | **500** | **2.689** | **2,3** | **4,47×** | **7.438** |
| `PARTICIONADO` | 8 | 100 | 2.850 | 1,7 | 4,21× | 7.015 |

**Óptimo declarado: `PARTICIONADO`, `gridSize=8`, `chunkSize=500`** — 4,47× sobre el mejor
secuencial y, además, el **CV más bajo** (2,3 %) de todas las configuraciones paralelas: el
más rápido *y* el más estable. Dos hallazgos que conviene subrayar:

- **El `chunkSize` pesa más que la estrategia.** Pasar de `chunk=10` a `chunk=500` en
  secuencial ya da 1,8× *sin tocar la arquitectura*. Antes de paralelizar, ajusta el chunk.
- **`MULTI_THREAD` y `PARTICIONADO` empatan en velocidad.** Se elige `PARTICIONADO` por las
  razones de corrección de §6.4, no por rapidez.

> **Declaración obligatoria — dataset amplificado.** La escala de 20.000 filas **no** es dato
> del enunciado: se genera con `AmplificadorDataset` (`data/generated/`, ×20, determinista,
> preserva exactamente las proporciones de defectos —
> `20.000 = 15.700 + 4.300` = 20 × (785 + 215)). Los CSV originales no se tocan. Las siete
> reglas de legitimidad están en [`docs/escalado.md`](docs/escalado.md) §9.

---

## 9. Tolerancia a fallos (criterio 5)

16 escenarios catalogados en [`docs/tolerancia-fallos.md`](docs/tolerancia-fallos.md):
**14 demostrados**, 1 cubierto por diseño, 1 declarado como no implementado.

La doctrina en una línea: **dato sucio → `skip` + dead letter · infraestructura → `retry`,
nunca `skip`**. Tragarse un fallo de infraestructura haría que el job "termine bien" con cero
filas cargadas, que es la peor forma posible de fallar.

| # | Escenario | Cómo reproducirlo | Resultado esperado |
|---|---|---|---|
| E8 | Caída **transitoria** de la BD | `bash scripts/escenarios-fallo/escenario-bd-transitoria.sh` | RETRY (200 ms, ×2), se recupera, `COMPLETED` 785+215 |
| E9 | Contención de **bloqueo** | `bash scripts/escenarios-fallo/escenario-bloqueo.sh` | RETRY por otra rama del mapa, `COMPLETED` 785+215 |
| E11 | La BD **no vuelve** | `bash scripts/escenarios-fallo/escenario-bd-caida.sh` | Agota 3 intentos, `FAILED`. No se omite ni una fila buena |
| E12 | Error **fatal** de escritura | `bash scripts/escenarios-fallo/escenario-escritura-fatal.sh` | Ni retry ni skip: fail-fast, `FAILED` |
| E13 | **Techo de omisiones** superado | `bash scripts/escenarios-fallo/escenario-limite-omisiones.sh` | `SkipLimitExceededException`, `FAILED` a propósito |
| E16 | **Doble ejecución** y reinicio tras fallo | `bash scripts/escenarios-fallo/escenario-doble-ejecucion.sh` | 1.ª `COMPLETED`, 2.ª `FAILED`, 3.ª **reinicia** y vuelve a 785+215 |

Logs de las seis corridas: [`evidencias/05-fallos/`](evidencias/05-fallos/).

---

## 10. Reproducir las evidencias

```bash
# Benchmark de escalado completo (perfil dedicado; tarda varios minutos)
./mvnw spring-boot:run -Dspring-boot.run.profiles=experiment

# Los seis escenarios de fallo
for s in bd-transitoria bloqueo bd-caida escritura-fatal limite-omisiones doble-ejecucion; do
  bash scripts/escenarios-fallo/escenario-$s.sh > evidencias/05-fallos/$s/log.txt 2>&1
done

# Auditoría del esquema: 5 inserciones legítimas + 14 pruebas negativas.
# Cada B1..B14 debe imprimir el ERROR de SU restricción. Termina en ROLLBACK.
docker exec -i bancoxyz-db psql -U banco -d bancoxyz < scripts/consultas-sql/auditar-esquema.sql

# Perfilado del dataset: recalcula los números esperados desde los CSV
bash scripts/perfilar-dataset.sh

# Consultas de verificación (salidas ya capturadas en evidencias/02-bd/)
ls scripts/consultas-sql/
```

### Estado del versionado — leer antes de clonar

**Este árbol de trabajo todavía no está publicado.** Lo que describe este README (los 3 Jobs,
el particionado, el banco de pruebas de escalado, los escenarios de fallo, `evidencias/`) vive
**en el directorio del proyecto**, que tiene **76 ficheros `.java`**; la rama remota solo tiene
**14** y un único Job sin particionar. Comprobado:

```bash
git ls-tree -r origin/claude/trabajo-a-estudiar-y4gj3t --name-only | grep -c '\.java$'   # -> 14
find src -name "*.java" ! -name "*.bak*" | wc -l                                          # -> 76
```

Por tanto: **evalúa este directorio (o el ZIP de la entrega) directamente.** Un `git clone` no
reproduce todavía lo que aquí se documenta. Para que lo haga hay que commitear y hacer push del
trabajo pendiente.

---

## 11. Índice de documentación y evidencias

### Documentación — orden de lectura sugerido

| # | Documento | Para qué sirve |
|---|---|---|
| 1 | [`docs/tutorial-primeros-pasos.md`](docs/tutorial-primeros-pasos.md) | Instalar Java, VS Code y Docker desde cero. Empieza aquí si nunca has usado Java. |
| 2 | [`docs/enunciado/RESUMEN.md`](docs/enunciado/RESUMEN.md) | Qué pide la actividad y la pauta de evaluación, en corto. |
| 3 | [`docs/analisis-datos.md`](docs/analisis-datos.md) | Perfilado real de los 3 CSV. La §6 tiene los números esperados. |
| 4 | [`docs/guia-didactica.md`](docs/guia-didactica.md) | Modelo mental de Spring Batch: particiones vs multi-thread, retry vs skip. |
| 5 | [`docs/escalado.md`](docs/escalado.md) | Criterio 4: protocolo, tablas comparativas, Amdahl y el óptimo con sus condiciones. |
| 6 | [`docs/tolerancia-fallos.md`](docs/tolerancia-fallos.md) | Criterio 5: los 16 escenarios y cómo reproducir cada uno. |
| 7 | [`docs/plan-maestro.md`](docs/plan-maestro.md) | El mapeo exhaustivo criterio → entregable → evidencia. |
| 8 | [`docs/referencia-tecnica/`](docs/referencia-tecnica/) | 5 documentos de API de Spring Batch 5.2.6 verificados. Consulta puntual. |

### Evidencias — por criterio de la pauta

Índice completo y navegable: [`evidencias/INDICE.md`](evidencias/INDICE.md).

| Criterio | Evidencia |
|---|---|
| 1 — Arquitectura (Jobs/Steps) | [`evidencias/02-ejecucion/job1-detalle-bd.txt`](evidencias/02-ejecucion/job1-detalle-bd.txt) · [`02-job2`](evidencias/02-ejecucion/job2-detalle-bd.txt) · [`02-job3`](evidencias/02-ejecucion/job3-detalle-bd.txt) |
| 2 — Ejecución y salida en BD | [`evidencias/02-bd/`](evidencias/02-bd/) — una captura por tabla + las 3 consultas de `scripts/consultas-sql/` |
| 3 — Transformaciones en el `ItemProcessor` | Distribución por estado (§4.2) + tests de los 3 processors |
| 4 — Escalado | [`evidencias/04-escalado/`](evidencias/04-escalado/) · [`results/scaling-results.csv`](results/scaling-results.csv) · [`docs/escalado.md`](docs/escalado.md) |
| 5 — Tolerancia a fallos | [`evidencias/05-fallos/`](evidencias/05-fallos/) — log de cada escenario |
| 6 — Análisis y justificación | [`docs/escalado.md`](docs/escalado.md) + decisiones de diseño (§6) + limitaciones (§7) |
| 7 — Código, documentación y evidencia | Este README + [`evidencias/INDICE.md`](evidencias/INDICE.md) |

---

## 12. Estado del proyecto

- [x] Proyecto Maven (Spring Boot 3.5.16 + Spring Batch 5.2.6 + API Java 21)
- [x] PostgreSQL 17 en Docker: 9 tablas de negocio + 4 vistas + metadatos en `batch_meta`
- [x] **Job 1 — Transacciones diarias**, particionado (manager + 4 workers), con decider,
      resumen diario y cuadratura. **785 + 215 = 1000**
- [x] **Job 2 — Intereses mensuales**, particionado por cuenta (manager + 5 particiones sobre
      4 hilos, ver §7.1), con consolidación idempotente y validación. **784 + 216 = 1000**
- [x] **Job 3 — Estados de cuenta anuales**, particionado por cuenta (manager + 4 workers),
      con consolidación, informe CSV y validación. **952 + 48 = 1000**
- [x] Escalado: 2 escalas × 12 configuraciones × 5 rondas, con óptimo declarado
- [x] Tolerancia a fallos: 14 de 16 escenarios demostrados con script o test
- [x] Tests: **149**, todos verdes, incluidos 5 de integración con Testcontainers
- [x] Evidencia organizada por criterio en `evidencias/INDICE.md`
- [ ] Publicación en el repositorio remoto (ver §10)

## Datos

Los CSV están en `src/main/resources/data/`, tomados de
[KariVillagran/bank_legacy_data](https://github.com/KariVillagran/bank_legacy_data), carpeta
`data/semana_3` (1.000 filas por archivo, con defectos intencionales). El detalle de cada
defecto está en [`docs/analisis-datos.md`](docs/analisis-datos.md).
