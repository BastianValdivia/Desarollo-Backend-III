# Tutorial — de cero a tener el Job 1 corriendo

Para alguien que nunca ha escrito Java. Si vienes de Python/PySpark, los recuadros
**"En Python esto sería…"** te van a servir de puente.

Al terminar este tutorial vas a tener el Job 1 procesando 1.000 transacciones y
escribiendo en PostgreSQL. Toma entre 40 y 60 minutos, casi todo esperando descargas.

---

## Paso 0 — Qué es cada cosa

Antes de instalar, cinco definiciones para que sepas qué estás haciendo:

| Cosa | Qué es | Equivalente en tu mundo |
|---|---|---|
| **Java** | El lenguaje y su máquina virtual (JVM). Hay que instalarlo. | El intérprete de Python |
| **Maven** | Gestor de dependencias y de compilación. **No hay que instalarlo**: el proyecto trae `mvnw`, que se descarga solo. | `pip` + `venv` + un poco de `make` |
| **Spring Boot** | Un framework de Java. **No se instala**: es una librería que Maven descarga sola en la primera compilación. | Como `pandas` — se declara y se baja |
| **Spring Batch** | El módulo de Spring para procesos por lotes. Es lo que estamos usando. | Airflow + PySpark, muy resumido |
| **Docker** | Levanta PostgreSQL sin instalarlo en tu máquina. Ya lo tienes. | Igual que lo usas hoy |

> **Aclaración importante:** Spring Boot **no tiene nada que ver con JavaScript**. Java y
> JavaScript son lenguajes distintos que sólo comparten parte del nombre, por una decisión
> de marketing de los años 90. Spring Boot es el framework de backend más usado en Java.

---

## Paso 1 — ¿Tienes Java?

Abre una terminal:

- **Windows**: tecla Windows → escribe `PowerShell` → Enter
- **macOS**: `Cmd + Espacio` → escribe `Terminal` → Enter

Escribe:

```
java -version
```

**Si responde** `openjdk version "21.x"` o superior → ya está, salta al Paso 2.

**Si dice** `no se reconoce como un comando` o `command not found` → no lo tienes.

**Si dice una versión menor a 21** (17, 11, 8) → instala la 21 igual, conviven sin problema.

### Instalarlo

La forma más simple: ve a **[adoptium.net](https://adoptium.net)**, descarga **Temurin JDK 21 (LTS)**
para tu sistema y ejecuta el instalador con las opciones por defecto.

O por terminal:

```powershell
# Windows
winget install EclipseAdoptium.Temurin.21.JDK
```
```bash
# macOS
brew install --cask temurin@21
```

⚠️ **Cierra la terminal y ábrela de nuevo** al terminar. Si no, el sistema todavía no
encuentra `java`. Vuelve a correr `java -version` para confirmar que dice 21.

---

## Paso 2 — VS Code y sus extensiones

Si no lo tienes, descárgalo de [code.visualstudio.com](https://code.visualstudio.com).

Luego, en una terminal:

```bash
code --install-extension vscjava.vscode-java-pack
code --install-extension vmware.vscode-boot-dev-pack
code --install-extension ms-azuretools.vscode-docker
code --install-extension cweijan.vscode-database-client2
```

Qué hace cada una:

- **Extension Pack for Java** — compilar, autocompletado, depurador, tests. Imprescindible.
- **Spring Boot Extension Pack** — entiende las anotaciones de Spring y te deja navegar entre piezas.
- **Docker** — ver y parar contenedores desde el editor.
- **Database Client** — consultar PostgreSQL sin salir de VS Code. Lo vas a usar mucho:
  buena parte de tu evidencia son consultas SQL.

> El proyecto ya trae `.vscode/extensions.json`, así que al abrirlo VS Code te las va a
> sugerir solo.

---

## Paso 3 — Abrir el proyecto

El proyecto viene en el archivo comprimido de la entrega. Descomprímelo donde quieras y
entra en la carpeta:

```bash
cd Entrega_Semana_3
code .
```

`code .` abre VS Code en esa carpeta. La primera vez, VS Code va a tardar un par de
minutos en "importar el proyecto Java" (aparece abajo a la derecha). Déjalo terminar.

---

## Paso 4 — Levantar PostgreSQL

Abre **Docker Desktop** y espera a que abajo a la izquierda diga **"Engine running"** con un
punto verde. Si no arranca, nada de lo siguiente va a funcionar.

Luego, en la terminal (dentro de la carpeta del proyecto):

```bash
docker compose up -d
```

La primera vez descarga la imagen de PostgreSQL (~80 MB). Cuando termina:

```bash
docker compose ps
```

Debe mostrar `bancoxyz-db` con estado `running` y `(healthy)`.

### Comandos que vas a usar seguido

| Para | Comando |
|---|---|
| Encender la BD | `docker compose up -d` |
| Apagarla (conserva los datos) | `docker compose down` |
| Apagarla y **borrar** los datos | `docker compose down -v` |
| Ver la BD por consola | `docker exec -it bancoxyz-db psql -U banco -d bancoxyz` |

> Los scripts de `docker/initdb/` se ejecutan **sólo la primera vez**, cuando se crea el
> volumen. Si cambias ese SQL y no ves el efecto, necesitas `docker compose down -v`.

---

## Paso 5 — Ejecutar el Job 1

Dos formas. La primera vez usa la terminal, para ver todo lo que pasa:

```bash
# macOS / Linux
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias
```
```powershell
# Windows PowerShell
.\mvnw.cmd spring-boot:run "-Dspring-boot.run.arguments=--job=jobTransaccionesDiarias"
```

**La primera vez tarda varios minutos**: Maven está descargando Spring Boot, Spring Batch,
el driver de PostgreSQL y sus dependencias (unos 60 MB). Las siguientes veces son segundos.

Cuando termine, entre los logs vas a ver algo así:

```
Step 'stepCargarTransacciones': leídas=1000 escritas=785 omitidas=215 rechazos_guardados=215
=== jobTransaccionesDiarias terminó con estado COMPLETED ===
```

**La otra forma**, más cómoda para el día a día: en VS Code, panel **Run and Debug**
(el triangulito con el bicho en la barra izquierda), elige *"Job 1 · Transacciones diarias"*
y dale al play. Ahí puedes poner *breakpoints* y ver fila por fila cómo se transforma cada dato.

---

## Paso 6 — Mirar lo que quedó en la base de datos

```bash
docker exec -it bancoxyz-db psql -U banco -d bancoxyz
```

Y dentro, pega estas consultas:

```sql
-- 1. LA CONSULTA QUE IMPORTA: ¿se perdió alguna fila?
SELECT (SELECT COUNT(*) FROM banco.transaccion)        AS en_negocio,
       (SELECT COUNT(*) FROM banco.registro_rechazado) AS rechazadas,
       (SELECT COUNT(*) FROM banco.transaccion)
     + (SELECT COUNT(*) FROM banco.registro_rechazado) AS suma;
-- Debe dar 785 + 215 = 1000. Ni una fila menos.

-- 2. ¿Cómo quedaron clasificadas?
SELECT estado, COUNT(*) FROM banco.transaccion GROUP BY estado ORDER BY 2 DESC;

-- 3. ¿Por qué se rechazaron las otras?
SELECT motivo, COUNT(*) FROM banco.registro_rechazado GROUP BY motivo ORDER BY 2 DESC;

-- 4. Los 4 formatos de fecha, ya reparados
SELECT formato_fecha, COUNT(*) FROM banco.transaccion GROUP BY formato_fecha;

-- 5. Ver la reparación en acción (original -> normalizado)
SELECT fecha_original, fecha, tipo_original, tipo, estado
FROM banco.transaccion LIMIT 15;

-- 6. Las tablas internas de Spring Batch: tu fuente de evidencia
SELECT step_name, status, read_count, write_count,
       process_skip_count, commit_count, rollback_count
FROM batch_step_execution;
```

Para salir de `psql`: `\q`

La consulta 5 es la que mejor muestra el trabajo: verás filas donde `fecha_original` decía
`24-07-2024` o `2024/10/15` y `fecha` quedó normalizada, o donde `tipo_original` era
`invalid` y `tipo` quedó como `DESCONOCIDO` con su estado marcado.

---

## Paso 7 — Entender qué acaba de pasar

Recorre los archivos en este orden. Están comentados a propósito.

| Orden | Archivo | Qué mirar |
|---|---|---|
| 1 | `domain/TransaccionRaw.java` | La fila del CSV, **todo como texto**. Aquí está el truco que evita perder filas. |
| 2 | `support/NormalizadorFecha.java` | Los 4 formatos de fecha y por qué el primer número es el día. |
| 3 | `processor/TransaccionProcessor.java` | **El corazón.** Reparar / marcar / rechazar. Léelo entero. |
| 4 | `policy/BancoXyzSkipPolicy.java` | Distinguir dato sucio de fallo de infraestructura. |
| 5 | `listener/RechazoListener.java` | Dónde van a parar las filas rechazadas. |
| 6 | `config/TransaccionesJobConfig.java` | El cableado: cómo se conectan reader, processor y writer. |

El flujo completo, en una línea:

```
transacciones.csv → Reader (texto crudo) → Processor (repara/marca/rechaza)
                                                │
                        ┌───────────────────────┴────────────────┐
                        ▼                                        ▼
              banco.transaccion (785)              banco.registro_rechazado (215)
```

---

## Anexo A — Java para quien viene de Python

Lo mínimo para leer el código sin sentirte perdido:

| Python | Java | Comentario |
|---|---|---|
| `def f(x):` | `public String f(int x) { }` | Hay que declarar el tipo que entra y el que sale |
| `x = 5` | `int x = 5;` | Tipo explícito, y **punto y coma al final de cada línea** |
| `class A:` | `public class A { }` | Las llaves `{}` reemplazan a la indentación |
| `@dataclass` | `record` | Clase de sólo datos, con constructor y getters automáticos |
| `Enum` | `enum` | Igual conceptualmente |
| `None` | `null` / `Optional` | `Optional` obliga a comprobar si hay valor: es más seguro |
| `try/except` | `try/catch` | Mismo concepto |
| `raise X()` | `throw new X()` | Mismo concepto |
| `str.upper()` | `str.toUpperCase()` | Métodos más verbosos |
| `# comentario` | `// comentario` | `/* ... */` para varias líneas |
| `pip install` | dependencia en `pom.xml` | Se declara y Maven la baja |
| type hints (opcionales) | genéricos `<T>` (obligatorios) | El compilador los verifica de verdad |

**Las anotaciones** (`@Component`, `@Bean`, `@Configuration`) son lo más extraño al principio.
Son marcas que le dicen a Spring qué hacer con una clase. `@Component` significa
*"Spring, crea uno de estos y tenlo listo para dárselo a quien lo pida"*. A eso se le llama
inyección de dependencias: tú declaras las piezas, Spring las arma.

**Lo que más te va a chocar:** en Java todo es explícito y verboso. Donde en Python escribes
una línea, aquí escribes cinco. No es que lo estés haciendo mal — es así.

---

## Anexo B — Los CSV

Ya están en el proyecto, en `src/main/resources/data/`:

| Archivo | Filas | Columnas |
|---|---|---|
| `transacciones.csv` | 1.000 | `id, fecha, monto, tipo` |
| `intereses.csv` | 1.000 | `cuenta_id, nombre, saldo, edad, tipo` |
| `cuentas_anuales.csv` | 1.000 | `cuenta_id, fecha, transaccion, monto, descripcion` |

Vienen de [github.com/KariVillagran/bank_legacy_data](https://github.com/KariVillagran/bank_legacy_data),
carpeta `data/semana_3` (las de semanas 1 y 2 tienen sólo ~10 filas; **la de esta entrega es
la 3**). Están sucios a propósito: el detalle campo por campo, con conteos medidos, está en
[`analisis-datos.md`](analisis-datos.md).

---

## Si algo falla

| Error | Causa | Solución |
|---|---|---|
| `java: command not found` | Java no instalado, o terminal no reiniciada | Cierra y abre la terminal |
| `Connection refused: localhost:5432` | Postgres no está corriendo | `docker compose up -d` |
| `relation "banco.transaccion" does not exist` | El esquema no se creó | `docker compose down -v && docker compose up -d` |
| `JobInstanceAlreadyCompleteException` | Ya corriste ese job con los mismos parámetros | No debería pasar: hay `RunIdIncrementer`. Si pasa, avisa |
| `Port 5432 is already allocated` | Tienes otro Postgres ocupando el puerto | `docker ps` para ver cuál, y párralo |
| VS Code no reconoce el proyecto | No terminó de importar | `Ctrl+Shift+P` → *Java: Clean Java Language Server Workspace* |
| La compilación tarda muchísimo | Primera vez, descargando dependencias | Normal. Sólo la primera |

---

## Qué viene después

Con esto tienes la **etapa 2** del plan hecha (un job completo funcionando en secuencial).
Lo que sigue, en orden:

1. Tests de los normalizadores (etapa 3)
2. Más escenarios de tolerancia a fallos (etapa 4)
3. Particiones — el escalado del criterio 4 (etapa 5)
4. Replicar el patrón para los Jobs 2 y 3 (etapa 6)

El detalle de cada etapa está en [`guia-didactica.md`](guia-didactica.md) y
[`plan-maestro.md`](plan-maestro.md).
