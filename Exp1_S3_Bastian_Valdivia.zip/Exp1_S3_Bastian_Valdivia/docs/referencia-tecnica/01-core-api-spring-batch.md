## PARTE 1 — ERRORES ENCONTRADOS

Verifiqué cada afirmación contra los JAR reales en `/root/.m2/repository` (`javap`), contra los POM/metadata de Maven Central, contra la doc oficial, y **ejecutando 4 proyectos Spring Boot 4.1.1 nuevos**. El informe es en su mayoría correcto y muchas de sus afirmaciones más agresivas quedaron **confirmadas**. Encontré **9 errores**, dos de ellos graves.

---

### 🔴 E1 — CRÍTICO: `application.properties` del §7 impide que la aplicación arranque

**Afirmación:** `spring.batch.jdbc.isolation-level-for-create=ISOLATION_READ_COMMITTED`

**Es falso.** En Boot 4.1 esa propiedad se enlaza al **enum** `org.springframework.transaction.annotation.Isolation`, cuyas constantes **no llevan el prefijo `ISOLATION_`**. Ejecuté la app y falla al arrancar:

```
APPLICATION FAILED TO START
Failed to bind properties under 'spring.batch.jdbc.isolation-level-for-create'
   to org.springframework.transaction.annotation.Isolation:
    Value: "ISOLATION_READ_COMMITTED"
    Reason: No enum constant org.springframework.transaction.annotation.Isolation.ISOLATION_READ_COMMITTED
```

Firma real (`javap` sobre `spring-boot-batch-jdbc-4.1.1.jar`):
```java
public void setIsolationLevelForCreate(org.springframework.transaction.annotation.Isolation);
```
Y `spring-configuration-metadata.json` del mismo JAR declara `"type": "org.springframework.transaction.annotation.Isolation"`.

**Corrección:** `spring.batch.jdbc.isolation-level-for-create=READ_COMMITTED` (verificado: arranca y crea las 6 tablas).
Es una inconsistencia interna del informe: el §4 descubrió correctamente que el atributo pasó de String a enum, pero no propagó el cambio al `.properties`.
Fuente: https://docs.spring.io/spring-boot/appendix/application-properties/index.html

---

### 🔴 E2 — FALSO: §4 «pierdes `spring.batch.job.name`, `spring.batch.job.enabled` y el `JobLauncherApplicationRunner`»

`BatchJobLauncherAutoConfiguration` **no** hace back-off ante `@EnableBatchProcessing`. Sus anotaciones reales (`javap -v` sobre `spring-boot-batch-4.1.1.jar`) son:

```java
@AutoConfiguration(after = BatchAutoConfiguration.class)
@ConditionalOnClass(JobOperator.class)
@ConditionalOnBean(JobOperator.class)
@EnableConfigurationProperties(BatchProperties.class)   // ← declara BatchProperties por su cuenta
public final class BatchJobLauncherAutoConfiguration { ... }
```

No hay `@ConditionalOnMissingBean(annotation = EnableBatchProcessing.class)` a nivel de clase (eso sí lo tienen `BatchAutoConfiguration` y `BatchJdbcAutoConfiguration`). Como `@EnableBatchProcessing` registra un bean `JobOperator`, la condición se cumple igual.

**Comprobación empírica** (app con `@EnableBatchProcessing` + `@EnableJdbcJobRepository`, dos Jobs):
```
# spring.batch.job.enabled=false
>>> JobLauncherApplicationRunner present = false     ← la propiedad SIGUE funcionando

# spring.batch.job.enabled=true / spring.batch.job.name=otroJob
Job: [SimpleJob: [name=otroJob]] launched ...        ← la propiedad SIGUE funcionando
>>> JobLauncherApplicationRunner present = true
```

**Corrección:** con `@EnableBatchProcessing` sólo se pierden las propiedades **`spring.batch.jdbc.*`** (inicialización del esquema y `table-prefix`). Verificado: sin DDL manual la app revienta con `Table "BATCH_JOB_INSTANCE" not found`. `spring.batch.job.name` y `spring.batch.job.enabled` siguen operativas.
Fuente: https://github.com/spring-projects/spring-boot/blob/v4.1.1/module/spring-boot-batch/src/main/java/org/springframework/boot/batch/autoconfigure/BatchJobLauncherAutoConfiguration.java

---

### 🟠 E3 — FALSO: §6.2 «El segundo parámetro es `long`, no `int` como en 5.x»

`javap` sobre **`spring-batch-core-5.2.6.jar`**:
```java
public interface org.springframework.batch.core.step.skip.SkipPolicy {
  public abstract boolean shouldSkip(java.lang.Throwable, long) throws SkipLimitExceededException;
}
```
Es **idéntico** en 5.2.6 y 6.0.5. El cambio `int` → `long` ocurrió en **Spring Batch 5.0**, no en 6.0. La advertencia es innecesaria y confunde.
Fuente: https://docs.spring.io/spring-batch/docs/5.2.x/api/org/springframework/batch/core/step/skip/SkipPolicy.html

---

### 🟠 E4 — VERSIONES MAL CITADAS: §1 «Líneas con soporte: 6.0.5, 5.2.6, 5.1.3»

- **5.1.x está fuera de soporte OSS desde el 2024-11-22.**
- **5.2.6 fue anunciada como la última release OSS de la línea 5.2:** *"Spring Batch 5.2.6 is most probably the last OSS release of the 5.2.x generation"* y se recomienda *"consider upgrading to 6.0.x at your earliest convenience"*.

**Corrección:** la única línea con soporte OSS vigente es **6.0.x**.
Fuente: https://spring.io/blog/2026/06/10/spring-batch-6-0-4-and-5-2-6-available-now/

---

### 🟠 E5 — RECOMENDACIÓN INVÁLIDA: §11 Opción B («conservadora … sigue estando con soporte»)

Ambas patas de la Opción B están fuera de soporte OSS:
- **Spring Batch 5.2.6** → última release OSS de 5.2.x (ver E4).
- **Spring Boot 3.5.16** (2026-06-25) → *"This is the last OSS release of the 3.5.x generation. To continue to receive OSS support, upgrade to 4.0.x or 4.1.x at your earliest convenience."*

La tabla del §1 la lista como «vigente», lo cual es incorrecto sin la aclaración.
Fuente: https://spring.io/blog/2026/06/25/spring-boot-3-5-16-available-now/

---

### 🟠 E6 — OMISIÓN MATERIAL: §8, `ResourcelessJobRepository` tampoco sirve para multi-thread

El informe sólo dice que no sirve para particionado. La doc oficial añade una restricción que invalida **también la Opción A** del mismo §8:

> *"This implementation is **not** thread-safe and should **not** be used in any concurrent environment."*

Un `chunk(...).taskExecutor(...)` con el repositorio resourceless es igual de inválido que el particionado.
Fuente: https://docs.spring.io/spring-batch/reference/job/configuring-repository.html

---

### 🟡 E7 — IMPRECISO: §5 «`ChunkOrientedStep` … reemplaza a `ChunkOrientedTasklet`/`TaskletStep`»

`javap -v` sobre `spring-batch-core-6.0.5.jar`:

| Clase | Estado en 6.0.5 |
|---|---|
| `ChunkOrientedTasklet` | **DEPRECATED** |
| `SimpleStepBuilder` | **DEPRECATED** |
| `FaultTolerantStepBuilder` | **DEPRECATED** |
| `TaskletStep` | **NO deprecado** — sigue siendo la implementación de los steps tipo tasklet |

**Corrección:** `ChunkOrientedStep` reemplaza a `ChunkOrientedTasklet` (+ el `TaskletStep` que lo envolvía) **sólo en el camino chunk-oriented**. `TaskletStep` permanece plenamente vigente para `.tasklet(...)`.

---

### 🟡 E8 — IMPRECISO: §9.3 «`JobParameters` ahora es `Set<JobParameter>`»

Firma real: `JobParameters` es un `record` que implementa `Iterable<JobParameter<?>>` y envuelve `Set<JobParameter<?>>` — `JobParameter` es **genérico** (`JobParameter<T>`), no crudo.
```java
public final class JobParameters extends Record implements Serializable, Iterable<JobParameter<?>> {
  public JobParameters(java.util.Set<JobParameter<?>>);
  public java.util.Set<JobParameter<?>> parameters();
}
public final class JobParameter<T> extends Record { ... public String name(); public T value(); }
```

---

### 🟡 E9 — AFIRMACIÓN SIN RESPALDO EXACTO: §9.9 «`CommandLineJobOperator` (reemplaza `CommandLineJobRunner`)»

La guía de migración 6.0 **no nombra** un reemplazo; sólo marca `CommandLineJobRunner` como deprecado. Lo verificable es: `CommandLineJobRunner` está `Deprecated` en el JAR, `CommandLineJobOperator` existe, y el «What's New» lo lista como *"New command line operator"*. La relación de reemplazo es inferencia razonable, no cita.

---

### ✅ Afirmaciones que INTENTÉ refutar y quedaron CONFIRMADAS

No pude tumbar nada de lo siguiente:

| Afirmación | Cómo la verifiqué |
|---|---|
| Batch 6.0.5 / Boot 4.1.1 / SF 7.0.9 GA; 6.1.0-M1 es milestone | `maven-metadata.xml` + POM del BOM |
| Boot 4.1.1 → batch 6.0.5 + SF 7.0.9; Boot 3.5.16 → batch 5.2.6 + SF 6.2.19 | POM de `spring-boot-dependencies` |
| Java 17 mín., hasta Java 26; Maven 3.6.3+ | doc oficial de system-requirements |
| `spring-boot-starter-batch` NO trae JDBC → `ResourcelessJobRepository`, 0 tablas | **ejecutado**: `probe5` |
| `spring-boot-starter-batch-jdbc` → 6 tablas + JobRepository proxificado | **ejecutado**: `probe4` |
| `initialize-schema=always` se ignora en silencio sin el módulo JDBC | **ejecutado**: la app arrancó sin error ni tablas |
| Initializr con `dependencies=batch` genera el starter in-memory | descargué `start.spring.io/starter.zip` |
| Firmas de `JobBuilder`, `StepBuilder`, `ChunkOrientedStepBuilder`, `PartitionStepBuilder` | `javap` |
| `chunk(int,tm)` y `chunk(CompletionPolicy,tm)` con `@Deprecated(forRemoval=true)`; `tasklet(Tasklet,tm)` NO deprecado | `javap -v` |
| En 5.2.6 es al revés: `chunk(int)` deprecado | `javap -v` sobre 5.2.6 |
| **Errata de la doc oficial**: `isolationLevelForCreate` como String vs enum `Isolation` | doc muestra `"SERIALIZABLE"`; JAR expone `Isolation` |
| `@EnableBatchProcessing` sin `dataSourceRef`; `modular` `@Deprecated(since="6.0", forRemoval=true)` | `javap -v` |
| API de `RetryPolicy` / `RetryPolicy.Builder` de spring-core 7.0.9 | `javap` |
| `LimitCheckingExceptionHierarchySkipPolicy(Set, long)`, `SkipLimitExceededException(long, Throwable)` | `javap` |
| 6 tablas, 3 secuencias, `BATCH_JOB_SEQ` → `BATCH_JOB_INSTANCE_SEQ` | `schema-postgresql.sql` de ambos JAR |
| Defaults: `initialize-schema=embedded`, `continue-on-error=true`, isolation `SERIALIZABLE` | `spring-configuration-metadata.json` + bytecode |
| Reubicación de paquetes, Jackson 3 (`tools.jackson.*`), `JobRepository extends JobExplorer`, inyección por constructor, sin restart desde 5.x | migration guide + `javap` |
| **Los 6 snippets compilan** contra Boot 4.1.1 con `-Xlint:all`: `BUILD SUCCESS`, cero warnings | `mvn clean compile` en `probe3` |

**Además resolví los puntos que el informe dejaba abiertos en §12:** `continue-on-error=true` está confirmado (`"defaultValue": true` en el metadata del JAR) y `spring.batch.jdbc.schema` sí tiene default (`DEFAULT_SCHEMA_LOCATION = classpath:org/springframework/batch/core/schema-@@platform@@.sql`, leído del bytecode de `BatchJdbcProperties`).

**Proyectos de verificación (rutas absolutas):**
- `/tmp/claude-0/-home-user-backend-3-bastian/4e7e7dfe-fd51-590e-98b4-3e8278e117a0/scratchpad/probe3/` — compilación de los 6 snippets del informe
- `/tmp/claude-0/-home-user-backend-3-bastian/4e7e7dfe-fd51-590e-98b4-3e8278e117a0/scratchpad/probe4/` — arranque con `starter-batch-jdbc` + prueba del enum de aislamiento
- `/tmp/claude-0/-home-user-backend-3-bastian/4e7e7dfe-fd51-590e-98b4-3e8278e117a0/scratchpad/probe5/` — arranque con `starter-batch` + `starter-jdbc` (resourceless)
- `/tmp/claude-0/-home-user-backend-3-bastian/4e7e7dfe-fd51-590e-98b4-3e8278e117a0/scratchpad/probe6/` — prueba de `@EnableBatchProcessing`

---
---

## PARTE 2 — INFORME CORREGIDO Y CONSOLIDADO

# Spring Batch 6 / Spring Boot 4 — Material de estudio (agosto 2026)

**Fecha de verificación: 2026-08-26.** Todo lo que sigue fue contrastado contra Maven Central, la documentación oficial, el bytecode de los JAR (`javap`) y **ejecución real** de aplicaciones Spring Boot 4.1.1 con H2 (JDK 21, Maven 3.9.11).

> **Regla de oro de este documento:** cuando la doc oficial y el JAR se contradicen, **manda el JAR**. Hay al menos una errata confirmada en la doc de 6.0.5 (§4).

---

## 1. Versiones estables y estado de soporte

| Componente | Versión GA | Estado |
|---|---|---|
| **Spring Batch** | **6.0.5** (2026-08-20) | Única línea con **soporte OSS** vigente. Preview: 6.1.0-M1 |
| **Spring Boot** | **4.1.1** | 4.0.x también con soporte OSS |
| **Spring Framework** | 7.0.9 | Traído por Boot 4.1.1 |

**Líneas cerradas (¡ojo!):**

| Línea | Última release | Estado OSS |
|---|---|---|
| Spring Batch 5.2.x | 5.2.6 (2026-06-10) | *"most probably the last OSS release of the 5.2.x generation"* — recomiendan subir a 6.0.x |
| Spring Batch 5.1.x | 5.1.3 | Fuera de soporte OSS desde 2024-11-22 |
| Spring Boot 3.5.x | 3.5.16 (2026-06-25) | *"the last OSS release of the 3.5.x generation"* — recomiendan subir a 4.0.x/4.1.x |

Sigue habiendo soporte **comercial** para esas líneas, pero no OSS.

Mapeo de dependencias gestionadas (leído de los POM reales del BOM `spring-boot-dependencies`):

| Spring Boot | `spring-batch.version` | `spring-framework.version` |
|---|---|---|
| 4.1.1 | **6.0.5** | 7.0.9 |
| 4.0.8 | 6.0.5 | 7.0.9 |
| 3.5.16 | 5.2.6 | 6.2.19 |

**Requisitos de Boot 4.1.1:** Java **17 mínimo**, compatible **hasta Java 26 inclusive**. Maven **3.6.3+**, Gradle 8.14+ / 9.x. Spring Framework 7.0.9 o superior.

Fuentes:
- https://spring.io/blog/2026/08/20/spring-batch-6-0-5-and-6-1-0-M1-available-now/
- https://spring.io/blog/2026/06/10/spring-batch-6-0-4-and-5-2-6-available-now/
- https://spring.io/blog/2026/06/25/spring-boot-3-5-16-available-now/
- https://docs.spring.io/spring-boot/system-requirements.html
- https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-dependencies/4.1.1/spring-boot-dependencies-4.1.1.pom

---

## 2. ⚠️ ALERTA CRÍTICA: `spring-boot-starter-batch` YA NO persiste metadatos

Es el hallazgo que rompe la mayoría de tutoriales.

En Spring Batch 6, `DefaultBatchConfiguration` provee por defecto una infraestructura **"resourceless"** (`ResourcelessJobRepository`): **los metadatos quedan en memoria, no en BD**. En Spring Boot 4.x, `spring-boot-starter-batch` sólo depende de `spring-boot-starter` + `spring-boot-batch` (auto-configuración *in-memory*). El módulo JDBC vive en un artefacto aparte.

**Verificación empírica** (Boot 4.1.1 + H2 + `spring.batch.jdbc.initialize-schema=always`):

```
# spring-boot-starter-batch + spring-boot-starter-jdbc:
>>> JobRepository impl = org.springframework.batch.core.repository.support.ResourcelessJobRepository
>>> BATCH_* tables found = 0

# spring-boot-starter-batch-jdbc:
>>> JobRepository impl = jdk.proxy2.$Proxy54   (JobRepository JDBC proxificado transaccionalmente)
>>> BATCH_* tables found = 6
```

**`spring.batch.jdbc.initialize-schema=always` se ignora en silencio** si falta el módulo JDBC: no hay error, el job corre, los tests pasan, y no hay reinicio ni trazabilidad. Para una evaluación que exige "BD relacional" y "tolerancia a fallos" sería una falla invisible.

**Spring Initializr NO lo resuelve:** un proyecto generado con `start.spring.io?bootVersion=4.1.1&dependencies=batch,postgresql` produce `spring-boot-starter-batch` (in-memory). Hay que cambiarlo a mano.

**POM correcto:**

```xml
<parent>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-parent</artifactId>
  <version>4.1.1</version>
</parent>
<properties><java.version>21</java.version></properties>

<dependencies>
  <!-- OBLIGATORIO: trae starter-batch + starter-jdbc + spring-boot-batch-jdbc -->
  <dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-batch-jdbc</artifactId>
  </dependency>
  <dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <scope>runtime</scope>
  </dependency>
  <dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-batch-test</artifactId>
    <scope>test</scope>
  </dependency>
</dependencies>
```

**Limitaciones del `ResourcelessJobRepository`** (doc oficial, literal):
> *"This implementation does not use or store batch meta-data. It is intended for use-cases where restartability is not required and where the execution context is not involved in any way (like sharing data between steps through the execution context, or partitioned steps where partitions meta-data is shared between the manager and workers through the execution context, etc)."*
> *"This implementation is **not** thread-safe and should **not** be used in any concurrent environment."*

Es decir: **no sirve ni para particionado ni para multi-thread steps ni para reinicio**.

Fuentes:
- https://docs.spring.io/spring-boot/reference/io/spring-batch.html
- https://docs.spring.io/spring-batch/reference/whatsnew.html
- https://docs.spring.io/spring-batch/reference/job/configuring-repository.html
- https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-starter-batch/4.1.1/spring-boot-starter-batch-4.1.1.pom
- https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-starter-batch-jdbc/4.1.1/spring-boot-starter-batch-jdbc-4.1.1.pom

---

## 3. Firmas exactas de `JobBuilder` y `StepBuilder` (`javap` sobre `spring-batch-core-6.0.5.jar`)

`JobBuilderFactory` / `StepBuilderFactory` fueron eliminados en 5.0 y **no existen** ni en 5.2.6 ni en 6.0.5.

### `org.springframework.batch.core.job.builder.JobBuilder`

```java
public JobBuilder(JobRepository jobRepository)
public JobBuilder(String name, JobRepository jobRepository)

public SimpleJobBuilder start(Step step)
public JobFlowBuilder  start(Flow flow)
public JobFlowBuilder  start(JobExecutionDecider decider)
public JobFlowBuilder  flow(Step step)
```

`JobBuilder` recibe **(nombre, JobRepository)**. **NO recibe `PlatformTransactionManager`.** Si se declara como `@Bean`, el nombre puede omitirse: `AbstractJob` implementa `BeanNameAware`, así que el nombre se deriva del bean.

### `org.springframework.batch.core.step.builder.StepBuilder`

```java
public StepBuilder(JobRepository jobRepository)
public StepBuilder(String name, JobRepository jobRepository)

// ==== VIGENTE ====
public <I,O> ChunkOrientedStepBuilder<I,O> chunk(int chunkSize)
public TaskletStepBuilder tasklet(Tasklet tasklet)
public TaskletStepBuilder tasklet(Tasklet tasklet, PlatformTransactionManager tm)   // NO deprecado
public PartitionStepBuilder partitioner(String stepName, Partitioner partitioner)
public PartitionStepBuilder partitioner(Step step)
public JobStepBuilder  job(Job job)
public FlowStepBuilder flow(Flow flow)

// ==== DEPRECADO Y MARCADO PARA ELIMINACIÓN ====
@Deprecated(forRemoval = true)
public <I,O> SimpleStepBuilder<I,O> chunk(int, PlatformTransactionManager)
@Deprecated(forRemoval = true)
public <I,O> SimpleStepBuilder<I,O> chunk(CompletionPolicy, PlatformTransactionManager)
```

`StepBuilder` recibe **(nombre, JobRepository)**. El `PlatformTransactionManager` ya no es argumento de constructor ni de `chunk()`: se pasa con `.transactionManager(tm)` en la cadena, y **es opcional** — el default es `ResourcelessTransactionManager` (verificado en el bytecode de `ChunkOrientedStepBuilder`).

Advertencia real emitida por `javac` al usar la forma antigua:
```
[WARNING] <I,O>chunk(int,org.springframework.transaction.PlatformTransactionManager)
          in org.springframework.batch.core.step.builder.StepBuilder
          has been deprecated and marked for removal
```

> **Trampa de versiones — muy importante:** en **Spring Batch 5.2.6 es exactamente al revés**. Verificado con `javap -v` sobre `spring-batch-core-5.2.6.jar`: allí están deprecados `StepBuilder(String)`, `tasklet(Tasklet)`, `chunk(int)` y `chunk(CompletionPolicy)`; la forma correcta es `chunk(int, transactionManager)`. Un snippet de 5.x compila en 6.x pero con warning "for removal"; uno de 6.x no compila bien en 5.x. **Elige una versión y sé consistente.**

Fuentes:
- https://docs.spring.io/spring-batch/reference/job/configuring-job.html
- https://docs.spring.io/spring-batch/reference/step/chunk-oriented-processing/configuring.html
- https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide

---

## 4. Estado de `@EnableBatchProcessing`

**Con Spring Boot: NO lo uses.** La doc oficial de Boot es explícita:

> *"To disable Spring Boot's auto-configuration and take complete control of Spring Batch's configuration, add `@EnableBatchProcessing` to one of your `@Configuration` classes or extend `DefaultBatchConfiguration`. This will cause the auto-configuration to back off, including initialization of Spring Batch's database schema (JDBC or MongoDB)."*
> — https://docs.spring.io/spring-boot/reference/io/spring-batch.html

Condiciones reales de las auto-configuraciones (`javap -v` sobre los JAR de Boot 4.1.1):

| Auto-config | ¿Back-off ante `@EnableBatchProcessing`? |
|---|---|
| `BatchAutoConfiguration` | **SÍ** — `@ConditionalOnMissingBean(value = DefaultBatchConfiguration.class, annotation = EnableBatchProcessing.class)` |
| `BatchJdbcAutoConfiguration` | **SÍ** — misma condición |
| `BatchJobLauncherAutoConfiguration` | **NO** — sólo `@ConditionalOnClass/@ConditionalOnBean(JobOperator.class)` + `@EnableConfigurationProperties(BatchProperties.class)` |

### ✅ Consecuencia práctica (corregida y verificada por ejecución)

Si pones `@EnableBatchProcessing` en tu app Boot:

- **PIERDES:** `spring.batch.jdbc.initialize-schema`, `spring.batch.jdbc.table-prefix`, `spring.batch.jdbc.isolation-level-for-create` y demás `spring.batch.jdbc.*`. Las tablas `BATCH_*` dejan de crearse solas → la app falla con `Table "BATCH_JOB_INSTANCE" not found`. **Esto explica el 90 % de los "no me crea las tablas" en foros.** Debes configurar el store vía `@EnableJdbcJobRepository` y crear el DDL tú.
- **CONSERVAS:** `spring.batch.job.name`, `spring.batch.job.enabled` y el `JobLauncherApplicationRunner`. Comprobado: con `spring.batch.job.enabled=false` el runner desaparece; con `spring.batch.job.name=otroJob` se lanza ese Job y no el otro.

### Novedad de 6.0: `@EnableBatchProcessing` ya no está atada a JDBC

Se dividió en tres anotaciones. Atributos reales (`javap`):

```java
// org.springframework.batch.core.configuration.annotation.EnableBatchProcessing
boolean modular();                    // @Deprecated(since="6.0", forRemoval=true)
String  taskExecutorRef();
String  jobRegistryRef();
String  observationRegistryRef();
String  transactionManagerRef();
String  jobParametersConverterRef();
// ← YA NO existe dataSourceRef

// org.springframework.batch.core.configuration.annotation.EnableJdbcJobRepository
String databaseType(); boolean validateTransactionState();
Isolation isolationLevelForCreate();          // ← ENUM, no String
String charset(); String tablePrefix();
int maxVarCharLength(); int clobType();
String dataSourceRef(); String transactionManagerRef(); String jdbcOperationsRef();
String jobKeyGeneratorRef(); String executionContextSerializerRef();
String incrementerFactoryRef(); String conversionServiceRef();

// org.springframework.batch.core.configuration.annotation.EnableMongoJobRepository → store MongoDB
```

Sólo si necesitaras control total (normalmente **no** es el caso):

```java
@Configuration
@EnableBatchProcessing(taskExecutorRef = "batchTaskExecutor")
@EnableJdbcJobRepository(
        dataSourceRef = "dataSource",
        tablePrefix = "BATCH_",
        isolationLevelForCreate = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
public class BatchInfraConfig { }
```
*(compilado y verificado)*

> 🔴 **ERRATA EN LA DOCUMENTACIÓN OFICIAL — confirmada.** La página https://docs.spring.io/spring-batch/reference/job/configuring-repository.html muestra `isolationLevelForCreate = "SERIALIZABLE"` y `"ISOLATION_REPEATABLE_READ"` (String). **Eso NO compila en 6.0.5:**
> ```
> [ERROR] incompatible types: java.lang.String cannot be converted to
>         org.springframework.transaction.annotation.Isolation
> ```
> Firma real: `public abstract org.springframework.transaction.annotation.Isolation isolationLevelForCreate();`
> Constantes válidas del enum: `DEFAULT`, `READ_UNCOMMITTED`, `READ_COMMITTED`, `REPEATABLE_READ`, `SERIALIZABLE` — **sin prefijo `ISOLATION_`**.

`@EnableBatchProcessing` y `DefaultBatchConfiguration` son **mutuamente excluyentes**: uno u otro, nunca ambos.
Fuente: https://docs.spring.io/spring-batch/reference/job/configuring-infrastructure.html

---

## 5. `chunk(...)` y el step orientado a chunk

La forma vigente devuelve un tipo **distinto** al de 5.x: `ChunkOrientedStepBuilder<I,O>`, que construye la nueva clase `ChunkOrientedStep`.

**Precisión sobre qué reemplaza a qué** (estado de deprecación en 6.0.5, verificado):

| Clase | Estado |
|---|---|
| `ChunkOrientedTasklet` | **DEPRECADA** |
| `SimpleStepBuilder` | **DEPRECADA** |
| `FaultTolerantStepBuilder` | **DEPRECADA** |
| `TaskletStep` | **NO deprecada** — sigue siendo la implementación de `.tasklet(...)` |

O sea: `ChunkOrientedStep` sustituye al par `ChunkOrientedTasklet` + `TaskletStep` **sólo en el camino chunk-oriented**; para steps tipo tasklet, `TaskletStep` sigue plenamente vigente.

API completa de `ChunkOrientedStepBuilder<I,O>` (`javap`):

```java
public ChunkOrientedStepBuilder(JobRepository jobRepository, int chunkSize)
public ChunkOrientedStepBuilder(String name, JobRepository jobRepository, int chunkSize)

reader(ItemReader<? extends I>)              processor(ItemProcessor<? super I, ? extends O>)
writer(ItemWriter<? super O>)                transactionManager(PlatformTransactionManager)
transactionAttribute(TransactionAttribute)   stream(ItemStream)
listener(StepListener) / listener(Object)    interruptionPolicy(StepInterruptionPolicy)
faultTolerant()
retryPolicy(org.springframework.core.retry.RetryPolicy)     // ← Spring Framework 7, NO spring-retry
retryListener(org.springframework.core.retry.RetryListener)
retry(Class<? extends Throwable>...)         retryLimit(long)
skipPolicy(SkipPolicy)                       skipListener(SkipListener<? super I, ? super O>)
skip(Class<? extends Throwable>...)          skipLimit(long)
taskExecutor(AsyncTaskExecutor)              observationRegistry(ObservationRegistry)
ChunkOrientedStep<I,O> build()
```

**Snippet compilable y verificado** (Job 1 – Reporte de Transacciones Diarias). Compila sin errores ni warnings con `-Xlint:all` contra Boot 4.1.1 / Batch 6.0.5:

```java
package cl.duoc.bancoxyz.batch;

import java.time.Duration;
import java.util.Set;
import javax.sql.DataSource;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.skip.LimitCheckingExceptionHierarchySkipPolicy;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.infrastructure.item.ItemProcessor;
import org.springframework.batch.infrastructure.item.ItemWriter;
import org.springframework.batch.infrastructure.item.database.JdbcBatchItemWriter;
import org.springframework.batch.infrastructure.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.infrastructure.item.file.FlatFileItemReader;
import org.springframework.batch.infrastructure.item.file.FlatFileParseException;
import org.springframework.batch.infrastructure.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.retry.RetryPolicy;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class JobTransaccionesConfig {

    @Bean
    public FlatFileItemReader<Transaccion> transaccionReader() {
        return new FlatFileItemReaderBuilder<Transaccion>()
                .name("transaccionReader")
                .resource(new ClassPathResource("data/semana_3/transacciones.csv"))
                .linesToSkip(1)
                .delimited()
                    .delimiter(",")
                    .names("id", "fecha", "monto", "tipo")
                .targetType(Transaccion.class)
                .build();
    }

    /** Devolver null FILTRA el item (no se escribe, cuenta como filterCount). */
    @Bean
    public ItemProcessor<Transaccion, Transaccion> transaccionProcessor() {
        return item -> item.getMonto() == null ? null : item;
    }

    @Bean
    public JdbcBatchItemWriter<Transaccion> transaccionWriter(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<Transaccion>()
                .dataSource(dataSource)
                .sql("INSERT INTO transaccion (id, fecha, monto, tipo) "
                   + "VALUES (:id, :fecha, :monto, :tipo)")
                .beanMapped()
                .build();
    }

    @Bean
    public Step pasoTransacciones(JobRepository jobRepository,
                                  PlatformTransactionManager transactionManager,
                                  FlatFileItemReader<Transaccion> reader,
                                  ItemProcessor<Transaccion, Transaccion> processor,
                                  ItemWriter<Transaccion> writer) {

        // Política de reintento personalizada (Spring Framework 7)
        RetryPolicy retryPolicy = RetryPolicy.builder()
                .maxRetries(3)
                .includes(TransientDataAccessException.class)
                .delay(Duration.ofMillis(500))
                .multiplier(2.0)
                .maxDelay(Duration.ofSeconds(5))
                .build();

        // Tolerancia a fallos ante datos sucios del legacy
        SkipPolicy skipPolicy = new LimitCheckingExceptionHierarchySkipPolicy(
                Set.of(FlatFileParseException.class), 100L);

        return new StepBuilder("pasoTransacciones", jobRepository)
                .<Transaccion, Transaccion>chunk(200)          // ← firma vigente
                .transactionManager(transactionManager)        // ← ya NO va dentro de chunk()
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .faultTolerant()
                .retryPolicy(retryPolicy)
                .skipPolicy(skipPolicy)
                .build();
    }

    @Bean
    public Job jobTransaccionesDiarias(JobRepository jobRepository, Step pasoTransacciones) {
        return new JobBuilder("jobTransaccionesDiarias", jobRepository)
                .start(pasoTransacciones)
                .build();
    }
}
```

Ejemplo equivalente en la doc oficial: https://docs.spring.io/spring-batch/reference/whatsnew.html (sección *"New implementation of the chunk-oriented processing model"*).

---

## 6. Políticas personalizadas de reintento y skip

### 6.1 Reintento: cambió de librería

En 6.0 el retry **ya no usa `spring-retry`**. Usa `org.springframework.core.retry` de Spring Framework 7.

| 5.2.x (`FaultTolerantStepBuilder`) | 6.0.x (`ChunkOrientedStepBuilder`) |
|---|---|
| `org.springframework.retry.RetryPolicy` | `org.springframework.core.retry.RetryPolicy` |
| `.retryLimit(int)` | `.retryLimit(long)` |
| `.backOffPolicy(org.springframework.retry.backoff.BackOffPolicy)` | backoff dentro del propio `RetryPolicy` |
| `.skipLimit(int)` | `.skipLimit(long)` |

API real (`javap` sobre `spring-core-7.0.9.jar`):

```java
public interface RetryPolicy {
    boolean shouldRetry(Throwable throwable);
    default Duration getTimeout();
    default org.springframework.util.backoff.BackOff getBackOff();
    static RetryPolicy withDefaults();
    static RetryPolicy withMaxRetries(long maxRetries);
    static RetryPolicy.Builder builder();
}

// RetryPolicy.Builder:
backOff(BackOff) | maxRetries(long) | delay(Duration) | jitter(Duration)
multiplier(double) | maxDelay(Duration) | timeout(Duration)
includes(Class<? extends Throwable>...) | includes(Collection<...>)
excludes(Class<? extends Throwable>...) | excludes(Collection<...>)
predicate(Predicate<Throwable>) | build()
```

### 6.2 Skip: vía `SkipPolicy`

```java
public interface org.springframework.batch.core.step.skip.SkipPolicy {
    boolean shouldSkip(Throwable t, long skipCount) throws SkipLimitExceededException;
}
```

> ℹ️ **Nota corregida:** esta firma con `long` es **idéntica en 5.2.6 y en 6.0.5**. El cambio de `int` a `long` ocurrió en Spring Batch **5.0**, no en 6.0. No es un punto de fricción al migrar de 5.2 a 6.0.

Implementación lista para usar (nueva y muy cómoda):
```java
public LimitCheckingExceptionHierarchySkipPolicy(Set<Class<? extends Throwable>> skippable, long skipLimit)
```
*(La clásica `LimitCheckingItemSkipPolicy` sigue existiendo, con constructores que reciben `int` y un `Classifier`/`Map`.)*

**Política personalizada compilable** (para distinguir "fecha con mes 13" de "error de BD"):

```java
package cl.duoc.bancoxyz.batch;

import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.infrastructure.item.file.FlatFileParseException;

public class PoliticaSkipBancoXYZ implements SkipPolicy {

    private final long limite;

    public PoliticaSkipBancoXYZ(long limite) {
        this.limite = limite;
    }

    @Override
    public boolean shouldSkip(Throwable t, long skipCount) throws SkipLimitExceededException {
        // Datos sucios del legacy: se saltan hasta el límite
        if (t instanceof FlatFileParseException || t instanceof java.time.format.DateTimeParseException) {
            if (skipCount >= this.limite) {
                throw new SkipLimitExceededException(this.limite, t);
            }
            return true;
        }
        // Errores de infraestructura: NUNCA se saltan, deben fallar el step
        return false;
    }
}
```
Constructor real de la excepción: `SkipLimitExceededException(long, Throwable)`.

Listener para auditar lo descartado (`org.springframework.batch.core.listener.SkipListener`, todos los métodos son `default`):

```java
public class AuditorSkips implements SkipListener<Transaccion, Transaccion> {
    @Override public void onSkipInRead(Throwable t) { /* log fila ilegible */ }
    @Override public void onSkipInProcess(Transaccion item, Throwable t) { }
    @Override public void onSkipInWrite(Transaccion item, Throwable t) { }
}
```

---

## 7. Metadatos: propiedades `spring.batch.*` y tablas `BATCH_*`

### Propiedades (Spring Boot 4.1.1 — leídas de `spring-configuration-metadata.json` en los JAR)

| Propiedad | Default | Notas |
|---|---|---|
| `spring.batch.jdbc.initialize-schema` | **`embedded`** | `always` / `embedded` / `never` |
| `spring.batch.jdbc.schema` | `classpath:org/springframework/batch/core/schema-@@platform@@.sql` | Constante `DEFAULT_SCHEMA_LOCATION` de `BatchJdbcProperties` (la tabla de la doc la muestra vacía) |
| `spring.batch.jdbc.platform` | auto-detectado | Reemplaza `@@platform@@` |
| `spring.batch.jdbc.table-prefix` | `BATCH_` | Sólo el prefijo es configurable; nombres de tabla y columnas NO |
| `spring.batch.jdbc.isolation-level-for-create` | `SERIALIZABLE` | **Tipo `Isolation` (enum)** — ver aviso abajo |
| `spring.batch.jdbc.validate-transaction-state` | `true` | |
| `spring.batch.jdbc.continue-on-error` | **`true`** | ✅ verificado en el metadata del JAR (era `false` en Boot 3.x) |
| `spring.batch.job.enabled` | `true` | Ejecutar Job al arrancar |
| `spring.batch.job.name` | `""` | **Obligatorio si hay varios Jobs** |

> 🔴 **`isolation-level-for-create` acepta SÓLO las constantes del enum `Isolation`:** `DEFAULT`, `READ_UNCOMMITTED`, `READ_COMMITTED`, `REPEATABLE_READ`, `SERIALIZABLE`.
> El formato antiguo con prefijo (`ISOLATION_READ_COMMITTED`, típico de Boot 3.x y de muchos tutoriales) **hace fallar el arranque**:
> ```
> Failed to bind properties under 'spring.batch.jdbc.isolation-level-for-create'
>   Reason: No enum constant ...Isolation.ISOLATION_READ_COMMITTED
> ```

`DatabaseInitializationMode`: `ALWAYS` = siempre; `EMBEDDED` = **sólo bases embebidas**; `NEVER` = nunca.

> ⚠️ **Con PostgreSQL/MySQL/Oracle el default `embedded` NO crea nada.** Hay que poner `always` explícitamente, o ejecutar el DDL a mano.

`application.properties` correcto:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/bancoxyz
spring.datasource.username=bancoxyz
spring.datasource.password=secret
spring.datasource.driver-class-name=org.postgresql.Driver

# Sin esto, con PostgreSQL NO se crean las tablas BATCH_*
spring.batch.jdbc.initialize-schema=always
spring.batch.jdbc.table-prefix=BATCH_
spring.batch.jdbc.isolation-level-for-create=READ_COMMITTED

# Hay 3 Jobs: sin esto Boot no sabe cuál lanzar
spring.batch.job.enabled=true
spring.batch.job.name=jobTransaccionesDiarias
```

### Tablas y secuencias (`schema-postgresql.sql` dentro de `spring-batch-core-6.0.5.jar`)

**6 tablas** (verificado en ejecución real: `BATCH_* tables found = 6`):

| Tabla | Columnas |
|---|---|
| `BATCH_JOB_INSTANCE` | `JOB_INSTANCE_ID`, `VERSION`, `JOB_NAME`, `JOB_KEY` |
| `BATCH_JOB_EXECUTION` | `JOB_EXECUTION_ID`, `VERSION`, `JOB_INSTANCE_ID`, `CREATE_TIME`, `START_TIME`, `END_TIME`, `STATUS`, `EXIT_CODE`, `EXIT_MESSAGE`, `LAST_UPDATED` |
| `BATCH_JOB_EXECUTION_PARAMS` | `JOB_EXECUTION_ID`, `PARAMETER_NAME`, `PARAMETER_TYPE`, `PARAMETER_VALUE`, `IDENTIFYING` |
| `BATCH_JOB_EXECUTION_CONTEXT` | `JOB_EXECUTION_ID`, `SHORT_CONTEXT`, `SERIALIZED_CONTEXT` |
| `BATCH_STEP_EXECUTION` | `STEP_EXECUTION_ID`, `VERSION`, `STEP_NAME`, `JOB_EXECUTION_ID`, `CREATE_TIME`, `START_TIME`, `END_TIME`, `STATUS`, `COMMIT_COUNT`, `READ_COUNT`, `FILTER_COUNT`, `WRITE_COUNT`, `READ_SKIP_COUNT`, `WRITE_SKIP_COUNT`, `PROCESS_SKIP_COUNT`, `ROLLBACK_COUNT`, `EXIT_CODE`, `EXIT_MESSAGE`, `LAST_UPDATED` |
| `BATCH_STEP_EXECUTION_CONTEXT` | `STEP_EXECUTION_ID`, `SHORT_CONTEXT`, `SERIALIZED_CONTEXT` |

**3 secuencias:**
```sql
CREATE SEQUENCE BATCH_STEP_EXECUTION_SEQ MAXVALUE 9223372036854775807 NO CYCLE;
CREATE SEQUENCE BATCH_JOB_EXECUTION_SEQ  MAXVALUE 9223372036854775807 NO CYCLE;
CREATE SEQUENCE BATCH_JOB_INSTANCE_SEQ   MAXVALUE 9223372036854775807 NO CYCLE;
```

> 🔴 **Cambio de esquema 5.x → 6.x:** la secuencia `BATCH_JOB_SEQ` fue **renombrada a `BATCH_JOB_INSTANCE_SEQ`**. Verificado en ambos JAR: 5.2.6 crea `BATCH_JOB_SEQ`, 6.0.5 crea `BATCH_JOB_INSTANCE_SEQ`. Un esquema creado con 5.x no sirve tal cual para 6.x.

Las columnas `READ_COUNT` / `FILTER_COUNT` / `*_SKIP_COUNT` de `BATCH_STEP_EXECUTION` son la evidencia cuantitativa de tolerancia a fallos para el informe de entrega.

Fuentes:
- https://docs.spring.io/spring-boot/appendix/application-properties/index.html
- https://docs.spring.io/spring-batch/reference/schema-appendix.html

---

## 8. Escalado: particiones vs multi-thread (ambos compilados)

> ⚠️ **Requisito previo para AMBAS opciones:** necesitas `spring-boot-starter-batch-jdbc`. El `ResourcelessJobRepository` **no es thread-safe** (invalida el multi-thread step) y **no comparte el `ExecutionContext`** entre manager y workers (invalida el particionado).
> Fuente: https://docs.spring.io/spring-batch/reference/job/configuring-repository.html

```java
package cl.duoc.bancoxyz.batch;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.partition.Partitioner;                    // ← 6.x: sin .support
import org.springframework.batch.core.partition.support.TaskExecutorPartitionHandler;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.infrastructure.item.ExecutionContext;
import org.springframework.batch.infrastructure.item.ItemReader;
import org.springframework.batch.infrastructure.item.ItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class EscaladoConfig {

    /** OPCIÓN A — multi-thread step. Variar chunk y concurrencia para buscar el óptimo. */
    @Bean
    public Step pasoMultiThread(JobRepository jobRepository,
                                PlatformTransactionManager txManager,
                                ItemReader<Transaccion> reader,
                                ItemWriter<Transaccion> writer) {
        SimpleAsyncTaskExecutor executor = new SimpleAsyncTaskExecutor("batch-");
        executor.setConcurrencyLimit(4);
        return new StepBuilder("pasoMultiThread", jobRepository)
                .<Transaccion, Transaccion>chunk(500)
                .transactionManager(txManager)
                .reader(reader)
                .writer(writer)
                .taskExecutor(executor)     // AsyncTaskExecutor
                .build();
    }

    /** OPCIÓN B — particionado por rango de cuenta_id (101..150). */
    @Bean
    public Partitioner particionadorCuentas() {
        return gridSize -> {
            Map<String, ExecutionContext> particiones = new HashMap<>();
            int min = 101, max = 150;
            int rango = (max - min + 1) / gridSize;
            for (int i = 0; i < gridSize; i++) {
                ExecutionContext ctx = new ExecutionContext();
                ctx.putInt("minId", min + i * rango);
                ctx.putInt("maxId", (i == gridSize - 1) ? max : min + (i + 1) * rango - 1);
                particiones.put("particion" + i, ctx);
            }
            return particiones;
        };
    }

    @Bean
    public Step pasoParticionado(JobRepository jobRepository,
                                 Step pasoMultiThread,
                                 Partitioner particionadorCuentas) {
        TaskExecutorPartitionHandler handler = new TaskExecutorPartitionHandler();
        handler.setTaskExecutor(new SimpleAsyncTaskExecutor("part-"));
        handler.setStep(pasoMultiThread);
        handler.setGridSize(4);
        return new StepBuilder("pasoParticionado", jobRepository)
                .partitioner(pasoMultiThread.getName(), particionadorCuentas)
                .partitionHandler(handler)
                .build();
    }

    @Bean
    public Job jobEscalado(JobRepository jobRepository, Step pasoParticionado) {
        return new JobBuilder("jobEscalado", jobRepository)
                .start(pasoParticionado)
                .build();
    }
}
```

API de `PartitionStepBuilder` (`javap`): `partitioner(String, Partitioner)`, `step(Step)`, `taskExecutor(TaskExecutor)`, `partitionHandler(PartitionHandler)`, `gridSize(int)`, `splitter(...)`, `aggregator(...)`, `build()`.

**Modelo de concurrencia en 6.0:** cambió de "iteración paralela" a **productor–consumidor con cola interna acotada**. Los números de rendimiento de tutoriales de 5.x no son extrapolables — hay que medir. Con 1000 filas el overhead de hilos probablemente domine; conviene replicar el dataset para que la comparación de parámetros sea significativa.

---

## 9. Otros cambios de 6.x que afectan a un proyecto nuevo

1. **Reubicación masiva de paquetes.** Todo lo del módulo `spring-batch-infrastructure` pasó de `org.springframework.batch.*` a **`org.springframework.batch.infrastructure.*`**:
   - `org.springframework.batch.infrastructure.item.file.FlatFileItemReader`
   - `org.springframework.batch.infrastructure.item.file.builder.FlatFileItemReaderBuilder`
   - `org.springframework.batch.infrastructure.item.database.JdbcBatchItemWriter`
   - `org.springframework.batch.infrastructure.item.file.mapping.{DefaultLineMapper, BeanWrapperFieldSetMapper, FieldSetMapper, RecordFieldSetMapper}`
   - `org.springframework.batch.infrastructure.item.file.transform.{FieldSet, DelimitedLineTokenizer}`
   - `org.springframework.batch.infrastructure.item.{ItemReader, ItemProcessor, ItemWriter, Chunk, ExecutionContext}`
   - `org.springframework.batch.infrastructure.repeat.{CompletionPolicy, RepeatStatus}`
   - `org.springframework.batch.infrastructure.support.transaction.ResourcelessTransactionManager`

   En **core** también se reorganizó: `org.springframework.batch.core.job.Job`, `.core.step.Step`, `.core.job.JobExecution`, `.core.listener.*`, `.core.job.parameters.*`, `.core.repository.explore.*`, `.core.partition.Partitioner` (antes en `.partition.support`). **Ningún import de un tutorial de 5.x funcionará.**

2. **`JobRepository extends JobExplorer`** y **`JobOperator extends JobLauncher`**. `JobExplorer` y `JobLauncher` están **deprecados** (verificado en el bytecode) — inyecta `JobRepository` y `JobOperator`.

3. **`JobParameters` es ahora un `record`** que envuelve `Set<JobParameter<?>>` (antes `Map<String, JobParameter>`); `JobParameter<T>` es un `record` genérico que incluye `name()`, `value()`, `type()`, `identifying()`. Los IDs de entidades pasaron de `Long` a `long` primitivo.

4. **Artefactos batch requieren inyección por constructor.** Cita literal de la guía de migración: *"It is not possible to create batch artefacts (item readers, writers, etc) with default constructors + setters + `afterPropertiesSet` call. Required dependencies must now be specified at construction time."*

5. **Jackson 3** en `JsonItemReader` / `JsonFileItemWriter` / `JacksonExecutionContextStringSerializer` — el paquete es `tools.jackson.databind.json.JsonMapper` (verificado en el JAR). Jackson 2 deprecado.

6. **Namespace XML `batch:` y `batch-integration:` deprecados**; soporte de JUnit 4 en `@SpringBatchTest` deprecado (usa JUnit 5).

7. **Estilo lambda** para configurar readers/writers (nuevos overloads `delimited(Consumer<DelimitedSpec<T>>)` y `fixedLength(Consumer<FixedLengthSpec<T>>)`):
   ```java
   var reader = new FlatFileItemReaderBuilder<Transaccion>()
        .resource(...)
        .delimited(config -> config.delimiter(",").quoteCharacter('"').names("id","fecha","monto","tipo"))
        .targetType(Transaccion.class)
        .build();
   ```
   El estilo clásico `.delimited().delimiter(",").names(...)` sigue funcionando.

8. **Sin restart desde 5.x.** Cita literal: *"it is not possible to restart failed job instances that were launched with v5 using v6. It is expected that failed v5 job instances are either restarted to success or abandoned before the migration to v6 is done."* Irrelevante para proyecto nuevo, pero conviene saberlo.

9. **Nuevos en 6.0:** `CommandLineJobOperator` (`CommandLineJobRunner` queda deprecado, aunque la guía de migración no nombra explícitamente el reemplazo), `JobOperator#recover(JobExecution)`, `StoppableStep`, graceful shutdown, eventos **JFR** (`org.springframework.batch.core.observability.jfr.events.*`), remote step, JSpecify.

Fuentes:
- https://docs.spring.io/spring-batch/reference/whatsnew.html
- https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide

---

## 10. Spring Batch 6.1

`6.1.0-M1` es un **milestone**, no GA. La página "What's new" de la rama 6.1-SNAPSHOT lleva el aviso *"This version is still in development and is not considered stable yet"* y **repite el contenido de 6.0** — no hay lista de cambios 6.1 publicada. **Recomendación: no usarlo en un proyecto evaluado.** Quédate en 6.0.5.

---

## 11. Recomendación final y decisión de versión

### ✅ Opción A (única recomendable) — Spring Boot 4.1.1 + Spring Batch 6.0.5, Java 21

Es la **única combinación con soporte OSS vigente**. Lo más actual y no deprecado.

**Riesgo académico:** casi todo el material didáctico y los tutoriales que encontrará el evaluador están en Batch 5.x, y la sintaxis 6.x se ve "distinta". Documenta explícitamente en el informe de entrega por qué `chunk(200).transactionManager(tm)` es la forma correcta hoy, citando el warning `deprecated and marked for removal` — eso demuestra dominio, no error.

### ⚠️ Opción B (sólo si la asignatura lo exige) — Spring Boot 3.5.16 + Spring Batch 5.2.6, Java 17/21

**Ambas patas están fuera de soporte OSS.** 3.5.16 es *"the last OSS release of the 3.5.x generation"* y 5.2.6 es *"most probably the last OSS release of the 5.2.x generation"*; en ambos casos Spring recomienda subir. Coincide con la mayoría del material de curso, pero es una decisión de compatibilidad didáctica, **no** de vigencia técnica. Si vas por aquí:

- `spring-boot-starter-batch` **sí** trae JDBC (comportamiento clásico).
- La sintaxis correcta es `new StepBuilder("nombre", jobRepository).<I,O>chunk(200, transactionManager)` — **`chunk(int)` a secas está deprecado en 5.2.6**, al revés que en 6.x.
- Imports en `org.springframework.batch.item.*` (sin `.infrastructure`).
- Secuencia `BATCH_JOB_SEQ`.
- Retry con `org.springframework.retry.RetryPolicy` + `.retryLimit(int)` + `.backOffPolicy(...)`.
- `spring.batch.jdbc.isolation-level-for-create` acepta el formato String antiguo (`ISOLATION_READ_COMMITTED`).

**No mezcles snippets de ambas líneas.** Es la fuente de error #1 en este tema.

---

## 12. Puntos donde NO hay certeza (explícito)

1. **Erratas en la doc oficial 6.0.5** — hay una confirmada (`isolationLevelForCreate` como String en la doc vs enum `Isolation` en el JAR). Puede haber otras; en caso de duda, **el JAR manda sobre la doc**. Verifica con `javap` o deja hablar al compilador.
2. **Rendimiento particiones vs multi-thread en 6.0** — el modelo de concurrencia es nuevo (productor-consumidor con cola acotada). No hay benchmarks publicados; hay que medir empíricamente. Con ~1000 filas el overhead de hilos probablemente domine: replica el dataset para que la comparación sea significativa.
3. **Qué versión espera el evaluador** — si la guía de la asignatura menciona `JobBuilderFactory`, está escrita para Spring Batch ≤ 4.x y **nada de lo que hay aquí calzará** con ella; conviene aclararlo antes de entregar.
4. **Contenido exacto de 6.1.0-M1** — sin release notes publicadas al momento de esta consulta.
5. **Fechas exactas de fin de soporte comercial** de las líneas 3.5.x / 5.2.x — la política publicada es "13 meses OSS desde la release" para Boot y "+5 años enterprise para el último minor de cada major", pero la tabla con fechas concretas no está en las páginas públicas consultadas.

---

### URLs oficiales de referencia

- Proyecto: https://spring.io/projects/spring-batch
- Doc 6.0.5 (raíz): https://docs.spring.io/spring-batch/reference/
- Configurar Job: https://docs.spring.io/spring-batch/reference/job/configuring-job.html
- Infraestructura / `@EnableBatchProcessing`: https://docs.spring.io/spring-batch/reference/job/configuring-infrastructure.html
- JobRepository / tablas / prefijo / `ResourcelessJobRepository`: https://docs.spring.io/spring-batch/reference/job/configuring-repository.html
- Configurar Step chunk: https://docs.spring.io/spring-batch/reference/step/chunk-oriented-processing/configuring.html
- Novedades 6: https://docs.spring.io/spring-batch/reference/whatsnew.html
- Esquema de metadatos: https://docs.spring.io/spring-batch/reference/schema-appendix.html
- Guía de migración 6.0: https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide
- Política de soporte Spring Batch: https://github.com/spring-projects/spring-batch/wiki/Support-Policy
- Spring Boot + Spring Batch: https://docs.spring.io/spring-boot/reference/io/spring-batch.html
- Spring Boot how-to Batch: https://docs.spring.io/spring-boot/how-to/batch.html
- Propiedades: https://docs.spring.io/spring-boot/appendix/application-properties/index.html
- Requisitos del sistema: https://docs.spring.io/spring-boot/system-requirements.html
- Release Batch 6.0.5: https://spring.io/blog/2026/08/20/spring-batch-6-0-5-and-6-1-0-M1-available-now/
- Release Batch 6.0.4 / 5.2.6 (fin OSS de 5.2.x): https://spring.io/blog/2026/06/10/spring-batch-6-0-4-and-5-2-6-available-now/
- Release Boot 3.5.16 (fin OSS de 3.5.x): https://spring.io/blog/2026/06/25/spring-boot-3-5-16-available-now/
- Política de soporte Spring: https://spring.io/support-policy/