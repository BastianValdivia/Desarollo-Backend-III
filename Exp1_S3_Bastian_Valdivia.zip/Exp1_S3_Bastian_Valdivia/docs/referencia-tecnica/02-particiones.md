He verificado cada afirmación contra el código fuente de las ramas `5.2.x` y `6.0.x`, los javadoc publicados, la doc de referencia versionada, la guía oficial de migración a 6.0 y el POM de Spring Boot. Encontré **18 defectos** (3 graves, el resto de precisión/atribución). El núcleo técnico del informe es sólido; lo que falla es sobre todo el *respaldo documental*: varias afirmaciones se presentan como "confirmadas por la doc oficial" cuando la doc oficial dice **lo contrario**.

---

# PARTE 1 — ERRORES ENCONTRADOS

## 🔴 GRAVES

### E1. Cita truncada del javadoc de `PartitionStepBuilder#gridSize` — la mitad omitida dice lo contrario
**El informe dice (§2):** *«Y `PartitionStepBuilder#gridSize`: "**A hint** to the splitter about how many step executions are required."»* — presentado como confirmación de que gridSize no limita nada.

**Javadoc real y completo (5.2.x):**
> `A hint to the {@link #splitter(StepExecutionSplitter)} about how many step executions are required. If running locally or remotely through a {@link #taskExecutor(TaskExecutor)} determines precisely the number of step executions in the first attempt at a partition step execution.`

La segunda frase — omitida — afirma que gridSize *«determina con precisión el número de step executions»*, exactamente lo que el informe niega. **Corrección:** el comportamiento observado es correcto (gana el Partitioner), pero hay que decir que **el javadoc es inexacto/obsoleto en este punto**, no que "lo confirma".
🔗 https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/PartitionStepBuilder.java#L124-L135

### E2. «gridSize no limita el nº de particiones» se presenta con respaldo oficial; la doc 5.2.6 lo contradice dos veces
**Texto literal de `scalability.html` 5.2.6:**
> *«Similar to the multi-threaded step's `throttleLimit` method, the `gridSize` method **prevents the task executor from being saturated with requests from a single step**.»*
> *«The `gridSize` attribute **determines the number of separate step executions to create**, so it can be matched to the size of the thread pool in the `TaskExecutor`. Alternatively, it can be set to be larger than the number of threads available, which makes the blocks of work smaller.»*

**Corrección:** la conclusión empírica es correcta y demostrable por código, pero debe etiquetarse como **contradicción documentada entre doc e implementación**, no como consenso.
🔗 https://docs.spring.io/spring-batch/reference/5.2.6/scalability.html

### E3. El snippet publicado de `LineRangePartitioner` **no puede reproducir** el experimento §2 y no es el código ejecutado
El informe marca el snippet como *«(compilado y ejecutado)»* con constructor de 2 argumentos `(totalDataLines, headerLines)` y `int n = Math.max(1, gridSize)`. Con ese código, `n == gridSize` **siempre**: con `gridSize(4)` devuelve 4 particiones, jamás 7.

El código realmente ejecutado (`/tmp/claude-0/.../scratchpad/pt/src/main/java/demo/LineRangePartitioner.java`) tiene **tres** argumentos y un campo `forcedPartitions`:
```java
public LineRangePartitioner(int totalDataLines, int headerLines, int forcedPartitions) { ... }
int n = forcedPartitions > 0 ? forcedPartitions : gridSize;
```
**Corrección:** el `[VERIFICADO]` está aplicado a un snippet editado distinto del ejecutado. Hay que publicar el de 3 argumentos.

---

## 🟠 API / COMPILACIÓN

### E4. Clave del ExecutionContext mal escrita: `read.max.count` → `read.count.max`
**El informe dice (§6.a):** *«El reader persiste `[name].read.count` y `[name].read.max.count`»*.
**Real (`AbstractItemCountingItemStreamItemReader`, 5.2.x):**
```java
private static final String READ_COUNT = "read.count";
private static final String READ_COUNT_MAX = "read.count.max";
```
→ las claves son `[name].read.count` y **`[name].read.count.max`**.
🔗 https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-infrastructure/src/main/java/org/springframework/batch/item/support/AbstractItemCountingItemStreamItemReader.java#L39-L41

### E5. `PartitionStepBuilder.DEFAULT_GRID_SIZE` es `private` — ese código NO compila
```java
private static final int DEFAULT_GRID_SIZE = 6;   // línea 45, private
```
El valor 6 es correcto, pero `PartitionStepBuilder.DEFAULT_GRID_SIZE` no es referenciable. **Además falta un dato crítico que el informe omite:** `AbstractPartitionHandler` declara `protected int gridSize = 1;` → un `TaskExecutorPartitionHandler` construido a mano **sin** `setGridSize()` usa **1**, no 6.
🔗 https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/partition/support/AbstractPartitionHandler.java#L38

### E6. El `String` de `partitioner(workerStepName, …)` **se ignora** cuando se usa `.step(step)`
El informe afirma (§4): *«El parámetro String es el nombre del worker step, usado para construir los nombres de las particiones»*. Cierto solo en particionado remoto. En `PartitionStepBuilder.build()`:
```java
String name = stepName;
if (this.step != null) {
    allowStartIfComplete = this.step.isAllowStartIfComplete();
    name = this.step.getName();          // <-- el Step real PISA el String
}
...
splitter.setStepName(name);
```
En particionado local **gana `workerStep.getName()`**. Escribir mal el String no rompe nada.
🔗 https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/PartitionStepBuilder.java#L185-L200

### E7. Clases de 6.0 sin paquete y en el módulo equivocado
`ChunkTaskExecutorItemWriter` y `RemoteStep` **no están en `spring-batch-core`**, están en `spring-batch-integration`:
`org.springframework.batch.integration.chunk.ChunkTaskExecutorItemWriter` y `org.springframework.batch.integration.remote.RemoteStep`. Además la página *What's New* nombra las funcionalidades ("Local chunking support", "Remote step support") pero **nunca esas clases**.
🔗 https://docs.spring.io/spring-batch/reference/api/org/springframework/batch/integration/chunk/ChunkTaskExecutorItemWriter.html · https://docs.spring.io/spring-batch/reference/api/org/springframework/batch/integration/remote/RemoteStep.html

### E8. `throttleLimit`: falta el nombre de la clase y el valor por defecto
El método eliminado en 6.0 es **`AbstractTaskletStepBuilder#throttleLimit`** (así lo lista la guía de migración), no un método genérico del `StepBuilder`. Y su valor por defecto en 5.2.x era **4**.
🔗 https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide

### E9. El snippet de `Partitioner` omite `@FunctionalInterface`
La interfaz real lleva `@FunctionalInterface` desde 5.x → **un lambda es un Partitioner válido**, dato útil que el informe pierde.
🔗 https://docs.spring.io/spring-batch/docs/5.2.6/api/org/springframework/batch/core/partition/support/Partitioner.html

### E10. Dos beans distintos con el mismo nombre de step `"managerStep"`
`managerStep(...)` y `managerStepB(...)` hacen ambos `new StepBuilder("managerStep", repo)`. Como material de estudio induce a error (colisión de nombre en `BATCH_STEP_EXECUTION`). Renombrar el segundo.

### E11. `MultiResourcePartitioner` devuelve `HashMap` — sin orden garantizado
Las claves son `partition0..partitionN` ✅, pero el `Map` es `new HashMap<>(gridSize)`, así que el orden de iteración no está garantizado (a diferencia del `LinkedHashMap` del propio informe). Irrelevante para la corrección, relevante para logs reproducibles.
🔗 https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/partition/support/MultiResourcePartitioner.java#L69

---

## 🟡 PROVENIENCIA, URLs Y CITAS

### E12. URLs sin versionar y una mal etiquetada
| Informe | Problema | Correcto |
|---|---|---|
| «Javadoc `FlatFileItemReader`: `.../reference/readers-and-writers/flat-files/file-item-reader.html`» | **No es javadoc**, es doc de referencia, y sin versionar → sirve **6.0.5** | Javadoc 5.2.6: `https://docs.spring.io/spring-batch/docs/5.2.6/api/org/springframework/batch/item/file/FlatFileItemReader.html` |
| `.../reference/step/late-binding.html` | Sin versionar → sirve 6.0.5, contradiciendo el propio aviso del informe | `https://docs.spring.io/spring-batch/reference/5.2.6/step/late-binding.html` |
| `.../reference/whatsnew.html` | Sin versionar | `https://docs.spring.io/spring-batch/reference/6.0.5/whatsnew.html` |
| `docs/current/api/...` etiquetado «5.2.6» | Hoy `docs/current/api` **sí sirve 5.2.6** (`<title>Overview (Spring Batch 5.2.6 API)</title>`), pero "current" es un blanco móvil | Fijar `docs/5.2.6/api/...` |

(`https://docs.spring.io/spring-batch/reference/api/...` **sí** sirve 6.0.5 — esa etiqueta del informe es correcta.)

### E13. «Verificado contra la rama `main`» no verifica 6.0
`main` es **6.1.0-SNAPSHOT** (`pom.xml`). Las afirmaciones sobre 6.0 deben venir de la rama `6.0.x`. **Las re-verifiqué contra `6.0.x` y todas resultan correctas**, pero la trazabilidad estaba mal.

### E14. El punto marcado «INCIERTO» sobre renombres de paquete ya no lo es
El informe dice que la página *What's New* «no los documenta explícitamente». Cierto, pero **la Guía de Migración oficial 6.0 sí los documenta textualmente**:
> *«Partitioner, PartitionNameProvider, PartitionStep and StepExecutionAggregator have been moved from `org.springframework.batch.core.partition.support` to `org.springframework.batch.core.partition`»*
> *«Step, StepContribution and StepExecution have been moved from `org.springframework.batch.core` to `org.springframework.batch.core.step`»*
> *«All APIs defined in the spring-batch-infrastructure module were moved from `org.springframework.batch.*` to `org.springframework.batch.infrastructure.*`»*

🔗 https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide

### E15. Afirmación causal sin respaldo sobre por qué "no hubo corrupción"
*«Corrí esto 6 veces sin corrupción de datos — porque `BufferedReader.readLine()` está internamente sincronizado, así que las líneas no se parten.»*
`FlatFileItemReader` mantiene además `private int lineCount` y `private boolean noInput` (no volátiles, no sincronizados) **fuera** del lock del `BufferedReader`, y `doRead()` lee `noInput` y luego llama `lineMapper.mapLine(line, lineCount)`. La ausencia de corrupción en 6 ejecuciones **no es evidencia de seguridad**; es un data race con más superficie de la descrita.
🔗 https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-infrastructure/src/main/java/org/springframework/batch/item/file/FlatFileItemReader.java#L182-L201

### E16. Cita sobre el pool de `DataSource` mal atribuida
No es javadoc: es la doc de referencia y está en la sección **multi-thread step**, no en particionado. Texto exacto: *«…at least as large as the desired number of concurrent threads **in the step**.»* El consejo sigue siendo válido por analogía, pero no está afirmado ahí para particiones.

### E17. Cita de late binding truncada justo donde perdía su propio punto
Real: *«A `Step` bean should not be step-scoped **or job-scoped**. If late binding is needed in a step definition, then the components of that step (tasklet, item reade/writer, **completion policy**, and so on) are the ones that should be scoped instead.»* El informe eliminó "or job-scoped", que es exactamente su regla nº 10.

### E18. Cita de 5.2.6 sobre multi-thread ligeramente alterada
Real: *«the `Step` executes by reading, processing, and writing each chunk of items **(each commit interval)** in a separate thread of execution.»*

---

## ✅ VERIFICADO COMO CORRECTO (no refutable)

- **Versiones:** `spring-boot-dependencies:3.5.16` declara `<spring-batch.version>5.2.6</spring-batch.version>` ✅. Última Boot 3.5.x = 3.5.16 ✅. Última Spring Batch = 6.0.5 ✅. Doc por defecto = 6.0.5 ✅.
- **Tabla completa de renombres 5.2.x→6.0.x (§9): las 9 filas correctas**, verificadas fichero a fichero contra la rama `6.0.x` — incluidas las dos "sin cambio" (`TaskExecutorPartitionHandler` y `SimpleStepExecutionSplitter` siguen en `.support` en 6.0.x) ✅.
- Javadoc de `Partitioner`, `AbstractPartitionHandler#setGridSize`, `MultiResourcePartitioner` («The grid size is ignored», `fileName`, `setKeyName`, `resource.getURL().toExternalForm()`), `SynchronizedItemStreamReader`, `ColumnRangePartitioner` (ambas citas) — **verbatim correctos** ✅.
- `STEP_NAME_SEPARATOR = ":"`, `contexts.size()`, clave `"SimpleStepExecutionSplitter.GRID_SIZE"` ✅.
- `TaskExecutorPartitionHandler.doHandle` y el fallo silencioso ante `TaskRejectedException` ✅.
- `PartitionStepBuilder.build()` cae a `SyncTaskExecutor` ✅; `.partitionHandler()` cortocircuita `gridSize`/`taskExecutor` ✅.
- `StepBuilder` tiene exactamente 2 sobrecargas de `partitioner`; `PartitionStepBuilder` exactamente 1 ✅.
- `.<String,String>partitioner(...)` compila (lo recompilé con `javac -Xlint:all`) y la doc oficial realmente lo usa ✅.
- `"Subclasses are inherently not thread-safe"`, `read()`, `Assert.isTrue(count > 0, "count must be greater than zero")`, restauración de `maxItemCount` en `open()` ✅.
- `WriterNotOpenException("Writer must be open before it can be written to")` en `AbstractFileItemWriter.write` ✅.
- **Todos** los métodos de builder usados existen en 5.2.6 (`FlatFileItemReaderBuilder.maxItemCount/linesToSkip`, `FlatFileItemWriterBuilder.delimited().delimiter().names()`, `JdbcBatchItemWriterBuilder.beanMapped/assertUpdates`, `JdbcPagingItemReaderBuilder.*`, `AbstractSqlPagingQueryProvider.set*Clause` — que además tolera el keyword inicial vía `removeKeyWord`) ✅.
- Citas de 6.0.5 (`scalability.html` y `whatsnew.html`) — **verbatim correctas** ✅.
- *«Many people prefer to call the manager step step1:manager for consistency»* ✅ verbatim.

---
---

# PARTE 2 — INFORME CORREGIDO Y CONSOLIDADO

# Particionado local (single-JVM) en Spring Batch 5.2.6

**Entorno de referencia:** Spring Batch **5.2.6**, traído por Spring Boot **3.5.16** (verificado: `spring-boot-dependencies-3.5.16.pom` declara `<spring-batch.version>5.2.6</spring-batch.version>`), JDK 21.
Marcas usadas: `[VERIFICADO]` = ejecutado; `[FUENTE]` = comprobado contra código fuente o javadoc oficial; `[NO EJECUTADO]` = solo API verificada.

> ### ⚠️ AVISO DE VERSIÓN
> `docs.spring.io/spring-batch/reference/` **sirve por defecto Spring Batch 6.0.5**, que renombró paquetes y cambió la semántica de concurrencia. Tu proyecto usa **5.2.6**. **Fija siempre la versión en la URL**: `https://docs.spring.io/spring-batch/reference/5.2.6/…`
> Nota adicional: el javadoc legado en `docs.spring.io/spring-batch/docs/current/api/` **hoy sirve 5.2.6**, pero "current" es un blanco móvil — usa `docs/5.2.6/api/…`. El javadoc en `reference/api/` sirve **6.0.5**.

---

## 1. La interfaz `Partitioner`

| Versión | Paquete |
|---|---|
| 5.2.x | `org.springframework.batch.core.partition.support.Partitioner` |
| 6.0.x | `org.springframework.batch.core.partition.Partitioner` |

```java
@FunctionalInterface                       // <-- un lambda es un Partitioner valido
public interface Partitioner {
    Map<String, ExecutionContext> partition(int gridSize);
}
```

Javadoc oficial `[FUENTE]`:
> *"Create a set of distinct ExecutionContext instances together with a unique identifier for each one. The identifiers should be short, mnemonic values, and only have to be unique within the return value (e.g. use an incrementer). @param gridSize the size of the map to return."*

### Dos niveles de claves (fuente constante de confusión)

| Nivel | Qué es | Quién lo fija | Ejemplo `[VERIFICADO]` |
|---|---|---|---|
| Clave del `Map<String,…>` | **sufijo** del nombre de la partición | tú | `"partition0"` |
| Nombre real del StepExecution | `nombreDelStepWorker + ":" + clave` | Spring Batch | `"workerStep:partition0"` |
| Claves dentro del `ExecutionContext` | parámetros de negocio | tú, libremente | `minValue`, `maxValue`, … |

Separador *hardcodeado* en `SimpleStepExecutionSplitter` `[FUENTE]`:
```java
private static final String STEP_NAME_SEPARATOR = ":";
String stepName = this.stepName + STEP_NAME_SEPARATOR + context.getKey();
```

> **⚠️ Corrección importante respecto a de dónde sale `this.stepName`.**
> No sale del `String` que pasas a `.partitioner("workerStep", …)` cuando usas `.step(workerStep)`. En `PartitionStepBuilder.build()`:
> ```java
> String name = stepName;
> if (this.step != null) { name = this.step.getName(); }   // el Step REAL pisa el String
> splitter.setStepName(name);
> ```
> En particionado **local gana `workerStep.getName()`**. El `String` solo manda en particionado **remoto** (sin instancia de `Step`). Aun así, pásalo igual al nombre real: es lo legible.

### ¿`minValue`/`maxValue` o `start`/`end`?

**No hay ninguna clave obligatoria.** El `ExecutionContext` es, según la doc oficial 5.2.6, *"just a bag of name-value pairs"*. `minValue`/`maxValue` es la **convención** del `ColumnRangePartitioner` de los samples oficiales, cuyo javadoc dice: *"The execution context values will have keys `minValue` and `maxValue` specifying the range of values to consider in each partition."* `[FUENTE]`

Úsala por convención, y añade las que quieras (`linesToSkip`, `maxItemCount`, `partitionName`…).

Otras convenciones oficiales — `MultiResourcePartitioner` `[FUENTE]`:
- clave por defecto **`fileName`** (configurable con `setKeyName`);
- nombra las particiones `partition0..partitionN`;
- javadoc: *"The grid size is ignored."*;
- el valor guardado **no es una ruta**, es `resource.getURL().toExternalForm()` (p.ej. `file:/home/data/uno.csv`);
- devuelve un `HashMap`, así que **el orden de iteración no está garantizado** (usa `LinkedHashMap` en los tuyos si quieres logs reproducibles).

---

## 2. `gridSize`: la doc y la implementación **se contradicen** `[VERIFICADO + FUENTE]`

Esta es la respuesta directa a *"¿qué pasa si gridSize y el nº de particiones no coinciden?"*.

### Lo que dice la documentación oficial 5.2.6 (y que es INEXACTO)

> *"Similar to the multi-threaded step's `throttleLimit` method, the `gridSize` method **prevents the task executor from being saturated** with requests from a single step."*
> *"The `gridSize` attribute **determines the number of separate step executions to create**, so it can be matched to the size of the thread pool in the `TaskExecutor`."*
> Javadoc `PartitionStepBuilder#gridSize`: *"A hint to the splitter about how many step executions are required. **If running locally or remotely through a taskExecutor determines precisely the number of step executions in the first attempt at a partition step execution.**"*

### Lo que hace realmente el código `[FUENTE]`

`AbstractPartitionHandler.handle()` pasa `gridSize` **solo** como argumento a `split(...)`, y ahí termina su papel:
```java
public Collection<StepExecution> handle(StepExecutionSplitter stepSplitter, StepExecution managerStepExecution) {
    Set<StepExecution> stepExecutions = stepSplitter.split(managerStepExecution, gridSize);
    return doHandle(managerStepExecution, stepExecutions);   // itera sobre TODO lo devuelto
}
```
Y `SimpleStepExecutionSplitter.split()` itera sobre **lo que devolvió tu Partitioner**, no sobre `gridSize`:
```java
Map<String, ExecutionContext> contexts = getContexts(stepExecution, gridSize);
Set<StepExecution> set = new HashSet<>(contexts.size());
for (Entry<String, ExecutionContext> context : contexts.entrySet()) {   // <-- la evidencia real
    String stepName = this.stepName + STEP_NAME_SEPARATOR + context.getKey();
    ...
}
```

### Prueba ejecutada `[VERIFICADO]`
`gridSize(4)` + Partitioner forzado a devolver **7** particiones, pool de **4** hilos:
```
>>> Partitioner.partition() invocado con gridSize=4 ; voy a devolver 7 particiones
particiones ejecutadas = 7
instancias distintas de reader creadas = 7
  workerStep:partition0 -> items=143 thread=part-3
  ...
  workerStep:partition6 -> items=142 thread=part-4
TOTAL items procesados = 1000 (esperado 1000)
hilos distintos = [part-1, part-2, part-3, part-4]
```
7 particiones sobre 4 hilos. Ni error, ni warning, ni truncamiento.

### Conclusiones sobre `gridSize`
- **Gana siempre el Partitioner.** La doc que dice lo contrario está desactualizada respecto a `TaskExecutorPartitionHandler`.
- `gridSize` **NO** limita la concurrencia. La concurrencia la fija el pool del `TaskExecutor`.
- `gridSize` **NO** limita el número de particiones.
- Su único uso real: que tu Partitioner lo lea para decidir cuántos trozos hacer (patrón `ColumnRangePartitioner`).
- **Valores por defecto** (¡son dos distintos!):
  - vía builder: `PartitionStepBuilder` usa **6** (constante `private static final int DEFAULT_GRID_SIZE = 6` — **no referenciable desde tu código**);
  - handler construido a mano: `AbstractPartitionHandler` declara `protected int gridSize = 1;` → si olvidas `setGridSize()`, es **1**.
- En **reinicio**, el gridSize original se persiste en el ExecutionContext del manager bajo la clave literal `"SimpleStepExecutionSplitter.GRID_SIZE"` y se reutiliza, ignorando el nuevo:
  ```java
  String key = SimpleStepExecutionSplitter.class.getSimpleName() + ".GRID_SIZE";
  int splitSize = (int) context.getLong(key, gridSize);
  context.putLong(key, splitSize);
  ```

---

## 3. `PartitionHandler` / `TaskExecutorPartitionHandler`

`TaskExecutorPartitionHandler` sigue en `org.springframework.batch.core.partition.support` **en 5.2.x y en 6.0.x** `[FUENTE]`. Setters relevantes: `setStep(Step)`, `setTaskExecutor(TaskExecutor)`, `setGridSize(int)` (heredado de `AbstractPartitionHandler`).

### Trampa grave nº1: no limita la concurrencia, lanza TODO de golpe

Código real de `doHandle` `[FUENTE]`:
```java
for (final StepExecution stepExecution : partitionStepExecutions) {
    final FutureTask<StepExecution> task = createTask(step, stepExecution);
    try {
        taskExecutor.execute(task);      // <-- las envia TODAS, sin throttling
        tasks.add(task);
    } catch (TaskRejectedException e) {
        ExitStatus exitStatus = ExitStatus.FAILED
            .addExitDescription("TaskExecutor rejected the task for this step.");
        stepExecution.setStatus(BatchStatus.FAILED);   // <-- FALLA EN SILENCIO
        stepExecution.setExitStatus(exitStatus);
        result.add(stepExecution);
    }
}
for (Future<StepExecution> task : tasks) { result.add(task.get()); }
```

**Prueba ejecutada** `[VERIFICADO]` con `ThreadPoolTaskExecutor(corePoolSize=2, queueCapacity=1)` y 20 particiones:
```
### JOB status=FAILED
###   workerStep:partition0  status=FAILED    read=0  write=0  exitDesc='TaskExecutor rejected the task for this step.'
###   workerStep:partition1  status=COMPLETED read=50 write=50 exitDesc=''
...
particiones rechazadas: 17 de 20
TOTAL items procesados = 150 (esperado 1000)
```
17 de 20 particiones marcadas FAILED sin procesar nada y **sin excepción visible en el log**. Solo el manager falló con `JobExecutionException: Partition handler returned an unsuccessful step`.

**Regla práctica:** con `ThreadPoolTaskExecutor`, o `queueCapacity` ≥ nº de particiones, o `CallerRunsPolicy`, o usa `SimpleAsyncTaskExecutor` con `concurrencyLimit`. Nunca una cola acotada menor que el nº de particiones.

### Trampa grave nº2: sin `.taskExecutor(...)` no hay paralelismo `[VERIFICADO]`

`PartitionStepBuilder.build()` `[FUENTE]`:
```java
TaskExecutorPartitionHandler partitionHandler = new TaskExecutorPartitionHandler();
partitionHandler.setStep(this.step);
if (taskExecutor == null) {
    taskExecutor = new SyncTaskExecutor();   // <-- SECUENCIAL, sin avisar
}
```
Prueba con 6 particiones y sin `.taskExecutor(...)`:
```
particiones ejecutadas = 6
TOTAL items procesados = 1000 (esperado 1000)
hilos distintos = [main]
```
Funcionalmente correcto, **cero paralelismo, cero warnings**. Arruinaría cualquier medición comparativa sin que lo notes.

### Trampa nº3: `partitionHandler(...)` explícito anula `gridSize` y `taskExecutor` del builder
Si llamas a `.partitionHandler(h)`, la rama `if (partitionHandler != null)` cortocircuita y `.gridSize(...)` / `.taskExecutor(...)` del builder **se ignoran en silencio**. Configúralos sobre el handler (y recuerda: su default es **1**).

---

## 4. `StepBuilder.partitioner(...)`: las dos sobrecargas reales `[FUENTE]`

```java
public PartitionStepBuilder partitioner(String stepName, Partitioner partitioner) {
    return new PartitionStepBuilder(this).partitioner(stepName, partitioner);
}

public PartitionStepBuilder partitioner(Step step) {
    return new PartitionStepBuilder(this).step(step);   // NO fija Partitioner
}
```
La segunda **no** recibe Partitioner: sirve para arrancar la cadena y luego añadir `.partitioner(...)` o `.splitter(...)`. En `PartitionStepBuilder` existe **una sola** sobrecarga: `partitioner(String workerStepName, Partitioner)`.

### Nota sobre `.<String, String>partitioner(...)` en la doc oficial
La doc muestra `.<String, String>partitioner("step1", partitioner())`. **`partitioner` NO es un método genérico.** Compila igualmente porque Java permite e ignora argumentos de tipo explícitos en métodos no genéricos `[VERIFICADO con javac -Xlint:all]`. Es un resto heredado: **omítelo**.

### Manager step vs worker step

```java
// WORKER: step normal. NUNCA @StepScope sobre el Step (los @StepScope van en sus componentes)
@Bean
public Step workerStep(JobRepository repo, PlatformTransactionManager tx,
                       FlatFileItemReader<Transaccion> partReader,
                       FlatFileItemWriter<Transaccion> partWriter) {
    return new StepBuilder("workerStep", repo)
            .<Transaccion, Transaccion>chunk(100, tx)
            .reader(partReader)
            .writer(partWriter)
            .build();
}

// MANAGER, forma A - el builder construye el handler (RECOMENDADA)
@Bean
public Step managerStep(JobRepository repo, Partitioner txPartitioner,
                        Step workerStep, TaskExecutor partTaskExecutor) {
    return new StepBuilder("managerStep", repo)
            .partitioner("workerStep", txPartitioner)   // nombre del WORKER (informativo en local)
            .step(workerStep)                           // <-- este nombre es el que manda
            .gridSize(4)
            .taskExecutor(partTaskExecutor)
            .build();
}

// MANAGER, forma B - handler explicito (gridSize/taskExecutor van en el HANDLER)
@Bean
public Step managerStepB(JobRepository repo, Partitioner txPartitioner,
                         PartitionHandler partitionHandler) {
    return new StepBuilder("managerStepB", repo)      // nombre DISTINTO del de la forma A
            .partitioner("workerStep", txPartitioner)
            .partitionHandler(partitionHandler)
            .build();
}

@Bean
public PartitionHandler partitionHandler(Step workerStep, TaskExecutor partTaskExecutor) {
    TaskExecutorPartitionHandler h = new TaskExecutorPartitionHandler();
    h.setStep(workerStep);
    h.setTaskExecutor(partTaskExecutor);
    h.setGridSize(4);            // OBLIGATORIO: sin esto vale 1, no 6
    return h;
}
```

El `Job` arranca con el **manager**, nunca con el worker:
```java
@Bean
public Job partitionJob(JobRepository repo, Step managerStep) {
    return new JobBuilder("partitionJob", repo).start(managerStep).build();
}
```

Convención de la doc oficial: *"Many people prefer to call the manager step `step1:manager` for consistency."* (curiosamente, el ejemplo Java de esa misma página usa `"step1.manager"`, con punto).

---

## 5. `@StepScope` y la inyección de valores de partición

### Por qué hace falta
Regla oficial: *"Using a scope of `Step` is **required** to use late binding, because the bean cannot actually be instantiated until the `Step` starts, to let the attributes be found."* `[FUENTE]`

Sin `@StepScope` el bean es singleton: se construye al arrancar el contexto, cuando no existe `StepExecution` ni `stepExecutionContext`. Con `@StepScope`, Spring inyecta un **proxy** y crea **una instancia nueva por cada StepExecution** — es decir, **un reader por partición**, que es exactamente lo que hace segura la lectura concurrente.
`[VERIFICADO]` con 7 particiones: `instancias distintas de reader creadas = 7`.

### Qué error da exactamente si falta `[VERIFICADO]`
```
org.springframework.beans.factory.UnsatisfiedDependencyException: Error creating bean with name
'partReader' ... Unsatisfied dependency expressed through method 'partReader' parameter 0:
Expression parsing failed
Caused by: org.springframework.expression.spel.SpelEvaluationException: EL1008E: Property or field
'stepExecutionContext' cannot be found on object of type
'org.springframework.beans.factory.config.BeanExpressionContext'
```
**`EL1008E` sobre `BeanExpressionContext` = te falta `@StepScope`.** Falla al arrancar (fail-fast): el caso benigno.

### Reglas adicionales de la doc oficial `[FUENTE]`
1. **Tipo de retorno al menos `ItemStream`:** *"the return type of the bean definition method should be at least `ItemStream`. This is required so that Spring Batch correctly creates a proxy that implements this interface, and therefore honors its contract by calling `open`, `update` and `close` methods as expected."* Por eso se declara `FlatFileItemReader<Transaccion>` y no `ItemReader<Transaccion>`.
2. **Un `Step` nunca lleva scope:** *"A `Step` bean should not be step-scoped **or job-scoped**. If late binding is needed in a step definition, then the components of that step (tasklet, item reader/writer, completion policy, and so on) are the ones that should be scoped instead."*
3. **Nada de `@JobScope` en steps particionados:** *"Spring Batch does not control the threads spawned in these use cases, so it is not possible to set them up correctly to use such beans. Hence, we do not recommend using job-scoped beans in multi-threaded or partitioned steps."*

### Trampa nº4: envolver el writer en un lambda rompe el `ItemStream` `[VERIFICADO]`
```
org.springframework.batch.item.WriterNotOpenException: Writer must be open before it can be written to
	at org.springframework.batch.item.support.AbstractFileItemWriter.write(AbstractFileItemWriter.java:226)
```
Al envolverlo en un lambda, el step ve un `ItemWriter` pelado, no un `ItemStream`, y nunca llama a `open()`. Si necesitas envolver: registra el delegado con `.stream(delegate)` o implementa `ItemStreamWriter` en el wrapper. Para contar, usa un `StepExecutionListener` y `stepExecution.getWriteCount()`.

---

## 6. Particionar un CSV plano vs una tabla

### 6.a — Particionar UN ÚNICO CSV por rango de líneas: SÍ se puede `[VERIFICADO]`

No existe Partitioner oficial para esto (los oficiales son `SimplePartitioner`, `MultiResourcePartitioner` y el `ColumnRangePartitioner` de samples, que es JDBC). Se apoya en dos propiedades del reader:

- `setLinesToSkip(int)` — líneas saltadas desde el principio (`FlatFileItemReader`).
- `setMaxItemCount(int)` — heredado de `AbstractItemCountingItemStreamItemReader`. **Es un CONTADOR de items a leer, no un índice final** `[FUENTE]`:
  ```java
  if (currentItemCount >= maxItemCount) { return null; }
  currentItemCount++;
  ```
  y `setMaxItemCount` valida `Assert.isTrue(count > 0, "count must be greater than zero")`.

Fórmula para un CSV con cabeceras:
- `linesToSkip = cabeceras + offsetDeLaParticion`
- `maxItemCount = númeroDeLíneasDeEstaPartición`

**Partitioner — este es el código realmente compilado y ejecutado `[VERIFICADO]`:**
```java
package demo;

import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.batch.core.partition.support.Partitioner;  // 5.2.x
import org.springframework.batch.item.ExecutionContext;               // 5.2.x

/** Particiona UN solo CSV plano por rangos de lineas. */
public class LineRangePartitioner implements Partitioner {

    private final int totalDataLines;    // sin contar cabeceras
    private final int headerLines;
    private final int forcedPartitions;  // 0 => usar gridSize

    public LineRangePartitioner(int totalDataLines, int headerLines, int forcedPartitions) {
        this.totalDataLines   = totalDataLines;
        this.headerLines      = headerLines;
        this.forcedPartitions = forcedPartitions;
    }

    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {
        // forcedPartitions permite demostrar que el Partitioner gana sobre gridSize
        int n = forcedPartitions > 0 ? forcedPartitions : Math.max(1, gridSize);
        int chunk = (int) Math.ceil((double) totalDataLines / n);
        Map<String, ExecutionContext> map = new LinkedHashMap<>();
        int number = 0;
        for (int start = 0; start < totalDataLines; start += chunk) {
            int count = Math.min(chunk, totalDataLines - start);
            ExecutionContext ctx = new ExecutionContext();
            ctx.putInt("minValue", start);                    // convencion oficial
            ctx.putInt("maxValue", start + count - 1);
            ctx.putInt("linesToSkip", headerLines + start);   // lo que consume el reader
            ctx.putInt("maxItemCount", count);
            ctx.putString("partitionName", "partition" + number);
            map.put("partition" + number, ctx);
            number++;
        }
        return map;
    }
}
```

**Reader `@StepScope` `[VERIFICADO]`:**
```java
@Bean
@StepScope
public FlatFileItemReader<Transaccion> partReader(
        @Value("#{stepExecutionContext['linesToSkip']}") Integer linesToSkip,
        @Value("#{stepExecutionContext['maxItemCount']}") Integer maxItemCount,
        @Value("#{stepExecutionContext['partitionName']}") String partitionName) {

    return new FlatFileItemReaderBuilder<Transaccion>()
            .name("txReader-" + partitionName)   // nombre UNICO por particion
            .resource(new FileSystemResource("data/semana_3/transacciones.csv"))
            .linesToSkip(linesToSkip)
            .maxItemCount(maxItemCount)
            .delimited().names("id", "fecha", "monto", "tipo")
            .fieldSetMapper(fs -> new Transaccion(
                    fs.readString("id"), fs.readString("fecha"),
                    fs.readString("monto"), fs.readString("tipo")))
            .build();
}
```

**Resultado real** sobre 1000 filas + cabecera, `gridSize=4`, pool de 4:
```
>>> READER partition0 (stepName=workerStep:partition0) linesToSkip=1   maxItemCount=250 thread=part-3
>>> READER partition1 (stepName=workerStep:partition1) linesToSkip=251 maxItemCount=250 thread=part-4
>>> READER partition2 (stepName=workerStep:partition2) linesToSkip=501 maxItemCount=250 thread=part-1
>>> READER partition3 (stepName=workerStep:partition3) linesToSkip=751 maxItemCount=250 thread=part-2
TOTAL items procesados = 1000 (esperado 1000)
total=1000  unicos=1000  min=1  max=1000  faltantes/duplicados: (ninguno)
```

**Caveats honestos:**
- **Coste O(n·p):** cada partición reabre el fichero y lo lee desde el principio descartando `linesToSkip` líneas. Con 4 particiones lees el fichero 4 veces. Para 1000 filas es irrelevante; para millones deja de compensar.
- **Necesitas el total de líneas de antemano** (`Files.lines(path).count()` en el Partitioner, o job parameter).
- **`.name()` único por partición** si `saveState=true` (por defecto). El reader persiste **`[name].read.count`** y **`[name].read.count.max`** en el ExecutionContext. Nombres repetidos entre particiones **no** colisionan (cada partición tiene su propio contexto), pero un nombre único hace el metadata legible.
- **En reinicio, `maxItemCount` se restaura desde el ExecutionContext y pisa el valor inyectado por `@Value`** `[FUENTE, NO EJECUTADO]`. `open()` lo hace solo si `saveState=true`:
  ```java
  if (!isSaveState()) { return; }
  if (executionContext.containsKey(getExecutionContextKey(READ_COUNT_MAX))) {
      maxItemCount = executionContext.getInt(getExecutionContextKey(READ_COUNT_MAX));
  }
  ```
  Si cambias el número de particiones entre ejecuciones de la **misma** JobInstance, arrastrarás valores viejos. Si tu Job debe ser reiniciable, pruébalo explícitamente.

### 6.b — Alternativa preferible para archivos: `MultiResourcePartitioner`

Sin coste O(n·p) si puedes trocear en N ficheros:
```java
@Bean
public Partitioner filePartitioner(
        @Value("file:data/semana_3/transacciones-*.csv") Resource[] resources) {
    MultiResourcePartitioner p = new MultiResourcePartitioner();
    p.setResources(resources);
    return p;   // claves: partition0..N ; contexto: fileName = URL del recurso
}

@Bean
@StepScope
public FlatFileItemReader<Transaccion> fileReader(
        @Value("#{stepExecutionContext['fileName']}") String fileUrl) throws Exception {
    return new FlatFileItemReaderBuilder<Transaccion>()
            .name("fileReader")
            .resource(new UrlResource(fileUrl))   // OJO: es una URL, no una ruta
            .linesToSkip(1)
            .delimited().names("id", "fecha", "monto", "tipo")
            .fieldSetMapper(fs -> new Transaccion(fs.readString("id"), fs.readString("fecha"),
                    fs.readString("monto"), fs.readString("tipo")))
            .build();
}
```

### 6.c — Particionar una TABLA: `ColumnRangePartitioner` + `JdbcPagingItemReader`

Caso natural para el **Job 2** (`cuenta_id` 101..150) y el **Job 3** (101..120). Código del sample oficial, con imports 5.2.x `[FUENTE]`:
```java
@Override
public Map<String, ExecutionContext> partition(int gridSize) {
    int min = jdbcTemplate.queryForObject("SELECT MIN(" + column + ") from " + table, Integer.class);
    int max = jdbcTemplate.queryForObject("SELECT MAX(" + column + ") from " + table, Integer.class);
    int targetSize = (max - min) / gridSize + 1;

    Map<String, ExecutionContext> result = new HashMap<>();
    int number = 0, start = min, end = start + targetSize - 1;

    while (start <= max) {
        ExecutionContext value = new ExecutionContext();
        result.put("partition" + number, value);
        if (end >= max) { end = max; }
        value.putInt("minValue", start);
        value.putInt("maxValue", end);
        start += targetSize;
        end += targetSize;
        number++;
    }
    return result;
}
```

Reader `[NO EJECUTADO — API verificada contra el fuente/javadoc de 5.2.6]`:
```java
@Bean
@StepScope
public JdbcPagingItemReader<Cuenta> cuentaReader(
        DataSource ds,
        @Value("#{stepExecutionContext['minValue']}") Integer minValue,
        @Value("#{stepExecutionContext['maxValue']}") Integer maxValue) {

    PostgresPagingQueryProvider qp = new PostgresPagingQueryProvider();
    qp.setSelectClause("SELECT cuenta_id, nombre, saldo, edad, tipo");   // el keyword se tolera
    qp.setFromClause("FROM cuentas");
    qp.setWhereClause("WHERE cuenta_id >= :minValue AND cuenta_id <= :maxValue");
    qp.setSortKeys(Map.of("cuenta_id", Order.ASCENDING));   // obligatorio y UNICO

    return new JdbcPagingItemReaderBuilder<Cuenta>()
            .name("cuentaReader")
            .dataSource(ds)
            .queryProvider(qp)
            .parameterValues(Map.of("minValue", minValue, "maxValue", maxValue))
            .pageSize(100)
            .rowMapper((rs, i) -> new Cuenta(rs.getInt("cuenta_id"), rs.getString("nombre"),
                    rs.getBigDecimal("saldo"), rs.getObject("edad", Integer.class),
                    rs.getString("tipo")))
            .build();
}
```
> `AbstractSqlPagingQueryProvider.setSelectClause/setFromClause/setWhereClause` aplican `removeKeyWord("select"|"from"|"where", …)`, así que incluir el keyword inicial es correcto.
> Nota: `JdbcPagingItemReader` extiende `AbstractPagingItemReader`, que extiende `AbstractItemCountingItemStreamItemReader` → **tampoco es thread-safe**; también necesita una instancia por partición.

**Advertencia sobre tus datos reales:** `intereses.csv` tiene 9 filas 100% duplicadas y `cuenta_id` va solo de 101 a 150 (~20 filas por cuenta). El javadoc del `ColumnRangePartitioner` avisa: *"Works best if the values are **uniformly distributed** (e.g. auto-generated primary key values)."* Particiona por el **PK autogenerado** de la tabla de staging, no por `cuenta_id`.

---

## 7. Thread-safety: por qué particiones SÍ y multi-thread NO

### Por qué `FlatFileItemReader` no es thread-safe
Javadoc de `AbstractItemCountingItemStreamItemReader` (superclase) `[FUENTE]`:
> *"Subclasses are inherently **not** thread-safe."*

El sitio de la carrera, en `read()`:
```java
if (currentItemCount >= maxItemCount) { return null; }
currentItemCount++;                      // <-- NO atomico, sin sincronizar
T item = doRead();
```
`currentItemCount++` es read-modify-write sobre un `int` normal, y es lo que se persiste como `[name].read.count` para el reinicio.

> **Y no es el único estado compartido.** `FlatFileItemReader` mantiene además `private int lineCount` y `private boolean noInput`, no volátiles y no sincronizados, usados en `doRead()`:
> ```java
> if (noInput) { return null; }
> String line = readLine();
> return lineMapper.mapLine(line, lineCount);
> ```
> Es decir: hay más superficie de carrera que el contador (números de línea erróneos en `FlatFileParseException`, terminación prematura).

### `[VERIFICADO]` Un step multi-thread SÍ llama a `read()` concurrentemente (en 5.2.6)
```
======== MULTI-THREAD STEP (taskExecutor) ========
synchronizedReader = false
concurrencia MAXIMA observada dentro de read() = 4
hilos que llamaron a read() = [mt-1, mt-2, mt-3, mt-4]
items escritos = 1000 / esperado 1000 ; DUPLICADOS = 0 ; PERDIDOS = 0
```
En 6 ejecuciones no se corrompieron datos, pero **eso no demuestra seguridad**: es un data race, y su no-manifestación no es garantía. Lo que sí se reprodujo es la corrupción del contador, con `maxItemCount=500`:
```
run1: 500 (ok)   run2: 500 (ok)   run3: 500 (ok)
run4: 501  <<< LIMITE VIOLADO
run5: 500 (ok)
```
**Punto pedagógico clave: falla ~1 de cada 5 veces.** Un incremento perdido lee un item de más. El peor tipo de bug: "funciona" en la demo y falla en la corrección.

Con `SynchronizedItemStreamReader` envolviendo el mismo reader: **8 de 8 ejecuciones correctas** y `concurrencia MAXIMA = 1`.

### Por qué con PARTICIONES sí funciona
Porque **no hay estado compartido**. Con `@StepScope`, cada `StepExecution` de partición obtiene su **propia instancia** de `FlatFileItemReader`, con su propio `currentItemCount`, su propio `lineCount`, su propio `BufferedReader` y su propio fichero abierto. `[VERIFICADO]`: 7 particiones → 7 instancias distintas.

| | Step multi-thread (`.taskExecutor()`) | Step particionado |
|---|---|---|
| Instancias de reader | **1 compartida** entre todos los hilos | **1 por partición** vía `@StepScope` |
| `currentItemCount` / `lineCount` | compartidos → *race* | privados por partición |
| Necesita sincronizar | Sí (`SynchronizedItemStreamReader`) | No |
| ¿`linesToSkip`/`maxItemCount` para dividir? | **No** — el contador es lo que se corrompe | **Sí** |
| Reinicio granular | Todo o nada | Solo las particiones FAILED |
| Metadata en BD | 1 StepExecution | 1 StepExecution por partición (auditable) |

Argumento fuerte para la evaluación: **el particionado te da trazabilidad por partición en `BATCH_STEP_EXECUTION`**, justo lo que pide un requisito de "manejo de errores y tolerancia a fallos".

Si quieres comparar multi-thread (el enunciado dice "particiones **O** multi-thread"), la única forma correcta es:
```java
@Bean
public SynchronizedItemStreamReader<Transaccion> safeReader(FlatFileItemReader<Transaccion> raw) {
    SynchronizedItemStreamReader<Transaccion> s = new SynchronizedItemStreamReader<>();
    s.setDelegate(raw);
    return s;
}
```
…asumiendo su javadoc: *"if reprocessing an item is problematic then using this will make a job not restartable."* Y ojo: serializar `read()` elimina buena parte del beneficio si la lectura es el cuello de botella.

---

## 8. Escribir la salida sin que las particiones se pisen

### Opción A — un fichero por partición (`@StepScope` en el writer) `[VERIFICADO]`
```java
@Bean
@StepScope
public FlatFileItemWriter<Transaccion> partWriter(
        @Value("#{stepExecutionContext['partitionName']}") String partitionName) {
    return new FlatFileItemWriterBuilder<Transaccion>()
            .name("txWriter-" + partitionName)
            .resource(new FileSystemResource("target/out/salida-" + partitionName + ".csv"))
            .delimited().delimiter(",").names("id", "fecha", "monto", "tipo")
            .build();
}
```
Resultado real: 4 ficheros de 250 líneas, 1000 ids únicos sin solapes ni pérdidas.

Alternativa para el nombre: `@Value("#{stepExecution.stepName}")` devuelve `workerStep:partition0` `[VERIFICADO]` — funciona, pero los dos puntos son incómodos como nombre de fichero. Mejor un `partitionName` limpio en el ExecutionContext.

**Nunca** apuntes dos writers `@StepScope` al mismo `Resource`: `FlatFileItemWriter` abre y trunca el fichero en `open()` (salvo `append=true`); las particiones se pisarían.

Si necesitas un único fichero final, añade un **step de agregación posterior** al manager (un `Tasklet` que concatene), o usa `MultiResourceItemReader` en un step siguiente.

### Opción B — escribir a BD (recomendada para tu caso)
```java
@Bean
public JdbcBatchItemWriter<Cuenta> cuentaWriter(DataSource ds) {
    return new JdbcBatchItemWriterBuilder<Cuenta>()
            .dataSource(ds)
            .sql("UPDATE cuentas SET saldo = :saldo WHERE cuenta_id = :cuentaId")
            .beanMapped()
            .assertUpdates(true)
            .build();
}
```
Es **inherentemente seguro entre particiones** (cada partición tiene su propia transacción de chunk) y **sí puede ser singleton** (sin `@StepScope`), porque no guarda estado por partición.

**Requisito de infraestructura.** La doc de referencia 5.2.6 lo dice en la sección de *multi-threaded step* (no en la de particionado, pero aplica igual por analogía):
> *"there may be limits placed on concurrency by any pooled resources used in your step, such as a `DataSource`. Be sure to make the pool in those resources at least as large as the desired number of concurrent threads in the step."*

Con HikariCP: `spring.datasource.hikari.maximum-pool-size` ≥ (hilos de particiones + 1 para el JobRepository del manager). Si no, tendrás deadlocks o timeouts intermitentes justo cuando midas para "hallar el óptimo".

---

## 9. Diferencias Spring Batch 5.2.x → 6.0.x

`[FUENTE: verificado fichero a fichero contra la rama **6.0.x** (no `main`, que es 6.1.0-SNAPSHOT) y contra la Guía de Migración oficial]`

| Clase | 5.2.x (tu proyecto) | 6.0.x (lo que muestra la doc web por defecto) |
|---|---|---|
| `Partitioner` | `o.s.b.core.partition.support.Partitioner` | `o.s.b.core.partition.Partitioner` |
| `PartitionNameProvider` | `o.s.b.core.partition.support.…` | `o.s.b.core.partition.…` |
| `PartitionStep` | `o.s.b.core.partition.support.PartitionStep` | `o.s.b.core.partition.PartitionStep` |
| `StepExecutionAggregator` | `o.s.b.core.partition.support.…` | `o.s.b.core.partition.…` |
| `TaskExecutorPartitionHandler` | `o.s.b.core.partition.support.…` | **sin cambio** (sigue en `.support`) |
| `SimpleStepExecutionSplitter` | `o.s.b.core.partition.support.…` | **sin cambio** |
| `MultiResourcePartitioner` / `SimplePartitioner` | `o.s.b.core.partition.support.…` | **sin cambio** |
| `Step`, `StepExecution`, `StepContribution` | `o.s.b.core.…` | `o.s.b.core.step.…` |
| `ExecutionContext` | `o.s.b.item.ExecutionContext` | `o.s.b.infrastructure.item.ExecutionContext` |
| `FlatFileItemReader` | `o.s.b.item.file.FlatFileItemReader` | `o.s.b.infrastructure.item.file.FlatFileItemReader` |
| `SynchronizedItemStreamReader` | `o.s.b.item.support.…` | `o.s.b.infrastructure.item.support.…` |

Cita literal de la Guía de Migración 6.0:
> *"Partitioner, PartitionNameProvider, PartitionStep and StepExecutionAggregator have been moved from `org.springframework.batch.core.partition.support` to `org.springframework.batch.core.partition`."*
> *"Step, StepContribution and StepExecution have been moved from `org.springframework.batch.core` to `org.springframework.batch.core.step`."*
> *"All APIs defined in the spring-batch-infrastructure module were moved from `org.springframework.batch.*` to `org.springframework.batch.infrastructure.*`."*

### Cambio semántico de concurrencia en 6.0
*What's New in Spring Batch 6*:
> *"Prior to this release, the concurrency model based on the 'parallel iteration' concept required a lot of state synchronization at different levels and had several limitations related to throttling and backpressure leading to confusing transaction semantics and poor performance. This release revisits that model and comes with a new, simplified approach to concurrency based on the producer-consumer pattern."*

Y la doc de escalabilidad 6.0.5:
> *"The reading and writing of items is still done **in serial by the main thread** executing the step, so the `ItemReader` and `ItemWriter` **do not have to be thread-safe** or synchronized."*

Mientras que la 5.2.6 dice lo contrario:
> *"the `Step` executes by reading, processing, and writing each chunk of items (each commit interval) **in a separate thread of execution**."*

**Si citas la doc web sin versionar verás la frase de 6.0 y contradirá tu propio código de 5.2.6.** Usa siempre `https://docs.spring.io/spring-batch/reference/5.2.6/…`

También en 6.0:
- **`AbstractTaskletStepBuilder#throttleLimit` eliminado** (ya `@Deprecated` desde 5.0, default 4, sin reemplazo; la sustitución es un `RepeatOperations` propio vía `StepBuilder#stepOperations`).
- **Local Chunking** → `org.springframework.batch.integration.chunk.ChunkTaskExecutorItemWriter` (módulo `spring-batch-integration`).
- **Remote Step** → `org.springframework.batch.integration.remote.RemoteStep` (módulo `spring-batch-integration`).
- Nuevo `ChunkOrientedStep` / `ChunkOrientedStepBuilder` en sustitución de `ChunkOrientedTasklet`/`TaskletStep`.

---

## 10. Checklist de trampas

1. Sin `.taskExecutor(...)` → `SyncTaskExecutor` → **cero paralelismo, cero avisos**.
2. `ThreadPoolTaskExecutor` con `queueCapacity` < nº particiones → particiones **FAILED en silencio** con `exitDesc='TaskExecutor rejected the task for this step.'`.
3. `gridSize` **no** limita ni la concurrencia ni el nº de particiones — **aunque la doc oficial afirma lo contrario**. Gana el Partitioner.
4. Dos defaults distintos de gridSize: **6** vía `PartitionStepBuilder` (constante `private`, no la referencies), **1** en `AbstractPartitionHandler` si construyes el handler a mano.
5. `.partitionHandler(h)` explícito → `.gridSize()` y `.taskExecutor()` del builder se **ignoran**.
6. Con `.step(workerStep)`, el `String` de `.partitioner("x", …)` **se ignora**: manda `workerStep.getName()`.
7. Falta `@StepScope` → `SpelEvaluationException: EL1008E ... 'stepExecutionContext' cannot be found on ... BeanExpressionContext`.
8. El tipo de retorno del `@Bean` `@StepScope` debe ser al menos `ItemStream` para que se llame `open()`/`close()`.
9. Envolver un `FlatFileItemWriter` en un lambda `ItemWriter` → `WriterNotOpenException: Writer must be open before it can be written to`.
10. Step multi-thread + `FlatFileItemReader` sin sincronizar → `maxItemCount` violado ~1 de cada 5 ejecuciones (y `lineCount`/`noInput` también en carrera).
11. Claves persistidas del reader: `[name].read.count` y **`[name].read.count.max`** (no `read.max.count`).
12. Pool de conexiones JDBC ≥ hilos de particiones + 1.
13. Nunca `@StepScope` **ni `@JobScope`** sobre un bean `Step`.
14. `.<String,String>partitioner(...)` de la doc: los argumentos de tipo son ignorados por el compilador; omítelos.
15. `MultiResourcePartitioner` guarda una **URL** (`file:/...`), no una ruta, y devuelve un `HashMap` (sin orden garantizado).
16. `JdbcPagingItemReader` hereda del mismo contador: **tampoco es thread-safe**.

---

## URLs oficiales (todas verificadas HTTP 200 y **fijadas a versión**)

**Doc de referencia 5.2.6 (la que aplica a tu proyecto)**
- Escalabilidad y particionado: https://docs.spring.io/spring-batch/reference/5.2.6/scalability.html
- Late Binding / `@StepScope` / `@JobScope`: https://docs.spring.io/spring-batch/reference/5.2.6/step/late-binding.html
- `FlatFileItemReader` (referencia): https://docs.spring.io/spring-batch/reference/5.2.6/readers-and-writers/flat-files/file-item-reader.html

**Javadoc 5.2.6**
- `Partitioner`: https://docs.spring.io/spring-batch/docs/5.2.6/api/org/springframework/batch/core/partition/support/Partitioner.html
- `TaskExecutorPartitionHandler`: https://docs.spring.io/spring-batch/docs/5.2.6/api/org/springframework/batch/core/partition/support/TaskExecutorPartitionHandler.html
- `MultiResourcePartitioner`: https://docs.spring.io/spring-batch/docs/5.2.6/api/org/springframework/batch/core/partition/support/MultiResourcePartitioner.html
- `PartitionStepBuilder`: https://docs.spring.io/spring-batch/docs/5.2.6/api/org/springframework/batch/core/step/builder/PartitionStepBuilder.html
- `AbstractItemCountingItemStreamItemReader`: https://docs.spring.io/spring-batch/docs/5.2.6/api/org/springframework/batch/item/support/AbstractItemCountingItemStreamItemReader.html
- `SynchronizedItemStreamReader`: https://docs.spring.io/spring-batch/docs/5.2.6/api/org/springframework/batch/item/support/SynchronizedItemStreamReader.html
- `FlatFileItemReader`: https://docs.spring.io/spring-batch/docs/5.2.6/api/org/springframework/batch/item/file/FlatFileItemReader.html

**Código fuente rama 5.2.x**
- `PartitionStepBuilder`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/PartitionStepBuilder.java
- `TaskExecutorPartitionHandler`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/partition/support/TaskExecutorPartitionHandler.java
- `AbstractPartitionHandler`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/partition/support/AbstractPartitionHandler.java
- `SimpleStepExecutionSplitter`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/partition/support/SimpleStepExecutionSplitter.java
- `MultiResourcePartitioner`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/partition/support/MultiResourcePartitioner.java
- `AbstractItemCountingItemStreamItemReader`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-infrastructure/src/main/java/org/springframework/batch/item/support/AbstractItemCountingItemStreamItemReader.java
- `FlatFileItemReader`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-infrastructure/src/main/java/org/springframework/batch/item/file/FlatFileItemReader.java

**Spring Batch 6.0.5**
- **Guía de Migración 6.0 (documenta TODOS los renombres de paquete):** https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide
- What's New: https://docs.spring.io/spring-batch/reference/6.0.5/whatsnew.html
- Escalabilidad: https://docs.spring.io/spring-batch/reference/6.0.5/scalability.html
- Javadoc `Partitioner` 6.0: https://docs.spring.io/spring-batch/reference/api/org/springframework/batch/core/partition/Partitioner.html

**Samples**
- `ColumnRangePartitioner`: https://github.com/spring-projects/spring-batch/blob/main/spring-batch-samples/src/main/java/org/springframework/batch/samples/common/ColumnRangePartitioner.java *(ojo: la rama `main` usa ya los imports de 6.x)*

---

## Puntos que siguen siendo INCIERTOS

- **Reinicio de un step particionado con `maxItemCount` restaurado desde el ExecutionContext:** deducido del fuente de `AbstractItemCountingItemStreamItemReader.open()` (y solo aplica con `saveState=true`), **no ejecutado**. Si tu Job 1 debe ser reiniciable, pruébalo explícitamente.
- **`JdbcPagingItemReader` particionado:** API verificada contra el fuente de 5.2.6, **no ejecutada** (no se montó PostgreSQL).

*(El punto que el informe anterior marcaba como incierto — los renombres de paquete de 6.0 — ya no lo es: están documentados textualmente en la Guía de Migración oficial 6.0, enlazada arriba.)*

---

## Artefactos reutilizables

Proyecto Maven compilado y ejecutado (Spring Boot 3.5.16 / Spring Batch 5.2.6 / H2):
- `/tmp/claude-0/-home-user-backend-3-bastian/4e7e7dfe-fd51-590e-98b4-3e8278e117a0/scratchpad/pt/src/main/java/demo/LineRangePartitioner.java` — particionado de un CSV único por rangos de línea (**constructor de 3 argumentos**, es el que reproduce el experimento de §2)
- `/tmp/claude-0/-home-user-backend-3-bastian/4e7e7dfe-fd51-590e-98b4-3e8278e117a0/scratchpad/pt/src/main/java/demo/GoodConfig.java` — manager/worker, `@StepScope` reader+writer, un fichero por partición
- `/tmp/claude-0/-home-user-backend-3-bastian/4e7e7dfe-fd51-590e-98b4-3e8278e117a0/scratchpad/pt/src/main/java/demo/BadConfig.java` — reproduce el error `EL1008E` por falta de `@StepScope`
- `/tmp/claude-0/-home-user-backend-3-bastian/4e7e7dfe-fd51-590e-98b4-3e8278e117a0/scratchpad/pt/src/main/java/demo/MtConfig.java` — sonda de concurrencia que demuestra la *race condition* del step multi-thread

Fuentes descargadas para esta revisión (5.2.x, 6.0.x y javadoc): `/tmp/claude-0/-home-user-backend-3-bastian/4e7e7dfe-fd51-590e-98b4-3e8278e117a0/scratchpad/verify/`