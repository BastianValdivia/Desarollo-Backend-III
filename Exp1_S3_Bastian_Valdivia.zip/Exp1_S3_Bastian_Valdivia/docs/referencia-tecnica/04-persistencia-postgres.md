# PARTE 1 — ERRORES ENCONTRADOS

Metodología: no me limité a leer documentación. Descargué el código fuente de `spring-batch` (ramas `5.2.x` y `main`), `spring-retry` (`main`) y `spring-framework` (`6.2.x` / `main`), **compilé todos los snippets del informe** contra `spring-batch-core:5.2.6` + `spring-retry:2.0.13` + Spring Framework 6.2.19 (JDK 21) y contra `spring-batch-core:6.0.5` + Spring Framework 7.0.9, y **ejecuté pruebas de runtime** sobre las afirmaciones de comportamiento. Los proyectos de verificación quedaron en `/tmp/rev` (5.2.x) y `/tmp/rev6` (6.0.x).

**Resultado global: el informe es sorprendentemente sólido.** La gran mayoría de firmas, citas de Javadoc y fragmentos de código fuente son textualmente exactos. Encontré **4 errores sustantivos** (uno de ellos hace que el ejemplo estrella del §8 no funcione), **1 error que impide compilar** y **7 imprecisiones menores**. Detalle:

---

### 🔴 E1 — §3.1, tabla de interacción: `noRetry()` **NO** "siempre gana"

**Lo que dice el informe:**
> | cualquiera + `noRetry(Y)` | se envuelve todo en `ExceptionClassifierRetryPolicy` que mapea `Y → NeverRetryPolicy`. `noRetry` **siempre gana**. |

**Lo que es verdad:** son dos mecanismos distintos que el informe fusionó.
- `noRetry(Y)` sólo hace `retryableExceptionClasses.put(Y, false)` — alimenta el `SimpleRetryPolicy` que construye `createRetryOperations()`.
- El `ExceptionClassifierRetryPolicy` de `getFatalExceptionAwareProxy(RetryPolicy)` se alimenta de **otra** colección, `nonRetryableExceptionClasses`, que se puebla **únicamente** en `addSpecialExceptions()` con excepciones internas del framework: `SkipLimitExceededException`, `NonSkippableReadException`, `TransactionException`, `FatalStepExecutionException`, `SkipListenerFailedException`, `SkipPolicyFailedException`, `RetryException`, `JobInterruptedException`, `Error`, `BeanCreationException`. **`noRetry()` nunca escribe ahí.**

**Consecuencia real, verificada ejecutando el builder:**

```
A) retryPolicy(custom) + noRetry(ValidationException)  SIN retryLimit  -> ¿reintentable? true   ← noRetry IGNORADO
B) retryPolicy(custom) + retry(X) + retryLimit(3) + noRetry(...)       -> ¿reintentable? false  ← funciona (vía AND del composite)
C) retry(Exception) + retryLimit(3) + noRetry(...)                     -> ¿reintentable? false  ← funciona
```

**Corrección exacta:** `noRetry(Y)` sólo surte efecto a través del `SimpleRetryPolicy` derivado de `retry()`/`retryLimit()`. Si configuras un `retryPolicy()` explícito **sin** `retryLimit(n>0)`, tu `noRetry()` se descarta en silencio; debes excluir `Y` dentro de tu propia política.
**Fuente:** [`FaultTolerantStepBuilder.java` 5.2.x](https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/FaultTolerantStepBuilder.java) — líneas 380-388 (`noRetry`), 474-483 (`addSpecialExceptions`), 584-630 (`createRetryOperations`), 642-658 (`getFatalExceptionAwareProxy`).

---

### 🔴 E2 — §6.5, "Trampa real y frecuente": no es un registro a medias, es un **error de compilación**

**Lo que dice el informe:**
> la llamada `.listener(bean)` sin cast resuelve a la sobrecarga `listener(Object)` y usa el escaneo de anotaciones — que no detecta las interfaces. Resultado: el listener se registra a medias o no se registra.

**Lo que es verdad** (compilado con javac 21 + spring-batch-core 5.2.6):

```
Amb.java:19: error: reference to listener is ambiguous
                .listener(bean)
                ^
  both method listener(StepExecutionListener) in StepBuilderHelper
   and method listener(SkipListener<? super I,? super O>) in FaultTolerantStepBuilder match
```

Las dos sobrecargas son máximamente específicas y no comparables → **ambigüedad, el código no compila**. Nunca cae en `listener(Object)`.

**Además, el informe se pierde un dato que simplifica todo:** `FaultTolerantStepBuilder.build()` llama a `registerStepListenerAsSkipListener()`, que recorre los `StepExecutionListener` y `ChunkListener` ya registrados y **auto-registra como `SkipListener` a los que también implementen esa interfaz**. Es decir: para un bean dual basta **una** llamada, `.listener((StepExecutionListener) bean)`.
**Fuente:** mismo archivo, líneas 156-168.

---

### 🔴 E3 — §8.3 + §8.5: el `@BeforeStep` del `DeadLetterSkipListener` **nunca se ejecuta**

Este es el error más caro del informe, porque rompe el ejemplo central de la sección de dead letter.

`.listener((SkipListener<TransaccionRaw, Transaccion>) deadLetter)` resuelve a:

```java
public FaultTolerantStepBuilder<I, O> listener(SkipListener<? super I, ? super O> listener) {
    skipListeners.add(listener);   // <-- eso es TODO. Ningún escaneo de anotaciones.
    return this;
}
```

El escaneo de `@BeforeStep`/`@AfterStep` vive sólo en `listener(Object)`. Con el registro que propone §8.5, `capturarContexto()` jamás se invoca: **cada fila del dead letter se escribe con `job_execution_id = 0` y `step_name = "desconocido"`**, en tabla y en CSV.

**Corrección exacta:** que `DeadLetterSkipListener` implemente `StepExecutionListener` y sobrescriba `beforeStep(StepExecution)` en vez de usar `@BeforeStep`, y registrarlo con `.listener((StepExecutionListener) deadLetter)` — que por E2 lo registra también como `SkipListener`. (Alternativas válidas: `.listener((Object) deadLetter)`, o dos llamadas casteadas.) Verificado: la versión corregida compila con **cero warnings**.
**Fuente:** [`FaultTolerantStepBuilder.java`](https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/FaultTolerantStepBuilder.java) líneas 195-221.

*(Menor asociado: §8.3 importa `org.springframework.batch.core.StepExecutionListener` sin usarlo.)*

---

### 🟠 E4 — §3.2, §4.1, §4.2, §8.5, §10, §11: `DeadlockLoserDataAccessException` está **deprecada**

El informe la usa como excepción-ejemplo canónica de retry en seis lugares. Compilar sus snippets produce:

```
warning: [deprecation] DeadlockLoserDataAccessException in org.springframework.dao has been deprecated
```

Fuente en Spring Framework:
```java
@Deprecated(since = "6.0.3")
public class DeadlockLoserDataAccessException extends PessimisticLockingFailureException {
```
Javadoc: *"@deprecated as of 6.0.3, in favor of `PessimisticLockingFailureException`/`CannotAcquireLockException`"*.

**Corrección exacta:** usar `org.springframework.dao.CannotAcquireLockException` (caso concreto) o `org.springframework.dao.PessimisticLockingFailureException` (familia). Nota adicional: en §8.5 `.retry(DeadlockLoserDataAccessException.class)` junto a `.retry(TransientDataAccessException.class)` es **redundante**, porque `DeadlockLoser… → PessimisticLockingFailure… → ConcurrencyFailure… → TransientDataAccessException`.
**Fuente:** [Javadoc `DeadlockLoserDataAccessException`](https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/dao/DeadlockLoserDataAccessException.html)

---

### 🟠 E5 — §6.1 / §6.5: en Spring Batch 6.0 las anotaciones `@OnSkipIn*` **dejan de funcionar** vía `.listener(Object)`

El informe presenta `@OnSkipInRead/@OnSkipInProcess/@OnSkipInWrite` como "equivalentes" sin salvedad de versión. En `ChunkOrientedStepBuilder.listener(Object)` (6.0) el escaneo cubre 14 anotaciones (`@BeforeStep`, `@AfterStep`, `@BeforeChunk`, `@AfterChunk`, `@OnChunkError`, `@BeforeRead`, `@AfterRead`, `@OnReadError`, `@BeforeProcess`, `@AfterProcess`, `@OnProcessError`, `@BeforeWrite`, `@AfterWrite`, `@OnWriteError`) — **las tres de skip no están**. En 6.0 hay que usar `skipListener(SkipListener)` o implementar la interfaz.
**Fuente:** [`ChunkOrientedStepBuilder.java`](https://github.com/spring-projects/spring-batch/blob/main/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/ChunkOrientedStepBuilder.java), método `listener(Object)`.

---

### 🟡 E6 — §2.2: atribución incorrecta de fuente sobre el "modo sonda"

El informe dice que la sonda `skipCount < 0` es un detalle interno "que la mayoría de tutoriales omite", con "evidencia en el propio framework". En realidad **está documentado en el Javadoc oficial de la interfaz**:

> *"Clients may use `skipCount<0` to probe for exception types that are skippable, so implementations should be able to handle gracefully the case where `skipCount<0`."*

El hecho es correcto; la atribución no. Corregido: es contrato público, no arqueología de código.
**Fuente:** [`SkipPolicy` Javadoc 5.2.6](https://docs.spring.io/spring-batch/docs/current/api/org/springframework/batch/core/step/skip/SkipPolicy.html)

---

### 🟡 E7 — §9.1: cita de la guía de migración inexacta

Informe: *"When job parameter incrementers are configured, parameters of the next instance…"*
Texto real: *"**When a job parameters incrementer is attached to a job definition**, the parameters of the next instance will be calculated by the framework, and any additional parameters supplied by the user will be ignored with a warning."*
Sentido idéntico, pero se presenta como cita literal.
**Fuente:** [Spring Batch 6.0 Migration Guide](https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide)

---

### 🟡 E8 — §4.1: "cada reintento implica rollback" es una sobregeneralización

Cierto para retry en **process** y **write** (la transacción del chunk se deshace), pero no para todo reintento: si la excepción está en `noRollback` y el skip procede en línea, no hay rollback; y un reintento de **lectura** dentro de la misma transacción no incrementa necesariamente `rollbackCount`. Corregido con la salvedad.

---

### 🟡 E9 — §3.3: "`ExponentialBackOffPolicy` es thread-safe" — sin respaldo oficial

Ni el Javadoc de spring-retry ni la referencia lo afirman. Es *plausible* (el estado por intento vive en un `ExponentialBackOffContext` que devuelve `start(RetryContext)`), pero los setters mutan estado compartido. Reformulado como observación de diseño, no como garantía.

---

### 🟡 E10 — §13 punto 6 ya no es incierto: `CompositeRetryPolicy` es AND por defecto

Verificado en fuente: `private boolean optimistic = false;`. La suposición del informe era correcta; la muevo de "incierto" a "verificado".
**Fuente:** [`CompositeRetryPolicy.java`](https://github.com/spring-projects/spring-retry/blob/main/src/main/java/org/springframework/retry/policy/CompositeRetryPolicy.java) línea 41.

---

### 🟡 E11 — Imports muertos en tres snippets

`§2.5` importa `AlwaysSkipItemSkipPolicy` sin usarlo; `§8.3` importa `StepExecutionListener` sin usarlo; `§11` importa `RunIdIncrementer` sin usarlo. No rompen la compilación (sólo warnings con `-Xlint`), pero en un entregable evaluado conviene limpiarlos.

---

### 🟡 E12 — §0/§11: matiz sobre el "default" de skip policy en 6.0

El Javadoc de `ChunkOrientedStepBuilder.skipPolicy()` dice *"Defaults to `NeverSkipItemSkipPolicy`"*, pero en `build()` la rama es:

```java
if (!this.skippableExceptions.isEmpty() || this.skipLimit > 0) { ... LimitCheckingExceptionHierarchySkipPolicy ... }
else { new NeverSkipItemSkipPolicy(); }
```

Como `skipLimit` **nace en 10**, la condición es siempre verdadera y la rama `NeverSkipItemSkipPolicy` es **inalcanzable**. El efecto neto es el mismo (conjunto de omitibles vacío ⇒ no se omite nada), pero la clase real siempre es `LimitCheckingExceptionHierarchySkipPolicy`. El informe acierta en el efecto; añado la precisión.

---

### ✅ Afirmaciones que INTENTÉ refutar y resultaron CORRECTAS (verificadas una a una)

| Afirmación del informe | Veredicto |
|---|---|
| `@Deprecated(since="6.0", forRemoval=true)` en `FaultTolerantStepBuilder` y en `StepBuilder.chunk(int, tx)` | ✅ literal en `main` |
| `.faultTolerant()` en 6.0 devuelve el **mismo** `ChunkOrientedStepBuilder` (sólo flag) | ✅ |
| 6.0 no expone `noRollback()` ni `backOffPolicy()` | ✅ ambos ausentes |
| `SkipPolicy` es `@FunctionalInterface`, `shouldSkip(Throwable, long)` | ✅ |
| `skipCount` era `int` en 4.3.x y pasó a `long` en 5.0 | ✅ comprobado en 4.3.x |
| `SkipLimitExceededException(long, Throwable)` | ✅ (el snippet de §2.3 compila con `long`) |
| Código citado de `LimitCheckingExceptionHierarchySkipPolicy` | ✅ **carácter por carácter** |
| `LimitCheckingItemSkipPolicy` de 5.x **no** recorre causas | ✅ probado en runtime (`false` con causa envuelta) |
| `createSkipPolicy()` compone con `CompositeSkipPolicy` (OR con cortocircuito) | ✅ código + runtime |
| Tabla completa de §2.4 (los 4 escenarios) | ✅ reproducida empíricamente: sólo-custom → veto respetado; custom+`skip()` → OR lo anula; con `skipCount≥skipLimit` → lanza `SkipLimitExceededException(limit=3)` |
| En 6.0 `skipPolicy()` custom ignora `skip()`/`skipLimit()` (`if (skipPolicy == null)`) | ✅ |
| Javadoc de `skipLimit` (cita larga) | ✅ literal |
| Javadoc de `retryLimit` ("Zero and one both translate to try only once…") | ✅ literal |
| `Assert.state("If a retry limit is provided then retryable exceptions must also be specified")` | ✅ literal |
| Los 6 constructores de `SimpleRetryPolicy` + `DEFAULT_MAX_ATTEMPTS = 3` | ✅ |
| Defaults de backoff: 1000 / 100 / 30000 / 2 / 500-1500 ms; setters `void` | ✅ |
| `ExponentialRandomBackOffPolicy extends ExponentialBackOffPolicy`; existe `NoBackOffPolicy` | ✅ |
| Existencia de las 8 políticas de `org.springframework.retry.policy` citadas | ✅ |
| `RetryPolicy.builder().maxRetries(long)` + `includes/excludes` varargs + `delay/jitter/multiplier/maxDelay` (SF 7) | ✅ compilado |
| `maxRetries(3)` = 1 intento + 3 reintentos vs `retryLimit(3)` = 3 totales | ✅ Javadoc: *"the maximum number of retry attempts"* |
| Los 8 métodos de `org.springframework.core.retry.RetryListener` **con sus `@since 7.0.2 / 7.0.4`** | ✅ exacto |
| `RetryListener` de spring-retry (`open/close/onSuccess @since 2.0/onError`) | ✅ |
| Fragmentos de `ChunkOrientedStep`: `doRead`, `doSkipInRead`, `writeChunk` (sonda `-1`), `scan()` con su comentario JPA | ✅ **textuales** |
| Fragmento de `FaultTolerantChunkProcessor.transform()` + mensaje `NonSkippableProcessException` | ✅ textual |
| `shouldSkip(itemWriteSkipPolicy, …, -1)` en 5.2.x | ✅ líneas 398 y 594 |
| Cita de referencia: *"By default, regardless of retry or skip, any exceptions thrown from the ItemWriter cause the transaction… to rollback"* | ✅ |
| Javadoc de `noRollback` y de `processorNonTransactional()` (6.0, "like JPA entities") | ✅ textuales |
| Firmas de `SkipListener`, `ItemRead/Process/WriteListener`, `ChunkListener` (`sb_rollback_exception`), `StepExecutionListener` (`afterStep` → `null`) | ✅ todas |
| `ItemWriteListener` recibe `Chunk<? extends S>` desde 5.0 | ✅ |
| Javadoc de `onSkipInRead` sobre invocaciones repetidas | ✅ literal |
| `registerTypedListener()` con `instanceof` contra 6 interfaces en 6.0 | ✅ |
| `SimpleStepExecutionSplitter`: `":"`, `SimpleStepExecutionSplitter.GRID_SIZE`, `(int) context.getLong(key, gridSize)`, `isStartable`, `"Cannot restart step from UNKNOWN status"` | ✅ todos |
| `PartitionNameProvider` evita re-ejecutar `partition()` en reinicio | ✅ documentado en el propio Javadoc de la interfaz |
| Rutas de paquete 5.2 ↔ 6.0 (`item.*`→`infrastructure.item.*`, `core.*`→`core.listener.*`, `RunIdIncrementer`, `Step`) | ✅ HTTP 200/404 verificados uno a uno |
| Todas las URLs del §12 | ✅ resuelven (200) |
| `docs/current/api` = **5.2.6**; `reference/api` = **6.0.5**; GA actual = **6.0.5** | ✅ |
| Boot 3.5→Batch 5.2 / Boot 4.0→Batch 6.0 | ✅ |
| `ResolverStyle.SMART` rechaza mes 13, convierte `2024-02-30`→`2024-02-29`; `STRICT`+`uuuu` lo rechaza | ✅ ejecutado |
| Los snippets de §2.3, §2.5, §3.2, §5.3, §8.3, §8.4, §8.5, §8.6, §9.1, §9.4 | ✅ **compilan** contra 5.2.6 |
| El snippet §11 completo | ✅ **compila** contra 6.0.5 + SF 7.0.9 |

---
---

# PARTE 2 — INFORME CORREGIDO Y CONSOLIDADO

# INFORME TÉCNICO: Tolerancia a Fallos en Spring Batch (API actual)
### Banco XYZ — Duoc UC, Desarrollo Backend III PBY2203, Exp1 Semana 3
> **Estado de verificación (agosto 2026):** todas las firmas de API de este documento fueron contrastadas contra el código fuente de `spring-batch` (`5.2.x` y `main`), `spring-retry` (`main`) y `spring-framework` (`6.2.x`/`main`). Todos los snippets Java **compilan sin warnings** contra `spring-batch-core:5.2.6` + `spring-retry:2.0.13` + Spring Framework 6.2.19 (JDK 21); el snippet del §11 compila contra `spring-batch-core:6.0.5` + Spring Framework 7.0.9. Las afirmaciones de comportamiento marcadas con 🧪 se comprobaron ejecutando el framework.

---

## 0. AVISO CRÍTICO DE VERSIONES (leer antes que nada)

Existen **dos APIs de tolerancia a fallos vigentes** y son incompatibles entre sí. Elegir mal significa código que no compila.

| | **Spring Batch 5.2.x** (Spring Boot 3.4/3.5) | **Spring Batch 6.0.x** (Spring Boot 4.0) |
|---|---|---|
| Builder de chunk | `StepBuilder.chunk(int, PlatformTransactionManager)` → `SimpleStepBuilder` | `StepBuilder.chunk(int)` → `ChunkOrientedStepBuilder` |
| `.faultTolerant()` | devuelve `FaultTolerantStepBuilder<I,O>` (subtipo distinto) | devuelve `ChunkOrientedStepBuilder<I,O>` (**el mismo builder**, solo activa un flag) |
| `RetryPolicy` | `org.springframework.retry.RetryPolicy` (spring-retry 2.x) | `org.springframework.core.retry.RetryPolicy` (Spring Framework 7) |
| `BackOffPolicy` | `org.springframework.retry.backoff.BackOffPolicy` vía `.backOffPolicy(...)` | **no existe** `.backOffPolicy()`; el backoff va dentro de `RetryPolicy.builder()` |
| Listeners | `org.springframework.batch.core.*` | `org.springframework.batch.core.listener.*` |
| Readers/Writers | `org.springframework.batch.item.*` | `org.springframework.batch.infrastructure.item.*` |
| `RunIdIncrementer` | `org.springframework.batch.core.launch.support.RunIdIncrementer` | `org.springframework.batch.core.job.parameters.RunIdIncrementer` |
| `Step` | `org.springframework.batch.core.Step` | `org.springframework.batch.core.step.Step` |
| `Partitioner` / `PartitionNameProvider` | `…core.partition.support.*` | `…core.partition.*` |
| Skip policy por defecto | `LimitCheckingItemSkipPolicy` | `LimitCheckingExceptionHierarchySkipPolicy` (la anterior queda `@Deprecated(since="6.0", forRemoval=true)`) |
| `skip()` / `retry()` | un `Class` por llamada | **varargs** `Class<? extends Throwable>...` |
| `skipLimit` / `retryLimit` | `int` | `long`, y con `Assert.isTrue(> 0)` |
| `noRollback(Class)` | **sí existe** | **NO existe en `ChunkOrientedStepBuilder`** (ver §5) |
| Anotaciones `@OnSkipIn*` vía `.listener(Object)` | **sí se escanean** | **NO se escanean** — usar `skipListener(...)` |

En la rama `main` (6.x), `FaultTolerantStepBuilder` está marcado literalmente:
```java
@Deprecated(since = "6.0", forRemoval = true)
public class FaultTolerantStepBuilder<I, O> extends SimpleStepBuilder<I, O> {
```
y `StepBuilder.chunk(int, transactionManager)` también (`@Deprecated(since = "6.0", forRemoval = true)`).

**Recomendación para la evaluación:** usar **Spring Boot 3.5.x / Spring Batch 5.2.x**. Es la versión de la que hay documentación, tutoriales y ejemplos que el docente reconocerá, tiene `noRollback()` (clave para tu caso de validación) y `.backOffPolicy()` explícito. Todos los snippets de este informe están escritos para 5.2.x salvo la §11, que muestra el equivalente 6.0.

> **Versiones exactas al momento de esta revisión:** el Javadoc bajo `docs.spring.io/spring-batch/docs/current/api/` corresponde a **Spring Batch 5.2.6**; el de `docs.spring.io/spring-batch/reference/api/` a **6.0.5**, que es el **GA actual**. Confirma siempre con `mvn dependency:tree` en tu proyecto.

---

## 1. `.faultTolerant()` — qué devuelve y qué habilita

### 1.1 Firma (Spring Batch 5.2.x)

```java
// org.springframework.batch.core.step.builder.SimpleStepBuilder
public FaultTolerantStepBuilder<I, O> faultTolerant()
```

Devuelve un **`FaultTolerantStepBuilder<I,O>`**, que extiende `SimpleStepBuilder<I,O>`. Ese cambio de tipo es lo que habilita los métodos nuevos. Es decir: **`.skip(...)`, `.retry(...)`, `.noRollback(...)` no existen antes de llamar a `.faultTolerant()`** — es un error de compilación, no de runtime.

Internamente, `.faultTolerant()` reemplaza el `SimpleChunkProvider`/`SimpleChunkProcessor` por `FaultTolerantChunkProvider`/`FaultTolerantChunkProcessor`, envueltos en un `BatchRetryTemplate`.

### 1.2 Catálogo completo de métodos habilitados

```java
// Skip (omisión)
FaultTolerantStepBuilder<I,O> skip(Class<? extends Throwable> type)
FaultTolerantStepBuilder<I,O> noSkip(Class<? extends Throwable> type)
FaultTolerantStepBuilder<I,O> skipLimit(int skipLimit)              // default 10
FaultTolerantStepBuilder<I,O> skipPolicy(SkipPolicy skipPolicy)

// Retry (reintento)
FaultTolerantStepBuilder<I,O> retry(Class<? extends Throwable> type)
FaultTolerantStepBuilder<I,O> noRetry(Class<? extends Throwable> type)
FaultTolerantStepBuilder<I,O> retryLimit(int retryLimit)            // default 0; 0 y 1 == sin reintento
FaultTolerantStepBuilder<I,O> retryPolicy(RetryPolicy retryPolicy)
FaultTolerantStepBuilder<I,O> backOffPolicy(BackOffPolicy backOffPolicy)
FaultTolerantStepBuilder<I,O> retryContextCache(RetryContextCache cache)
FaultTolerantStepBuilder<I,O> keyGenerator(KeyGenerator keyGenerator)

// Rollback
FaultTolerantStepBuilder<I,O> noRollback(Class<? extends Throwable> type)
SimpleStepBuilder<I,O>        readerIsTransactionalQueue()          // heredado (¡degrada el tipo!)
FaultTolerantStepBuilder<I,O> processorNonTransactional()

// Listeners (sobrecargas)
FaultTolerantStepBuilder<I,O> listener(SkipListener<? super I, ? super O> listener)
FaultTolerantStepBuilder<I,O> listener(RetryListener listener)
FaultTolerantStepBuilder<I,O> listener(ChunkListener listener)
FaultTolerantStepBuilder<I,O> listener(Object listener)   // basado en anotaciones
// heredado de StepBuilderHelper:
B                             listener(StepExecutionListener listener)

// Build
TaskletStep build()
```

### 1.3 Trampa de orden en el fluent builder

Métodos no sobrescritos por `FaultTolerantStepBuilder` (`.reader(...)`, `.processor(...)`, `.writer(...)`) devuelven `SimpleStepBuilder`, y `.stream(...)` / `.transactionAttribute(...)` lo devuelven explícitamente: llamarlos **después** de `.faultTolerant()` **pierde el tipo `FaultTolerantStepBuilder`**. Regla práctica: **`.faultTolerant()` siempre después de reader/processor/writer y antes de todo lo de skip/retry**, y `.build()` al final.

```java
new StepBuilder("nombre", jobRepository)
    .<In, Out>chunk(100, txManager)
    .reader(...).processor(...).writer(...)
    .faultTolerant()          // <-- aquí
    .skip(...).skipLimit(...).retry(...).retryLimit(...).backOffPolicy(...)
    .listener(...)
    .build();
```

> **Nota:** aunque `.listener((StepExecutionListener) x)` degrade el tipo estático a `AbstractTaskletStepBuilder`, `.build()` sigue despachando dinámicamente a `FaultTolerantStepBuilder.build()`. El step construido **sí** es tolerante a fallos. Sólo pierdes acceso a más métodos de skip/retry a partir de ahí.

**Fuentes:** [FaultTolerantStepBuilder 5.2.6 API](https://docs.spring.io/spring-batch/docs/current/api/org/springframework/batch/core/step/builder/FaultTolerantStepBuilder.html) · [código fuente en GitHub](https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/FaultTolerantStepBuilder.java)

---

## 2. SKIP — omisión de ítems

### 2.1 `skip(Class)` / `skipLimit(int)` / `noSkip(Class)`

- `skip(X)` marca `X` **y todas sus subclases** como omitibles. Se puede encadenar varias veces.
- `noSkip(X)` excluye explícitamente `X`. Gana sobre un `skip()` de una superclase porque el `BinaryExceptionClassifier` resuelve **por la clase más específica de la jerarquía** — útil para `skip(Exception.class).noSkip(SQLException.class)`.
- `skipLimit(int)` — **el default es 10** (campo `private int skipLimit = 10`). Es un contador **global del step**, no por tipo de excepción ni por fase. Se contabilizan por separado `readSkipCount`, `processSkipCount` y `writeSkipCount`, pero **el límite se aplica a la suma**. Al superarse, el step falla con `SkipLimitExceededException` y estado `FAILED`.

> **Relevancia directa para tu proyecto:** `transacciones.csv` tiene 371 filas con `tipo` inválido y 168 con `monto` vacío; `intereses.csv` tiene 331 tipos inválidos + 211 saldos vacíos. Si tratas todo eso como excepción omitible, **el `skipLimit` por defecto de 10 hace que el step falle en la fila ~11**. Debes subir el límite explícitamente (ej. `skipLimit(500)`) o —mejor— separar (§8): errores de **parseo** → skip; datos **inválidos de negocio esperados** → filtrado en el `ItemProcessor` devolviendo `null`, que **no cuenta como skip** y no requiere tolerancia a fallos.

### 2.2 La interfaz `SkipPolicy` — firma exacta

```java
package org.springframework.batch.core.step.skip;

@FunctionalInterface
public interface SkipPolicy {

    /**
     * Returns true or false, indicating whether or not processing should continue with
     * the given throwable. Clients may use skipCount<0 to probe for exception types that
     * are skippable, so implementations should be able to handle gracefully the case
     * where skipCount<0. Implementations should avoid throwing any undeclared exceptions.
     */
    boolean shouldSkip(Throwable t, long skipCount) throws SkipLimitExceededException;
}
```

Tres puntos que la mayoría de tutoriales omite y que sí importan:

1. **`skipCount` es `long`, no `int`.** Cambió en Spring Batch 5.0 (en 4.3.x la firma era `shouldSkip(Throwable t, int skipCount)`). Si copias un ejemplo de Spring Batch 4.x con `int skipCount`, **no sobrescribe el método** y tu política nunca se ejecuta.
2. **Spring Batch invoca `shouldSkip` con `skipCount < 0` como *sonda*** ("¿este tipo de excepción es omitible en principio?", sin consumir cupo). Esto **es contrato público, está en el Javadoc de la interfaz** (citado arriba). Tu implementación **debe** manejar ese caso. Puntos de llamada reales:
   ```java
   // FaultTolerantChunkProcessor (5.2.x), líneas 398 y 594:
   if (!shouldSkip(itemWriteSkipPolicy, context.getLastThrowable(), -1)) { ... }
   ```
   ```java
   // ChunkOrientedStep (6.0), writeChunk():
   if (this.faultTolerant && exception instanceof RetryException retryException
           && this.skipPolicy.shouldSkip(retryException.getCause(), -1)) {
       logger.info("Retry exhausted, entering scan mode for next transaction", retryException);
       this.chunkTracker.get().enterScanMode(scanItems);
   }
   ```
   Si tu política lanza `SkipLimitExceededException` o incrementa un contador cuando `skipCount == -1`, rompes el mecanismo de scanning.
3. Devolver `false` = "no omitir" → el step falla. Lanzar `SkipLimitExceededException` = "era omitible pero se agotó el cupo" → el step falla con mensaje explícito.

**Referencia de implementación oficial** (`LimitCheckingExceptionHierarchySkipPolicy`, nueva en 6.0, es el mejor modelo a copiar) — reproducida literal del fuente:

```java
@Override
public boolean shouldSkip(Throwable t, long skipCount) throws SkipLimitExceededException {
    boolean skippable = isSkippable(t);
    if (skipCount < 0) {            // sonda
        return skippable;
    }
    if (!skippable) {
        return false;
    }
    if (skipCount >= this.skipLimit) {
        throw new SkipLimitExceededException(this.skipLimit, t);
    }
    return true;
}
```
🧪 `isSkippable` recorre la **cadena de causas** con `getCause()`; `LimitCheckingItemSkipPolicy` de 5.x **no** lo hace: usa un `BinaryExceptionClassifier` sobre la excepción de nivel superior. Verificado ejecutando: una `ValidationException` envuelta en `IllegalStateException` devuelve `false` en 5.x.

> ⚠️ **Diferencia adicional de 5.x:** `LimitCheckingItemSkipPolicy` **no implementa la sonda**: con `skipCount = -1` y una excepción omitible devuelve `true` (porque `-1 < skipLimit`). Es benigno para el flujo de scan, pero es otra razón para no tomarla como plantilla de una política propia.

### 2.3 SkipPolicy personalizado para Banco XYZ (compilable, Spring Batch 5.2.x) ✅

```java
package cl.duoc.bancoxyz.batch.policy;

import java.io.FileNotFoundException;

import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.OptimisticLockingFailureException;

/**
 * Política de omisión del Banco XYZ.
 *
 * Reglas:
 *  - Errores de formato de línea (FlatFileParseException, incluye fechas mes 13,
 *    montos vacíos que rompen el FieldSetMapper) -> omitibles.
 *  - Errores de validación de negocio (ValidationException: tipo 'invalid',
 *    edad 150, saldo vacío) -> omitibles.
 *  - Errores de infraestructura (BD caída, archivo no encontrado, bloqueo
 *    optimista) -> NUNCA omitibles: son transitorios o fatales, no datos sucios.
 *
 * IMPORTANTE: esta implementación es SIN ESTADO. Usa el skipCount que entrega
 * el framework (que proviene de StepExecution y es el único conteo confiable,
 * porque shouldSkip puede invocarse varias veces para el mismo ítem durante el
 * escaneo del chunk).
 */
public class BancoXyzSkipPolicy implements SkipPolicy {

    private final long limiteTotal;

    public BancoXyzSkipPolicy(long limiteTotal) {
        this.limiteTotal = limiteTotal;
    }

    @Override
    public boolean shouldSkip(Throwable t, long skipCount) throws SkipLimitExceededException {

        // 1) Fatales primero: se evalúan incluso en modo sonda.
        if (esDeTipo(t, DataAccessResourceFailureException.class)
                || esDeTipo(t, FileNotFoundException.class)
                || esDeTipo(t, OptimisticLockingFailureException.class)) {
            return false;
        }

        boolean omitible = esDeTipo(t, FlatFileParseException.class)
                        || esDeTipo(t, ValidationException.class)
                        || esDeTipo(t, NumberFormatException.class);

        // 2) MODO SONDA: skipCount < 0 -> solo responder "¿es omitible?".
        //    Nunca lanzar excepción ni mutar estado aquí.
        if (skipCount < 0) {
            return omitible;
        }

        if (!omitible) {
            return false;
        }

        // 3) Cupo agotado -> el step debe fallar de forma explícita.
        if (skipCount >= this.limiteTotal) {
            throw new SkipLimitExceededException(this.limiteTotal, t);
        }
        return true;
    }

    /** Recorre la cadena de causas: FlatFileParseException suele envolver la real. */
    private boolean esDeTipo(Throwable t, Class<? extends Throwable> tipo) {
        Throwable actual = t;
        while (actual != null) {
            if (tipo.isInstance(actual)) {
                return true;
            }
            actual = actual.getCause();
        }
        return false;
    }
}
```
> El constructor `SkipLimitExceededException(long skipLimit, Throwable t)` acepta `long` (verificado en fuente 5.2.x), así que el `limiteTotal` de tipo `long` compila sin cast.

> **Advertencia de diseño:** si necesitas **límites distintos por tipo de excepción** (ej. 400 errores de formato y 400 de validación), la tentación es llevar contadores `AtomicLong` dentro de la política. **Es incorrecto**: `shouldSkip` se llama más de una vez para el mismo ítem (en el `retryCallback`, en el `recoveryCallback`, en el scan del chunk) y además con `skipCount = -1`. Tus contadores se inflarán. La forma correcta es `ExceptionClassifierSkipPolicy` (§2.5), que delega a una política distinta por tipo, cada una usando el `skipCount` del framework.

### 2.4 Registro y **conflicto entre `skipPolicy()` y `skip()`/`skipLimit()`**

Esta es la parte que la documentación describe de forma **incompleta**. El Javadoc dice:

> *"Sets the maximum number of failed items to skip before the step fails. The default value is 10. This limit is enforced using the default `LimitCheckingItemSkipPolicy`. **If a custom `SkipPolicy` is provided via `skipPolicy(SkipPolicy)`, this limit will not be enforced by the step directly**, but it can be implemented to be honored by the custom policy."*

Pero el código real de `FaultTolerantStepBuilder.createSkipPolicy()` (5.2.x) es:

```java
protected SkipPolicy createSkipPolicy() {
    SkipPolicy skipPolicy = this.skipPolicy;
    Map<Class<? extends Throwable>, Boolean> map = new HashMap<>(skippableExceptionClasses);
    map.put(ForceRollbackForWriteSkipException.class, true);
    LimitCheckingItemSkipPolicy limitCheckingItemSkipPolicy =
            new LimitCheckingItemSkipPolicy(skipLimit, map);
    if (skipPolicy == null) {
        if (skippableExceptionClasses.isEmpty() && skipLimit > 0) {
            logger.debug(...);   // solo un aviso, no falla
        }
        skipPolicy = limitCheckingItemSkipPolicy;
    }
    else if (limitCheckingItemSkipPolicy != null) {
        skipPolicy = new CompositeSkipPolicy(
                new SkipPolicy[] { skipPolicy, limitCheckingItemSkipPolicy });   // <-- OJO
    }
    return skipPolicy;
}
```

Y `CompositeSkipPolicy` es un **OR de cortocircuito**:

```java
@Override
public boolean shouldSkip(Throwable t, long skipCount) throws SkipLimitExceededException {
    for (SkipPolicy policy : skipPolicies) {
        if (policy.shouldSkip(t, skipCount)) {
            return true;
        }
    }
    return false;
}
```

🧪 **Consecuencias reales de mezclar `skipPolicy()` con `skip()`/`skipLimit()` en 5.2.x** — reproducidas ejecutando el builder con una política que veta todo:

| Escenario | Comportamiento real (medido) |
|---|---|
| Solo `skipPolicy(custom)` | Clase resultante: `CompositeSkipPolicy`. Se compone con un `LimitCheckingItemSkipPolicy(10, {ForceRollbackForWriteSkipException})`. Como tu excepción no está en ese mapa, esa política devuelve `false` y no interfiere → `shouldSkip(ValidationException, 0)` = **false**, `(…, 9)` = **false**. **Tu política manda.** |
| `skipPolicy(custom)` + `skip(X)` | **OR.** `shouldSkip(ValidationException, 0)` = **true** pese al veto. Tu veto queda anulado. |
| `skipPolicy(custom)` + `skip(X)` + `skipCount >= skipLimit` | `shouldSkip(ValidationException, 9)` con `skipLimit(3)` → **lanza `SkipLimitExceededException(limit=3)`** → el step falla. El límite **sí se aplica** en esta ruta, contradiciendo la lectura ingenua del Javadoc. |
| `skipPolicy(custom)` que devuelve `true` siempre | El `skipLimit` **nunca** se evalúa (cortocircuito). Riesgo de omitir las 1000 filas sin que nadie proteste. |

**Regla operativa: elige uno de los dos modelos, no los mezcles.**

```java
// MODELO A — declarativo (suficiente para la mayoría de los casos)
.faultTolerant()
    .skip(FlatFileParseException.class)
    .skip(ValidationException.class)
    .noSkip(DataAccessResourceFailureException.class)
    .skipLimit(500)

// MODELO B — política personalizada (lo que pide el enunciado: "políticas personalizadas")
.faultTolerant()
    .skipPolicy(new BancoXyzSkipPolicy(500))
    // NO llamar a .skip(...) ni a .skipLimit(...) aquí
```

En **6.0** este solapamiento **ya no existe**: `ChunkOrientedStepBuilder.build()` usa `if (this.skipPolicy == null) { ... }` — si diste una política personalizada, las listas de `skip()`/`skipLimit()` se **ignoran por completo**, sin composición.

> **Precisión sobre el default de 6.0:** el Javadoc de `skipPolicy()` dice *"Defaults to `NeverSkipItemSkipPolicy`"*, pero en `build()` la condición es `if (!skippableExceptions.isEmpty() || skipLimit > 0)` y `skipLimit` nace en 10, así que **la rama `NeverSkipItemSkipPolicy` es inalcanzable**: siempre se construye un `LimitCheckingExceptionHierarchySkipPolicy(∅, 10)`. El efecto neto es el mismo (conjunto vacío ⇒ nada omitible), pero conviene saberlo si depuras con el debugger.

### 2.5 Alternativa oficial: `ExceptionClassifierSkipPolicy` (límites por tipo, sin estado propio) ✅

```java
package cl.duoc.bancoxyz.batch.config;

import java.util.Map;

import org.springframework.batch.core.step.skip.ExceptionClassifierSkipPolicy;
import org.springframework.batch.core.step.skip.LimitCheckingItemSkipPolicy;
import org.springframework.batch.core.step.skip.NeverSkipItemSkipPolicy;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.dao.DataAccessResourceFailureException;

public class SkipPolicies {

    public static SkipPolicy porTipo() {
        ExceptionClassifierSkipPolicy politica = new ExceptionClassifierSkipPolicy();
        politica.setPolicyMap(Map.of(
            // hasta 400 errores de formato de línea
            FlatFileParseException.class,
                new LimitCheckingItemSkipPolicy(400, Map.of(FlatFileParseException.class, true)),
            // hasta 400 errores de validación de negocio
            ValidationException.class,
                new LimitCheckingItemSkipPolicy(400, Map.of(ValidationException.class, true)),
            // BD caída: jamás omitir
            DataAccessResourceFailureException.class, new NeverSkipItemSkipPolicy()
        ));
        return politica;
    }
}
```
🧪 Verificado en ejecución: `shouldSkip(ValidationException, 0)` → `true`; `shouldSkip(DataAccessResourceFailureException, 0)` → `false`. `ExceptionClassifierSkipPolicy.shouldSkip(Throwable, long)` delega según la **jerarquía de clases** (usa `SubclassClassifier`, con `NeverSkipItemSkipPolicy` como default), y cada `LimitCheckingItemSkipPolicy` lanza su propia `SkipLimitExceededException`. Ojo: el `skipCount` que recibe cada sub-política sigue siendo el **global del step**, no uno por tipo. Es una limitación real del diseño — para conteos verdaderamente independientes por tipo hay que llevar estado propio, con las precauciones de §2.3.

**Fuentes:** [Configuring Skip Logic (6.0)](https://docs.spring.io/spring-batch/reference/step/chunk-oriented-processing/configuring-skip.html) · [SkipPolicy 5.2.6 API](https://docs.spring.io/spring-batch/docs/current/api/org/springframework/batch/core/step/skip/SkipPolicy.html) · [Baeldung: Configuring Skip Logic](https://www.baeldung.com/spring-batch-skip-logic)

---

## 3. RETRY — reintentos

### 3.1 Métodos y su interacción

```java
.retry(Class<? extends Throwable> type)   // marca tipo (y subclases) como reintentable
.noRetry(Class<? extends Throwable> type) // excluye explícitamente
.retryLimit(int retryLimit)               // nº TOTAL de intentos, no de reintentos extra
.retryPolicy(RetryPolicy retryPolicy)     // política explícita
.backOffPolicy(BackOffPolicy backOffPolicy)
```

**Semántica exacta de `retryLimit`** (Javadoc literal): *"The maximum number of times to try a failed item. **Zero and one both translate to try only once and do not retry.** Ignored if an explicit `retryPolicy` is set."* Es decir, `retryLimit(3)` = 1 intento inicial + 2 reintentos. Esto es distinto de `maxRetries` en la API nueva de 6.0, donde `maxRetries(3)` = 1 intento + 3 reintentos = 4 intentos totales.

**Validación en construcción:** si pones `retryLimit(n>0)` sin ningún `retry(X)`, el builder lanza en `build()`:
```java
Assert.state(!(retryableExceptionClasses.isEmpty() && retryLimit > 0),
    "If a retry limit is provided then retryable exceptions must also be specified");
```
(Contraste con `skipLimit`, que sin `skip()` solo emite un `logger.debug`, no falla.)

🧪 **Interacción `retryPolicy()` vs `retry()`/`retryLimit()`/`noRetry()`** — de `createRetryOperations()`, medido ejecutando el builder:

| Configuración | Resultado |
|---|---|
| solo `retry(X)` + `retryLimit(n)` | `SimpleRetryPolicy(n, {X:true, ForceRollbackForWriteSkipException:true})` |
| solo `retryPolicy(p)` | se usa `p` tal cual; `retryLimit` y `backOffPolicy` **ignorados** por el policy (el backoff sí se aplica al `BatchRetryTemplate`) |
| `retryPolicy(p)` **+** `retry(X)` **+** `retryLimit(n>0)` | `CompositeRetryPolicy{p, SimpleRetryPolicy(n,…)}` — **ambas deben permitir** el reintento (`CompositeRetryPolicy` tiene `optimistic = false` por defecto ⇒ **AND**, verificado en fuente). Configuración confusa, evítala. |
| **`noRetry(Y)`** | ⚠️ **CORRECCIÓN IMPORTANTE.** `noRetry(Y)` sólo hace `retryableExceptionClasses.put(Y, false)`, es decir **sólo influye en el `SimpleRetryPolicy` derivado de `retry()`/`retryLimit()`**. Con `retryPolicy(p)` explícito y **sin** `retryLimit(n>0)`, **`noRetry` se ignora en silencio** (medido: `Y` sigue siendo reintentable). El `ExceptionClassifierRetryPolicy` de `getFatalExceptionAwareProxy()` **no** se alimenta de `noRetry()`, sino de `nonRetryableExceptionClasses`, poblada sólo por `addSpecialExceptions()` con excepciones internas del framework (`SkipLimitExceededException`, `NonSkippableReadException`, `TransactionException`, `FatalStepExecutionException`, `SkipListenerFailedException`, `SkipPolicyFailedException`, `RetryException`, `JobInterruptedException`, `Error`, `BeanCreationException`). |

**Regla operativa derivada:** si usas `retryPolicy()` propio, **excluye los tipos no reintentables dentro de esa política**; no confíes en `noRetry()`.

### 3.2 `SimpleRetryPolicy` con mapa de excepciones — firmas exactas

```java
package org.springframework.retry.policy;

public class SimpleRetryPolicy implements RetryPolicy {

    public final static int DEFAULT_MAX_ATTEMPTS = 3;

    public SimpleRetryPolicy();
    public SimpleRetryPolicy(int maxAttempts);
    public SimpleRetryPolicy(int maxAttempts, Map<Class<? extends Throwable>, Boolean> retryableExceptions);
    public SimpleRetryPolicy(int maxAttempts, Map<Class<? extends Throwable>, Boolean> retryableExceptions,
                             boolean traverseCauses);
    public SimpleRetryPolicy(int maxAttempts, Map<Class<? extends Throwable>, Boolean> retryableExceptions,
                             boolean traverseCauses, boolean defaultValue);
    public SimpleRetryPolicy(int maxAttempts, BinaryExceptionClassifier classifier);
}
```

- **`maxAttempts` es el nº total de intentos**, no de reintentos.
- El `Map<Class<? extends Throwable>, Boolean>`: `true` = reintentable, `false` = no reintentable. Se resuelve por **jerarquía**: la clase más específica que coincida gana.
- **`traverseCauses = true`** es clave con `FlatFileItemReader` y con JDBC, porque las excepciones reales vienen envueltas (`FlatFileParseException` → `IncorrectTokenCountException`; `DataAccessException` → `SQLException`).

```java
package cl.duoc.bancoxyz.batch.config;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.batch.item.validator.ValidationException;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.PessimisticLockingFailureException;   // reemplaza a DeadlockLoser… (deprecada)
import org.springframework.dao.TransientDataAccessException;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;

public class RetryPolicies {

    /**
     * Reintenta SOLO fallos transitorios de BD. Los errores de datos sucios
     * (validación) se marcan explícitamente como NO reintentables: reintentar
     * una fila con fecha "2024-13-05" 3 veces es puro desperdicio de CPU.
     */
    public static RetryPolicy bd() {
        Map<Class<? extends Throwable>, Boolean> reintentables = new LinkedHashMap<>();
        reintentables.put(PessimisticLockingFailureException.class, true);  // incluye deadlock
        reintentables.put(CannotAcquireLockException.class,         true);
        reintentables.put(TransientDataAccessException.class,       true);
        reintentables.put(ValidationException.class,                false); // determinista
        reintentables.put(IllegalArgumentException.class,           false); // determinista

        // 3 intentos totales, atravesando la cadena de causas
        return new SimpleRetryPolicy(3, reintentables, true);
    }
}
```

> ⚠️ **`org.springframework.dao.DeadlockLoserDataAccessException` está `@Deprecated(since = "6.0.3")`** en Spring Framework, *"in favor of `PessimisticLockingFailureException`/`CannotAcquireLockException`"*. No la uses en código nuevo: genera warning de compilación y el docente puede penalizarlo. Jerarquía útil: `DeadlockLoser…` → `PessimisticLockingFailureException` → `ConcurrencyFailureException` → `TransientDataAccessException`. Basta con declarar el nivel que cubra tu caso; declarar varios niveles de la misma rama es redundante.

Otras políticas útiles de `org.springframework.retry.policy` (todas verificadas como existentes): `NeverRetryPolicy`, `AlwaysRetryPolicy`, `MaxAttemptsRetryPolicy`, `TimeoutRetryPolicy`, `CircuitBreakerRetryPolicy`, `ExceptionClassifierRetryPolicy`, `CompositeRetryPolicy`.

### 3.3 Backoff — firmas exactas (spring-retry, `org.springframework.retry.backoff`)

```java
// FixedBackOffPolicy
public class FixedBackOffPolicy extends StatelessBackOffPolicy
        implements SleepingBackOffPolicy<FixedBackOffPolicy> {
    private static final long DEFAULT_BACK_OFF_PERIOD = 1000L;   // 1 s
    public void setBackOffPeriod(long backOffPeriod);            // milisegundos
    public void setSleeper(Sleeper sleeper);
}

// ExponentialBackOffPolicy
public class ExponentialBackOffPolicy implements SleepingBackOffPolicy<ExponentialBackOffPolicy> {
    public static final long   DEFAULT_INITIAL_INTERVAL = 100L;    // 100 ms
    public static final long   DEFAULT_MAX_INTERVAL     = 30000L;  // 30 s
    public static final double DEFAULT_MULTIPLIER       = 2;
    public void setInitialInterval(long initialInterval);          // ms
    public void setMultiplier(double multiplier);                  // >1
    public void setMaxInterval(long maxInterval);                  // ms (tope)
    public void setSleeper(Sleeper sleeper);
}

// ExponentialRandomBackOffPolicy extends ExponentialBackOffPolicy  -> añade jitter
// UniformRandomBackOffPolicy: setMinBackOffPeriod(long) / setMaxBackOffPeriod(long)  (500/1500 ms)
// NoBackOffPolicy: sin espera
```

Todas son **`BackOffPolicy`** (`org.springframework.retry.backoff.BackOffPolicy`). Los setters son **void** (JavaBean), **no fluent** — un error clásico es escribir `new ExponentialBackOffPolicy().setInitialInterval(200)` esperando encadenar.

```java
@Bean
public BackOffPolicy backOffExponencial() {
    ExponentialBackOffPolicy backOff = new ExponentialBackOffPolicy();
    backOff.setInitialInterval(200);   // 1er reintento: ~200 ms
    backOff.setMultiplier(2.0);        // 2do: ~400 ms, 3ro: ~800 ms
    backOff.setMaxInterval(5_000);     // techo 5 s
    return backOff;
}

@Bean
public BackOffPolicy backOffFijo() {
    FixedBackOffPolicy backOff = new FixedBackOffPolicy();
    backOff.setBackOffPeriod(500);     // 500 ms entre cada intento
    return backOff;
}
```

> **Nota para el step multi-thread:** el estado por serie de reintentos vive en el `BackOffContext` que devuelve `start(RetryContext)`, así que compartir la instancia entre hilos es la práctica habitual — **pero la documentación oficial no declara garantía de thread-safety**, y los setters mutan estado compartido: configúralos una sola vez, en el `@Bean`. Lo que sí es seguro afirmar: el backoff **bloquea el hilo** (`Thread.sleep` vía `Sleeper`). En un step con `taskExecutor` y pool de 8, un backoff de 5 s puede parar 8 hilos a la vez. Para la comparación de parámetros que pide el enunciado, mide con y sin backoff — el impacto es medible y es un buen dato para el informe.

**Fuentes:** [Configuring Retry Logic (6.0)](https://docs.spring.io/spring-batch/reference/step/chunk-oriented-processing/retry-logic.html) · [ExponentialBackOffPolicy Javadoc](https://docs.spring.io/spring-retry/docs/api/current/org/springframework/retry/backoff/ExponentialBackOffPolicy.html) · [Baeldung: Configuring Retry Logic](https://www.baeldung.com/spring-batch-retry-logic)

---

## 4. RETRY vs SKIP — diferencia crítica y ORDEN de aplicación

### 4.1 Diferencia conceptual

| | **RETRY (reintento)** | **SKIP (omisión)** |
|---|---|---|
| Hipótesis | El fallo es **transitorio y no determinista**. La misma operación puede funcionar en el siguiente intento. | El fallo es **determinista**: el dato es malo y siempre fallará. |
| Acción | Repetir la **misma** operación sobre el **mismo** ítem, N veces. | **Descartar** el ítem y continuar con el siguiente. |
| Ejemplos típicos | `CannotAcquireLockException`, `PessimisticLockingFailureException`, timeout de red, `TransientDataAccessException`. | `FlatFileParseException`, `ValidationException`, `NumberFormatException`. |
| Efecto en tu dataset | Ninguno útil: `fecha=2024-13-05` fallará las 3 veces. | Correcto: descartar las 55 fechas imposibles. |
| Contador en `StepExecution` | `getRollbackCount()` sube **cuando el reintento implica rollback del chunk** (típico en process y write; **no** si la excepción está en `noRollback` y el skip procede en línea, ni necesariamente en reintentos de lectura dentro de la misma transacción) | `getSkipCount()` = read + process + write skip counts |
| Coste | Latencia (sleep del backoff) + rollbacks | Pérdida de datos (¡hay que registrarla! → §8) |

**Antipatrón principal en tu caso:** poner `retry(ValidationException.class)` o `retry(Exception.class)`. Con 371 filas inválidas × 3 intentos × backoff de 200 ms = ~4 minutos de espera pura por un resultado idéntico. Reintenta **solo excepciones de infraestructura**.

### 4.2 Orden: **primero RETRY, después SKIP** — evidencia en código fuente

Spring Batch aplica **siempre retry primero**; el skip es el mecanismo de **recuperación cuando el retry se agota**. Esto no es opinión: en `ChunkOrientedStep` (6.0) la operación va envuelta en el `RetryTemplate`, y el `SkipPolicy` solo se consulta cuando la excepción resultante es una `RetryException` (fragmentos literales del fuente):

```java
// Lectura
private @Nullable I doRead() throws Exception {
    if (this.faultTolerant) {
        Retryable<I> retryableRead = new Retryable<>() {
            @Override public I execute() throws Throwable { return itemReader.read(); }
            @Override public String getName() { return "Retryable read operation"; }
        };
        return this.retryTemplate.execute(retryableRead);   // <-- 1º RETRY
    }
    return this.itemReader.read();
}

// ...y en el catch de readItem():
catch (Exception exception) {
    this.compositeItemReadListener.onReadError(exception);
    if (this.faultTolerant && exception instanceof RetryException retryException) {
        doSkipInRead(retryException, contribution);          // <-- 2º SKIP
    } else {
        throw exception;
    }
    ...
}

private void doSkipInRead(RetryException retryException, StepContribution contribution) {
    Throwable cause = retryException.getCause();
    if (this.skipPolicy.shouldSkip(cause, contribution.getStepSkipCount())) {
        this.compositeSkipListener.onSkipInRead(cause);
        contribution.incrementReadSkipCount();
    } else {
        throw new NonSkippableReadException("Skip policy rejected skipping item", cause);
    }
}
```

Idéntico patrón en `doProcess`/`doSkipInProcess` (con `NonSkippableProcessException`) y en `doWrite`.

**Secuencia completa por ítem (fase read o process):**

```
1. Intento 1  ──fallo──►  ¿RetryPolicy dice reintentable?
                            │ NO ──► ¿SkipPolicy? ── SÍ ► omitir ── NO ► FALLA el step
                            │ SÍ
2.                          ▼ BackOffPolicy.backOff()  (dormir)
3. Intento 2  ──fallo──►  ... hasta agotar retryLimit
4. RETRY AGOTADO ──► RetryException ──► SkipPolicy.shouldSkip(causa, skipCount)
                                          │ true  ► SkipListener + skipCount++ + continuar
                                          │ false ► NonSkippableXxxException ► FALLA el step
```

**Corolario práctico:** una excepción puede estar en **ambas** listas (`retry(X)` **y** `skip(X)`) — significa "intenta N veces; si aun así falla, descártala". Es la configuración correcta para `CannotAcquireLockException` en un writer JDBC bajo carga multi-thread. Lo que **nunca** debe estar en `retry()` es una excepción determinista de datos.

Para el fallo **en write** el flujo es distinto y más caro — ver §7.

---

## 5. `noRollback(Class)` — por qué es decisivo cuando el error es de VALIDACIÓN

### 5.1 El problema

Por defecto, **cualquier** excepción que escape del chunk provoca **rollback de la transacción del chunk completo**. La documentación oficial lo dice así:

> *"By default, regardless of retry or skip, any exceptions thrown from the `ItemWriter` cause the transaction controlled by the `Step` to rollback."*

Con un `chunk(100)` y 371 filas inválidas de 1000, si cada validación fallida rueda atrás el chunk, pagas ~371 rollbacks + re-lecturas + re-procesos. El coste es brutal y no hay ninguna razón técnica: **una `ValidationException` lanzada por el `ItemProcessor` no ha tocado la base de datos**. La transacción sigue perfectamente válida.

### 5.2 La solución y el comportamiento exacto

```java
.faultTolerant()
    .skip(ValidationException.class)
    .noRollback(ValidationException.class)   // <-- ambos, obligatoriamente
```

Javadoc de `noRollback` (literal):
> *"Mark this exception as ignorable during item read or processing operations. Processing continues with no additional callbacks (use skips instead if you need to be notified). **Ignored during write** because there is no guarantee of skip and retry without rollback."*

Y el código de `FaultTolerantChunkProcessor.transform()` (5.2.x) muestra exactamente qué pasa:

```java
catch (Exception e) {
    status = BatchMetrics.STATUS_FAILURE;
    if (rollbackClassifier.classify(e)) {
        // Default is to rollback unless the classifier allows us to continue
        throw e;                                  // ── ROLLBACK del chunk entero
    }
    else if (shouldSkip(itemProcessSkipPolicy, e, contribution.getStepSkipCount())) {
        contribution.incrementProcessSkipCount();
        logger.debug("Skipping after failed process with no rollback", e);
        callProcessSkipListener(item, e);         // ── SKIP EN LÍNEA, SIN ROLLBACK
    }
    else {
        throw new NonSkippableProcessException(
            "Non-skippable exception in processor.  Make sure any exceptions that do not "
            + "cause a rollback are skippable.", e);
    }
}
```

**Tres conclusiones verificadas:**

1. **`noRollback(X)` + `skip(X)` ⇒ el ítem se descarta *inline*, sin rollback, sin re-lectura, sin re-proceso del resto del chunk.** Es el camino barato. Los otros 99 ítems del chunk siguen su curso normal.
2. **`noRollback(X)` SIN `skip(X)` ⇒ `NonSkippableProcessException` y el step FALLA.** El propio mensaje de error del framework lo dice: *"Make sure any exceptions that do not cause a rollback are skippable."* Es el error de configuración más común con `noRollback`.
3. **`noRollback` NO tiene efecto en el `ItemWriter`.** Si tu validación se dispara al escribir (constraint de BD), el rollback ocurre igual y entras en chunk scanning (§7). Por eso: **valida en el processor, nunca dejes que la BD sea tu validador.**

> **Nota 6.0:** `ChunkOrientedStepBuilder` **no expone `noRollback()`**, y la página *Controlling Rollback* de la referencia **ya no existe** en la versión current (404); sólo sobrevive en la rama 5.1. En su lugar, `ChunkOrientedStep.processItem()` ya no relanza la excepción cuando el skip procede (llama a `doSkipInProcess` y sigue), lo que hace que el skip en process sea *inline por defecto*. **Incierto:** no hay declaración explícita en la guía de migración de que `noRollback` sea intencionalmente innecesario en 6.0; se deduce del código. Si vas a 6.0, verifícalo con un test.

### 5.3 Excepción de validación personalizada para Banco XYZ ✅

```java
package cl.duoc.bancoxyz.batch.error;

import org.springframework.batch.item.validator.ValidationException;

/**
 * Excepción de validación de negocio. Extiende ValidationException de Spring Batch
 * para que un solo .skip(ValidationException.class) las cubra todas.
 * Lleva el nº de línea y el motivo, para el dead letter.
 */
public class RegistroInvalidoException extends ValidationException {

    private final long numeroLinea;
    private final String campo;
    private final String valorCrudo;
    private final String motivo;

    public RegistroInvalidoException(long numeroLinea, String campo,
                                     String valorCrudo, String motivo) {
        super("Linea %d - campo '%s' valor '%s': %s"
                .formatted(numeroLinea, campo, valorCrudo, motivo));
        this.numeroLinea = numeroLinea;
        this.campo = campo;
        this.valorCrudo = valorCrudo;
        this.motivo = motivo;
    }

    public long getNumeroLinea() { return numeroLinea; }
    public String getCampo()     { return campo; }
    public String getValorCrudo(){ return valorCrudo; }
    public String getMotivo()    { return motivo; }
}
```

`ValidationException` está en `org.springframework.batch.item.validator` (5.2.x) / `org.springframework.batch.infrastructure.item.validator` (6.0). Extiende `ItemReaderException`, que es `abstract class … extends RuntimeException` → **es no comprobada**, así que no obliga a `throws`. Sólo tiene constructores `(String)` y `(String, Throwable)`: tu subclase **debe** llamar a `super(mensaje)`.

**Fuentes:** [Controlling Rollback (5.1)](https://docs.spring.io/spring-batch/reference/5.1/step/chunk-oriented-processing/controlling-rollback.html)

---

## 6. LISTENERS — firmas actuales y registro

### 6.1 `SkipListener` — el más importante para el dead letter

```java
package org.springframework.batch.core;            // 5.2.x
// package org.springframework.batch.core.listener; // 6.0.x

public interface SkipListener<T, S> extends StepListener {

    /** Fallo en lectura, legal, no se relanza. OJO (Javadoc literal): "In case a
     *  transaction is rolled back and items are re-read, this callback occurs
     *  repeatedly for the same cause. This happens only if read items are not buffered." */
    default void onSkipInRead(Throwable t) { }

    /** El ítem falló en procesamiento y se decidió omitirlo. */
    default void onSkipInProcess(T item, Throwable t) { }

    /** El ítem falló en escritura y se decidió omitirlo. */
    default void onSkipInWrite(S item, Throwable t) { }
}
```

- Los tres métodos son **`default`** desde Spring Batch 5 → implementa solo los que uses.
- `T` = tipo de entrada (salida del reader), `S` = tipo de salida (entrada del writer).
- **`onSkipInRead` NO recibe el ítem** (obviamente: falló al leerlo). Solo el `Throwable`. Para saber *qué línea* falló, tienes que sacarlo de la excepción: `FlatFileParseException.getLineNumber()` y `.getInput()`.
- Anotaciones equivalentes **en 5.2.x**: `@OnSkipInRead`, `@OnSkipInProcess`, `@OnSkipInWrite` (paquete `org.springframework.batch.core.annotation`), registradas vía `.listener(Object)`.
  ⚠️ **En 6.0 estas tres anotaciones ya NO se escanean** por `ChunkOrientedStepBuilder.listener(Object)` (su escaneo cubre sólo las 14 anotaciones de step/chunk/read/process/write). En 6.0 usa `skipListener(SkipListener)` o implementa la interfaz.

### 6.2 `RetryListener` (spring-retry 2.x, Spring Batch 5.2.x)

```java
package org.springframework.retry;

public interface RetryListener {

    default <T, E extends Throwable> boolean open(RetryContext context, RetryCallback<T, E> callback) {
        return true;   // devolver false veta el retry -> TerminatedRetryException
    }

    default <T, E extends Throwable> void close(RetryContext context, RetryCallback<T, E> callback,
                                                Throwable throwable) { }

    /** @since 2.0 */
    default <T, E extends Throwable> void onSuccess(RetryContext context, RetryCallback<T, E> callback,
                                                    T result) { }

    default <T, E extends Throwable> void onError(RetryContext context, RetryCallback<T, E> callback,
                                                  Throwable throwable) { }
}
```

`RetryContext` te da `getRetryCount()` y `getLastThrowable()`. `open()` se llama **una vez por serie de reintentos**, `onError()` **una vez por intento fallido**, `close()` al final.

### 6.3 `RetryListener` en Spring Batch 6.0 (¡API totalmente distinta!)

```java
package org.springframework.core.retry;   // Spring Framework 7 (@since 7.0)

public interface RetryListener {
    default void onRetryableExecution(RetryPolicy p, Retryable<?> r, RetryState s) { }  // @since 7.0.2
    default void beforeRetry(RetryPolicy p, Retryable<?> r, RetryState s) { }           // @since 7.0.4
    default void beforeRetry(RetryPolicy p, Retryable<?> r) { }
    default void onRetrySuccess(RetryPolicy p, Retryable<?> r, @Nullable Object result) { }
    default void onRetryFailure(RetryPolicy p, Retryable<?> r, Throwable throwable) { }
    default void onRetryPolicyExhaustion(RetryPolicy p, Retryable<?> r, RetryException e) { }
    default void onRetryPolicyInterruption(RetryPolicy p, Retryable<?> r, RetryException e) { }
    default void onRetryPolicyTimeout(RetryPolicy p, Retryable<?> r, RetryException e) { } // @since 7.0.2
}
```
Nada en común con la de spring-retry. Registro: `.retryListener(RetryListener)` en `ChunkOrientedStepBuilder`.

### 6.4 `ItemReadListener`, `ItemProcessListener`, `ItemWriteListener`, `ChunkListener`, `StepExecutionListener`

```java
package org.springframework.batch.core;   // 5.2.x (en 6.0: ...core.listener)

public interface ItemReadListener<T> extends StepListener {
    default void beforeRead() { }
    default void afterRead(T item) { }
    default void onReadError(Exception ex) { }
}

public interface ItemProcessListener<T, S> extends StepListener {
    default void beforeProcess(T item) { }
    default void afterProcess(T item, @Nullable S result) { }
    default void onProcessError(T item, Exception e) { }
}

public interface ItemWriteListener<S> extends StepListener {
    default void beforeWrite(Chunk<? extends S> items) { }
    default void afterWrite(Chunk<? extends S> items) { }
    default void onWriteError(Exception exception, Chunk<? extends S> items) { }
}

public interface ChunkListener extends StepListener {
    String ROLLBACK_EXCEPTION_KEY = "sb_rollback_exception";
    default void beforeChunk(ChunkContext context) { }
    default void afterChunk(ChunkContext context) { }
    default void afterChunkError(ChunkContext context) { }   // aquí recuperas la excepción
}

public interface StepExecutionListener extends StepListener {
    default void beforeStep(StepExecution stepExecution) { }
    @Nullable
    default ExitStatus afterStep(StepExecution stepExecution) { return null; }  // null = no cambiar
}
```

Nota: `ItemWriteListener` recibe un **`Chunk<? extends S>`** (no un `List<S>`) desde Spring Batch 5.0. Y en `afterChunkError` recuperas la excepción con:
```java
Throwable t = (Throwable) context.getAttribute(ChunkListener.ROLLBACK_EXCEPTION_KEY);
```

### 6.5 Registro de listeners — ⚠️ SECCIÓN CORREGIDA

Formas válidas:

```java
// 1) Tipada (recomendada, con seguridad en compilación)
.faultTolerant()
    .listener((SkipListener<TransaccionRaw, Transaccion>) miSkipListener)
    .listener((RetryListener) miRetryListener)
    .listener((ChunkListener) miChunkListener)

// 2) Por anotaciones: .listener(Object)  [válido en 5.2.x; ver salvedad de §6.1 para 6.0]
.listener(new Object() {
    @OnSkipInProcess
    public void alOmitir(TransaccionRaw item, Throwable t) { /* ... */ }
})

// 3) A nivel de Step (fuera de faultTolerant), para StepExecutionListener
new StepBuilder("step", jobRepository)
    .listener(miStepExecutionListener)
    ...
```

**🔧 CORRECCIÓN — la trampa real de las sobrecargas.** Si tu bean implementa **varias** interfaces de listener (p. ej. `SkipListener` + `StepExecutionListener`), la llamada `.listener(bean)` **sin cast no compila**. javac 21 con spring-batch-core 5.2.6 emite:

```
error: reference to listener is ambiguous
  both method listener(StepExecutionListener) in StepBuilderHelper
   and method listener(SkipListener<? super I,? super O>) in FaultTolerantStepBuilder match
```

No hay "registro a medias": es un **error de compilación**, y las dos sobrecargas son máximamente específicas e incomparables entre sí.

**🔧 CORRECCIÓN — y la buena noticia: para un bean dual basta UNA llamada.** `FaultTolerantStepBuilder.build()` ejecuta antes que nada:

```java
@Override
public TaskletStep build() {
    registerStepListenerAsSkipListener();
    return super.build();
}

protected void registerStepListenerAsSkipListener() {
    for (StepExecutionListener stepExecutionListener : properties.getStepExecutionListeners()) {
        if (stepExecutionListener instanceof SkipListener) {
            listener((SkipListener<I, O>) stepExecutionListener);   // <-- auto-registro
        }
    }
    for (ChunkListener chunkListener : this.chunkListeners) {
        if (chunkListener instanceof SkipListener) {
            listener((SkipListener<I, O>) chunkListener);
        }
    }
}
```

Es decir: **`.listener((StepExecutionListener) bean)` registra el bean como `StepExecutionListener` Y, si además implementa `SkipListener`, también como skip listener.** Ésa es la forma canónica.

**🔧 CORRECCIÓN CRÍTICA — `listener(SkipListener)` NO escanea anotaciones.** Su implementación completa es:
```java
public FaultTolerantStepBuilder<I, O> listener(SkipListener<? super I, ? super O> listener) {
    skipListeners.add(listener);
    return this;
}
```
Sólo `listener(Object)` escanea `@BeforeStep`, `@AfterStep`, `@OnSkipIn*`, etc. **Si registras un bean con `@BeforeStep` casteándolo a `SkipListener`, ese `@BeforeStep` nunca se ejecuta.** Éste es exactamente el bug que corrige el §8.3/§8.5 de este informe.

**En 6.0** el problema desaparece por diseño: hay métodos separados (`skipListener()`, `retryListener()`, `listener(StepListener)`) y `ChunkOrientedStepBuilder.registerTypedListener()` hace `instanceof` contra las seis interfaces (`ItemReadListener`, `ItemProcessListener`, `ItemWriteListener`, `ChunkListener`, `SkipListener`, `StepExecutionListener`) y registra todas.

---

## 7. El problema del "rollback y re-lectura" del chunk (chunk scanning)

Este es el mecanismo peor documentado de Spring Batch, y el que más destruye el rendimiento si escribes con `skip` activo. Hay un issue abierto pidiendo documentarlo: [spring-batch#3946 "Improve documentation with regard to chunk scanning"](https://github.com/spring-projects/spring-batch/issues/3946).

### 7.1 Por qué existe

La firma del writer es `void write(Chunk<? extends S> items)` — **escribe el chunk entero, no ítem a ítem**. Cuando el writer lanza una excepción, Spring Batch **no sabe qué ítem del chunk la causó**. Y la transacción ya está sucia: hay que hacer rollback.

Como el skip requiere identificar el ítem culpable, Spring Batch entra en **modo scan**: rueda atrás la transacción y **vuelve a procesar el chunk ítem por ítem, cada uno en su propia transacción**, hasta descubrir cuál falla.

### 7.2 El flujo exacto (literal de `ChunkOrientedStep` 6.0; concepto idéntico en `FaultTolerantChunkProcessor` 5.2)

```java
// writeChunk(): tras agotar el retry
catch (Exception exception) {
    this.compositeItemWriteListener.onWriteError(exception, chunk);
    ...
    if (this.faultTolerant && exception instanceof RetryException retryException
            && this.skipPolicy.shouldSkip(retryException.getCause(), -1)) {   // <-- SONDA
        logger.info("Retry exhausted, entering scan mode for next transaction", retryException);
        this.chunkTracker.get().enterScanMode(scanItems);
    }
    else {
        logger.error("Retry exhausted after last attempt in recovery path, but exception is not skippable");
    }
    throw exception;   // ROLLBACK
}
```

```java
/*
 * Re-attempt a single item in its own transaction after the enclosing chunk has been
 * rolled back. Unless the item processor has been marked as non-transactional, the
 * item is re-processed first: the output produced in the rolled back transaction may
 * have been mutated by the failed write (a JPA entity whose flush failed, for
 * example) and would otherwise fail again for an unrelated reason.
 */
private Chunk<O> scan(ScanItem<I, O> scanItem, StepContribution contribution,
                      TransactionStatus status) throws Exception {
    O item = this.processorTransactional ? processItem(scanItem.input(), contribution)
                                         : scanItem.output();
    if (item == null) return new Chunk<>();
    Chunk<O> singleItemChunk = new Chunk<>(item);
    try {
        this.compositeItemWriteListener.beforeWrite(singleItemChunk);
        this.itemWriter.write(singleItemChunk);           // <-- CHUNK DE 1 ÍTEM
        contribution.incrementWriteCount(singleItemChunk.size());
        this.compositeItemWriteListener.afterWrite(singleItemChunk);
    }
    catch (Exception exception) {
        if (this.skipPolicy.shouldSkip(exception, contribution.getStepSkipCount())) {
            this.compositeSkipListener.onSkipInWrite(item, exception);
            contribution.incrementWriteSkipCount();
            contribution.getStepExecution().incrementRollbackCount();
            status.setRollbackOnly();
            notifyChunkError(exception, singleItemChunk);
        }
        else {
            logger.error("Failed to write item: " + item, exception);
            this.compositeItemWriteListener.onWriteError(exception, singleItemChunk);
            notifyChunkError(exception, singleItemChunk);
            throw new NonSkippableWriteException("Skip policy rejected skipping item", exception);
        }
    }
    return singleItemChunk;
}
```

### 7.3 Consecuencias prácticas (medibles y examinables)

Con `chunk(100)` y **1 ítem malo** en el chunk:

| Sin scan (todo OK) | Con scan (1 ítem malo) |
|---|---|
| 1 transacción | 1 transacción fallida + rollback + **100 transacciones** de 1 ítem |
| 1 llamada a `writer.write()` con 100 ítems | **101** llamadas a `writer.write()`, 100 de ellas con 1 solo ítem |
| 0 llamadas extra al processor | **100** re-invocaciones del `ItemProcessor` (si es transaccional, que es el default) |
| — | `beforeWrite`/`afterWrite` disparados 100 veces más |

Esto explica el bug reportado en #3946: "10 llamadas en vez de las 5 esperadas".

**Efectos colaterales que rompen tests y writers:**
- **`ItemWriter` no idempotente**: los 99 ítems buenos del chunk **se escriben dos veces** si tu writer ya los había materializado antes de fallar sin transacción real (típico con archivos, colas, o REST). Con JDBC/JPA el rollback lo protege; con `FlatFileItemWriter` **no**.
- **`ItemProcessor` con efectos secundarios** (contadores, llamadas externas) se ejecuta múltiples veces sobre el mismo ítem.
- **`onSkipInRead` se dispara repetidamente** para la misma causa cuando hay rollback y re-lectura y los ítems no están buffereados (lo dice el propio Javadoc de `SkipListener`).

### 7.4 Cómo evitarlo — receta para Banco XYZ

1. **Detecta lo malo en el `ItemProcessor`, nunca en el writer.** Un skip en process con `noRollback` es *inline* (§5.2): sin rollback, sin scan, sin re-proceso. Coste ~0.
2. Escribe con `JdbcBatchItemWriter` y deja que **solo** errores de infraestructura lleguen al writer.
3. Si sabes que habrá errores de write inevitables, **reduce el `chunk` size** para ese step: el coste del scan es O(chunkSize).
4. `processorNonTransactional()` evita las re-invocaciones del processor durante el scan (cachea la salida). **Solo si el output del processor es seguro de reescribir tras un rollback** — el Javadoc 6.0 advierte explícitamente: *"Set this flag only if the output of the processor is safe to write again after a failed, rolled back write. This is typically not the case for items that the writer mutates, like JPA entities: a failed flush can leave the entity in a state that makes the next write attempt fail with an unrelated exception."* Con DTOs inmutables y `JdbcBatchItemWriter`, es seguro.

---

## 8. Excepciones de VALIDACIÓN omitibles + contador de rechazados a "dead letter"

### 8.1 Estrategia recomendada para tus tres archivos

Tienes ~40% de datos sucios. **Distingue dos categorías**, porque tienen coste y semántica distintos:

| Categoría | Ejemplos de tu dataset | Mecanismo | ¿Cuenta como skip? | Coste |
|---|---|---|---|---|
| **Filtrado** (esperado, alto volumen) | `tipo='invalid'` (371), `tipo='-1'` (279), duplicados (9) | `ItemProcessor` devuelve `null` | No → `filterCount` | Cero |
| **Skip** (excepcional, bajo volumen) | fecha mes 13 (55), formato irreconocible, `edad=150` (52) | lanza `RegistroInvalidoException` + `.skip()` + `.noRollback()` | Sí → `processSkipCount` | Bajo (inline) |
| **Retry** | contención de bloqueo en el `UPDATE` de saldo del Job 2 bajo multi-thread | `.retry(CannotAcquireLockException.class)` | No | Latencia |

Para la evaluación conviene demostrar **las tres** rutas. Si el docente exige que todo lo inválido sea "rechazado", puedes hacer que el `null` del filtrado también escriba al dead letter (desde el processor, antes de devolver `null`) — así el conteo cuadra sin pagar el coste del skip.

### 8.2 Tabla de dead letter (PostgreSQL)

```sql
CREATE TABLE batch_registro_rechazado (
    id               BIGSERIAL     PRIMARY KEY,
    job_execution_id BIGINT        NOT NULL,
    step_name        VARCHAR(100)  NOT NULL,
    fase             VARCHAR(10)   NOT NULL,   -- READ | PROCESS | WRITE | FILTER
    numero_linea     BIGINT,
    payload_crudo    TEXT,                     -- la línea original del CSV
    excepcion        VARCHAR(255)  NOT NULL,   -- FQCN
    motivo           TEXT,
    fecha_rechazo    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_rechazado_job ON batch_registro_rechazado(job_execution_id);
CREATE INDEX idx_rechazado_fase ON batch_registro_rechazado(step_name, fase);
```

### 8.3 `SkipListener` con dead letter dual (tabla + archivo) — ✅ CORREGIDO

> **🔧 Qué cambió respecto de la versión original y por qué:** la versión anterior capturaba el contexto con `@BeforeStep`. Como el step la registraba con `.listener((SkipListener<…>) deadLetter)`, y esa sobrecarga **no escanea anotaciones**, `@BeforeStep` nunca se ejecutaba: todas las filas del dead letter salían con `job_execution_id = 0` y `step_name = "desconocido"`. La corrección es implementar `StepExecutionListener` y sobrescribir `beforeStep(...)`; al registrarlo con `.listener((StepExecutionListener) deadLetter)`, `registerStepListenerAsSkipListener()` lo registra **también** como `SkipListener` automáticamente (§6.5).

```java
package cl.duoc.bancoxyz.batch.listener;

import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.SkipListener;          // 6.0: ...core.listener.SkipListener
import org.springframework.batch.core.StepExecution;         // 6.0: ...core.step.StepExecution
import org.springframework.batch.core.StepExecutionListener; // 6.0: ...core.listener.StepExecutionListener
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.jdbc.core.JdbcTemplate;

import cl.duoc.bancoxyz.batch.error.RegistroInvalidoException;
import cl.duoc.bancoxyz.batch.model.TransaccionRaw;
import cl.duoc.bancoxyz.batch.model.Transaccion;

/**
 * Dead letter para el Job 1 (Reporte de Transacciones Diarias).
 * Escribe cada registro rechazado en (a) tabla batch_registro_rechazado
 * y (b) un CSV de rechazos, y lleva contadores por fase.
 *
 * Implementa StepExecutionListener (no @BeforeStep) porque la sobrecarga
 * listener(SkipListener) NO escanea anotaciones. Al registrarlo como
 * StepExecutionListener, FaultTolerantStepBuilder.registerStepListenerAsSkipListener()
 * lo registra ademas como SkipListener.
 *
 * ATENCIÓN: los callbacks pueden invocarse MÁS DE UNA VEZ para la misma causa
 * cuando hay rollback y re-lectura (ver Javadoc de onSkipInRead). El insert usa
 * job_execution_id + numero_linea para poder deduplicar en la consulta final.
 */
public class DeadLetterSkipListener
        implements SkipListener<TransaccionRaw, Transaccion>, StepExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(DeadLetterSkipListener.class);

    private static final String INSERT = """
        INSERT INTO batch_registro_rechazado
            (job_execution_id, step_name, fase, numero_linea, payload_crudo, excepcion, motivo)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """;

    private final JdbcTemplate jdbcTemplate;
    private final Path archivoRechazos;

    private final AtomicLong rechazosRead    = new AtomicLong();
    private final AtomicLong rechazosProcess = new AtomicLong();
    private final AtomicLong rechazosWrite   = new AtomicLong();

    private volatile long jobExecutionId;
    private volatile String stepName = "desconocido";

    public DeadLetterSkipListener(JdbcTemplate jdbcTemplate, Path archivoRechazos) {
        this.jdbcTemplate = jdbcTemplate;
        this.archivoRechazos = archivoRechazos;
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        this.jobExecutionId = stepExecution.getJobExecutionId();   // devuelve Long -> autounboxing
        this.stepName = stepExecution.getStepName();
    }

    @Override
    public void onSkipInRead(Throwable t) {
        rechazosRead.incrementAndGet();
        long linea = -1L;
        String crudo = null;
        if (t instanceof FlatFileParseException ffpe) {
            linea = ffpe.getLineNumber();
            crudo = ffpe.getInput();
        }
        registrar("READ", linea, crudo, t, t.getMessage());
    }

    @Override
    public void onSkipInProcess(TransaccionRaw item, Throwable t) {
        rechazosProcess.incrementAndGet();
        long linea = (t instanceof RegistroInvalidoException rie) ? rie.getNumeroLinea() : -1L;
        String motivo = (t instanceof RegistroInvalidoException rie) ? rie.getMotivo() : t.getMessage();
        registrar("PROCESS", linea, String.valueOf(item), t, motivo);
    }

    @Override
    public void onSkipInWrite(Transaccion item, Throwable t) {
        rechazosWrite.incrementAndGet();
        registrar("WRITE", -1L, String.valueOf(item), t, t.getMessage());
    }

    private void registrar(String fase, long linea, String crudo, Throwable t, String motivo) {
        // El dead letter NUNCA debe tumbar el step: cualquier fallo se traga y se loguea.
        try {
            jdbcTemplate.update(INSERT, jobExecutionId, stepName, fase, linea,
                                truncar(crudo, 4000), t.getClass().getName(), truncar(motivo, 2000));
        }
        catch (RuntimeException e) {
            log.error("No se pudo persistir el rechazo en dead letter (fase={}, linea={})",
                      fase, linea, e);
        }
        try (Writer w = Files.newBufferedWriter(archivoRechazos, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            w.write("%d;%s;%s;%d;%s;%s;%s%n".formatted(
                    jobExecutionId, stepName, fase, linea,
                    escapar(crudo), t.getClass().getSimpleName(), escapar(motivo)));
        }
        catch (IOException e) {
            log.error("No se pudo escribir el archivo de rechazos", e);
        }
    }

    private static String truncar(String s, int max) {
        return (s == null || s.length() <= max) ? s : s.substring(0, max);
    }

    private static String escapar(String s) {
        return s == null ? "" : s.replace('\n', ' ').replace('\r', ' ').replace(';', ',');
    }

    public long getRechazosRead()    { return rechazosRead.get(); }
    public long getRechazosProcess() { return rechazosProcess.get(); }
    public long getRechazosWrite()   { return rechazosWrite.get(); }
    public long getTotalRechazos()   { return rechazosRead.get() + rechazosProcess.get()
                                            + rechazosWrite.get(); }
}
```

> **Importante sobre el `JdbcTemplate` dentro del listener:** `onSkipInProcess` con `noRollback` se ejecuta **dentro de la transacción del chunk**. Si el chunk luego rueda atrás por otra razón, tus inserts de dead letter también se pierden. Para garantizar la persistencia del rechazo, usa un `TransactionTemplate` con **`PROPAGATION_REQUIRES_NEW`** o escribe primero al archivo (que no es transaccional). Para la evaluación, el archivo CSV de rechazos es la opción más simple y demostrable.

### 8.4 `StepExecutionListener` con resumen y `ExitStatus` condicional ✅

```java
package cl.duoc.bancoxyz.batch.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

public class ResumenStepListener implements StepExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(ResumenStepListener.class);

    /** Si más del N% de las filas se rechaza, el archivo es sospechoso. */
    private final double umbralRechazo;

    public ResumenStepListener(double umbralRechazo) {
        this.umbralRechazo = umbralRechazo;
    }

    @Override
    public void beforeStep(StepExecution se) {
        log.info("=== Inicio step '{}' (jobExecutionId={}) ===",
                 se.getStepName(), se.getJobExecutionId());
    }

    @Override
    public ExitStatus afterStep(StepExecution se) {
        long leidos     = se.getReadCount();
        long escritos   = se.getWriteCount();
        long filtrados  = se.getFilterCount();
        long skipRead   = se.getReadSkipCount();
        long skipProc   = se.getProcessSkipCount();
        long skipWrite  = se.getWriteSkipCount();
        long skipTotal  = se.getSkipCount();          // suma de los tres
        long rollbacks  = se.getRollbackCount();
        long commits    = se.getCommitCount();

        log.info("""
                 === Fin step '{}' ===
                   leidos={}  escritos={}  filtrados={}
                   skip: read={} process={} write={} TOTAL={}
                   commits={}  rollbacks={}
                   estado={}""",
                 se.getStepName(), leidos, escritos, filtrados,
                 skipRead, skipProc, skipWrite, skipTotal,
                 commits, rollbacks, se.getStatus());

        if (leidos > 0 && ((double) skipTotal / leidos) > umbralRechazo) {
            log.warn("Tasa de rechazo {}% supera el umbral {}%: revisar calidad del origen",
                     Math.round(100.0 * skipTotal / leidos), Math.round(100 * umbralRechazo));
            return new ExitStatus("COMPLETED_WITH_WARNINGS",
                    "Rechazados %d de %d registros".formatted(skipTotal, leidos));
        }
        return null;   // null = conservar el ExitStatus por defecto
    }
}
```
> Todos los contadores de `StepExecution` (`getReadCount`, `getWriteCount`, `getFilterCount`, `getSkipCount`, `getRollbackCount`, `getCommitCount`, …) devuelven **`long`** desde Spring Batch 5.0. `getJobExecutionId()` devuelve `Long` (boxed).

Devolver un `ExitStatus` personalizado te permite luego ramificar el flujo del job:
```java
.start(stepTransacciones)
    .on("COMPLETED_WITH_WARNINGS").to(stepNotificarCalidad)
    .from(stepTransacciones).on("*").to(stepResumen)
.end()
```

### 8.5 Step completo del Job 1 (ensamblado, Spring Batch 5.2.x) — ✅ CORREGIDO

```java
package cl.duoc.bancoxyz.batch.config;

import java.nio.file.Path;

import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.retry.backoff.BackOffPolicy;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.transaction.PlatformTransactionManager;

import cl.duoc.bancoxyz.batch.listener.DeadLetterSkipListener;
import cl.duoc.bancoxyz.batch.listener.ResumenStepListener;
import cl.duoc.bancoxyz.batch.model.Transaccion;
import cl.duoc.bancoxyz.batch.model.TransaccionRaw;
import cl.duoc.bancoxyz.batch.policy.BancoXyzSkipPolicy;

@Configuration
public class TransaccionesStepConfig {

    @Bean
    public DeadLetterSkipListener deadLetterTransacciones(JdbcTemplate jdbcTemplate) {
        return new DeadLetterSkipListener(jdbcTemplate,
                Path.of("target/rechazos-transacciones.csv"));
    }

    @Bean
    public BackOffPolicy backOffTransacciones() {
        ExponentialBackOffPolicy backOff = new ExponentialBackOffPolicy();
        backOff.setInitialInterval(200);
        backOff.setMultiplier(2.0);
        backOff.setMaxInterval(5_000);
        return backOff;
    }

    @Bean
    public Step stepTransaccionesDiarias(
            JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            ItemReader<TransaccionRaw> transaccionesReader,
            ItemProcessor<TransaccionRaw, Transaccion> transaccionesProcessor,
            ItemWriter<Transaccion> transaccionesWriter,
            DeadLetterSkipListener deadLetter,
            BackOffPolicy backOffTransacciones) {

        return new StepBuilder("stepTransaccionesDiarias", jobRepository)
                .<TransaccionRaw, Transaccion>chunk(100, transactionManager)
                .reader(transaccionesReader)
                .processor(transaccionesProcessor)
                .writer(transaccionesWriter)

                .faultTolerant()

                // --- OMISIÓN: política personalizada (NO combinar con .skip()/.skipLimit())
                .skipPolicy(new BancoXyzSkipPolicy(500))

                // --- REINTENTO: solo fallos transitorios de infraestructura.
                //     TransientDataAccessException ya cubre deadlocks y fallos de bloqueo;
                //     CannotAcquireLockException se deja explícito por legibilidad.
                .retry(CannotAcquireLockException.class)
                .retry(TransientDataAccessException.class)
                .retryLimit(3)                       // 3 intentos TOTALES (1 + 2 reintentos)
                .backOffPolicy(backOffTransacciones)
                // OJO (§3.1): noRetry solo surte efecto porque aquí NO hay retryPolicy() propio
                .noRetry(ValidationException.class)
                .noRetry(FlatFileParseException.class)

                // --- SIN ROLLBACK: la validación no ensucia la transacción
                .noRollback(ValidationException.class)
                .noRollback(FlatFileParseException.class)

                // --- LISTENERS: una sola llamada por bean, casteada.
                //     deadLetter implementa StepExecutionListener + SkipListener:
                //     registerStepListenerAsSkipListener() lo registra como AMBOS.
                .listener((StepExecutionListener) deadLetter)
                .listener((StepExecutionListener) new ResumenStepListener(0.50))
                .build();
    }
}
```
> ✅ Verificado: compila **sin warnings** con `-Xlint:deprecation,unchecked` contra `spring-batch-core:5.2.6`.

### 8.6 El `ItemProcessor` que decide: filtrar vs. rechazar ✅

```java
package cl.duoc.bancoxyz.batch.processor;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Set;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.lang.Nullable;

import cl.duoc.bancoxyz.batch.error.RegistroInvalidoException;
import cl.duoc.bancoxyz.batch.model.Transaccion;
import cl.duoc.bancoxyz.batch.model.TransaccionRaw;

public class TransaccionProcessor implements ItemProcessor<TransaccionRaw, Transaccion> {

    /** Los 4 formatos presentes en transacciones.csv y cuentas_anuales.csv. */
    private static final List<DateTimeFormatter> FORMATOS = List.of(
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd"));

    private static final Set<String> TIPOS_BASURA = Set.of("invalid", "desconocido", "-1", "unknown");
    private static final Set<String> TIPOS_VALIDOS = Set.of("deposito", "retiro", "pago", "compra");

    @Override
    @Nullable
    public Transaccion process(TransaccionRaw raw) {

        // (A) FILTRADO: basura esperada y masiva (371 filas). Devolver null:
        //     NO cuenta como skip, NO consume el skipLimit, coste cero.
        if (raw.tipo() == null || TIPOS_BASURA.contains(raw.tipo().trim().toLowerCase())) {
            return null;   // -> incrementa filterCount
        }

        // (B) RECHAZO: anomalía que sí queremos auditar. Excepción omitible.
        String tipoNormalizado = normalizarTipo(raw.tipo());
        if (!TIPOS_VALIDOS.contains(tipoNormalizado)) {
            throw new RegistroInvalidoException(raw.linea(), "tipo", raw.tipo(),
                    "tipo de transaccion no reconocido");
        }

        LocalDate fecha = parsearFecha(raw);   // lanza RegistroInvalidoException si mes=13

        if (raw.monto() == null || raw.monto().isBlank()) {
            throw new RegistroInvalidoException(raw.linea(), "monto", raw.monto(), "monto vacio");
        }
        java.math.BigDecimal monto;
        try {
            monto = new java.math.BigDecimal(raw.monto().trim());
        }
        catch (NumberFormatException e) {
            throw new RegistroInvalidoException(raw.linea(), "monto", raw.monto(), "monto no numerico");
        }
        if (monto.signum() < 0) {
            throw new RegistroInvalidoException(raw.linea(), "monto", raw.monto(), "monto negativo");
        }

        return new Transaccion(raw.id(), fecha, monto, tipoNormalizado);
    }

    /** Normaliza 'depósito' (con tilde, 52 filas) -> 'deposito'. */
    private String normalizarTipo(String tipo) {
        return java.text.Normalizer.normalize(tipo.trim().toLowerCase(),
                        java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }

    private LocalDate parsearFecha(TransaccionRaw raw) {
        String valor = raw.fecha() == null ? "" : raw.fecha().trim();
        for (DateTimeFormatter f : FORMATOS) {
            try {
                return LocalDate.parse(valor, f);   // mes 13 -> DateTimeParseException
            }
            catch (DateTimeParseException ignorado) {
                // probar el siguiente formato
            }
        }
        throw new RegistroInvalidoException(raw.linea(), "fecha", valor,
                "formato no reconocido o fecha imposible");
    }
}
```

> 🧪 **Detalle fino, verificado ejecutando en JDK 21:** `DateTimeFormatter.ofPattern("yyyy-MM-dd")` con `ResolverStyle.SMART` (el default) **rechaza `2024-13-05`** con `DateTimeParseException`, pero **acepta `2024-02-30` y devuelve `2024-02-29`**. Si necesitas rechazar también esas, usa `.withResolverStyle(ResolverStyle.STRICT)` **y** patrón con `uuuu` en vez de `yyyy` (`STRICT` exige era): `DateTimeFormatter.ofPattern("uuuu-MM-dd").withResolverStyle(ResolverStyle.STRICT)` sí rechaza `2024-02-30`. Es un punto que suele valorarse en la rúbrica.
>
> Nota 6.0: `org.springframework.lang.Nullable` está en desuso en Spring Framework 7 en favor de JSpecify (`org.jspecify.annotations.Nullable`). En 5.2.x/Spring 6 es correcto.

---

## 9. RESTARTABILIDAD

### 9.1 Identidad de `JobInstance` y `JobParametersIncrementer`

Un `JobInstance` se identifica por **nombre del job + parámetros identificadores**. Relanzar con los mismos parámetros:
- si la ejecución anterior terminó en `FAILED`/`STOPPED` → **reinicio** (retoma donde quedó).
- si terminó en `COMPLETED` → **`JobInstanceAlreadyCompleteException`**.

Para forzar una **instancia nueva** en cada corrida (lo típico en desarrollo y demos), usas un incrementer:

```java
package org.springframework.batch.core;                       // 5.2.x
// package org.springframework.batch.core.job.parameters;      // 6.0.x

@FunctionalInterface
public interface JobParametersIncrementer {
    JobParameters getNext(@Nullable JobParameters parameters);
}
```

`RunIdIncrementer` añade/incrementa un parámetro `run.id`:
- **5.2.x**: `org.springframework.batch.core.launch.support.RunIdIncrementer`
- **6.0.x**: `org.springframework.batch.core.job.parameters.RunIdIncrementer`

```java
@Bean
public Job jobTransaccionesDiarias(JobRepository jobRepository, Step stepTransaccionesDiarias) {
    return new JobBuilder("jobTransaccionesDiarias", jobRepository)
            .incrementer(new RunIdIncrementer())   // cada lanzamiento = JobInstance nueva
            .start(stepTransaccionesDiarias)
            .build();
}
```

**Advertencia 6.0** (cita literal de la guía de migración): *"When a job parameters incrementer is attached to a job definition, the parameters of the next instance will be calculated by the framework, and any additional parameters supplied by the user will be ignored with a warning."* Comportamiento distinto de 5.x.

**Incrementer personalizado para tu caso** (una instancia por día hábil, así el reinicio del mismo día sí retoma): ✅

```java
package cl.duoc.bancoxyz.batch.incrementer;

import java.time.LocalDate;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersIncrementer;
import org.springframework.lang.Nullable;

public class FechaProcesoIncrementer implements JobParametersIncrementer {

    @Override
    public JobParameters getNext(@Nullable JobParameters parameters) {
        JobParameters base = (parameters == null) ? new JobParameters() : parameters;
        return new JobParametersBuilder(base)
                // identificador -> define la JobInstance: una por fecha de proceso
                .addString("fechaProceso", LocalDate.now().toString(), true)
                // NO identificador -> puede cambiar entre reinicios sin crear instancia nueva
                .addString("rutaEntrada", "data/semana_3/transacciones.csv", false)
                .toJobParameters();
    }
}
```
El tercer argumento booleano de `addString/addLong/addDate` es **`identifying`**. Parámetros con `false` **no** forman parte de la identidad de la instancia — imprescindible para poder cambiar rutas o niveles de log entre reinicios sin romper el reinicio.

### 9.2 `preventRestart()` — a nivel de Job

```java
@Bean
public Job jobInteresesMensuales(JobRepository jobRepository, Step stepIntereses) {
    return new JobBuilder("jobInteresesMensuales", jobRepository)
            .preventRestart()          // restartable = false
            .start(stepIntereses)
            .build();
}
```
Intentar relanzar una instancia ya existente lanza **`JobRestartException`**.

> **Para el Job 2 (intereses) esto es una decisión de diseño defendible en el informe:** aplicar interés compuesto es **no idempotente**. Si el step falla a mitad y reinicias, las cuentas ya actualizadas **recibirían el interés dos veces**. Dos salidas válidas:
> - `preventRestart()` + reproceso manual controlado, o
> - hacer el step idempotente: `UPDATE cuenta SET saldo = ?, periodo_interes_aplicado = ? WHERE cuenta_id = ? AND periodo_interes_aplicado <> ?`.
>
> La segunda es la profesional; menciona ambas y justifica.

### 9.3 `allowStartIfComplete(boolean)` y `startLimit(int)` — a nivel de Step

```java
// Por defecto: un step COMPLETED se SALTA en el reinicio.
// allowStartIfComplete(true) lo fuerza a ejecutarse siempre.
new StepBuilder("stepValidacionPrevia", jobRepository)
        .<In, Out>chunk(100, txManager)
        .reader(...).writer(...)
        .allowStartIfComplete(true)     // p.ej. limpieza de tablas staging
        .startLimit(3)                  // default: Integer.MAX_VALUE
        .build();
```
Al superar `startLimit` se lanza **`StartLimitExceededException`** y el job termina; requiere intervención manual (subir el límite o crear una `JobInstance` nueva). El default `Integer.MAX_VALUE` está en `StepBuilderHelper.CommonStepProperties`.

### 9.4 Reinicio de un job PARTICIONADO — **¿solo las particiones fallidas?**

**Sí.** Y esto es verificable en el código de `SimpleStepExecutionSplitter` (el splitter por defecto que usa `PartitionStep`) — literal del fuente 5.2.x:

```java
@Override
public Set<StepExecution> split(StepExecution stepExecution, int gridSize) throws JobExecutionException {
    JobExecution jobExecution = stepExecution.getJobExecution();
    Map<String, ExecutionContext> contexts = getContexts(stepExecution, gridSize);
    Set<StepExecution> set = new HashSet<>(contexts.size());
    for (Entry<String, ExecutionContext> context : contexts.entrySet()) {
        // Make the step execution name unique and repeatable
        String stepName = this.stepName + STEP_NAME_SEPARATOR + context.getKey();   // ":"
        StepExecution currentStepExecution = jobExecution.createStepExecution(stepName);
        boolean startable = isStartable(currentStepExecution, context.getValue());
        if (startable) {
            set.add(currentStepExecution);        // <-- solo las arrancables entran
        }
    }
    jobRepository.addAll(set);
    ...
}
```

```java
protected boolean isStartable(StepExecution stepExecution, ExecutionContext context) throws JobExecutionException {
    ...
    boolean isRestart = (lastStepExecution != null && lastStepExecution.getStatus() != BatchStatus.COMPLETED);
    if (isRestart) {
        stepExecution.setExecutionContext(lastStepExecution.getExecutionContext());
    } else {
        stepExecution.setExecutionContext(context);
    }
    return shouldStart(allowStartIfComplete, stepExecution, lastStepExecution) || isRestart;
}
```
Y `shouldStart` devuelve `false` cuando `stepStatus == BatchStatus.COMPLETED && !allowStartIfComplete`.

**Comportamiento observable al reiniciar un step particionado:**

| Aspecto | Comportamiento |
|---|---|
| Particiones `COMPLETED` | **Se omiten** (no se recrean sus `StepExecution`) — salvo `allowStartIfComplete(true)` |
| Particiones `FAILED`/`STOPPED` | **Se re-ejecutan**, reutilizando su `ExecutionContext` guardado (un `JdbcPagingItemReader` retoma desde su última posición confirmada) |
| Nombre de partición | Determinista y repetible: `<stepName>:<claveDeParticion>` — esto es lo que permite emparejar la partición vieja con la nueva |
| `gridSize` | **Se conserva del `ExecutionContext`**, ignorando el que le pases al reiniciar: `int splitSize = (int) context.getLong(key, gridSize);` con `key = "SimpleStepExecutionSplitter.GRID_SIZE"`. Cambiar `gridSize` entre corridas **no** tiene efecto en un reinicio. |
| `Partitioner.partition()` | **Se vuelve a invocar** en el reinicio, salvo que tu `Partitioner` implemente `PartitionNameProvider`, en cuyo caso solo se piden los nombres. Lo dice el Javadoc de la propia interfaz: *"on a restart the `Partitioner.partition(int)` method will not be called again, instead the partitions will be re-used from the last execution, and matched by name… This can be a useful performance optimisation if the partitioning process is expensive."* (issue histórico relacionado: [spring-batch#2051](https://github.com/spring-projects/spring-batch/issues/2051)) |
| Estado `UNKNOWN` | `JobExecutionException: "Cannot restart step from UNKNOWN status. …"` — irrecuperable automáticamente |

**Partitioner con `PartitionNameProvider` para el Job 3 (cuentas 101..120):** ✅

```java
package cl.duoc.bancoxyz.batch.partition;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Collection;
import java.util.Map;

// 5.2.x: ...core.partition.support.*   |   6.0.x: ...core.partition.*
import org.springframework.batch.core.partition.support.PartitionNameProvider;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;

/**
 * Particiona por rango de cuenta_id (101..120 en cuentas_anuales.csv).
 * Implementa PartitionNameProvider para que en el REINICIO el framework
 * pida solo los nombres y NO vuelva a ejecutar la lógica de particionado.
 */
public class RangoCuentaPartitioner implements Partitioner, PartitionNameProvider {

    private final int minCuenta;
    private final int maxCuenta;

    public RangoCuentaPartitioner(int minCuenta, int maxCuenta) {
        this.minCuenta = minCuenta;
        this.maxCuenta = maxCuenta;
    }

    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {
        Map<String, ExecutionContext> particiones = new HashMap<>(gridSize);
        int total = maxCuenta - minCuenta + 1;
        int tamano = Math.max(1, (int) Math.ceil((double) total / gridSize));
        int desde = minCuenta;
        int i = 0;
        while (desde <= maxCuenta) {
            int hasta = Math.min(desde + tamano - 1, maxCuenta);
            ExecutionContext ctx = new ExecutionContext();
            ctx.putInt("cuentaDesde", desde);
            ctx.putInt("cuentaHasta", hasta);
            ctx.putString("nombreParticion", "particion" + i);
            particiones.put("particion" + i, ctx);
            desde = hasta + 1;
            i++;
        }
        return particiones;
    }

    @Override
    public Collection<String> getPartitionNames(int gridSize) {
        Collection<String> nombres = new LinkedHashSet<>();
        int total = maxCuenta - minCuenta + 1;
        int tamano = Math.max(1, (int) Math.ceil((double) total / gridSize));
        int n = (int) Math.ceil((double) total / tamano);
        for (int i = 0; i < n; i++) {
            nombres.add("particion" + i);
        }
        return nombres;
    }
}
```

**Advertencia sobre tolerancia a fallos + particiones:** si el step esclavo tiene `skipLimit(500)`, **ese límite se aplica por `StepExecution`, es decir, por partición**. Con 8 particiones, el job tolera hasta 8 × 500 = 4000 skips en total. Es un punto que conviene explicitar en el informe de la evaluación: el `skipLimit` no es global al job.

**Fuentes:** [Configuring a Step for Restart](https://docs.spring.io/spring-batch/reference/step/chunk-oriented-processing/restart.html) · [Configuring a Job](https://docs.spring.io/spring-batch/reference/job/configuring-job.html)

---

## 10. RESUMEN DE CONFIGURACIÓN RECOMENDADA POR JOB

| | **Job 1: Transacciones Diarias** | **Job 2: Intereses Mensuales** | **Job 3: Estados de Cuenta Anuales** |
|---|---|---|---|
| Origen | `transacciones.csv` (1000) | `intereses.csv` (1000, 9 dups) | `cuentas_anuales.csv` (1000, cuentas 101-120) |
| Escalado | multi-thread `taskExecutor` (reader thread-safe con `SynchronizedItemStreamReader`) | multi-thread (mide 1/2/4/8 hilos) | **particionado** por `cuenta_id` (20 cuentas → 4-8 particiones) |
| `chunk` | 100 | **50** (writes UPDATE, scan caro) | 200 (solo lectura+agregación) |
| Skip | `skipPolicy(BancoXyzSkipPolicy(500))` | `skipPolicy(...)` límite 600 | límite 400 |
| Retry | `CannotAcquireLockException`, `TransientDataAccessException` × 3, exponencial 200→5000 ms | **igual + `PessimisticLockingFailureException`** (UPDATE concurrente de saldo) | mínimo (sin escritura concurrente) |
| `noRollback` | `ValidationException`, `FlatFileParseException` | idem | idem |
| Restart | `RunIdIncrementer` | **`preventRestart()`** o UPDATE idempotente (§9.2) | reinicio por particiones fallidas |
| Dead letter | tabla + CSV | tabla + CSV | tabla + CSV |
| Riesgo principal | 371 tipos inválidos → subir `skipLimit` | interés aplicado 2× al reiniciar | scan de chunk si hay skip en write |

**Nota sobre los 9 duplicados 100% de `intereses.csv`:** no los trates con skip. Un `ItemProcessor` con un `Set<String>` de claves ya vistas devolviendo `null` (filtrado) es lo correcto — **pero es estado mutable**, así que con `taskExecutor` necesita un `ConcurrentHashMap.newKeySet()` o, mejor, una constraint `UNIQUE` en la tabla destino + `skip(DuplicateKeyException.class)`. Esta última opción es la que **mejor demuestra la tolerancia a fallos en la fase de write** para la rúbrica… pero recuerda que dispara chunk scanning (§7). Con solo 9 duplicados el coste es aceptable y da un caso real que explicar en el informe.

**Nota sobre multi-thread + skip:** con `taskExecutor`, los contadores (`getStepSkipCount()`) se agregan desde múltiples `StepContribution`. Tu `SkipPolicy` recibe un `skipCount` que puede ir ligeramente desfasado entre hilos. Es una carrera plausible, no un bug — pero **es una inferencia del diseño de `StepContribution`, no una verificación empírica** (ver §13).

---

## 11. EQUIVALENTE EN SPRING BATCH 6.0 (por si usas Spring Boot 4) ✅

```java
package cl.duoc.bancoxyz.batch.config;

import java.time.Duration;
import java.util.Set;

import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.skip.LimitCheckingExceptionHierarchySkipPolicy;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.infrastructure.item.file.FlatFileParseException;
import org.springframework.batch.infrastructure.item.validator.ValidationException;
import org.springframework.core.retry.RetryPolicy;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.transaction.PlatformTransactionManager;

import cl.duoc.bancoxyz.batch.model.Transaccion;
import cl.duoc.bancoxyz.batch.model.TransaccionRaw;

@org.springframework.context.annotation.Configuration
public class Step60Config {

    @org.springframework.context.annotation.Bean
    public Step stepTransacciones60(JobRepository jobRepository,
                                    PlatformTransactionManager transactionManager) {

        SkipPolicy skipPolicy = new LimitCheckingExceptionHierarchySkipPolicy(
                Set.of(FlatFileParseException.class, ValidationException.class), 500L);

        // Backoff exponencial + jitter, todo dentro del RetryPolicy (ya no hay backOffPolicy())
        RetryPolicy retryPolicy = RetryPolicy.builder()
                .maxRetries(3)                                   // 1 intento + 3 reintentos = 4
                .includes(CannotAcquireLockException.class)
                .excludes(ValidationException.class)
                .delay(Duration.ofMillis(200))
                .multiplier(2.0)
                .jitter(Duration.ofMillis(50))
                .maxDelay(Duration.ofSeconds(5))
                .build();

        return new StepBuilder("stepTransacciones60", jobRepository)
                .<TransaccionRaw, Transaccion>chunk(100)          // <-- sin txManager aquí
                .transactionManager(transactionManager)           // <-- método separado
                .reader(/* ... */ null)
                .processor(/* ... */ null)
                .writer(/* ... */ null)
                .faultTolerant()
                .skipPolicy(skipPolicy)     // ignora por completo skip()/skipLimit()
                .retryPolicy(retryPolicy)
                .skipListener(/* SkipListener */ null)
                .retryListener(/* org.springframework.core.retry.RetryListener */ null)
                // .noRollback(...) NO EXISTE en ChunkOrientedStepBuilder
                .build();
    }
}
```
> ✅ Verificado: compila contra `spring-batch-core:6.0.5` + Spring Framework 7.0.9. La transformación `chunk(5, transactionManager)` → `chunk(5).transactionManager(transactionManager)` es exactamente la que indica la guía de migración oficial.

Diferencias a tener presentes en 6.0:
- `maxRetries(3)` = **4 intentos** (1 inicial + 3), a diferencia de `retryLimit(3)` de 5.x que son 3 totales. (`RetryPolicy.Builder.DEFAULT_MAX_RETRIES = 3`, `DEFAULT_DELAY = 1000` ms.)
- Sin `skipPolicy()` explícito, `build()` construye `LimitCheckingExceptionHierarchySkipPolicy(skippableExceptions, skipLimit)` con `skipLimit` default **10** (la rama `NeverSkipItemSkipPolicy` del código es inalcanzable).
- Sin `retry()` ni `retryLimit()`, el retry policy es `throwable -> false` (nunca reintenta).
- `retryLimit(n)` sin `retry(X)` **no** falla: usa `Set.of(Exception.class)` por defecto (excluye `Error`). Contraste con 5.2.x, donde eso lanza `IllegalStateException` en `build()`.
- `.faultTolerant()` no cambia el tipo del builder: activa `chunkOrientedStep.setFaultTolerant(true)`.
- `skip(...)` y `retry(...)` son **varargs** (`@SafeVarargs`); `skipLimit`/`retryLimit` son `long` y exigen `> 0`.
- `listener(Object)` **ya no escanea** `@OnSkipInRead/@OnSkipInProcess/@OnSkipInWrite`.

---

## 12. URLS OFICIALES (todas verificadas: HTTP 200)

**Referencia (6.0.5, "current"):**
- Skip: https://docs.spring.io/spring-batch/reference/step/chunk-oriented-processing/configuring-skip.html
- Retry: https://docs.spring.io/spring-batch/reference/step/chunk-oriented-processing/retry-logic.html
- Restart de Step: https://docs.spring.io/spring-batch/reference/step/chunk-oriented-processing/restart.html
- Configuración de Job: https://docs.spring.io/spring-batch/reference/job/configuring-job.html

**Referencia (5.x, la que aplica a Spring Boot 3):**
- Controlling Rollback / `noRollback`: https://docs.spring.io/spring-batch/reference/5.1/step/chunk-oriented-processing/controlling-rollback.html
  ⚠️ **Esta página no existe en la versión current (404)** — es exclusiva de la rama 5.x.
- Retry 5.1: https://docs.spring.io/spring-batch/reference/5.1/step/chunk-oriented-processing/retry-logic.html

**Javadoc:**
- `FaultTolerantStepBuilder` **5.2.6**: https://docs.spring.io/spring-batch/docs/current/api/org/springframework/batch/core/step/builder/FaultTolerantStepBuilder.html
- `FaultTolerantStepBuilder` **6.0.5** (deprecado): https://docs.spring.io/spring-batch/reference/api/org/springframework/batch/core/step/builder/FaultTolerantStepBuilder.html
- `SkipPolicy`: https://docs.spring.io/spring-batch/docs/current/api/org/springframework/batch/core/step/skip/SkipPolicy.html
- `SkipListener`: https://docs.spring.io/spring-batch/docs/current/api/org/springframework/batch/core/SkipListener.html
- `FaultTolerantChunkProcessor`: https://docs.spring.io/spring-batch/docs/current/api/org/springframework/batch/core/step/item/FaultTolerantChunkProcessor.html
- spring-retry `ExponentialBackOffPolicy`: https://docs.spring.io/spring-retry/docs/api/current/org/springframework/retry/backoff/ExponentialBackOffPolicy.html
- Spring Framework 7 Resilience (`org.springframework.core.retry`): https://docs.spring.io/spring-framework/reference/core/resilience.html
- `DeadlockLoserDataAccessException` (deprecada): https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/dao/DeadlockLoserDataAccessException.html

**Código fuente (la fuente más confiable, usada para verificar todo este informe):**
- `FaultTolerantStepBuilder.java` (5.2.x): https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/FaultTolerantStepBuilder.java
- `ChunkOrientedStepBuilder.java` (6.0): https://github.com/spring-projects/spring-batch/blob/main/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/ChunkOrientedStepBuilder.java
- `ChunkOrientedStep.java` (scan mode): https://github.com/spring-projects/spring-batch/blob/main/spring-batch-core/src/main/java/org/springframework/batch/core/step/item/ChunkOrientedStep.java
- `SimpleStepExecutionSplitter.java` (restart de particiones): https://github.com/spring-projects/spring-batch/blob/main/spring-batch-core/src/main/java/org/springframework/batch/core/partition/support/SimpleStepExecutionSplitter.java
- `RetryPolicy.java` (Spring Framework 7): https://github.com/spring-projects/spring-framework/blob/main/spring-core/src/main/java/org/springframework/core/retry/RetryPolicy.java
- Guía de migración 6.0: https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide
- Issue de documentación de chunk scanning: https://github.com/spring-projects/spring-batch/issues/3946

**Complementarias (no oficiales, útiles como referencia didáctica):**
- Baeldung Skip Logic: https://www.baeldung.com/spring-batch-skip-logic
- Baeldung Retry Logic: https://www.baeldung.com/spring-batch-retry-logic

---

## 13. PUNTOS INCIERTOS — MARCADOS EXPLÍCITAMENTE

*(De los 7 puntos de la versión anterior, 3 quedaron resueltos por esta revisión y se mueven a "verificado".)*

**Siguen inciertos:**

1. **`noRollback` en Spring Batch 6.0.** `ChunkOrientedStepBuilder` no expone `noRollback()` y la página *Controlling Rollback* de la referencia devuelve 404 en la versión current. Del código de `ChunkOrientedStep.processItem()` (que llama a `doSkipInProcess` y no relanza cuando el skip procede) se deduce que el skip en process es *inline* por defecto. **No hay confirmación explícita en la guía de migración.** Verifica con un test si vas a 6.0.

2. **Rollback en skips de fase READ.** La documentación de Controlling Rollback afirma que el step bufferiza la entrada del reader para no re-leer tras un rollback, pero el Javadoc de `SkipListener.onSkipInRead` advierte que *"in case a transaction is rolled back and items are re-read, this callback occurs repeatedly for the same cause. This happens only if read items are not buffered."* Los dos enunciados conviven porque el rollback puede venir de la fase de write posterior y el buffering se desactiva con `readerIsTransactionalQueue()`. **No verifiqué el comportamiento exacto en 5.2.x con `readerIsTransactionalQueue()` activado.**

3. **`skipCount` por tipo con `ExceptionClassifierSkipPolicy`.** Cada sub-política recibe el `skipCount` **global del step**, no uno por tipo de excepción (verificado en el código de `ExceptionClassifierSkipPolicy`, que solo delega, y en las llamadas de `FaultTolerantChunkProcessor`/`ChunkOrientedStep`, que pasan `contribution.getStepSkipCount()`). **No existe mecanismo oficial de conteo por tipo.** Si el enunciado exige límites independientes por tipo, hay que implementar estado propio con las precauciones de §2.3, y documentar la limitación.

4. **Número exacto de re-invocaciones de `shouldSkip` por ítem.** Ocurre más de una vez (retryCallback, recoveryCallback, sonda con `-1`, scan), pero **no conté el número exacto en cada ruta** de `FaultTolerantChunkProcessor` 5.2.x. Para el informe basta con la conclusión operativa: *no lleves contadores mutables dentro de un `SkipPolicy`*.

5. **Métricas de skip en steps multi-thread.** El desfase de `getStepSkipCount()` entre hilos descrito en §10 es una inferencia razonable de cómo `StepContribution` se agrega en `TaskletStep`, **no una verificación empírica**. Si tu informe incluye la comparación multi-thread que pide el enunciado, mídelo: es un dato original y valioso.

**Resueltos en esta revisión (ya no inciertos):**

- ✅ **`CompositeRetryPolicy` con `setOptimistic`.** El default es `optimistic = false` ⇒ **pesimista (AND, todas deben permitir)**. Verificado en el fuente de spring-retry.
- ✅ **Números exactos de versión.** `docs/current/api` = **Spring Batch 5.2.6**; `reference/api` = **6.0.5**, que es además el **GA actual**. Boot 3.5 → Batch 5.2; Boot 4.0 → Batch 6.0 (y Spring Framework 7, Spring Data 4, Micrometer 1.16). Confirma igualmente con `mvn dependency:tree`.
- ✅ **Comportamiento de `skipPolicy()` + `skip()`/`skipLimit()` en 5.2.x.** Reproducido ejecutando el builder: composición `CompositeSkipPolicy` con OR de cortocircuito; el `skipLimit` sí se aplica cuando la política custom veta y la excepción está en `skip()`.

---

## 14. CHECKLIST DE ERRORES A EVITAR (resumen ejecutable)

| # | Error | Síntoma | Corrección |
|---|---|---|---|
| 1 | `skipLimit` por defecto (10) con dataset 40% sucio | Step `FAILED` en la fila ~11 | `skipLimit(500)` o filtrar con `null` en el processor |
| 2 | `int skipCount` en un `SkipPolicy` copiado de 4.x | La política nunca se invoca | Firma `long skipCount` |
| 3 | Ignorar la sonda `skipCount < 0` | Se rompe el chunk scanning | `if (skipCount < 0) return omitible;` |
| 4 | Contadores `AtomicLong` dentro del `SkipPolicy` | Conteos inflados | Usar el `skipCount` del framework |
| 5 | Mezclar `skipPolicy()` con `skip()`/`skipLimit()` en 5.2.x | Tu veto se anula (OR) | Elegir Modelo A o Modelo B (§2.4) |
| 6 | `noRollback(X)` sin `skip(X)` | `NonSkippableProcessException`, step falla | Declarar ambos |
| 7 | `retry(ValidationException.class)` | Minutos de espera inútil | Reintentar solo infraestructura |
| 8 | Confiar en `noRetry()` con `retryPolicy()` propio y sin `retryLimit` | La exclusión se ignora en silencio | Excluir dentro de la propia política (§3.1) |
| 9 | `.listener(bean)` sin cast con bean multi-interfaz | **No compila** (`reference to listener is ambiguous`) | Castear, o usar `.listener((StepExecutionListener) bean)` |
| 10 | `@BeforeStep` + registro como `SkipListener` | La anotación nunca se ejecuta | Implementar `StepExecutionListener` (§8.3) |
| 11 | `DeadlockLoserDataAccessException` | Warning de deprecación | `CannotAcquireLockException` / `PessimisticLockingFailureException` |
| 12 | Validar en el writer (constraints) | Chunk scanning: 101 writes en vez de 1 | Validar en el `ItemProcessor` |
| 13 | Setters de backoff encadenados | No compila (`void`) | Configurar en un `@Bean`, línea a línea |
| 14 | Copiar imports de 5.2.x a un proyecto 6.0 | `package does not exist` | Ver tabla de §0 |

---

**Fuentes principales:** [Spring Batch Reference (6.0)](https://docs.spring.io/spring-batch/reference/index.html) · [Spring Batch 6.0 Migration Guide](https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide) · [spring-projects/spring-batch (código fuente)](https://github.com/spring-projects/spring-batch) · [spring-projects/spring-retry](https://github.com/spring-projects/spring-retry) · [Spring Framework Resilience](https://docs.spring.io/spring-framework/reference/core/resilience.html) · [Spring Batch 6.0.0 GA](https://spring.io/blog/2025/11/19/spring-batch-6-0-0-ga/) · [Baeldung Skip Logic](https://www.baeldung.com/spring-batch-skip-logic) · [Baeldung Retry Logic](https://www.baeldung.com/spring-batch-retry-logic)