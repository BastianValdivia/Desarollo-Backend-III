I have verified every API claim against Spring Batch 5.2.x sources, the official reference docs, and the Micrometer/Boot sources. Here is the deliverable.

---

# PARTE 1 — ERRORES ENCONTRADOS

**No, el informe no está limpio.** Encontré **17 problemas**, de los cuales **4 son críticos** (código que no funciona en tiempo de ejecución, o una contradicción interna que invalida toda la §2). También **resolví 2 de los 7 puntos que el informe marcaba como "inciertos"** — ambos estaban equivocados en la dirección conservadora.

Contexto de versión verificado: **Spring Boot 3.5.x → Spring Batch 5.2.6** (confirmado en `spring-boot-dependencies/build.gradle`: `library("Spring Batch", "5.2.6")`). La premisa de versión del informe es correcta.

---

## E1 — CRÍTICO: los nombres de los tags de métricas son incorrectos. El código de §2.2 y §2.3 no encuentra nada.

**Qué dice el informe (§2):** tabla con tags `name`, `status`, `job.name`, `step.name`.

**Qué pasa realmente:** el informe copió fielmente la tabla de la doc oficial 5.2 — pero **esa tabla está desactualizada desde Spring Batch 5.0**. Los nombres reales de los tags están *totalmente cualificados* con el prefijo de la métrica. Verificado en el código fuente:

| Métrica | Tags REALES en 5.2.6 | Fuente en el código |
|---|---|---|
| `spring.batch.job` | `spring.batch.job.name`, `spring.batch.job.status` | `BatchJobObservation.JobLowCardinalityTags` + `DefaultBatchJobObservationConvention` |
| `spring.batch.job.active` | `spring.batch.job.active.name` | `AbstractJob.java:284-286` |
| `spring.batch.step` | `spring.batch.step.name`, `spring.batch.step.job.name`, `spring.batch.step.status` | `DefaultBatchStepObservationConvention` |
| `spring.batch.step.active` | `spring.batch.step.name`, `spring.batch.step.job.name`, `spring.batch.step.status` | Micrometer `DefaultMeterObservationHandler:75` |
| `spring.batch.item.read` | `spring.batch.item.read.job.name`, `spring.batch.item.read.step.name`, `spring.batch.item.read.status` | `SimpleChunkProvider.java:156-163` |
| `spring.batch.item.process` | `spring.batch.item.process.job.name`, `.step.name`, `.status` | `SimpleChunkProcessor.java:349-357` |
| `spring.batch.chunk.write` | `spring.batch.chunk.write.job.name`, `.step.name`, `.status` | `SimpleChunkProcessor.java:349-357` |

**Consecuencia exacta:** en §2.3, `registry.find("spring.batch.chunk.write").tag("job.name", jobName).timer()` devuelve **siempre `null`** → `avgChunkWriteMs()` devuelve `NaN` y `chunkWriteCount()` devuelve `0` en todas las filas del CSV. El experimento parece funcionar y produce columnas vacías.

**Corrección exacta:**
```java
Timer t = registry.find("spring.batch.chunk.write")
                  .tag("spring.batch.chunk.write.job.name", jobName)
                  .timer();
```
```bash
curl "http://localhost:8080/actuator/metrics/spring.batch.job?tag=spring.batch.job.name:interesesJob"
curl "http://localhost:8080/actuator/metrics/spring.batch.chunk.write?tag=spring.batch.chunk.write.job.name:interesesJob&tag=spring.batch.chunk.write.status:SUCCESS"
```

**URLs:**
- Código: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/item/SimpleChunkProvider.java#L156-L163
- Código: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/observability/BatchJobObservation.java
- Issue que confirma la discrepancia: https://github.com/spring-projects/spring-batch/issues/4753
- (La tabla desactualizada: https://docs.spring.io/spring-batch/reference/5.2/monitoring-and-metrics.html)

---

## E2 — CRÍTICO: "Batch 5.x: no requiere configuración" es falso como está enunciado.

**Qué dice el informe (§2.1):** *"Batch 5.x: no requiere configuración; solo necesitas un `MeterRegistry` en el contexto para poder leerlas."*

**Qué pasa realmente:** `AbstractJob` y `AbstractStep` inicializan `private ObservationRegistry observationRegistry = ObservationRegistry.NOOP;`. Sin un bean `ObservationRegistry`, **`spring.batch.job` y `spring.batch.step` no se registran en absoluto**. Quien lo inyecta es `BatchObservabilityBeanPostProcessor`, que hace `beanFactory.getBean(ObservationRegistry.class)` y, si no lo encuentra, loguea `"No Micrometer observation registry found, defaulting to ObservationRegistry.NOOP"`.

Funciona en Spring Boot únicamente porque **Actuator autoconfigura el bean `ObservationRegistry`** (`ObservationAutoConfiguration`), no porque baste el `MeterRegistry`. Distinción importante: las métricas `item.*`/`chunk.write`/`job.launch.count` **sí** funcionan sin `ObservationRegistry`, porque usan `MeterRegistry` con default `Metrics.globalRegistry`.

**Corrección:** "Batch 5.x + Spring Boot Actuator: funciona sin configuración adicional **porque Actuator aporta el bean `ObservationRegistry`**. Sin ese bean, las métricas de job y step son silenciosamente NOOP; las de ítem/chunk siguen funcionando."

**URLs:**
- https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/configuration/annotation/BatchObservabilityBeanPostProcessor.java
- https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/job/AbstractJob.java#L92

---

## E3 — CRÍTICO: contradicción interna. La *factory* imperativa de §5.1 apaga las métricas de §2.

Este es el error más grave del informe, y es **suyo**, no de la documentación.

`BatchObservabilityBeanPostProcessor` es un **`BeanPostProcessor`**: solo actúa sobre `AbstractJob`/`AbstractStep` que sean **beans de Spring**. La decisión de diseño de §5.1 —*"construir los `Job`/`Step` con una factory imperativa, no con beans"*— hace que el post-procesador **nunca se ejecute**. Resultado: `ObservationRegistry.NOOP` → **no existen `spring.batch.job`, `spring.batch.step`, `spring.batch.job.active` ni `spring.batch.step.active`** para ninguna celda del experimento.

**Corrección exacta** (los builders sí exponen el hook, `@since 5.0`):
```java
@Component
public class ExperimentJobFactory {
    private final ObservationRegistry observationRegistry;   // inyectado
    private final MeterRegistry meterRegistry;

    private Job sequentialJob(ExperimentCase c) {
        Step step = new StepBuilder("step-" + c.label(), jobRepository)
                .observationRegistry(observationRegistry)   // <-- OBLIGATORIO sin beans
                .meterRegistry(meterRegistry)
                .<TransaccionRaw, TransaccionEntity>chunk(c.chunkSize(), txManager)
                /* ... */
                .build();

        return new JobBuilder(c.jobName(), jobRepository)
                .observationRegistry(observationRegistry)   // <-- OBLIGATORIO sin beans
                .meterRegistry(meterRegistry)
                .listener(new JobTimingListener())
                .start(step)
                .build();
    }
}
```
Ojo: en un `PartitionStep` hay que aplicarlo **tanto al manager como al worker**.

**URLs:**
- `JobBuilderHelper.observationRegistry(...)` / `.meterRegistry(...)`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/job/builder/JobBuilderHelper.java#L142-L160
- `StepBuilderHelper.observationRegistry(...)`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/builder/StepBuilderHelper.java#L111-L119

---

## E4 — INCERTIDUMBRE #2 RESUELTA (y estaba equivocada): `spring.batch.job.launch.count` **SÍ existe en 5.2.x**.

**Qué dice el informe:** *"⚠ INCIERTO: la documentación de 6.0 lista además un `spring.batch.job.launch.count`. No aparece en la tabla de 5.2 que consulté. Si programas contra 5.2, no cuentes con él."*

**Realidad:** existe desde 5.0, en `TaskExecutorJobLauncher.afterPropertiesSet()`:
```java
this.jobLaunchCount = BatchMetrics.createCounter(this.meterRegistry, "job.launch.count", "Job launch count");
```
Es un `COUNTER`, **sin tags**, registrado en `Metrics.globalRegistry` por defecto. Solo falta en la *tabla* de la doc 5.2. Como Boot usa `TaskExecutorJobLauncher` por defecto, estará disponible.

**Corrección:** eliminar la advertencia y añadir la fila a la tabla, con la nota de que no tiene tags (no permite discriminar por job).

**URL:** https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/launch/support/TaskExecutorJobLauncher.java#L233

---

## E5 — INCERTIDUMBRE #1 RESUELTA (el informe acertó, pero puede afirmarlo): `getEndTime()` **sí** está disponible en `afterJob`.

Bloque `finally` de `AbstractJob.execute()` en 5.2.x, verbatim:
```java
stopObservation(execution, observation);
longTaskTimerSample.stop();
execution.setEndTime(LocalDateTime.now());

try {
    listener.afterJob(execution);
} catch (Exception e) { ... }

jobRepository.update(execution);
```
Confirmado: `setEndTime` precede a `afterJob`. **Bonus no señalado por el informe:** `stopObservation()` y `longTaskTimerSample.stop()` ocurren **antes** de `setEndTime`, luego el timer `spring.batch.job` **excluye** el `afterJob` y el `jobRepository.update()` final. Es decir, `spring.batch.job` < `Duration.between(start,end)` < reloj B. Eso es un dato bueno para el informe, no una molestia.

**URL:** https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/job/AbstractJob.java#L340-L365

---

## E6 — `JobLauncherApplicationRunner` **NO está deprecado** en Boot 3.5.

**Qué dice el informe (§10):** *"`JobLauncherApplicationRunner` (**deprecado**, sujeto a eliminación)"*.

**Realidad:** la clase no está deprecada. Solo su método `validate()` lo está: `@Deprecated(since="3.0.10", forRemoval=true)`.

**Corrección:** quitar la etiqueta "deprecado" de la clase; si se quiere mencionar algo, es que el método `validate()` está deprecado desde 3.0.10.

**URL:** https://docs.spring.io/spring-boot/3.5/api/java/org/springframework/boot/autoconfigure/batch/JobLauncherApplicationRunner.html

---

## E7 — URL rota (404) en §10.

`https://docs.spring.io/spring-boot/api/java/org/springframework/boot/autoconfigure/batch/BatchAutoConfiguration.html` → **404**. La ruta sin versión ahora apunta a Boot 4, donde la clase se movió de módulo.

**Corrección:** usar la URL fijada a 3.5 (verificada 200):
`https://docs.spring.io/spring-boot/3.5/api/java/org/springframework/boot/autoconfigure/batch/BatchAutoConfiguration.html`

---

## E8 — `SimpleAsyncTaskExecutor`: `concurrencyLimit` **no** hace que reutilice hilos.

**Qué dice el informe (§3.5):** *"crea un hilo nuevo por tarea y no los reutiliza (salvo que le pongas `concurrencyLimit`)"*.

**Realidad**, javadoc verbatim: *"**NOTE: This implementation does not reuse threads!**"* — sin excepciones. `setConcurrencyLimit` **acota la concurrencia** con un semáforo (`ConcurrencyThrottleSupport`), pero sigue creando un hilo por tarea.

**Corrección:** *"no reutiliza hilos **nunca**; `concurrencyLimit` acota cuántos corren a la vez, pero cada tarea sigue costando la creación de un hilo. El argumento contra usarlo en el experimento es doble: eje X ficticio **y** coste de creación de hilos contaminando la medición."* (El argumento del informe queda **más fuerte** tras la corrección.)

**URL:** https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/core/task/SimpleAsyncTaskExecutor.html

---

## E9 — Sobre-cita del javadoc de `System.nanoTime()`: no garantiza monotonicidad.

**Qué dice el informe (§1.2):** *"`nanoTime` es **monotónico** y no se ve afectado por ajustes de reloj (NTP, cambio de hora). `currentTimeMillis` puede retroceder. Ver javadoc"*.

**Realidad:** el javadoc **no** usa la palabra monotónico ni garantiza monotonicidad. Lo que sí dice, verbatim: *"This method can only be used to measure elapsed time and **is not related to any other notion of system or wall-clock time**."* Y el javadoc de `currentTimeMillis()` no dice que pueda retroceder.

**Corrección (formulación defendible):** *"El javadoc establece que `nanoTime()` mide tiempo transcurrido y **no está relacionado con ninguna noción de reloj de sistema o de pared**; por tanto los ajustes de reloj (NTP, horario de verano) no lo afectan, a diferencia de `currentTimeMillis()`, que sí refleja el reloj del sistema. El javadoc no promete monotonicidad estricta, aunque las implementaciones reales la proveen."*

**URL:** https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/System.html#nanoTime()

---

## E10 — El tag `status` de `spring.batch.step` no incluye `spring.batch.step.type`, aunque esté declarado.

`BatchStepObservation.StepLowCardinalityTags` declara `STEP_TYPE` (`spring.batch.step.type`), pero `DefaultBatchStepObservationConvention.getLowCardinalityKeyValues()` **solo emite** `STEP_NAME`, `JOB_NAME` y `STEP_STATUS`. Si el alumno busca `spring.batch.step.type` en `/actuator/metrics`, no estará.

**URL:** https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/observability/DefaultBatchStepObservationConvention.java

---

## E11 — `spring.batch.job.active` se registra DOS veces con tags incompatibles (bug real, aprovechable).

Dato que el informe no tiene y que vale puntos: `spring.batch.job.active` se crea en **dos sitios** con juegos de tags distintos:
1. `AbstractJob.java:284` → tag `spring.batch.job.active.name`
2. Micrometer `DefaultMeterObservationHandler:75` (`context.getName() + ".active"`) → tags `spring.batch.job.name`, `spring.batch.job.status=UNKNOWN`

Con Prometheus esto emite el WARN: *"requires that all meters with the same name have the same set of tag keys. There is already an existing meter named 'spring.batch.job.active' containing tag keys [spring.batch.job.active.name]. The meter you are attempting to register has keys [spring.batch.job.name, spring.batch.job.status]."*

Corregido en **6.0.0-M4**; presente en toda la línea 5.2.x. Además explica el origen de `spring.batch.step.active`: **no lo crea `AbstractStep`** (verificado: no hay ningún `LongTaskTimer` en esa clase), lo crea el `DefaultMeterObservationHandler` a partir de la observación.

**URL:** https://github.com/spring-projects/spring-batch/issues/4753

---

## E12 — §1.3: la granularidad de milisegundos no es de la API, es de la BD.

`JobExecution.getStartTime()` devuelve `LocalDateTime` alimentado por `LocalDateTime.now()`, con resolución de micro/nanosegundos en memoria. La pérdida a milisegundos ocurre **al persistir** en la columna `TIMESTAMP` de `BATCH_JOB_EXECUTION`. El informe atribuye la limitación al reloj C en general.

**Corrección:** *"granularidad limitada por la columna `TIMESTAMP` de la BD al releerlo por SQL; en memoria, dentro de `afterJob`, la resolución es la de `LocalDateTime.now()`."*

---

## E13 — §3.4: "`SynchronizedItemStreamReader` rompe la restartabilidad" — afirmación sin respaldo, mal atribuida.

La doc de *Scalability* **no** dice eso, ni recomienda `saveState=false` en esa sección. Lo que sí es citable:
- `AbstractItemCountingItemStreamItemReader` (superclase de `FlatFileItemReader`), javadoc verbatim: *"Subclasses are inherently **not** thread-safe."*
- Reference 5.2: *"It is, however, possible to work with stateless or thread safe readers and writers"*, y remite al patrón *process indicator*.

**Corrección (enunciado correcto y defendible):** *"El problema de restart no lo causa el decorador: lo causa el step multihilo. `FlatFileItemReader` guarda `read.count` en el `ExecutionContext` para reanudar, pero con N hilos ese contador ya no corresponde a un prefijo contiguo de ítems procesados (el ítem 900 puede estar hecho y el 850 no). Reanudar desde el contador guardado puede saltarse o reprocesar filas. La salida documentada es usar readers stateless/thread-safe o el patrón *process indicator*; la alternativa pragmática es `reader.setSaveState(false)`, que renuncia explícitamente al restart a mitad de step. **La partición no tiene este problema:** cada partición tiene su propio `StepExecution` y su propio `ExecutionContext`."*

**URLs:**
- https://docs.spring.io/spring-batch/reference/5.2/scalability.html
- https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-infrastructure/src/main/java/org/springframework/batch/item/support/AbstractItemCountingItemStreamItemReader.java#L26-L31

---

## E14 — Error aritmético interno: la base del speedup se contradice a sí misma.

El informe advierte correctamente en §6.1 *"el de 'Partición 4' (2,26×) debe usar como base **el mejor secuencial**, no el peor"* — y acto seguido **incumple su propia regla**:

- Mejor secuencial de la tabla = **8.870 ms** (chunk=500), no 9.310.
- 9.310 / 4.120 = **2,26×** ← lo que está escrito
- 8.870 / 4.120 = **2,15×** ← lo que debería estar si la base es "el mejor secuencial"

Igual con multi-thread: 1,49× = 9.310/6.240 (base chunk=100), no 8.870/6.240 = 1,42×.

Y **§6.3(a) propaga el error**: *"2,26× sobre el mejor secuencial"* es falso incluso dentro de la tabla ilustrativa.

**Además, arrastra a §6.3(c):** con S(4)=2,15 en vez de 2,26, `p = 4(1,15)/(2,15·3) = 0,713` (no 0,74) y el techo `S(∞) = 1/0,287 ≈ 3,5×` (no 3,8×).

**Corrección:** declarar **una sola base** y usarla en todas partes. Recomiendo *"speedup contra el mejor secuencial (chunk=500, 8.870 ms)"*, y recalcular la columna entera. (Verifiqué el resto de la aritmética de la tabla: throughputs, commits, 4,7 %, 1,7 %, 44 % y las dos aplicaciones de Amdahl de §4.1 están **todas correctas**.)

---

## E15 — §3.6: la definición de *skew* y las cifras reportadas no son la misma métrica.

El informe define **skew = max/avg**, y luego reporta *"desbalance de hasta 2,75×"* (intereses) y *"~1,5×"* (cuentas anuales), que son **max/min** (33/12 y 60/39).

Con los datos reales de `docs/analisis-datos.md` (1.000 filas / 50 cuentas y 1.000 / 20 cuentas), si se particiona **una cuenta por partición**:
- `intereses.csv`: avg = 20 filas → **skew = 33/20 = 1,65** (max/min = 2,75)
- `cuentas_anuales.csv`: avg = 50 filas → **skew = 60/50 = 1,20** (max/min = 1,54)

**Corrección:** reportar ambas y nombrarlas: `skew = max/avg` (impacto real en el tiempo del manager) y `ratio max/min` (dispersión). No mezclarlas.

---

## E16 — §3.5: `throttleLimit` está en `AbstractTaskletStepBuilder`, y ya tiene fecha de eliminación.

Menor pero citable con precisión. Javadoc 5.2.x verbatim: *"@deprecated with no replacement since 5.0, **scheduled for removal in 6.0**. Use a custom `RepeatOperations` implementation ... `#stepOperations(RepeatOperations)`"*. Y la guía de migración confirma que **en 6.0 ya está eliminado** (`AbstractTaskletStepBuilder#throttleLimit` y `TaskExecutorRepeatTemplate#setThrottleLimit` figuran en la lista de *removed*). El método no está en `StepBuilder` sino en `AbstractTaskletStepBuilder` (heredado por `SimpleStepBuilder`/`TaskletStepBuilder`).

---

## E17 — Nota sobre las URLs de javadoc `docs/current/api` (no es error, pero es frágil).

Verifiqué: `https://docs.spring.io/spring-batch/docs/current/api/...` devuelve **200** y sirve el javadoc de **5.2.6** (no 6.0 — el esquema `docs/{version}/api` quedó congelado en la línea 5.2). Por eso `.../core/JobExecution.html` funciona y `.../core/job/JobExecution.html` da 404. Las URLs del informe funcionan hoy, pero **conviene fijarlas a `docs/5.2.x/api/`** para que no se rompan cuando Spring migre ese alias.

---

## ✅ Lo que verifiqué y está CORRECTO (no tocar)

Para que no se corrija de más:

- **Toda la tabla de relocalización de paquetes 5.2 → 6.0 de §0**: exacta, incluida `...partition.support` → `...core.partition`. ✓
- **`JobOperator` reemplaza a `JobLauncher` en 6.0**: la guía dice *"`JobOperator` now extends `JobLauncher` and there is no need for a `JobLauncher` bean anymore, which is now deprecated"*. ✓
- **6.0 requiere bean `ObservationRegistry`**: *"The usage of Micrometer's global static meter registry was removed. It is now required to configure an `ObservationRegistry` as a bean"*. El snippet de §2.1 coincide con el ejemplo oficial. ✓
- **`JobExecution.getStartTime()/getEndTime()` → `LocalDateTime` en 5.x.** ✓
- **`BatchMetrics` en `org.springframework.batch.core.observability`, `calculateDuration(LocalDateTime,LocalDateTime)` → `Duration`, `formatDuration(...)`, javadoc `"Only intended for internal use."`** ✓ — la advertencia del informe es correcta y literal.
- **Todos los getters de `StepExecution` devuelven `long` en 5.x** (`getReadCount`, `getWriteCount`, `getFilterCount`, `getCommitCount`, `getRollbackCount`, `getSkipCount`, `getReadSkipCount`, `getProcessSkipCount`, `getWriteSkipCount`) → el `record ExperimentResult` con campos `long` **compila**. ✓
- **`SynchronizedItemStreamReader` usa `private final Lock lock = new ReentrantLock();`** y `setDelegate(ItemStreamReader<T>)`. ✓
- **La cita de scalability es verbatim**: *"In particular, most of the readers and writers from Spring Batch are not designed for multi-threaded use."* ✓
- **Toda la cadena de builders de §5.4 compila**: `StepBuilder.chunk(int, PlatformTransactionManager)` → `SimpleStepBuilder`; `.taskExecutor()` (de `AbstractTaskletStepBuilder`) → `SimpleStepBuilder`; `.faultTolerant()` → `FaultTolerantStepBuilder`; `.skipPolicy(SkipPolicy)`, `.retryPolicy(RetryPolicy)`, `.listener(Object)` existen; `StepBuilder.partitioner(String, Partitioner)` → `PartitionStepBuilder` con `.step(Step)`, `.gridSize(int)`, `.taskExecutor(TaskExecutor)`, `.build()`. ✓
- **`JobBuilderHelper.listener(JobExecutionListener)` e `.incrementer(JobParametersIncrementer)` existen.** ✓
- **`Partitioner`: `Map<String, ExecutionContext> partition(int gridSize)`.** ✓
- **`ItemWriter` es `@FunctionalInterface` con `void write(Chunk<? extends T>)`** → el lambda `chunk -> { }` compila. ✓
- **Micrometer**: `MeterRegistry.remove(Meter)` existe; `getMeters()` devuelve `Collections.unmodifiableList(Arrays.asList(...))` sobre un **snapshot**, así que `clearBatchMeters()` **no lanza `ConcurrentModificationException`**; `Timer.mean(TimeUnit)`, `MeterFilter.deny(Predicate<Meter.Id>)` y `MeterFilter.denyNameStartsWith(String)` existen. ✓
- **Boot añade sus registries a `Metrics.globalRegistry` por defecto** (`management.metrics.use-global-registry=true`), por eso las métricas de ítem/chunk (que van a `Metrics.globalRegistry`) sí aparecen en `/actuator/metrics`. ✓
- **`SimpleMeterRegistry` como fallback en memoria**: *"Micrometer ships with a simple, in-memory backend that is automatically used as a fallback if no other registry is configured."* ✓
- **`System.gc()` es una sugerencia**: javadoc *"suggests that the JVM expend effort... There is no guarantee..."* ✓
- **Columnas de `BATCH_JOB_EXECUTION_PARAMS` en 5.x** = `PARAMETER_NAME`/`PARAMETER_TYPE`/`PARAMETER_VALUE` (en 4.x `KEY_NAME`/`STRING_VAL`/`LONG_VAL`). ✓ (incertidumbre #3 del informe: confirmada como correcta)
- **`HikariCP` default `maximumPoolSize=10`.** ✓
- **Toda la aritmética de Amdahl** (§4.1 y la fórmula despejada `p = n(S−1)/(S(n−1))`), los throughputs, los commitCounts y los porcentajes de §6.3(e) y (f). ✓
- **El perfil de datos citado** coincide con `/home/user/backend-3-bastian/docs/analisis-datos.md`: transacciones `id` 1..1000 contiguo; intereses `cuenta_id` 101..150 (50 cuentas, 12–33 filas); cuentas anuales 101..120 (20 cuentas, 39–60 filas); 168 montos vacíos; 230 descripciones vacías. ✓

---
---

# PARTE 2 — INFORME CORREGIDO Y CONSOLIDADO

# Diseño experimental de escalado en Spring Batch — Banco XYZ (Exp1 S3)

Contexto del repo: `/home/user/backend-3-bastian/docs/enunciado/RESUMEN.md` (rúbrica) y `/home/user/backend-3-bastian/docs/analisis-datos.md` (perfil real de los 3 CSV). El criterio 4 (15 pts) exige literalmente *"comparando diferentes parámetros para encontrar la configuración óptima"*.

> **Estado de verificación:** todas las afirmaciones de API de este documento fueron contrastadas contra el código fuente de **Spring Batch 5.2.6** y la documentación oficial. Donde la documentación oficial y el código discrepan, se indica explícitamente y **manda el código**.

---

## 0. Advertencia de versión (leer primero)

El diseño asume **Spring Boot 3.5.x + Spring Batch 5.2.6** (Boot 3.5.x declara `library("Spring Batch", "5.2.6")` en su BOM). Con **Boot 4.x / Batch 6.0** cambia lo siguiente y rompe compilación:

| Aspecto | Batch 5.2 | Batch 6.0 |
|---|---|---|
| `Job`, `JobExecution`, `JobInstance` | `org.springframework.batch.core` | `org.springframework.batch.core.job` |
| `Step`, `StepExecution`, `StepContribution` | `org.springframework.batch.core` | `org.springframework.batch.core.step` |
| `JobParameters`, `JobParametersBuilder`, `JobParametersIncrementer`, `JobParameter` | `org.springframework.batch.core` | `org.springframework.batch.core.job.parameters` |
| `JobExecutionListener`, `SkipListener`, `ChunkListener`, `ItemReadListener`, `StepExecutionListener` | `org.springframework.batch.core` | `org.springframework.batch.core.listener` |
| `Partitioner`, `PartitionStep`, `StepExecutionAggregator` | `...core.partition.support` | `org.springframework.batch.core.partition` |
| Métricas Micrometer | requieren bean `ObservationRegistry` (lo aporta Actuator) | *"the usage of Micrometer's global static meter registry was removed"* → bean obligatorio |
| Lanzador | `JobLauncher` | *"`JobOperator` now extends `JobLauncher` and there is no need for a `JobLauncher` bean anymore, which is now deprecated"* |
| `throttleLimit` | deprecado desde 5.0 | **eliminado** |

Fuente: [Spring Batch 6.0 Migration Guide](https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide).

**Recomendación:** quedarse en **Boot 3.5.x / Batch 5.2.6**.

---

## 1. Cómo medir correctamente el tiempo de un Job

Hay **cuatro relojes distintos**. Medir el equivocado es el error más común.

### 1.1 Reloj A — wall-clock del proceso (`time java -jar`)
Incluye arranque de JVM + contexto Spring (2–6 s) + el job (0,3 s). **Inútil para comparar configuraciones**: el ruido del arranque es 10× la señal. Repórtalo una vez, para contexto, y no lo uses como métrica.

### 1.2 Reloj B — cronómetro del runner (MÉTRICA PRIMARIA)

```java
long t0 = System.nanoTime();
JobExecution exec = jobLauncher.run(job, params);
long elapsedNanos = System.nanoTime() - t0;
```

**Por qué `nanoTime()` y no `currentTimeMillis()`** — con la formulación que el javadoc realmente respalda:

> *"This method can only be used to measure elapsed time and **is not related to any other notion of system or wall-clock time**."*

Es decir: `nanoTime()` no está atado al reloj del sistema, así que los ajustes de reloj (NTP, horario de verano) no lo afectan; `currentTimeMillis()` sí refleja el reloj del sistema. **El javadoc no promete monotonicidad estricta** (aunque las implementaciones reales la proveen), así que no lo afirmes como garantía documental. Fuente: [javadoc de `System.nanoTime()` (Java 17)](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/System.html#nanoTime()).

Este reloj incluye: creación de `JobInstance`+`JobExecution` en la BD, todos los steps, y el `update` final. Es exactamente *"cuánto tarda el proceso batch"*, que es lo que la rúbrica compara. **Es también el único reloj inmune a los problemas de instrumentación de la §2.**

### 1.3 Reloj C — `JobExecution.getStartTime()` / `getEndTime()`

En Spring Batch 5.x devuelven **`LocalDateTime`** (en 4.x eran `java.util.Date`):

```java
Duration d = Duration.between(exec.getStartTime(), exec.getEndTime());
```

**Ventaja:** queda persistido en `BATCH_JOB_EXECUTION` (`START_TIME`, `END_TIME`), así que puedes reconstruir toda la tabla de resultados con SQL sin depender de logs.
**Desventaja:** al releerlo por SQL, la granularidad la fija la columna `TIMESTAMP` de la BD (milisegundos). *En memoria*, dentro de `afterJob`, la resolución es la de `LocalDateTime.now()` (micro/nanosegundos). Y no cubre el overhead previo del `JobLauncher`.

Spring Batch expone una utilidad para esto:
`org.springframework.batch.core.observability.BatchMetrics.calculateDuration(LocalDateTime start, LocalDateTime end)` → `Duration`, y `formatDuration(...)` para salida legible.

> **Cuidado (verificado en el javadoc de la clase):** `BatchMetrics` está marcada literalmente como *"Only intended for internal use."* Funciona, pero si la usas deja un comentario reconociéndolo, o replica `Duration.between(...)`, que es trivial. Ver [`BatchMetrics`](https://docs.spring.io/spring-batch/docs/5.2.x/api/org/springframework/batch/core/observability/BatchMetrics.html).

### 1.4 Reloj D — `StepExecution`, el nivel con la información interesante

Todos estos getters devuelven **`long`** en Spring Batch 5.x (en 4.x eran `int` — importante si copias código de tutoriales viejos):

```java
for (StepExecution se : exec.getStepExecutions()) {
    se.getStepName();
    Duration.between(se.getStartTime(), se.getEndTime());
    long read     = se.getReadCount();        // ítems leídos
    long written  = se.getWriteCount();       // ítems escritos
    long filtered = se.getFilterCount();      // el processor devolvió null (filas descartadas)
    long commits  = se.getCommitCount();      // nº de chunks confirmados
    long rollback = se.getRollbackCount();    // reintentos/rollbacks
    long skips    = se.getSkipCount();        // = readSkip + processSkip + writeSkip
    se.getReadSkipCount(); se.getProcessSkipCount(); se.getWriteSkipCount();
}
```

**`getCommitCount()` es oro para tu informe.** Con 100.000 ítems y `chunkSize=10` verás ~10.000 commits; con `chunkSize=500`, ~200. Cada commit es un `UPDATE` a `BATCH_STEP_EXECUTION` **más** el commit real de la transacción de negocio. Esa cifra es la explicación cuantitativa de por qué `chunkSize=10` es lento, y es justo el tipo de argumento que separa un 15/15 de un 9/15.

> Matiz honesto: en un step `faultTolerant`, `commitCount` puede **exceder** `items/chunkSize`, porque tras una excepción Spring Batch reprocesa el chunk ítem a ítem para aislar al culpable. Si tus números no cuadran exactamente, ésa es la razón — y decirlo suma.

En un **PartitionStep** verás el step manager más N `StepExecution` hijas (`workerStep:partition0`, `:partition1`, …). La suma de sus duraciones **no** es la duración del manager: se solapan. Reportar `max(duración hija)` frente a `sum(duración hija)` da directamente el grado de paralelismo efectivo y el **desbalance de particiones** (skew).

### 1.5 Dónde enganchar la medición: `JobExecutionListener`

```java
public class JobTimingListener implements JobExecutionListener {
    private long t0;
    @Override public void beforeJob(JobExecution je) { t0 = System.nanoTime(); }
    @Override public void afterJob(JobExecution je) {
        long nanos = System.nanoTime() - t0;
        je.getExecutionContext().putLong("elapsedNanos", nanos);
    }
}
```

Guardarlo en el `ExecutionContext` lo persiste en `BATCH_JOB_EXECUTION_CONTEXT`.

**✅ VERIFICADO (esto era un punto incierto en la versión anterior de este informe; ya no lo es).** El bloque `finally` de `AbstractJob.execute()` en 5.2.x es, textualmente:

```java
stopObservation(execution, observation);
longTaskTimerSample.stop();
execution.setEndTime(LocalDateTime.now());

try {
    listener.afterJob(execution);
} catch (Exception e) { logger.error("Exception encountered in afterJob callback", e); }

jobRepository.update(execution);
```

Dos conclusiones, ambas citables:
1. **`getEndTime()` SÍ está disponible dentro de `afterJob`.** Confirmado, no hace falta comprobarlo empíricamente.
2. **El timer `spring.batch.job` se cierra ANTES de `setEndTime`**, por tanto **excluye** el `afterJob` y el `jobRepository.update()` final. Orden esperado de magnitudes:
   `spring.batch.job` **<** `Duration.between(getStartTime(), getEndTime())` **<** reloj B.
   Si tu informe muestra esa desigualdad y la explica, demuestra que entendiste dónde mide cada instrumento.

Fuente: [`AbstractJob.java` (5.2.x)](https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/job/AbstractJob.java).

---

## 2. Métricas que Spring Batch expone en Micrometer

Desde Spring Batch 4.2 las métricas se publican bajo el prefijo `spring.batch`.

> ### ⚠ ADVERTENCIA CRÍTICA — la tabla de tags de la documentación oficial está desactualizada
>
> La [tabla de *Monitoring and metrics* 5.2](https://docs.spring.io/spring-batch/reference/5.2/monitoring-and-metrics.html) lista los tags como `name`, `status`, `job.name`, `step.name`. **Eso era cierto en Batch 4.x.** Desde 5.0 los tags están **totalmente cualificados** con el prefijo de su métrica. Si programas contra la tabla de la doc, `registry.find(...).tag("job.name", ...)` devuelve **`null`** y tu CSV sale con columnas vacías sin ningún error.
>
> La tabla siguiente está tomada del **código fuente de 5.2.6**, no de la documentación.

### 2.1 Tabla real de métricas (verificada en código, Batch 5.2.6)

| Nombre | Tipo | Qué mide | Tags REALES | Origen en el código |
|---|---|---|---|---|
| `spring.batch.job` | `TIMER` | Duración del Job | `spring.batch.job.name`, `spring.batch.job.status` | `DefaultBatchJobObservationConvention` |
| `spring.batch.job.active` | `LONG_TASK_TIMER` | Jobs en ejecución | `spring.batch.job.active.name` ⚠ ver §2.2 | `AbstractJob:284` |
| `spring.batch.job.launch.count` | `COUNTER` | Lanzamientos de job | *(sin tags)* | `TaskExecutorJobLauncher:233` |
| `spring.batch.step` | `TIMER` | Duración del Step | `spring.batch.step.name`, `spring.batch.step.job.name`, `spring.batch.step.status` | `DefaultBatchStepObservationConvention` |
| `spring.batch.step.active` | `LONG_TASK_TIMER` | Steps en ejecución | `spring.batch.step.name`, `spring.batch.step.job.name`, `spring.batch.step.status` | Micrometer `DefaultMeterObservationHandler` |
| `spring.batch.item.read` | `TIMER` | Lectura **de un ítem** | `spring.batch.item.read.job.name`, `.step.name`, `.status` | `SimpleChunkProvider:156` |
| `spring.batch.item.process` | `TIMER` | Procesado **de un ítem** | `spring.batch.item.process.job.name`, `.step.name`, `.status` | `SimpleChunkProcessor:349` |
| `spring.batch.chunk.write` | `TIMER` | Escritura **de un chunk** | `spring.batch.chunk.write.job.name`, `.step.name`, `.status` | `SimpleChunkProcessor:349` |

Notas verificadas:
- **`spring.batch.job.launch.count` SÍ existe en 5.2.x** (`BatchMetrics.createCounter(meterRegistry, "job.launch.count", "Job launch count")` en `TaskExecutorJobLauncher.afterPropertiesSet()`). Solo falta en la *tabla* de la doc 5.2. No tiene tags, así que no discrimina por job: con varios jobs es un contador global.
- **Valor del tag `status`:** para job y step es el **exit code** (`execution.getExitStatus().getExitCode()`, típicamente `COMPLETED`/`FAILED`); para ítem y chunk es `SUCCESS`/`FAILURE` (constantes `BatchMetrics.STATUS_SUCCESS`/`STATUS_FAILURE`). La doc de 5.2 dice solo *"either SUCCESS or FAILURE"* — cierto únicamente para ítem/chunk.
- **`spring.batch.step.active` no lo crea `AbstractStep`.** Lo crea Micrometer: `DefaultMeterObservationHandler` registra automáticamente un `LongTaskTimer` llamado `<nombreObservación> + ".active"`. Por eso hereda los tags de la observación de step.
- `BatchStepObservation` declara un tag `spring.batch.step.type`, pero el **convention por defecto no lo emite**. No lo busques.

### 2.2 Bug conocido: `spring.batch.job.active` se registra dos veces

En 5.2.x esa métrica se crea desde **dos sitios** con juegos de tags incompatibles:
1. `AbstractJob:284` → tag `spring.batch.job.active.name`
2. `DefaultMeterObservationHandler` → tags `spring.batch.job.name`, `spring.batch.job.status=UNKNOWN`

Con Prometheus produce el WARN *"requires that all meters with the same name have the same set of tag keys…"*. Corregido en **6.0.0-M4**. Ver [issue #4753](https://github.com/spring-projects/spring-batch/issues/4753). **Menciónalo en el informe:** demuestra que leíste el código y no solo la doc.

### 2.3 Habilitarlas

**Batch 5.x.** No basta con un `MeterRegistry`. Verificado en el código: `AbstractJob` y `AbstractStep` inicializan `observationRegistry = ObservationRegistry.NOOP`. Sin un **bean `ObservationRegistry`**, `spring.batch.job` y `spring.batch.step` **no se registran en absoluto** (las de ítem/chunk sí, porque usan `MeterRegistry` con default `Metrics.globalRegistry`).

Quien inyecta el registry es `BatchObservabilityBeanPostProcessor`, que si no encuentra el bean loguea:
`"No Micrometer observation registry found, defaulting to ObservationRegistry.NOOP"`.

En Spring Boot funciona sin configuración porque **Actuator autoconfigura el bean `ObservationRegistry`**:

```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```
```properties
management.endpoints.web.exposure.include=metrics,health
```

Boot autoconfigura además un **registry "simple" en memoria** como fallback: *"Micrometer ships with a simple, in-memory backend that is automatically used as a fallback if no other registry is configured."* Y añade sus registries al registry global estático (`management.metrics.use-global-registry=true` por defecto), por lo que las métricas de ítem/chunk —que van a `Metrics.globalRegistry`— también aparecen en `/actuator/metrics`. ([Spring Boot Actuator Metrics](https://docs.spring.io/spring-boot/reference/actuator/metrics.html))

> ### 🚨 TRAMPA QUE INVALIDA ESTA SECCIÓN ENTERA — léela junto con §5.1
> `BatchObservabilityBeanPostProcessor` es un **`BeanPostProcessor`**: solo actúa sobre `Job`/`Step` que sean **beans de Spring**.
> Si construyes los jobs con una *factory* imperativa (que es lo que recomienda §5.1), **el post-procesador nunca se ejecuta** y todas las métricas de job y step quedan en NOOP, silenciosamente.
>
> **Solución obligatoria:** pasar el registry explícitamente en cada builder (`@since 5.0`):
> ```java
> new JobBuilder(name, jobRepository)
>       .observationRegistry(observationRegistry)
>       .meterRegistry(meterRegistry)
>       ...
> new StepBuilder(name, jobRepository)
>       .observationRegistry(observationRegistry)
>       .meterRegistry(meterRegistry)
>       ...
> ```
> En un `PartitionStep` hay que hacerlo **tanto en el manager como en el worker**.

**Batch 6.x:** el bean es obligatorio siempre (*"the usage of Micrometer's global static meter registry was removed"*):

```java
@Bean
public ObservationRegistry observationRegistry(MeterRegistry meterRegistry) {
    ObservationRegistry registry = ObservationRegistry.create();
    registry.observationConfig()
            .observationHandler(new DefaultMeterObservationHandler(meterRegistry));
    return registry;
}
```
([Micrometer support, Spring Batch 6.0](https://docs.spring.io/spring-batch/reference/spring-batch-observability/micrometer.html))

### 2.4 Leerlas — vía HTTP (con los tags CORRECTOS)

```bash
curl http://localhost:8080/actuator/metrics

curl "http://localhost:8080/actuator/metrics/spring.batch.job?tag=spring.batch.job.name:interesesJob"

curl "http://localhost:8080/actuator/metrics/spring.batch.chunk.write\
?tag=spring.batch.chunk.write.job.name:interesesJob\
&tag=spring.batch.chunk.write.status:SUCCESS"
```

Devuelve `COUNT`, `TOTAL_TIME`, `MAX`. **No devuelve percentiles** salvo que los actives:

```properties
management.metrics.distribution.percentiles-histogram.spring.batch.step=true
management.metrics.distribution.percentiles.spring.batch.step=0.5,0.95,0.99
```

> **Primer paso obligatorio del experimento:** ejecuta `GET /actuator/metrics` una vez y **pega la lista literal de nombres en tu informe**. Es la prueba de que tus tags existen en tu build, y te ahorra descubrir a las 60 ejecuciones que estabas leyendo `null`.

### 2.5 Leerlas — programáticamente (lo que usará tu runner)

```java
@Component
public class MicrometerSnapshotReader {

    private final MeterRegistry registry;

    public MicrometerSnapshotReader(MeterRegistry registry) { this.registry = registry; }

    /** Media en ms del timer de escritura de chunk para un job dado.
     *  OJO con el nombre del tag: totalmente cualificado, no "job.name". */
    public double avgChunkWriteMs(String jobName) {
        Timer t = registry.find("spring.batch.chunk.write")
                          .tag("spring.batch.chunk.write.job.name", jobName)
                          .timer();
        return t == null ? Double.NaN : t.mean(TimeUnit.MILLISECONDS);
    }

    public long chunkWriteCount(String jobName) {
        Timer t = registry.find("spring.batch.chunk.write")
                          .tag("spring.batch.chunk.write.job.name", jobName)
                          .timer();
        return t == null ? 0L : t.count();
    }

    /** Importante entre repeticiones: los Timer son acumulativos.
     *  getMeters() devuelve un snapshot, así que remover mientras se itera es seguro. */
    public void clearBatchMeters() {
        registry.getMeters().stream()
                .filter(m -> m.getId().getName().startsWith("spring.batch"))
                .forEach(registry::remove);
    }
}
```

**Trampa 1 — los `Timer` son acumulativos dentro de la JVM.** Si corres 60 ejecuciones en el mismo proceso sin limpiar, `spring.batch.job` te dará el promedio de las 60 mezcladas, no el de la última. O limpias los meters entre repeticiones (arriba), o —más limpio— **tomas snapshot de `count`/`totalTime` antes y después** de cada ejecución y calculas la delta.

**Trampa 2 — sesgo del observador.** `spring.batch.item.read` y `spring.batch.item.process` registran **un Timer por ítem**. Con 100.000 filas × 3 jobs × decenas de configuraciones son millones de `Timer.record()`. El coste no es cero y **contamina justo la medición que quieres**. Recomendación:

- Métricas de ítem **activas** en una corrida exploratoria (para localizar el cuello de botella).
- En la matriz oficial de tiempos, **desactívalas** y documenta que lo hiciste:

```java
Metrics.globalRegistry.config().meterFilter(
    MeterFilter.deny(id -> id.getName().startsWith("spring.batch.item")));
// equivalente y más idiomático:
// MeterFilter.denyNameStartsWith("spring.batch.item")
```
Ambas formas existen en Micrometer (`MeterFilter.deny(Predicate<Meter.Id>)` y `MeterFilter.denyNameStartsWith(String)`). Reportar esta decisión es exactamente el rigor que la rúbrica premia.

---

## 3. Diseño del experimento honesto

### 3.1 Factores y por qué NO hacer factorial completo

| Factor | Niveles | # |
|---|---|---|
| Estrategia | secuencial / multi-thread / partición | 3 |
| Paralelismo (threads o gridSize) | 1, 2, 4, 8 | 4 |
| `chunkSize` | 10, 50, 100, 500 | 4 |
| Dataset | 1k (real), 100k (amplificado) | 2 |

Factorial completo = 3 × 4 × 4 × 2 = 96 celdas × 3 jobs × 7 repeticiones = **2.016 ejecuciones**. Innecesario, y con 100k filas puede ser horas.

**Diseño escalonado (defendible y explicable en 3 frases):**

- **Fase 0 — Baseline.** Secuencial, `chunkSize ∈ {10, 50, 100, 500}`, paralelismo = 1. **4 celdas.** Aísla el efecto de `chunkSize` sin interferencia de concurrencia. Sale un `chunk*` ganador.
- **Fase 1 — Paralelismo.** Fijar `chunk = chunk*`. Cruzar {multi-thread, partición} × {2, 4, 8}. **6 celdas.**
- **Fase 2 — Confirmación cruzada.** Tomar la mejor celda de Fase 1 y re-cruzarla con los 2 mejores `chunkSize` de Fase 0. **2–4 celdas.** Esta fase es la que te protege de la crítica *"asumiste que los factores no interactúan"*. Si el óptimo de Fase 2 coincide con el de Fase 1, tu diseño escalonado queda validado; si no coincide, tienes un hallazgo *interesante* (interacción chunk×threads) que reportar.

Total: ~14 celdas × 7 repeticiones = **98 ejecuciones por job**. Manejable.

### 3.2 Repeticiones y warm-up

**7 repeticiones por celda. Descarta las 2 primeras como warm-up. Reporta la MEDIANA de las 5 restantes, más el rango intercuartílico (IQR) y el coeficiente de variación (CV = σ/μ).**

Justificación:
- La JVM arranca interpretando bytecode; HotSpot compila con C1 y luego C2 tras miles de invocaciones. **La primera ejecución puede ser 2–5× más lenta que la quinta** sin que cambie nada de tu configuración.
- Se suma el *class loading* perezoso (parsers de fecha, proxies CGLIB de `@StepScope`, drivers JDBC) y el llenado del pool de HikariCP.
- Y el *page cache* del SO: la primera lectura del CSV va a disco, las siguientes vienen de RAM.

Si mides sin descartar warm-up, **el orden de ejecución determina el ganador** — la primera celda siempre pierde. Eso es un experimento inválido y un evaluador atento lo detecta.

Refuerzos:
- **Aleatoriza el orden de las celdas** entre repeticiones, o ejecuta **por rondas** (ronda 1 = todas las celdas, ronda 2 = todas…, en vez de 7 seguidas de A y luego 7 de B). Reparte la deriva térmica/de carga entre todas las celdas en vez de castigar a una.
- **Mediana, no media.** Una pausa de GC o del SO desplaza la media; la mediana la absorbe.
- **Heap fijo:** `-Xms2g -Xmx2g`. Con `-Xms` pequeño la JVM redimensiona el heap durante la corrida y aparece como ruido inexplicable.
- **JMH: menciónala, no la uses.** [JMH](https://github.com/openjdk/jmh) es la herramienta canónica para *microbenchmarks* JVM (fork por benchmark, warm-up e iteraciones gestionadas, protección contra dead-code elimination). Un job Spring Batch **no** es un microbenchmark: dura cientos de ms a segundos, toca BD y disco, y JMH no puede reiniciar el contexto Spring por iteración de forma barata. Redacción sugerida: *"adoptamos la metodología de JMH (warm-up + N iteraciones + estadística de dispersión) sin su runner"*. Demuestra que sabes que existe y por qué no aplica.

### 3.3 Evitar que la BD sea el cuello de botella (o al menos, saber que lo es)

Aquí es donde la mayoría de trabajos falla en silencio.

1. **Pool de conexiones ≥ paralelismo + margen.** Con `gridSize=8` y `maximumPoolSize=10` (default de Hikari), y cada worker necesitando conexión para el `JobRepository` *y* para el writer, los threads se bloquean esperando conexión. **Estarías midiendo el pool, no el paralelismo.**
   ```properties
   spring.datasource.hikari.maximum-pool-size=20
   spring.datasource.hikari.minimum-idle=20
   ```
   Fijar `minimum-idle = maximum-pool-size` evita que el pool crezca durante la medición (otra fuente de ruido). ([HikariCP — About Pool Sizing](https://github.com/brettwooldridge/HikariCP/wiki/About-Pool-Sizing)) **Reporta el tamaño del pool en la tabla de resultados**: es un parámetro del experimento, no un detalle.

2. **Batching JDBC real en el writer.** Usa `JdbcBatchItemWriter` (agrupa el chunk en `PreparedStatement.addBatch()`). Pero el driver puede seguir mandando N round-trips:
   - PostgreSQL: `?reWriteBatchedInserts=true`
   - MySQL: `?rewriteBatchedStatements=true`

   Sin esto, `chunkSize=500` no da el beneficio esperado y **tu conclusión sobre chunk size sería falsa**.

3. **Aísla el cuello de botella con una variante control.**
   ```java
   ItemWriter<Transaccion> noop = chunk -> { };   // ItemWriter es @FunctionalInterface en 5.x
   ```
   Si el tiempo apenas baja → el cuello está en lectura/parseo (CPU) y el paralelismo ayudará. Si se desploma → el cuello es la BD y **añadir threads no mejorará nada**, solo aumentará contención. Esta comparación de dos líneas produce la conclusión técnica más fuerte de todo tu informe.

4. **La BD compite por CPU con la JVM.** Si Postgres corre en Docker en el mismo portátil, con `gridSize=8` en 4 núcleos, JVM y BD se pelean por los mismos cores. **Documenta `Runtime.getRuntime().availableProcessors()` en cada fila del CSV.** Sin ese dato, tu "punto de saturación" no es interpretable.

5. **Las tablas `BATCH_*` son parte del sistema medido.** Cada commit de chunk hace `UPDATE BATCH_STEP_EXECUTION SET VERSION=?, READ_COUNT=?, … WHERE STEP_EXECUTION_ID=?`. Con **particiones**, N workers golpean N filas distintas (bien). Con **multi-thread**, los N threads golpean **la misma fila** → contención de bloqueo optimista (columna `VERSION`) y posibles reintentos. **Ésta es una razón técnica real y citable por la que la partición suele escalar mejor que multi-thread en Spring Batch.**

6. **Estado inicial idéntico.** `TRUNCATE` de las tablas de negocio antes de cada ejecución, **fuera del cronómetro**. Si no, la corrida 7 inserta sobre una tabla con 700k filas y sus índices, y es más lenta por razones ajenas a la configuración.

### 3.4 Trampa específica de multi-thread: el reader serializado

`FlatFileItemReader` **no es thread-safe**. Dos citas oficiales, ambas verbatim:

- Reference 5.2, *Scalability*: *"In particular, most of the readers and writers from Spring Batch are not designed for multi-threaded use."*
- Javadoc de `AbstractItemCountingItemStreamItemReader` (superclase de `FlatFileItemReader`): *"Subclasses are inherently **not** thread-safe."*

La solución estándar, también documentada (*"If a reader is not thread safe, you can decorate it with the provided `SynchronizedItemStreamReader`"*):

```java
SynchronizedItemStreamReader<Transaccion> safe = new SynchronizedItemStreamReader<>();
safe.setDelegate(flatFileItemReader());
```

Verificado en el código: `SynchronizedItemStreamReader` declara `private final Lock lock = new ReentrantLock();` y envuelve `read()` en `lock()/unlock()`.

**Consecuencia que DEBES explicar:** eso **serializa la fase de lectura**. En la ley de Amdahl, la lectura pasa a la fracción secuencial (1−p). Con un CSV cuyo parseo es la mayor parte del trabajo, multi-thread rendirá poco **por diseño**. **La partición no tiene este problema:** cada partición abre su propio `FlatFileItemReader` sobre un rango disjunto, sin lock compartido.

Si tu experimento muestra "particiones ganan a multi-thread", ésta es la explicación causal, no una casualidad. Escribirla vale puntos.

**Sobre restartabilidad — enunciado corregido y defendible.** El decorador no "rompe" nada por sí mismo; el problema es del step multihilo: `FlatFileItemReader` guarda `read.count` en el `ExecutionContext` para reanudar, pero con N hilos ese contador **ya no corresponde a un prefijo contiguo de ítems procesados** (el ítem 900 puede estar hecho y el 850 no). Reanudar desde ahí puede saltarse o reprocesar filas. Salidas: readers stateless/thread-safe, el patrón *process indicator* que la doc recomienda, o `reader.setSaveState(false)`, que **renuncia explícitamente** al restart a mitad de step. **La partición no sufre esto:** cada partición tiene su propio `StepExecution` y su propio `ExecutionContext`. Menciónalo en la sección de tolerancia a fallos (criterio 5).

### 3.5 Trampa: "4 threads" que no son 4 threads

`SimpleAsyncTaskExecutor` **no es un pool**. Javadoc verbatim: *"**NOTE: This implementation does not reuse threads!**"* — sin excepciones. `setConcurrencyLimit` **acota cuántas tareas corren a la vez** (mediante `ConcurrencyThrottleSupport`), pero **cada tarea sigue costando la creación de un hilo nuevo**.

Doble motivo para no usarlo en el experimento: (a) sin `concurrencyLimit` tu eje X es ficticio, porque el número real de hilos concurrentes lo decide el throttling interno; (b) aun con `concurrencyLimit`, el coste de crear un hilo por tarea contamina la medición.

Usa siempre un pool fijo:

```java
public static TaskExecutor fixedPool(int n) {
    ThreadPoolTaskExecutor te = new ThreadPoolTaskExecutor();
    te.setCorePoolSize(n);
    te.setMaxPoolSize(n);              // == core: pool fijo, sin crecimiento durante la medición
    te.setQueueCapacity(Integer.MAX_VALUE);
    te.setThreadNamePrefix("batch-exp-");
    te.setWaitForTasksToCompleteOnShutdown(true);
    te.initialize();
    return te;
}
```

**Sobre `throttleLimit`:** está en `AbstractTaskletStepBuilder` (heredado por `SimpleStepBuilder`/`TaskletStepBuilder`), **no** en `StepBuilder`. Javadoc verbatim: *"@deprecated with no replacement since 5.0, **scheduled for removal in 6.0**. Use a custom `RepeatOperations` implementation … `#stepOperations(RepeatOperations)`"*. Confirmado: **en 6.0 ya está eliminado**. No lo uses; controla la concurrencia con el pool.

### 3.6 Trampa: `gridSize` vs. número real de particiones

`gridSize` es una **sugerencia** al `Partitioner`. La interfaz es literalmente:
```java
public interface Partitioner { Map<String, ExecutionContext> partition(int gridSize); }
```
Tu implementación decide cuántas particiones devuelve. Si particionas por `cuenta_id` y solo hay 20 cuentas, pedir `gridSize=64` no crea 64 particiones útiles.

Con tus datos reales (`docs/analisis-datos.md`):

| Archivo | Clave | Cardinalidad | Filas/clave | Particiones máx. | skew = max/avg | ratio max/min |
|---|---|---|---|---|---|---|
| `transacciones.csv` | `id` 1..1000 contiguo, sin duplicados | 1000 | 1 | libre (por rango) | **1,00** | 1,00 |
| `intereses.csv` | `cuenta_id` 101..150 | 50 | 12–33 | **50** | **1,65** | 2,75 |
| `cuentas_anuales.csv` | `cuenta_id` 101..120 | 20 | 39–60 | **20** | **1,20** | 1,54 |

`transacciones.csv` es el caso ideal para el experimento: **rango de id perfectamente balanceado**.

**Reporta las dos métricas y no las confundas:**
- **`skew = max(readCount hija) / avg(readCount hija)`** — es la que predice el impacto real: el manager termina cuando termina la partición más lenta, así que `skew` es aproximadamente el factor por el que pierdes speedup.
- **`ratio = max/min`** — mide dispersión, se ve más dramático, pero no es lo que frena al manager.

Ambas salen gratis de los `StepExecution` hijos.

### 3.7 Cuándo partición ≠ multi-thread por corrección, no por rendimiento

Argumento fuerte para el **Job 2 (Intereses)**, que *actualiza el saldo* de cuentas: `intereses.csv` tiene 12–33 filas por `cuenta_id`. Con **multi-thread**, dos hilos pueden procesar dos filas de la **misma cuenta** a la vez → `UPDATE cuentas SET saldo = ? WHERE id = ?` desde ambos = **lost update**, o deadlock si el orden de locks difiere. Con **partición por `cuenta_id`**, una cuenta pertenece a exactamente una partición y a un solo hilo: la corrección está garantizada por construcción.

Conclusión defendible: *"para el Job 2 la partición no es una optimización opcional sino un requisito de corrección; para el Job 1 (sin estado compartido entre filas) ambas estrategias son válidas y ahí sí la elección es puramente de rendimiento."* Es exactamente el nivel de análisis que pide el criterio 6.

---

## 4. El problema de las 1.000 filas — y cómo tratarlo con honestidad

### 4.1 Por qué 1.000 filas es ruido

Un job sobre 1.000 filas de CSV → BD tarda del orden de **150–500 ms**. De eso:

| Componente | Coste aproximado | ¿Escala con threads? |
|---|---|---|
| `INSERT` en `BATCH_JOB_INSTANCE` + `BATCH_JOB_EXECUTION` + params | ~10–30 ms | No (fijo) |
| Creación del pool / setup del `PartitionStep` | ~5–40 ms | **Empeora** con N |
| Apertura del `FlatFileItemReader`, buffers | ~5–20 ms | No |
| Lectura + parseo de 1.000 líneas | ~20–60 ms | Sí |
| Processor (validación, 4 formatos de fecha) | ~20–80 ms | Sí |
| Escritura JDBC (chunk=100 → 10 batches) | ~40–150 ms | Parcialmente |
| `UPDATE` final de metadatos | ~5–15 ms | No |

La **fracción paralelizable p ≈ 0,3–0,5**. Ley de Amdahl con p = 0,4:

$$S(n)=\frac{1}{(1-p)+\frac{p}{n}} \qquad S(4)=\frac{1}{0{,}6+0{,}1}=1{,}43 \qquad S(\infty)=\frac{1}{0{,}6}=1{,}67$$

Un speedup teórico máximo de 1,43× sobre 300 ms son **~90 ms** de mejora. **La desviación estándar entre repeticiones de la misma configuración en un portátil es fácilmente ±30–60 ms.** La señal está dentro del ruido. Y el overhead de crear el pool y las particiones puede comerse la mejora entera: es **habitual y correcto** que con 1.000 filas el particionado sea *más lento* que el secuencial.

> Nota de contexto: la guía de la semana muestra 329 ms vs 234 ms. Es exactamente este régimen. Un 1,4× medido una sola vez a esa escala es indistinguible del ruido — **no lo cites como evidencia sólida.**

### 4.2 Estrategia recomendada: reportar AMBAS escalas

No elijas. Haz las dos y explica por qué.

**Escala A — dataset real (1.000 filas).** Es el dato honesto sobre el problema tal como te lo entregaron. Conclusión esperada y perfectamente válida: *"a la escala del dataset entregado, ninguna configuración paralela supera al secuencial de forma estadísticamente distinguible (los IQR se solapan); el overhead de coordinación domina. La configuración óptima a 1k filas es secuencial con chunk=100."*

**Un evaluador serio valora más esto que un speedup de 1,4× presentado como hallazgo.** Y demuestra que entendiste Amdahl.

**Escala B — dataset amplificado (100.000 filas).** Aquí sí el paralelismo tiene margen: curvas legibles, punto de saturación y contención medible. Es donde ganas el criterio 4 con datos de verdad.

**La joya es el cruce de ambas:** *"existe un punto de equilibrio en torno a N filas por debajo del cual el particionado es contraproducente."* Si lo mides (1k / 5k / 20k / 100k, mejor config paralela vs. secuencial, y ves dónde se cruzan las curvas), tienes el gráfico más convincente que puedes entregar.

### 4.3 Cómo amplificar el dataset de forma legítima

1. **No modifiques los CSV originales.** Quedan intactos y versionados, tal como vinieron de `KariVillagran/bank_legacy_data`.
2. **Genera el amplificado con un script versionado y determinista** (semilla fija), reproducible por el evaluador con un comando.
3. **Preserva las proporciones de defectos.** Replicar ×100 las mantiene automáticamente (168/1000 montos vacíos → 16.800/100.000). La carga del `ItemProcessor` sigue siendo representativa.
4. **Re-secuencia los IDs.** En `transacciones.csv` el `id` es único 1..1000; si replicas sin tocarlo tendrás 100 filas con `id=1`, lo que rompe la PK y **cambia la naturaleza del test** (medirías violaciones de constraint). Reasigna `id = 1..100000`.
5. **NO re-secuencies `cuenta_id`.** En `intereses.csv` y `cuentas_anuales.csv` es una FK con cardinalidad real (50 y 20). Mantenerla preserva la característica más interesante: **el particionado por cuenta está limitado por la cardinalidad, no por `gridSize`**. Inflar las cuentas a 5.000 sería inventar un problema distinto del real.
6. **Declara el factor de amplificación** en cada fila del CSV de resultados (columna `datasetRows`) y en el README.
7. **Marca el archivo como derivado:** `transacciones_x100.csv`, en `data/generated/`, con `.gitignore` (o comprimido, ~1–2 MB en gzip).

Redacción sugerida para el README:
> *"Los tiempos de la escala 100k se obtuvieron sobre un dataset sintético derivado del original por replicación ×100 con re-secuenciación de claves primarias, preservando la distribución exacta de defectos (formatos de fecha, montos vacíos/negativos, tipos inválidos) y la cardinalidad original de `cuenta_id`. El generador es `DatasetAmplifier` y es determinista. Los CSV originales no fueron modificados."*

```java
/**
 * Genera un CSV amplificado replicando el original N veces.
 * Determinista. NO altera el archivo fuente.
 */
public final class DatasetAmplifier {

    /**
     * @param source        CSV original (con cabecera)
     * @param target        destino
     * @param factor        nº de réplicas
     * @param pkColumnIndex índice de la columna PK a re-secuenciar, o -1 si no aplica
     */
    public static void amplify(Path source, Path target, int factor, int pkColumnIndex)
            throws IOException {
        List<String> lines = Files.readAllLines(source, StandardCharsets.UTF_8);
        String header = lines.get(0);
        List<String> body = lines.subList(1, lines.size());

        try (BufferedWriter out = Files.newBufferedWriter(target, StandardCharsets.UTF_8)) {
            out.write(header); out.newLine();
            long pk = 1;
            for (int rep = 0; rep < factor; rep++) {
                for (String line : body) {
                    if (pkColumnIndex >= 0) {
                        String[] cols = line.split(",", -1);   // -1 conserva campos vacíos
                        cols[pkColumnIndex] = Long.toString(pk++);
                        line = String.join(",", cols);
                    }
                    out.write(line); out.newLine();
                }
            }
        }
    }
}
```

`split(",", -1)` con límite negativo es **obligatorio**: sin él Java descarta los campos vacíos finales y perderías precisamente las `descripcion` vacías (230 filas) y los `monto` vacíos que son parte del test.

---

## 5. Diseño del runner de experimentos

### 5.1 Arquitectura

```
com.bancoxyz.batch.experiment
├── ExperimentCase.java          (record) — una celda de la matriz
├── ExperimentResult.java        (record) — resultado de UNA ejecución
├── ScalingStrategy.java         (enum)  — SEQUENTIAL | MULTI_THREAD | PARTITIONED
├── ExperimentMatrix.java                — construye la lista de casos (fases 0/1/2)
├── ExperimentJobFactory.java            — construye Job/Step a partir de un caso
├── ScalingExperimentRunner.java         — orquesta, mide, repite
├── ExperimentResultWriter.java          — vuelca CSV
└── EnvironmentProbe.java                — captura contexto de la máquina
```

**Decisión de diseño: construir los `Job`/`Step` con una *factory* imperativa, no con beans `@Bean` parametrizados.**

El `chunkSize` se fija en `StepBuilder.chunk(n, tx)` en **tiempo de definición de bean**. Para variarlo por ejecución la vía "Spring" sería `@Bean @JobScope` con `@Value("#{jobParameters['chunkSize']}")`, que funciona pero introduce proxies de scope, complica la depuración y añade resolución SpEL dentro de la medición. Una factory que devuelve objetos frescos es más simple, más transparente y no contamina el tiempo medido. Los `JobParameters` siguen usándose — para que la configuración quede **registrada en `BATCH_JOB_EXECUTION_PARAMS`** y puedas reconstruir la tabla de resultados con SQL.

> ### 🚨 PRECIO DE ESTA DECISIÓN — obligatorio compensarlo
> Al no ser beans, `BatchObservabilityBeanPostProcessor` **no** se ejecuta sobre estos jobs y steps, y todas las métricas de §2 quedan en `ObservationRegistry.NOOP`.
> **Cada** `JobBuilder` y **cada** `StepBuilder` (manager y worker incluidos) debe recibir el registry explícitamente.

### 5.2 Modelo de datos

```java
public enum ScalingStrategy { SEQUENTIAL, MULTI_THREAD, PARTITIONED }

/** Una celda de la matriz experimental. Inmutable. */
public record ExperimentCase(
        String jobName,            // "transaccionesJob" | "interesesJob" | "cuentasAnualesJob"
        ScalingStrategy strategy,
        int parallelism,           // threads (MULTI_THREAD) | gridSize (PARTITIONED) | 1 (SEQUENTIAL)
        int chunkSize,
        int datasetRows,           // 1_000 | 100_000
        String phase               // "F0-baseline" | "F1-parallel" | "F2-confirm"
) {
    public String label() {
        return "%s-%s-p%d-c%d-n%d".formatted(jobName, strategy, parallelism, chunkSize, datasetRows);
    }
}

/** Resultado de UNA ejecución individual (una repetición de un caso).
 *  Todos los contadores son long: en Spring Batch 5.x los getters de
 *  StepExecution devuelven long (en 4.x eran int). */
public record ExperimentResult(
        ExperimentCase testCase,
        int repetition,
        boolean warmup,            // true = excluir del análisis, pero SÍ va al CSV
        long wallClockNanos,       // reloj B — métrica primaria
        long jobExecutionMillis,   // reloj C — desde JobExecution start/end
        String batchStatus,
        String exitCode,
        long readCount, long writeCount, long filterCount,
        long skipCount, long commitCount, long rollbackCount,
        long maxPartitionMillis,   // duración de la partición más lenta
        long sumPartitionMillis,   // suma de duraciones de particiones
        double partitionSkew,      // max(readCount hija) / avg(readCount hija); 1.0 = perfecto
        double partitionMaxMin,    // max/min: dispersión (NO es el skew)
        int hikariPoolSize,
        int availableProcessors,
        long heapMaxBytes,
        String timestampIso
) {
    public double throughputItemsPerSec() {
        double secs = wallClockNanos / 1_000_000_000d;
        return secs == 0 ? 0 : readCount / secs;
    }
}
```

> Nota práctica sobre `label()`: **evita `/` en nombres de step**. Los nombres van a `BATCH_STEP_EXECUTION.STEP_NAME` (`VARCHAR(100)` en el DDL estándar) y en particionado se les añade el sufijo `:partitionN`. Usa `-` y vigila la longitud.

`warmup` como columna en vez de descartar en silencio: **el CSV crudo contiene TODO**, incluidos los descartes. El filtrado se hace en el análisis y queda documentado. Ésa es la diferencia entre reportar y maquillar.

### 5.3 La matriz

```java
@Component
public class ExperimentMatrix {

    private static final int[] CHUNKS      = {10, 50, 100, 500};
    private static final int[] PARALLELISM = {2, 4, 8};

    /** Fase 0 — baseline secuencial: aísla el efecto de chunkSize. */
    public List<ExperimentCase> build(String jobName, int datasetRows) {
        List<ExperimentCase> cases = new ArrayList<>();
        for (int c : CHUNKS) {
            cases.add(new ExperimentCase(jobName, ScalingStrategy.SEQUENTIAL, 1, c,
                                         datasetRows, "F0-baseline"));
        }
        return cases;
    }

    /** Fase 1 — requiere chunk* de la fase 0. */
    public List<ExperimentCase> buildPhase1(String jobName, int datasetRows, int bestChunk) {
        List<ExperimentCase> cases = new ArrayList<>();
        for (ScalingStrategy s : List.of(ScalingStrategy.MULTI_THREAD, ScalingStrategy.PARTITIONED)) {
            for (int p : PARALLELISM) {
                cases.add(new ExperimentCase(jobName, s, p, bestChunk, datasetRows, "F1-parallel"));
            }
        }
        return cases;
    }

    /** Fase 2 — confirmación cruzada: protege contra la crítica de no-interacción. */
    public List<ExperimentCase> buildPhase2(String jobName, int datasetRows,
                                            ScalingStrategy bestStrategy, int bestParallelism,
                                            int... chunksToRetest) {
        return Arrays.stream(chunksToRetest)
                .mapToObj(c -> new ExperimentCase(jobName, bestStrategy, bestParallelism, c,
                                                  datasetRows, "F2-confirm"))
                .toList();
    }
}
```

### 5.4 La factory de jobs (con el registry cableado — CORREGIDO)

```java
@Component
public class ExperimentJobFactory {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager txManager;
    private final ObservationRegistry observationRegistry;   // <-- imprescindible sin beans
    private final MeterRegistry meterRegistry;               // <-- imprescindible sin beans
    private final ReaderProvider readers;
    private final ProcessorProvider processors;
    private final WriterProvider writers;

    public Job build(ExperimentCase c) {
        return switch (c.strategy()) {
            case SEQUENTIAL   -> sequentialJob(c);
            case MULTI_THREAD -> multiThreadJob(c);
            case PARTITIONED  -> partitionedJob(c);
        };
    }

    /** Todos los jobs comparten este cableado de observabilidad. */
    private JobBuilder job(ExperimentCase c) {
        return new JobBuilder(c.jobName(), jobRepository)
                .observationRegistry(observationRegistry)
                .meterRegistry(meterRegistry)
                .listener(new JobTimingListener());
    }

    private StepBuilder step(String name) {
        return new StepBuilder(name, jobRepository)
                .observationRegistry(observationRegistry)
                .meterRegistry(meterRegistry);
    }

    private Job sequentialJob(ExperimentCase c) {
        Step s = step("step-" + c.label())
                .<TransaccionRaw, TransaccionEntity>chunk(c.chunkSize(), txManager)
                .reader(readers.wholeFile(c))
                .processor(processors.forJob(c.jobName()))
                .writer(writers.forJob(c.jobName()))
                .faultTolerant()
                .skipPolicy(new BancoXyzSkipPolicy())
                .retryPolicy(new BancoXyzRetryPolicy())   // org.springframework.retry.RetryPolicy
                .listener(new SkipAuditListener())
                .build();

        return job(c).start(s).build();
    }

    private Job multiThreadJob(ExperimentCase c) {
        // FlatFileItemReader NO es thread-safe -> sincronizarlo (y esto serializa la lectura)
        SynchronizedItemStreamReader<TransaccionRaw> safeReader = new SynchronizedItemStreamReader<>();
        safeReader.setDelegate(readers.wholeFile(c));

        Step s = step("step-" + c.label())
                .<TransaccionRaw, TransaccionEntity>chunk(c.chunkSize(), txManager)
                .reader(safeReader)
                .processor(processors.forJob(c.jobName()))
                .writer(writers.forJob(c.jobName()))
                .taskExecutor(TaskExecutors.fixedPool(c.parallelism()))
                .faultTolerant()
                .skipPolicy(new BancoXyzSkipPolicy())
                .build();

        return job(c).start(s).build();
    }

    private Job partitionedJob(ExperimentCase c) {
        // Cada partición abre su PROPIO reader sobre un rango disjunto: sin lock compartido.
        Step worker = step("worker-" + c.label())
                .<TransaccionRaw, TransaccionEntity>chunk(c.chunkSize(), txManager)
                .reader(readers.rangeAware(c))       // @StepScope o delegate con ExecutionContext
                .processor(processors.forJob(c.jobName()))
                .writer(writers.forJob(c.jobName()))
                .faultTolerant()
                .skipPolicy(new BancoXyzSkipPolicy())
                .build();

        Step manager = step("manager-" + c.label())   // <-- el manager TAMBIÉN necesita el registry
                .partitioner(worker.getName(), partitionerFor(c))
                .step(worker)
                .gridSize(c.parallelism())
                .taskExecutor(TaskExecutors.fixedPool(c.parallelism()))
                .build();

        return job(c).start(manager).build();
    }

    private Partitioner partitionerFor(ExperimentCase c) {
        return switch (c.jobName()) {
            // transacciones: id 1..N contiguo -> rangos perfectamente balanceados
            case "transaccionesJob"  -> new RangePartitioner(1, c.datasetRows());
            // intereses / cuentas anuales: por cuenta_id (cardinalidad 50 y 20)
            case "interesesJob"      -> new CuentaIdPartitioner(101, 150);
            case "cuentasAnualesJob" -> new CuentaIdPartitioner(101, 120);
            default -> throw new IllegalArgumentException("job desconocido: " + c.jobName());
        };
    }
}
```

`RangePartitioner` implementa la interfaz (firma verificada en 5.2.x):
```java
public interface Partitioner { Map<String, ExecutionContext> partition(int gridSize); }
```
y pone `minValue`/`maxValue` en cada `ExecutionContext`; el reader de la partición los lee vía late binding `@Value("#{stepExecutionContext['minValue']}")`.

### 5.5 El runner

```java
@Component
@Profile("experiment")   // no se activa en ejecución normal
public class ScalingExperimentRunner implements CommandLineRunner {

    private static final int WARMUP_RUNS   = 2;
    private static final int MEASURED_RUNS = 5;

    private final JobLauncher jobLauncher;
    private final ExperimentJobFactory jobFactory;
    private final ExperimentMatrix matrix;
    private final ExperimentResultWriter csv;
    private final DatabaseResetter resetter;
    private final EnvironmentProbe env;
    private final MicrometerSnapshotReader meters;

    @Override
    public void run(String... args) throws Exception {
        List<ExperimentResult> all = new ArrayList<>();
        List<ExperimentCase> cases = matrix.build("transaccionesJob", 100_000);

        // Por RONDAS, no por caso: reparte la deriva del entorno entre todas las celdas.
        int totalRounds = WARMUP_RUNS + MEASURED_RUNS;
        for (int round = 0; round < totalRounds; round++) {
            List<ExperimentCase> shuffled = new ArrayList<>(cases);
            Collections.shuffle(shuffled, new Random(42 + round));  // semilla fija = reproducible
            boolean isWarmup = round < WARMUP_RUNS;
            for (ExperimentCase c : shuffled) {
                all.add(executeOnce(c, round, isWarmup));
            }
        }
        csv.write(Path.of("results/scaling-results.csv"), all);
    }

    private ExperimentResult executeOnce(ExperimentCase c, int repetition, boolean warmup)
            throws Exception {

        resetter.truncateBusinessTables();   // FUERA del cronómetro
        meters.clearBatchMeters();           // los Timer son acumulativos
        System.gc();                         // sugerencia; ver nota abajo
        Thread.sleep(200);                   // deja asentar GC/IO antes de cronometrar

        Job job = jobFactory.build(c);

        // Todos los parámetros son identificantes -> cada celda es un JobInstance distinto
        // y la configuración queda persistida en BATCH_JOB_EXECUTION_PARAMS.
        JobParameters params = new JobParametersBuilder()
                .addString("strategy",   c.strategy().name())
                .addLong("parallelism",  (long) c.parallelism())
                .addLong("chunkSize",    (long) c.chunkSize())
                .addLong("datasetRows",  (long) c.datasetRows())
                .addLong("repetition",   (long) repetition)
                .addString("phase",      c.phase())
                .addLong("runId",        System.currentTimeMillis())  // garantiza unicidad
                .toJobParameters();

        long t0 = System.nanoTime();
        JobExecution exec = jobLauncher.run(job, params);
        long wallClock = System.nanoTime() - t0;

        return ExperimentResultMapper.from(c, repetition, warmup, wallClock, exec, env);
    }
}
```

Notas de honestidad sobre el runner:

- **`runId` con timestamp es obligatorio.** Sin un parámetro identificante único, la segunda ejecución de la misma celda lanza `JobInstanceAlreadyCompleteException`. La alternativa idiomática es `RunIdIncrementer` (`JobBuilder.incrementer(new RunIdIncrementer())` + `jobOperator.startNextInstance(...)`), pero con timestamp explícito el runner es más simple y el parámetro queda legible en la BD.
- **`System.gc()` es una *sugerencia*, no una orden.** Javadoc verbatim: *"There is no guarantee that this effort will recycle any particular number of unused objects, reclaim any particular amount of space, or complete at any particular time, if at all."* Lo incluyo porque reduce la probabilidad de que una pausa de GC pendiente caiga en la ventana medida, pero **no lo presentes como control riguroso**. El control riguroso es la mediana sobre 5 repeticiones + heap fijo.
- **`Thread.sleep(200)`**: deja que el flush de disco del `TRUNCATE` termine antes de arrancar el cronómetro.
- **Los jobs de este runner no son beans**, así que Boot no intentará lanzarlos al arranque. Si además tuvieras algún `Job` como bean en el contexto, añade `spring.batch.job.enabled=false` al perfil `experiment` para que `JobLauncherApplicationRunner` no te ejecute nada por su cuenta.

### 5.6 Captura del entorno

```java
@Component
public class EnvironmentProbe {
    public int    processors()   { return Runtime.getRuntime().availableProcessors(); }
    public long   maxHeap()      { return Runtime.getRuntime().maxMemory(); }
    public String javaVersion()  { return System.getProperty("java.version"); }
    public String osName()       { return System.getProperty("os.name"); }
    // + hikariPoolSize inyectado desde HikariDataSource.getMaximumPoolSize()
}
```

Estos datos van **en cada fila del CSV**, no en un pie de página. Si el evaluador reproduce en otra máquina, la comparación sigue siendo interpretable.

### 5.7 Ruta alternativa: reconstruir resultados desde las tablas de metadatos

Como los `JobParameters` son identificantes y quedan persistidos, puedes generar la tabla de resultados con SQL puro — útil como verificación cruzada del CSV (si coinciden, tus mediciones son sólidas):

```sql
SELECT
    MAX(CASE WHEN p.PARAMETER_NAME='strategy'    THEN p.PARAMETER_VALUE END) AS strategy,
    MAX(CASE WHEN p.PARAMETER_NAME='parallelism' THEN p.PARAMETER_VALUE END) AS parallelism,
    MAX(CASE WHEN p.PARAMETER_NAME='chunkSize'   THEN p.PARAMETER_VALUE END) AS chunk_size,
    e.JOB_EXECUTION_ID,
    EXTRACT(EPOCH FROM (e.END_TIME - e.START_TIME)) * 1000 AS millis,
    e.STATUS
FROM BATCH_JOB_EXECUTION e
JOIN BATCH_JOB_EXECUTION_PARAMS p ON p.JOB_EXECUTION_ID = e.JOB_EXECUTION_ID
GROUP BY e.JOB_EXECUTION_ID, e.END_TIME, e.START_TIME, e.STATUS
ORDER BY strategy, parallelism, chunk_size;
```

**✅ Confirmado:** los nombres de columna de `BATCH_JOB_EXECUTION_PARAMS` **cambiaron en Spring Batch 5**. En 4.x eran `KEY_NAME`, `STRING_VAL`, `LONG_VAL`, `DATE_VAL`, `DOUBLE_VAL`, `TYPE_CD`; en **5.x son `PARAMETER_NAME`, `PARAMETER_TYPE`, `PARAMETER_VALUE`, `IDENTIFYING`**. La consulta de arriba es la correcta para 5.2. Puedes contrastarla con el DDL real de tu versión: `org/springframework/batch/core/schema-postgresql.sql` dentro del jar `spring-batch-core`.

`EXTRACT(EPOCH ...)` es sintaxis PostgreSQL; en MySQL sería `TIMESTAMPDIFF(MICROSECOND, START_TIME, END_TIME)/1000`.

---

## 6. Presentación de resultados

### 6.1 Tabla comparativa (la que va en el README)

Una fila por celda, con estadística de dispersión. Sin dispersión, la tabla no prueba nada.

> **⚠ REGLA DE ORO — declara UNA base de speedup y úsala en todas partes.**
> Es el error aritmético más fácil de cometer y el más fácil de detectar por un evaluador. Aquí la base es **el mejor secuencial (chunk=500, 8.870 ms)**, declarada en la leyenda y aplicada a **todas** las filas.

| Estrategia | Paralelismo | Chunk | n filas | Mediana (ms) | P25–P75 | CV % | Speedup¹ | Throughput (it/s) | Commits | Skew |
|---|---|---|---|---|---|---|---|---|---|---|
| Secuencial | 1 | 10 | 100.000 | 18.420 | 18,1k–18,9k | 2,1 % | 0,48× | 5.429 | 10.000 | — |
| Secuencial | 1 | 100 | 100.000 | 9.310 | 9,2k–9,5k | 1,4 % | 0,95× | 10.741 | 1.000 | — |
| **Secuencial** | **1** | **500** | 100.000 | **8.870** | 8,7k–9,1k | 1,8 % | **1,00× (base)** | 11.274 | 200 | — |
| Multi-thread | 4 | 100 | 100.000 | 6.240 | 6,0k–6,8k | 5,3 % | 1,42× | 16.026 | 1.000 | — |
| **Partición** | **4** | **100** | 100.000 | **4.120** | 4,0k–4,3k | 3,2 % | **2,15×** | 24.272 | 1.000 | 1,08 |
| Partición | 8 | 100 | 100.000 | 4.050 | 3,9k–4,9k | 11,4 % | 2,19× | 24.691 | 1.000 | 1,31 |

¹ *Speedup respecto del mejor secuencial (chunk=500, 8.870 ms).*
*(cifras ilustrativas — sustituir íntegramente por las tuyas)*

Dos columnas hacen todo el trabajo argumentativo:
- **CV %**: cuando salta de 3 % a 11 % al pasar de 4 a 8 hilos, tienes **evidencia** de contención, no una intuición.
- **Speedup**: con base explícita. Si además quieres mostrar el efecto aislado de `chunkSize`, hazlo en una **columna aparte** con su propia base declarada (p. ej. "18.420 ms → 8.870 ms = 2,08× por efecto de chunk"). Mezclar dos bases en una sola columna es exactamente cómo se inflan números sin querer.

### 6.2 Gráficos (3, no más)

1. **Throughput (ítems/s) vs. paralelismo**, una línea por `chunkSize`. Muestra el **punto de saturación** (donde la línea se aplana o cae).
2. **Speedup vs. paralelismo**, con dos referencias superpuestas: la recta ideal `S(n)=n` y la curva de Amdahl ajustada. La distancia entre tu curva y la recta ideal **es** el coste de coordinación, visualmente.
3. **Boxplot de duración por configuración.** Éste es el gráfico de honestidad: si las cajas de "secuencial" y "partición gridSize=2" se solapan a escala 1k, el gráfico **dice** que no hay diferencia y tu texto puede afirmarlo sin rodeos.

Genera los gráficos desde el CSV con matplotlib o similar; incluye el script en el repo. Sin escalas logarítmicas artificiales, y con el eje Y **empezando en cero** para las barras — un eje truncado convierte un 3 % de mejora en una montaña, y es la manipulación visual más común.

### 6.3 Conclusión técnica esperada

La rúbrica premia el *razonamiento*, no el número.

**(a) Óptimo identificado, con condiciones.**
> *"La configuración óptima para el Job 1 a escala 100k es particionado con gridSize=4 y chunkSize=100 (mediana 4.120 ms, **2,15× sobre el mejor secuencial**, que es chunk=500 con 8.870 ms). El óptimo depende del hardware: 4 particiones sobre 4 núcleos físicos disponibles."*

**(b) Punto de saturación y su causa.**
> *"Entre gridSize=4 y gridSize=8 la mejora es de solo 1,7 % mientras el CV se multiplica por 3,5 (3,2 % → 11,4 %). Con 4 núcleos, 8 particiones no aportan paralelismo real y sí añaden cambio de contexto, presión sobre el pool de conexiones y desbalance (skew 1,08 → 1,31). El punto de saturación coincide con el número de núcleos."*

**(c) Ley de Amdahl, con p estimado de TUS datos.**
Despejando p desde un speedup medido:

$$p = \frac{n\,(S-1)}{S\,(n-1)}$$

> *"Con S(4)=2,15 obtenemos p ≈ 0,71: aproximadamente el 71 % del trabajo es paralelizable y un 29 % es irreductiblemente secuencial (creación del `JobExecution`, arranque del `PartitionStep`, agregación de exit status, `UPDATE` final de metadatos). El techo teórico es S(∞)=1/0,29 ≈ 3,5×, coherente con la saturación observada."*

**(d) Por qué partición > multi-thread — la explicación causal.**
> *"El multi-thread queda un 51 % por detrás (6.240 vs 4.120 ms) porque `FlatFileItemReader` no es thread-safe —su superclase `AbstractItemCountingItemStreamItemReader` lo declara literalmente en el javadoc— y debe envolverse en `SynchronizedItemStreamReader`, que serializa `read()` con un `ReentrantLock`. La lectura pasa así a la fracción secuencial de Amdahl. La partición evita ese lock: cada partición instancia su propio reader sobre un rango disjunto del archivo. A esto se suma que en multi-thread los N hilos actualizan la MISMA fila de `BATCH_STEP_EXECUTION` en cada commit de chunk, generando contención de bloqueo optimista sobre la columna `VERSION`, mientras que en partición cada worker tiene su propia fila."*

**(e) Coste de contención en BD, medido.**
> *"La variante con writer no-op ejecuta en 2.310 ms frente a 4.120 ms con escritura real: el 44 % del tiempo es E/S de base de datos. Elevar el paralelismo por encima de `maximumPoolSize` no puede mejorar ese 44 %; solo desplaza la espera del cálculo al pool."*

**(f) Efecto de chunkSize, explicado con `commitCount`.**
> *"chunkSize=10 duplica el tiempo del secuencial frente a chunkSize=100 (18.420 vs 9.310 ms). `getCommitCount()` lo explica: 10.000 commits vs 1.000. Cada commit implica una transacción de negocio más un `UPDATE` a `BATCH_STEP_EXECUTION`. Entre 100 y 500 la mejora se agota (4,7 %): el coste por commit ya no domina y aparece el coste de memoria por mantener 500 ítems en el buffer del chunk. Nota de riesgo: un chunk grande implica que un fallo revierte más trabajo y, con `faultTolerant`, dispara un reprocesamiento ítem-a-ítem más costoso —que además infla `commitCount` por encima de `items/chunkSize`—. Hay una tensión real entre rendimiento y coste de recuperación."*

**(g) El resultado a escala real — la parte que demuestra criterio.**
> *"A la escala del dataset entregado (1.000 filas), ninguna configuración paralela supera al secuencial de forma estadísticamente distinguible: los rangos intercuartílicos se solapan y el particionado con gridSize=8 es un 12 % MÁS LENTO por el coste de crear el pool y las particiones. El paralelismo solo empieza a compensar a partir de aproximadamente N filas. Recomendación operativa: mantener el job secuencial para el volumen diario actual y activar particionado por configuración cuando el volumen crezca — la implementación soporta ambos modos vía `JobParameters`."*

Ese último párrafo distingue un trabajo que *implementó* particiones de uno que *entendió* cuándo usarlas.

**(h) Contrapunto de Gustafson (una frase, opcional).**
> *"Amdahl asume problema de tamaño fijo. La ley de Gustafson señala que en batch el tamaño del problema crece con los recursos disponibles; por eso la conclusión relevante para el banco no es el speedup a volumen fijo, sino la capacidad de absorber crecimiento de volumen sin exceder la ventana nocturna de procesamiento."*

---

## 7. Amenazas a la validez (sección corta, gran retorno)

Media página. Es lo que un evaluador con criterio busca y casi nadie escribe.

1. **Máquina no dedicada.** Mediciones en portátil con SO, navegador y Docker activos. Mitigación: mediana sobre 5 repeticiones, orden aleatorizado por rondas, reporte de CV.
2. **BD co-localizada.** PostgreSQL en Docker compite por CPU con la JVM; con paralelismo alto la contención es entre procesos, no solo intra-JVM.
3. **Warm-up de JVM.** Descartadas 2 rondas; el CSV crudo las conserva marcadas para auditoría.
4. **Sesgo del observador.** Métricas por ítem de Micrometer (`spring.batch.item.*`) desactivadas en la matriz oficial por su overhead; documentado, con el `MeterFilter` exacto en el repo.
5. **Instrumentación no trivial.** Los `Job`/`Step` se construyen imperativamente, fuera del ciclo de beans, por lo que hubo que inyectar `ObservationRegistry` explícitamente en cada builder; sin eso las métricas de job/step habrían quedado en NOOP sin ningún error visible. Se verificó su presencia con `GET /actuator/metrics` antes de lanzar la matriz.
6. **Escalado térmico / turbo boost.** Corridas largas pueden reducir la frecuencia del CPU. La aleatorización por rondas reparte el efecto; no lo elimina.
7. **Dataset sintético a escala 100k.** Réplica del original: distribución de defectos preservada, pero **la cardinalidad de `cuenta_id` no crece**, lo que limita el particionado por cuenta a 50/20 particiones y mantiene el skew original. Un dataset real de 100k tendría más cuentas y probablemente mejor balance — es decir, **nuestros resultados de particionado por cuenta son conservadores**.
8. **Una sola máquina.** Los óptimos (`gridSize=4`, `chunk=100`) son específicos de esta configuración de hardware y pool; no se generalizan.

---

## 8. Recomendación de estrategia por Job

| Job | Estrategia | Clave de partición | Razón dominante |
|---|---|---|---|
| 1 — Transacciones diarias | Partición (o multi-thread) | Rango de `id` (1..N, contiguo, sin duplicados) | Sin estado compartido entre filas → ambas son correctas; la partición gana por rendimiento (sin lock de lectura) y por balance perfecto (skew = 1,00) |
| 2 — Intereses mensuales | **Partición, obligatoriamente** | `cuenta_id` (101..150, 50 cuentas) | **Corrección, no rendimiento**: hay 12–33 filas por cuenta y el job actualiza el saldo. Multi-thread permitiría dos hilos actualizando la misma cuenta → lost update / deadlock. Particionar por cuenta garantiza afinidad hilo↔cuenta. Skew 1,65 |
| 3 — Estados de cuenta anuales | Partición | `cuenta_id` (101..120, 20 cuentas) | El consolidado es por cuenta: la agregación debe ocurrir dentro de una partición. Cardinalidad 20 acota el `gridSize` útil. Skew 1,20 |

Documentar el caso del Job 2 explícitamente (*"elegí partición aquí por una razón de corrección concurrente, no de velocidad"*) es probablemente el párrafo de mayor densidad de puntos de todo el informe.

---

## 9. Checklist de entrega para el criterio 4 (15 pts)

- [ ] Al menos 2 estrategias implementadas y ejecutables (secuencial + partición como mínimo; ideal: + multi-thread)
- [ ] Al menos 2 parámetros barridos (`chunkSize` **y** `gridSize`/threads)
- [ ] ≥ 5 repeticiones medidas por celda, con warm-up descartado y **declarado**
- [ ] CSV crudo versionado (`results/scaling-results.csv`), con los warm-ups incluidos y marcados
- [ ] Tabla comparativa con mediana + dispersión (IQR o CV), no solo la media
- [ ] **Una sola base de speedup, declarada en la leyenda y aplicada a todas las filas**
- [ ] Al menos 1 gráfico (idealmente 3: throughput, speedup vs. ideal, boxplot), eje Y desde cero
- [ ] Configuración óptima **declarada explícitamente** con sus condiciones (hardware, tamaño de dataset, pool)
- [ ] Explicación causal del punto de saturación (no solo "a partir de 4 no mejora")
- [ ] Amdahl aplicada con p **calculado de tus datos**, no citada en abstracto
- [ ] Entorno documentado: núcleos, heap, versión de JVM, BD, `maximumPoolSize`
- [ ] Runner versionado y ejecutable con un comando (`--spring.profiles.active=experiment`)
- [ ] **Salida de `GET /actuator/metrics` pegada en el informe**, probando qué métricas y tags existen en tu build
- [ ] Si amplificaste el dataset: generador versionado, determinista, CSV originales intactos, y el hecho declarado en el README

---

## 10. URLs oficiales (todas verificadas)

**Spring Batch — referencia**
- Monitoring and metrics (5.2) — ⚠ *tabla de tags desactualizada, ver §2*: https://docs.spring.io/spring-batch/reference/5.2/monitoring-and-metrics.html
- Micrometer support (6.0, requiere `ObservationRegistry`): https://docs.spring.io/spring-batch/reference/spring-batch-observability/micrometer.html
- Scalability (multi-thread, particiones, `throttleLimit`, thread-safety): https://docs.spring.io/spring-batch/reference/5.2/scalability.html
- Item reader/writer implementations: https://docs.spring.io/spring-batch/reference/readers-and-writers/item-reader-writer-implementations.html
- Guía de migración a 6.0: https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide

**Spring Batch — javadoc** (nota: `docs/current/api` sirve hoy **5.2.6**, no 6.0; se recomienda fijar a `docs/5.2.x/api`)
- `JobExecution` (`getStartTime()` → `LocalDateTime`): https://docs.spring.io/spring-batch/docs/5.2.x/api/org/springframework/batch/core/JobExecution.html
- `StepExecution` (getters `long`): https://docs.spring.io/spring-batch/docs/5.2.x/api/org/springframework/batch/core/StepExecution.html
- `BatchMetrics` (*"Only intended for internal use."*): https://docs.spring.io/spring-batch/docs/5.2.x/api/org/springframework/batch/core/observability/BatchMetrics.html
- `SynchronizedItemStreamReader`: https://docs.spring.io/spring-batch/docs/5.2.x/api/org/springframework/batch/item/support/SynchronizedItemStreamReader.html

**Spring Batch — código fuente (la fuente de verdad para los tags)**
- `SimpleChunkProvider` (tags de `item.read`): https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/item/SimpleChunkProvider.java#L156-L163
- `SimpleChunkProcessor` (tags de `item.process` / `chunk.write`): https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/step/item/SimpleChunkProcessor.java#L349-L357
- `BatchJobObservation` / `DefaultBatchJobObservationConvention`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/observability/
- `AbstractJob` (orden `setEndTime` / `afterJob`; `job.active`): https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/job/AbstractJob.java
- `BatchObservabilityBeanPostProcessor`: https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/configuration/annotation/BatchObservabilityBeanPostProcessor.java
- `TaskExecutorJobLauncher` (`job.launch.count`): https://github.com/spring-projects/spring-batch/blob/5.2.x/spring-batch-core/src/main/java/org/springframework/batch/core/launch/support/TaskExecutorJobLauncher.java#L233
- Issue #4753 (`spring.batch.job.active` duplicado): https://github.com/spring-projects/spring-batch/issues/4753

**Spring Boot**
- Actuator — Metrics: https://docs.spring.io/spring-boot/reference/actuator/metrics.html
- `BatchAutoConfiguration` (URL corregida, 3.5): https://docs.spring.io/spring-boot/3.5/api/java/org/springframework/boot/autoconfigure/batch/BatchAutoConfiguration.html
- `JobLauncherApplicationRunner` (**NO deprecado**; solo su método `validate()` lo está, desde 3.0.10): https://docs.spring.io/spring-boot/3.5/api/java/org/springframework/boot/autoconfigure/batch/JobLauncherApplicationRunner.html

**Spring Framework**
- `SimpleAsyncTaskExecutor` (*"does not reuse threads!"*): https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/core/task/SimpleAsyncTaskExecutor.html

**Micrometer**
- Concepts / Timer: https://docs.micrometer.io/micrometer/reference/concepts.html
- MeterFilter: https://docs.micrometer.io/micrometer/reference/concepts/meter-filters.html

**Otros**
- HikariCP — About Pool Sizing: https://github.com/brettwooldridge/HikariCP/wiki/About-Pool-Sizing
- OpenJDK JMH (citar como metodología, no usar como runner): https://github.com/openjdk/jmh
- `System.nanoTime()` javadoc: https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/System.html#nanoTime()

---

## 11. Puntos que quedan genuinamente por verificar (los 5 que sobreviven de los 7 originales)

Dos de los siete puntos "inciertos" del informe original quedaron **resueltos** (el orden `setEndTime`/`afterJob` está confirmado por código; `spring.batch.job.launch.count` **sí** existe en 5.2). Quedan estos:

1. **`@JobScope` sobre un bean `Step` para `chunkSize` dinámico.** Patrón usado en la práctica, no verificado aquí. Por eso el diseño usa una factory imperativa, que no depende de ello — a costa de tener que cablear el `ObservationRegistry` a mano (§5.4).
2. **Cifras de la tabla de §6.1 y del punto de saturación.** Son **ilustrativas**, para mostrar el formato y el tipo de razonamiento. Sustitúyelas íntegramente por tus mediciones. **No las cites como si fueran datos.**
3. **`p ≈ 0,71`, "44 % del tiempo es E/S", "51 % de diferencia multi-thread vs partición".** Todas ilustrativas. Las direcciones cualitativas (partición ≥ multi-thread con readers de archivo; saturación cerca del nº de núcleos; chunk pequeño penalizado por `commitCount`) son predicciones razonadas y **muy probables**, pero deben confirmarse con tus datos. Si tus mediciones contradicen alguna, **repórtalo así** — un resultado inesperado bien documentado vale más que uno esperado y maquillado.
4. **Hardware del evaluador.** Si corre tu matriz de 100k en otra máquina, los óptimos cambiarán. Por eso el CSV lleva `availableProcessors` y `hikariPoolSize` en cada fila.
5. **Comportamiento exacto del tag `status` en `spring.batch.step.active`.** El `LongTaskTimer` lo abre Micrometer al *inicio* de la observación, cuando el exit code aún no es definitivo (típicamente `UNKNOWN`/`EXECUTING`). No lo uses para filtrar por resultado; para eso está `spring.batch.step`.

**Sources:**
- [Spring Batch 6.0 Migration Guide](https://github.com/spring-projects/spring-batch/wiki/Spring-Batch-6.0-Migration-Guide)
- [Monitoring and metrics — Spring Batch 5.2](https://docs.spring.io/spring-batch/reference/5.2/monitoring-and-metrics.html)
- [Scalability — Spring Batch 5.2](https://docs.spring.io/spring-batch/reference/5.2/scalability.html)
- [Micrometer support — Spring Batch 6.0](https://docs.spring.io/spring-batch/reference/spring-batch-observability/micrometer.html)
- [Spring Batch issue #4753](https://github.com/spring-projects/spring-batch/issues/4753)
- [Spring Batch 5.2.x source](https://github.com/spring-projects/spring-batch/tree/5.2.x)
- [Spring Boot Actuator Metrics](https://docs.spring.io/spring-boot/reference/actuator/metrics.html)
- [JobLauncherApplicationRunner javadoc (Boot 3.5)](https://docs.spring.io/spring-boot/3.5/api/java/org/springframework/boot/autoconfigure/batch/JobLauncherApplicationRunner.html)
- [System javadoc (Java 17)](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/System.html)
- [SimpleAsyncTaskExecutor javadoc](https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/core/task/SimpleAsyncTaskExecutor.html)