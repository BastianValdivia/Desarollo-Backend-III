# MAPEO EXHAUSTIVO: RÚBRICA → ENTREGABLE → EVIDENCIA
## Banco XYZ · Exp1 S3 · Desarrollo Backend III (PBY2203)

---

## 0. DECISIONES DE BASE (fijar antes de escribir una línea de código)

Estas decisiones atraviesan los 7 criterios. Si cambias una, cambia el mapeo entero.

| Decisión | Valor fijado | Justificación (va al README, suma en criterio 6) |
|---|---|---|
| Stack | **Spring Boot 3.5.16 + Spring Batch 5.2.6 + Java 21** | La guía de la semana habla de `PartitionHandler`, `setGridSize`, `RetryPolicy`/`BackOffPolicy`/`SkipPolicy`: vocabulario de Batch 5. En Batch 6 esas clases se renombraron y `noRollback()`/`backOffPolicy()` desaparecen. **Declarar en el README que Boot 3.5.16 es el último release OSS de esa rama (25-jun-2026) y que la elección es pedagógica, no de vigencia.** Ese párrafo convierte una debilidad en evidencia de criterio. |
| BD | **PostgreSQL 17 en Docker Compose**, 1 datasource, 2 esquemas: `banco` (negocio) + `batch_meta` (`BATCH_*`) | Un solo datasource ⇒ el commit del chunk y el update del `StepExecution` van en la **misma transacción**. Con dos datasources se rompe la atomicidad y en un crash puedes duplicar un chunk. |
| Writer | **`JdbcBatchItemWriter` + `.beanMapped()`** en los 3 jobs | 1 `executeBatch()` por chunk, thread-safe documentado, SQL nativo Postgres (`ON CONFLICT`), y `assertUpdates` como detector de "0 filas afectadas". |
| Escalado | **Particiones** como estrategia principal; multi-thread implementado sólo como **brazo de comparación** | El enunciado dice "particiones **O** multi-thread"; implementar ambas y comparar es exactamente lo que pide el criterio 4. Y en el Job 2 la partición es un requisito de **corrección**, no de velocidad (ver §5). |
| Modelo de lectura | El reader lee **todo como `String`** (`TransaccionRaw`, `InteresRaw`, `MovimientoRaw`) | Si tipas en el reader, `FlatFileItemReader` lanza `FlatFileParseException` antes de que tu `ItemProcessor` pueda **reparar** la fecha o el tipo. Perderías filas reparables ⇒ hundes criterios 2 y 3 de un golpe. |
| Regla de oro | **Ninguna fila desaparece en silencio: entrada = negocio + rechazos.** | Es la defensa literal del criterio 2 ("procesando TODOS los datos"). |

### 0.1 Regla de precedencia de validación (define los números esperados)

Sin esta regla, la cuadratura no cierra y no puedes declarar la "salida esperada".

```
1. FECHA_INVALIDA      (rechazo)   ← se evalúa primero
2. MONTO_AUSENTE / SALDO_AUSENTE (rechazo)
3. DUPLICADO           (rechazo, sólo intereses.csv)
4. ANOMALA_TIPO_DESCONOCIDO   (se guarda marcada)
5. ANOMALA_MONTO_NEGATIVO     (se guarda marcada)
6. ANOMALA_MONTO_CERO         (se guarda marcada)
7. ANOMALA_EDAD_FUERA_RANGO   (se guarda marcada)
8. VALIDA
```

Aplicada a `transacciones.csv` da el reparto ya verificado en `docs/analisis-datos.md`:

```
VALIDA 401 | ANOMALA_TIPO_DESCONOCIDO 230 | RECHAZADA_MONTO_AUSENTE 160
ANOMALA_MONTO_NEGATIVO 136 | RECHAZADA_FECHA_INVALIDA 55 | ANOMALA_MONTO_CERO 18
TOTAL = 1000
```

> **Acción obligatoria antes de codificar:** corre el mismo conteo con esta precedencia sobre `intereses.csv` y `cuentas_anuales.csv` (script `scripts/perfilar-dataset.sh`) y **escribe los tres repartos esperados en el README**. Eso es lo que el evaluador contrasta contra la BD en el criterio 2. Sin números esperados publicados, "la salida esperada" es opinable.

---

# CRITERIO 1 — Arquitectura Spring Batch (15 pts)

> *Descriptor 80%: "Baja a 12 con **1 error de estructura o componente omitido**"*

## 1a) Qué construir exactamente

**3 Jobs, 14 Steps.** La trampa está en el número de steps: un Job = 1 step es "componente omitido" garantizado, porque el enunciado pide explícitamente *detectar anomalías **+ generar resumen***, *actualizar saldo **en BD***, y *compilar consolidado **para auditoría***. Cada uno de esos verbos es un step.

### Job 1 — `jobTransaccionesDiarias`
| Step | Tipo | Clase de configuración | Salida |
|---|---|---|---|
| `stepPrepararTransacciones` | Tasklet, `allowStartIfComplete(true)` | `LimpiezaTasklet` | limpia staging de la ejecución previa |
| `stepCargarTransaccionesManager` | **PartitionStep** | `Job1PartitionConfig` | orquesta N particiones |
| `stepCargarTransaccionesWorker` | chunk(200) fault-tolerant | `Job1StepConfig` | `banco.transaccion` + `banco.registro_rechazado` |
| `deciderCalidadDatos` | `JobExecutionDecider` | `DeciderCalidadDatos` | ramifica si tasa de rechazo > umbral |
| `stepAlertaCalidad` | Tasklet | `AlertaCalidadTasklet` | log + fila en `banco.control_carga` |
| `stepResumenDiario` | Tasklet SQL agregado | `ResumenDiarioTasklet` | `banco.resumen_diario` |
| `stepValidarCuadratura` | Tasklet | `CuadraturaTasklet` | `banco.control_carga`, falla el job si no cuadra |

### Job 2 — `jobInteresesMensuales`
`stepPrepararIntereses` → `stepCalcularInteresesManager` / `...Worker` (chunk 50, particionado por `cuenta_id` 101–150) → `stepConsolidarSaldos` (Tasklet: `INSERT…SELECT SUM…ON CONFLICT DO UPDATE`, **idempotente por `periodo_aplicado`**) → `stepValidarCuadratura`.

### Job 3 — `jobEstadosCuentaAnuales`
`stepPrepararAnuales` → `stepCargarMovimientosManager` / `...Worker` (chunk 200, particionado por `cuenta_id` 101–120) → `stepGenerarEstadosCuenta` (Tasklet SQL agregado) → `stepExportarEstadosCuenta` (chunk `JdbcCursorItemReader` → `FlatFileItemWriter`, el "informe para auditorías" literal) → `stepValidarCuadratura`.

### Componentes por nombre propio que el evaluador debe poder señalar

| Componente Spring Batch | Clase(s) en el proyecto |
|---|---|
| `Job` × 3 | `Job1TransaccionesConfig`, `Job2InteresesConfig`, `Job3AnualesConfig` |
| `Step` chunk × 4 | los tres workers + `stepExportarEstadosCuenta` |
| `Step` tasklet × 10 | `LimpiezaTasklet`, `ResumenDiarioTasklet`, `ConsolidarSaldosTasklet`, `GenerarEstadosCuentaTasklet`, `CuadraturaTasklet`, `AlertaCalidadTasklet` |
| `ItemReader` | `ReadersConfig` → `FlatFileItemReader<*Raw>` `@StepScope` (uno por partición) + `JdbcCursorItemReader<EstadoCuentaAnual>` |
| `ItemProcessor` × 3 | `TransaccionProcessor`, `InteresProcessor`, `MovimientoAnualProcessor` |
| `ItemWriter` | `WritersConfig` → `ClassifierCompositeItemWriter` (válidos/rechazados) sobre `JdbcBatchItemWriter` |
| `Classifier` | `ResultadoClassifier` (⚠ `org.springframework.classify.Classifier`, **no** `…batch.classify`) |
| `Partitioner` × 2 | `RangoIdPartitioner` (Job 1), `RangoCuentaPartitioner implements Partitioner, PartitionNameProvider` (Jobs 2 y 3) |
| `PartitionHandler` | `TaskExecutorPartitionHandler` en `EscaladoConfig` |
| `TaskExecutor` | `TaskExecutorConfig#poolParticiones(int n)` → `ThreadPoolTaskExecutor` con `core==max` |
| `SkipPolicy` custom | `BancoXyzSkipPolicy` |
| `RetryPolicy` custom | `RetryPolicies#infraestructura()` → `SimpleRetryPolicy(3, mapa, traverseCauses=true)` |
| `BackOffPolicy` | `BackOffPolicies#exponencial()` |
| `SkipListener` | `DeadLetterSkipListener` (implementa además `StepExecutionListener`) |
| `StepExecutionListener` | `ResumenStepListener` |
| `JobExecutionListener` | `JobTimingListener` |
| `RetryListener` | `ReintentoRetryListener` |
| `ChunkListener` | `ChunkErrorListener` |
| `JobExecutionDecider` | `DeciderCalidadDatos` |
| `JobParametersIncrementer` | `FechaProcesoIncrementer` |
| `JobRepository` / `JobLauncher` | autoconfigurados por Boot sobre `batch_meta` |
| Lanzador | `LanzadorJobs implements CommandLineRunner` (`--job=<nombre>`), con `spring.batch.job.enabled=false` |

## 1b) La trampa (el "componente omitido")

**Las cuatro omisiones que el evaluador detecta en 30 segundos:**

1. **No hay step de resumen/consolidación.** El enunciado nombra "generar resumen" y "consolidado para auditoría". Si el Job 1 sólo carga transacciones, falta un componente. → `stepResumenDiario` y `stepGenerarEstadosCuenta` son obligatorios.
2. **No hay diagrama.** El criterio dice "arquitectura **estructurada**". Si el evaluador tiene que reconstruirla leyendo `@Bean`s, cualquier duda se resuelve en tu contra. → `docs/arquitectura.md` con un diagrama Mermaid de los 3 jobs y sus steps, más la tabla de componentes de arriba.
3. **Error de estructura clásico:** `@StepScope` o `@JobScope` sobre un bean `Step`. La doc oficial lo prohíbe literalmente: *"A `Step` bean should not be step-scoped **or job-scoped**"*. El scope va en el **reader/writer**, nunca en el Step.
4. **Error de estructura clásico #2:** el `Job` arranca con el **worker** en vez del **manager**. `new JobBuilder(...).start(managerStep)`, siempre.

**Bonus anti-error:** dos beans `Step` con el mismo `new StepBuilder("mismoNombre", …)` colisionan en `BATCH_STEP_EXECUTION`. Convención obligatoria: `step<Verbo><Dominio>[Manager|Worker]`, y **sin `/` ni `:`** en el nombre (a los workers Spring les añade el sufijo `:partitionN` y `STEP_NAME` es `VARCHAR(100)`).

## 1c) Evidencia a capturar

| Evidencia | Cómo se obtiene | Archivo |
|---|---|---|
| Diagrama de los 3 jobs con todos sus steps y el flujo condicional | Mermaid a mano | `docs/arquitectura.md` |
| Tabla componente-Spring-Batch → clase del proyecto | la de §1a | `README.md` §Estructura |
| Prueba de que los 14 steps existen y se ejecutan | `SELECT DISTINCT STEP_NAME FROM batch_meta.BATCH_STEP_EXECUTION ORDER BY 1;` | `evidencias/01-arquitectura/steps-registrados.txt` |
| Prueba de versión real del stack | `./mvnw dependency:tree -Dincludes=org.springframework.batch:*,org.springframework.boot:*` | `evidencias/01-arquitectura/dependency-tree.txt` |
| Prueba de que el `JobRepository` es JDBC y no in-memory | log de arranque + `\dt batch_meta.*` (6 tablas + 3 secuencias) | `evidencias/01-arquitectura/tablas-metadatos.txt` |

## 1d) Checklist binario

- [ ] Existen exactamente 3 beans `Job` con nombres `jobTransaccionesDiarias`, `jobInteresesMensuales`, `jobEstadosCuentaAnuales`
- [ ] Cada Job tiene ≥ 4 Steps y al menos 1 Step tasklet de consolidación/resumen
- [ ] Existe al menos un `PartitionStep` (manager) por Job, con su worker separado
- [ ] Ningún bean de tipo `Step` lleva `@StepScope` ni `@JobScope`
- [ ] Todos los `@Bean` de reader/writer que leen `#{stepExecutionContext[...]}` llevan `@StepScope`
- [ ] El tipo de retorno de esos `@Bean` es al menos `ItemStream` (ej. `FlatFileItemReader<T>`, no `ItemReader<T>`)
- [ ] Cada `Job` arranca con el **manager**, no con el worker
- [ ] No hay dos `StepBuilder` con el mismo nombre en todo el proyecto
- [ ] `docs/arquitectura.md` existe y contiene el diagrama de los 3 jobs
- [ ] `SELECT DISTINCT STEP_NAME FROM batch_meta.BATCH_STEP_EXECUTION` devuelve ≥ 14 nombres distintos (más los `:partitionN`)
- [ ] `mvn dependency:tree` muestra `spring-batch-core:5.2.6`
- [ ] Existen las 6 tablas `BATCH_*` en `batch_meta`

---

# CRITERIO 2 — Ejecución completa con salida EN LA BD (15 pts)

> *Descriptor 80%: "Baja a 12 si **uno o más datos procesados no cumplen la salida esperada**"*

## 2a) Qué construir

1. **Tablas de negocio pobladas de verdad** (DDL completo en §9): `banco.transaccion`, `banco.resumen_diario`, `banco.cuenta`, `banco.interes_calculado`, `banco.movimiento_anual`, `banco.estado_cuenta_anual`.
2. **`banco.registro_rechazado`** — dead letter único para los 3 jobs, con `archivo_origen`, `numero_linea`, `linea_cruda`, `motivo`, `campo`, `valor_crudo`, `fase`, `job_execution_id`.
3. **`CuadraturaTasklet`** — el componente que **te salva este criterio**: al final de cada job compara `filas_leidas` (del `StepExecution`) contra `COUNT(negocio) + COUNT(rechazados)` de esa ejecución, escribe el resultado en `banco.control_carga` y **hace fallar el job si no cuadra**.
4. **`banco.control_carga`** — una fila por (archivo, job_execution_id) con `filas_entrada`, `filas_negocio`, `filas_rechazadas`, `cuadra BOOLEAN`.
5. **Vistas de verificación** `banco.v_cuadratura`, `banco.v_distribucion_estados`.
6. **`scripts/consultas-sql/*.sql`** — las consultas que el evaluador puede correr él mismo.

## 2b) La trampa

**"Uno o más datos" = literalmente una fila.** Las cinco formas de perder filas sin notarlo:

| Fuga | Por qué ocurre | Antídoto |
|---|---|---|
| `ItemProcessor` devuelve `null` | filtra el ítem: no se escribe, **no cuenta como skip**, sólo incrementa `filterCount` y desaparece | **Prohibido devolver `null` sin escribir antes al dead letter.** Si filtras, el rechazo se persiste igual. |
| `FlatFileParseException` en el reader | tipaste el CSV en el reader; la fila muere antes del processor | leer todo como `String` (`*Raw`) |
| `INSERT … ON CONFLICT DO NOTHING` | el duplicado se traga sin dejar rastro | `assertUpdates(false)` **+** contar y registrar el conflicto explícitamente |
| `skipLimit` por defecto = **10** | con ~40 % de filas sucias el step muere en la fila ~11 y el evaluador ve `FAILED` | `skipPolicy(new BancoXyzSkipPolicy(...))` con límites reales |
| Rechazo escrito con `JdbcTemplate` dentro del chunk que luego hace rollback | el rechazo se pierde con la transacción | el `DeadLetterSkipListener` escribe **también** a CSV (no transaccional) o usa `PROPAGATION_REQUIRES_NEW` |

**Trampa de infraestructura que anula todo el criterio:** con PostgreSQL, `spring.batch.jdbc.initialize-schema` tiene default `embedded` ⇒ **no crea nada**. Hay que ponerlo en `always`. Y si usas `table-prefix: batch_meta.BATCH_` **sin** `?currentSchema=batch_meta` en la URL, el DDL crea las tablas en `public` y los DAO las buscan en `batch_meta` → `relation "batch_meta.batch_job_instance" does not exist` al arrancar.

## 2c) Evidencia a capturar (la consulta que cierra la discusión)

```sql
-- scripts/consultas-sql/01-cuadratura.sql
WITH e AS (SELECT 1000 AS filas_entrada)
SELECT 'transacciones.csv' AS archivo,
       (SELECT filas_entrada FROM e)                                   AS entrada,
       (SELECT COUNT(*) FROM banco.transaccion)                        AS en_negocio,
       (SELECT COUNT(*) FROM banco.registro_rechazado
         WHERE archivo_origen = 'transacciones.csv')                   AS rechazadas,
       (SELECT COUNT(*) FROM banco.transaccion)
     + (SELECT COUNT(*) FROM banco.registro_rechazado
         WHERE archivo_origen = 'transacciones.csv')                   AS suma,
       CASE WHEN (SELECT COUNT(*) FROM banco.transaccion)
               + (SELECT COUNT(*) FROM banco.registro_rechazado
                   WHERE archivo_origen='transacciones.csv') = 1000
            THEN 'OK ✔' ELSE 'DESCUADRE ✘' END                        AS veredicto
UNION ALL SELECT 'intereses.csv',      1000, (SELECT COUNT(*) FROM banco.interes_calculado), … 
UNION ALL SELECT 'cuentas_anuales.csv',1000, (SELECT COUNT(*) FROM banco.movimiento_anual), … ;
```

```sql
-- scripts/consultas-sql/02-distribucion-esperada.sql  (contrasta contra los números publicados)
SELECT estado, COUNT(*) AS real,
       CASE estado
         WHEN 'VALIDA' THEN 401 WHEN 'ANOMALA_TIPO_DESCONOCIDO' THEN 230
         WHEN 'ANOMALA_MONTO_NEGATIVO' THEN 136 WHEN 'ANOMALA_MONTO_CERO' THEN 18 END AS esperado
FROM banco.transaccion GROUP BY estado
UNION ALL
SELECT motivo, COUNT(*),
       CASE motivo WHEN 'MONTO_AUSENTE' THEN 160 WHEN 'FECHA_INVALIDA' THEN 55 END
FROM banco.registro_rechazado WHERE archivo_origen='transacciones.csv' GROUP BY motivo
ORDER BY 1;
```

```sql
-- scripts/consultas-sql/03-contadores-batch.sql  (la evidencia oficial de Spring Batch)
SELECT je.JOB_EXECUTION_ID, ji.JOB_NAME, se.STEP_NAME, se.STATUS,
       se.READ_COUNT, se.FILTER_COUNT, se.WRITE_COUNT,
       se.READ_SKIP_COUNT, se.PROCESS_SKIP_COUNT, se.WRITE_SKIP_COUNT,
       se.COMMIT_COUNT, se.ROLLBACK_COUNT,
       se.READ_COUNT - se.FILTER_COUNT - se.WRITE_COUNT AS descuadre_interno
FROM batch_meta.BATCH_STEP_EXECUTION se
JOIN batch_meta.BATCH_JOB_EXECUTION je USING (JOB_EXECUTION_ID)
JOIN batch_meta.BATCH_JOB_INSTANCE  ji USING (JOB_INSTANCE_ID)
ORDER BY je.JOB_EXECUTION_ID, se.STEP_EXECUTION_ID;
```

Y capturas: `SELECT * FROM banco.transaccion LIMIT 20;`, `banco.resumen_diario` (≈365 filas), `banco.cuenta` (50 filas, saldo antes/después), `banco.estado_cuenta_anual` (20 filas), `banco.registro_rechazado` con las 3 procedencias.

## 2d) Checklist binario

- [ ] `docker compose up -d && ./scripts/run-all.sh` deja los 3 jobs en `COMPLETED`
- [ ] `banco.transaccion` + rechazos de `transacciones.csv` = **1000** exactas
- [ ] `banco.interes_calculado` + rechazos de `intereses.csv` = **1000** exactas
- [ ] `banco.movimiento_anual` + rechazos de `cuentas_anuales.csv` = **1000** exactas
- [ ] La distribución por `estado` coincide **exactamente** con los números publicados en el README
- [ ] `banco.resumen_diario` tiene una fila por cada fecha distinta presente y `SUM(total_operaciones)` = filas de negocio del Job 1
- [ ] `banco.cuenta` tiene 50 filas (101..150) y ninguna con `saldo` = `saldo_inicial` salvo tipo desconocido
- [ ] `banco.estado_cuenta_anual` tiene 20 filas (101..120) y `SUM(n_movimientos)` = filas de `banco.movimiento_anual`
- [ ] `banco.registro_rechazado` no tiene ninguna fila con `linea_cruda IS NULL`
- [ ] `banco.control_carga.cuadra` = `true` en las 3 filas
- [ ] `READ_COUNT − FILTER_COUNT − WRITE_COUNT = 0` en todos los steps chunk (o la diferencia está justificada y documentada)
- [ ] Existe `scripts/consultas-sql/` con las 3 consultas y su salida capturada

---

# CRITERIO 3 — Transformaciones y validaciones en el `ItemProcessor` (15 pts)

> *Descriptor: "datos de entrada procesados correctamente y **resultados completos**"*

## 3a) Qué construir

**Los 3 processors, con la lógica dentro de ellos** (no en el reader, no en la BD):

| Clase | Transforma | Valida |
|---|---|---|
| `TransaccionProcessor` | fecha (4 formatos → `LocalDate`), `tipo` → canónico `CREDITO`/`DEBITO`/`DESCONOCIDO`, monto → `BigDecimal` | mes 13 → rechazo; monto vacío → rechazo; negativo/cero/tipo basura → marca de anomalía |
| `InteresProcessor` | `tipo` → `AHORRO`/`PRESTAMO`/`HIPOTECA`/`DESCONOCIDO`, `nombre` `Unknown`→`DESCONOCIDO`, cálculo del interés por tasa | saldo vacío → rechazo; duplicado exacto → rechazo; edad 100/150/vacía → `NULL` + anomalía |
| `MovimientoAnualProcessor` | fecha (4 formatos), `depósito`→`DEPOSITO` (Normalizer NFD), signo por tipo de transacción, `descripcion` vacía → `'SIN DESCRIPCION'` | monto vacío → rechazo; monto negativo en un `deposito` → anomalía de signo |

**Clases de soporte (una responsabilidad cada una, testeables solas):**
- `NormalizadorFecha` — prueba los 4 patrones en orden `yyyy-MM-dd`, `dd-MM-yyyy`, `dd/MM/yyyy`, `yyyy/MM/dd` y devuelve `Optional<FechaNormalizada(LocalDate, patronUsado)>`.
- `NormalizadorTexto` — `Normalizer.normalize(s, Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+","")` + `trim().toUpperCase()`.
- `NormalizadorMonto` — `String` → `Optional<BigDecimal>`, distinguiendo *vacío* de *no numérico*.
- `CalculadoraInteres` — `tasaMensual(TipoCuenta)` desde `PropiedadesBatch`, `interes = saldo × tasa` con `RoundingMode.HALF_UP`, escala 2.
- `ClasificadorAnomalias` — aplica la precedencia de §0.1 y devuelve `(EstadoRegistro, List<String> anomalias)`.
- `RegistroInvalidoException extends ValidationException` con `numeroLinea`, `campo`, `valorCrudo`, `motivo`.

**Contrato del processor (esto es lo que evita perder filas):**
```
process(raw):
  1. normaliza todo lo normalizable
  2. si es IRRECUPERABLE  -> lanza RegistroInvalidoException  (skip + dead letter)
  3. si es RECUPERABLE    -> devuelve la entidad con estado ANOMALA_* y anomalias
  4. si es limpia         -> devuelve la entidad con estado VALIDA
  NUNCA devuelve null sin haber persistido antes el rechazo
```

## 3b) La trampa

1. **Validar fuera del `ItemProcessor`.** Si tipas en el `FieldSetMapper`, si dejas que un `CHECK` de Postgres sea tu validador, o si usas un `ValidatingItemProcessor` genérico, el evaluador **no ve** transformaciones en el processor → el criterio baja. Además, validar en el writer dispara *chunk scanning*: con `chunk(200)` y 1 fila mala pagas **201 llamadas a `write()`** y 200 re-invocaciones del processor.
2. **"Resultados completos" ≠ "sólo lo limpio".** Un processor que devuelve `null` para las 371 filas con `tipo` inválido es técnicamente correcto y te cuesta el criterio 2 y el 3 a la vez. Esas filas se **marcan**, no se tiran.
3. **`ResolverStyle` de `DateTimeFormatter`.** El default `SMART` rechaza `2024-13-05` (bien) pero **acepta `2024-02-30` y lo convierte a `2024-02-29`** (silenciosamente). Si quieres rechazar también esas, necesitas patrón con `uuuu` + `.withResolverStyle(ResolverStyle.STRICT)`. Documentar cuál elegiste y por qué **es exactamente el detalle fino que sube este criterio a 15**.
4. **`beanMapped()` + `record` de Java no funciona.** `BeanPropertyItemSqlParameterSourceProvider` busca `getCuentaId()`, el record expone `cuentaId()`. Las entidades destino deben ser **clases con getters** (los `*Raw` de entrada sí pueden ser records).
5. **Estado mutable en el processor** (el `Set` para deduplicar los 9 duplicados) **no es thread-safe** bajo particiones/multi-thread. O `ConcurrentHashMap.newKeySet()`, o —mejor— constraint `UNIQUE` en BD + `skip(DuplicateKeyException.class)`.

## 3c) Evidencia a capturar

| Evidencia | Cómo |
|---|---|
| **Tests unitarios del processor**, uno por regla, con los valores reales del CSV | `NormalizadorFechaTest` (los 4 formatos + `2024-13-01` + `2024-02-30`), `TransaccionProcessorTest`, `InteresProcessorTest`, `MovimientoAnualProcessorTest` → `./mvnw test` con salida capturada |
| **Tabla antes/después** con 10 filas reales del CSV y su fila resultante en BD | `docs/transformaciones.md` |
| Prueba de normalización de tilde | `SELECT transaccion_original, transaccion, COUNT(*) FROM banco.movimiento_anual GROUP BY 1,2;` → debe mostrar `depósito`→`DEPOSITO` 52 filas y `deposito`→`DEPOSITO` 296 |
| Prueba de los 4 formatos de fecha reparados | `SELECT formato_fecha, COUNT(*) FROM banco.transaccion GROUP BY 1;` → 4 filas, suma = filas de negocio |
| Prueba de descripciones rellenadas | `SELECT COUNT(*) FROM banco.movimiento_anual WHERE descripcion='SIN DESCRIPCION';` ≈ 230 |
| Prueba de edad saneada | `SELECT edad_original, edad, COUNT(*) FROM banco.interes_calculado GROUP BY 1,2;` → `100`/`150`/`''` mapean a `NULL` |
| `filterCount` = 0 (nada se filtró en silencio) | consulta 03 del criterio 2 |

## 3d) Checklist binario

- [ ] Existen 3 clases `*Processor implements ItemProcessor<Raw, Entidad>`
- [ ] Ningún `ItemProcessor` devuelve `null` sin haber registrado el rechazo
- [ ] `NormalizadorFecha` prueba los 4 patrones en el orden documentado y devuelve el patrón usado
- [ ] Existe un test que verifica que `2024-13-01` es rechazada y que `24-07-2024` se lee como 24 de julio (no como mes 24)
- [ ] Existe un test que verifica `depósito` → `DEPOSITO`
- [ ] Existe un test que verifica que `monto` vacío ≠ `monto` no numérico (motivos distintos)
- [ ] La decisión sobre `ResolverStyle` está documentada en `docs/decisiones.md`
- [ ] Las entidades destino son clases con getters públicos (compatibles con `beanMapped()`)
- [ ] Ninguna validación de negocio vive en un `CHECK` de la BD como único mecanismo
- [ ] `./mvnw test` pasa con ≥ 20 tests de processors/normalizadores
- [ ] `FILTER_COUNT = 0` en los 3 steps de carga, o el valor está explicado en el README
- [ ] Cada fila de `banco.*` conserva el valor crudo original (`fecha_original`, `tipo_original`, `monto_original`)

---

# CRITERIO 4 — Escalado COMPARANDO parámetros (15 pts)

> *Descriptor 80%: "Baja a 12 si implementa escalado pero **NO compara ejecuciones con distintos parámetros**"*

## 4a) Qué construir

**Un runner de experimentos, no un README con dos números.**

```
cl.duoc.bancoxyz.experiment
├── EstrategiaEscalado.java        enum { SECUENCIAL, MULTI_THREAD, PARTICIONADO }
├── CasoExperimento.java           record(jobName, estrategia, paralelismo, chunkSize, filasDataset, fase)
├── ResultadoExperimento.java      record(caso, repeticion, warmup, wallClockNanos, ...)
├── MatrizExperimentos.java        fases F0/F1/F2
├── FabricaJobsExperimento.java    construye Job/Step por caso
├── EjecutorExperimentos.java      @Profile("experiment"), por RONDAS, orden aleatorizado
├── EscritorResultadosCsv.java     -> results/scaling-results.csv
├── SondaEntorno.java              cpus, heap, versión JVM, hikariPoolSize
└── AmplificadorDataset.java       transacciones_x100.csv determinista
```

**Diseño escalonado (14 celdas, no 96):**
- **Fase 0 — baseline secuencial:** `chunkSize ∈ {10, 50, 100, 500}`, paralelismo 1. → sale `chunk*`.
- **Fase 1 — paralelismo:** fijado `chunk*`, cruzar `{MULTI_THREAD, PARTICIONADO} × {2, 4, 8}`.
- **Fase 2 — confirmación cruzada:** mejor celda de F1 × los 2 mejores `chunkSize` de F0 (protege de la crítica "asumiste que los factores no interactúan").

**Protocolo:** 7 repeticiones por celda, **2 descartadas como warm-up** (pero presentes en el CSV con `warmup=true`), reporte de **mediana + IQR + CV %**, orden aleatorizado por rondas con semilla fija, `TRUNCATE` fuera del cronómetro, `-Xms2g -Xmx2g`.

**Doble escala:** dataset real (1000 filas) **y** `transacciones_x100.csv` (100.000 filas, generado por `AmplificadorDataset`, con re-secuenciación de `id` y **sin** tocar `cuenta_id`).

## 4b) La trampa

**Trampa principal — la literal del descriptor:** implementas particiones, corres una vez, pones "234 ms vs 329 ms" y crees que comparaste. **No comparaste parámetros.** Necesitas ≥ 2 parámetros barridos (`chunkSize` **y** `gridSize`/threads) con ≥ 2 niveles cada uno y repeticiones.

**Trampas técnicas que hacen falso el número:**

| Trampa | Síntoma | Antídoto |
|---|---|---|
| `PartitionStepBuilder` sin `.taskExecutor(...)` | cae a `SyncTaskExecutor`: **secuencial, sin warning**. Tu "particionado" es un secuencial con más overhead | `.taskExecutor(poolParticiones(n))` siempre; verificar `hilos distintos` en el log |
| `ThreadPoolTaskExecutor` con `queueCapacity` < nº particiones | particiones `FAILED` **en silencio** con `exitDesc='TaskExecutor rejected the task for this step.'` | `queueCapacity = Integer.MAX_VALUE` o `CallerRunsPolicy` |
| `hikari.maximum-pool-size` (default **10**) < gridSize + metadatos | mides el pool, no el paralelismo | `maximum-pool-size ≥ gridSize + 2`, y `minimum-idle = maximum` |
| `.partitionHandler(h)` explícito | `.gridSize()` y `.taskExecutor()` del builder se **ignoran**; y el default de `AbstractPartitionHandler` es **1**, no 6 | o usas el builder, o configuras todo sobre el handler |
| multi-thread con `FlatFileItemReader` sin envolver | `maxItemCount` violado ~1 de cada 5 corridas; datos duplicados/perdidos | `SynchronizedItemStreamReader` **y explicar que eso serializa la lectura** |
| Micrometer con los tags de la doc oficial | `registry.find("spring.batch.chunk.write").tag("job.name",…)` devuelve **`null`**; columnas vacías sin error | los tags reales están cualificados: `spring.batch.chunk.write.job.name` |
| Jobs construidos por factory (no beans) | `BatchObservabilityBeanPostProcessor` no corre → todas las métricas de job/step en **NOOP** | `.observationRegistry(...)` y `.meterRegistry(...)` en **cada** `JobBuilder` y `StepBuilder`, manager y worker incluidos |
| Comparar sin declarar base de speedup | speedups inconsistentes entre filas; error aritmético detectable | **una sola base declarada en la leyenda**: el mejor secuencial |

**Trampa de honestidad (y es la que sube a 15):** con 1000 filas el paralelismo **no va a ganar** — el overhead domina y es habitual que el particionado sea *más lento*. Reportar eso con IQR solapados y explicarlo con la ley de Amdahl vale **más** que inventar un 1,4×.

## 4c) Evidencia a capturar

| Evidencia | Archivo |
|---|---|
| CSV crudo con TODAS las ejecuciones, warm-ups incluidos y marcados | `results/scaling-results.csv` |
| Tabla comparativa con mediana, P25–P75, CV %, speedup (base declarada), throughput, `COMMIT_COUNT`, `skew` | `docs/escalado.md` + README |
| 3 gráficos: throughput vs paralelismo; speedup vs ideal + Amdahl; boxplot de duración | `evidencias/04-escalado/*.png` (script `scripts/graficar.py`) |
| Log que prueba paralelismo real (nombres de hilo distintos por partición) | `evidencias/04-escalado/log-particionado-grid4.txt` |
| Duración por partición desde metadatos | `evidencias/04-escalado/particiones.txt` |
| Variante de control con writer no-op (cuánto del tiempo es BD) | fila extra en la tabla |
| Salida literal de `GET /actuator/metrics` probando qué métricas y tags existen en tu build | `evidencias/04-escalado/actuator-metrics.json` |
| Entorno: cpus, heap, JVM, pool | columnas del propio CSV |

```sql
-- scripts/consultas-sql/04-particiones.sql  — duración y desbalance por partición
SELECT se.STEP_NAME, se.STATUS, se.READ_COUNT, se.WRITE_COUNT,
       EXTRACT(EPOCH FROM (se.END_TIME - se.START_TIME))*1000 AS ms
FROM batch_meta.BATCH_STEP_EXECUTION se
WHERE se.JOB_EXECUTION_ID = :id AND se.STEP_NAME LIKE '%:partition%'
ORDER BY ms DESC;
-- skew = max(READ_COUNT)/avg(READ_COUNT)   |   speedup real = sum(ms)/max(ms)
```

```sql
-- scripts/consultas-sql/05-comparativa.sql  — reconstruye la tabla desde los metadatos
SELECT MAX(CASE WHEN p.PARAMETER_NAME='estrategia'  THEN p.PARAMETER_VALUE END) AS estrategia,
       MAX(CASE WHEN p.PARAMETER_NAME='paralelismo' THEN p.PARAMETER_VALUE END) AS paralelismo,
       MAX(CASE WHEN p.PARAMETER_NAME='chunkSize'   THEN p.PARAMETER_VALUE END) AS chunk,
       e.JOB_EXECUTION_ID,
       EXTRACT(EPOCH FROM (e.END_TIME - e.START_TIME))*1000 AS ms, e.STATUS
FROM batch_meta.BATCH_JOB_EXECUTION e
JOIN batch_meta.BATCH_JOB_EXECUTION_PARAMS p USING (JOB_EXECUTION_ID)
GROUP BY e.JOB_EXECUTION_ID, e.START_TIME, e.END_TIME, e.STATUS
ORDER BY estrategia, paralelismo, chunk;
```
*(columnas `PARAMETER_NAME/PARAMETER_VALUE`: son las de Batch 5.x; en 4.x eran `KEY_NAME/STRING_VAL`.)*

**Párrafo de conclusión obligatorio** (adaptado a tus números reales):
> *"La configuración óptima para el Job 1 a escala 100k es particionado con gridSize=4 y chunkSize=100 (mediana X ms, N,NN× sobre el mejor secuencial que es chunk=500 con Y ms). El punto de saturación coincide con el nº de núcleos: entre 4 y 8 la mejora es de Z % mientras el CV se multiplica por K. Despejando Amdahl con S(4) obtenemos p ≈ 0,NN, techo teórico S(∞) ≈ N,N×. A la escala del dataset entregado (1000 filas) ninguna configuración paralela supera al secuencial de forma distinguible: los IQR se solapan y el overhead de crear el pool domina. Recomendación operativa: secuencial para el volumen diario actual, particionado activable por `JobParameters` cuando el volumen crezca."*

## 4d) Checklist binario

- [ ] Están implementadas ≥ 2 estrategias ejecutables (secuencial + particionado; ideal + multi-thread)
- [ ] Se barren ≥ 2 parámetros con ≥ 3 niveles cada uno (`chunkSize` y `gridSize`/threads)
- [ ] ≥ 5 repeticiones medidas por celda, con warm-up descartado **y declarado**
- [ ] `results/scaling-results.csv` está versionado e incluye los warm-ups marcados
- [ ] La tabla reporta mediana **y** dispersión (IQR o CV), no sólo media
- [ ] Hay **una sola base de speedup**, declarada en la leyenda y aplicada a todas las filas
- [ ] Hay ≥ 1 gráfico con el eje Y empezando en cero
- [ ] La configuración óptima está declarada explícitamente **con sus condiciones** (hardware, tamaño, pool)
- [ ] El punto de saturación tiene explicación causal, no sólo descripción
- [ ] Amdahl aplicada con `p` **calculado de tus datos**
- [ ] El log de particionado muestra ≥ 2 nombres de hilo distintos (prueba de paralelismo real)
- [ ] `hikari.maximum-pool-size ≥ gridSize + 2` y está en la tabla como parámetro
- [ ] Si amplificaste el dataset: generador versionado y determinista, CSV originales intactos, hecho declarado en el README
- [ ] Salida de `/actuator/metrics` pegada en la evidencia

---

# CRITERIO 5 — Reintento y tolerancia a fallos (15 pts)

> *Descriptor: "Baja a 12 si **no considera 1 escenario** posible de fallo; a 9 si no considera 2 o más"*

## 5a) Qué construir

| Componente | Clase | Qué hace |
|---|---|---|
| SkipPolicy personalizada | `BancoXyzSkipPolicy implements SkipPolicy` | `shouldSkip(Throwable, long)` con **manejo del modo sonda `skipCount < 0`**, recorrido de la cadena de causas, y separación tajante datos-sucios vs infraestructura |
| SkipPolicy por tipo (alternativa documentada) | `SkipPolicies#porTipo()` con `ExceptionClassifierSkipPolicy` | límites distintos por familia de excepción |
| RetryPolicy personalizada | `RetryPolicies#infraestructura()` → `new SimpleRetryPolicy(3, mapa, true)` | reintenta **sólo** `PessimisticLockingFailureException`, `CannotAcquireLockException`, `TransientDataAccessException`; marca `ValidationException` y `IllegalArgumentException` como `false` |
| BackOff | `BackOffPolicies#exponencial()` → `ExponentialBackOffPolicy` 200 ms × 2.0, tope 5 s | espera creciente entre intentos |
| Dead letter | `DeadLetterSkipListener implements SkipListener<Raw,Entidad>, StepExecutionListener` | persiste cada rechazo en tabla **y** CSV; captura `jobExecutionId`/`stepName` en `beforeStep(...)` |
| Auditoría de reintentos | `ReintentoRetryListener implements RetryListener` | log de cada intento fallido con `getRetryCount()` |
| Resumen y umbral | `ResumenStepListener` | `afterStep` devuelve `ExitStatus("COMPLETED_WITH_WARNINGS")` si la tasa de rechazo supera el umbral |
| Errores de chunk | `ChunkErrorListener implements ChunkListener` | `afterChunkError` recupera la excepción con `ROLLBACK_EXCEPTION_KEY` |
| Excepciones propias | `RegistroInvalidoException extends ValidationException` + subtipos | portan `numeroLinea`, `campo`, `valorCrudo`, `motivo` |
| Restart | `FechaProcesoIncrementer implements JobParametersIncrementer` | `fechaProceso` identificante + `rutaEntrada` no identificante |

**Configuración del step (Modelo B — política personalizada, sin mezclar):**
```java
.faultTolerant()
    .skipPolicy(new BancoXyzSkipPolicy(500))   // NO llamar a .skip() ni .skipLimit() aquí
    .retry(CannotAcquireLockException.class)
    .retry(TransientDataAccessException.class)
    .retryLimit(3)                              // 3 intentos TOTALES en Batch 5
    .backOffPolicy(backOffExponencial)
    .noRetry(ValidationException.class)         // válido porque NO hay retryPolicy() explícito
    .noRollback(ValidationException.class)      // skip inline, sin rollback ni re-proceso
    .listener((StepExecutionListener) deadLetter)   // una sola llamada: se auto-registra como SkipListener
    .listener((StepExecutionListener) resumenListener)
```

## 5b) La trampa

**La trampa del descriptor es de conteo:** el evaluador cuenta **escenarios considerados**. Si tu README dice "implementé retry y skip" sin enumerar escenarios, considera 1 y te deja en 12. **Necesitas una tabla explícita escenario → disparador → política → prueba → evidencia**, y las pruebas ejecutadas.

**Trampas técnicas:**

| # | Error | Síntoma | Corrección |
|---|---|---|---|
| 1 | `skipLimit` default = 10 | step `FAILED` en la fila ~11 con 40 % de datos sucios | `skipPolicy(...)` con límites reales |
| 2 | `SkipPolicy` copiada de Batch 4 con `int skipCount` | **no sobrescribe** el método; tu política nunca se ejecuta | firma `boolean shouldSkip(Throwable, long)` |
| 3 | Ignorar la sonda `skipCount < 0` | rompes el *chunk scanning*; lanzas `SkipLimitExceededException` cuando el framework sólo preguntaba | `if (skipCount < 0) return esOmitible;` |
| 4 | Contadores `AtomicLong` dentro del `SkipPolicy` | conteos inflados: `shouldSkip` se llama varias veces por ítem | usar el `skipCount` que entrega el framework |
| 5 | Mezclar `skipPolicy()` con `skip()`/`skipLimit()` en 5.2.x | se componen con `CompositeSkipPolicy` en **OR**: tu veto queda anulado | elegir Modelo A **o** B |
| 6 | `noRollback(X)` sin `skip(X)` | `NonSkippableProcessException`, step falla | declarar ambos |
| 7 | `retry(ValidationException.class)` | 371 filas × 3 intentos × backoff = minutos de espera inútil | reintentar **sólo** infraestructura |
| 8 | `.listener(bean)` sin cast con bean multi-interfaz | **no compila**: `reference to listener is ambiguous` | `.listener((StepExecutionListener) bean)` |
| 9 | `@BeforeStep` en un listener registrado como `SkipListener` | la anotación **nunca se ejecuta**; todos los rechazos con `job_execution_id = 0` | implementar `StepExecutionListener` y sobrescribir `beforeStep` |
| 10 | `DeadlockLoserDataAccessException` | warning de deprecación (`@Deprecated since 6.0.3`) | `CannotAcquireLockException` / `PessimisticLockingFailureException` |
| 11 | `skipLimit` en step particionado | el límite es **por `StepExecution`**, o sea **por partición**: 8×500 = 4000 skips tolerados en el job | documentarlo explícitamente |

## 5c) LISTA COMPLETA DE ESCENARIOS DE FALLO (16 escenarios)

Cada uno con disparador real del dataset, política que lo maneja, y cómo se prueba.

### Grupo A — Datos irrecuperables (skip + dead letter)

**E1 · Fecha imposible (mes 13)**
- **Dispara:** 55 filas `2024-13-01` en `transacciones.csv`. Los 4 formatos fallan → `NormalizadorFecha` devuelve `Optional.empty()` → `RegistroInvalidoException(FECHA_INVALIDA)`.
- **Política:** `BancoXyzSkipPolicy` (omitible) + `noRollback(ValidationException)` → skip *inline*, sin rollback ni scanning. `DeadLetterSkipListener.onSkipInProcess` persiste.
- **Prueba:** `NormalizadorFechaTest#rechazaMes13()`; y `SELECT COUNT(*) FROM banco.registro_rechazado WHERE motivo='FECHA_INVALIDA'` = **55**.
- **Evidencia:** `evidencias/05-fallos/E1-fecha-invalida/` (test + query + `PROCESS_SKIP_COUNT`).

**E2 · Monto ausente**
- **Dispara:** 168 filas con `monto` vacío en `transacciones.csv` (160 tras precedencia) y 48 en `cuentas_anuales.csv`.
- **Política:** idéntica a E1, motivo `MONTO_AUSENTE`. Diferenciado de "monto no numérico" (`MONTO_NO_NUMERICO`), que es otro motivo.
- **Prueba:** `SELECT motivo, COUNT(*) …` = 160 y 48.

**E3 · Saldo ausente (Job 2)**
- **Dispara:** 211 filas con `saldo` vacío en `intereses.csv`. Sin saldo no hay interés que calcular.
- **Política:** skip + dead letter, motivo `SALDO_AUSENTE`.
- **Prueba:** conteo en `registro_rechazado` + verificación de que ninguna de esas cuentas quedó con `interes_aplicado` inflado.

**E4 · Duplicado exacto — fallo en fase WRITE**
- **Dispara:** las **9 filas 100 % idénticas** de `intereses.csv`.
- **Política:** `UNIQUE (periodo, cuenta_id, nombre, saldo_inicial, edad_original, tipo_original)` en `banco.interes_calculado` → `DuplicateKeyException` en el writer → `BancoXyzSkipPolicy` la declara omitible → `onSkipInWrite` la persiste con motivo `DUPLICADO`.
- **Por qué este escenario vale doble:** es el **único** que demuestra tolerancia en fase de escritura, y permite explicar el *chunk scanning* (el chunk hace rollback y se reprocesa ítem a ítem: 1 chunk fallido = ~50 transacciones de 1 ítem). Con 9 duplicados el coste es asumible y el análisis es material de criterio 6.
- **Prueba:** `SELECT COUNT(*) … motivo='DUPLICADO'` = 9; `WRITE_SKIP_COUNT` = 9; `ROLLBACK_COUNT` ≥ 9.

### Grupo B — Datos degradados (marcar, NO skip)

**E5 · Tipo desconocido masivo**
- **Dispara:** 371 filas (`invalid` 308 + `desconocido` 63) en transacciones; 331 (`-1` 279 + `unknown` 52) en intereses.
- **Política:** **deliberadamente NO es skip.** Si lo fuera, agotaría cualquier `skipLimit` razonable y perderías el 37 % del archivo. Se canoniza a `DESCONOCIDO`, estado `ANOMALA_TIPO_DESCONOCIDO`, y en el Job 2 tasa = 0 (no se aplica interés a una cuenta de tipo desconocido: **decisión de negocio documentada**).
- **Prueba:** `PROCESS_SKIP_COUNT` **no** incluye esas filas; `SELECT COUNT(*) FROM banco.transaccion WHERE estado='ANOMALA_TIPO_DESCONOCIDO'` = 230 (tras precedencia).
- **Por qué cuenta como escenario:** es la decisión explícita de *no* usar tolerancia a fallos donde el coste sería prohibitivo. Explicarlo demuestra criterio.

**E6 · Edad fuera de rango**
- **Dispara:** `edad=100` (120 filas), `edad=150` (52), vacía (193).
- **Política:** saneado en el processor a `NULL` + `ANOMALA_EDAD_FUERA_RANGO`. El `CHECK (edad IS NULL OR edad BETWEEN 18 AND 99)` de la BD queda como **red de seguridad**: si alguna vez se dispara, `DataIntegrityViolationException` **no es omitible** (es un bug del processor, no un dato sucio) y el step falla.
- **Prueba:** `SELECT edad_original, edad, COUNT(*) … GROUP BY 1,2` + un test que inserta a mano `edad=150` y verifica que el CHECK la rechaza.

**E7 · Monto negativo / cero (la anomalía que el Job 1 debe REPORTAR)**
- **Dispara:** 141 negativos + 18 ceros en transacciones; 254 negativos + 12 ceros en anuales.
- **Política:** se guardan con `ANOMALA_MONTO_NEGATIVO` / `ANOMALA_MONTO_CERO`. En `cuentas_anuales` se añade la regla de signo: un `deposito` con monto negativo es `ANOMALA_SIGNO_CONTRADICTORIO`.
- **Prueba:** `banco.resumen_diario.n_anomalas` > 0 y coincide con el conteo por estado.

### Grupo C — Infraestructura (retry, NUNCA skip)

**E8 · Caída transitoria de la BD**
- **Dispara:** `docker compose stop postgres` durante 3 s a mitad del job (script `scripts/escenarios-fallo/escenario-bd-caida.sh`).
- **Política:** `retry(TransientDataAccessException)` × 3 + `ExponentialBackOffPolicy(200 ms, ×2, tope 5 s)`. **Nunca** skip: perder datos buenos por un hipo de red es inaceptable.
- **Prueba:** el job termina `COMPLETED` a pesar del corte; `ROLLBACK_COUNT` > 0; log del `ReintentoRetryListener` con 3 intentos.
- **Evidencia:** `evidencias/05-fallos/E8-bd-caida/log.txt` + captura de la fila `BATCH_STEP_EXECUTION`.

**E9 · Contención de bloqueo en el UPDATE de saldo**
- **Dispara:** particionado del Job 2 con `gridSize` alto y —para provocarlo deliberadamente— la variante "mala" que particiona por **rango de línea** en vez de por `cuenta_id`: dos hilos actualizan la misma cuenta.
- **Política:** `retry(CannotAcquireLockException)` + `retry(PessimisticLockingFailureException)`. **Y la solución estructural:** particionar por `cuenta_id`, que garantiza afinidad hilo↔cuenta y hace el problema imposible por construcción.
- **Prueba:** correr las dos variantes; la mala muestra reintentos y/o *lost update* (saldo final distinto entre corridas), la buena es determinista.
- **Por qué es el escenario de mayor densidad de puntos:** demuestra que eliges partición por **corrección concurrente**, no por velocidad.

**E10 · Cuenta inexistente en el UPDATE**
- **Dispara:** CSV de prueba `data/casos-prueba/intereses-cuenta-fantasma.csv` con `cuenta_id=999`.
- **Política:** `JdbcBatchItemWriter` con `assertUpdates(true)` → afecta 0 filas → `EmptyResultDataAccessException` → declarada omitible → dead letter con motivo `CUENTA_INEXISTENTE`.
- **Prueba:** correr el job con ese CSV y ver la fila en `registro_rechazado`.

**E11 · Archivo de entrada ausente o ilegible (fail-fast)**
- **Dispara:** `mv data/semana_3/transacciones.csv /tmp/` y lanzar el job.
- **Política:** `ItemStreamException`/`FileNotFoundException` **NO es omitible ni reintentable**. El step falla inmediatamente con mensaje claro.
- **Prueba:** job `FAILED`, `READ_COUNT=0`, `EXIT_MESSAGE` legible.
- **Por qué cuenta:** demuestra que tu política **distingue** dato sucio de fallo de infraestructura. Un `skip(Exception.class)` se tragaría esto y arruinaría el job en silencio.

**E12 · Rechazo del TaskExecutor (cola saturada)**
- **Dispara:** `ThreadPoolTaskExecutor(core=2, queueCapacity=1)` con 20 particiones (perfil `escenario-pool-chico`).
- **Política:** el `TaskExecutorPartitionHandler` marca las particiones rechazadas como `FAILED` **sin excepción visible**. La política preventiva es `queueCapacity` ≥ nº particiones o `CallerRunsPolicy`, más una validación de arranque en `TaskExecutorConfig` que falla si `queueCapacity < gridSize`.
- **Prueba:** reproducir el fallo, mostrar el `exitDesc='TaskExecutor rejected the task for this step.'`, luego mostrar la configuración correcta funcionando.

### Grupo D — Umbral, reinicio e idempotencia

**E13 · Superación del límite de tolerancia**
- **Dispara:** `data/casos-prueba/transacciones-envenenado.csv` con 600 filas irrecuperables y `skipLimit=500`.
- **Política:** `BancoXyzSkipPolicy` lanza `SkipLimitExceededException` → job `FAILED` **deliberadamente**.
- **Prueba:** el job falla; `EXIT_MESSAGE` nombra el límite.
- **Por qué cuenta:** la tolerancia sin techo es negligencia. Demostrar el techo es demostrar la política.

**E14 · Interrupción y reinicio a mitad de job**
- **Dispara:** `kill -9` del proceso durante `stepCargarMovimientos` (script `scripts/escenarios-fallo/escenario-interrupcion.sh`).
- **Política:** relanzar con **los mismos `JobParameters` identificantes** → Spring Batch reinicia la `JobInstance`; los steps `COMPLETED` se saltan y **sólo se re-ejecutan las particiones `FAILED`** (`SimpleStepExecutionSplitter.isStartable`).
- **Prueba:** dos `JOB_EXECUTION_ID` para la misma `JOB_INSTANCE_ID`; en la segunda, particiones `COMPLETED` ausentes y sólo las fallidas presentes.
- **Detalle de nota:** `RangoCuentaPartitioner implements PartitionNameProvider` para que en el reinicio no se recalcule el particionado.

**E15 · Doble aplicación de interés (no idempotencia)**
- **Dispara:** correr `jobInteresesMensuales` dos veces con el mismo `periodo`.
- **Política:** `stepConsolidarSaldos` es idempotente por guarda de periodo:
  `… ON CONFLICT (cuenta_id) DO UPDATE SET saldo = … WHERE banco.cuenta.periodo_aplicado IS DISTINCT FROM EXCLUDED.periodo_aplicado`.
- **Prueba:** `SELECT SUM(saldo) FROM banco.cuenta` antes y después de la 2ª corrida → **idéntico**.
- **Alternativa documentada:** `preventRestart()` a nivel de Job. Mencionar ambas y justificar la elegida.

**E16 · Relanzamiento con parámetros ya completados**
- **Dispara:** ejecutar el mismo job dos veces seguidas sin cambiar nada. **El evaluador hará esto.**
- **Política:** `FechaProcesoIncrementer` (o `RunIdIncrementer`) → nueva `JobInstance` en cada lanzamiento; sin él, `JobInstanceAlreadyCompleteException` y el evaluador ve una excepción fea en su primera interacción con tu proyecto.
- **Prueba:** `./scripts/run-all.sh && ./scripts/run-all.sh` → ambas corridas `COMPLETED`.

> **Resumen para el README:** 16 escenarios, 5 categorías (irrecuperable / degradado / infraestructura / umbral / reinicio), 4 mecanismos (skip, retry+backoff, marcado sin skip, fail-fast). El descriptor pide "no omitir 2 o más"; aquí sobran 8.

## 5d) Checklist binario

- [ ] `BancoXyzSkipPolicy` implementa `shouldSkip(Throwable, long)` con `long` (no `int`)
- [ ] Maneja el modo sonda `skipCount < 0` sin lanzar excepción ni mutar estado
- [ ] Recorre la cadena de causas (`getCause()`) al clasificar
- [ ] Devuelve `false` para `DataAccessResourceFailureException`, `FileNotFoundException` y `OptimisticLockingFailureException`
- [ ] No hay ninguna llamada a `.skip()` ni `.skipLimit()` en el mismo step que usa `.skipPolicy()`
- [ ] `retry(...)` no incluye ninguna `ValidationException` ni subtipo
- [ ] Cada `noRollback(X)` tiene su `X` cubierta por la política de skip
- [ ] `DeadLetterSkipListener` implementa `StepExecutionListener` (no usa `@BeforeStep`)
- [ ] Está registrado con **una sola** llamada `.listener((StepExecutionListener) bean)`
- [ ] Ninguna fila de `registro_rechazado` tiene `job_execution_id = 0`
- [ ] Los 3 Jobs tienen `JobParametersIncrementer`
- [ ] `stepConsolidarSaldos` es idempotente y hay evidencia de la doble ejecución
- [ ] Existe `docs/tolerancia-fallos.md` con la tabla de los 16 escenarios
- [ ] Existen ≥ 6 scripts `scripts/escenarios-fallo/escenario-*.sh` ejecutables
- [ ] Existe `evidencias/05-fallos/E<n>-*/` con log para cada escenario probado
- [ ] Está documentado que `skipLimit` en particionado es **por partición**, no global

---

# CRITERIO 6 — Aplicación de políticas y optimización de tiempos/estabilidad (15 pts)

> *Descriptor 80%: "Baja a 12 **con 1-2 errores**"*

## 6a) Qué construir

Este criterio no tiene entregables nuevos: **es la ausencia de errores** en todo lo anterior más la justificación de cada parámetro.

1. **`application.yml` correcto y comentado** (cada propiedad con el porqué).
2. **`PropiedadesBatch`** (`@ConfigurationProperties("app.batch")`) — cero números mágicos en el código: `chunkSize` por job, `gridSize`, `skipLimit`, `maxRetries`, `backoff`, `tasas`, `umbralRechazo`, rutas.
3. **`docs/decisiones.md`** — una entrada por decisión: chunk por job, gridSize, pool, `assertUpdates` por writer, `ON CONFLICT` vs `UPDATE`, `ResolverStyle`, un datasource, partición vs multi-thread, `reWriteBatchedInserts` sí/no por step.
4. **Build limpio:** `./mvnw clean verify -Dmaven.compiler.showDeprecation=true` sin warnings de deprecación.
5. **Arranque limpio:** cero `WARN` en el log de arranque.

## 6b) La trampa (inventario de "los 1-2 errores")

Cada uno de estos, visto una vez, es un punto menos. Son los que un evaluador detecta sin esfuerzo:

| # | Error | Detección |
|---|---|---|
| 1 | `spring.batch.job.enabled` en `true` con 3 jobs | al arrancar se lanza un job solo, o falla pidiendo `spring.batch.job.name` |
| 2 | Sin `JobParametersIncrementer` | 2ª ejecución → `JobInstanceAlreadyCompleteException` |
| 3 | `initialize-schema` en default (`embedded`) con Postgres | no existen las tablas `BATCH_*` |
| 4 | `table-prefix` con esquema sin `currentSchema` en la URL | `relation "batch_meta.batch_job_instance" does not exist` |
| 5 | `spring.sql.init.mode` en default | `schema.sql` **no corre** contra Postgres |
| 6 | `throttleLimit(...)` | deprecado desde 5.0, `forRemoval` en 6.0 |
| 7 | `chunk(int)` a secas en 5.2.6 | deprecado; la forma correcta en 5.2 es `chunk(int, txManager)` |
| 8 | `DeadlockLoserDataAccessException` | deprecada desde Spring 6.0.3 |
| 9 | `SimpleAsyncTaskExecutor` como "pool" | no reutiliza hilos **nunca**; tu eje X del criterio 4 es ficticio |
| 10 | Pool Hikari (default 10) < gridSize + metadatos | timeouts intermitentes justo al medir |
| 11 | `ClassifierCompositeItemWriter` con delegado de archivo sin `.stream(...)` | `WriterNotOpenException` o CSV vacío |
| 12 | `import org.springframework.batch.classify.Classifier` | no existe; es `org.springframework.classify.Classifier` |
| 13 | `DOUBLE PRECISION` para dinero | error de diseño de datos, señalable en el DDL |
| 14 | `chunkSize` idéntico en los 3 jobs sin justificar | "no aplica las configuraciones", es literalmente este criterio |
| 15 | Mezclar imports de Batch 5 y Batch 6 | `package does not exist` |
| 16 | `spring.sql.init` + Flyway a la vez | la doc oficial lo desaconseja explícitamente |

**Justificación de parámetros que hay que escribir** (esto es lo que "aplica las configuraciones optimizando"):
- Job 1 `chunk(200)`: inserts puros, rewrite activable, sin scanning esperado.
- Job 2 `chunk(50)`: hay `UNIQUE` que dispara *chunk scanning* con los 9 duplicados; chunk pequeño acota el coste del scan (O(chunkSize)).
- Job 3 `chunk(200)`: carga + agregación posterior, sin writes conflictivos.
- `reWriteBatchedInserts=true` **sólo** si todos los writers de ese step son INSERT puros; **apagado** en el Job 2 por el `ON CONFLICT DO UPDATE` y por la *cardinality violation* (1000 filas para 50 cuentas ⇒ el mismo `cuenta_id` ~20 veces).
- `assertUpdates(true)` en el writer de rechazos y en los UPDATE; `false` donde hay `DO NOTHING`.

## 6c) Evidencia a capturar

| Evidencia | Archivo |
|---|---|
| `./mvnw clean verify` completo sin warnings de deprecación | `evidencias/06-estabilidad/build.txt` |
| Log de arranque sin `WARN` | `evidencias/06-estabilidad/arranque.txt` |
| Doble ejecución consecutiva de los 3 jobs, ambas `COMPLETED` | `evidencias/06-estabilidad/doble-ejecucion.txt` |
| Prueba de idempotencia del Job 2 (`SUM(saldo)` antes/después) | `evidencias/06-estabilidad/idempotencia-job2.txt` |
| `application.yml` con comentario por propiedad | el propio archivo |
| `docs/decisiones.md` con ≥ 10 decisiones justificadas | el archivo |
| Tabla de tiempos antes/después de la optimización (chunk 10 → chunk óptimo) con `COMMIT_COUNT` como explicación | `docs/escalado.md` |
| Log del reinicio tras interrupción mostrando que sólo se re-ejecutan las particiones fallidas | `evidencias/06-estabilidad/reinicio.txt` |

## 6d) Checklist binario

- [ ] `spring.batch.job.enabled=false` y el lanzamiento es explícito por `--job=`
- [ ] `spring.batch.jdbc.initialize-schema=always`
- [ ] `spring.sql.init.mode=always` y `platform=postgresql`
- [ ] La URL JDBC lleva `currentSchema=batch_meta` **o** las `BATCH_*` viven en `public` sin prefijo calificado
- [ ] `hikari.maximum-pool-size ≥ gridSize + 2` y `minimum-idle = maximum-pool-size`
- [ ] No aparece `throttleLimit` en ninguna parte del código
- [ ] No aparece `SimpleAsyncTaskExecutor` en ninguna configuración medida
- [ ] `./mvnw clean verify -Dmaven.compiler.showDeprecation=true` sin warnings de deprecación de Spring
- [ ] Cero `WARN` en el log de arranque
- [ ] Los 3 jobs corren dos veces seguidas sin error
- [ ] Todos los importes son `NUMERIC(15,2)` o `NUMERIC(18,2)`; ningún `DOUBLE`/`float8`
- [ ] Ningún literal numérico de configuración está hardcodeado en clases `*Config` (todo vía `PropiedadesBatch`)
- [ ] `docs/decisiones.md` justifica `chunkSize` distinto por job
- [ ] Todos los delegados de archivo bajo un `ClassifierCompositeItemWriter` están registrados con `.stream(...)`
- [ ] Existe al menos una tabla "antes/después" de optimización con `COMMIT_COUNT` como explicación

---

# CRITERIO 7 — Los 3 aspectos clave: código, documentación, evidencia (10 pts)

## 7a) Qué construir

**1. Código fuente** — repo GitHub propio, público, con historial de commits real (no un solo commit "initial"), `.gitignore` correcto, `mvnw` incluido.

**2. `README.md`** con **las 3 secciones que el enunciado nombra literalmente**:
- **Objetivo del proyecto** — el problema del Banco XYZ y los 3 jobs.
- **Estructura del código** — árbol comentado + tabla componente-Spring-Batch → clase.
- **Instrucciones de ejecución** — requisitos, `docker compose up -d`, `./mvnw clean package`, los 3 comandos de lanzamiento, cómo verificar en BD, cómo correr el benchmark, cómo reproducir los escenarios de fallo.

Y además (sube el criterio 6 y protege el 4 y el 5): tabla de resultados de escalado, tabla de escenarios de fallo, cuadratura esperada por archivo, declaración honesta de versiones EOL, decisiones de diseño.

**3. Evidencia** — carpeta `evidencias/` organizada **por criterio**, con un `INDICE.md` que mapea criterio → archivo. Que el evaluador no tenga que buscar.

```
evidencias/
├── INDICE.md                        ← mapeo criterio → evidencia
├── 01-arquitectura/                 diagrama.png, dependency-tree.txt, steps-registrados.txt, tablas-metadatos.txt
├── 02-ejecucion/                    log-job1.txt, log-job2.txt, log-job3.txt,
│                                    cuadratura.txt, distribucion.txt, contadores-batch.txt,
│                                    captura-transaccion.png, captura-cuenta.png,
│                                    captura-estado-cuenta.png, captura-rechazados.png
├── 03-processor/                    mvn-test.txt, antes-despues.md, normalizacion-tildes.txt, formatos-fecha.txt
├── 04-escalado/                     scaling-results.csv, tabla-comparativa.md,
│                                    grafico-throughput.png, grafico-speedup.png, boxplot.png,
│                                    log-particionado-grid4.txt, particiones.txt, actuator-metrics.json
├── 05-fallos/                       E01…E16/ (log.txt + query.txt por escenario)
├── 06-estabilidad/                  build.txt, arranque.txt, doble-ejecucion.txt,
│                                    idempotencia-job2.txt, reinicio.txt
└── 07-entrega/                      checklist-final.md, estructura-entrega.txt
```

## 7b) La trampa

1. **Falta una de las 3 secciones del README.** El enunciado las nombra: *objetivo, estructura del código, instrucciones de ejecución*. Falta una → falta un "aspecto clave".
2. **Evidencia genérica.** Una captura del IDE con "BUILD SUCCESS" no es evidencia de ejecución de **cada Job y sus resultados**. El enunciado dice "de cada Job **y sus resultados**": hacen falta log **y** estado final de la BD, **por job**.
3. **Instrucciones no reproducibles.** Si el evaluador no puede levantar el proyecto en 3 comandos, todos los criterios anteriores quedan sin verificar y bajan por defecto. Prueba las instrucciones **en limpio**: `git clone` en un directorio nuevo, `docker compose down -v`, seguir el README al pie de la letra.
4. **Formato de entrega.** "Todo en una misma carpeta", comprimido como **`Exp1_S3_Nombre_Apellido`**. Y el `.zip` no debe llevar `target/`, `.git/` pesado ni `data/generated/`.
5. **Repo privado o de otra cuenta.** El enunciado exige cuenta propia; verifica el acceso desde una sesión anónima.

## 7c) Evidencia a capturar

La evidencia **es** el entregable de este criterio. Añade:
- `evidencias/INDICE.md` con la tabla criterio → archivo → qué demuestra.
- Un `asciinema`/GIF opcional de la ejecución completa (`scripts/run-all.sh`), o al menos el log completo con timestamps.
- Captura de la BD **con datos**, no de la estructura vacía.

## 7d) Checklist binario

- [ ] Repo público en cuenta propia, verificado desde sesión anónima
- [ ] ≥ 10 commits con mensajes descriptivos
- [ ] `README.md` tiene sección **Objetivo**
- [ ] `README.md` tiene sección **Estructura del código** con árbol y tabla de componentes
- [ ] `README.md` tiene sección **Instrucciones de ejecución** probada en un clon limpio
- [ ] `README.md` incluye la tabla comparativa de escalado y la de escenarios de fallo
- [ ] `README.md` incluye la cuadratura esperada por archivo
- [ ] `evidencias/INDICE.md` mapea los 7 criterios a archivos concretos
- [ ] Hay log de ejecución completo por **cada uno** de los 3 Jobs
- [ ] Hay captura de datos en BD por **cada una** de las 6 tablas de negocio + rechazados
- [ ] `.gitignore` excluye `target/`, `data/generated/`, `*.log`
- [ ] El `mvnw` está incluido y funciona
- [ ] Carpeta comprimida como `Exp1_S3_Nombre_Apellido.zip`, sin `target/`

---

# 8. ÁRBOL DE DIRECTORIOS DEL PROYECTO MAVEN COMPLETO

```
banco-xyz-batch/
├── pom.xml
├── README.md                                    ← criterio 7 (objetivo/estructura/ejecución)
├── LICENSE
├── .gitignore
├── .gitattributes                               ← * text=auto eol=lf ; *.csv -text
├── mvnw
├── mvnw.cmd
├── .mvn/wrapper/maven-wrapper.properties
├── compose.yaml                                 ← postgres:17-alpine + pgadmin + healthcheck
│
├── docker/
│   └── initdb/
│       └── 00-schemas.sql                       ← CREATE SCHEMA banco; CREATE SCHEMA batch_meta;
│
├── scripts/
│   ├── run-all.sh                               ← levanta BD + los 3 jobs + cuadratura
│   ├── run-job.sh                               ← ./scripts/run-job.sh jobInteresesMensuales
│   ├── benchmark.sh                             ← perfil experiment, matriz completa
│   ├── graficar.py                              ← 3 gráficos desde results/scaling-results.csv
│   ├── perfilar-dataset.sh                      ← conteos esperados con la precedencia de §0.1
│   ├── generar-dataset.sh                       ← invoca AmplificadorDataset (x100)
│   ├── verificar-cuadratura.sh                  ← psql -f scripts/consultas-sql/01-cuadratura.sql
│   ├── capturar-evidencia.sh                    ← vuelca logs+queries a evidencias/
│   ├── escenario-bd-caida.sh                    ← E8
│   ├── escenario-interrupcion.sh                ← E14
│   ├── escenario-archivo-ausente.sh             ← E11
│   ├── escenario-skiplimit.sh                   ← E13
│   ├── escenario-pool-chico.sh                  ← E12
│   ├── escenario-duplicados.sh                  ← E4
│   └── escenario-idempotencia.sh                ← E15
│
├── sql/
│   └── verificacion/
│       ├── 00-esquema.sql
│       ├── 01-cuadratura.sql
│       ├── 02-distribucion-esperada.sql
│       ├── 03-contadores-batch.sql
│       ├── 04-particiones.sql
│       ├── 05-comparativa-escalado.sql
│       ├── 06-rechazos-por-motivo.sql
│       ├── 07-idempotencia-job2.sql
│       └── 08-resumen-ejecutivo.sql
│
├── data/
│   ├── semana_3/                                ← ORIGINALES, no se tocan jamás
│   │   ├── transacciones.csv
│   │   ├── intereses.csv
│   │   └── cuentas_anuales.csv
│   ├── casos-prueba/
│   │   ├── transacciones-envenenado.csv         ← E13
│   │   ├── intereses-cuenta-fantasma.csv        ← E10
│   │   ├── transacciones-vacio.csv
│   │   └── transacciones-sin-cabecera.csv
│   └── generated/                               ← .gitignore
│       └── transacciones_x100.csv
│
├── docs/
│   ├── enunciado/                               (ya existe)
│   │   ├── RESUMEN.md
│   │   ├── instrucciones-especificas.docx
│   │   ├── pauta-evaluacion.docx
│   │   └── guia-aprendizaje-escalado-particiones.docx
│   ├── analisis-datos.md                        (ya existe)
│   ├── arquitectura.md                          ← criterio 1: diagrama + tabla de componentes
│   ├── transformaciones.md                      ← criterio 3: tabla antes/después
│   ├── escalado.md                              ← criterio 4: matriz, tabla, gráficos, Amdahl
│   ├── tolerancia-fallos.md                     ← criterio 5: los 16 escenarios
│   ├── decisiones.md                            ← criterio 6: ADRs cortos
│   ├── amenazas-validez.md                      ← criterio 4/6: honestidad metodológica
│   └── diagramas/
│       ├── job1.mmd  job2.mmd  job3.mmd
│       └── modelo-datos.mmd
│
├── evidencias/                                  ← (estructura completa en §7a)
├── results/
│   └── scaling-results.csv
│
└── src/
    ├── main/
    │   ├── java/cl/duoc/bancoxyz/
    │   │   ├── BancoXyzBatchApplication.java
    │   │   ├── LanzadorJobs.java                        ← CommandLineRunner --job=
    │   │   │
    │   │   ├── config/
    │   │   │   ├── PropiedadesBatch.java                ← @ConfigurationProperties("app.batch")
    │   │   │   ├── TaskExecutorConfig.java              ← poolParticiones(int), valida queueCapacity
    │   │   │   ├── ObservabilidadConfig.java            ← ObservationRegistry + MeterFilter
    │   │   │   └── JdbcConfig.java                      ← JdbcTemplate, NamedParameterJdbcTemplate
    │   │   │
    │   │   ├── common/
    │   │   │   ├── EstadoRegistro.java                  enum VALIDA, ANOMALA_*, …
    │   │   │   ├── MotivoRechazo.java                   enum FECHA_INVALIDA, MONTO_AUSENTE, …
    │   │   │   ├── FaseFallo.java                       enum READ, PROCESS, WRITE, FILTER
    │   │   │   ├── TipoCuenta.java                      enum AHORRO, PRESTAMO, HIPOTECA, DESCONOCIDO
    │   │   │   ├── TipoTransaccion.java                 enum CREDITO, DEBITO, DESCONOCIDO
    │   │   │   ├── TipoMovimiento.java                  enum DEPOSITO, RETIRO, PAGO, COMPRA
    │   │   │   ├── ResultadoProceso.java                sealed interface
    │   │   │   └── RegistroRechazado.java               implements ResultadoProceso
    │   │   │
    │   │   ├── error/
    │   │   │   ├── RegistroInvalidoException.java       extends ValidationException
    │   │   │   ├── FechaIrrecuperableException.java
    │   │   │   ├── ImporteAusenteException.java
    │   │   │   └── CuadraturaException.java
    │   │   │
    │   │   ├── support/
    │   │   │   ├── NormalizadorFecha.java
    │   │   │   ├── NormalizadorTexto.java
    │   │   │   ├── NormalizadorMonto.java
    │   │   │   ├── CalculadoraInteres.java
    │   │   │   └── ClasificadorAnomalias.java
    │   │   │
    │   │   ├── policy/
    │   │   │   ├── BancoXyzSkipPolicy.java
    │   │   │   ├── SkipPolicies.java                    ← ExceptionClassifierSkipPolicy (alternativa)
    │   │   │   ├── RetryPolicies.java                   ← SimpleRetryPolicy(3, mapa, traverseCauses)
    │   │   │   └── BackOffPolicies.java                 ← Exponential / Fixed / NoBackOff
    │   │   │
    │   │   ├── listener/
    │   │   │   ├── DeadLetterSkipListener.java          ← SkipListener + StepExecutionListener
    │   │   │   ├── ResumenStepListener.java             ← ExitStatus COMPLETED_WITH_WARNINGS
    │   │   │   ├── JobTimingListener.java               ← elapsedNanos al ExecutionContext
    │   │   │   ├── ReintentoRetryListener.java          ← org.springframework.retry.RetryListener
    │   │   │   ├── ChunkErrorListener.java              ← afterChunkError
    │   │   │   └── ParticionListener.java               ← log de partición + hilo
    │   │   │
    │   │   ├── partition/
    │   │   │   ├── RangoIdPartitioner.java              ← Job 1, id 1..N
    │   │   │   ├── RangoCuentaPartitioner.java          ← Jobs 2 y 3, + PartitionNameProvider
    │   │   │   └── LineRangePartitioner.java            ← variante por líneas (comparación E9)
    │   │   │
    │   │   ├── writer/
    │   │   │   ├── WritersConfig.java
    │   │   │   ├── ResultadoClassifier.java             ← org.springframework.classify.Classifier
    │   │   │   └── RechazadoWriterFactory.java
    │   │   │
    │   │   ├── tasklet/
    │   │   │   ├── LimpiezaTasklet.java
    │   │   │   ├── CuadraturaTasklet.java
    │   │   │   ├── AlertaCalidadTasklet.java
    │   │   │   └── DeciderCalidadDatos.java             ← JobExecutionDecider
    │   │   │
    │   │   ├── incrementer/
    │   │   │   └── FechaProcesoIncrementer.java
    │   │   │
    │   │   ├── job1transacciones/
    │   │   │   ├── model/TransaccionRaw.java            record (todo String)
    │   │   │   ├── model/Transaccion.java               clase con getters (beanMapped)
    │   │   │   ├── TransaccionProcessor.java
    │   │   │   ├── TransaccionReaderConfig.java         @StepScope, FlatFileItemReader
    │   │   │   ├── TransaccionWriterConfig.java
    │   │   │   ├── ResumenDiarioTasklet.java
    │   │   │   └── Job1TransaccionesConfig.java
    │   │   │
    │   │   ├── job2intereses/
    │   │   │   ├── model/InteresRaw.java
    │   │   │   ├── model/InteresCalculado.java
    │   │   │   ├── model/Cuenta.java
    │   │   │   ├── InteresProcessor.java
    │   │   │   ├── InteresReaderConfig.java
    │   │   │   ├── InteresWriterConfig.java
    │   │   │   ├── ConsolidarSaldosTasklet.java         ← INSERT…SELECT SUM…ON CONFLICT, idempotente
    │   │   │   └── Job2InteresesConfig.java
    │   │   │
    │   │   ├── job3anuales/
    │   │   │   ├── model/MovimientoRaw.java
    │   │   │   ├── model/MovimientoAnual.java
    │   │   │   ├── model/EstadoCuentaAnual.java
    │   │   │   ├── MovimientoAnualProcessor.java
    │   │   │   ├── MovimientoReaderConfig.java
    │   │   │   ├── MovimientoWriterConfig.java
    │   │   │   ├── GenerarEstadosCuentaTasklet.java
    │   │   │   ├── ExportadorEstadosConfig.java         ← JdbcCursorItemReader → FlatFileItemWriter
    │   │   │   └── Job3AnualesConfig.java
    │   │   │
    │   │   └── experiment/
    │   │       ├── EstrategiaEscalado.java
    │   │       ├── CasoExperimento.java
    │   │       ├── ResultadoExperimento.java
    │   │       ├── MatrizExperimentos.java
    │   │       ├── FabricaJobsExperimento.java
    │   │       ├── EjecutorExperimentos.java            ← @Profile("experiment")
    │   │       ├── EscritorResultadosCsv.java
    │   │       ├── LectorMetricasMicrometer.java        ← tags CUALIFICADOS
    │   │       ├── SondaEntorno.java
    │   │       ├── ReseteadorBaseDatos.java
    │   │       └── AmplificadorDataset.java
    │   │
    │   └── resources/
    │       ├── application.yml
    │       ├── application-experiment.yml
    │       ├── application-escenario-pool-chico.yml
    │       ├── schema.sql                               ← DDL de negocio (§9)
    │       ├── data.sql                                 ← (vacío o seed de banco.cuenta)
    │       ├── banner.txt
    │       └── logback-spring.xml                       ← patrón con %X{partition}, archivo por job
    │
    └── test/
        ├── java/cl/duoc/bancoxyz/
        │   ├── support/NormalizadorFechaTest.java
        │   ├── support/NormalizadorTextoTest.java
        │   ├── support/NormalizadorMontoTest.java
        │   ├── support/CalculadoraInteresTest.java
        │   ├── job1transacciones/TransaccionProcessorTest.java
        │   ├── job2intereses/InteresProcessorTest.java
        │   ├── job3anuales/MovimientoAnualProcessorTest.java
        │   ├── policy/BancoXyzSkipPolicyTest.java       ← incluye el caso skipCount = -1
        │   ├── partition/RangoCuentaPartitionerTest.java
        │   ├── integration/Job1IntegrationTest.java     ← @SpringBatchTest + JobLauncherTestUtils
        │   ├── integration/Job2IdempotenciaTest.java
        │   ├── integration/Job3IntegrationTest.java
        │   └── integration/CuadraturaIntegrationTest.java
        └── resources/
            ├── application-test.yml                     ← Testcontainers Postgres
            └── data/mini-*.csv                          ← 20 filas por archivo, defectos representativos
```

---

# 9. ESQUEMA SQL COMPLETO (DDL PostgreSQL)

`src/main/resources/schema.sql` — idempotente, ejecutable N veces.

```sql
-- =====================================================================
-- Banco XYZ — esquema de negocio  (PostgreSQL 17)
-- Exp1 S3 · Desarrollo Backend III (PBY2203)
-- Convención: dinero = NUMERIC(15,2) / agregados NUMERIC(18,2). NUNCA float.
--             se conserva SIEMPRE el valor crudo original (*_original).
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS banco;
CREATE SCHEMA IF NOT EXISTS batch_meta;   -- aquí van las BATCH_* de Spring Batch

-- ---------------------------------------------------------------------
-- 0. DEAD LETTER — común a los 3 jobs.  Regla de oro: entrada = negocio + rechazos
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS banco.registro_rechazado (
    id                BIGSERIAL     PRIMARY KEY,
    archivo_origen    VARCHAR(40)   NOT NULL,
    job_name          VARCHAR(60)   NOT NULL,
    job_execution_id  BIGINT        NOT NULL,
    step_name         VARCHAR(100)  NOT NULL,
    particion         VARCHAR(40),
    fase              VARCHAR(10)   NOT NULL,
    numero_linea      BIGINT        NOT NULL DEFAULT -1,
    clave_natural     VARCHAR(80),
    motivo            VARCHAR(40)   NOT NULL,
    campo             VARCHAR(40),
    valor_crudo       VARCHAR(200),
    linea_cruda       TEXT          NOT NULL,
    excepcion         VARCHAR(255)  NOT NULL,
    mensaje           TEXT,
    creado_en         TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CONSTRAINT ck_rechazo_fase   CHECK (fase IN ('READ','PROCESS','WRITE','FILTER')),
    CONSTRAINT ck_rechazo_motivo CHECK (motivo IN (
        'FECHA_INVALIDA','MONTO_AUSENTE','MONTO_NO_NUMERICO','SALDO_AUSENTE',
        'SALDO_NO_NUMERICO','DUPLICADO','CUENTA_INEXISTENTE','TIPO_AUSENTE',
        'LINEA_MALFORMADA','ERROR_ESCRITURA','OTRO'))
);
CREATE INDEX IF NOT EXISTS ix_rechazo_job     ON banco.registro_rechazado(job_execution_id);
CREATE INDEX IF NOT EXISTS ix_rechazo_archivo ON banco.registro_rechazado(archivo_origen, motivo);
CREATE INDEX IF NOT EXISTS ix_rechazo_fase    ON banco.registro_rechazado(step_name, fase);

-- ---------------------------------------------------------------------
-- 0b. CONTROL DE CARGA — la cuadratura persistida (la escribe CuadraturaTasklet)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS banco.control_carga (
    id                BIGSERIAL    PRIMARY KEY,
    archivo_origen    VARCHAR(40)  NOT NULL,
    job_name          VARCHAR(60)  NOT NULL,
    job_execution_id  BIGINT       NOT NULL,
    filas_entrada     BIGINT       NOT NULL,
    filas_negocio     BIGINT       NOT NULL,
    filas_rechazadas  BIGINT       NOT NULL,
    filas_filtradas   BIGINT       NOT NULL DEFAULT 0,
    cuadra            BOOLEAN      GENERATED ALWAYS AS
                        (filas_entrada = filas_negocio + filas_rechazadas + filas_filtradas) STORED,
    duracion_ms       BIGINT,
    verificado_en     TIMESTAMPTZ  NOT NULL DEFAULT now(),
    CONSTRAINT uq_control UNIQUE (job_execution_id, archivo_origen)
);

-- =====================================================================
-- JOB 1 — Reporte de Transacciones Diarias
-- =====================================================================
CREATE TABLE IF NOT EXISTS banco.transaccion (
    id                BIGINT        PRIMARY KEY,                  -- id 1..1000, único en el CSV
    fecha             DATE          NOT NULL,
    fecha_original    VARCHAR(20)   NOT NULL,
    formato_fecha     VARCHAR(12)   NOT NULL,                     -- patrón que sí parseó
    monto             NUMERIC(15,2) NOT NULL,
    monto_original    VARCHAR(20)   NOT NULL,
    tipo              VARCHAR(12)   NOT NULL,
    tipo_original     VARCHAR(30)   NOT NULL,
    estado            VARCHAR(32)   NOT NULL,
    anomalias         VARCHAR(160)  NOT NULL DEFAULT '',          -- lista separada por coma
    es_anomala        BOOLEAN       GENERATED ALWAYS AS (estado <> 'VALIDA') STORED,
    numero_linea      BIGINT        NOT NULL,
    job_execution_id  BIGINT        NOT NULL,
    procesado_en      TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CONSTRAINT ck_tx_tipo   CHECK (tipo   IN ('CREDITO','DEBITO','DESCONOCIDO')),
    CONSTRAINT ck_tx_estado CHECK (estado IN ('VALIDA','ANOMALA_TIPO_DESCONOCIDO',
                                              'ANOMALA_MONTO_NEGATIVO','ANOMALA_MONTO_CERO',
                                              'ANOMALA_MONTO_ALTO','ANOMALA_MULTIPLE')),
    CONSTRAINT ck_tx_formato CHECK (formato_fecha IN
                                    ('yyyy-MM-dd','dd-MM-yyyy','dd/MM/yyyy','yyyy/MM/dd'))
);
CREATE INDEX IF NOT EXISTS ix_tx_fecha  ON banco.transaccion(fecha);
CREATE INDEX IF NOT EXISTS ix_tx_estado ON banco.transaccion(estado);
CREATE INDEX IF NOT EXISTS ix_tx_job    ON banco.transaccion(job_execution_id);

CREATE TABLE IF NOT EXISTS banco.resumen_diario (
    fecha              DATE          PRIMARY KEY,
    total_operaciones  INTEGER       NOT NULL,
    n_creditos         INTEGER       NOT NULL DEFAULT 0,
    n_debitos          INTEGER       NOT NULL DEFAULT 0,
    n_tipo_desconocido INTEGER       NOT NULL DEFAULT 0,
    monto_total        NUMERIC(18,2) NOT NULL DEFAULT 0,
    monto_creditos     NUMERIC(18,2) NOT NULL DEFAULT 0,
    monto_debitos      NUMERIC(18,2) NOT NULL DEFAULT 0,
    monto_promedio     NUMERIC(18,4) NOT NULL DEFAULT 0,
    monto_maximo       NUMERIC(15,2),
    n_anomalas         INTEGER       NOT NULL DEFAULT 0,
    n_rechazadas       INTEGER       NOT NULL DEFAULT 0,   -- sólo rechazos con fecha recuperable
    job_execution_id   BIGINT        NOT NULL,
    generado_en        TIMESTAMPTZ   NOT NULL DEFAULT now()
);
COMMENT ON COLUMN banco.resumen_diario.n_rechazadas IS
  'Rechazos imputables a esta fecha. Los rechazos por FECHA_INVALIDA no tienen fecha '
  'y sólo aparecen en banco.control_carga (cuadratura global).';

-- =====================================================================
-- JOB 2 — Cálculo de Intereses Mensuales
-- =====================================================================
CREATE TABLE IF NOT EXISTS banco.cuenta (
    cuenta_id          INTEGER       PRIMARY KEY,      -- 101..150 (PK obligatoria para ON CONFLICT)
    nombre             VARCHAR(120)  NOT NULL DEFAULT 'DESCONOCIDO',
    tipo_predominante  VARCHAR(14)   NOT NULL DEFAULT 'DESCONOCIDO',
    n_posiciones       INTEGER       NOT NULL DEFAULT 0,
    saldo_inicial      NUMERIC(18,2) NOT NULL DEFAULT 0,
    interes_aplicado   NUMERIC(18,2) NOT NULL DEFAULT 0,
    saldo              NUMERIC(18,2) NOT NULL DEFAULT 0,
    periodo_aplicado   VARCHAR(7),                     -- 'yyyy-MM' — GUARDA DE IDEMPOTENCIA
    job_execution_id   BIGINT,
    actualizado_en     TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CONSTRAINT ck_cuenta_tipo CHECK (tipo_predominante IN
                                     ('AHORRO','PRESTAMO','HIPOTECA','DESCONOCIDO')),
    CONSTRAINT ck_cuenta_saldo CHECK (saldo = saldo_inicial + interes_aplicado)
);

CREATE TABLE IF NOT EXISTS banco.interes_calculado (
    id                BIGSERIAL     PRIMARY KEY,
    periodo           VARCHAR(7)    NOT NULL,          -- 'yyyy-MM'
    cuenta_id         INTEGER       NOT NULL,
    nombre            VARCHAR(120)  NOT NULL,
    nombre_original   VARCHAR(120)  NOT NULL,
    edad              INTEGER,                          -- NULL si estaba fuera de rango o vacía
    edad_original     VARCHAR(10)   NOT NULL DEFAULT '',
    tipo              VARCHAR(14)   NOT NULL,
    tipo_original     VARCHAR(30)   NOT NULL,
    saldo_inicial     NUMERIC(15,2) NOT NULL,
    saldo_original    VARCHAR(20)   NOT NULL,
    tasa              NUMERIC(7,5)  NOT NULL,           -- 0 si el tipo es DESCONOCIDO
    interes           NUMERIC(15,2) NOT NULL,
    saldo_final       NUMERIC(15,2) GENERATED ALWAYS AS (saldo_inicial + interes) STORED,
    estado            VARCHAR(32)   NOT NULL,
    anomalias         VARCHAR(160)  NOT NULL DEFAULT '',
    numero_linea      BIGINT        NOT NULL,
    job_execution_id  BIGINT        NOT NULL,
    creado_en         TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CONSTRAINT ck_int_tipo   CHECK (tipo IN ('AHORRO','PRESTAMO','HIPOTECA','DESCONOCIDO')),
    CONSTRAINT ck_int_edad   CHECK (edad IS NULL OR edad BETWEEN 18 AND 99),
    CONSTRAINT ck_int_tasa   CHECK (tasa >= 0 AND tasa < 1),
    CONSTRAINT ck_int_estado CHECK (estado IN ('VALIDA','ANOMALA_TIPO_DESCONOCIDO',
                                               'ANOMALA_EDAD_FUERA_RANGO','ANOMALA_NOMBRE_DESCONOCIDO',
                                               'ANOMALA_MULTIPLE')),
    -- Dispara DuplicateKeyException para las 9 filas 100% duplicadas (escenario E4).
    -- Campos CRUDOS y NOT NULL: en Postgres los NULL no colisionan en un UNIQUE.
    CONSTRAINT uq_interes_posicion UNIQUE
        (periodo, cuenta_id, nombre_original, saldo_original, edad_original, tipo_original)
);
CREATE INDEX IF NOT EXISTS ix_int_cuenta ON banco.interes_calculado(periodo, cuenta_id);
CREATE INDEX IF NOT EXISTS ix_int_job    ON banco.interes_calculado(job_execution_id);

-- =====================================================================
-- JOB 3 — Estados de Cuenta Anuales
-- =====================================================================
CREATE TABLE IF NOT EXISTS banco.movimiento_anual (
    id                    BIGSERIAL     PRIMARY KEY,
    cuenta_id             INTEGER       NOT NULL,          -- 101..120
    fecha                 DATE          NOT NULL,
    fecha_original        VARCHAR(20)   NOT NULL,
    formato_fecha         VARCHAR(12)   NOT NULL,
    anio                  INTEGER       GENERATED ALWAYS AS (EXTRACT(YEAR FROM fecha)::INT) STORED,
    transaccion           VARCHAR(12)   NOT NULL,          -- normalizado sin tildes, mayúsculas
    transaccion_original  VARCHAR(30)   NOT NULL,          -- conserva 'depósito' con tilde
    signo                 SMALLINT      NOT NULL,          -- +1 DEPOSITO ; -1 RETIRO/PAGO/COMPRA
    monto                 NUMERIC(15,2) NOT NULL,          -- valor absoluto
    monto_original        VARCHAR(20)   NOT NULL,
    monto_con_signo       NUMERIC(15,2) GENERATED ALWAYS AS ((signo * monto)::NUMERIC(15,2)) STORED,
    descripcion           VARCHAR(255)  NOT NULL DEFAULT 'SIN DESCRIPCION',
    estado                VARCHAR(32)   NOT NULL,
    anomalias             VARCHAR(160)  NOT NULL DEFAULT '',
    numero_linea          BIGINT        NOT NULL,
    job_execution_id      BIGINT        NOT NULL,
    procesado_en          TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CONSTRAINT ck_mov_tipo  CHECK (transaccion IN ('DEPOSITO','RETIRO','PAGO','COMPRA')),
    CONSTRAINT ck_mov_signo CHECK (signo IN (-1, 1)),
    CONSTRAINT ck_mov_monto CHECK (monto >= 0),
    CONSTRAINT ck_mov_estado CHECK (estado IN ('VALIDA','ANOMALA_MONTO_NEGATIVO','ANOMALA_MONTO_CERO',
                                               'ANOMALA_SIGNO_CONTRADICTORIO','ANOMALA_DESCRIPCION_AUSENTE',
                                               'ANOMALA_MULTIPLE'))
);
CREATE INDEX IF NOT EXISTS ix_mov_cuenta_anio ON banco.movimiento_anual(cuenta_id, anio);
CREATE INDEX IF NOT EXISTS ix_mov_job         ON banco.movimiento_anual(job_execution_id);

CREATE TABLE IF NOT EXISTS banco.estado_cuenta_anual (
    cuenta_id        INTEGER       NOT NULL,
    anio             INTEGER       NOT NULL,
    n_movimientos    INTEGER       NOT NULL DEFAULT 0,
    n_depositos      INTEGER       NOT NULL DEFAULT 0,
    n_retiros        INTEGER       NOT NULL DEFAULT 0,
    n_pagos          INTEGER       NOT NULL DEFAULT 0,
    n_compras        INTEGER       NOT NULL DEFAULT 0,
    total_depositos  NUMERIC(18,2) NOT NULL DEFAULT 0,
    total_retiros    NUMERIC(18,2) NOT NULL DEFAULT 0,
    total_pagos      NUMERIC(18,2) NOT NULL DEFAULT 0,
    total_compras    NUMERIC(18,2) NOT NULL DEFAULT 0,
    saldo_neto       NUMERIC(18,2) NOT NULL DEFAULT 0,     -- SUM(monto_con_signo)
    n_anomalias      INTEGER       NOT NULL DEFAULT 0,
    primera_fecha    DATE,
    ultima_fecha     DATE,
    job_execution_id BIGINT        NOT NULL,
    generado_en      TIMESTAMPTZ   NOT NULL DEFAULT now(),
    PRIMARY KEY (cuenta_id, anio),
    CONSTRAINT ck_eca_saldo CHECK (saldo_neto = total_depositos
                                   - total_retiros - total_pagos - total_compras)
);

-- =====================================================================
-- MÉTRICAS DE ESCALADO (criterio 4 — evidencia también en BD, no sólo en CSV)
-- =====================================================================
CREATE TABLE IF NOT EXISTS banco.ejecucion_metrica (
    id                BIGSERIAL    PRIMARY KEY,
    job_name          VARCHAR(60)  NOT NULL,
    fase              VARCHAR(20)  NOT NULL,        -- F0-baseline | F1-parallel | F2-confirm
    estrategia        VARCHAR(20)  NOT NULL,        -- SECUENCIAL | MULTI_THREAD | PARTICIONADO
    paralelismo       INTEGER      NOT NULL,
    chunk_size        INTEGER      NOT NULL,
    dataset_filas     INTEGER      NOT NULL,
    repeticion        INTEGER      NOT NULL,
    warmup            BOOLEAN      NOT NULL DEFAULT false,
    wall_clock_ms     BIGINT       NOT NULL,
    job_exec_ms       BIGINT,
    read_count        BIGINT       NOT NULL DEFAULT 0,
    write_count       BIGINT       NOT NULL DEFAULT 0,
    filter_count      BIGINT       NOT NULL DEFAULT 0,
    skip_count        BIGINT       NOT NULL DEFAULT 0,
    commit_count      BIGINT       NOT NULL DEFAULT 0,
    rollback_count    BIGINT       NOT NULL DEFAULT 0,
    max_particion_ms  BIGINT,
    sum_particion_ms  BIGINT,
    skew              NUMERIC(6,3),                 -- max(readCount)/avg(readCount)
    ratio_max_min     NUMERIC(6,3),
    hikari_pool_size  INTEGER      NOT NULL,
    cpus              INTEGER      NOT NULL,
    heap_max_mb       INTEGER      NOT NULL,
    batch_status      VARCHAR(20)  NOT NULL,
    job_execution_id  BIGINT,
    creado_en         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    CONSTRAINT ck_metrica_estrategia CHECK (estrategia IN ('SECUENCIAL','MULTI_THREAD','PARTICIONADO'))
);
CREATE INDEX IF NOT EXISTS ix_metrica_celda
    ON banco.ejecucion_metrica(job_name, estrategia, paralelismo, chunk_size, dataset_filas);

-- =====================================================================
-- VISTAS DE VERIFICACIÓN
-- =====================================================================
CREATE OR REPLACE VIEW banco.v_cuadratura AS
SELECT 'transacciones.csv' AS archivo,
       (SELECT COUNT(*) FROM banco.transaccion)                                       AS negocio,
       (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='transacciones.csv') AS rechazos,
       (SELECT COUNT(*) FROM banco.transaccion)
     + (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='transacciones.csv') AS total
UNION ALL
SELECT 'intereses.csv',
       (SELECT COUNT(*) FROM banco.interes_calculado),
       (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='intereses.csv'),
       (SELECT COUNT(*) FROM banco.interes_calculado)
     + (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='intereses.csv')
UNION ALL
SELECT 'cuentas_anuales.csv',
       (SELECT COUNT(*) FROM banco.movimiento_anual),
       (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='cuentas_anuales.csv'),
       (SELECT COUNT(*) FROM banco.movimiento_anual)
     + (SELECT COUNT(*) FROM banco.registro_rechazado WHERE archivo_origen='cuentas_anuales.csv');

CREATE OR REPLACE VIEW banco.v_anomalias_transaccion AS
SELECT t.id, t.fecha, t.estado, TRIM(a) AS anomalia
FROM banco.transaccion t,
     LATERAL UNNEST(STRING_TO_ARRAY(NULLIF(t.anomalias,''), ',')) AS a;

CREATE OR REPLACE VIEW banco.v_resumen_ejecutivo AS
SELECT ji.JOB_NAME,
       je.JOB_EXECUTION_ID,
       je.STATUS,
       je.START_TIME,
       EXTRACT(EPOCH FROM (je.END_TIME - je.START_TIME)) * 1000 AS duracion_ms,
       SUM(se.READ_COUNT)  AS leidos,
       SUM(se.WRITE_COUNT) AS escritos,
       SUM(se.FILTER_COUNT) AS filtrados,
       SUM(se.READ_SKIP_COUNT + se.PROCESS_SKIP_COUNT + se.WRITE_SKIP_COUNT) AS omitidos,
       SUM(se.COMMIT_COUNT)   AS commits,
       SUM(se.ROLLBACK_COUNT) AS rollbacks
FROM batch_meta.BATCH_JOB_EXECUTION je
JOIN batch_meta.BATCH_JOB_INSTANCE  ji USING (JOB_INSTANCE_ID)
JOIN batch_meta.BATCH_STEP_EXECUTION se USING (JOB_EXECUTION_ID)
GROUP BY ji.JOB_NAME, je.JOB_EXECUTION_ID, je.STATUS, je.START_TIME, je.END_TIME
ORDER BY je.JOB_EXECUTION_ID DESC;
```

**SQL del `ConsolidarSaldosTasklet` (Job 2, idempotente — escenario E15):**

```sql
INSERT INTO banco.cuenta AS c
      (cuenta_id, nombre, tipo_predominante, n_posiciones,
       saldo_inicial, interes_aplicado, saldo, periodo_aplicado, job_execution_id, actualizado_en)
SELECT i.cuenta_id,
       MODE() WITHIN GROUP (ORDER BY i.nombre)             AS nombre,
       MODE() WITHIN GROUP (ORDER BY i.tipo)               AS tipo_predominante,
       COUNT(*)                                            AS n_posiciones,
       SUM(i.saldo_inicial)                                AS saldo_inicial,
       SUM(i.interes)                                      AS interes_aplicado,
       SUM(i.saldo_inicial) + SUM(i.interes)               AS saldo,
       :periodo, :jobExecutionId, now()
  FROM banco.interes_calculado i
 WHERE i.periodo = :periodo
 GROUP BY i.cuenta_id
ON CONFLICT (cuenta_id) DO UPDATE
   SET nombre            = EXCLUDED.nombre,
       tipo_predominante = EXCLUDED.tipo_predominante,
       n_posiciones      = EXCLUDED.n_posiciones,
       saldo_inicial     = EXCLUDED.saldo_inicial,
       interes_aplicado  = EXCLUDED.interes_aplicado,
       saldo             = EXCLUDED.saldo,
       periodo_aplicado  = EXCLUDED.periodo_aplicado,
       job_execution_id  = EXCLUDED.job_execution_id,
       actualizado_en    = now()
 WHERE c.periodo_aplicado IS DISTINCT FROM EXCLUDED.periodo_aplicado;  -- ← GUARDA DE IDEMPOTENCIA
```

> Una sola sentencia agregada ⇒ **imposible** la *cardinality violation* de `ON CONFLICT DO UPDATE` que provocarían las ~20 filas por `cuenta_id` si se hiciera fila a fila desde el writer. Y el `WHERE` final hace que una segunda ejecución del mismo periodo **no toque nada**.

**SQL del `ResumenDiarioTasklet` (Job 1):**

```sql
INSERT INTO banco.resumen_diario
      (fecha, total_operaciones, n_creditos, n_debitos, n_tipo_desconocido,
       monto_total, monto_creditos, monto_debitos, monto_promedio, monto_maximo,
       n_anomalas, n_rechazadas, job_execution_id, generado_en)
SELECT t.fecha,
       COUNT(*),
       COUNT(*) FILTER (WHERE t.tipo='CREDITO'),
       COUNT(*) FILTER (WHERE t.tipo='DEBITO'),
       COUNT(*) FILTER (WHERE t.tipo='DESCONOCIDO'),
       SUM(t.monto),
       COALESCE(SUM(t.monto) FILTER (WHERE t.tipo='CREDITO'), 0),
       COALESCE(SUM(t.monto) FILTER (WHERE t.tipo='DEBITO'), 0),
       ROUND(AVG(t.monto), 4),
       MAX(t.monto),
       COUNT(*) FILTER (WHERE t.es_anomala),
       0,
       :jobExecutionId, now()
  FROM banco.transaccion t
 WHERE t.job_execution_id = :jobExecutionId
 GROUP BY t.fecha
ON CONFLICT (fecha) DO UPDATE
   SET total_operaciones = EXCLUDED.total_operaciones,
       n_creditos = EXCLUDED.n_creditos, n_debitos = EXCLUDED.n_debitos,
       n_tipo_desconocido = EXCLUDED.n_tipo_desconocido,
       monto_total = EXCLUDED.monto_total, monto_creditos = EXCLUDED.monto_creditos,
       monto_debitos = EXCLUDED.monto_debitos, monto_promedio = EXCLUDED.monto_promedio,
       monto_maximo = EXCLUDED.monto_maximo, n_anomalas = EXCLUDED.n_anomalas,
       job_execution_id = EXCLUDED.job_execution_id, generado_en = now();
```

**SQL del `GenerarEstadosCuentaTasklet` (Job 3):**

```sql
INSERT INTO banco.estado_cuenta_anual
      (cuenta_id, anio, n_movimientos, n_depositos, n_retiros, n_pagos, n_compras,
       total_depositos, total_retiros, total_pagos, total_compras, saldo_neto,
       n_anomalias, primera_fecha, ultima_fecha, job_execution_id, generado_en)
SELECT m.cuenta_id, m.anio, COUNT(*),
       COUNT(*) FILTER (WHERE m.transaccion='DEPOSITO'),
       COUNT(*) FILTER (WHERE m.transaccion='RETIRO'),
       COUNT(*) FILTER (WHERE m.transaccion='PAGO'),
       COUNT(*) FILTER (WHERE m.transaccion='COMPRA'),
       COALESCE(SUM(m.monto) FILTER (WHERE m.transaccion='DEPOSITO'), 0),
       COALESCE(SUM(m.monto) FILTER (WHERE m.transaccion='RETIRO'),   0),
       COALESCE(SUM(m.monto) FILTER (WHERE m.transaccion='PAGO'),     0),
       COALESCE(SUM(m.monto) FILTER (WHERE m.transaccion='COMPRA'),   0),
       SUM(m.monto_con_signo),
       COUNT(*) FILTER (WHERE m.estado <> 'VALIDA'),
       MIN(m.fecha), MAX(m.fecha), :jobExecutionId, now()
  FROM banco.movimiento_anual m
 WHERE m.job_execution_id = :jobExecutionId
 GROUP BY m.cuenta_id, m.anio
ON CONFLICT (cuenta_id, anio) DO UPDATE
   SET n_movimientos = EXCLUDED.n_movimientos, n_depositos = EXCLUDED.n_depositos,
       n_retiros = EXCLUDED.n_retiros, n_pagos = EXCLUDED.n_pagos, n_compras = EXCLUDED.n_compras,
       total_depositos = EXCLUDED.total_depositos, total_retiros = EXCLUDED.total_retiros,
       total_pagos = EXCLUDED.total_pagos, total_compras = EXCLUDED.total_compras,
       saldo_neto = EXCLUDED.saldo_neto, n_anomalias = EXCLUDED.n_anomalias,
       primera_fecha = EXCLUDED.primera_fecha, ultima_fecha = EXCLUDED.ultima_fecha,
       job_execution_id = EXCLUDED.job_execution_id, generado_en = now();
```

> ⚠️ Las columnas `GENERATED ALWAYS AS … STORED` (`es_anomala`, `anio`, `monto_con_signo`, `saldo_final`, `cuadra`) **no pueden aparecer** en la lista de columnas de los `INSERT` del `JdbcBatchItemWriter`. Es un error de arranque fácil de cometer y difícil de leer.

---

# 10. VERIFICACIONES OBLIGATORIAS ANTES DE DAR NADA POR HECHO

Cinco cosas que este documento asume y que debes comprobar tú en tu máquina, porque si fallan invalidan bloques enteros:

1. **`./mvnw dependency:tree`** debe mostrar `spring-batch-core:5.2.6`. Si tu Boot resuelve otra versión, la mitad de las firmas de este documento cambia (`chunk(int)` vs `chunk(int, tm)`, paquetes `item.*` vs `infrastructure.item.*`).
2. **Arranque con `table-prefix: batch_meta.BATCH_`**: comprueba que las 6 tablas quedan en `batch_meta` y no en `public`. Si falla, cae al plan B (BATCH_* en `public`, sin prefijo calificado) — cuesta 0 puntos y ahorra una tarde.
3. **`GET /actuator/metrics`**: pega la salida literal antes de escribir una línea del runner de experimentos. Si `spring.batch.chunk.write` no aparece con los tags cualificados, tu CSV saldrá con columnas vacías **sin ningún error**.
4. **Conteos esperados de `intereses.csv` y `cuentas_anuales.csv`** con la precedencia de §0.1 (los de `transacciones.csv` ya están verificados en `docs/analisis-datos.md`). El solapamiento entre defectos cambia los números y no se puede deducir a ojo.
5. **Los 9 duplicados de `intereses.csv`**: verifica cuántos de ellos tienen además `saldo` vacío. Con la precedencia elegida (`SALDO_AUSENTE` antes que `DUPLICADO`) esos se rechazan por saldo y el conteo de `DUPLICADO` será < 9. Mide el número real antes de publicarlo como "salida esperada".