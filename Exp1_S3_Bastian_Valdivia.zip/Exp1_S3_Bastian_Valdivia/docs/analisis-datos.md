# Análisis del dataset legacy — Banco XYZ

Fuente: https://github.com/KariVillagran/bank_legacy_data → carpeta `data/semana_3/`
(las carpetas `semana_1` y `semana_2` traen ~10 filas; **la de esta entrega es `semana_3`, con 1000 filas por archivo**).

Este documento no es teoría: son las cifras reales medidas sobre los CSV. Cada regla de validación
del proyecto debe poder justificarse con una línea de esta tabla.

---

## 1. `transacciones.csv` — 1.000 filas

Columnas: `id, fecha, monto, tipo`

| Campo | Hallazgo | Nº filas |
|---|---|---|
| `id` | 1..1000, **sin duplicados**, sin huecos | 1000 |
| `fecha` | formato `dd-MM-yyyy` | 250 |
| | formato `yyyy-MM-dd` (ISO) válida | 239 |
| | formato `dd/MM/yyyy` | 234 |
| | formato `yyyy/MM/dd` | 222 |
| | **`2024-13-01` → mes 13, irrecuperable** | 55 |
| `monto` | positivo | 673 |
| | **vacío** | 168 |
| | **negativo** (`-100`, `-200`) | 141 |
| | **cero** | 18 |
| `tipo` | `credito` | 316 |
| | `debito` | 313 |
| | **`invalid`** | 308 |
| | **`desconocido`** | 63 |

- Valores de monto observados: `-200, -100, 0, 500, 700, 800, 1000, 1200, 1500, 3000`.
- Rango de fechas real: **2024-01-01 … 2024-12-30** (todo el año 2024).
- Filas sin ningún defecto: **401 de 1000** → el 59,9 % trae al menos un problema.

## 2. `intereses.csv` — 1.000 filas

Columnas: `cuenta_id, nombre, saldo, edad, tipo`

| Campo | Hallazgo | Nº filas |
|---|---|---|
| `cuenta_id` | rango **101..150** = 50 cuentas; entre 12 y 33 filas por cuenta | 1000 |
| `nombre` | 7 nombres reales + **`Unknown`** | 50 |
| `saldo` | valores discretos `5000, 7000, 8000, 10000, 12000` | 789 |
| | **vacío** | 211 |
| `edad` | válida (25/30/35/40/45) | 635 |
| | **vacía** | 193 |
| | **`100`** (fuera de rango) | 120 |
| | **`150`** (imposible) | 52 |
| `tipo` | **`-1`** | 279 |
| | `prestamo` | 226 |
| | `hipoteca` | 224 |
| | `ahorro` | 219 |
| | **`unknown`** | 52 |

- **9 filas están duplicadas al 100 %** (todos los campos idénticos) → único archivo con duplicados exactos.
- Filas sin ningún defecto: **305 de 1000** → el 69,5 % trae al menos un problema.

## 3. `cuentas_anuales.csv` — 1.000 filas

Columnas: `cuenta_id, fecha, transaccion, monto, descripcion`

| Campo | Hallazgo | Nº filas |
|---|---|---|
| `cuenta_id` | rango **101..120** = 20 cuentas; entre 39 y 60 filas por cuenta | 1000 |
| `fecha` | `dd-MM-yyyy` | 255 |
| | `yyyy-MM-dd` | 253 |
| | `yyyy/MM/dd` | 246 |
| | `dd/MM/yyyy` | 246 |
| | irrecuperables | **0** |
| `transaccion` | `compra` | 314 |
| | `deposito` | 296 |
| | `retiro` | 296 |
| | **`depósito` (con tilde)** — mismo concepto, distinta grafía | 52 |
| | `pago` | 42 |
| `monto` | positivo | 686 |
| | **negativo** | 254 |
| | **vacío** | 48 |
| | **cero** | 12 |
| `descripcion` | **vacía** | 230 |

---

## 4. Dos conclusiones que definen el diseño

### 4.1 El formato de fecha con barras/guiones es `dd`, no `MM`

Hay **302 filas en `transacciones.csv` y 301 en `cuentas_anuales.csv`** cuyo primer componente es
mayor que 12 (`24-07-2024`, `30-07-2024`), y **cero** filas cuyo segundo componente supere 12.
Por tanto el patrón es inequívocamente `dd-MM-yyyy` / `dd/MM/yyyy`, nunca `MM/dd/yyyy`.

Esto no es un detalle menor: si se asume `MM/dd/yyyy` el parseo revienta en 300 filas por archivo.
El normalizador debe probar los 4 patrones en orden y quedarse con el primero que parsee.

### 4.2 Validar ≠ descartar — y aquí se juega la nota

Si se aplica una validación estricta que rechaza toda fila con cualquier defecto, sobreviven:

| Archivo | Filas limpias | Se perdería |
|---|---|---|
| `transacciones.csv` | 401 / 1000 | 59,9 % |
| `intereses.csv` | 305 / 1000 | 69,5 % |
| `cuentas_anuales.csv` | 686 / 1000 (monto y fecha) | 31,4 % |

Pero el criterio 2 de la pauta exige *"procesando **todos** los datos de entrada y generando la
salida esperada en la base de datos"*. Tirar el 60-70 % de las filas al vacío es exactamente lo que
hace bajar ese criterio a 12 o 9 puntos.

**La regla de oro del proyecto: ninguna fila desaparece en silencio.** Cada registro de entrada
termina en uno de dos sitios, y la suma siempre da 1000:

1. **Tabla de negocio**, si es válida o *reparable* (fecha normalizada, `depósito`→`deposito`).
2. **Tabla de rechazados/anomalías**, con `motivo`, `campo` y la línea original, si es irrecuperable.

Clasificación de los defectos por tratamiento:

| Tratamiento | Defecto | Qué se hace |
|---|---|---|
| **Reparar** | 4 formatos de fecha | normalizar a `LocalDate` ISO |
| **Reparar** | `depósito` vs `deposito` | normalizar acentos y minúsculas |
| **Reparar** | `descripcion` vacía (230) | rellenar con literal `SIN DESCRIPCION` |
| **Marcar** | monto negativo (141 / 254) | se guarda con estado `ANOMALA_MONTO_NEGATIVO` — *es justamente la anomalía que el Job 1 debe reportar* |
| **Marcar** | monto cero (18 / 12) | estado `ANOMALA_MONTO_CERO` |
| **Marcar** | `tipo` = `invalid`/`desconocido`/`-1`/`unknown` | estado `ANOMALA_TIPO_DESCONOCIDO`, tipo canónico `DESCONOCIDO` |
| **Marcar** | `edad` 100/150 o vacía | estado `ANOMALA_EDAD_FUERA_RANGO`, no se usa para segmentar |
| **Rechazar** | fecha `2024-13-01` (55) | a tabla de rechazados, motivo `FECHA_INVALIDA` |
| **Rechazar** | `monto` vacío (168 / 48) | a tabla de rechazados, motivo `MONTO_AUSENTE` |
| **Rechazar** | `saldo` vacío (211) | a tabla de rechazados, motivo `SALDO_AUSENTE` — sin saldo no hay interés que calcular |
| **Deduplicar** | 9 filas idénticas en `intereses.csv` | descartar la repetida, motivo `DUPLICADO` |

Reparto resultante para `transacciones.csv` aplicando estas reglas (verificado, suma exacta 1000):

```
VALIDA                     401
ANOMALA_TIPO_DESCONOCIDO   230
RECHAZADA_MONTO_AUSENTE    160
ANOMALA_MONTO_NEGATIVO     136
RECHAZADA_FECHA_INVALIDA    55
ANOMALA_MONTO_CERO          18
                          ----
TOTAL                     1000   ← ninguna fila se pierde
```

Esa cuadratura (`entrada = negocio + rechazos`) es la consulta SQL que hay que enseñar como
evidencia: demuestra de un golpe el criterio 2 (procesa todo) y el criterio 3 (valida bien).

---

## 5. Cómo se reparte el trabajo para particionar

El particionado necesita una clave numérica contigua. Los tres archivos la tienen:

| Job | Clave de partición | Rango | Reparto natural |
|---|---|---|---|
| Transacciones diarias | `id` | 1..1000 | gridSize 4 → 250 filas por partición |
| Intereses mensuales | `cuenta_id` | 101..150 (50 cuentas) | gridSize 5 → 10 cuentas por partición |
| Estados de cuenta anuales | `cuenta_id` | 101..120 (20 cuentas) | gridSize 4 → 5 cuentas por partición |

Particionar por `cuenta_id` en los Jobs 2 y 3 tiene además una ventaja semántica: como la
agregación es *por cuenta*, cada partición contiene cuentas completas y puede consolidar sin
depender de las demás. Si se particionara por número de línea, una misma cuenta quedaría partida
entre dos hilos y la agregación daría resultados incorrectos.

> Ojo con el desbalanceo: en `intereses.csv` hay cuentas con 12 filas y otras con 33. Las
> particiones no quedan iguales, y eso se ve en los tiempos por partición del log. Es un buen dato
> para comentar en el informe de comparación de parámetros.

---

## 6. Repartos esperados (verificados) — la "salida esperada" del criterio 2

Estos son los números que produce `scripts/perfilar-dataset.sh` y que deben coincidir
**exactamente** con lo que quede en PostgreSQL. Si no coinciden, hay un bug.

Reproducibles con:

```bash
./scripts/perfilar-dataset.sh
```

### Regla de precedencia (corregida)

Cada fila cae en **una sola** casilla: la primera regla que se cumple. Este es el orden real
que implementa `TransaccionProcessor`, y el que produce los números publicados:

```
1. FECHA_INVALIDA        -> rechazo (dead letter)
2. MONTO/SALDO AUSENTE   -> rechazo
3. MONTO/SALDO NO NUMERICO -> rechazo
4. DUPLICADO             -> rechazo (solo intereses.csv)
5. MONTO NEGATIVO        -> se guarda, marcada
6. MONTO CERO            -> se guarda, marcada
7. TIPO DESCONOCIDO      -> se guarda, marcada
8. VALIDA
```

> **Corrección al plan maestro.** El §0.1 de `plan-maestro.md` documenta esta lista con el
> tipo en la posición 4 y los montos en la 5 y 6, es decir, al revés. Ese orden **no** produce
> los números que el propio plan publica: daría `TIPO_DESCONOCIDO 294 / MONTO_NEGATIVO 81 /
> MONTO_CERO 9` en vez de `230 / 136 / 18`. Son las mismas 64 filas contadas en otra casilla.
> El código es el correcto; la lista del §0.1 está mal.

Además del estado (excluyente), cada fila guarda en la columna `anomalias` **todos** sus
defectos separados por coma. Por eso las dos tablas de abajo no suman igual: una fila con
monto negativo y tipo desconocido aporta 1 al estado y 2 a las anomalías.

### `transacciones.csv` — 1.000 filas

| Estado (excluyente) | Filas |
|---|---:|
| VALIDA | 401 |
| ANOMALA_TIPO_DESCONOCIDO | 230 |
| ANOMALA_MONTO_NEGATIVO | 136 |
| ANOMALA_MONTO_CERO | 18 |
| **EN NEGOCIO** | **785** |
| RECHAZADA_MONTO_AUSENTE | 160 |
| RECHAZADA_FECHA_INVALIDA | 55 |
| **RECHAZADAS** | **215** |
| **CUADRATURA** | **785 + 215 = 1000** |

Anomalías detectadas (no excluyentes): `TIPO_DESCONOCIDO` 294, `MONTO_NEGATIVO` 136, `MONTO_CERO` 18.

Formatos de fecha reparados: `yyyy-MM-dd` 210, `dd-MM-yyyy` 209, `dd/MM/yyyy` 187, `yyyy/MM/dd` 179.

### `intereses.csv` — 1.000 filas, cuentas 101–150

| Estado (excluyente) | Filas |
|---|---:|
| VALIDA | 303 |
| ANOMALA_TIPO_DESCONOCIDO | 260 |
| ANOMALA_EDAD_AUSENTE | 101 |
| ANOMALA_EDAD_FUERA_RANGO | 96 |
| ANOMALA_NOMBRE_DESCONOCIDO | 24 |
| **EN NEGOCIO** | **784** |
| RECHAZADA_SALDO_AUSENTE | 211 |
| RECHAZADA_DUPLICADO | 5 |
| **RECHAZADAS** | **216** |
| **CUADRATURA** | **784 + 216 = 1000** |

Anomalías detectadas (no excluyentes): `TIPO_DESCONOCIDO` 260, `EDAD_AUSENTE` 151,
`EDAD_FUERA_RANGO` 137, `NOMBRE_DESCONOCIDO` 45.

Filas por número de anomalías: 0 → 303, 1 → 372, 2 → 106, 3 → 3.

> **Los duplicados son 5, no 9.** El archivo contiene 9 filas 100 % repetidas, pero 4 de ellas
> tienen además el saldo vacío y la precedencia las rechaza antes por `SALDO_AUSENTE`. No es un
> error de conteo: es la precedencia funcionando. Conviene decirlo en el README, porque el
> número "9 duplicados" aparece en el plan y alguien podría pensar que falta algo.

### `cuentas_anuales.csv` — 1.000 filas, cuentas 101–120

| Estado (excluyente) | Filas |
|---|---:|
| VALIDA | 524 |
| ANOMALA_MONTO_NEGATIVO | 173 |
| ANOMALA_DESCRIPCION_AUSENTE | 162 |
| ANOMALA_SIGNO_CONTRADICTORIO | 81 |
| ANOMALA_MONTO_CERO | 12 |
| **EN NEGOCIO** | **952** |
| RECHAZADA_MONTO_AUSENTE | 48 |
| **RECHAZADAS** | **48** |
| **CUADRATURA** | **952 + 48 = 1000** |

Anomalías detectadas (no excluyentes): `MONTO_NEGATIVO` 254, `DESCRIPCION_AUSENTE` 220,
`SIGNO_CONTRADICTORIO` 81, `MONTO_CERO` 12.

Filas por número de anomalías: 0 → 524, 1 → 370, 2 → 58.

Formatos de fecha reparados: `dd-MM-yyyy` 244, `yyyy-MM-dd` 242, `dd/MM/yyyy` 233, `yyyy/MM/dd` 233.

**Ninguna fecha inválida.** Las 1.000 son fechas reales del calendario; el único trabajo del
procesador es unificar los cuatro formatos.

`SIGNO_CONTRADICTORIO` son 81 depósitos con monto negativo: un depósito suma al saldo y un monto
negativo resta, así que la fila se contradice a sí misma. Se guarda marcada, no se rechaza.

### Nota de limpieza: `deposito` con y sin tilde

`cuentas_anuales.csv` escribe el mismo tipo de dos formas: `deposito` 296 veces y `depósito`
52 veces. Son 348 depósitos que hay que unificar en el `ItemProcessor` normalizando las tildes.
Es una transformación pequeña pero visible, del tipo que puntúa en el criterio 3.
