# Comparación de configuraciones de escalado — Job 1 (Banco XYZ)

> Criterio 4 de la pauta. El descriptor baja la nota si se implementa escalado
> pero **no se comparan ejecuciones con distintos parámetros**. Este documento
> compara **3 estrategias × 4 tamaños de chunk × 3 grados de paralelismo × 2
> escalas de datos**, con 7 repeticiones por celda de las que 5 se miden y 2 se
> descartan como calentamiento, y reporta **mediana y dispersión**, no medias.

---

## 0. Resumen en cinco líneas

1. A las dos escalas medidas **el paralelismo sí gana**: 2,73× a 1.000 filas y
   **4,47× a 20.000 filas** sobre el mejor secuencial.
2. La causa es que este job **no está limitado por CPU sino por viajes a
   PostgreSQL**, y esos viajes se solapan bien entre hilos.
3. **`chunkSize` pesa más que la estrategia**: pasar de 500 a 10 cuesta un
   factor 1,8× *antes* de tocar un solo hilo.
4. `MULTI_THREAD` y `PARTICIONADO` salen **prácticamente empatados**; sus
   rangos intercuartílicos se solapan casi siempre, y donde no se solapan la
   diferencia es del 3%. **No se declara ganador entre esos dos.**
5. La configuración óptima medida es **PARTICIONADO, gridSize=8, chunk=500**,
   y solo es válida **con el pool de conexiones subido a 24**.

---

## 1. Qué se comparó exactamente

### 1.1 Las tres estrategias

| Estrategia | Qué hace | Lector | Límite estructural |
|---|---|---|---|
| `SECUENCIAL` | Un step, un hilo | 1 `FlatFileItemReader` | Ninguno; es la **base** |
| `MULTI_THREAD` | Un step, N hilos, chunks en paralelo | 1 lector **compartido** envuelto en `SynchronizedItemStreamReader` | La lectura queda **serializada** por el cerrojo |
| `PARTICIONADO` | Step *manager* que reparte + N copias del step *worker* | N lectores, uno por rango disjunto | Cada partición reabre el fichero: coste O(n·p) al leer |

Las tres ejecutan **el mismo `TransaccionProcessor`, el mismo writer JDBC, la
misma `BancoXyzSkipPolicy` y el mismo dead letter** que el Job 1 de producción.
Eso es deliberado: un banco de pruebas que midiera una versión aligerada del job
no diría nada sobre el job que de verdad se ejecuta.

### 1.2 Los dos parámetros barridos

- **`chunkSize` ∈ {10, 50, 100, 500}** — 4 niveles. Es cuántas filas entran en
  cada COMMIT.
- **paralelismo ∈ {2, 4, 8}** (hilos en `MULTI_THREAD`, `gridSize` en
  `PARTICIONADO`) — 3 niveles, más el 1 implícito del secuencial.

### 1.3 Diseño escalonado, no factorial completo

El cruce completo serían 4 × 3 × 3 × 2 = 72 celdas y 504 ejecuciones. Se usó el
diseño clásico de *un factor cada vez*:

| Fase | Qué mide | Celdas por escala |
|---|---|---|
| **F0 — baseline** | Solo secuencial, los 4 `chunkSize`. Aísla el efecto del lote sin ruido de paralelismo. De aquí sale `chunk*` | 4 |
| **F1 — paralelismo** | Fijado `chunk*`, cruce {MULTI_THREAD, PARTICIONADO} × {2, 4, 8} | 6 |
| **F2 — confirmación cruzada** | La celda ganadora de F1, re-medida con los **dos mejores `chunkSize`** de F0 | 2 |

**Para qué sirve F2:** responde a la crítica obvia del diseño escalonado —
*"asumiste que `chunkSize` y paralelismo no interactúan"*. Si el chunk óptimo en
paralelo fuera otro distinto que en secuencial, F2 lo destaparía. **Resultado
real: no lo destapó.** El orden 500 > 100 se mantuvo idéntico bajo paralelismo,
así que la suposición era razonable. F2 no es, por tanto, un test de interacción
fuerte: es una comprobación de que el ranking se conserva, y además funciona
como control de reproducibilidad (la celda `PAR-p8-c500` se midió dos veces,
en F1 y en F2, y dio 2.698 ms y 2.689 ms — una diferencia del 0,3%).

**Total: 12 celdas por escala, 24 celdas, 168 ejecuciones, 13 min 10 s.**

---

## 2. Protocolo de medición

Esto es lo que separa una tabla creíble de dos números sueltos.

| Decisión | Por qué |
|---|---|
| **7 repeticiones por celda: 2 de calentamiento + 5 medidas** | La JVM interpreta el bytecode las primeras veces y solo después lo compila a código máquina. Sin descartar las primeras rondas estarías midiendo al compilador JIT |
| **Los calentamientos SE GUARDAN, marcados `warmup=true`** | 48 de las 168 filas de `results/scaling-results.csv` son calentamientos y están ahí. El descarte se hace al analizar y queda declarado. Descartar en silencio impide comprobar que se tiraron *las dos primeras* y no *las que salieron feas* |
| **Por rondas, no por celda** | Una pasada por todas las celdas, luego otra. Si la máquina se calienta o Windows decide indexar el disco a mitad, la deriva se reparte entre todas las celdas en vez de castigar a la que tocara |
| **Orden aleatorizado con semilla fija (42 + ronda)** | Aleatorizar rompe el sesgo de orden; la semilla fija hace el experimento reproducible |
| **`TRUNCATE` fuera del cronómetro** | Se limpia antes de arrancar `System.nanoTime()` |
| **Control de integridad por ejecución** | Cada corrida verifica `readCount == filas del dataset`. **Descartadas por este control: 0 de 120 medidas** |
| **Se reporta MEDIANA + P25–P75 + CV%** | Ver §2.1 |

### 2.1 Por qué mediana y no media, con un ejemplo de esta misma corrida

En la primera corrida completa del banco de pruebas, la celda
`MULTI_THREAD p=4 chunk=500` a 20.000 filas dio estas cinco medidas:

```
4485   4737   4550   16751   4246     (ms)
```

La **media** es 6.954 ms. La **mediana** es 4.550 ms. Ese 16.751 no es el job:
es una pausa del sistema operativo o del recolector de basura que cayó dentro de
la ventana medida. La media se la traga y desplaza el resultado un 53%; la
mediana la ignora. Por eso todas las tablas de este documento van con mediana.

Y por eso además hace falta la **dispersión**: `412 ms contra 389 ms` no
significa nada si los dos rangos intercuartílicos se solapan. Cada celda lleva:

- **P25–P75 (el IQR)**: dónde cae la mitad central de las medidas.
- **CV%** = desviación típica / media. Cuánto ruido hay *en proporción* al
  valor. Por encima del 15% la celda no es concluyente. (Un CV alto con un IQR
  estrecho — como el 20% de `MTH p=8` — es exactamente la firma de un valor
  atípico único: la desviación típica lo nota, los cuartiles no.)

### 2.2 Entorno declarado

```
CPU:        8 procesadores lógicos
Heap:       máx. 4.040 MB
JVM:        Java 25.0.2 (compilado con --release 21)
SO:         Windows 11 amd64
Base:       PostgreSQL 17 en Docker (contenedor bancoxyz-db), misma máquina
Hikari:     maximum-pool-size = 24, minimum-idle = 24  (perfil "experiment")
Spring:     Boot 3.5.16 / Batch 5.2.6
```

Estos datos **van en cada fila del CSV**, no en un pie de página, porque
"gridSize=8 es lo mejor" es una frase sin sentido sin decir sobre cuántos
núcleos y con qué pool.

---

## 3. Tabla comparativa — escala 1.000 filas (dataset real del enunciado)

> **Base de speedup, única y declarada para toda la tabla: `SECUENCIAL,
> paralelismo=1, chunk=500`, mediana 639,0 ms.** Es el **mejor** secuencial, no
> uno cualquiera: comparar contra un secuencial mal configurado regalaría un
> speedup que en realidad mide lo mal elegido que estaba el chunk.

| Fase | Estrategia | Paralelismo | chunk | n | Mediana (ms) | P25–P75 (ms) | IQR | CV % | Speedup | Throughput (filas/s) | COMMIT | skew | hilos |
|---|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
| F0-baseline | SECUENCIAL | 1 | 10 | 5 | 1088.0 | 1088.0–1124.0 | 36.0 | 2.6 | 0.59x | 919 | 101 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 50 | 5 | 741.0 | 736.0–743.0 | 7.0 | 2.2 | 0.86x | 1348 | 21 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 100 | 5 | 717.0 | 694.0–720.0 | 26.0 | 2.7 | 0.89x | 1395 | 11 | 1.00 | 1 |
| F0-baseline | **SECUENCIAL** | **1** | **500** | 5 | **639.0** | 636.0–680.0 | 44.0 | 4.8 | **1.00x (base)** | 1563 | 3 | 1.00 | 1 |
| F1-paralelo | MULTI_THREAD | 2 | 500 | 5 | 411.0 | 407.0–412.0 | 5.0 | 3.8 | 1.55x | 2431 | 5 | 1.00 | 3 |
| F1-paralelo | MULTI_THREAD | 4 | 500 | 5 | 303.0 | 272.0–304.0 | 32.0 | 10.8 | 2.11x | 3298 | 5 | 1.00 | 5 |
| F1-paralelo | MULTI_THREAD | 8 | 500 | 5 | 236.0 | 222.0–266.0 | 44.0 | 18.1 | 2.71x | 4234 | 9 | 1.00 | 9 |
| F1-paralelo | PARTICIONADO | 2 | 500 | 5 | 421.0 | 407.0–433.0 | 26.0 | 5.9 | 1.52x | 2375 | 4 | 1.00 | 2 |
| F1-paralelo | PARTICIONADO | 4 | 500 | 5 | 317.0 | 297.0–328.0 | 31.0 | 6.2 | 2.02x | 3152 | 4 | 1.00 | 4 |
| F1-paralelo | **PARTICIONADO** | **8** | **500** | 5 | **234.0** | 228.0–248.0 | 20.0 | 8.4 | **2.73x** | 4259 | 8 | 1.00 | 8 |
| F2-confirmación | PARTICIONADO | 8 | 100 | 5 | 266.0 | 230.0–268.0 | 38.0 | 9.7 | 2.40x | 3754 | 16 | 1.00 | 8 |
| F2-confirmación | PARTICIONADO | 8 | 500 | 5 | 253.0 | 239.0–258.0 | 19.0 | 5.8 | 2.53x | 3946 | 8 | 1.00 | 8 |

---

## 4. Tabla comparativa — escala 20.000 filas (dataset amplificado ×20)

> **Base de speedup, única y declarada para toda la tabla: `SECUENCIAL,
> paralelismo=1, chunk=500`, mediana 12.010,0 ms.**
> (Cada escala tiene su propia base declarada; los speedup **no** son
> comparables entre las dos tablas, solo dentro de cada una.)

| Fase | Estrategia | Paralelismo | chunk | n | Mediana (ms) | P25–P75 (ms) | IQR | CV % | Speedup | Throughput (filas/s) | COMMIT | skew | hilos |
|---|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
| F0-baseline | SECUENCIAL | 1 | 10 | 5 | 21584.0 | 21204.0–21737.0 | 533.0 | 2.9 | 0.56x | 927 | 2001 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 50 | 5 | 13810.0 | 13710.0–13868.0 | 158.0 | 3.5 | 0.87x | 1448 | 401 | 1.00 | 1 |
| F0-baseline | SECUENCIAL | 1 | 100 | 5 | 12750.0 | 12725.0–13734.0 | 1009.0 | 4.3 | 0.94x | 1569 | 201 | 1.00 | 1 |
| F0-baseline | **SECUENCIAL** | **1** | **500** | 5 | **12010.0** | 11996.0–12857.0 | 861.0 | 5.7 | **1.00x (base)** | 1665 | 41 | 1.00 | 1 |
| F1-paralelo | MULTI_THREAD | 2 | 500 | 5 | 7416.0 | 6680.0–9384.0 | 2704.0 | 21.2 | 1.62x | 2697 | 43 | 1.00 | 3 |
| F1-paralelo | MULTI_THREAD | 4 | 500 | 5 | 4199.0 | 4175.0–4341.0 | 166.0 | 20.3 | 2.86x | 4763 | 45 | 1.00 | 5 |
| F1-paralelo | MULTI_THREAD | 8 | 500 | 5 | 2778.0 | 2760.0–2817.0 | 57.0 | 19.9 | 4.32x | 7198 | 49 | 1.00 | 9 |
| F1-paralelo | PARTICIONADO | 2 | 500 | 5 | 6992.0 | 6648.0–7139.0 | 491.0 | 23.6 | 1.72x | 2860 | 42 | 1.00 | 2 |
| F1-paralelo | PARTICIONADO | 4 | 500 | 5 | 4237.0 | 4188.0–4248.0 | 60.0 | 22.3 | 2.83x | 4720 | 44 | 1.00 | 4 |
| F1-paralelo | **PARTICIONADO** | **8** | **500** | 5 | **2698.0** | 2669.0–2756.0 | 87.0 | 2.8 | **4.45x** | 7411 | 48 | 1.00 | 8 |
| F2-confirmación | PARTICIONADO | 8 | 100 | 5 | 2850.0 | 2811.0–2860.0 | 49.0 | 1.7 | 4.21x | 7015 | 208 | 1.00 | 8 |
| F2-confirmación | **PARTICIONADO** | **8** | **500** | 5 | **2689.0** | 2658.0–2725.0 | 67.0 | 2.3 | **4.47x** | 7438 | 48 | 1.00 | 8 |

### Gráficos

Están en `evidencias/04-escalado/` y se regeneran con `python scripts/graficar.py`
(solo biblioteca estándar, sin dependencias que instalar). **Los tres tienen el
eje Y empezando en cero**, porque un eje truncado convierte una mejora del 3% en
una montaña visual sin escribir un solo número falso.

| Archivo | Qué muestra |
|---|---|
| `grafico-throughput-{1000,20000}.svg` | Filas/segundo contra paralelismo |
| `grafico-speedup-{1000,20000}.svg` | Speedup real contra el ideal lineal y contra la curva de Amdahl |
| `grafico-cajas-{1000,20000}.svg` | Caja y bigotes de la duración: es donde se ve a ojo qué IQR se solapan |

---

## 5. Lectura de los resultados

### 5.1 El `chunkSize` pesa más que la estrategia (y esto sorprende)

A 20.000 filas, **sin tocar un solo hilo**, pasar de `chunk=10` a `chunk=500`
baja de 21.584 ms a 12.010 ms: un factor **1,80×**. Es casi la mitad de todo lo
que aporta después subir a 8 particiones.

La causa está en la columna `COMMIT` de la tabla: 2.001 confirmaciones contra
41. Cada COMMIT es un viaje de ida y vuelta a PostgreSQL más una escritura
sincronizada del WAL a disco. Dividiendo la diferencia entre las confirmaciones
de más:

```
(21.584 - 12.010) ms / (2.001 - 41) commits ≈ 4,9 ms por COMMIT
```

Ese número es, indirectamente, **la medida de cuánto del tiempo es base de
datos**. No se ejecutó una variante de control con writer no-op — se declara la
ausencia —, pero este cálculo apunta a lo mismo: el cuello de botella de este
job está en PostgreSQL, no en la CPU.

**Conclusión operativa inmediata:** antes de complicar la arquitectura con
hilos, ajusta el tamaño del lote. Es gratis y da casi la mitad de la mejora.

### 5.2 Por qué el paralelismo SÍ gana, incluso con 1.000 filas

La expectativa razonable era la contraria: con 1.000 filas el coste fijo de
arrancar un job (crear el pool, dar de alta la `JobExecution` y N
`StepExecution` en la base de metadatos) debería dominar y el particionado
debería salir *más lento*. **No ocurrió: 639 ms → 234 ms, 2,73×.**

La explicación es la naturaleza del trabajo, no la escala. Este job está
**limitado por entrada/salida contra PostgreSQL**, no por CPU:

- 785 INSERT de negocio agrupados en lotes,
- **más 215 transacciones INDIVIDUALES** del dead letter, cada una en su propia
  transacción `REQUIRES_NEW` (así lo exige `RechazoListener` para que el
  registro del rechazo sobreviva al rollback del chunk).

Un hilo que espera una respuesta de la base no consume CPU: libera el núcleo.
Por eso 8 hilos sobre 8 núcleos rinden mucho más de lo que rendirían en un
trabajo puramente aritmético, y por eso el paralelismo compensa ya a 1.000
filas. Si el processor fuese CPU-bound y el writer no existiera, la conclusión
habría sido la opuesta.

### 5.3 `MULTI_THREAD` vs `PARTICIONADO`: NO hay ganador declarable

Esta es la comparación donde es más fácil mentir sin querer.

| Escala | p | MULTI_THREAD (P25–P75) | PARTICIONADO (P25–P75) | ¿Se solapan los IQR? | Veredicto |
|---|---:|---|---|---|---|
| 1.000 | 8 | 236 (222–266) | 234 (228–248) | **Sí, totalmente** | **Indistinguibles** |
| 20.000 | 2 | 7416 (6680–9384) | 6992 (6648–7139) | **Sí** | **Indistinguibles** |
| 20.000 | 4 | 4199 (4175–4341) | 4237 (4188–4248) | **Sí** | **Indistinguibles** |
| 20.000 | 8 | 2778 (2760–2817) | 2698 (2669–2756) | **No, por 4 ms** | PARTICIONADO gana un **2,9%** |

De cuatro comparaciones directas, en tres los rangos se solapan y no se puede
afirmar que una sea más rápida. En la cuarta los rangos casi se tocan (2.756
contra 2.760) y la diferencia es del 3%. **Decir "el particionado es más
rápido" sería sobreinterpretar el ruido.**

Y hay algo más interesante en ese empate. `MULTI_THREAD` **serializa la lectura
del fichero** con un `SynchronizedItemStreamReader`, mientras que
`PARTICIONADO` da a cada partición su propio lector sin cerrojo. Si leer el CSV
fuera el cuello de botella, `PARTICIONADO` debería ganar con claridad. **Empatan
igualmente**, lo que confirma desde otro ángulo lo dicho en §5.1 y §5.2: el
tiempo no se va en leer el archivo, se va en la base de datos.

### 5.4 Nota sobre la columna `hilos`

`MULTI_THREAD p=8` muestra **9** hilos distintos, `p=4` muestra 5 y `p=2`
muestra 3. No es un error: son los N hilos del pool **más el hilo `main`**,
donde se ejecuta el `beforeStep` del step único. En `PARTICIONADO` la cifra
coincide exactamente con `gridSize` (2, 4, 8) porque ahí el `beforeStep` corre
dentro del hilo de cada partición.

La prueba de que el paralelismo fue **real** y no un `SyncTaskExecutor`
disfrazado está en `evidencias/04-escalado/hilos-particionado.txt`:

```
PAR-p8-c500-n20000 ronda 3 -> 8 hilos distintos:
  [particion-1, particion-2, particion-3, particion-4,
   particion-5, particion-6, particion-7, particion-8]
```

y en `evidencias/04-escalado/log-particionado-grid4.txt`, con las cuatro
particiones terminando en cuatro hilos distintos con 9 ms de diferencia entre
la primera y la última.

### 5.5 Calidad del reparto: `skew` y `ratio_max_min`

Son dos cosas distintas que se confunden a menudo:

- **`skew` = máx(filas de una partición) / media(filas)**. Mide si a alguna
  partición le tocaron **más filas**. Vale **1,000 en todas las celdas**:
  `LineRangePartitioner` reparte exacto.
- **`ratio_max_min` = duración más larga / más corta**. Mide si alguna **tardó**
  más, que no es lo mismo: dos particiones con idénticas filas pueden tardar
  distinto si una tiene más filas sucias.

| Escala | gridSize | skew | ratio_max_min | speedup interno (Σms / máx ms) |
|---|---:|---:|---:|---:|
| 1.000 | 2 | 1.000 | 1.033 | 1.97 |
| 1.000 | 4 | 1.000 | 1.420 | 3.48 |
| 1.000 | 8 | 1.000 | 1.501 | 6.79 |
| 20.000 | 2 | 1.000 | 1.001 | 2.00 |
| 20.000 | 4 | 1.000 | 1.005 | 3.99 |
| 20.000 | 8 | 1.000 | **1.015** | **7.93** |

La última columna es reveladora. El **speedup interno** (7,93× a 20.000 filas
con 8 particiones) es lo que ganarías si el job fuera *solo* las particiones. El
**speedup real medido es 4,45×**. Esa diferencia — 7,93 contra 4,45 — **es
exactamente el coste que queda fuera de las particiones**: arrancar la JVM del
job, crear el pool de hilos, el step manager, y las escrituras de metadatos de
Spring Batch. Es la parte no paralelizable, medida directamente en vez de
deducida.

A 1.000 filas ese `ratio_max_min` de 1,50 con `skew` perfecto significa que la
partición más lenta tardó un 50% más que la más rápida **con las mismas filas**:
a esa escala cada partición dura ~100 ms y las variaciones de arranque de hilo y
de contención de conexiones pesan mucho en términos relativos. A 20.000 filas el
ratio baja a 1,015: el desequilibrio desaparece cuando hay trabajo suficiente.

---

## 6. Punto de saturación, con explicación causal

**Eficiencia = speedup / paralelismo.** Es qué fracción de cada hilo se
aprovecha realmente.

| Escala | p=2 | p=4 | p=8 | Ganancia marginal 4→8 |
|---|---:|---:|---:|---|
| 1.000 filas | 76% | 50% | **34%** | 317/234 = **1,35×** (el ideal sería 2×) |
| 20.000 filas | 86% | 71% | **56%** | 4237/2698 = **1,57×** (el ideal sería 2×) |

**El punto de saturación está en p = 8, que es exactamente el número de
procesadores lógicos de la máquina.** No es una coincidencia y la causa es
acumulativa:

1. **Se acabaron los núcleos.** Por encima de 8 los hilos se turnan en el mismo
   procesador. El cambio de contexto añade coste sin añadir trabajo simultáneo.
2. **Se acabó la base de datos.** PostgreSQL corre en la misma máquina, en
   Docker, compitiendo por esos mismos 8 núcleos y por el mismo disco. Cuantos
   más hilos escriben, más contención en el WAL.
3. **La parte serial no encoge.** Arrancar el pool, dar de alta las
   `StepExecution`, ejecutar el manager y confirmar el job son costes fijos que
   siguen ahí con 2 hilos o con 80. La medida directa de §5.5 (7,93× interno
   contra 4,45× real) los cuantifica.

**Por qué satura antes a 1.000 filas que a 20.000:** el coste fijo de arranque
(crear el pool, dar de alta las `StepExecution`, cerrar el job) es
aproximadamente el mismo en las dos escalas —del orden de 175 ms—, pero eso es
el 27% de una corrida de 639 ms y solo el 1,5% de una de 12.010 ms. Cuanto menor
es el volumen, mayor es el peso relativo de lo que no se puede paralelizar.

Conviene precisar que ese coste fijo **no es toda** la parte serial: la fracción
serial medida a 20.000 filas es del 11,4% (§7.1), y el arranque solo explica
1,5 de esos 11,4 puntos. El resto es trabajo serial **proporcional al volumen**:
las escrituras de metadatos que Spring Batch hace en cada confirmación, la
adquisición de conexiones y la agregación del manager. Por eso la fracción
serial baja al crecer el volumen, pero **no tiende a cero**. **No existe un
"número óptimo de particiones" universal: depende del volumen.**

---

## 7. Ley de Amdahl con la `p` calculada de estos datos

La ley de Amdahl dice que si una fracción `p` del trabajo se puede paralelizar
y el resto `(1-p)` es forzosamente secuencial, con `N` unidades de proceso el
speedup máximo es:

```
S(N) = 1 / ( (1 - p) + p/N )
```

Despejando `p` a partir del speedup **medido**:

```
p = (1 - 1/S) / (1 - 1/N)
```

### 7.1 Escala 20.000 filas

Con `S(8) = 4,451` (PARTICIONADO, gridSize=8, chunk=500):

```
p = (1 - 1/4,451) / (1 - 1/8) = 0,7753 / 0,875 = 0,886
```

- **Fracción paralelizable: p ≈ 0,886 (88,6%).**
- **Fracción serial: 1 - p ≈ 0,114 (11,4%).**
- **Techo teórico con infinitos núcleos: S(∞) = 1/0,114 ≈ 8,8×.**

Es decir: por muchos núcleos que se añadan, este job no bajará de ~1.360 ms a
esta escala. Con 8 núcleos ya se ha alcanzado el 51% de ese techo.

### 7.2 Escala 1.000 filas

Con `S(8) = 2,731`:

```
p = (1 - 1/2,731) / 0,875 = 0,6338 / 0,875 = 0,724
```

- **p ≈ 0,724; fracción serial 27,6%; techo S(∞) ≈ 3,6×.**

La comparación entre las dos escalas es el resultado más informativo del
documento: **la fracción serial cae del 27,6% al 11,4% al multiplicar el volumen
por 20**, porque el coste fijo de arranque se reparte entre más trabajo útil.
Esto es la ley de Gustafson en acción: cuando el problema crece, el paralelismo
escala mejor.

### 7.3 Honestidad sobre el modelo

Amdahl supone que `p` es una constante del programa. **En estos datos no lo es**:
despejándola desde distintos grados de paralelismo a 20.000 filas sale

| Desde | `p` despejada | S(∞) implícito |
|---|---:|---:|
| S(2) = 1,718 | 0,836 | 6,1× |
| S(4) = 2,835 | 0,863 | 7,3× |
| S(8) = 4,451 | 0,886 | 8,8× |

La deriva (0,836 → 0,886) demuestra que **el modelo es una aproximación**: hay
efectos que Amdahl no captura, como que a más hilos el solapamiento de esperas
de entrada/salida mejora. Se reporta `p = 0,886` (la despejada con el mayor
paralelismo medido) como cifra de cabecera, y se declara la deriva en vez de
esconderla. Un único `p` presentado como si fuera una constante física sería
una precisión falsa.

---

## 8. Configuración óptima declarada, **con sus condiciones**

> ### Óptimo medido
> **`PARTICIONADO`, `gridSize = 8`, `chunkSize = 500`**
> — mediana **2.689 ms** a 20.000 filas (**4,47×** sobre el mejor secuencial,
> que es `chunk=500` con 12.010 ms), throughput 7.438 filas/s, `skew` 1,000,
> `ratio_max_min` 1,015.

**Este óptimo sólo es válido bajo estas condiciones, y fuera de ellas no se
sostiene:**

| Condición | Valor | Qué pasa si cambia |
|---|---|---|
| **Núcleos** | 8 lógicos | `gridSize=8` sobre 4 núcleos sería sobresuscripción: los hilos se turnarían |
| **Volumen** | ≥ 20.000 filas | A 1.000 filas la ventaja sobre `MULTI_THREAD` desaparece dentro del ruido, y la eficiencia cae al 34% |
| **Pool de conexiones** | **`maximum-pool-size = 24`** | **Crítico.** Ver el recuadro de abajo |
| **Heap** | 4 GB fijos | Un heap menor añadiría pausas de GC dentro de la ventana medida |
| **Base de datos** | PostgreSQL 17 local en Docker | Con la base en otra máquina la latencia de red cambiaría el balance a favor de *más* hilos |

> ### El pool NO es un detalle de configuración: es parte del resultado
> El `application.yml` de producción trae `maximum-pool-size: 12`. Con
> `gridSize=8` eso **no basta**, y la razón es sutil: cada partición puede
> necesitar **dos** conexiones a la vez, la del chunk en curso y la que abre el
> dead letter con `PROPAGATION_REQUIRES_NEW`. Son 16, más el manager, más las
> consultas de metadatos de Spring Batch.
>
> Con el pool corto las particiones se turnan esperando una conexión libre y lo
> que se mide **es el pool, no el paralelismo** — y aparecería una "saturación"
> falsa en 4 u 8 que en realidad sería el pool. Por eso el perfil `experiment`
> lo sube a 24, y por eso **la recomendación de activar el particionado va
> acompañada obligatoriamente de subir el pool**. Sin eso, la recomendación no
> es accionable.

---

## 9. El dataset amplificado (declaración obligatoria)

Los CSV del enunciado tienen 1.000 filas. Para tener una segunda escala se
generó `data/generated/transacciones_x20k.csv` con `AmplificadorDataset`.

**Las siete reglas de legitimidad, y cómo se cumplen:**

1. **Los CSV originales no se tocaron.** Se leen del classpath, en solo lectura.
2. **El generador es determinista**: sin azar, sin semillas, sin fechas. Dos
   ejecuciones producen archivos idénticos byte a byte.
3. **Se preservan exactamente las proporciones de defectos.** Comprobado en la
   propia corrida: `20.000 = 15.700 negocio + 4.300 rechazos`, que es 20 × (785
   + 215). No es una estimación, es la salida del job.
4. **Se re-secuencia el `id`** a 1..20.000, porque `banco.transaccion` lo tiene
   como PRIMARY KEY; replicar sin tocarlo mediría violaciones de restricción en
   vez de rendimiento.
5. **`split(",", -1)` con límite negativo.** Sin el `-1`, Java descarta los
   campos vacíos finales y se perderían los 160 montos ausentes por cada 1.000
   filas, que son la mayoría de los rechazos. El dataset amplificado no tendría
   la misma proporción de defectos y la comparación entre escalas sería falsa.
6. **Vive fuera del classpath**, en `data/generated/`, para que quede claro que
   es un artefacto reproducible y no parte del entregable de datos.
7. **El factor va declarado en la columna `dataset_filas`** de cada fila del CSV
   de resultados, además de aquí.

**Por qué ×20 y no ×100:** ×20 ya multiplica por 19 el tiempo de una corrida
secuencial (639 ms → 12.010 ms), suficiente para que el coste fijo de arranque
pase de ser el 28% del total a ser el 1,4% y para que el paralelismo tenga
margen de lucirse. Con ×100 las 168 ejecuciones habrían pasado de 13 minutos a
más de una hora sin cambiar ninguna conclusión. **La decisión fue de
presupuesto de tiempo y se declara como tal.**

---

## 10. Amenazas a la validez (lo que estos números NO demuestran)

Sección corta y de gran retorno: un benchmark sin esto no es honesto.

1. **Una sola máquina, una sola vez.** 5 medidas por celda acotan el ruido de
   *esta* máquina, no la variación entre máquinas.
2. **La base de datos comparte los 8 núcleos.** PostgreSQL en Docker compite con
   la JVM. En una arquitectura con la base en otro servidor, el punto de
   saturación se movería.
3. **Windows no es un entorno de medición controlado.** Antivirus, indexado y
   política de energía pueden intervenir. Es la razón del atípico de 16.751 ms
   documentado en §2.1, y la razón de usar mediana.
4. **`throttleLimit` está deprecado.** Se usa porque en Spring Batch 5.2.6 es el
   único mecanismo para que "8 hilos" sean de verdad 8 (ver §11); desaparecerá
   en 6.x y habrá que remedir.
5. **No se midió una variante de control con writer no-op.** El coste de la base
   se estima indirectamente (§5.1: ~4,9 ms por COMMIT); no está medido de forma
   directa.
6. **F2 confirma el ranking, no descarta interacción fuerte.** Se re-midieron
   los dos mejores chunks, no los cuatro.
7. **Solo se midió el Job 1.** Los Jobs 2 y 3 particionan por `cuenta_id`, cuya
   cardinalidad real es 50 y 20; ahí el techo lo pone la cardinalidad, no
   `gridSize`, y estas conclusiones no se les aplican directamente.

---

## 11. Las trampas técnicas, y cómo se evitó cada una

Cualquiera de estas invalida los números **sin producir ningún error**.

| Trampa | Síntoma si se cae | Antídoto aplicado | Dónde verificarlo |
|---|---|---|---|
| `PartitionStepBuilder` sin `.taskExecutor(...)` | Cae a `SyncTaskExecutor`: secuencial disfrazado, **sin warning** | `.taskExecutor(pool)` siempre | Columna `hilos_distintos` del CSV = gridSize; `hilos-particionado.txt` |
| `queueCapacity` menor que el nº de particiones | Particiones `FAILED` en silencio: *"TaskExecutor rejected the task"* | `queueCapacity = Integer.MAX_VALUE` | `FabricaJobsExperimento.pool()` |
| `hikari.maximum-pool-size` < gridSize + 2 | Mides el pool, no el paralelismo | Pool = 24 (gridSize máx 8 × 2 conexiones + margen) | Columna `hikari_pool_size` en cada fila |
| `.partitionHandler(h)` explícito | `.gridSize()` y `.taskExecutor()` del builder se **ignoran**, y el handler arranca con 1 | No se usa; solo el builder | `FabricaJobsExperimento.particionado()` |
| Multi-hilo con `FlatFileItemReader` sin envolver | `maxItemCount` violado, filas duplicadas o perdidas | `SynchronizedItemStreamReader` **y se declara que serializa la lectura** | §5.3 |
| **`throttleLimit` por defecto = 4** | La celda "8 hilos" usa **4** y aparece una saturación **falsa** en 4 | `.throttleLimit(paralelismo)` explícito | `FabricaJobsExperimento.multiHilo()` |
| Jobs construidos por factory, no beans | `BatchObservabilityBeanPostProcessor` no corre → todas las métricas en NOOP | `.observationRegistry()` y `.meterRegistry()` en **cada** `JobBuilder` y `StepBuilder`, manager incluido | `evidencias/04-escalado/metricas-micrometer.txt` |
| Tags de métrica según la doc oficial | `.tag("job.name", ...)` devuelve `null`; columnas vacías **sin error** | Los tags reales van cualificados | Ver §11.1 |
| Comparar sin declarar la base del speedup | Speedups inconsistentes entre filas | **Una sola base por tabla**, declarada en la leyenda | §3 y §4 |
| **PK duplicada entre repeticiones** | La 2ª repetición choca contra las filas de la 1ª, **omite casi todo** (`DuplicateKeyException` es dato sucio omitible), termina `COMPLETED` y sale **rapidísima**: tabla entera de números falsos con aspecto de éxito | `TRUNCATE` antes de cada repetición **fuera del cronómetro** + verificación `readCount == filas` en cada ejecución | Columna `filas_esperadas_ok`; descartadas: **0** |
| `JdbcBatchItemWriterBuilder` fuera de Spring | `NullPointerException: itemPreparedStatementSetter is null` en el primer chunk | Llamar `writer.afterPropertiesSet()` a mano | Ocurrió de verdad en la primera corrida; ver el comentario en `FabricaJobsExperimento.escritor()` |
| `String.format` con la configuración regional del sistema | En una JVM en español `%.1f` escribe `1203,0` con **coma**, y en un CSV separado por comas destroza las columnas | `Locale.ROOT` en todas las salidas numéricas | Ocurrió en la primera corrida completa; corregido en `AnalizadorResultados` y `EscritorResultadosCsv` |

### 11.1 Los tags de Micrometer que existen de verdad en este build

La documentación oficial de Spring Batch todavía lista los tags como `job.name`
y `status`. **Desde 5.0 eso es falso**: van cualificados con el prefijo de su
métrica. Quien copie la tabla de la doc recibirá `null` y publicará columnas
vacías sin ver un solo error. Salida literal de este build
(`evidencias/04-escalado/metricas-micrometer.txt`):

```
spring.batch.chunk.write   TIMER  tags[spring.batch.chunk.write.job.name=...,
                                       spring.batch.chunk.write.status=SUCCESS,
                                       spring.batch.chunk.write.step.name=w-PAR-p4-c500-n1000:partition0]
spring.batch.item.read     TIMER  tags[spring.batch.item.read.job.name=...,
                                       spring.batch.item.read.status=SUCCESS, ...]
spring.batch.job           TIMER  tags[error=none, spring.batch.job.name=...,
                                       spring.batch.job.status=COMPLETED]
spring.batch.step          TIMER  tags[error=none, spring.batch.step.job.name=...,
                                       spring.batch.step.name=..., spring.batch.step.status=COMPLETED]
spring.batch.job.launch.count COUNTER tags[]
```

Ese volcado documenta además, de forma reproducible, el **bug conocido de
`spring.batch.job.active`**, que aparece registrado **dos veces con tags
incompatibles**:

```
spring.batch.job.active  LONG_TASK_TIMER  tags[spring.batch.job.name=..., spring.batch.job.status=UNKNOWN]
spring.batch.job.active  LONG_TASK_TIMER  tags[spring.batch.job.active.name=...]
```

**No hay endpoint HTTP `/actuator/metrics`** y decirlo es más honesto que fingir
una captura: el proyecto incluye `spring-boot-starter-actuator` pero **no**
`spring-boot-starter-web`, así que no se levanta ningún servidor. Es lo correcto
para una aplicación batch que arranca, trabaja y termina. Los datos se leen del
`MeterRegistry`, que es exactamente la fuente que Actuator expondría.

---

## 12. Conclusión y recomendación operativa

**Conclusión.** La configuración óptima para el Job 1 a escala 20.000 filas es
**particionado con `gridSize=8` y `chunkSize=500`**: mediana **2.689 ms**,
**4,47×** sobre el mejor secuencial, que es `chunk=500` con 12.010 ms. El punto
de saturación coincide con el número de procesadores lógicos de la máquina (8):
entre 4 y 8 la mejora es del 57% cuando el ideal sería del 100%, y la eficiencia
cae del 71% al 56%. Despejando Amdahl con `S(8) = 4,451` se obtiene
**`p ≈ 0,886`** y un techo teórico **`S(∞) ≈ 8,8×`**. A la escala del dataset
entregado (1.000 filas) el paralelismo también gana (2,73×), pero con una
fracción serial del 27,6% y una eficiencia de solo el 34% con 8 hilos; y ahí
**`MULTI_THREAD` y `PARTICIONADO` son indistinguibles**: sus rangos
intercuartílicos se solapan por completo (236 ms con 222–266 frente a 234 ms con
228–248), así que declarar un ganador sería sobreinterpretar el ruido. El
hallazgo que más rendimiento da por unidad de esfuerzo no es la estrategia sino
el `chunkSize`: pasar de 10 a 500 aporta un 1,80× sin tocar un solo hilo, porque
recorta las confirmaciones de 2.001 a 41 y cada COMMIT cuesta unos 4,9 ms.

**Recomendación operativa.**

1. **Ahora, sin discusión:** dejar `chunkSize = 500`. Es la mitad de la mejora,
   es gratis y no añade ni un hilo.
2. **Para el volumen diario actual (1.000 filas):** el particionado con
   `gridSize=4` que ya tiene el Job 1 es adecuado y suficiente. Subir a 8 recorta
   el tiempo un 26% (317 ms → 234 ms, 1,35×) a cambio de duplicar los hilos y de
   exigir un pool mayor: mal negocio a este volumen.
3. **Cuando el volumen crezca por encima de ~10.000 filas por corrida:** activar
   `gridSize=8` **y simultáneamente subir `hikari.maximum-pool-size` a 24**. Las
   dos cosas juntas o ninguna: con el pool en 12 estarías midiendo —y
   sufriendo— la espera por conexión, no el paralelismo.
4. **Hacer el `gridSize` un `JobParameter`** en lugar de una constante, para que
   ese cambio no requiera recompilar y quede además registrado en
   `BATCH_JOB_EXECUTION_PARAMS` como parte de la auditoría de cada corrida.
5. **Volver a medir si cambia el entorno.** Todos los números de este documento
   están condicionados a 8 núcleos, 4 GB de heap, pool 24 y PostgreSQL local. Un
   despliegue con la base en otro servidor cambia el balance a favor de *más*
   hilos, no de menos.

---

## 13. Cómo reproducirlo

```bash
# 1. El banco de pruebas completo (168 ejecuciones, ~13 min)
./mvnw spring-boot:run -Dspring-boot.run.profiles=experiment

# 2. Los gráficos (solo biblioteca estándar de Python)
python scripts/graficar.py

# 3. La evidencia de qué métricas y tags existen realmente
./mvnw spring-boot:run -Dspring-boot.run.profiles=metricas

# 4. La verificación cruzada desde la base de datos
docker exec -i bancoxyz-db psql -U banco -d bancoxyz < scripts/consultas-sql/07-comparativa-escalado.sql
docker exec -i bancoxyz-db psql -U banco -d bancoxyz -v id=<jobExecutionId> \
    -f - < scripts/consultas-sql/06-particiones.sql

# 5. IMPORTANTE: el experimento hace TRUNCATE de las tablas de negocio.
#    Deja la base como estaba volviendo a lanzar los tres jobs:
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobInteresesMensuales
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobEstadosCuentaAnuales
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "SELECT * FROM banco.v_cuadratura;"
```

### Artefactos

| Archivo | Contenido |
|---|---|
| `results/scaling-results.csv` | **168 ejecuciones**, incluidos los 48 calentamientos marcados `warmup=true`. El dato crudo |
| `results/scaling-summary.md` | Las dos tablas, generadas por el propio runner |
| `banco.ejecucion_metrica` | Las mismas 168 filas en la base, cruzables con `BATCH_JOB_EXECUTION` por `job_execution_id` |
| `evidencias/04-escalado/hilos-particionado.txt` | Nombres de hilo por corrida particionada: la prueba del paralelismo real |
| `evidencias/04-escalado/log-particionado-grid4.txt` | Log crudo de 4 particiones terminando en 4 hilos distintos |
| `evidencias/04-escalado/metricas-micrometer.txt` | Qué métricas y qué tags existen de verdad en este build |
| `evidencias/04-escalado/grafico-*.svg` | Los tres gráficos, eje Y desde cero |
| `scripts/consultas-sql/06-particiones.sql` | Duración y desbalance por partición |
| `scripts/consultas-sql/07-comparativa-escalado.sql` | La tabla reconstruida por dos caminos independientes |

### Código

```
src/main/java/cl/duoc/bancoxyz/experiment/
├── EstrategiaEscalado.java            enum SECUENCIAL | MULTI_THREAD | PARTICIONADO
├── CasoExperimento.java               una celda de la matriz (record inmutable)
├── ResultadoExperimento.java          el resultado de UNA ejecución
├── MatrizExperimentos.java            las fases F0 / F1 / F2
├── FabricaJobsExperimento.java        construye Job y Step por caso
├── LectorRangoTransacciones.java      lector único para las 3 estrategias
├── ProcesadorExperimento.java         envuelve el TransaccionProcessor real
├── EjecutorExperimentos.java          orquesta, mide, repite  (@Profile "experiment")
├── AnalizadorResultados.java          mediana, IQR, CV, speedup
├── EscritorResultadosCsv.java         -> results/scaling-results.csv
├── RepositorioMetricasExperimento.java-> banco.ejecucion_metrica
├── AmplificadorDataset.java           generador determinista ×20
├── SondaEntorno.java                  cpus, heap, JVM, tamaño del pool
└── VolcadoMetricasMicrometer.java     evidencia de métricas  (@Profile "metricas")

src/main/resources/application-experiment.yml    pool 24, logging reducido
scripts/graficar.py                              SVG sin dependencias
```

**Nada de esto toca el Job 1.** El banco de pruebas vive en su propio perfil y
en su propio paquete; el flujo de producción quedó intacto y sigue dando
`1000 = 785 + 215`.
