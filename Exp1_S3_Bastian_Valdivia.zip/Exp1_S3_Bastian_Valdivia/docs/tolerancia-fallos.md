# Políticas de reintento y tolerancia a fallos

> Criterio 5 de la pauta (15 pts). Documento de referencia del Job 1
> (`jobTransaccionesDiarias`). La configuración vive en beans reutilizables, así
> que los Jobs 2 y 3 la heredarán sin copiar código.

---

## 1. La doctrina en cuatro líneas

Todo lo que sigue son consecuencias de estas cuatro reglas:

| Situación | Política | Nunca |
|---|---|---|
| **Dato malo irreparable** (fecha `2024-13-01`, monto vacío) | **SKIP** + dead letter | Nunca se reintenta |
| **Dato degradado** (tipo desconocido, edad fuera de rango) | Se **guarda marcado** | Ni skip ni retry |
| **Fallo de infraestructura** (conexión caída, deadlock, timeout) | **RETRY** con backoff | Nunca se hace skip |
| **Cualquier otra cosa** | **FAIL-FAST** | Nunca se traga en silencio |

**Por qué la primera regla:** reintentar una fila cuya fecha es `2024-13-01`
fallará las tres veces exactamente igual — el dato no cambia entre intentos. Con
las 215 filas malas del CSV serían 645 intentos inútiles más el backoff, para
acabar en el mismo sitio.

**Por qué la tercera:** una conexión caída es *pasajera*. El mismo dato, que es
bueno, escrito medio segundo después entra sin problema. Hacer skip aquí sería
tirar datos correctos a la basura por un hipo de red, y encima el job terminaría
`COMPLETED` mintiendo sobre lo que cargó.

**Por qué la cuarta:** un `.skip(Exception.class)` perezoso se tragaría un
"archivo no encontrado" y el job terminaría `COMPLETED` con cero filas. *Un job
que miente es peor que un job que falla.*

---

## 2. Componentes

| Componente | Fichero | Qué hace |
|---|---|---|
| `RetryPolicies.infraestructura()` | `policy/RetryPolicies.java` | `SimpleRetryPolicy(3, mapa, traverseCauses=true)`. Solo infraestructura; el veto a los datos sucios viaja **dentro del mapa** |
| `BackOffPolicies.exponencial()` | `policy/BackOffPolicies.java` | `ExponentialBackOffPolicy` 200 ms × 2.0, tope 5 s |
| `BancoXyzSkipPolicy` | `policy/BancoXyzSkipPolicy.java` | `shouldSkip(Throwable, long)`, modo sonda, recorre causas, techo configurable |
| `ReintentoRetryListener` | `listener/ReintentoRetryListener.java` | Log de cada intento fallido |
| `ChunkErrorListener` | `listener/ChunkErrorListener.java` | Log de cada rollback, con la causa vía `ROLLBACK_EXCEPTION_KEY` |
| `RechazoListener` | `listener/RechazoListener.java` | Dead letter en `banco.registro_rechazado`, en transacción propia |
| `ToleranciaFallosConfig` | `config/ToleranciaFallosConfig.java` | Todo lo anterior como beans, en un solo sitio |
| `InyectorFallosWriter` | `support/InyectorFallosWriter.java` | Inyector de fallos **reproducible** |

### Configuración del step (Modelo B puro)

```java
.faultTolerant()
    .skipPolicy(skipPolicyBancoXyz)          // NO se mezcla con .skip()/.skipLimit()
    .retryPolicy(retryPolicyInfraestructura) // NO se mezcla con .retry()/.retryLimit()/.noRetry()
    .backOffPolicy(backOffExponencial)
    .noRollback(RegistroInvalidoException.class)
```

**Por qué no se mezclan los modelos.** Con un `retryPolicy(...)` explícito, un
`.noRetry(X)` solo se tiene en cuenta si además hay `retryLimit > 0`; en caso
contrario **tu veto se ignora en silencio**. Por eso el veto a
`RegistroInvalidoException` está dentro del mapa, con valor `false`. Lo mismo
con skip: `skipPolicy()` + `skip()` se combinan con un OR y anulan el veto.

---

## 3. Cómo reproducir cualquier escenario

No hace falta apagar Docker con el cronómetro en la mano. Un `JobParameter`
llega hasta `InyectorFallosWriter`, un decorador que envuelve al escritor real y
lanza la excepción fingida que toque:

```bash
./mvnw -q spring-boot:run \
  "-Dspring-boot.run.arguments=--job=jobTransaccionesDiarias --simular-fallo=BD_TRANSITORIA"
```

| Valor | Excepción inyectada | Resultado esperado |
|---|---|---|
| `NINGUNO` (defecto) | ninguna | `COMPLETED`, 785 + 215 |
| `BD_TRANSITORIA` | `TransientDataAccessResourceException` × 1 por partición | `COMPLETED` tras reintentar |
| `BLOQUEO` | `CannotAcquireLockException` × 1 por partición | `COMPLETED` tras reintentar |
| `BD_CAIDA_PERMANENTE` | `TransientDataAccessResourceException` siempre | `FAILED` al agotar 3 intentos |
| `ESCRITURA_FATAL` | `DataIntegrityViolationException` | `FAILED` de inmediato |

Con `NINGUNO` el coste es una comparación de cadenas por chunk: la ejecución
normal no cambia.

Dos detalles de diseño que hacen la demostración *repetible*:

- El inyector es `@StepScope`, así que hay **una instancia por partición** y
  cada una falla exactamente una vez. Con un contador compartido, la primera
  partición se comería el presupuesto de fallos y el resultado variaría entre
  corridas.
- La excepción se lanza **antes** de delegar en el escritor real. Si se lanzara
  después, el reintento reinsertaría los mismos ids y el fallo simulado se
  convertiría en corrupción real.

### El parámetro se añade *siempre*

`simularFallo` se añade en **todas** las ejecuciones, con `NINGUNO` por defecto.
No es opcional: `getNextJobParameters` **arrastra** los parámetros de la
ejecución anterior. Si solo se añadiera cuando se pide, la corrida siguiente a un
`--simular-fallo=BD_CAIDA_PERMANENTE` lo heredaría en silencio y volvería a
fallar, con toda la pinta de ser un bug de datos. Añadiéndolo siempre, cada
ejecución declara su escenario y queda escrito en `BATCH_JOB_EXECUTION_PARAMS`.

---

## 4. Los 16 escenarios

Estado: **DEMOSTRADO** = hay test o script que lo ejecuta · **CUBIERTO** = la
política está escrita y probada en unitario, sin demo end-to-end ·
**NO IMPLEMENTADO** = declarado aquí pero sin código ni evidencia detrás.

> Los Jobs 2 y 3 **ya están implementados y verificados**. Las filas que antes
> decían «JOB 2» estaban desactualizadas: subvaloraban trabajo que hoy se puede
> comprobar con una consulta. Se han reevaluado una por una contra la base de
> datos y contra la suite de tests, y solo E10 sigue sin implementar (ver su
> nota, que es deliberadamente honesta).

### Grupo A — Datos irrecuperables → SKIP + dead letter

| # | Escenario | Qué lo provoca | Qué hace el sistema | Cómo se comprueba | Estado |
|---|---|---|---|---|---|
| **E1** | Fecha imposible (mes 13) | 55 filas `2024-13-01`; los 4 formatos fallan → `RegistroInvalidoException(FECHA_INVALIDA)` | Skip *inline* (`noRollback`), sin rollback ni scanning; dead letter | `SELECT COUNT(*) … motivo='FECHA_INVALIDA'` = **55** · `JobTransaccionesTest` | **DEMOSTRADO** |
| **E2** | Monto ausente | 160 filas con `monto` vacío (tras precedencia) | Skip + dead letter, motivo `MONTO_AUSENTE`. Distinto de `MONTO_NO_NUMERICO` | `SELECT COUNT(*) … motivo='MONTO_AUSENTE'` = **160** · `JobTransaccionesTest` | **DEMOSTRADO** |
| **E3** | Saldo ausente | 211 filas sin `saldo` en `intereses.csv`; sin saldo no hay interés | Skip + dead letter, motivo `SALDO_AUSENTE` | `SELECT COUNT(*) … archivo_origen='intereses.csv' AND motivo='SALDO_AUSENTE'` = **211** · `InteresProcessorTest` («Rechazos (fase PROCESS)») · `JobInteresesTest` («Procesa las 1000 filas: 784 + 216») | **DEMOSTRADO** |
| **E4** | Duplicado exacto (fase WRITE) | 5 filas idénticas en `intereses.csv` → `DuplicateKeyException` contra `uq_interes_posicion` | Skip en fase WRITE + `onSkipInWrite` | `SELECT COUNT(*) … motivo='DUPLICADO'` = **5** · `JobInteresesTest` · prueba B9 de `scripts/consultas-sql/auditar-esquema.sql` | **DEMOSTRADO** |

> **E4 — por qué un duplicado es «dato sucio» y no «fallo de infraestructura».**
> `BancoXyzSkipPolicy.esDatoSucio()` reconoce hoy tres excepciones:
> `RegistroInvalidoException`, `FlatFileParseException` y **`DuplicateKeyException`**.
> La tercera es la única que no nace en el processor sino en la fase WRITE,
> cuando PostgreSQL rechaza el `INSERT` por violar `uq_interes_posicion`.
>
> El razonamiento para omitirla: una fila repetida es un **dato malo**, no una
> base caída — de hecho la base está funcionando *perfectamente*, que por eso
> detecta el duplicado. Y reintentarla fallaría las tres veces igual, porque el
> dato no cambia entre intentos; un retry aquí solo gastaría tiempo para acabar
> matando el step. Omitir y mandar al dead letter es la única respuesta útil.
>
> Ojo al matiz que hace que esto **no** sea peligroso en el Job 1: allí el `id`
> del CSV es la PRIMARY KEY de `banco.transaccion`, y una reinserción duplicada
> sería un bug real. Lo que impide que se cuele es que el step de preparación
> vacía la tabla antes de cada carga, así que un duplicado en el Job 1 solo
> puede venir del propio fichero — que es exactamente un dato sucio.

### Grupo B — Datos degradados → marcar, NO skip

| # | Escenario | Qué lo provoca | Qué hace el sistema | Cómo se comprueba | Estado |
|---|---|---|---|---|---|
| **E5** | Tipo desconocido masivo | 371 filas (`invalid` 308 + `desconocido` 63) | **Deliberadamente NO es skip.** Se canoniza a `DESCONOCIDO`, estado `ANOMALA_TIPO_DESCONOCIDO` | `estado='ANOMALA_TIPO_DESCONOCIDO'` = **230** y **no** aparecen en `PROCESS_SKIP_COUNT` | **DEMOSTRADO** |
| **E6** | Edad fuera de rango | `edad=100`, `edad=150`, vacía | Saneado a `NULL` + `ANOMALA_EDAD_FUERA_RANGO`. El `CHECK` de la BD queda como red de seguridad: si salta, **no es omitible** (sería un bug del processor) | `estado='ANOMALA_EDAD_FUERA_RANGO'` = **96** y `ANOMALA_EDAD_AUSENTE` = **101** en `banco.interes_calculado` · `InteresProcessorTest` («Precedencia del estado») · prueba B7 de `auditar-esquema.sql` | **DEMOSTRADO** |
| **E7** | Monto negativo / cero | 136 negativos + 18 ceros | Se guardan con `ANOMALA_MONTO_NEGATIVO` / `ANOMALA_MONTO_CERO` | Conteo por estado = **136** y **18** · `JobTransaccionesTest` | **DEMOSTRADO** |

> **Por qué E5 cuenta como escenario.** Es la decisión explícita de **no** usar
> tolerancia a fallos donde el coste sería prohibitivo: si esas 371 filas fueran
> skip, agotarían cualquier `skipLimit` razonable y se perdería el 37 % del
> archivo. Saber cuándo *no* aplicar una política es parte de tener una.

### Grupo C — Infraestructura → RETRY, NUNCA skip

| # | Escenario | Qué lo provoca | Qué hace el sistema | Cómo se comprueba | Estado |
|---|---|---|---|---|---|
| **E8** | Caída transitoria de la BD | `--simular-fallo=BD_TRANSITORIA` | Reintenta (200 ms, ×2, tope 5 s) y se recupera. **Nunca** skip | `scripts/escenarios-fallo/escenario-bd-transitoria.sh` · `EscenariosFalloTest#fallosTransitorios…` | **DEMOSTRADO** |
| **E8-bis** | La BD no vuelve | `--simular-fallo=BD_CAIDA_PERMANENTE` | Agota los 3 intentos y **mata el step**. No se omite ni una fila buena | `scripts/escenarios-fallo/escenario-bd-caida.sh` · `EscenariosFalloTest#siLaInfraestructuraNoVuelve…` | **DEMOSTRADO** |
| **E9** | Contención de bloqueo | `--simular-fallo=BLOQUEO` (`CannotAcquireLockException`) | Reintenta. Recorre **otra rama** del mapa que E8 | `scripts/escenarios-fallo/escenario-bloqueo.sh` · `EscenariosFalloTest#laContencionDeBloqueo…` | **DEMOSTRADO** |
| **E10** | Cuenta inexistente en el UPDATE | CSV con `cuenta_id=999` → `assertUpdates(true)` → 0 filas afectadas | Dead letter con motivo `CUENTA_INEXISTENTE` | — | **NO IMPLEMENTADO** |
| **E11** | Archivo ausente / fallo no clasificado | Mover el CSV, o `--simular-fallo=ESCRITURA_FATAL` | **Ni retry ni skip: fail-fast.** El step muere con mensaje legible | `scripts/escenarios-fallo/escenario-escritura-fatal.sh` · `PoliticasToleranciaTest#noOmiteElArchivoAusente` | **DEMOSTRADO** |
| **E12** | Rechazo del TaskExecutor | `queueCapacity < gridSize` con muchas particiones | Particiones marcadas `FAILED` **sin excepción visible**. Prevención: `queueCapacity ≥ gridSize` validado al arrancar en `TaskExecutorConfig` | Revisión de `TaskExecutorConfig` | **CUBIERTO** |

> **E10 — declaración honesta, y por qué se queda fuera.** Este escenario
> **no está implementado y no se reclama como demostrado.** El motivo
> `CUENTA_INEXISTENTE` existe en la lista blanca de `RechazoListener` y en el
> `CHECK ck_rechazo_motivo` del esquema, pero **ningún processor lo emite,
> ningún test lo ejercita y no hay ni una fila con ese motivo en
> `banco.registro_rechazado`** (compruébalo: `SELECT motivo, COUNT(*) FROM
> banco.registro_rechazado GROUP BY 1` devuelve solo `FECHA_INVALIDA`,
> `MONTO_AUSENTE`, `SALDO_AUSENTE` y `DUPLICADO`).
>
> La razón de fondo es que ninguno de los tres jobs hace un `UPDATE` fila a fila
> contra una cuenta preexistente: el Job 2 escribe `banco.interes_calculado` con
> `INSERT` y consolida con un `INSERT … ON CONFLICT`, así que la situación
> «0 filas afectadas por cuenta inexistente» nunca llega a darse. Dejar el
> motivo declarado en el esquema es barato y prepara el terreno; marcarlo como
> demostrado sería mentir sobre la evidencia.

**E9 — la solución estructural.** Reintentar es la red de seguridad; la cura es
particionar el Job 2 por `cuenta_id`, lo que da afinidad hilo↔cuenta y hace el
deadlock imposible por construcción. Se elige la partición por **corrección
concurrente**, no por velocidad.

### Grupo D — Umbral, reinicio e idempotencia

| # | Escenario | Qué lo provoca | Qué hace el sistema | Cómo se comprueba | Estado |
|---|---|---|---|---|---|
| **E13** | Techo de tolerancia superado | `--banco.tolerancia.limite-omisiones=10` con 215 filas malas | `SkipLimitExceededException` → job `FAILED` **a propósito** | `scripts/escenarios-fallo/escenario-limite-omisiones.sh` · `PoliticasToleranciaTest#aplicaElTechoDeTolerancia` | **DEMOSTRADO** |
| **E14** | Interrupción y reinicio | Matar el proceso a mitad del step | Al relanzar con los mismos parámetros, el step de preparación **y** el manager se vuelven a ejecutar (los dos llevan `allowStartIfComplete`), así que la limpieza y la recarga se repiten **juntas** y se regeneran **todas** las particiones | Dos `JOB_EXECUTION_ID` para una `JOB_INSTANCE_ID` · `ReinicioParticionesTest` · 3.ª corrida de `escenario-doble-ejecucion.sh` | **DEMOSTRADO** |
| **E15** | Doble aplicación de interés | Ejecutar el job de intereses dos veces con el mismo periodo | Guarda de **contenido** en el `ON CONFLICT` (periodo + `n_posiciones` + `saldo_inicial` + `interes_aplicado`), más `stepValidarConsolidadoIntereses` | `SUM(saldo)` idéntico antes y después · `JobInteresesTest` («Dos corridas del mismo periodo NO reaplican el interes») · log `0 filas afectadas sobre 784 filas de detalle` | **DEMOSTRADO** |
| **E16** | Relanzamiento y recuperación tras fallo | Ejecutar dos veces seguidas; o fallar y relanzar | `RunIdIncrementer` + `stepPrepararTransacciones`. Ambas corridas dan 785 + 215 | `scripts/escenarios-fallo/escenario-doble-ejecucion.sh` · `EscenariosFalloTest#trasElFallo…` · `JobTransaccionesTest#sePuedeEjecutarDosVeces…` | **DEMOSTRADO** |

**Recuento:** **14 escenarios DEMOSTRADOS** con test, script o consulta SQL
reproducible; **1 CUBIERTO** por diseño (E12, el rechazo del `TaskExecutor`, que
se previene validando `queueCapacity ≥ gridSize` al arrancar); **1 NO
IMPLEMENTADO** y declarado como tal (E10). El descriptor pide no omitir 2 o más.

El salto respecto de la versión anterior de este documento (que decía «10
demostrados, 5 pendientes de los Jobs 2 y 3») no es trabajo nuevo: es que E3,
E4, E6 y E15 ya estaban implementados y verificados en el Job 2, y la tabla no
se había actualizado. E14 pasó a DEMOSTRADO al corregirse el reinicio.

---

## 5. Dos fallos reales encontrados al construir esto

No son hipótesis: se encontraron ejecutando los escenarios, y ambos eran
**invisibles** hasta que se provocó un reintento de verdad.

### 5.1 El dead letter se borraba con el rollback

Con `BD_TRANSITORIA`, la cuadratura se rompía:

```
CUADRATURA ROTA en transacciones.csv: entrada=1000 pero
negocio=785 + rechazadas=42 + filtradas=0 = 827. Faltan 173 filas.
```

El `RechazoListener` se ejecutaba las 215 veces que debía — los cuatro workers
sumaban `57+40+53+65 = 215` en su propio contador — pero en la tabla solo
quedaban **42** filas.

**Causa:** los `SkipListener` se ejecutan **dentro de la transacción del chunk**.
Cuando el escritor falla, el chunk entero hace rollback, y ese rollback se lleva
por delante los rechazos ya insertados. Las filas de negocio se reescriben al
reintentar, así que no se notaba; los rechazos no se vuelven a insertar, porque
una omisión ya registrada no se notifica dos veces.

**Arreglo:** el INSERT del dead letter va en `PROPAGATION_REQUIRES_NEW` — el
mismo patrón que ya usaba `ControlCargaDao.upsert()`. *La evidencia de un fallo
no puede vivir en la transacción que ese fallo va a deshacer.* Verificado
después del arreglo: **215 exactas, no 216** — no hay duplicación.

### 5.2 El `ReintentoRetryListener` no estaba registrado

Los reintentos ocurrían, pero **no se escribía ni una línea de log**. Auditoría
inexistente, sin ningún síntoma.

**Causa: resolución de sobrecargas de Java, no Spring.** Los `.listener(...)` no
devuelven siempre el mismo tipo:

```
FaultTolerantStepBuilder          → tiene listener(RetryListener)
  .listener(StepExecutionListener) → declarado en StepBuilderHelper,
                                     devuelve AbstractTaskletStepBuilder
AbstractTaskletStepBuilder        → ya NO tiene listener(RetryListener)
```

Tras el primer `.listener((StepExecutionListener) …)`, la llamada
`.listener((RetryListener) …)` ya no encontraba su sobrecarga y Java la resolvía
contra `listener(Object)`, que solo busca anotaciones y **con un `RetryListener`
no hace nada**. Compila, no avisa, y te deja sin auditoría de reintentos. Es
también la razón de que `ChunkErrorListener` sí funcionara: `listener(ChunkListener)`
sí existe en `AbstractTaskletStepBuilder`.

**Arreglo:** guardar el `FaultTolerantStepBuilder` en una variable y registrar
ahí el `RetryListener`, antes de que el tipo se degrade al encadenar.

### 5.3 Un log que mentía

El `close()` del listener decía `RECUPERADO tras 3 intentos` incluso cuando el
job terminaba `FAILED`. En el reintento **con estado** de Batch, al agotarse los
intentos no se propaga la excepción por `close()`, sino que se entra en la ruta
de recuperación: desde el listener el desenlace **no se ve**. El log ahora se
limita a los hechos que sí constan (intentos gastados, si se llegó al tope).

---

## 6. Matiz obligatorio: `skipLimit` es **por partición**

El límite de omisiones se aplica **por `StepExecution`**, y en un step
particionado hay una por partición. Con 4 particiones y límite 500, el job entero
tolera hasta **2000** omisiones, no 500.

Por eso el techo de omisiones **no** es la garantía de que no se pierde nada. La
garantía es `stepValidarCuadraturaTransacciones`, que compara
`entrada = negocio + rechazadas + filtradas` y hace **fallar el job** si no
cuadra. Es lo que convirtió el fallo 5.1 —que habría pasado desapercibido— en un
job rojo con un mensaje explícito.

---

## 7. Verificación ejecutada

```
./mvnw -q compile     -> exit 0
./mvnw -q test        -> exit 0

[INFO] Tests run: 5,   Failures: 0, Errors: 0  -- EscenariosFalloTest
[INFO] Tests run: 3,   Failures: 0, Errors: 0  -- JobTransaccionesTest
[INFO] Tests run: 3,   Failures: 0, Errors: 0  -- JobInteresesTest
[INFO] Tests run: 4,   Failures: 0, Errors: 0  -- JobAnualesTest
[INFO] Tests run: 13,  Failures: 0, Errors: 0  -- PoliticasToleranciaTest
[INFO] Tests run: 34,  Failures: 0, Errors: 0  -- RangoCuentaPartitionerTest
[INFO] Tests run: 1,   Failures: 0, Errors: 0  -- ReinicioParticionesTest
[INFO] Tests run: 149, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
[INFO] BUILD SUCCESS
```

Arranque limpio: **cero `WARN`** en el log de arranque. Había dos, y los
provocaba este mismo trabajo: declarar `transaccionWriterTolerante` con tipo de
retorno `ItemWriter` hacía que Spring Batch avisara de que, tras el proxy de
`@StepScope`, no podía inspeccionar la clase real en busca de anotaciones de
listener. Se corrigió devolviendo la clase concreta.

Secuencia completa contra PostgreSQL 17 en Docker — incluye una corrida rota a
propósito en medio, que es la secuencia que un evaluador produce sin querer:

| # | job_execution_id | escenario | status | entrada | negocio | rechazadas | cuadra |
|---|---|---|---|---|---|---|---|
| 1 | 12 | `NINGUNO` | COMPLETED | 1000 | 785 | 215 | `t` |
| 2 | 13 | `BD_TRANSITORIA` | COMPLETED | 1000 | 785 | 215 | `t` |
| 3 | 14 | `BD_CAIDA_PERMANENTE` | **FAILED** | — | — | — | — |
| 4 | 15 | `NINGUNO` | COMPLETED | 1000 | 785 | 215 | `t` |
| 5 | 16 | `NINGUNO` | COMPLETED | 1000 | 785 | 215 | `t` |

La ejecución 14 no tiene fila en `control_carga` porque murió antes del step de
cuadratura: correcto, y observable.

Evidencia del reintento (ejecución 13):

```
REINTENTO | hilo=particion-2 | intento 1 fallido (total acumulado 1) |
  TransientDataAccessResourceException: FALLO SIMULADO: conexion perdida con la base
CHUNK ROLLBACK | step=…:partition0 | causa=TransientDataAccessResourceException: FALLO SIMULADO…
CUADRATURA OK en transacciones.csv: 1000 = 785 + 215 + 0
=== jobTransaccionesDiarias terminó con estado COMPLETED ===
```

Evidencia del agotamiento (ejecución 14) — lo dice el propio framework:

```
REINTENTO | TOPE ALCANZADO: 3 intento(s) gastados en este bloque.
org.springframework.retry.ExhaustedRetryException:
  Retry exhausted after last attempt in recovery path, but exception is not skippable.
```

Esa última frase es la doctrina entera en una línea: se agotaron los reintentos
**y** se comprobó que la excepción no era omitible, así que el step muere.

---

## 8. Scripts

| Script | Escenario |
|---|---|
| `scripts/escenarios-fallo/escenario-bd-transitoria.sh` | E8 — reintento que recupera |
| `scripts/escenarios-fallo/escenario-bloqueo.sh` | E9 — contención de cerrojo |
| `scripts/escenarios-fallo/escenario-bd-caida.sh` | E8-bis — reintentos agotados → `FAILED` |
| `scripts/escenarios-fallo/escenario-escritura-fatal.sh` | E11 — fail-fast de lo no clasificado |
| `scripts/escenarios-fallo/escenario-limite-omisiones.sh` | E13 — techo de tolerancia |
| `scripts/escenarios-fallo/escenario-doble-ejecucion.sh` | E16 — doble ejecución y recuperación |

Los seis pasan `bash -n`. Se han **ejecutado de verdad**, no solo comprobado de
sintaxis, `escenario-bd-transitoria.sh`, `escenario-limite-omisiones.sh` y
`escenario-doble-ejecucion.sh`; los otros tres reutilizan la misma consulta SQL
y el mismo mecanismo de inyección, ya verificados por sus tests equivalentes.

Salida real de `escenario-limite-omisiones.sh` (E13) — confirma además que la
propiedad llega hasta el bean por línea de comandos, sin recompilar:

```
REINTENTO | hilo=particion-3 | intento 1 fallido |
  SkipLimitExceededException: Skip limit of '10' exceeded
=== jobTransaccionesDiarias terminó con estado FAILED ===
```

Salida real de `escenario-doble-ejecucion.sh` (E16), con la corrida rota en medio:

```
 job_execution_id | escenario |  status   | filas_negocio | filas_rechazadas | cuadra
               27 | NINGUNO   | COMPLETED |           785 |              215 | t
               25 | NINGUNO   | COMPLETED |           785 |              215 | t
               24 | NINGUNO   | COMPLETED |           785 |              215 | t
```

La ejecución 26 (`BD_CAIDA_PERMANENTE`) no aparece: murió antes del step de
cuadratura. Y la 27, lanzada justo después, **no heredó** el escenario — que es
exactamente lo que este escenario venía a demostrar.
