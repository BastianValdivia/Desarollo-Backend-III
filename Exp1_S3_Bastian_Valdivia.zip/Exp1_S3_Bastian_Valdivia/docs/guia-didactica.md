# Guía didáctica — Exp1 S3, Banco XYZ con Spring Batch

Cómo entender y ejecutar la actividad para llegar a los 100 puntos.
Esta guía explica el **porqué**; el paso a paso operativo está en [`plan-maestro.md`](plan-maestro.md)
y los detalles de API verificados en [`referencia-tecnica/`](referencia-tecnica/).

---

## Parte 0 — Qué te están pidiendo de verdad

El enunciado se lee como "haz tres jobs de Spring Batch". Pero si lo desmontas, lo que evalúan es
otra cosa: **si sabes construir un proceso batch que no se rompe con datos sucios y que aprovecha
el paralelismo con criterio**. Los tres jobs son la excusa; la resiliencia y el escalado son la materia.

Eso se nota en la pauta: de los 100 puntos, **30 están en escalado + tolerancia a fallos**
(criterios 4 y 5) y otros 15 en "aplicar las políticas optimizando tiempos y estabilidad"
(criterio 6). Casi la mitad de la nota no está en que el job funcione, sino en **cómo se comporta
cuando algo va mal y cuánto rinde**.

La traducción práctica:

| Lo que dice el enunciado | Lo que se evalúa realmente |
|---|---|
| "Configura Jobs y Steps" | Que la arquitectura tenga piezas separadas y nombradas, no un job monolítico |
| "Procesa todos los datos" | Que las 1000 filas de cada CSV estén contabilizadas al final, ninguna perdida |
| "Aplica transformaciones y validaciones" | Que repares lo reparable en vez de tirarlo |
| "Implementa escalado" | Que **compares configuraciones** y justifiques cuál es la óptima |
| "Políticas de reintento y tolerancia" | Que distingas *dato sucio* de *fallo de infraestructura* |
| "Sube el código, documenta, evidencia" | Que el evaluador pueda levantar tu proyecto en 3 comandos |

---

## Parte 1 — El modelo mental de Spring Batch

Antes de escribir código conviene tener la imagen mental correcta. Piensa en una **línea de montaje**.

```
                    ┌──────────────── JOB (la orden de producción) ────────────────┐
                    │                                                              │
                    │   STEP 1            STEP 2                    STEP 3         │
                    │  (estación)        (estación)                (estación)      │
                    │  ┌────────┐    ┌──────────────────────┐    ┌────────────┐    │
                    │  │Tasklet │ →  │ Reader→Processor→Writer│ → │  Tasklet   │    │
                    │  │limpieza│    │      (chunk)          │    │  resumen   │    │
                    │  └────────┘    └──────────────────────┘    └────────────┘    │
                    └──────────────────────────────────────────────────────────────┘
                                              │
                                   ┌──────────▼──────────┐
                                   │   JobRepository     │  ← el cuaderno de bitácora
                                   │  (tablas BATCH_*)   │     (permite reiniciar)
                                   └─────────────────────┘
```

**Job** = la orden de producción completa. **Step** = una estación de la línea. Un job son varios
steps en secuencia.

Hay dos tipos de step:

- **Tasklet**: una sola tarea de principio a fin ("borra la tabla", "ejecuta este SQL agregado").
  Se ejecuta una vez y termina.
- **Chunk-oriented**: el caballo de batalla. Tiene tres piezas:
  - **ItemReader** — lee un ítem cada vez desde el origen (CSV, tabla…).
  - **ItemProcessor** — recibe un ítem, lo transforma/valida, devuelve otro (o `null`).
  - **ItemWriter** — recibe **una lista** de ítems y los escribe de golpe.

### El concepto que hay que entender bien: el *chunk*

Con `chunk(200)` el ciclo es:

```
leer 1, leer 2, ... leer 200        (200 llamadas al reader, de una en una)
procesar 1, procesar 2, ... 200     (200 llamadas al processor, de una en una)
escribir([1..200])                  (UNA sola llamada al writer, con la lista)
COMMIT                              ← aquí se cierra la transacción
```

**La transacción es el chunk.** Eso tiene tres consecuencias que se pagan en la nota:

1. Un `chunkSize` grande = menos commits = más rápido, pero más memoria y más pérdida si falla.
2. Un `chunkSize` pequeño = más commits = más lento, pero errores más acotados.
3. **Si el writer falla, todo el chunk hace rollback** y Spring Batch lo reprocesa **ítem a ítem**
   para averiguar cuál era el malo. Se llama *chunk scanning* y con `chunk(200)` significa
   201 llamadas extra a `write()`. Por eso el `chunkSize` se elige distinto según el job:
   donde esperas conflictos de escritura, chunk pequeño.

### `JobRepository`: por qué Spring Batch no es un simple bucle

Spring Batch escribe en una base de datos (tablas `BATCH_JOB_INSTANCE`, `BATCH_STEP_EXECUTION`…)
qué job corrió, con qué parámetros, cuántas filas leyó, cuántas omitió y en qué step murió. Eso es
lo que permite **reiniciar** un job y que retome donde iba. También es tu mejor fuente de evidencia:
la mitad de las consultas SQL que vas a enseñar al evaluador salen de ahí.

### Particiones: abrir varias líneas de montaje

Una partición no es "hacer el step más rápido". Es **clonar el step N veces**, dando a cada clon un
trozo distinto de los datos:

```
                    stepCargarManager   ← el "manager": NO procesa nada, sólo reparte
                            │
              Partitioner: divide el trabajo en N trozos
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
   worker:partition0   worker:partition1   worker:partition2     ← copias del MISMO step
   cuentas 101-116     cuentas 117-133     cuentas 134-150         cada una en su hilo
        │                   │                   │
        └───────────────────┼───────────────────┘
                            ▼
                    se juntan los resultados
```

Piezas y para qué sirve cada una:

| Pieza | Rol |
|---|---|
| `Partitioner` | Decide **cómo se corta** el trabajo. Devuelve un `ExecutionContext` por partición con, p. ej., `minValue=101, maxValue=116`. |
| `PartitionHandler` | Decide **cómo se ejecutan** las particiones. `TaskExecutorPartitionHandler` las lanza en hilos. |
| `TaskExecutor` | El pool de hilos real. |
| Manager step | El que orquesta. **Es el que va en `job.start(...)`.** |
| Worker step | El step normal (reader/processor/writer) que se clona por partición. |

**El detalle que hace que funcione**: cada partición necesita **su propio reader**, apuntando a su
propio rango. Eso se consigue con `@StepScope`: el bean se crea una vez **por ejecución de step**,
no una vez por aplicación. Y dentro se inyecta el rango con
`@Value("#{stepExecutionContext['minValue']}")`. Sin `@StepScope`, las tres particiones comparten
el mismo reader y el resultado es basura.

### Multi-thread vs particiones (no son lo mismo)

| | Multi-thread (`.taskExecutor()` en un step normal) | Particiones |
|---|---|---|
| Qué hace | **un** step, varios hilos leyendo del **mismo** reader | **N copias** del step, cada una con **su** reader |
| Problema | `FlatFileItemReader` **no es thread-safe**: hay que envolverlo en `SynchronizedItemStreamReader`, y eso serializa la lectura (pierdes gran parte de la ganancia) | cada partición lee su trozo sin competir |
| Reinicio | si falla, falla el step entero | sólo se reintentan las particiones fallidas |
| Metadatos | 1 `StepExecution` | 1 por partición → puedes medir el desbalance |

Para este proyecto **particiones** es la elección correcta, y en el Job 2 no es una cuestión de
velocidad sino de **corrección**: si particionas por `cuenta_id`, cada cuenta la toca un solo hilo y
es imposible que dos hilos actualicen el mismo saldo a la vez. Ese argumento, escrito en el README,
vale puntos en los criterios 4, 5 y 6 a la vez.

---

## Parte 2 — Los datos, y por qué son el corazón del ejercicio

Los CSV de `data/semana_3/` (1000 filas cada uno) están **sucios a propósito**. El detalle completo
está en [`analisis-datos.md`](analisis-datos.md); lo esencial:

- **Cuatro formatos de fecha mezclados** en el mismo archivo (`2024-06-30`, `03-04-2024`,
  `04/05/2024`, `2024/10/15`). Son todos recuperables… salvo 55 filas con `2024-13-01` (mes 13).
- **Montos vacíos, negativos y cero.**
- **Tipos basura**: `invalid`, `desconocido`, `-1`, `unknown` — entre el 33 % y el 37 % de las filas.
- **Edades imposibles**: 100 y 150 años.
- **`depósito` con tilde vs `deposito` sin tilde** — el mismo concepto escrito de dos formas.
- **9 filas exactamente duplicadas** en `intereses.csv`.

Y un dato que hay que comprobar antes de escribir el parser: en los formatos con barra o guion,
**el primer número es el día, no el mes**. Hay 300 filas por archivo con el primer componente > 12
(`24-07-2024`) y ninguna con el segundo > 12. Si asumes `MM/dd/yyyy` revientas 300 filas.

---

## Parte 3 — La decisión que define tu nota

Aquí está el punto donde la mayoría pierde 20-30 puntos sin darse cuenta.

El instinto es: *"validación estricta, lo que no cumple se descarta"*. Si haces eso:

| Archivo | Filas que sobreviven | Filas que tiras |
|---|---|---|
| `transacciones.csv` | 401 / 1000 | **599** |
| `intereses.csv` | 305 / 1000 | **695** |
| `cuentas_anuales.csv` | 686 / 1000 | **314** |

Pero el criterio 2 exige literalmente *"procesando **todos** los datos de entrada y generando la
salida esperada en la base de datos"*, y baja a 12 puntos si *"uno o más datos procesados no cumplen
con la salida esperada"*. **Uno o más. Literalmente una fila.**

### La regla de oro

> **Ninguna fila desaparece en silencio. Entrada = negocio + rechazos. Siempre 1000.**

Cada fila de entrada acaba en uno de dos sitios:

1. **Tabla de negocio** — si es válida, o si es *reparable*.
2. **Tabla de rechazados** (`registro_rechazado`) — con motivo, campo, valor crudo y número de línea.

Y hay **tres** tratamientos, no dos:

| Tratamiento | Cuándo | Ejemplo | Dónde acaba |
|---|---|---|---|
| **Reparar** | el dato está mal escrito pero se entiende | 4 formatos de fecha → ISO; `depósito`→`DEPOSITO`; descripción vacía → `SIN DESCRIPCION` | tabla de negocio, estado `VALIDA` |
| **Marcar** | el dato es legible pero anómalo | monto negativo, tipo `invalid`, edad 150 | tabla de negocio, estado `ANOMALA_*` |
| **Rechazar** | el dato es irrecuperable | fecha mes 13, monto vacío, saldo vacío | tabla de rechazados, con motivo |

Fíjate en el tratamiento **"marcar"**: las 371 filas con `tipo` inválido **no se tiran**. Se guardan
con `tipo = DESCONOCIDO` y `estado = ANOMALA_TIPO_DESCONOCIDO`. Dos razones:

1. Si las tiraras, perderías el 37 % del archivo → criterio 2 hundido.
2. El Job 1 se llama *"detectar anomalías y generar un resumen"*. **Las anomalías son el producto,
   no la basura.** Un job que las descarta no puede reportarlas.

Aplicando esto a `transacciones.csv` (ya verificado sobre los datos reales):

```
VALIDA                     401
ANOMALA_TIPO_DESCONOCIDO   230
RECHAZADA_MONTO_AUSENTE    160
ANOMALA_MONTO_NEGATIVO     136
RECHAZADA_FECHA_INVALIDA    55
ANOMALA_MONTO_CERO          18
                          ----
TOTAL                     1000   ← cuadra
```

Esa cuadratura es **la consulta SQL que cierra la discusión con el evaluador**. Demuestra el
criterio 2 (procesa todo) y el 3 (valida bien) de un golpe. Publica los números esperados en el
README: sin números publicados, "la salida esperada" es opinable.

### El detalle técnico que lo hace posible

El `ItemReader` debe leer **todo como `String`** (clases `TransaccionRaw`, `InteresRaw`…). Si tipas
los campos en el reader, `FlatFileItemReader` lanza `FlatFileParseException` al encontrar
`2024/10/15` en un campo `LocalDate` — y la fila muere **antes** de que tu processor pueda repararla.
Perderías filas reparables y hundirías los criterios 2 y 3 a la vez.

Y en el processor:

```
process(raw):
  1. normaliza todo lo normalizable
  2. si es IRRECUPERABLE → lanza RegistroInvalidoException   (skip + dead letter)
  3. si es RECUPERABLE   → devuelve la entidad con estado ANOMALA_*
  4. si está limpia      → devuelve la entidad con estado VALIDA
  NUNCA devuelve null sin haber registrado antes el rechazo
```

> **Trampa clásica:** devolver `null` en el `ItemProcessor` **filtra** el ítem — no se escribe, no
> cuenta como error, sólo incrementa `filterCount` y desaparece sin dejar rastro. Es la forma más
> fácil de perder 200 filas sin que nada falle.

---

## Parte 4 — Los tres jobs, step a step

El error de arquitectura más caro es hacer **un job = un step**. El enunciado nombra tres verbos por
job ("procesar… **y generar un resumen**", "aplicar intereses **y actualizar el saldo en BD**",
"compilar datos **y generar un informe**"). Cada verbo es un step. Un job de un solo step es un
"componente omitido" → criterio 1 baja a 12.

### Job 1 — `jobTransaccionesDiarias`

| Step | Tipo | Qué hace |
|---|---|---|
| `stepPrepararTransacciones` | Tasklet | limpia el staging de la corrida anterior |
| `stepCargarTransaccionesManager` | **PartitionStep** | reparte por rango de `id` (1..1000) |
| `stepCargarTransaccionesWorker` | chunk(200) fault-tolerant | normaliza, clasifica, escribe a `transaccion` + `registro_rechazado` |
| `stepResumenDiario` | Tasklet SQL | agrega por fecha → `resumen_diario` (nº operaciones, créditos, débitos, **nº anomalías**) |
| `stepValidarCuadratura` | Tasklet | comprueba `negocio + rechazos = 1000` y **falla el job si no cuadra** |

### Job 2 — `jobInteresesMensuales`

Particionado **por `cuenta_id` (101..150)**. Chunk pequeño (50) porque el `UNIQUE` que detecta los
9 duplicados dispara *chunk scanning* y conviene acotar su coste.

Las tasas **no vienen en el enunciado: las decides tú y las documentas**. Por ejemplo ahorro 0,30 %,
préstamo 1,80 %, hipoteca 0,90 % mensual; tipo desconocido → tasa 0 (decisión de negocio explícita).
Y **`BigDecimal` con `setScale(2, HALF_UP)`, nunca `double`** — un evaluador de backend lo detecta al vuelo.

El step final (`stepConsolidarSaldos`) hace un `INSERT … SELECT SUM … ON CONFLICT DO UPDATE` con
guarda de periodo, para que **correr el job dos veces no aplique el interés dos veces**. El evaluador
va a ejecutar tu job dos veces; si el saldo se duplica, es un fallo grave de criterio 5 y 6.

### Job 3 — `jobEstadosCuentaAnuales`

Particionado por `cuenta_id` (101..120). Carga los movimientos normalizados, luego un step de
consolidación por cuenta (`estado_cuenta_anual`: totales por tipo, saldo neto, nº anomalías) y un
step final que **exporta el informe a archivo** — el "informe detallado para auditorías" que pide
el enunciado, literalmente.

---

## Parte 5 — Escalado: el criterio donde más fácil se pierden 3 puntos

Lee el descriptor con lupa:

> *100 %: "Implementa correctamente técnicas de escalado… **comparando diferentes parámetros para
> encontrar la configuración óptima**".*
> *80 %: "Implementa técnicas de escalado y procesamiento paralelo, **pero no compara ejecuciones
> con diferentes parámetros** para encontrar el óptimo".*

Está escrito ahí: si implementas particiones y corres una vez, tienes 12, no 15. Y "comparar" no es
poner dos números como hace la guía de FreshMart (329 ms vs 234 ms). Necesitas **barrer al menos dos
parámetros** (`chunkSize` **y** `gridSize`/threads) con varios niveles y **repeticiones**.

Diseño escalonado, para no hacer 96 corridas:

1. **Fase 0 — baseline secuencial**: `chunkSize ∈ {10, 50, 100, 500}`, sin paralelismo. Sale el `chunk*` óptimo.
2. **Fase 1 — paralelismo**: fijas `chunk*` y cruzas `{multi-thread, particiones} × {2, 4, 8}`.
3. **Fase 2 — confirmación**: la mejor celda de F1 con los dos mejores `chunkSize`, para descartar
   que los factores interactúen.

Con 5-7 repeticiones por celda, descartando las primeras como *warm-up* (el JIT de la JVM hace que
la primera corrida sea siempre más lenta), y reportando **mediana + dispersión**, no sólo la media.

### La trampa de honestidad (y por qué sube la nota)

Con 1000 filas **el paralelismo no va a ganar**. El coste de crear el pool de hilos y coordinar las
particiones domina sobre el trabajo real; es normal que el particionado salga *más lento* que el
secuencial. La tentación es maquillar el número.

**No lo hagas.** Reportar "a esta escala los intervalos se solapan y el overhead domina; el
particionado sólo compensa a partir de N filas" — y demostrarlo amplificando el dataset a 100.000
filas — vale **más** que un speedup inventado. Eso es análisis; lo otro es ruido presentado como
resultado. Y encaja con la ley de Amdahl, que puedes aplicar con tus propios números.

### Cuatro trampas técnicas que hacen falso el resultado

| Trampa | Síntoma |
|---|---|
| `PartitionStepBuilder` sin `.taskExecutor(...)` | cae silenciosamente a ejecución **secuencial**: tu "particionado" es un secuencial con overhead |
| Pool Hikari por defecto (10 conexiones) < gridSize | estás midiendo el pool de conexiones, no el paralelismo |
| `SimpleAsyncTaskExecutor` usado como "pool" | **no reutiliza hilos nunca**; crea uno por tarea |
| `ThreadPoolTaskExecutor` con `queueCapacity` < nº particiones | particiones marcadas `FAILED` **sin excepción visible** |

Y la prueba de que el paralelismo es real: el log debe mostrar **nombres de hilo distintos** por
partición (`taskExecutor-1`, `taskExecutor-2`…). Captúralo.

---

## Parte 6 — Tolerancia a fallos: la distinción que lo ordena todo

El descriptor cuenta **escenarios**: baja a 12 si no consideras 1 escenario, a 9 si no consideras 2
o más. Así que hay que **enumerarlos explícitamente** en una tabla del README. Si escribes
"implementé retry y skip", el evaluador cuenta uno.

### Retry ≠ Skip (y confundirlos es el error clásico)

| | **Retry** (reintentar) | **Skip** (omitir) |
|---|---|---|
| Para qué | fallos **transitorios**: la BD parpadeó, hubo un deadlock, timeout de red | **datos sucios**: esta fila concreta es inservible |
| Suposición | *"si lo intento otra vez, funcionará"* | *"esto no va a funcionar nunca, sigamos"* |
| Se aplica a | `TransientDataAccessException`, `CannotAcquireLockException` | `ValidationException`, `FlatFileParseException` |
| Error típico | reintentar una `ValidationException`: 371 filas × 3 intentos × backoff = minutos perdidos para nada | omitir una `FileNotFoundException`: te tragas que falta el archivo y el job "termina bien" con 0 filas |

Orden en que Spring Batch los aplica: **primero reintenta, y si agota los reintentos, entonces
consulta la política de skip.** Y el `BackOffPolicy` es la espera entre intentos — exponencial
(200 ms, 400 ms, 800 ms…) para no martillear una BD que ya está sufriendo.

### Escenarios a cubrir

El plan maestro detalla **16**, agrupados en cinco familias. Los imprescindibles:

- **Datos irrecuperables** (skip + dead letter): fecha mes 13, monto ausente, saldo ausente.
- **Duplicado exacto** — es el único que demuestra tolerancia en la **fase de escritura**: un
  `UNIQUE` en BD dispara `DuplicateKeyException` en el writer, que se omite y se registra. Además te
  permite explicar el *chunk scanning*.
- **Datos degradados** (marcar, **no** skip): tipo desconocido, edad fuera de rango, monto negativo.
  Decidir **no** usar skip aquí, y explicar por qué (agotarías cualquier `skipLimit` razonable), es
  en sí mismo un escenario que demuestra criterio.
- **Infraestructura** (retry, **nunca** skip): BD caída 3 segundos, contención de bloqueo.
- **Fail-fast**: archivo de entrada ausente. **No** es omitible ni reintentable — el job debe morir
  con un mensaje claro. Esto demuestra que tu política **distingue** dato sucio de fallo real.
- **Umbral superado**: con `skipLimit` agotado el job falla **a propósito**. La tolerancia sin techo
  es negligencia; demostrar el techo es demostrar la política.
- **Reinicio e idempotencia**: matar el proceso a mitad y relanzarlo (sólo se re-ejecutan las
  particiones fallidas), y correr el Job 2 dos veces sin que el interés se aplique doble.

### Cuatro trampas de API que rompen la política en silencio

| Trampa | Consecuencia |
|---|---|
| `skipLimit` por defecto es **10** | con 40 % de filas sucias el step muere en la fila ~11 y el evaluador ve `FAILED` |
| `SkipPolicy` copiada con firma antigua `shouldSkip(Throwable, int)` | **no sobrescribe** el método (la firma actual usa `long`): tu política **nunca se ejecuta** |
| Mezclar `.skipPolicy(...)` con `.skip()`/`.skipLimit()` | se combinan en **OR**: tu veto queda anulado. Elige un modelo u otro |
| `skipLimit` en un step particionado | el límite es **por partición**, no global: con 8 particiones y límite 500 toleras 4000 skips. Documéntalo |

---

## Parte 7 — La rúbrica descodificada

Truco de lectura: **el descriptor del 80 % te dice exactamente cuál es el error típico.** Está
escrito ahí. Léelos como una lista de cosas a evitar:

| Criterio | Lo que dice el 80 % | Traducción |
|---|---|---|
| 1. Arquitectura (15) | "1 error de estructura o **componente omitido**" | falta el step de resumen/consolidación, o falta el diagrama |
| 2. Ejecución (15) | "**uno o más** datos no cumplen la salida esperada" | perdiste filas: la cuadratura no da 1000 |
| 3. ItemProcessor (15) | "omite más de 2 aspectos que afectan la calidad" | validaste pero no reparaste, o validaste fuera del processor |
| 4. Escalado (15) | "**no compara** ejecuciones con diferentes parámetros" | corriste una vez y pusiste dos números |
| 5. Tolerancia (15) | "no considera **1 escenario** posible de fallo" | no enumeraste los escenarios en una tabla |
| 6. Optimización (15) | "con **1 o 2 errores**" | números mágicos sin justificar, warnings de deprecación, segunda ejecución que revienta |
| 7. Entrega (10) | "entrega **2** aspectos clave" | falta el README completo o falta la evidencia por job |

Las tres cosas que el evaluador hará en los primeros cinco minutos, y para las que hay que estar listo:

1. **Clonar y levantar.** Si no arranca con `docker compose up -d` + `./mvnw` + un comando, todo lo
   demás queda sin verificar y baja por defecto. Prueba las instrucciones en un clon limpio.
2. **Ejecutar el job dos veces.** Sin `JobParametersIncrementer` la segunda tira
   `JobInstanceAlreadyCompleteException` y esa es su primera impresión de tu proyecto.
3. **Mirar la BD.** Tiene que haber datos, no estructura vacía.

---

## Parte 8 — Orden de trabajo sugerido

| Etapa | Qué se hace | Criterios que asegura |
|---|---|---|
| **1. Cimientos** | Proyecto Maven, `compose.yaml` con Postgres, esquema SQL, arranque limpio, `spring.batch.job.enabled=false` + lanzador por `--job=` | 1, 6, 7 |
| **2. Un job completo de punta a punta** | Job 1 **secuencial**: reader `*Raw` → processor → writer + rechazos → cuadratura. Sin particiones todavía | 1, 2, 3 |
| **3. Normalizadores + tests** | `NormalizadorFecha` (4 patrones), `NormalizadorTexto` (tildes), `NormalizadorMonto`, con tests sobre los valores reales del CSV | 3 |
| **4. Tolerancia** | `SkipPolicy` custom, `RetryPolicy`, backoff exponencial, `SkipListener` → dead letter, listeners de auditoría | 5 |
| **5. Particiones** | `Partitioner`, manager/worker, `@StepScope`, pool de hilos. Verificar hilos distintos en el log | 4 |
| **6. Jobs 2 y 3** | Replicar el patrón ya probado; añadir idempotencia en el Job 2 | 1, 2, 3 |
| **7. Benchmark** | Runner de experimentos, matriz F0/F1/F2, CSV de resultados, gráficos, párrafo de conclusión | 4 |
| **8. Escenarios de fallo** | Scripts `escenario-*.sh`, ejecutar cada uno y capturar log + query | 5 |
| **9. Documentación y evidencia** | README con las 3 secciones, `docs/`, `evidencias/` por criterio con `INDICE.md` | 6, 7 |

El orden importa: **un job completo y secuencial antes que ninguna partición**. Si metes paralelismo
sobre una tubería que aún no da resultados correctos, no vas a saber si el fallo es de la lógica o
de la concurrencia.

---

## Nota sobre versiones

La guía de la semana habla de `PartitionHandler`, `setGridSize`, `RetryPolicy`, `BackOffPolicy` y
`SkipPolicy`: es vocabulario de **Spring Batch 5**. En Spring Batch 6 varias de esas clases se
renombraron o quedaron deprecadas, así que usar Batch 6 te obligaría a escribir un código que no se
parece al de la asignatura.

Recomendación: **Spring Boot 3.5.x + Spring Batch 5.2.x + Java 21**, y **decláralo en el README**
diciendo que esa rama ya no recibe soporte OSS y que la elección es pedagógica, para alinearse con
el material del curso. Ese párrafo convierte una debilidad potencial en evidencia de criterio
técnico — exactamente lo que premia el criterio 6.
