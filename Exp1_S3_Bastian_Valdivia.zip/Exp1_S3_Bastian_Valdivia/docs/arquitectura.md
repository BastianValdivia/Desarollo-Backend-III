# Arquitectura Spring Batch — Banco XYZ

> Exp1 S3 · Desarrollo Backend III (PBY2203) · criterio 1 de la pauta.
>
> Este documento describe la arquitectura **tal como esta implementada**, no
> como se planeo. Cada afirmacion de aqui se puede contrastar contra un fichero
> de `evidencias/`, que se indica al lado. Si el codigo y este documento
> discrepan, gana el codigo y este documento esta mal.

---

## 0. El mapa en una frase

Tres Jobs, **19 Steps** y **1 decider**. Los tres Jobs siguen la misma columna
vertebral —preparar, cargar en paralelo, consolidar, validar— y se diferencian
en la estrategia de particionado y en lo que consolidan.

| Job | Fichero de entrada | Steps | Particionador | gridSize | chunk |
|---|---|---:|---|---:|---:|
| `jobTransaccionesDiarias` | `data/transacciones.csv` | 6 + 1 decider | `LineRangePartitioner` | 4 | 200 |
| `jobInteresesMensuales` | `data/intereses.csv` | 6 | `RangoCuentaPartitioner` 101–150 | 5 | 50 |
| `jobEstadosCuentaAnuales` | `data/cuentas_anuales.csv` | 7 | `RangoCuentaPartitioner` 101–120 | 4 | 200 |

> **Discrepancia declarada con `docs/plan-maestro.md`.** El plan maestro
> anuncia «3 Jobs, 14 Steps»; la implementacion tiene **19**. La diferencia se
> explica entera, y en dos tramos:
>
> 1. El plan **se descuadra consigo mismo**: sus propias tablas enumeran 17
>    steps (6 en el Job 1 mas el decider, 5 en el Job 2, 6 en el Job 3), no 14.
>    La cifra 14 sale de contar cada pareja manager/worker como **un solo**
>    step: 17 − 3 = 14.
> 2. Sobre esos 17, la implementacion añadio **2** steps que el plan no
>    preveia: `stepValidarConsolidadoIntereses` y `stepValidarConsolidadoAnual`.
>    17 + 2 = **19**.
>
> Lo que el plan **si** preveia, y conviene decirlo para no atribuirle un olvido
> que no cometio, es `stepExportarEstadosCuenta`: aparece en su descripcion del
> Job 3, literalmente como «el informe para auditorias».
>
> Se deja escrito aqui a proposito: dos documentos del mismo proyecto con dos
> cifras distintas y sin explicacion es exactamente el «error de estructura» que
> penaliza el criterio 1. El desglose real esta en §1 y la prueba en
> `evidencias/01-arquitectura/steps-registrados.txt`, bloque B.

---

## 1. Diagrama de los 3 Jobs

Convenciones del diagrama:

- **Flecha continua** = transicion de flujo (`.next(...)`): el step siguiente
  empieza cuando el anterior termina.
- **Flecha discontinua** = *fan-out* de particionado. **No es una transicion
  de flujo**: el manager no «llama al worker y sigue», sino que crea N
  `StepExecution` del mismo worker y las lanza a la vez en hilos distintos.
  Confundir las dos cosas es el malentendido mas comun del particionado.
- **Rombo** = `JobExecutionDecider`. No es un Step: no se persiste en
  `BATCH_STEP_EXECUTION` y por eso nunca aparece en la evidencia de steps.

```mermaid
flowchart TD

  subgraph J1["JOB 1 · jobTransaccionesDiarias · transacciones.csv"]
    direction TB
    A1["stepPrepararTransacciones<br/><i>Tasklet · LimpiezaTasklet</i>"]
    A2["stepCargarTransaccionesManager<br/><b>PartitionStep</b> · gridSize=4"]
    subgraph WA["stepCargarTransaccionesWorker · chunk 200 · fault tolerant"]
      direction LR
      PA0[":partition0<br/>filas 1..250"]
      PA1[":partition1<br/>filas 251..500"]
      PA2[":partition2<br/>filas 501..750"]
      PA3[":partition3<br/>filas 751..1000"]
    end
    DEC{"deciderCalidadDatos<br/>rechazos / entrada &gt; 0.25 ?"}
    A3["stepAlertaCalidad<br/><i>Tasklet · AlertaCalidadTasklet</i>"]
    A4["stepResumenDiario<br/><i>Tasklet · ResumenDiarioTasklet</i>"]
    A5["stepValidarCuadraturaTransacciones<br/><i>Tasklet · CuadraturaTasklet</i>"]

    A1 --> A2
    A2 -. "reparte 4 particiones" .-> WA
    WA --> DEC
    DEC -- "CALIDAD_DEGRADADA" --> A3
    DEC -- "cualquier otro (*)" --> A4
    A3 -- "COMPLETED" --> A4
    A4 -- "COMPLETED" --> A5
  end

  subgraph J2["JOB 2 · jobInteresesMensuales · intereses.csv"]
    direction TB
    B1["stepPrepararIntereses<br/><i>Tasklet · LimpiezaInteresesTasklet</i>"]
    B2["stepCalcularInteresesManager<br/><b>PartitionStep</b> · gridSize=5"]
    subgraph WB["stepCalcularInteresesWorker · chunk 50 · fault tolerant"]
      direction LR
      PB0[":partition0<br/>cuentas ..110"]
      PB1[":partition1<br/>cuentas 111..120"]
      PB2[":partition2<br/>cuentas 121..130"]
      PB3[":partition3<br/>cuentas 131..140"]
      PB4[":partition4<br/>cuentas 141..<br/>+ ilegibles"]
    end
    B3["stepConsolidarSaldos<br/><i>Tasklet · ConsolidarSaldosTasklet</i>"]
    B4["stepValidarCuadraturaIntereses<br/><i>Tasklet · CuadraturaTasklet</i>"]
    B5["stepValidarConsolidadoIntereses<br/><i>Tasklet · ValidarConsolidadoInteresesTasklet</i>"]

    B1 --> B2
    B2 -. "reparte 5 particiones" .-> WB
    WB --> B3
    B3 --> B4
    B4 --> B5
  end

  subgraph J3["JOB 3 · jobEstadosCuentaAnuales · cuentas_anuales.csv"]
    direction TB
    C1["stepPrepararAnuales<br/><i>Tasklet · PrepararAnualesTasklet</i>"]
    C2["stepCargarMovimientosManager<br/><b>PartitionStep</b> · gridSize=4"]
    subgraph WC["stepCargarMovimientosWorker · chunk 200 · fault tolerant"]
      direction LR
      PC0[":partition0<br/>cuentas ..105"]
      PC1[":partition1<br/>cuentas 106..110"]
      PC2[":partition2<br/>cuentas 111..115"]
      PC3[":partition3<br/>cuentas 116..<br/>+ ilegibles"]
    end
    C3["stepGenerarEstadosCuenta<br/><i>Tasklet · GenerarEstadosCuentaTasklet</i>"]
    C4["stepExportarEstadosCuenta<br/><b>chunk</b> · BD -&gt; fichero de informe"]
    C5["stepValidarCuadraturaAnuales<br/><i>Tasklet · CuadraturaTasklet</i>"]
    C6["stepValidarConsolidadoAnual<br/><i>Tasklet · ValidarConsolidadoAnualTasklet</i>"]

    C1 --> C2
    C2 -. "reparte 4 particiones" .-> WC
    WC --> C3
    C3 --> C4
    C4 --> C5
    C5 --> C6
  end
```

### 1.1 Por que el Job 1 tiene un flujo condicional y los otros dos no

El Job 1 es el unico que **ramifica**. Los Jobs 2 y 3 encadenan con `.next(...)`,
que ya significa «solo si el anterior fue COMPLETED», asi que su flujo es lineal.

En el Job 1, despues de cargar, `DeciderCalidadDatos` lee `banco.control_carga`
y calcula `rechazos / entrada`:

- si supera el umbral (`umbralRechazo`, por defecto **0.25**) devuelve
  `CALIDAD_DEGRADADA` y el flujo pasa por `stepAlertaCalidad`;
- en cualquier otro caso (`"*"`) va directo a `stepResumenDiario`.

Las **dos ramas convergen** en `stepResumenDiario`. Eso es deliberado: la alerta
avisa, no aborta. Un lote sucio se sigue procesando y se sigue resumiendo; lo
que cambia es que queda constancia de que la calidad se degrado.

En la ejecucion de evidencia la tasa fue `215/1000 = 0.215`, por debajo de 0.25,
asi que se tomo la rama `"*"` y **`stepAlertaCalidad` no aparece** en
`evidencias/01-arquitectura/steps-registrados.txt` bloque B. Si aparece en el
bloque A (historico) porque una corrida anterior si lo disparo. Que un step
condicional no salga cuando su condicion no se cumple es la prueba de que la
condicion existe de verdad, no un fallo.

---

## 2. Componente de Spring Batch → clase del proyecto

| Componente de Spring Batch | Que hace en el framework | Clase / bean del proyecto |
|---|---|---|
| `Job` | Unidad de ejecucion completa | `jobTransaccionesDiarias`, `jobInteresesMensuales`, `jobEstadosCuentaAnuales` (beans en `config/*JobConfig.java`) |
| `JobRepository` | Persiste el estado en `batch_meta.BATCH_*` | Autoconfigurado por Boot; esquema fijado en `application.yml` |
| `JobLauncher` | Arranca un Job con sus parametros | `LanzadorJobs` (implementa `ApplicationRunner`, elige el job por `--job=`) |
| `JobParametersIncrementer` | Hace re-ejecutable un Job ya COMPLETED | `RunIdIncrementer`, en los 3 Jobs |
| `Step` (tasklet) | Un paso «todo o nada», sin ciclo de chunk | `LimpiezaTasklet`, `LimpiezaInteresesTasklet`, `PrepararAnualesTasklet`, `ResumenDiarioTasklet`, `ConsolidarSaldosTasklet`, `GenerarEstadosCuentaTasklet`, `AlertaCalidadTasklet`, `CuadraturaTasklet`, `ValidarConsolidadoInteresesTasklet`, `ValidarConsolidadoAnualTasklet` |
| `Step` (chunk) | Ciclo read → process → write con commit por lote | `stepCargarTransaccionesWorker`, `stepCalcularInteresesWorker`, `stepCargarMovimientosWorker`, `stepExportarEstadosCuenta` |
| `PartitionStep` | Step que divide el trabajo y lanza N copias del worker | `stepCargarTransaccionesManager`, `stepCalcularInteresesManager`, `stepCargarMovimientosManager` |
| `Partitioner` | Decide QUE le toca a cada particion | `LineRangePartitioner` (Job 1), `RangoCuentaPartitioner` (Jobs 2 y 3) |
| `PartitionNameProvider` | Da los nombres de particion al reiniciar sin recalcular el reparto | `RangoCuentaPartitioner` |
| `TaskExecutor` | El pool que ejecuta las particiones en paralelo | `TaskExecutorConfig#poolParticiones` — 4 hilos **daemon** llamados `particion-N` |
| `ItemReader` | Lee una fila cada vez | `FlatFileItemReader<TransaccionRaw>`, `FiltroRangoCuentaReader<InteresRaw>`, `FiltroRangoCuentaReader<MovimientoAnualRaw>`, `JdbcCursorItemReader<EstadoCuentaAnual>` |
| `ItemProcessor` | Valida, normaliza y transforma | `TransaccionProcessor`, `InteresProcessor`, `MovimientoAnualProcessor` |
| `ItemWriter` | Escribe el chunk entero de una vez | `JdbcBatchItemWriter` (3 jobs) + `FlatFileItemWriter<EstadoCuentaAnual>` (informe del Job 3) |
| `JobExecutionDecider` | Ramifica el flujo segun un dato de negocio | `DeciderCalidadDatos` |
| `SkipPolicy` | Decide que excepcion se omite y cual mata el step | `BancoXyzSkipPolicy` |
| `RetryPolicy` / `BackOffPolicy` | Cuantos reintentos y cuanto se espera entre ellos | `RetryPolicies`, `BackOffPolicies` |
| `SkipListener` | Punto de enganche del dead letter | `RechazoListener` (fases READ / PROCESS / WRITE) |
| `StepExecutionListener` | Traza de inicio/fin de cada particion | `ParticionListener` |
| `RetryListener` / `ChunkListener` | Traza de reintentos y de errores de chunk | `ReintentoRetryListener`, `ChunkErrorListener` |
| `FlatFileHeaderCallback` / `FooterCallback` | Cabecera y pie del informe exportado | `CabeceraInformeCallback`, `PieInformeCallback` |

Clases de apoyo que no son componentes de Batch pero sostienen las reglas:
`NormalizadorFecha`, `NormalizadorMonto`, `NormalizadorTexto`,
`CalculadoraInteres`, `ContadorFilasCsv`, `ControlCargaDao`,
`RegistroInvalidoException`.

---

## 3. Flujo de datos: CSV → reader → processor → writer → BD

### 3.1 El recorrido de una fila que sale bien

```
data/transacciones.csv
      |
      |  (1) READER  — FlatFileItemReader
      |      Lee la linea y la mapea a TransaccionRaw: TODOS los campos String.
      v
TransaccionRaw{ cuentaId:"501", fecha:"04/05/2024", monto:"1200", tipo:"credito" }
      |
      |  (2) PROCESSOR — TransaccionProcessor
      |      Normaliza (fecha a ISO, monto a BigDecimal, texto a minusculas),
      |      valida por precedencia y decide estado + lista de anomalias.
      v
Transaccion{ cuentaId:501, fecha:2024-05-04, monto:1200.00, estado:VALIDA, anomalias:"" }
      |
      |  (3) WRITER — JdbcBatchItemWriter, UNA vez cada 200 items
      |      Un solo executeBatch() por chunk, no un INSERT por fila.
      v
banco.transaccion   (+ commit del chunk)
```

**Por que el reader lee todo como `String`.** Si tipas en el reader (por ejemplo
declarando `monto` como `BigDecimal`), `FlatFileItemReader` lanza
`FlatFileParseException` **antes** de que tu processor pueda mirar la fila. Una
fecha en formato `04/05/2024` seria un error irrecuperable en vez de una fecha
reparable. Leyendo crudo, la decision de que es reparable y que no la toma un
sitio y solo uno: el `ItemProcessor`. Por eso existen los tipos `*Raw`.

**Por que el writer escribe por chunk y no por fila.** El chunk es tambien la
unidad transaccional: Spring Batch abre transaccion, acumula N items, llama al
writer una vez y hace commit. Con `chunk(200)` son 5 commits por particion en
lugar de 1000. Como el datasource es **uno solo** para `banco` y `batch_meta`,
ese commit incluye la actualizacion del `StepExecution`: o se guardan las filas
y el contador, o no se guarda ninguna de las dos cosas.

### 3.2 Donde encaja el dead letter

El dead letter (`banco.registro_rechazado`) es la salida **alternativa**, no la
excepcional. Es lo que hace cierta la Regla de Oro: *entrada = negocio +
rechazos*.

```
      READ                    PROCESS                      WRITE
        |                        |                            |
  linea ilegible        RegistroInvalidoException      fallo al insertar
  (parse error)         lanzada por el processor       (p.ej. clave unica)
        |                        |                            |
        +------------+-----------+----------------+-----------+
                     |                            |
                     v                            v
              BancoXyzSkipPolicy          BancoXyzSkipPolicy
              decide: omitir o morir      decide: omitir o morir
                     |
                     v  (si omite, Spring Batch avisa al SkipListener)
              RechazoListener
                     |
                     v
       banco.registro_rechazado
       (archivo, job, step, particion, FASE, motivo, campo,
        valor_crudo, linea_cruda, excepcion, mensaje, numero_linea)
```

Tres cosas que conviene entender de este diseno:

1. **La fase importa.** El mismo dato malo se detecta en sitios distintos segun
   que sea. Un monto ausente lo ve el processor (`PROCESS`). Un **duplicado**
   no lo puede ver el processor —que solo mira una fila cada vez—: lo detecta la
   clave unica de PostgreSQL al escribir (`WRITE`). Se ve en
   `evidencias/03-validaciones/rechazos-por-motivo.txt`: 474 rechazos en PROCESS
   y exactamente los 5 `DUPLICADO` en WRITE.
2. **Se guarda la linea cruda.** Sin ella el rechazo es una estadistica; con
   ella es reprocesable sin volver al fichero original. Es la columna que
   sostiene la auditabilidad, y no `numero_linea`: en las capturas se ve que
   `numero_linea` vale **-1** (el centinela por defecto del esquema) en todos
   los rechazos de fase `PROCESS`. No es un fallo, es una consecuencia de donde
   vive cada dato en el ciclo de chunk: el numero de linea lo conoce el
   `FlatFileItemReader` mientras lee, pero **no viaja dentro del item**, asi que
   cuando el processor rechaza la fila ya no esta disponible. Solo un fallo de
   fase `READ` podria traerlo. Por eso la unidad de auditoria aqui es la linea
   cruda, que si acompaña al item hasta el final.
3. **Omitir no es perder.** `SkipPolicy` decide que una excepcion no mata el
   step; `SkipListener` garantiza que la fila omitida queda escrita en algun
   sitio. Las dos piezas juntas —y solo juntas— hacen que «tolerante a fallos»
   no signifique «pierde datos en silencio».

Al final de cada Job, `CuadraturaTasklet` comprueba la aritmetica y falla el Job
si no cuadra. La columna `cuadra` de `banco.control_carga` es
`GENERATED ALWAYS ... STORED`: la calcula PostgreSQL, no el programa, asi que no
se puede falsear desde Java.

### 3.3 El caso especial: BD → fichero (Job 3)

`stepExportarEstadosCuenta` invierte el sentido habitual. Es un step de chunk
normal, pero con `JdbcCursorItemReader` (lee `banco.estado_cuenta_anual`) y
`FlatFileItemWriter` con cabecera y pie (`CabeceraInformeCallback`,
`PieInformeCallback`), que escribe el informe de auditoria en `results/`.
Demuestra que reader y writer son intercambiables: el ciclo de chunk es el
mismo, solo cambian los extremos.

---

## 4. Como se reparte el trabajo en particiones

### 4.1 El mecanismo, comun a los tres Jobs

1. El **manager** (`PartitionStep`) llama a `partition(gridSize)` del
   `Partitioner`.
2. El `Partitioner` devuelve un mapa `nombre -> ExecutionContext`. Cada
   `ExecutionContext` lleva las claves que el reader de esa particion necesita
   para saber que le toca.
3. El manager crea una `StepExecution` por entrada del mapa, con el nombre
   `worker:partitionN`, y las lanza en el `TaskExecutor`.
4. El reader es `@StepScope`: se instancia **una vez por particion** y recibe
   sus claves con `@Value("#{stepExecutionContext['...']}")`. Sin `@StepScope`
   habria un unico reader compartido y las 4 particiones leerian lo mismo.
5. El manager espera a que todas terminen y **agrega** sus contadores en su
   propia `StepExecution`. Por eso al sumar manager + particiones cada fila se
   cuenta dos veces (ver `evidencias/02-ejecucion/resumen-ejecutivo.txt`).

El `.taskExecutor(...)` del manager es **obligatorio** para que haya paralelismo:
sin el, Spring usa un ejecutor sincrono y las particiones corren una detras de
otra, en `main`, con el job igualmente COMPLETED. La prueba de que aqui si hay
paralelismo real esta en `evidencias/04-escalado/log-particionado.txt`: cuatro
nombres de hilo distintos (`particion-1..4`) y marcas de tiempo solapadas.

### 4.2 Job 1 — reparto por rango de linea

`LineRangePartitioner`, `gridSize = 4`. Un CSV no tiene indices, asi que el
reparto se expresa con las dos propiedades que entiende `FlatFileItemReader`:

| Particion | `linesToSkip` | `maxItemCount` | Filas |
|---|---:|---:|---|
| `partition0` | 1 | 250 | 1–250 |
| `partition1` | 251 | 250 | 251–500 |
| `partition2` | 501 | 250 | 501–750 |
| `partition3` | 751 | 250 | 751–1000 |

Reparto **perfectamente equilibrado**: `skew = 1.000` medido, 250 filas exactas
por particion. Coste honesto: cada particion reabre el fichero y descarta sus
primeras lineas, asi que el fichero se lee 4 veces. Con 1000 filas es
irrelevante; con millones habria que trocear el fichero y usar
`MultiResourcePartitioner`.

Guarda importante: si el fichero no tiene filas de datos, el partitioner **lanza
excepcion** en vez de devolver un mapa vacio. Un mapa vacio significaria cero
workers, cero filas cargadas y un Job COMPLETED mintiendo.

### 4.3 Jobs 2 y 3 — reparto por rango de cuenta

`RangoCuentaPartitioner`. Job 2: cuentas 101–150 en 5 particiones. Job 3:
cuentas 101–120 en 4 particiones.

Se cambia de criterio porque **cambia la unidad de trabajo**. El Job 2 consolida
saldos *por cuenta*, asi que la cuenta —y no la posicion fisica en el fichero—
es la unidad natural. Repartir por `cuenta_id` garantiza que todas las filas de
la cuenta 137 las procesa la misma particion, lo que a su vez hace que las dos
copias de una fila duplicada caigan juntas y que el rechazo `DUPLICADO` sea
reproducible entre corridas.

**El precio, y hay que decirlo:** las cuentas no traen el mismo numero de filas,
asi que el reparto sale **desequilibrado a proposito**. Medido en la ejecucion de
evidencia (`evidencias/04-escalado/particiones.txt`):

| Job | Particionador | Particiones | skew | ratio max/min de duracion |
|---|---|---:|---:|---:|
| Job 1 | `LineRangePartitioner` | 4 | **1.000** | 1.149 |
| Job 2 | `RangoCuentaPartitioner` | 5 | **1.050** | 4.234 |
| Job 3 | `RangoCuentaPartitioner` | 4 | **1.068** | 1.083 |

Filas por particion realmente medidas: Job 1 → 250 / 250 / 250 / 250 (exacto);
Job 2 → 210 / 207 / 205 / 205 / 173; Job 3 → 256 / 267 / 236 / 241. En los tres
casos la suma es **1000**, que es lo unico innegociable.

`skew` mide desequilibrio de **filas**; `ratio max/min` mide desequilibrio de
**tiempo**, que no es lo mismo: dos particiones con las mismas filas tardan
distinto si una tiene mas filas sucias, porque cada rechazo escribe ademas en el
dead letter.

**El invariante que protege la Regla de Oro.** Un reparto por rango tiene un
agujero mortal: las filas que no caen en ningun rango (un `cuenta_id` = 999,
vacio, o `abc`) no las leeria nadie, el job terminaria COMPLETED y la cuadratura
daria 999 en vez de 1000, sin un solo error en el log. La regla que lo cierra:

- la **primera** particion reclama ademas todo lo que este **por debajo** del rango;
- la **ultima** particion reclama ademas todo lo que este **por encima** y todo
  lo **ilegible** (vacio, no numerico).

Asi cada fila tiene exactamente un reclamante: ni cero (se perderia) ni dos (se
duplicaria). `RangoCuentaPartitionerTest` afirma justo eso, caso por caso.

**Nota sobre el Job 2:** `gridSize = 5` pero el pool tiene 4 hilos
(`TaskExecutorConfig.PARTICIONES = 4`). La quinta particion no se pierde: espera
y reutiliza el primer hilo que quede libre. Es el comportamiento correcto de un
pool acotado y explica parte del `ratio max/min = 4.234` de ese Job.

---

## 5. Correspondencia con la evidencia

| Afirmacion de este documento | Fichero que la prueba |
|---|---|
| Los 19 steps existen y los 3 Jobs arrancan por su manager | `evidencias/01-arquitectura/steps-registrados.txt` |
| Spring Batch 5.2.6 sobre Boot 3.5.16 | `evidencias/01-arquitectura/dependency-tree.txt` |
| 9 tablas + 4 vistas en `banco`, 6 `BATCH_*` en `batch_meta` | `evidencias/01-arquitectura/tablas.txt` |
| Los 3 Jobs terminan COMPLETED | `evidencias/02-ejecucion/job{1,2,3}.log` |
| `entrada = negocio + rechazos` en los 3 ficheros | `evidencias/02-ejecucion/cuadratura.txt` |
| Las reglas del processor dan los numeros esperados | `evidencias/03-validaciones/estados-por-job.txt` |
| El dead letter recoge los 479 rechazos, con su fase | `evidencias/03-validaciones/rechazos-por-motivo.txt` |
| El reparto por particion y su desequilibrio | `evidencias/04-escalado/particiones.txt` |
| Las particiones corren en hilos distintos, en paralelo | `evidencias/04-escalado/log-particionado.txt` |
