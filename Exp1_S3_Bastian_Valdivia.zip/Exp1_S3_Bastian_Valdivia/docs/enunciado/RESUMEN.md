# Resumen del enunciado — Exp1 S3 (Desarrollo Backend III, PBY2203)

## Actividad
**"Optimizando procesos batch para mejorar la resiliencia de procesos"** — actividad sumativa individual, Semana 3.

Objetivo: modernizar el sistema legacy del **Banco XYZ**, migrando 3 procesos batch usando **Spring Batch**, con foco en:
- Escalado / procesamiento paralelo (particiones o multi-thread)
- Políticas de reintento y tolerancia a fallos
- Manejo de errores y validación de datos

Dataset base: https://github.com/KariVillagran/bank_legacy_data

## Los 3 Jobs a implementar

1. **Reporte de Transacciones Diarias**: procesar transacciones diarias, detectar anomalías, generar resumen.
2. **Cálculo de Intereses Mensuales**: aplicar intereses sobre cuentas de ahorro y préstamos, actualizar saldo final en BD.
3. **Generación de Estados de Cuenta Anuales**: compilar datos anuales por cuenta, generar informe para auditorías.

## Requisitos técnicos

1. Proyecto Spring Batch con Jobs y Steps para leer/procesar/escribir CSV, versionado en GitHub (cuenta propia).
2. `ItemProcessor` con transformaciones y validaciones; escritura en BD relacional (PostgreSQL, MySQL u Oracle).
3. Manejo de errores/excepciones: reglas de consistencia sobre datos incorrectos o mal clasificados.
4. Políticas personalizadas de tolerancia a fallos (retry).
5. Escalado: elegir entre **multi-thread** o **particiones**, con parámetros propios (cantidad de particiones, threads min/max, etc.), y **comparar configuraciones** para encontrar la óptima (pedido explícitamente en la pauta, criterio 4).

### Conceptos clave de la guía (particiones)
- `PartitionStep` → paso principal que orquesta el particionado.
- `PartitionHandler` (ej. `TaskExecutorPartitionHandler`) → reparte el trabajo entre hilos/nodos; usa `setGridSize(n)` para definir el número de particiones.
- `Partitioner` → genera un `ExecutionContext` por partición (rangos `start`/`end`) que el `ItemReader` (`minionStep`) consume.
- `minionStep` → step "worker" que se ejecuta una vez por partición, en paralelo.
- Manejo de errores por partición: `SkipPolicy` (custom), `SkipListener`, aislado por partición (si falla una, no afecta a las demás).
- Comparar tiempos: ejecución secuencial vs particionada (el ejemplo de la guía compara 329ms vs 234ms).

### Políticas de reintento (retry)
- `RetryPolicy`: cuántos reintentos y qué excepciones los disparan.
- `BackOffPolicy`: tiempo de espera entre reintentos (ej. backoff exponencial).
- `SkipPolicy`: qué registros se omiten sin detener el job.

## Entregables

1. **Código fuente**: repo GitHub con propuesta técnica.
2. **Documentación (README.md)**: objetivo del proyecto, estructura del código, instrucciones de ejecución.
3. **Evidencia de ejecución**: capturas de pantalla o logs de consola de cada Job y sus resultados.

Todo en una misma carpeta; al subir la entrega, comprimir con nomenclatura `Exp1_S3_Nombre_Apellido`.

## Pauta de evaluación (7 criterios, 100 pts total → normalizado)

| # | Criterio | Puntos máx |
|---|----------|-----------|
| 1 | Arquitectura Spring Batch (Jobs/Steps) según requerimientos | 15 |
| 2 | Ejecución correcta de Jobs/Steps, salida esperada en BD | 15 |
| 3 | Transformaciones y validaciones en `ItemProcessor` | 15 |
| 4 | Escalado (multi-thread o particiones) **comparando parámetros** para hallar el óptimo | 15 |
| 5 | Políticas de reintento y tolerancia a fallos, cubriendo varios escenarios de falla | 15 |
| 6 | Aplicación general de políticas/configuraciones, optimización de tiempos y estabilidad | 15 |
| 7 | Entrega de los 3 aspectos clave (código, documentación, evidencia) | 10 |

Puntos a cuidar especialmente para el 100%:
- Criterio 4 exige explícitamente **comparar distintas configuraciones de escalado** (no basta con implementarlo una vez).
- Criterio 5 exige cubrir **varios escenarios de fallo** distintos, no solo uno.
- Criterio 7 exige los 3 entregables completos en la misma carpeta.

## Archivos originales
- `instrucciones-especificas.docx` — instrucciones específicas de la actividad.
- `pauta-evaluacion.docx` — rúbrica de evaluación sumativa.
- `guia-aprendizaje-escalado-particiones.docx` — guía teórica de la semana (particiones, PartitionHandler, retry/skip policies, caso FreshMart).
