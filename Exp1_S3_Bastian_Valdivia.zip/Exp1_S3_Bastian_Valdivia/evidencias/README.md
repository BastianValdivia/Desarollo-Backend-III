# Evidencias de ejecucion — Banco XYZ (Spring Batch)

> **Que es este fichero.** El indice de las evidencias **organizadas por
> criterio de la pauta**, en las carpetas `01-arquitectura/`, `02-ejecucion/`,
> `03-validaciones/` y `04-escalado/`. Cada fichero de esas carpetas es la
> **salida real** de ejecutar los tres jobs y consultar la base de datos; no hay
> ni una cifra transcrita a mano.
>
> **Relacion con [`INDICE.md`](INDICE.md).** `INDICE.md` es el indice general y
> mas antiguo, que ademas cubre las evidencias de tolerancia a fallos
> (`05-fallos/`), la base de datos tabla por tabla (`02-bd/`) y el banco de
> pruebas de escalado. Los dos ficheros conviven a proposito y **no se
> contradicen**: apuntan al mismo material desde dos entradas distintas. Para
> los criterios 5 y 6, ir a `INDICE.md`.

---

## Como se genero esta evidencia

Los tres jobs se ejecutaron **en orden y seguidos**, para que los datos de la
base sean coherentes entre si (el Job 2 consolida sobre lo que dejo el Job 1, y
el Job 3 sobre lo que dejo el Job 2):

```bash
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobInteresesMensuales
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobEstadosCuentaAnuales
```

Las tres ejecuciones que respaldan **todos** los ficheros de estas cuatro
carpetas son las `JOB_EXECUTION_ID` **463 (Job 1), 464 (Job 2) y 465 (Job 3)**,
las tres `COMPLETED`. Ese numero aparece impreso en la cabecera de cada captura,
para que se pueda comprobar que ninguna mezcla corridas distintas.

Se ejecuto **sin `-q`** a proposito: la opcion silenciosa de Maven se come
precisamente las lineas que hay que demostrar (`Executing step: [...]` y el
nombre del hilo de cada particion).

---

## El resultado en una tabla: la Regla de Oro

`entrada = negocio + rechazos`. Ninguna fila desaparece en silencio.

| Archivo | Entrada | Negocio | Rechazos | Cuadra |
|---|---:|---:|---:|:--:|
| `transacciones.csv` | 1000 | 785 | 215 | si |
| `intereses.csv` | 1000 | 784 | 216 | si |
| `cuentas_anuales.csv` | 1000 | 952 | 48 | si |

Fuente: [`02-ejecucion/cuadratura.txt`](02-ejecucion/cuadratura.txt).

---

## Criterio 1 — Arquitectura Spring Batch · carpeta `01-arquitectura/`

| Fichero | Que demuestra |
|---|---|
| [`steps-registrados.txt`](01-arquitectura/steps-registrados.txt) | Que los **19 steps** del diseno existen de verdad en la metadata de Spring Batch, con el nombre exacto, y que los 3 jobs arrancan por su step **manager**. El bloque B acota la consulta a las ejecuciones 463/464/465, que es la vista que se contrasta contra el diagrama de `docs/arquitectura.md`. |
| [`dependency-tree.txt`](01-arquitectura/dependency-tree.txt) | Que el stack declarado es el real: `spring-boot-starter-batch:3.5.16` arrastrando `spring-batch-core:5.2.6` y `spring-batch-infrastructure:5.2.6`. |
| [`tablas.txt`](01-arquitectura/tablas.txt) | Los dos esquemas: 9 tablas de negocio + 4 vistas en `banco`, y las 6 tablas `BATCH_*` en `batch_meta`. Al final, el conteo de filas de cada tabla tras las 3 ejecuciones. |

**Dos cosas de `steps-registrados.txt` que parecen errores y no lo son.** Merece
la pena leerlas antes de comparar el fichero con el diagrama:

1. `BATCH_STEP_EXECUTION` guarda **todo lo que se ha ejecutado alguna vez**
   contra esta base de datos, no solo la ultima corrida. Por eso el bloque A
   incluye los steps sinteticos del banco de pruebas de escalado (prefijos
   `s-SEC`, `m-MTH`, `g-PAR`, `w-PAR`, del paquete `cl.duoc.bancoxyz.experiment`)
   y `stepCargarTransacciones`, que fue el nombre del worker del Job 1 **antes**
   de particionarlo y que ya no existe en el codigo. El bloque B es el que
   filtra ese ruido.
2. **`deciderCalidadDatos` no aparece nunca**, y es correcto: es un
   `JobExecutionDecider`, no un `Step`. Los deciders deciden el camino pero no
   se persisten como ejecuciones. Y **`stepAlertaCalidad` tampoco aparece** en
   el bloque B: la tasa de rechazo del Job 1 fue `215/1000 = 0.215`, por debajo
   del umbral 0.25, asi que el decider tomo la rama `"*"` y la alerta no se
   disparo. En el bloque A si aparece, y se puede senalar la corrida exacta:
   la **unica** vez que se ha ejecutado en toda la historia de esta base es la
   `JOB_EXECUTION_ID = 8`, de `jobTransaccionesDiarias`, cuando se probo el
   decider con un umbral que si se cruzaba.
   Que un step condicional falte cuando su condicion no se cumple es
   la prueba de que la condicion existe; si saliera siempre, el decider seria
   decorativo.

---

## Criterio 2 — Ejecucion correcta y salida esperada · carpeta `02-ejecucion/`

| Fichero | Que demuestra |
|---|---|
| [`job1.log`](02-ejecucion/job1.log) | Log **completo** de `jobTransaccionesDiarias`. Se ven en orden: `stepPrepararTransacciones`, el manager, las 4 particiones en paralelo, `stepResumenDiario` (322 filas) y `stepValidarCuadraturaTransacciones`. Termina en `COMPLETED`. |
| [`job2.log`](02-ejecucion/job2.log) | Log completo de `jobInteresesMensuales`: preparar, manager, 5 particiones, `stepConsolidarSaldos`, y las dos validaciones. `COMPLETED`. |
| [`job3.log`](02-ejecucion/job3.log) | Log completo de `jobEstadosCuentaAnuales`: preparar, manager, 4 particiones, `stepGenerarEstadosCuenta`, `stepExportarEstadosCuenta` (BD -> fichero de informe) y las dos validaciones. `COMPLETED`. |
| [`cuadratura.txt`](02-ejecucion/cuadratura.txt) | La Regla de Oro medida: `SELECT * FROM banco.v_cuadratura` da 1000 en las tres filas, mas la fila de `banco.control_carga` de cada ejecucion con su columna `cuadra` en `t`. Esa columna es `GENERATED ALWAYS ... STORED`: la calcula PostgreSQL, no el programa, asi que no se puede falsear desde Java. |
| [`resumen-ejecutivo.txt`](02-ejecucion/resumen-ejecutivo.txt) | Una fila por `JobExecution` con los contadores del propio Spring Batch: estado, duracion, leidos, escritos, omitidos, commits y rollbacks. |

**Como leer la columna `leidos` del resumen ejecutivo.** Marca 2000 en el Job 1,
no 1000, y no es un error: en un job particionado el step **manager agrega** los
contadores de sus particiones dentro de su propia `StepExecution`. Al sumar
manager + particiones, cada fila se cuenta dos veces. La cifra buena de negocio
esta en `cuadratura.txt`.

---

## Criterio 3 — Transformaciones y validaciones · carpeta `03-validaciones/`

| Fichero | Que demuestra |
|---|---|
| [`estados-por-job.txt`](03-validaciones/estados-por-job.txt) | La distribucion por `estado` de las tres tablas de negocio. Es el resultado observable de las reglas del `ItemProcessor` y **coincide exactamente** con `docs/analisis-datos.md` seccion 6. |
| [`rechazos-por-motivo.txt`](03-validaciones/rechazos-por-motivo.txt) | El otro lado de la regla de precedencia: los 479 rechazos del dead letter, por archivo, por motivo, por fase y por particion, con una muestra de 8 lineas crudas. |

**Sobre la columna `numero_linea` de la muestra: vale -1, y esta bien.** Es el
centinela por defecto del esquema. El numero de linea lo conoce el
`FlatFileItemReader` mientras lee, pero **no viaja dentro del item**, asi que
cuando el `ItemProcessor` rechaza la fila ese dato ya no esta a mano; solo un
fallo de fase `READ` podria traerlo, y aqui los 474 rechazos de PROCESS no lo
son. Lo que hace auditable el rechazo es `linea_cruda`, que si acompaña al item
hasta el final: con ella la fila se puede reprocesar a mano sin volver al
fichero original. Se explica aqui en vez de callarlo porque un -1 sin contexto
parece un campo roto y no lo es.

Numeros verificados en esta corrida:

| Archivo | Distribucion por estado (excluyente) | Rechazos |
|---|---|---|
| `transacciones.csv` | VALIDA 401 · TIPO_DESCONOCIDO 230 · MONTO_NEGATIVO 136 · MONTO_CERO 18 | MONTO_AUSENTE 160 + FECHA_INVALIDA 55 |
| `intereses.csv` | VALIDA 303 · TIPO_DESCONOCIDO 260 · EDAD_AUSENTE 101 · EDAD_FUERA_RANGO 96 · NOMBRE_DESCONOCIDO 24 | SALDO_AUSENTE 211 + DUPLICADO 5 |
| `cuentas_anuales.csv` | VALIDA 524 · MONTO_NEGATIVO 173 · DESCRIPCION_AUSENTE 162 · SIGNO_CONTRADICTORIO 81 · MONTO_CERO 12 | MONTO_AUSENTE 48 |

**Estado y anomalias no son lo mismo, y por eso los totales difieren.** El
`estado` es **excluyente**: cada fila tiene uno solo, el primero que dispara la
regla de precedencia (fecha invalida > monto/saldo ausente > no numerico >
duplicado > monto negativo > monto cero > tipo desconocido > resto > VALIDA). La
columna `anomalias` guarda **todas** las anomalias detectadas separadas por coma.
Por eso en `transacciones` hay 230 filas con *estado* `ANOMALA_TIPO_DESCONOCIDO`
pero 294 filas con `TIPO_DESCONOCIDO` *entre sus anomalias*: las 64 de diferencia
tienen tipo desconocido **y ademas** algo con mas precedencia. El fichero muestra
las dos vistas para que la diferencia se vea, no se suponga.

**La fase del rechazo tambien es evidencia.** 474 rechazos se detectan en
`PROCESS` y exactamente 5 en `WRITE`. Los 5 de `WRITE` son los `DUPLICADO` del
Job 2: un duplicado **no lo puede ver el processor**, que mira una fila cada vez;
solo lo detecta la clave unica de PostgreSQL al escribir. Que la fase coincida
con la naturaleza del error demuestra que el dead letter engancha las tres fases
del ciclo de chunk y no solo la comoda.

---

## Criterio 4 — Escalado y particionado · carpeta `04-escalado/`

Ficheros **nuevos** de esta captura (los demas ficheros de la carpeta —los 6
SVG, `hilos-particionado.txt`, `log-particionado-grid4.txt` y
`metricas-micrometer.txt`— son del banco de pruebas de escalado y estan
indexados en `INDICE.md`):

| Fichero | Que demuestra |
|---|---|
| [`particiones.txt`](04-escalado/particiones.txt) | Duracion y reparto **por particion** en los tres jobs, con la consulta de `scripts/consultas-sql/06-particiones.sql`. Para cada job: una fila por particion (filas leidas, escritas, omitidas, commits, rollbacks, ms) y los tres indicadores de calidad del reparto (`skew`, `ratio_max_min`, `speedup_interno`). |
| [`log-particionado.txt`](04-escalado/log-particionado.txt) | Que las particiones corren **de verdad en paralelo**: los nombres de hilo extraidos de los tres logs, las trazas de `ParticionListener` con el hilo de cada una y las lineas del propio Spring Batch. |

Resultado medido:

| Job | Particionador | Particiones | skew | ratio max/min | Hilos distintos |
|---|---|---:|---:|---:|---:|
| Job 1 | `LineRangePartitioner` | 4 | **1.000** | 1.149 | 4 |
| Job 2 | `RangoCuentaPartitioner` 101–150 | 5 | 1.050 | 4.234 | 4 |
| Job 3 | `RangoCuentaPartitioner` 101–120 | 4 | 1.068 | 1.083 | 4 |

**Por que la prueba de paralelismo son los hilos y no las particiones.** Un
`PartitionStep` mal configurado —sin `.taskExecutor(...)`— tambien crea las N
particiones, tambien las completa y el job tambien termina `COMPLETED`. La unica
diferencia observable es que todas saldrian en el hilo `main`, una detras de
otra. Por eso el requisito es **>= 2 nombres de hilo distintos**: se cumple con
holgura, hay 4 (`particion-1` a `particion-4`), y ademas sus marcas de tiempo
**se solapan**.

**Por que el `skew` del Job 1 es 1.000 y el de los otros dos no.** No es que los
Jobs 2 y 3 esten peor repartidos por descuido: reparten por un criterio distinto
a proposito. El Job 1 reparte por **rango de linea** (250 filas exactas cada
particion, equilibrio perfecto). Los Jobs 2 y 3 reparten por **rango de
`cuenta_id`**, que es la unidad de negocio, para que todas las filas de una
cuenta caigan en la misma particion. Como las cuentas no traen el mismo numero
de filas, el reparto sale desequilibrado. Es un intercambio consciente:
correccion del agrupamiento a cambio de equilibrio. Explicado en detalle en
`docs/arquitectura.md` §4.

El `ratio max/min = 4.234` del Job 2 tiene ademas una segunda causa: su
`gridSize` es 5 pero el pool tiene 4 hilos, asi que la quinta particion espera a
que se libere uno. Es el comportamiento correcto de un pool acotado.

---

## Criterios 5, 6 y 7

- **Criterio 5** (reintento y tolerancia a fallos, 6 escenarios) → `05-fallos/`, indexado en [`INDICE.md`](INDICE.md).
- **Criterio 6** (politicas, optimizacion y estabilidad) → `results/scaling-summary.md`, `docs/escalado.md` y `scripts/consultas-sql/auditar-esquema.sql`, indexados en [`INDICE.md`](INDICE.md).
- **Criterio 7** (los 3 entregables) → codigo en `src/`, documentacion en `docs/` y `README.md`, y evidencia en esta carpeta. El documento de arquitectura que acompaña a estas capturas es [`../docs/arquitectura.md`](../docs/arquitectura.md).

---

## Como regenerar solo estas cuatro carpetas

```bash
# 1. los tres jobs, en orden, con el log completo
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias > evidencias/02-ejecucion/job1.log 2>&1
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobInteresesMensuales   > evidencias/02-ejecucion/job2.log 2>&1
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobEstadosCuentaAnuales > evidencias/02-ejecucion/job3.log 2>&1

# 2. anotar los tres JOB_EXECUTION_ID que imprimen los logs
grep -o "job_execution_id=[0-9]*" evidencias/02-ejecucion/job1.log | head -1

# 3. las consultas (sustituir los ids)
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "SELECT * FROM banco.v_cuadratura"
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "SELECT * FROM banco.v_resumen_ejecutivo"
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "SELECT DISTINCT STEP_NAME FROM batch_meta.BATCH_STEP_EXECUTION ORDER BY 1"
./mvnw dependency:tree -Dincludes=org.springframework.batch:*,org.springframework.boot:*
```

> **Aviso.** Los jobs se pueden relanzar tantas veces como se quiera —los tres
> llevan `RunIdIncrementer`, asi que cada corrida es una `JobInstance` nueva—,
> pero **cada corrida cambia los `JOB_EXECUTION_ID`**. Si se relanza algo entre
> medias, hay que rehacer las capturas enteras para que todas apunten a la misma
> terna de ejecuciones. Las de esta carpeta apuntan todas a 463 / 464 / 465.

### Que pasa si se vuelve a lanzar un job despues de capturar

Conviene entender la diferencia entre los dos tipos de dato, porque no envejecen
igual:

- **La metadata de Spring Batch es historica y no se borra nunca.** Las
  ejecuciones 463, 464 y 465 siguen en `batch_meta.BATCH_STEP_EXECUTION` pase lo
  que pase. Por eso `steps-registrados.txt`, `resumen-ejecutivo.txt` y
  `particiones.txt` se pueden volver a comprobar en cualquier momento con los
  mismos ids y dan lo mismo.
- **Las tablas de negocio se reescriben en cada corrida.** El step de
  preparacion de cada job limpia su tabla antes de recargarla, asi que
  `banco.transaccion` y `banco.registro_rechazado` reflejan siempre la **ultima**
  ejecucion, no la 463.

Eso no invalida la evidencia, y hay una razon concreta: **el proceso es
determinista**. Al cerrar esta captura, una corrida posterior del Job 1
(ejecucion 466) reescribio `banco.transaccion` y sus rechazos, y la cuadratura y
el desglose por motivo salieron **identicos**, cifra por cifra: 785 + 215, con
MONTO_AUSENTE 160 y FECHA_INVALIDA 55. Mismo fichero de entrada y mismas reglas
de validacion dan siempre el mismo resultado. Si al reproducir esta evidencia
salieran cifras distintas con el mismo CSV, eso **si** seria un hallazgo, y
apuntaria a un problema real de no-determinismo en el particionado o en el
processor.
