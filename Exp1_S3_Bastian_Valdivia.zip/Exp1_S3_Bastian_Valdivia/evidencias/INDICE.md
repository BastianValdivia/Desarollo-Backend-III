# Indice de evidencias — Exp1 S3, Banco XYZ (Spring Batch)

Mapa **criterio de la pauta -> fichero concreto**. Cada fila apunta a evidencia
que se puede abrir y leer, no a una afirmacion.

Toda la evidencia de base de datos se regenero **despues** de ejecutar los tres
jobs en orden y dos veces cada uno, asi que las tablas comparativas ya no
muestran ceros en los Jobs 2 y 3.

---

## Resumen: la Regla de Oro en una tabla

`entrada = negocio + rechazos`, para los tres archivos. Es el contrato del
proyecto: **ninguna fila desaparece en silencio**.

| Archivo | Negocio | Rechazos | Total | Fichero de entrada |
|---|---:|---:|---:|---:|
| transacciones.csv | 785 | 215 | **1000** | 1000 |
| intereses.csv | 784 | 216 | **1000** | 1000 |
| cuentas_anuales.csv | 952 | 48 | **1000** | 1000 |

Fuente: [`02-bd/00-cuadratura.txt`](02-bd/00-cuadratura.txt) (vista `banco.v_cuadratura` + `banco.control_carga`).

---

## Criterio 1 — Arquitectura Spring Batch (Jobs/Steps) · 15 pts

| Que demuestra | Fichero |
|---|---|
| Job 1 completo: manager + 4 workers + decider + resumen + cuadratura | [`02-ejecucion/job1-detalle-bd.txt`](02-ejecucion/job1-detalle-bd.txt) |
| Job 2 completo: manager + 5 workers + consolidacion + 2 validaciones | [`02-ejecucion/job2-detalle-bd.txt`](02-ejecucion/job2-detalle-bd.txt) |
| Job 3 completo: manager + 4 workers + consolidacion + export + 2 validaciones | [`02-ejecucion/job3-detalle-bd.txt`](02-ejecucion/job3-detalle-bd.txt) |
| Los 3 jobs arrancan por su step **manager**, nunca por el worker | los 3 logs, lineas `Executing step: [step*Manager]` |

## Criterio 2 — Ejecucion correcta y salida esperada en BD · 15 pts

Una captura por **cada** tabla de negocio, mas el dead letter compartido.

| Tabla | Filas | Fichero |
|---|---:|---|
| `banco.transaccion` (Job 1) | 785 | [`02-bd/01-transaccion.txt`](02-bd/01-transaccion.txt) |
| `banco.resumen_diario` (Job 1) | 322 | [`02-bd/02-resumen_diario.txt`](02-bd/02-resumen_diario.txt) |
| `banco.interes_calculado` (Job 2) | 784 | [`02-bd/03-interes_calculado.txt`](02-bd/03-interes_calculado.txt) |
| `banco.cuenta` (Job 2) | 50 | [`02-bd/04-cuenta.txt`](02-bd/04-cuenta.txt) |
| `banco.movimiento_anual` (Job 3) | 952 | [`02-bd/05-movimiento_anual.txt`](02-bd/05-movimiento_anual.txt) |
| `banco.estado_cuenta_anual` (Job 3) | 20 | [`02-bd/06-estado_cuenta_anual.txt`](02-bd/06-estado_cuenta_anual.txt) |
| `banco.registro_rechazado` (dead letter, 3 jobs) | 479 | [`02-bd/07-registro_rechazado.txt`](02-bd/07-registro_rechazado.txt) |

Las **3 consultas de `scripts/consultas-sql/`** con su salida capturada:

| Consulta | Salida |
|---|---|
| `04-job1-completo.sql` | [`02-bd/verificacion-04-job1-completo.txt`](02-bd/verificacion-04-job1-completo.txt) |
| `06-particiones.sql` | [`02-bd/verificacion-06-particiones.txt`](02-bd/verificacion-06-particiones.txt) |
| `07-comparativa-escalado.sql` | [`02-bd/verificacion-07-comparativa-escalado.txt`](02-bd/verificacion-07-comparativa-escalado.txt) |

## Criterio 3 — Transformaciones y validaciones en ItemProcessor · 15 pts

La distribucion por estado es el resultado observable de las reglas del
processor. Coincide **exactamente** con `docs/analisis-datos.md` seccion 6.

| Archivo | Distribucion por estado | Fichero |
|---|---|---|
| transacciones.csv | VALIDA 401 · TIPO_DESCONOCIDO 230 · MONTO_NEGATIVO 136 · MONTO_CERO 18 | [`02-bd/01-transaccion.txt`](02-bd/01-transaccion.txt) |
| intereses.csv | VALIDA 303 · TIPO_DESCONOCIDO 260 · EDAD_AUSENTE 101 · EDAD_FUERA_RANGO 96 · NOMBRE_DESCONOCIDO 24 | [`02-bd/03-interes_calculado.txt`](02-bd/03-interes_calculado.txt) |
| cuentas_anuales.csv | VALIDA 524 · MONTO_NEGATIVO 173 · DESCRIPCION_AUSENTE 162 · SIGNO_CONTRADICTORIO 81 · MONTO_CERO 12 | [`02-bd/05-movimiento_anual.txt`](02-bd/05-movimiento_anual.txt) |

Los motivos de rechazo (el otro lado de la regla de precedencia) estan en
[`02-bd/07-registro_rechazado.txt`](02-bd/07-registro_rechazado.txt):
MONTO_AUSENTE 160 + FECHA_INVALIDA 55 · SALDO_AUSENTE 211 + DUPLICADO 5 · MONTO_AUSENTE 48.

## Criterio 4 — Escalado comparando parametros · 15 pts

| Que demuestra | Fichero |
|---|---|
| Banco de pruebas completo (2 escalas x 12 celdas x 5 rondas medidas) | [`../results/scaling-results.csv`](../results/scaling-results.csv) |
| Tabla comparativa con mediana, IQR, CV, speedup y throughput | [`../results/scaling-summary.md`](../results/scaling-summary.md) |
| Analisis y eleccion del optimo | [`../docs/escalado.md`](../docs/escalado.md) |
| Graficos speedup / throughput / cajas (2 escalas) | [`04-escalado/`](04-escalado/) (6 SVG) |
| Prueba de que las particiones corren en hilos DISTINTOS | [`04-escalado/hilos-particionado.txt`](04-escalado/hilos-particionado.txt) |
| Log de una corrida particionada gridSize=4 | [`04-escalado/log-particionado-grid4.txt`](04-escalado/log-particionado-grid4.txt) |
| Metricas de Micrometer | [`04-escalado/metricas-micrometer.txt`](04-escalado/metricas-micrometer.txt) |
| Reparto real por particion (skew 1.000, ratio 1.263) | [`02-bd/verificacion-06-particiones.txt`](02-bd/verificacion-06-particiones.txt) |

Resumen del hallazgo (20.000 filas): `PARTICIONADO` con paralelismo 8 y chunk 500
es el optimo, **4.47x** sobre la base secuencial (12010 ms -> 2689 ms), y con el
CV mas bajo (2.3 %) de todas las configuraciones paralelas.

## Criterio 5 — Reintento y tolerancia a fallos, varios escenarios · 15 pts

Un directorio con log por escenario, todos reproducibles con `scripts/escenarios-fallo/escenario-*.sh`.

| # | Escenario | Comportamiento esperado | Log |
|---|---|---|---|
| E8 | Caida **transitoria** de la BD | RETRY, se recupera, COMPLETED 785+215 | [`05-fallos/bd-transitoria/log.txt`](05-fallos/bd-transitoria/log.txt) |
| E9 | **Bloqueo** / contencion de cerrojo | RETRY con backoff, COMPLETED 785+215 | [`05-fallos/bloqueo/log.txt`](05-fallos/bloqueo/log.txt) |
| E11 | Caida **permanente** de la BD | Se agotan los 3 intentos, FAILED | [`05-fallos/bd-caida/log.txt`](05-fallos/bd-caida/log.txt) |
| E12 | Error **fatal** de escritura | Ni retry ni skip, FAILED de inmediato | [`05-fallos/escritura-fatal/log.txt`](05-fallos/escritura-fatal/log.txt) |
| E13 | **Techo de omisiones** superado | SkipLimitExceededException, FAILED | [`05-fallos/limite-omisiones/log.txt`](05-fallos/limite-omisiones/log.txt) |
| E16 | **Doble ejecucion** + reinicio tras FAILED | 1a OK, 2a FAILED, 3a se **reinicia** y vuelve a 785+215 | [`05-fallos/doble-ejecucion/log.txt`](05-fallos/doble-ejecucion/log.txt) |

El escenario de doble ejecucion es ademas la prueba del reinicio: en la tercera
corrida se ven **los dos** steps `stepPrepararTransacciones` y
`stepCargarTransaccionesManager` ejecutandose, que es lo que garantiza que la
limpieza y la recarga se repiten juntas. Ver `docs/tolerancia-fallos.md`.

## Criterio 6 — Politicas generales, optimizacion y estabilidad · 15 pts

| Que demuestra | Fichero |
|---|---|
| CV por configuracion (estabilidad entre rondas) | [`../results/scaling-summary.md`](../results/scaling-summary.md) |
| El esquema rechaza de verdad los datos invalidos (14 pruebas negativas) | `scripts/consultas-sql/auditar-esquema.sql`, ver nota abajo |
| Cuadratura persistida de todas las ejecuciones | [`02-bd/00-cuadratura.txt`](02-bd/00-cuadratura.txt) |

Para regenerar la auditoria del esquema:

```bash
docker exec -i bancoxyz-db psql -U banco -d bancoxyz < scripts/consultas-sql/auditar-esquema.sql
```

Las 14 pruebas B1..B14 deben imprimir cada una el `ERROR` de **su** restriccion
nombrada, y la parte A debe entrar entera. El script usa claves centinela
(cuenta 999, anio 1999, periodo '1999-01') para no colisionar con datos reales,
y termina en `ROLLBACK`: no deja ni una fila.

## Criterio 7 — Los 3 entregables (codigo, documentacion, evidencia) · 10 pts

| Entregable | Donde |
|---|---|
| Codigo | `src/main/java/cl/duoc/bancoxyz/` (73 clases) + `src/test/` |
| Documentacion | `README.md`, `docs/escalado.md`, `docs/tolerancia-fallos.md`, `docs/plan-maestro.md`, `docs/analisis-datos.md` |
| Evidencia | esta carpeta, indexada por este fichero |
| Log de ejecucion por **cada** uno de los 3 jobs | `02-job1/2/3-*-completo.txt` |
| Captura de BD por **cada** tabla de negocio + rechazados | `02-bd/01..07-*.txt` |

---

## Como regenerar toda esta evidencia

```bash
# 1. los tres jobs, en orden
./mvnw -q spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias
./mvnw -q spring-boot:run -Dspring-boot.run.arguments=--job=jobInteresesMensuales
./mvnw -q spring-boot:run -Dspring-boot.run.arguments=--job=jobEstadosCuentaAnuales

# 2. la cuadratura, que debe dar 1000 en las tres filas
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "SELECT * FROM banco.v_cuadratura"

# 3. los seis escenarios de fallo
for s in bd-transitoria bloqueo bd-caida escritura-fatal limite-omisiones doble-ejecucion; do
  bash scripts/escenarios-fallo/escenario-$s.sh > evidencias/05-fallos/$s/log.txt 2>&1
done

# 4. el banco de pruebas de escalado (tarda; usa el perfil experiment)
./mvnw -q spring-boot:run -Dspring-boot.run.profiles=experiment
```
