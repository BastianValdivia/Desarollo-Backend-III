# Guía de replicación en otra máquina

Cómo poner este proyecto en marcha desde cero en un PC nuevo, y qué hacer cuando algo falla.

> Si solo quieres el resumen: instala **JDK 21+** y **Docker Desktop**, ejecuta
> `./scripts/verificar-entorno.sh`, y si todo sale en verde lanza los dos comandos del paso 3.

---

## 1. Qué necesitas instalar

Solo dos cosas.

| Requisito | Versión | Dónde |
|---|---|---|
| **JDK** | 21 o superior | https://adoptium.net (Temurin) |
| **Docker Desktop** | cualquiera reciente | https://www.docker.com/products/docker-desktop |

**No** necesitas instalar Maven: el proyecto trae el *wrapper* (`mvnw`), un script que descarga
la versión correcta de Maven por su cuenta.

**No** necesitas instalar PostgreSQL: se levanta dentro de un contenedor Docker.

**No** necesitas descargar datos: los tres CSV de origen viajan dentro del proyecto, en
`src/main/resources/data/`.

Sí necesitas **conexión a internet la primera vez**: Maven descarga unos 150–200 MB de
librerías y Docker se baja la imagen de PostgreSQL (~110 MB). Después funciona sin red.

### Sobre la versión de Java

El `pom.xml` declara `<java.version>21</java.version>`. Eso activa la opción `--release 21`
del compilador, que significa *"genera bytecode compatible con Java 21 y prohíbeme usar
cualquier API posterior"*. Consecuencia práctica: puedes compilar con un JDK 21, 22, 23, 24
o 25 y el resultado es el mismo. Con un JDK 17 **no** compila.

---

## 2. Comprobar la máquina antes de empezar

```bash
./scripts/verificar-entorno.sh
```

Revisa Java, Docker, el puerto 5432, que estén todos los archivos imprescindibles y si hace
falta internet. No modifica nada: solo mira y, cuando encuentra un problema, explica cómo
resolverlo.

En Windows ejecútalo desde **Git Bash**. Si prefieres no usarlo, los pasos del apartado 3
funcionan igual; el script solo te ahorra descubrir los problemas a media ejecución.

---

## 3. Puesta en marcha

**Paso 1 — Levantar la base de datos.**

```bash
docker compose up -d
```

`up` crea y arranca el contenedor; `-d` lo deja en segundo plano. La primera vez tarda
un poco porque descarga la imagen.

Comprueba que responde:

```bash
docker exec bancoxyz-db pg_isready -U banco -d bancoxyz
```

**Paso 2 — Ejecutar el primer job.**

```bash
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobTransaccionesDiarias
```

En Windows con CMD o PowerShell usa `mvnw.cmd` en lugar de `./mvnw`.

Al arrancar, la aplicación crea sola las 9 tablas de negocio y las 6 tablas internas de
Spring Batch. No hay que ejecutar ningún SQL a mano.

**Paso 3 — Los otros dos jobs.**

```bash
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobInteresesMensuales
./mvnw spring-boot:run -Dspring-boot.run.arguments=--job=jobEstadosCuentaAnuales
```

Los tres jobs se pueden ejecutar **varias veces seguidas** sin borrar nada: cada uno empieza
por un step de preparación que limpia su propia carga anterior.

---

## 4. Cómo saber que replicó bien

Una sola consulta lo decide:

```bash
docker exec bancoxyz-db psql -U banco -d bancoxyz -c "SELECT * FROM banco.v_cuadratura"
```

Debe devolver exactamente esto:

```
       archivo       | negocio | rechazos | total
---------------------+---------+----------+-------
 transacciones.csv   |     785 |      215 |  1000
 intereses.csv       |     784 |      216 |  1000
 cuentas_anuales.csv |     952 |       48 |  1000
```

Si las tres filas dan **1000** en `total`, la replicación es correcta: ninguna fila se perdió
en ninguno de los tres procesos. Si algún número difiere, algo del entorno no coincide.

Comprobación más exigente, la batería completa de pruebas (necesita Docker encendido, porque
levanta un PostgreSQL real para los tests):

```bash
./mvnw test
```

Deben pasar **149 pruebas sin fallos**.

---

## 5. Problemas frecuentes

### 5.1 `Connection to localhost:5432 refused`

Docker Desktop no está arrancado, o el contenedor no está levantado.

```bash
docker info                # ¿responde el motor?
docker compose up -d       # levanta el contenedor
docker compose ps          # ¿aparece bancoxyz-db como "Up"?
```

### 5.2 El puerto 5432 ya está ocupado — **el fallo más frecuente**

Ocurre si el PC ya tiene PostgreSQL instalado de forma nativa, o si otro proyecto tiene un
contenedor usando ese puerto. Es traicionero porque puede no dar un error claro: la
aplicación se conecta al **PostgreSQL equivocado** y crea sus tablas donde no debe.

Detectarlo:

```bash
# Windows
netstat -ano | findstr :5432
# Linux / macOS
lsof -iTCP:5432 -sTCP:LISTEN
```

Hay dos soluciones.

**Opción A — apagar el PostgreSQL que estorba.** En Windows, desde una terminal de
administrador:

```bash
net stop postgresql-x64-17      # ajusta el número a tu versión
```

**Opción B — mover nuestro contenedor a otro puerto.** Es la opción no invasiva. Cuando
Docker publica un puerto lo escribe como `HOST:CONTENEDOR`: el número de la **izquierda** es
el de tu máquina y el de la **derecha** el de dentro del contenedor. Solo choca el de la
izquierda.

En `compose.yaml`:

```yaml
    ports:
      - "5433:5432"     # antes: "5432:5432"
```

Y en `src/main/resources/application.yml`:

```yaml
    url: jdbc:postgresql://localhost:5433/bancoxyz?currentSchema=batch_meta,banco,public
```

Después: `docker compose down && docker compose up -d`.

### 5.3 `relation "banco.transaccion" does not exist` o falta el esquema `batch_meta`

El archivo `docker/initdb/00-schemas.sql` crea los dos esquemas, pero Docker **solo ejecuta
esos scripts cuando crea el volumen por primera vez**. Si reutilizas un volumen antiguo,
nunca se aplican.

```bash
docker compose down -v      # el -v BORRA el volumen y sus datos
docker compose up -d
```

Los datos se regeneran ejecutando los jobs, así que borrar el volumen no cuesta nada.

### 5.4 La aplicación no termina nunca

Ya está resuelto en el código (los hilos del pool de particiones son *daemon*), pero si
alguna vez lo ves: los hilos no-daemon impiden que la JVM salga, aunque el job haya
terminado bien. Se corta con Ctrl+C.

### 5.5 `JobInstanceAlreadyCompleteException`

No debería ocurrir: el lanzador aplica un `RunIdIncrementer` que añade un parámetro distinto
en cada ejecución. Si aparece, es que se lanzó el job sin pasar por `LanzadorJobs`.

### 5.6 La primera compilación tarda muchísimo

Normal: Maven está descargando las dependencias a `~/.m2`. Solo pasa una vez.

### 5.7 `./mvnw: Permission denied` en Linux o macOS

```bash
chmod +x mvnw scripts/*.sh
```

---

## 6. Qué NO copiar entre máquinas

| No copies | Por qué |
|---|---|
| `target/` | Son los `.class` compilados. Se regeneran con `./mvnw compile`, y arrastrarlos entre JDK distintos puede dar problemas raros |
| `~/.m2` | La caché de Maven. Ocupa gigas y se reconstruye sola |
| El volumen de Docker (`pgdata`) | **La base de datos es desechable**: se recrea desde `schema-negocio.sql` y se rellena ejecutando los jobs en unos segundos |
| Archivos `*.bak` | Copias de seguridad de trabajo, no forman parte del proyecto |
| `data/generated/` | El dataset amplificado del benchmark. Lo regenera `AmplificadorDataset` de forma determinista |

La idea de fondo: **todo el estado se reconstruye desde los tres CSV**. Si en algún momento
piensas "tengo que llevarme la base de datos", algo va mal.

---

## 7. Ficheros que sí son imprescindibles

Si alguno falta, el proyecto no arranca:

- `pom.xml`, `mvnw`, `mvnw.cmd`, `.mvn/` — la construcción
- `compose.yaml` — la definición del contenedor de PostgreSQL
- `docker/initdb/00-schemas.sql` — crea los esquemas `banco` y `batch_meta` **antes** de que
  arranque la aplicación
- `src/main/resources/schema-negocio.sql` — las 9 tablas de negocio y las vistas
- `src/main/resources/application.yml` — la conexión y la configuración de Spring Batch
- `src/main/resources/data/*.csv` — los datos de entrada
- `src/` completo — el código

El script `./scripts/verificar-entorno.sh` comprueba esta lista por ti.
