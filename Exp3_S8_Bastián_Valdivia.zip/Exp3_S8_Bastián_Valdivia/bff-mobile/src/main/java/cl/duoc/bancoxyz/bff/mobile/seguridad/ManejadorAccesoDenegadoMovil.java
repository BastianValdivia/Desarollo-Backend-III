package cl.duoc.bancoxyz.bff.mobile.seguridad;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.access.AccessDeniedHandler;

import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.error.MotivosError;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Responde los <strong>403</strong> de autoridad: los casos en que el servicio
 * <em>sabe perfectamente quien eres</em> y aun asi no te deja.
 *
 * <p>Se ejecuta cuando una regla {@code requestMatchers(...).hasAuthority(...)}
 * de la cadena de filtros no se cumple. El motivo es siempre
 * {@code permiso_insuficiente}: al token le falta la autoridad exacta que la
 * ruta exige.
 *
 * <h2>La distincion que hay que tener clara, porque se confunde a menudo</h2>
 *
 * <p>Este canal produce dos 403 con significados distintos:
 *
 * <ul>
 *   <li><b>{@code permiso_insuficiente}</b>, que decide esta clase, es sobre la
 *       <b>operacion</b>: no puedes dar de baja un dispositivo, con ninguno.
 *       Se resuelve en la cadena de filtros porque depende solo de la ruta y de
 *       las autoridades del token.</li>
 *   <li><b>{@code cuenta_ajena}</b>, que decide el servicio, es sobre el
 *       <b>dato</b>: puedes consultar resumenes, pero no ese. No podria
 *       resolverse aqui, porque exige comparar un claim del token con una
 *       variable de la ruta.</li>
 * </ul>
 *
 * <p>Son los niveles de operacion y de dato de la seccion 6.4 del contrato, y
 * responden preguntas distintas: por eso tienen dos motivos y dos pruebas
 * separadas.
 *
 * <h2>Por que un 403 nunca lleva WWW-Authenticate</h2>
 *
 * <p>Esa cabecera significa "identificate". Enviarsela a quien ya se identifico
 * correctamente lo manda a repetir un login que no va a cambiar nada: volveria
 * con el mismo token y las mismas autoridades. Un cliente automatico bien
 * escrito entraria en un ciclo de renovacion infinito. La ausencia de la
 * cabecera es, literalmente, la diferencia entre "vuelve a autenticarte" y "no
 * insistas".
 */
public class ManejadorAccesoDenegadoMovil implements AccessDeniedHandler {

    private static final Logger log = LoggerFactory.getLogger(ManejadorAccesoDenegadoMovil.class);

    private final EscritorErrorHttp escritor;

    public ManejadorAccesoDenegadoMovil(EscritorErrorHttp escritor) {
        this.escritor = escritor;
    }

    @Override
    public void handle(HttpServletRequest peticion,
                       HttpServletResponse respuesta,
                       AccessDeniedException denegacion) throws IOException {

        Authentication autenticacion = SecurityContextHolder.getContext().getAuthentication();

        // Nivel warn y con el sujeto: un 403 no es una averia, pero si es el
        // tipo de evento que interesa cuando se repite. Las autoridades del
        // token NO se registran: son informacion sobre lo que esa persona
        // puede hacer en el banco, y un log no es el lugar para guardarla.
        log.warn("Autoridad insuficiente. Sujeto={}, operacion={} {}",
                autenticacion == null ? "desconocido" : autenticacion.getName(),
                peticion.getMethod(), peticion.getRequestURI());

        ProblemaMovil.escribir(escritor, peticion, respuesta,
                HttpStatus.FORBIDDEN.value(),
                MotivosError.PERMISO_INSUFICIENTE,
                "Acceso denegado",
                "Su sesion no tiene permiso para esta operacion en el canal movil");
    }
}
