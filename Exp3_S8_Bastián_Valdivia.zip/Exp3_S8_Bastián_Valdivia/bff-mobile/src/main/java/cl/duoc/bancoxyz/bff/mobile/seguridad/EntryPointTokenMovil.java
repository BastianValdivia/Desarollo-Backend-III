package cl.duoc.bancoxyz.bff.mobile.seguridad;

import java.io.IOException;
import java.util.Locale;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.error.MotivosError;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Responde los <strong>401</strong> del canal movil: los casos en que el
 * servicio <em>no sabe quien eres</em>.
 *
 * <h2>Que es un AuthenticationEntryPoint</h2>
 *
 * <p>Es el objeto al que Spring Security le pasa la palabra cuando una peticion
 * necesitaba estar autenticada y no lo estaba. El nombre es historico y
 * confunde: no es una "puerta de entrada" por la que se pasa, es <b>la
 * respuesta que se da a quien no pudo entrar</b>. Sin uno propio, Spring
 * devuelve su pagina de error generica, sin el campo {@code motivo} que leen
 * los guiones de evidencia y con una forma que no se parece a ninguna otra
 * respuesta de esta API.
 *
 * <h2>Los cuatro motivos de 401, y por que hay que distinguirlos</h2>
 *
 * <p>Un guion de evidencia no lee solo el codigo HTTP: lee el campo
 * {@code motivo}. "Tu token esta vencido" y "ese token no es de este canal" son
 * los dos 401 mas distintos que existen desde el punto de vista de quien
 * diagnostica, y colapsarlos en uno solo convierte la evidencia en un numero
 * sin informacion.
 *
 * <table border="1">
 *   <caption>Clasificacion de los 401 de este canal</caption>
 *   <tr><th>Situacion</th><th>motivo</th></tr>
 *   <tr><td>No llego {@code Authorization}, o llego sin el esquema {@code Bearer}</td>
 *       <td>{@code token_ausente}</td></tr>
 *   <tr><td>La firma verifica y el {@code exp} ya paso</td><td>{@code token_expirado}</td></tr>
 *   <tr><td>La firma no verifica: token manipulado, <b>o token legitimo de otro canal</b></td>
 *       <td>{@code firma_invalida}</td></tr>
 *   <tr><td>La firma verifica y el claim {@code aud} no nombra a este canal</td>
 *       <td>{@code audiencia_invalida}</td></tr>
 * </table>
 *
 * <p>El orden de comprobacion (firma, vigencia, audiencia) no lo decide esta
 * clase: lo decide el decodificador, que primero verifica la firma y solo
 * despues ejecuta los validadores de claims. La consecuencia hay que saberla de
 * memoria antes de producir la matriz cruzada de tokens: hoy, como cada canal
 * firma con su propia clave, <b>el token del vecino muere en la primera barrera
 * y sale {@code firma_invalida}, no {@code audiencia_invalida}</b>.
 *
 * <h2>Por que la clasificacion mira un texto, y por que esta bien</h2>
 *
 * <p>Spring Security entrega estos tres fallos como un mismo tipo de excepcion
 * ({@code invalid_token}) y la unica diferencia esta en la descripcion. Mirar
 * ese texto es lo que hay, y la alternativa seria peor: escribir validadores
 * propios de firma, vigencia y audiencia para poder distinguirlos, es decir
 * reimplementar a mano justo lo que se decidio delegar. La clasificacion es
 * ademas <b>degradable con seguridad</b>: si una version futura cambia el
 * texto, el peor resultado posible es un 401 etiquetado como
 * {@code firma_invalida} en lugar de su motivo exacto. Nunca deja pasar a
 * nadie, que es la unica propiedad que no se puede perder.
 */
public class EntryPointTokenMovil implements AuthenticationEntryPoint {

    private static final String ESQUEMA = "Bearer ";

    private final EscritorErrorHttp escritor;

    public EntryPointTokenMovil(EscritorErrorHttp escritor) {
        this.escritor = escritor;
    }

    @Override
    public void commence(HttpServletRequest peticion,
                         HttpServletResponse respuesta,
                         AuthenticationException fallo) throws IOException {

        String cabecera = peticion.getHeader(HttpHeaders.AUTHORIZATION);
        boolean traeToken = cabecera != null && cabecera.startsWith(ESQUEMA);

        String motivo = traeToken ? clasificar(fallo) : MotivosError.TOKEN_AUSENTE;

        /*
         * WWW-Authenticate en toda respuesta 401, como exige la seccion 7.4 del contrato, y con el
         * valor EXACTO que esa seccion congela: la palabra "Bearer" y nada mas.
         *
         * Por que no se agrega el parametro error="invalid_token" del RFC 6750, que seria mas
         * informativo para un cliente automatico. Porque el contrato es la fuente unica de verdad y
         * congela el valor de la cabecera, no solo su presencia, y los otros dos canales emiten
         * "Bearer" a secas. Tres canales que responden tres cosas distintas a la misma pregunta
         * convierten la evidencia comparativa en ruido: quien la lee ya no puede saber si la
         * diferencia es una decision de canal o un descuido de quien la escribio. La regla de
         * cambio del contrato existe justamente para esto: si algun dia se quiere el parametro del
         * RFC, se escribe PRIMERO en el contrato para los tres canales y despues en el codigo de
         * los tres, en el mismo commit. Nunca al reves, y nunca en un canal solo.
         */
        respuesta.setHeader(HttpHeaders.WWW_AUTHENTICATE, "Bearer");

        ProblemaMovil.escribir(escritor, peticion, respuesta,
                HttpStatus.UNAUTHORIZED.value(),
                motivo,
                "Sesion no valida",
                detalleDe(motivo));
    }

    /**
     * Traduce el fallo del validador a uno de los tres motivos posibles.
     *
     * <p>Se comprueba la vigencia antes que la audiencia porque un token
     * vencido de este mismo canal trae una audiencia perfectamente valida: si
     * se preguntara primero por {@code aud}, el caso mas comun de todos (la
     * sesion que expiro) quedaria sin detectar y saldria etiquetado como
     * cualquier otra cosa.
     */
    private String clasificar(AuthenticationException fallo) {
        String descripcion = fallo instanceof OAuth2AuthenticationException oauth
                ? String.valueOf(oauth.getError().getDescription())
                : String.valueOf(fallo.getMessage());

        String texto = descripcion.toLowerCase(Locale.ROOT);

        if (texto.contains("expired")) {
            return MotivosError.TOKEN_EXPIRADO;
        }
        if (texto.contains("aud")) {
            return MotivosError.AUDIENCIA_INVALIDA;
        }
        // Cualquier otro fallo de decodificacion es, para este canal, una firma
        // que no valida. Es el destino del token legitimo de bff-web o de
        // bff-atm presentado aqui, que es la celda tipica de la matriz cruzada.
        return MotivosError.FIRMA_INVALIDA;
    }

    /**
     * Texto para el dueno del telefono.
     *
     * <p>Este canal si incluye {@code detail} (el cajero lo omite, porque su
     * pantalla esta en la via publica). Aun asi el texto no describe el fallo
     * criptografico: decirle a quien presento un token manipulado en que parte
     * fallo es darle la correccion para el siguiente intento. Lo util para el
     * usuario legitimo es saber si tiene que volver a iniciar sesion, y eso si
     * se dice.
     */
    private String detalleDe(String motivo) {
        return switch (motivo) {
            case MotivosError.TOKEN_AUSENTE ->
                    "Esta operacion requiere iniciar sesion en el canal movil";
            case MotivosError.TOKEN_EXPIRADO ->
                    "La sesion expiro, inicie sesion nuevamente";
            default ->
                    "La sesion no es valida en este canal";
        };
    }
}
