package cl.duoc.bancoxyz.bff.mobile.api;

import java.util.concurrent.TimeUnit;

import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.bancoxyz.bff.mobile.api.dto.ResumenMovilResponse;
import cl.duoc.bancoxyz.bff.mobile.aplicacion.ResumenMovilService;
import cl.duoc.bancoxyz.comun.token.LectorClaimsToken;

/**
 * Unico controlador de datos del canal movil. Expone <strong>M2</strong>,
 * {@code GET /v1/cuentas/{id}/resumen}.
 *
 * <h2>Rol en la arquitectura: la puerta, no la cocina</h2>
 *
 * <p>Un controlador REST traduce entre el mundo HTTP (una ruta, un verbo, unas
 * cabeceras) y una llamada a un metodo Java. Eso es todo lo que hace este, y
 * es todo lo que debe hacer: recibe el {@code cuentaId} de la ruta, se lo pasa
 * a {@link ResumenMovilService} y devuelve lo que ese servicio construyo.
 *
 * <p><b>Por que el recorte no esta aqui.</b> Si la proyeccion del DTO del core
 * al DTO del canal viviera en este metodo, quedaria amarrada al protocolo:
 * para probar la regla "cinco movimientos de tres campos" habria que levantar
 * un servidor, hacer una peticion HTTP y leer un JSON. La regla es de negocio
 * del canal, no de transporte, asi que vive en la capa de aplicacion y aqui
 * queda una linea.
 *
 * <h2>Por que la URL completa no se parece a lo que dice este archivo</h2>
 *
 * <p>Lo que se declara aqui es {@code /v1/cuentas/{cuentaId}/resumen}, pero la
 * direccion real es:
 *
 * <pre>http://localhost:8444/api/mobile/v1/cuentas/116/resumen</pre>
 *
 * <p>El tramo {@code /api/mobile} es el {@code context-path} del canal,
 * configurado en {@code config-repo/bff-mobile.yml}, y Spring lo antepone a todo lo que
 * este servicio publica. Conviene tenerlo presente porque es la causa del 404
 * mas frecuente del proyecto. Actuator ya no depende de el: desde la fase F1
 * vive en un puerto de gestion aparte y sin prefijo
 * ({@code http://127.0.0.1:8083/actuator/health} en local).
 *
 * <h2>Lo que este controlador NO expone, a proposito</h2>
 *
 * <ul>
 *   <li><b>Sin parametros de paginacion.</b> No hay {@code page} ni
 *       {@code size}. El canal entrega siempre los cinco ultimos movimientos.
 *       Es una decision de canal, no una funcionalidad faltante: el BFF decide
 *       por el cliente delgado en lugar de confiar en que el cliente pida
 *       poco. El canal web, cuyo cliente es un navegador con pantalla grande,
 *       si los expone.</li>
 *   <li><b>Sin ruta de baja de dispositivo.</b> El endpoint M3,
 *       {@code POST /v1/dispositivos/baja}, es exclusivo de este canal y vive
 *       en su propio controlador,
 *       {@link DispositivoMovilController}, porque habla de otro recurso.</li>
 * </ul>
 *
 * <h2>Que hace falta para llegar hasta aqui, desde la etapa de seguridad</h2>
 *
 * <p>Tres barreras, en este orden, antes de que el metodo se ejecute:
 *
 * <ol>
 *   <li>un token de <b>este</b> canal, valido en firma, vigencia y audiencia;</li>
 *   <li>presentado desde el <b>mismo dispositivo</b> al que se emitio, es decir
 *       con una cabecera {@code X-Device-Id} igual al claim del token;</li>
 *   <li>con la autoridad {@code PERM_saldo:leer}.</li>
 * </ol>
 *
 * <p>La cuarta comprobacion, la titularidad de la cuenta pedida, no cabe en la
 * cadena de filtros porque depende de la variable de ruta: se hace en el
 * servicio y produce <b>403 {@code cuenta_ajena}</b>.
 */
@RestController
@RequestMapping("/v1/cuentas")
public class ResumenMovilController {

    private final ResumenMovilService servicio;

    public ResumenMovilController(ResumenMovilService servicio) {
        this.servicio = servicio;
    }

    /**
     * M2. Devuelve saldo y los cinco ultimos movimientos de la cuenta.
     *
     * <p><b>Sobre el tipo del parametro.</b> Se declara {@code int} y no
     * {@code String}. Con eso, {@code /v1/cuentas/abc/resumen} ni siquiera
     * entra al metodo: Spring falla al convertir y el manejador de errores del
     * canal lo traduce. La validacion del formato la hace el framework una
     * sola vez y bien, en lugar de repetirse en cada controlador.
     *
     * <p><b>Por que devuelve el record y no un {@code ResponseEntity}.</b>
     * Este metodo solo tiene un resultado posible cuando todo va bien: 200 con
     * el cuerpo. Todos los demas caminos son excepciones que traduce
     * {@link ManejadorErroresMovil}. Envolver la respuesta feliz en un
     * {@code ResponseEntity} agregaria ruido sin agregar ninguna decision.
     *
     * <p><b>Por que el controlador pasa DOS identificadores de cuenta.</b> Uno
     * es el que el cliente pidio (la variable de ruta) y el otro es el que su
     * token acredita (el claim {@code cuentaId}). La comparacion entre ambos es
     * la comprobacion de titularidad, y se hace en el servicio, no aqui: el
     * controlador se limita a entregarle los dos datos que necesita para
     * decidir. Asi la regla se puede probar sin levantar un servidor ni fabricar
     * un token.
     *
     * @param cuentaId identificador de la cuenta pedido en la ruta, entre 101 y 150
     * @param jwt      token ya validado de quien hace la peticion
     * @return el resumen del canal movil
     */
    /**
     * Resumen M2 de la cuenta.
     *
     * <p><strong>Por que devuelve {@code ResponseEntity} y no el DTO pelado.</strong> Solo para
     * poder fijar la cabecera {@code Cache-Control}, y esa cabecera es la mitad que le falta al
     * ETag para servir de algo.
     *
     * <h3>{@code no-cache} y {@code no-store} no son sinonimos, y la diferencia decide el canal</h3>
     *
     * <p>Los nombres estan mal puestos en el estandar y confunden a todo el mundo:
     *
     * <ul>
     *   <li><strong>{@code no-store}</strong> significa "no guardes ninguna copia de esto". Es lo
     *       que Spring Security pone <em>por defecto en todas las respuestas</em>, que es una
     *       eleccion prudente para un servicio bancario.</li>
     *   <li><strong>{@code no-cache}</strong> significa algo bastante distinto: "puedes guardar
     *       una copia, pero <em>pregunta antes de usarla</em>". Es decir, revalidacion
     *       obligatoria.</li>
     * </ul>
     *
     * <p>Con el {@code no-store} por defecto, el telefono no conserva nada, nunca reenvia un
     * {@code If-None-Match} y <strong>el ETag no se activa jamas</strong>: se habria configurado
     * un filtro, se veria la cabecera {@code ETag} en la respuesta y el ahorro seria cero. Con
     * {@code no-cache} el telefono guarda la copia, la revalida en cada consulta y recibe un 304
     * vacio mientras el saldo no cambie, que es exactamente el ahorro que este canal busca.
     *
     * <p>Se agrega {@code private} para que la copia la conserve <strong>solo el telefono</strong>
     * y no ningun intermediario compartido: el saldo de un cliente no debe quedar en la cache de
     * un proxy por el que pasan los datos de otros.
     *
     * <p>Notese que esto <strong>no</strong> es una relajacion de la seguridad del canal: el
     * cliente sigue teniendo que revalidar, y para revalidar tiene que presentar su token. Lo que
     * se le permite es no volver a descargar un cuerpo que ya tiene.
     *
     * <p>Spring Security respeta esta cabecera porque su escritor por defecto solo la fija si la
     * respuesta no la trae ya puesta. El canal del cajero no hace nada de esto y conserva el
     * {@code no-store}, deliberadamente: alli no hay ningun ahorro de bytes que compense que un
     * terminal reutilice un saldo viejo.
     */
    @GetMapping("/{cuentaId}/resumen")
    public ResponseEntity<ResumenMovilResponse> obtenerResumen(@PathVariable int cuentaId,
                                                               @AuthenticationPrincipal Jwt jwt) {

        // LectorClaimsToken vive en plataforma-comun: leer un claim con el
        // nombre correcto es mecanismo, y los tres canales lo comparten. Que
        // ese claim signifique titularidad y que se compare contra esta ruta es
        // politica, y por eso se decide en el servicio de este modulo.
        ResumenMovilResponse resumen =
                servicio.obtenerResumen(cuentaId, LectorClaimsToken.cuentaId(jwt));

        return ResponseEntity.ok()
                .cacheControl(CacheControl.noCache()
                        .cachePrivate()
                        // El maximo de antiguedad que el telefono puede reutilizar si se queda
                        // sin red y decide servir una copia rancida. Cero: no queremos que una
                        // aplicacion bancaria muestre un saldo viejo por estar sin cobertura,
                        // preferimos que muestre un error.
                        .staleWhileRevalidate(0, TimeUnit.SECONDS))
                .body(resumen);
    }
}
