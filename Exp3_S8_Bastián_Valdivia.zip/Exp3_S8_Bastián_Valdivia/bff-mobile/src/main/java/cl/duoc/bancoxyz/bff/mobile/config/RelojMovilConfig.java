package cl.duoc.bancoxyz.bff.mobile.config;

import java.time.Clock;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Publica el reloj del canal como un bean inyectable.
 *
 * <h2>Por que un reloj se inyecta en vez de llamar a {@code Instant.now()}</h2>
 *
 * <p>Porque {@code Instant.now()} escrito dentro de un servicio es una
 * dependencia oculta e inmovible: no hay forma de probar que ocurre en un
 * instante concreto sin esperar de verdad a que pase el tiempo. Con un
 * {@link Clock} inyectado, una prueba puede pasar {@code Clock.fixed(...)} y
 * afirmar sobre un valor exacto, que es lo que permite verificar que la baja de
 * dispositivo devuelve el instante truncado a segundos del contrato y no uno
 * con milisegundos.
 *
 * <p>Va en UTC y no en la zona de la maquina: la seccion 5.1 del contrato
 * congela los instantes en ISO-8601 con zona, en UTC. Un servicio que tomara la
 * zona del sistema produciria respuestas distintas segun donde se ejecute, y la
 * evidencia dejaria de ser comparable entre la maquina del estudiante y la de
 * quien corrige.
 */
@Configuration
public class RelojMovilConfig {

    @Bean
    public Clock relojUtc() {
        return Clock.systemUTC();
    }
}
