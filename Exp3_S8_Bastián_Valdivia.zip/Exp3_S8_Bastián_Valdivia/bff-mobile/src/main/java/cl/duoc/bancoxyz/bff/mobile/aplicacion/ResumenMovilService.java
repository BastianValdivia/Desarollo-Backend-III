package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import java.util.List;

import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.bff.mobile.api.dto.MovimientoMovilResponse;
import cl.duoc.bancoxyz.bff.mobile.api.dto.ResumenMovilResponse;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;

/**
 * Capa de aplicacion del canal movil: pide la cuenta al {@code core-service} y
 * la <strong>traduce</strong> a la forma exacta que el telefono necesita.
 *
 * <h2>Rol en la arquitectura, y por que la traduccion vive aqui</h2>
 *
 * <p>Esta clase es el BFF propiamente dicho. El controlador de al lado solo
 * recibe una peticion HTTP y devuelve un objeto; el core solo sabe de cuentas
 * completas y genericas. El unico lugar del sistema donde alguien decide
 * <em>que se queda y que se va</em> para el canal movil es este.
 *
 * <p>Tenerlo separado del controlador no es ceremonia. Es lo que permite
 * probar la regla de recorte (cinco movimientos, tres campos, titular
 * abreviado) sin levantar un servidor HTTP: basta construir esta clase con una
 * implementacion de prueba de {@link CoreClient}. Si el recorte viviera dentro
 * del metodo del controlador, probarlo exigiria un contexto web completo, y lo
 * que cuesta probar termina sin prueba.
 *
 * <h2>Por que se llama a C2 (cuenta completa) y no a C3 (solo saldo)</h2>
 *
 * <p>Es la pregunta correcta, porque el core ofrece
 * {@code /internal/v1/cuentas/{id}/saldo}, que es mucho mas liviano, y la
 * matriz de optimizacion del plan asigna al movil el uso de endpoints
 * livianos aguas arriba. La razon de no usarlo aqui es concreta: la respuesta
 * M2 incluye {@code titular}, y <strong>el unico endpoint del core que
 * entrega el titular es C2</strong>. Con C3 mas C4 harian falta
 * <em>dos</em> viajes al core, se seguiria sin tener el nombre, y el resumen
 * no se podria armar.
 *
 * <p>Y hay algo que esa comparacion suele pasar por alto: el trafico caro es
 * el del telefono, no el del salto entre el BFF y el core. Ese salto ocurre
 * dentro de la misma maquina, contra {@code 127.0.0.1}, sobre datos que ya
 * estan en memoria. El recorte que importa es el que ocurre justo despues, en
 * {@link #proyectar}, porque es el que decide cuantos bytes cruzan la red
 * celular. Que el BFF cargue con la respuesta grande para que el telefono no
 * tenga que hacerlo es, literalmente, el trabajo de un BFF.
 *
 * <p>Queda anotado como pendiente para quien revise el sistema completo: si el
 * core expusiera un endpoint que devolviera saldo y titular juntos, este canal
 * lo preferiria. Ese cambio es del {@code core-service} y no se hace desde
 * aqui.
 *
 * <h2>Lo que esta clase NO hace</h2>
 *
 * <ul>
 *   <li><b>No comprueba el dispositivo.</b> Que el {@code X-Device-Id} de la
 *       peticion coincida con el claim del token es una regla del canal
 *       completo y por eso vive en un filtro: escrita en cada servicio habria
 *       que acordarse de repetirla en cada endpoint nuevo, y el olvido no
 *       daria ningun sintoma. La titularidad, en cambio, si esta en este
 *       metodo, porque depende de la cuenta concreta que se pide.</li>
 *   <li><b>No cachea el mismo, aunque el canal si cachea.</b> La cache del
 *       canal vive en {@link CacheCuentaMovil}, un bean aparte, con el nombre
 *       {@code resumen-movil} y un TTL de 30 s. No esta sobre este metodo por
 *       dos motivos: uno tecnico, que una anotacion en esta misma clase seria
 *       invocada por {@code this} sin pasar por el proxy de Spring y no
 *       cachearia nunca; y otro de fondo, que este metodo comprueba la
 *       titularidad, y en un acierto de cache el cuerpo del metodo no se
 *       ejecuta: el control desapareceria justo cuando la cache funciona.
 *       Tampoco esta sobre el {@link CoreClient}, porque ese cliente lo
 *       comparten los tres canales y el cajero heredaria una cache de saldo
 *       que nadie decidio para el.</li>
 * </ul>
 */
@Service
public class ResumenMovilService {

    /**
     * Tope duro de movimientos del canal, congelado en la seccion 5.10 del
     * contrato: <strong>maximo 5, no configurable</strong>.
     *
     * <p><b>Por que es una constante y no una propiedad del
     * {@code config-repo/bff-mobile.yml}.</b> Porque no es un ajuste, es parte de la forma
     * de la respuesta. Si fuera configurable, un cambio en un archivo de
     * configuracion podria poner 200 movimientos en la respuesta del telefono
     * sin que nadie revisara una linea de codigo, y el canal dejaria de cumplir
     * su contrato sin producir ningun error. Las cosas que el contrato congela
     * se escriben donde se rompe la compilacion al cambiarlas.
     *
     * <p>Este limite es tambien la diferencia visible con el canal web, que si
     * expone {@code page} y {@code size}. El movil no ofrece parametros de
     * paginacion a proposito: el BFF decide por el cliente delgado en lugar de
     * confiar en que el cliente pida poco.
     */
    private static final int MAXIMO_MOVIMIENTOS = 5;

    private final CacheCuentaMovil cacheCuenta;
    private final RespaldoDeLecturas respaldo;

    /**
     * Recibe la cache del canal, que a su vez envuelve el <strong>puerto</strong> hacia
     * el core. Esta clase sigue sin saber que el core habla HTTP, ni en que puerto, ni
     * con que cabecera se autentica, y tampoco necesita saber que hay una cache en medio:
     * {@link CacheCuentaMovil} devuelve exactamente el mismo DTO que devolvia el cliente.
     *
     * <p>Que el colaborador sea un bean <em>distinto</em> de este no es un detalle de
     * organizacion: es la condicion para que la cache exista. Spring implementa
     * {@code @Cacheable} con un proxy que se pone delante del bean, y un proxy solo puede
     * interceptar llamadas que entran desde fuera. Una anotacion puesta en un metodo de
     * esta misma clase, llamado desde otro metodo de esta misma clase, no se interceptaria
     * y la cache no se activaria jamas, sin ningun error que lo delatara.
     */
    public ResumenMovilService(CacheCuentaMovil cacheCuenta, RespaldoDeLecturas respaldo) {
        this.cacheCuenta = cacheCuenta;
        this.respaldo = respaldo;
    }

    /**
     * Arma el resumen M2 de una cuenta.
     *
     * <p>No atrapa ninguna excepcion del core. Las deja subir tal cual hasta
     * {@code ManejadorErroresMovil}, que es el unico lugar del canal que decide
     * codigos HTTP. Un {@code try/catch} aqui que devolviera, por ejemplo, un
     * resumen vacio cuando el core no responde seria mucho peor que un error:
     * el telefono mostraria saldo cero con cara de dato bueno. La unica excepcion
     * (F6) es el respaldo de {@link RespaldoDeLecturas}: ante un core no disponible
     * sirve el ULTIMO resumen REAL que el core entrego (nunca uno fabricado), con
     * menos de 10 minutos, y la respuesta sale marcada como desactualizada
     * (X-Datos-Desactualizados, Warning 110 y Cache-Control no-store). Sin un dato
     * asi, la excepcion sube y el canal responde 503.
     *
     * <h2>La comprobacion de titularidad, y por que es la PRIMERA linea</h2>
     *
     * <p>Es el tercer nivel de autorizacion del proyecto, el del <b>dato</b>.
     * Los otros dos (rol y operacion) los resuelve la cadena de filtros, porque
     * dependen solo de la ruta y de las autoridades. Este no: depende de
     * comparar un claim del token con una variable de la ruta, y eso solo se
     * puede hacer cuando ambas cosas estan a la vista, es decir aqui.
     *
     * <p>Que ocurra <b>antes</b> de llamar al core no es un detalle de estilo,
     * tiene dos consecuencias exigibles:
     *
     * <ol>
     *   <li><b>Pedir una cuenta ajena e inexistente devuelve 403, nunca 404.</b>
     *       Si se consultara primero la existencia, la API responderia 404 para
     *       las cuentas que no existen y 403 para las que si, y esa diferencia
     *       convertiria el endpoint en un detector de cuentas existentes para
     *       cualquiera con un token valido.</li>
     *   <li><b>La peticion rechazada no genera ninguna llamada al core.</b>
     *       Muere en el canal, que ademas es lo correcto en costo.</li>
     * </ol>
     *
     * @param cuentaId          cuenta pedida en la ruta
     * @param cuentaAcreditada  claim {@code cuentaId} del token, o {@code null}
     *                          si el token no acredita ninguna cuenta
     * @return el resumen ya recortado para el canal movil
     * @throws CuentaAjenaException si el token no acredita esa cuenta
     * @throws cl.duoc.bancoxyz.comun.core.CoreException si el core falla, no
     *         encuentra la cuenta o no responde
     */
    public ResumenMovilResponse obtenerResumen(int cuentaId, Integer cuentaAcreditada) {

        // El null se rechaza igual que el valor distinto. Un token sin claim
        // cuentaId no acredita titularidad sobre nada, y tratar la ausencia
        // como "no aplica la regla" seria convertir un token incompleto en una
        // llave maestra. La comparacion se escribe con equals y no con ==:
        // Integer es un objeto, y == compararia referencias, que coinciden por
        // casualidad solo hasta 127 por la cache de enteros pequenos de Java.
        // Los identificadores de cuenta van de 101 a 150, asi que ese error
        // funcionaria en unas cuentas y fallaria en otras.
        if (cuentaAcreditada == null || !cuentaAcreditada.equals(cuentaId)) {
            throw new CuentaAjenaException(cuentaId);
        }

        // La comprobacion de titularidad de arriba corre SIEMPRE; la linea de abajo puede
        // resolverse de memoria sin viajar al core. Ese orden no es negociable: si el
        // control viviera dentro del metodo cacheado, dejaria de aplicarse en los aciertos,
        // que es justo cuando la optimizacion esta haciendo su trabajo.
        //
        // F6: si ademas el core no esta disponible, se sirve el ultimo dato conocido de la cuenta
        // (marcado como desactualizado por AvisoDatosDesactualizados) o, si no hay uno aceptable, 503.
        // La titularidad ya se comprobo arriba, asi que el respaldo nunca decide quien ve una cuenta.
        CuentaCoreDto cuenta = respaldo.leerConRespaldo(CacheCuentaMovil.ESPACIO_RESPALDO, cuentaId,
                () -> cacheCuenta.obtenerCuenta(cuentaId));
        return proyectar(cuenta);
    }

    /**
     * <strong>El recorte.</strong> Aqui se ve, en una pantalla, todo el valor
     * que este BFF agrega: entra la representacion canonica y completa del
     * banco, y sale la forma exacta que dibuja un telefono.
     *
     * <p>De siete campos de cuenta salen cinco; de los 42 movimientos de la
     * cuenta 116 salen 5; de los cinco campos de cada movimiento salen tres; y
     * el nombre del titular sale abreviado. Ningun campo se agrega: un BFF
     * proyecta lo que el core ya sabe, no inventa datos.
     */
    private ResumenMovilResponse proyectar(CuentaCoreDto cuenta) {
        List<MovimientoMovilResponse> ultimos = cuenta.movimientos().stream()
                // El core entrega el historial en su orden canonico, del mas
                // reciente al mas antiguo, y ese orden es un invariante suyo
                // declarado. Por eso "los ultimos cinco" son los cinco
                // primeros de la lista y este canal NO reordena.
                //
                // Reordenar aqui seria ademas peor, no mas seguro: el core
                // desempata las fechas repetidas con el identificador interno
                // del movimiento, que no viaja en el DTO. Un orden por fecha
                // hecho en el BFF no tendria con que desempatar, y dos
                // peticiones iguales podrian devolver dos listas distintas.
                .limit(MAXIMO_MOVIMIENTOS)
                .map(this::proyectarMovimiento)
                .toList();

        return new ResumenMovilResponse(
                cuenta.cuentaId(),
                // La abreviacion del titular es minimizacion de datos
                // personales viajando por una red celular, no un formateo de
                // pantalla. El motivo completo esta en AbreviadorTitular.
                AbreviadorTitular.abreviar(cuenta.titular()),
                cuenta.saldo(),
                cuenta.moneda(),
                ultimos);
        // Lo que queda fuera, dicho explicitamente para que se vea que fue una
        // decision y no un olvido: tipoCuenta (informacion de producto que esta
        // pantalla no dibuja) y edadTitular (dato personal que este canal no
        // necesita para nada de lo que muestra).
    }

    /** Deja pasar tres campos de los cinco del movimiento del core. */
    private MovimientoMovilResponse proyectarMovimiento(MovimientoCoreDto movimiento) {
        return new MovimientoMovilResponse(
                movimiento.fecha(),
                movimiento.tipo(),
                movimiento.monto());
        // descripcion y origen se quedan aqui, en el BFF, y no cruzan la red
        // celular. Son los dos campos mas pesados del movimiento y los dos que
        // menos se leen en un telefono.
    }
}
