package cl.duoc.bancoxyz.bff.mobile.seguridad;

import java.io.IOException;

import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.error.RespuestaError;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Escribe un cuerpo RFC 7807 del canal movil directamente sobre la respuesta
 * HTTP, sin pasar por el {@code @RestControllerAdvice}.
 *
 * <h2>Por que hace falta esta clase, que a primera vista parece un duplicado</h2>
 *
 * <p>Es la nota de implementacion que ahorra una tarde entera. Las tres piezas
 * de seguridad de este paquete ({@link EntryPointTokenMovil},
 * {@link ManejadorAccesoDenegadoMovil} y {@link FiltroDispositivoMovil}) se
 * ejecutan <b>dentro de la cadena de filtros</b>, es decir <b>antes</b> de que
 * la peticion llegue a ningun controlador. El {@code @RestControllerAdvice} de
 * Spring MVC solo entra en accion cuando un controlador lanza una excepcion, de
 * modo que aqui no existe: no hay nadie que convierta un objeto en JSON ni que
 * ponga el {@code Content-Type}.
 *
 * <p>Si no se escribe el cuerpo a mano, los dos escenarios que el criterio de
 * seguridad evalua (el 401 y el 403) devuelven la pagina de error generica del
 * contenedor, que no se parece en nada al resto de la API y que ademas no lleva
 * el campo {@code motivo} que leen los guiones de evidencia.
 *
 * <p>El orden de las tres operaciones importa: <b>primero</b> el estado y el
 * tipo de contenido, <b>despues</b> el cuerpo. Una vez que se empieza a
 * escribir el cuerpo la respuesta se compromete y las cabeceras ya no se pueden
 * cambiar; hacerlo al reves deja un 200 con un cuerpo de error dentro, que es
 * la peor combinacion posible porque ningun cliente lo trata como fallo. Ese
 * orden esta garantizado dentro de {@link EscritorErrorHttp}, que es de la
 * libreria compartida: el mecanismo se comparte, el contenido lo decide el
 * canal.
 */
final class ProblemaMovil {

    /**
     * Valor del campo {@code canal}, congelado en la seccion 5.16 del contrato.
     * Es el mismo literal que usa el manejador de errores de la capa web, y por
     * eso una respuesta de seguridad y una de negocio se ven iguales desde
     * fuera.
     */
    static final String CANAL = "MOVIL";

    static void escribir(EscritorErrorHttp escritor,
                         HttpServletRequest peticion,
                         HttpServletResponse respuesta,
                         int estado,
                         String motivo,
                         String titulo,
                         String detalle) throws IOException {

        // instance se toma de getRequestURI(), que INCLUYE el context-path: el
        // cliente ve "/api/mobile/v1/cuentas/116/resumen", exactamente la ruta
        // que pidio. Un instance sin el prefijo no le sirve para diagnosticar,
        // porque no corresponde a ninguna URL que el conozca.
        respuesta.setHeader("Cache-Control", "no-store");
        escritor.escribir(respuesta, estado,
                RespuestaError.de(estado, motivo, titulo, detalle, peticion.getRequestURI(), CANAL));
    }

    private ProblemaMovil() {
    }
}
