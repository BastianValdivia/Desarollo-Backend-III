package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;

/**
 * Cache de la cuenta para el <strong>canal movil</strong>, con su propio TTL.
 *
 * <p>Es hermana de {@code CacheCuentaWeb}, no la misma clase, y esa duplicacion aparente es el
 * patron funcionando: cada canal decide cuanto tolera que envejezca su dato. Una unica clase
 * compartida en {@code plataforma-comun} obligaria a los tres canales al mismo TTL, que es
 * exactamente el "tratar igual a canales distintos" que el BFF existe para evitar. En el modulo
 * comun va el <strong>mecanismo</strong> (como se llama al core); en cada canal va la
 * <strong>politica</strong> (cuanto dura el dato en memoria).
 *
 * <h2>Por que el TTL del movil es de 30 segundos, MENOS que el de la web</h2>
 *
 * <p>Es lo contrario de lo que dicta la intuicion, y la intuicion aqui esta equivocada por una
 * razon que conviene entender bien.
 *
 * <p><strong>La intuicion.</strong> "El movil es el canal con la red mas cara y mas lenta, luego
 * es el que mas necesita cache." Suena razonable y es falso, porque confunde dos caches
 * distintas.
 *
 * <p><strong>Lo que realmente pasa.</strong> Esta cache vive en el <em>servidor</em>, dentro del
 * proceso del BFF. Lo unico que ahorra es el salto BFF hacia core, que ocurre entre dos procesos
 * de la misma maquina. <strong>No le ahorra al telefono ni un solo byte de datos moviles, ni un
 * solo encendido de radio, ni un milisegundo de su enlace celular</strong>: la peticion del
 * telefono viaja igual, y la respuesta vuelve igual de grande. Quien si le ahorra bytes al
 * telefono es el ETag, que puede convertir la respuesta entera en un 304 vacio, y la proyeccion
 * extrema, que manda 368 bytes donde el core manda 4669. Son otros mecanismos, y estan en otro
 * sitio.
 *
 * <p><strong>Entonces, con que criterio se elige el TTL de una cache de servidor.</strong> Con
 * uno solo: <em>cuanta antiguedad puede tener este numero antes de inducir a error a quien lo
 * lee</em>. Y ahi el movil es MAS exigente que la web, no menos:
 *
 * <ul>
 *   <li>El usuario del canal <strong>web</strong> esta en un navegador revisando historial y
 *       agregados. Es analisis. Un saldo de hace un minuto no le hace tomar ninguna decision
 *       equivocada.</li>
 *   <li>El usuario del canal <strong>movil</strong> abre la aplicacion para mirar cuanto tiene, y
 *       muy a menudo lo hace <em>justo despues de sacar plata de un cajero</em>. Si la aplicacion
 *       le muestra el saldo anterior al retiro durante dos minutos, el usuario cree que el retiro
 *       no ocurrio. Ese es el escenario concreto que fija el numero.</li>
 * </ul>
 *
 * <p>Treinta segundos siguen absorbiendo entera la rafaga tipica del canal, que es la aplicacion
 * refrescando al volver a primer plano y el usuario tirando de la pantalla para recargar dos o
 * tres veces seguidas, y acotan el desconcierto a medio minuto.
 *
 * <p><strong>Limite honesto que conviene tener presente.</strong> Quien mueve el saldo es el
 * cajero, que es otro proceso y otra JVM. Esta cache no se entera de ese retiro: no hay ningun
 * mecanismo que la invalide. En un sistema de varios procesos el TTL <strong>es</strong> el
 * mecanismo de invalidacion, y por eso la unica pregunta que importa al elegirlo es cuanta
 * antiguedad tolera cada canal. El cajero, que es quien entrega los billetes, tolera cero: por
 * eso no tiene cache y ni siquiera tiene la libreria en su classpath.
 */
@Component
public class CacheCuentaMovil {

    /**
     * Nombre de la cache, en una constante porque el mismo texto aparece en el
     * {@code config-repo/bff-mobile.yml} y en las pruebas. Una cache cuyo nombre se escribio distinto en dos
     * sitios no falla: simplemente nunca acierta, que es el peor modo de fallar.
     */
    public static final String NOMBRE_CACHE = "resumen-movil";

    private static final Logger log = LoggerFactory.getLogger(CacheCuentaMovil.class);

    /** Espacio del respaldo (ultimo dato conocido) donde se guarda la cuenta; lo lee {@link ResumenMovilService}. */
    static final String ESPACIO_RESPALDO = "cuenta";

    private final CoreClient core;
    private final RespaldoDeLecturas respaldo;

    public CacheCuentaMovil(CoreClient core, RespaldoDeLecturas respaldo) {
        this.core = core;
        this.respaldo = respaldo;
    }

    /**
     * Trae la cuenta del core, o la sirve de memoria si se pidio hace menos del TTL.
     *
     * <p><strong>No recibe el token ni el dispositivo, y eso es deliberado.</strong> En un acierto
     * de cache el cuerpo de este metodo no se ejecuta, asi que cualquier comprobacion escrita aqui
     * dejaria de aplicarse precisamente cuando la cache funciona. Las dos comprobaciones del canal
     * (que la cuenta sea la del token, y que el {@code X-Device-Id} coincida con el del token)
     * viven fuera, en {@link ResumenMovilService} y en el filtro de dispositivo, donde se ejecutan
     * en todas las peticiones sin excepcion.
     *
     * <p>La regla general, que vale para cualquier {@code @Cacheable} que se escriba en la vida:
     * <strong>cachear un metodo es no ejecutar su cuerpo</strong>. Lo que se cachea es el dato, no
     * la decision de si quien pregunta tiene derecho a verlo.
     */
    @Cacheable(cacheNames = NOMBRE_CACHE, key = "#cuentaId")
    public CuentaCoreDto obtenerCuenta(int cuentaId) {
        log.debug("FALLO DE CACHE para la cuenta {}: se viaja al core", cuentaId);
        CuentaCoreDto cuenta = core.obtenerCuenta(cuentaId);
        // F6: el dato recien traido del core queda tambien como "ultimo dato conocido". Se guarda AQUI,
        // en el unico punto que viaja al core, y no en cada acierto de cache: asi la antiguedad que se
        // informa si el core cae es la real y no la del ultimo acierto.
        respaldo.respaldar(ESPACIO_RESPALDO, cuentaId, cuenta);
        return cuenta;
    }
}
