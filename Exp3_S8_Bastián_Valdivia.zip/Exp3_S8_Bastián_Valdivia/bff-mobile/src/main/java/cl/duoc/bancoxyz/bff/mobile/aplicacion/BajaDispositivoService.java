package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.bff.mobile.api.dto.BajaDispositivoResponse;

/**
 * La operacion exclusiva del canal movil (M3): dar de baja el dispositivo desde
 * el que se esta operando.
 *
 * <h2>Por que el dispositivo se toma del token y no del cuerpo de la peticion</h2>
 *
 * <p>Es la decision de diseno de este endpoint y conviene entender la
 * alternativa para ver por que se descarta. Si el identificador viniera en el
 * cuerpo, cualquier sesion valida podria dar de baja el telefono de otra
 * persona escribiendo su identificador: haria falta una regla de autorizacion
 * adicional que comprobara la propiedad de ese dispositivo, es decir mas
 * superficie y mas cosas que pueden quedar mal.
 *
 * <p>Tomandolo del claim {@code device_id}, la operacion solo puede
 * ejercerse sobre el aparato desde el que se pidio, y esa garantia no depende
 * de ninguna regla nueva: la da la firma del token, mas la comprobacion de que
 * la cabecera {@code X-Device-Id} coincide con el claim. Un dispositivo puede
 * darse de baja a si mismo y a ninguno mas. La ausencia de cuerpo en la
 * peticion no es una simplificacion: es el resultado de haber movido la
 * autoridad al lugar correcto.
 *
 * <h2>Que hace la baja con los tokens que el dispositivo ya tenia</h2>
 *
 * <p>Un JWT es autocontenido: se valida comprobando su firma, sin preguntarle nada a nadie, y por eso el
 * {@code auth-server} no puede "apagar" un token ya emitido antes de que expire. Lo que SI puede hacer este
 * canal es negarse a servirlo: en cada peticion, {@code FiltroDispositivoMovil} consulta el
 * {@link RegistroDispositivos} (un acceso a un mapa en memoria) y rechaza con 401 {@code dispositivo_no_coincide}
 * un token cuyo dispositivo figura dado de baja. La baja, entonces, corta la sesion en curso de ESE telefono
 * (la unica ruta que sigue aceptando su token es esta misma baja, para que repetirla sea idempotente), y el
 * telefono puede volver a iniciar sesion en el auth-server pero su token nuevo tampoco servira mientras el
 * registro lo recuerde.
 *
 * <p>Esto es mas estricto que en el S5, donde la baja solo impedia EMITIR tokens nuevos porque el login era de
 * este canal; desde F5 el login es del auth-server, que no conoce este registro, y la unica forma de aplicar la
 * baja es en cada peticion.
 *
 * <p>La contrapartida es que la demostracion de la baja gasta el dispositivo: tras darlo de baja, todo lo que se
 * pida con ese {@code device_id} responde 401 hasta reiniciar el BFF (el registro vive en memoria, ver
 * {@link RegistroDispositivos}). Por eso los guiones de verificacion usan un dispositivo sacrificable
 * ({@code dispositivo-baja-01}) y no el de la demostracion, igual que el bloqueo por PIN del cajero se prueba
 * sobre una tarjeta sacrificable.
  */
@Service
public class BajaDispositivoService {

    private static final Logger log = LoggerFactory.getLogger(BajaDispositivoService.class);

    private final RegistroDispositivos registro;
    private final Clock reloj;

    public BajaDispositivoService(RegistroDispositivos registro, Clock reloj) {
        this.registro = registro;
        this.reloj = reloj;
    }

    /**
     * Da de baja el dispositivo de la sesion actual.
     *
     * @param dispositivoId identificador tomado del claim del token
     * @return los tres campos congelados en la seccion 5.11 del contrato
     */
    public BajaDispositivoResponse darDeBaja(String dispositivoId) {

        // Truncado a segundos para que la respuesta tenga la forma exacta del
        // contrato (2026-09-11T03:18:43Z). Sin esto Jackson imprimiria los
        // milisegundos y la evidencia dejaria de parecerse al ejemplo
        // congelado, que es la clase de diferencia que hace dudar de si el
        // formato es el pactado.
        Instant ahora = reloj.instant().truncatedTo(ChronoUnit.SECONDS);
        Instant dadoDeBajaEn = registro.darDeBaja(dispositivoId, ahora);

        // El identificador de dispositivo SI se registra aqui, a diferencia de
        // lo que hace el filtro de vinculacion. Es la diferencia entre un
        // evento de seguridad rutinario y un hecho que cambia el estado del
        // canal: de este ultimo tiene que quedar rastro para poder responder
        // "cuando se dio de baja este aparato".
        log.info("Dispositivo dado de baja en el canal movil. dispositivoId={}, en={}",
                dispositivoId, dadoDeBajaEn);

        return new BajaDispositivoResponse(
                dispositivoId,
                BajaDispositivoResponse.ESTADO_DADO_DE_BAJA,
                dadoDeBajaEn);
    }
}
