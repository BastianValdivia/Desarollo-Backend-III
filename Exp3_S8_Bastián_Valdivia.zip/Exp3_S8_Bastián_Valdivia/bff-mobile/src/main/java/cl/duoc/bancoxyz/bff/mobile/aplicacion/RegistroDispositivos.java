package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

/**
 * Anota que dispositivos fueron dados de baja, y cuando.
 *
 * <h2>Estado local por instancia, declarado sin disimulo</h2>
 *
 * <p>Este mapa vive en la memoria de <b>este</b> proceso. Si manana el canal
 * corriera en dos instancias detras de un balanceador, cada una tendria su
 * propio registro y una baja hecha contra la primera seria invisible para la
 * segunda. Por eso el proyecto no afirma que sus BFF sean "sin estado y
 * replicables" a secas: la <em>autenticacion</em> si es sin estado (el token es
 * autocontenido y no hay {@code HttpSession}), y este registro es un control
 * auxiliar del canal que habria que mover a un almacen compartido antes de
 * replicar. Decirlo es mas util que esconderlo detras de una afirmacion
 * generica que la primera replica desmentiria.
 *
 * <p>Se usa {@link ConcurrentHashMap} y no un {@code HashMap} porque Tomcat
 * atiende cada peticion en un hilo distinto: dos bajas simultaneas sobre un
 * mapa normal pueden corromper su estructura interna, y ese fallo no aparece en
 * pruebas de un solo hilo. {@code putIfAbsent} resuelve ademas la carrera
 * completa en una sola operacion atomica, sin necesidad de sincronizar nada a
 * mano.
 */
@Component
public class RegistroDispositivos {

    private final Map<String, Instant> bajas = new ConcurrentHashMap<>();

    /**
     * Registra la baja de un dispositivo, o devuelve la que ya existia.
     *
     * <p><b>Es idempotente a proposito.</b> Repetir la peticion devuelve el
     * mismo instante que la primera vez, no uno nuevo. Eso importa por una
     * razon muy concreta: un telefono con mala cobertura reintenta, y un guion
     * de evidencia se ejecuta dos veces seguidas. En ambos casos la segunda
     * llamada tiene que dar exactamente la misma respuesta que la primera; si
     * cada intento sobrescribiera la fecha, la evidencia dejaria de ser
     * reproducible y el cliente no podria distinguir "ya estaba de baja" de
     * "se dio de baja ahora".
     *
     * @param dispositivoId identificador tomado del token, nunca del cuerpo
     * @param ahora         instante propuesto para la primera baja
     * @return el instante en que ese dispositivo quedo dado de baja
     */
    public Instant darDeBaja(String dispositivoId, Instant ahora) {
        Instant previo = bajas.putIfAbsent(dispositivoId, ahora);
        return previo == null ? ahora : previo;
    }

    /**
     * Responde si un dispositivo figura como dado de baja.
     *
     * <p>La consulta {@code AutenticacionMovilService} en el LOGIN, para que un
     * dispositivo dado de baja no pueda obtener un token nuevo.
     *
     * <p>Deliberadamente NO se consulta en cada peticion: ver la explicacion
     * sobre la revocacion de tokens en {@link BajaDispositivoService}. La baja
     * no revoca los tokens ya emitidos, corta la emision de los siguientes.
     */
    public boolean estaDadoDeBaja(String dispositivoId) {
        return bajas.containsKey(dispositivoId);
    }

    /**
     * Vacia el registro de bajas.
     *
     * <p><b>Existe solo para aislar las pruebas, y conviene decir por que.</b>
     * Este registro es un bean unico compartido por todo el contexto, de modo
     * que una prueba que da de baja un dispositivo se lo deja dado de baja a
     * todas las que se ejecuten despues. Mientras la baja no se consultaba en
     * ninguna parte, esa contaminacion era invisible; en cuanto el login empezo
     * a mirarla, media suite fallo con {@code dispositivo_no_coincide} sin que
     * nada estuviera mal en el codigo de produccion.
     *
     * <p>Es un caso que vale la pena reconocer: la prueba dependia del orden de
     * ejecucion desde el primer dia, y solo un cambio ajeno lo revelo. Una suite
     * en verde tampoco demuestra que sus pruebas sean independientes entre si.
     *
     * <p>En produccion nadie la llama. Si algun dia hiciera falta reactivar un
     * dispositivo, eso seria una operacion de negocio con su propia ruta, su
     * autorizacion y su registro de auditoria, no este metodo.
     */
    public void limpiar() {
        bajas.clear();
    }
}
