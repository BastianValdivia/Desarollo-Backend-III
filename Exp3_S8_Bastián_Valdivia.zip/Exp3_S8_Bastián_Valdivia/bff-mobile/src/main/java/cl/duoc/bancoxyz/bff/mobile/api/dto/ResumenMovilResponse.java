package cl.duoc.bancoxyz.bff.mobile.api.dto;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Respuesta del endpoint M2, {@code GET /v1/cuentas/{id}/resumen}: la unica
 * pantalla de datos del canal movil, congelada en la seccion 5.10 del
 * contrato.
 *
 * <h2>Rol en la arquitectura</h2>
 *
 * <p>Este record ES el recorte. Puesto al lado del DTO que devuelve el core se
 * ve de un vistazo cuanto trabajo hace un BFF:
 *
 * <table border="1">
 *   <caption>Cuenta 116 en el core y en el movil</caption>
 *   <tr><th></th><th>core (C2)</th><th>movil (M2)</th></tr>
 *   <tr><td>campos de la cuenta</td><td>7</td><td>5</td></tr>
 *   <tr><td>movimientos</td><td>los 42</td><td>los 5 mas recientes</td></tr>
 *   <tr><td>campos por movimiento</td><td>5</td><td>3</td></tr>
 * </table>
 *
 * <p>Los dos campos de cuenta que no estan son {@code tipoCuenta} y
 * {@code edadTitular}. {@code tipoCuenta} es informacion de producto que la
 * pantalla de saldo del telefono no muestra, y {@code edadTitular} es un dato
 * personal que este canal no tiene ninguna razon para conocer: el telefono
 * dibuja saldo y movimientos, y la edad no participa en ninguno de los dos.
 *
 * <h2>Por que {@code titular} viaja abreviado</h2>
 *
 * <p>{@code Diana Prince} se proyecta como {@code D. Prince}, y eso
 * <strong>no es cosmetica</strong>: es minimizacion de datos personales
 * viajando por una red celular. El nombre completo del titular es un dato
 * identificatorio y este canal lo mueve por el enlace de radio de un telefono,
 * el mas expuesto de los tres. La pantalla solo necesita que el usuario
 * reconozca que la cuenta es suya, y para eso la inicial y el apellido bastan.
 * Se manda lo minimo que cumple la funcion, no lo maximo que se tiene a mano.
 * La regla completa esta en
 * {@code cl.duoc.bancoxyz.bff.mobile.aplicacion.AbreviadorTitular}.
 *
 * <h2>Por que {@code NON_NULL}</h2>
 *
 * <p>Si algun campo llegara nulo, desaparece del JSON en lugar de ocupar sitio
 * como {@code "campo": null}. En un canal que cuenta bytes, un campo nulo es
 * peso sin informacion. No afecta a {@code ultimosMovimientos}, que el
 * constructor compacto garantiza no nulo: el contrato exige {@code []} y nunca
 * {@code null} para una cuenta sin movimientos, y un arreglo vacio si dice
 * algo ("no hay ninguno"), mientras que un campo ausente obligaria al telefono
 * a adivinar.
 *
 * @param cuentaId           identificador de la cuenta, para que el cliente pueda
 *                           verificar que la respuesta es la que pidio
 * @param titular            nombre <strong>abreviado</strong>, nunca el completo
 * @param saldo              saldo actual, numero JSON
 * @param moneda             literal {@code CLP}
 * @param ultimosMovimientos como maximo cinco elementos, del mas reciente al mas
 *                           antiguo. Vacio, nunca nulo
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ResumenMovilResponse(
        int cuentaId,
        String titular,
        BigDecimal saldo,
        String moneda,
        List<MovimientoMovilResponse> ultimosMovimientos) {

    /**
     * Constructor compacto que blinda las dos promesas del contrato sobre la
     * lista: que nunca es nula y que nadie la puede modificar despues.
     *
     * <p>La primera evita el caso borde de la cuenta 130, que tiene cero
     * movimientos: sin esta linea, un {@code null} se serializaria como campo
     * ausente por culpa de {@code NON_NULL} y el telefono recibiria una
     * respuesta distinta en forma segun cuantos movimientos hubiera. Una forma
     * que cambia es una forma que el cliente tiene que programar dos veces.
     *
     * <p>La segunda ({@link List#copyOf}) hace inmutable la respuesta ya
     * construida. Un record protege sus referencias, no lo que hay al otro
     * lado de ellas: sin la copia, quien tuviera la lista original podria
     * seguir agregandole elementos despues de armado el objeto.
     */
    public ResumenMovilResponse {
        ultimosMovimientos = ultimosMovimientos == null
                ? List.of()
                : List.copyOf(ultimosMovimientos);
    }
}
