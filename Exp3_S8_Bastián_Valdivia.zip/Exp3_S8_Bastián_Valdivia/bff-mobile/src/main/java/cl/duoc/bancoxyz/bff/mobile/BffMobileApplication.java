package cl.duoc.bancoxyz.bff.mobile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.cache.annotation.EnableCaching;

/**
 * Punto de entrada del <strong>bff-mobile</strong>, el Backend for Frontend del canal movil.
 *
 * <p>Escucha en el puerto 8444 bajo el context-path {@code /api/mobile}. Su cliente es una
 * aplicacion de telefono: pantalla chica, red que puede ser lenta y cara, y un dispositivo
 * personal que se puede perder o robar.
 *
 * <p>Su papel en la arquitectura es el mismo que el de sus dos hermanos (traducir el modelo
 * generico del {@code core-service} a la forma que su cliente necesita), pero las decisiones que
 * toma son distintas, y ahi esta el valor del patron:
 *
 * <ul>
 *   <li>Proyecta de forma agresiva: saldo mas los 5 ultimos movimientos con 3 campos cada uno,
 *       en lugar de la cuenta completa.</li>
 *   <li>No expone parametros de paginacion. Es una decision de canal, no una funcionalidad
 *       faltante: el BFF decide por el cliente delgado en vez de confiar en que el cliente pida
 *       poco.</li>
 *   <li>El token queda amarrado al identificador de dispositivo, asi que robar el token no basta
 *       para usarlo desde otro telefono.</li>
 * </ul>
 *
 * <p>No comparte DTO de respuesta con {@code bff-web} ni con {@code bff-atm}, y no depende de
 * ninguno de los dos. Esa independencia es lo que permite cambiar la vista del movil sin tocar
 * ni arriesgar los otros canales.
 *
 * <p>Esta clase no contiene logica: en Spring Boot la clase principal es solo el disparador.
 */
@SpringBootApplication(
        /*
         * Sin esta enumeracion, el escaneo por defecto cubriria solo cl.duoc.bancoxyz.bff.mobile
         * y los beans de la libreria compartida no existirian. Ver la explicacion extendida en
         * BffWebApplication: se prefiere esta linea visible antes que el mecanismo de
         * auto-configuracion, que falla en silencio cuando algo no calza.
         */
        scanBasePackages = {"cl.duoc.bancoxyz.bff.mobile", "cl.duoc.bancoxyz.comun"}
)
/*
 * @SpringBootApplication escanea componentes pero no propiedades. Sin esta anotacion, una clase
 * @ConfigurationProperties no se registra como bean y el arranque muere con un mensaje que no
 * apunta a la causa. Se declara desde el primer dia en los cuatro modulos ejecutables.
 */
// Se escanea SOLO cl.duoc.bancoxyz.comun.core, no el paquete comun completo: es el unico paquete de la
// libreria compartida que declara propiedades (la direccion y los tiempos del cliente del core). Escanear
// mas obligaria a cada BFF a declarar un bloque de configuracion que quiza no necesita, y un bloque ausente
// fallaria al arrancar con un mensaje que no apunta a la causa. Desde F5 ningun BFF emite tokens, asi que
// la libreria ya no trae politica de token que declarar: solo valida (ver ConfianzaEnElAuthServerConfig).
@ConfigurationPropertiesScan({"cl.duoc.bancoxyz.bff.mobile", "cl.duoc.bancoxyz.comun.core"})
/*
 * @EnableCaching (Etapa 7) enciende el MECANISMO de cache: el contenedor envuelve en un proxy a
 * todo bean con un metodo @Cacheable y consulta la cache antes de dejar pasar la llamada.
 *
 * Lo que hay que saber de esta anotacion es que sin ella NO HAY ERROR. Un @Cacheable en un
 * proyecto sin @EnableCaching compila, arranca y funciona: simplemente no cachea nunca, sin
 * excepcion, sin aviso en el log y sin nada visible. El unico sintoma es que el ahorro esperado
 * no aparece, y eso se atribuye con facilidad a cualquier otra cosa. Por eso la prueba de este
 * canal comprueba el EFECTO (el core recibe una sola llamada) y no la presencia de la anotacion.
 *
 * No existe en BffAtmApplication, y no es un olvido: es lo que mantiene inerte cualquier
 * @Cacheable que alguien escribiera por error en aquel canal. El motivo esta en bff-atm/pom.xml y
 * se resume en que un saldo cacheado, en una maquina que entrega billetes, es dinero entregado dos
 * veces. Alli la regla no se confia a esta ausencia, que seria silenciosa, sino a una prueba de
 * arquitectura que falla si aparece cualquier anotacion de cache.
 */
@EnableCaching
public class BffMobileApplication {

    public static void main(String[] args) {
        SpringApplication.run(BffMobileApplication.class, args);
    }
}
