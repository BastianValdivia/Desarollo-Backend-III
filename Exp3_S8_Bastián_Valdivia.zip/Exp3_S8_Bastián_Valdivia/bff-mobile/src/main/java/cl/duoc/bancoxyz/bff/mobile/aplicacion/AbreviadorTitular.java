package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import java.util.Locale;

/**
 * Convierte el nombre completo del titular en su forma abreviada del canal
 * movil: {@code Diana Prince} pasa a {@code D. Prince}.
 *
 * <h2>Por que esto merece una clase propia y no tres lineas dentro del
 * servicio</h2>
 *
 * <p>Porque no es formateo, es una <strong>decision de proteccion de
 * datos</strong>, y las decisiones se leen mejor cuando tienen nombre. La
 * abreviacion no se hace para que el nombre quepa en la pantalla: se hace
 * porque el nombre completo del titular es un dato personal identificatorio y
 * este es el canal que lo transporta por el enlace de radio de un telefono,
 * que es el trayecto menos controlado de los tres. El principio que se aplica
 * es el de <em>minimizacion</em>: se envia el minimo dato que cumple la
 * funcion, no el maximo dato que se tiene a mano.
 *
 * <p>La funcion, en esta pantalla concreta, es que el usuario reconozca que la
 * cuenta que esta mirando es la suya. {@code D. Prince} lo logra igual de bien
 * que {@code Diana Prince}, y ante la interceptacion de una sola respuesta
 * entrega bastante menos.
 *
 * <p>Notese donde NO esta esta clase: no esta en {@code plataforma-comun}. El
 * canal web muestra el nombre completo a proposito, porque un ejecutivo en un
 * computador de sucursal necesita identificar sin ambiguedad a la persona.
 * Compartir esta regla impondria la politica del movil a los tres canales, que
 * es justo lo que el modulo compartido tiene prohibido hacer.
 *
 * <h2>Por que es una clase de metodos estaticos y no un bean</h2>
 *
 * <p>No tiene estado, no depende de nada y su resultado depende solo de su
 * entrada. Convertirla en {@code @Component} agregaria una inyeccion, un proxy
 * y un motivo mas de fallo en el arranque, sin ganar nada: no hay ninguna
 * implementacion alternativa que alguien quisiera sustituir.
 */
public final class AbreviadorTitular {

    /**
     * Abrevia el nombre para el canal movil.
     *
     * <p><b>La regla.</b> Inicial de la primera palabra, punto, espacio, y el
     * resto del nombre tal cual.
     *
     * <p><b>Por que se conserva TODO el resto y no solo la ultima palabra.</b>
     * Es la decision fina de este metodo. Recortar a la ultima palabra
     * ahorraria algunos bytes mas en un nombre como {@code Ana Perez Soto},
     * pero para hacerlo habria que saber cual de las palabras del medio es el
     * apellido, y eso depende de una convencion de nombres que el dataset no
     * declara: en {@code Juan Pablo Soto}, {@code Pablo} es un segundo nombre,
     * y en {@code Ana Perez Soto}, {@code Perez} es el apellido paterno.
     * Adivinar mal no produce un nombre mas corto: produce el nombre de otra
     * persona. La minimizacion de datos no puede convertirse en corrupcion de
     * datos, asi que solo se abrevia aquello de lo que hay certeza, que es que
     * la primera palabra es el nombre de pila.
     *
     * <p><b>Casos borde, y por que devuelven la entrada en vez de fallar.</b>
     * Un nombre nulo, en blanco o de una sola palabra no se puede abreviar
     * segun la regla anterior. Este metodo no lanza excepcion en esos casos:
     * un titular raro no es motivo para negarle el saldo a un cliente que
     * abrio su aplicacion. Devuelve lo que recibio y deja que el resto de la
     * respuesta siga su curso. Con una sola palabra, ademas, abreviar seria
     * absurdo: {@code Madonna} quedaria como {@code M.}, que no identifica
     * nada y por lo tanto ya no cumple la funcion que justificaba el recorte.
     *
     * @param nombreCompleto nombre tal como lo entrega el core, por ejemplo
     *                       {@code Diana Prince}
     * @return el nombre abreviado, por ejemplo {@code D. Prince}
     */
    public static String abreviar(String nombreCompleto) {
        if (nombreCompleto == null || nombreCompleto.isBlank()) {
            return nombreCompleto;
        }

        // El limite 2 es intencional: parte en la PRIMERA separacion y deja el
        // resto entero. Con split(" ") sin limite habria que volver a unir las
        // palabras restantes, y esa reunion es donde se pierden los espacios
        // dobles y los nombres compuestos.
        String[] partes = nombreCompleto.strip().split("\\s+", 2);
        if (partes.length < 2) {
            return partes[0];
        }

        // Locale.ROOT y no el del sistema: con el locale turco, "i" en
        // mayuscula no es "I" sino "I" con punto, y el mismo nombre se
        // abreviaria distinto segun la maquina donde corra el BFF. Una
        // respuesta que cambia con la configuracion regional del servidor es
        // un error que no aparece nunca en la maquina del que programa.
        String inicial = partes[0].substring(0, 1).toUpperCase(Locale.ROOT);
        return inicial + ". " + partes[1];
    }

    /** Contenedor de una regla sin estado: no tiene sentido instanciarlo. */
    private AbreviadorTitular() {
    }
}
