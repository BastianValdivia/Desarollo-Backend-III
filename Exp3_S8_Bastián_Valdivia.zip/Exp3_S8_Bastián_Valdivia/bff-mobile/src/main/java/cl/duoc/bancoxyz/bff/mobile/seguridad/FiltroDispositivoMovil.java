package cl.duoc.bancoxyz.bff.mobile.seguridad;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.filter.OncePerRequestFilter;

import cl.duoc.bancoxyz.bff.mobile.aplicacion.RegistroDispositivos;
import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.error.MotivosError;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * La regla propia del canal movil: el token solo vale desde el telefono al que
 * se emitio.
 *
 * <p>Compara, en <b>cada</b> peticion autenticada, el claim
 * {@code device_id} del token (que escribe el auth-server con el dispositivo que
 * la app declaro al iniciar sesion) con la cabecera {@code X-Device-Id} que trae
 * la peticion. Si no coinciden, o si la cabecera no llego, responde
 * <strong>401 {@code dispositivo_no_coincide}</strong> y la peticion no avanza.
 * El motivo, y el hecho de que la cabecera ausente cuente como no coincidente,
 * estan congelados en la seccion 7.4 del contrato.
 *
 * <h2>La baja de un dispositivo se aplica aqui, en cada peticion</h2>
 *
 * <p>En el S5 este canal emitia sus tokens y por eso podia negarse a emitir uno
 * para un dispositivo dado de baja (el login lo comprobaba). Desde F5 el login
 * es del auth-server, que no conoce ese registro, asi que la baja se aplica del
 * unico modo posible: en cada peticion, un token cuyo dispositivo figura dado de
 * baja se rechaza con el mismo 401 {@code dispositivo_no_coincide} (no hay
 * dispositivo acreditado). Es mas estricto que antes: la baja corta tambien los
 * tokens que el telefono ya tenia, no solo los nuevos. La unica ruta que sigue
 * aceptando ese token es la propia baja, para que repetirla siga siendo
 * idempotente.
 *
 * <h2>Por que es un filtro y no una comprobacion dentro de cada servicio</h2>
 *
 * <p>Porque es una regla del canal completo, no de una operacion. Escrita en el
 * servicio habria que repetirla en cada endpoint nuevo, y el dia que alguien
 * agregue el tercero y se olvide, el agujero no producira ningun sintoma: ese
 * endpoint funcionara perfectamente, solo que tambien desde un telefono ajeno.
 * Las reglas de seguridad que fallan en silencio son las que salen mas caras,
 * asi que esta se escribe una vez en el camino por el que pasa todo.
 *
 * <h2>Donde se inserta, y por que exactamente ahi</h2>
 *
 * <p>Va <b>despues</b> del filtro que valida el token y <b>antes</b> del que
 * aplica las reglas de autorizacion. Ese orden reproduce el de la seccion 7.4
 * del contrato: autenticacion, autoridad, titularidad. Cuando este filtro se
 * ejecuta, el token ya fue verificado (firma, vigencia y audiencia), asi que
 * comparar su claim contra la cabecera tiene sentido; y como todavia no se
 * evaluaron las autoridades, un token de otro telefono muere con
 * <b>401</b> y no con el 403 que le habria tocado por permisos. Es la
 * diferencia entre "no se quien eres" y "se quien eres y no puedes", que es el
 * esqueleto conceptual completo de esta etapa.
 *
 * <h2>Dos detalles de implementacion que no son obvios</h2>
 *
 * <ul>
 *   <li><b>Solo actua si hay un token.</b> La salud es una ruta publica: ahi
 *       la autenticacion es anonima, no hay claim con el que comparar y el
 *       filtro se aparta. Si exigiera la cabecera tambien en ella,
 *       {@code /actuator/health} dejaria de responder a un guion de
 *       arranque.</li>
 *   <li><b>La comparacion es un {@code equals} normal, no en tiempo
 *       constante.</b> Deliberado: el identificador de dispositivo no es un
 *       secreto (viaja en claro en cada peticion y el propio cliente lo
 *       eligio), asi que no hay nada que un ataque por diferencias de tiempo
 *       pueda descubrir aqui. La comparacion en tiempo constante se reserva
 *       para lo que si es secreto, como el secreto de un cliente OAuth2.
 *       Usarla en todas partes "por si acaso" es ruido que hace mas dificil
 *       ver donde hacia falta de verdad.</li>
 * </ul>
 */
public class FiltroDispositivoMovil extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(FiltroDispositivoMovil.class);

    /** Ruta de la baja de dispositivo: la unica que acepta el token de un dispositivo ya dado de baja. */
    private static final String RUTA_DE_BAJA = "/v1/dispositivos/baja";

    private final EscritorErrorHttp escritor;
    private final RegistroDispositivos registro;

    public FiltroDispositivoMovil(EscritorErrorHttp escritor, RegistroDispositivos registro) {
        this.escritor = escritor;
        this.registro = registro;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest peticion,
                                    HttpServletResponse respuesta,
                                    FilterChain cadena) throws ServletException, IOException {

        Authentication autenticacion = SecurityContextHolder.getContext().getAuthentication();

        // Sin token no hay vinculo que comprobar. Quien deba traerlo y no lo
        // traiga sera rechazado un filtro mas adelante, por la regla de
        // autorizacion, con 401 token_ausente.
        if (!(autenticacion instanceof JwtAuthenticationToken tokenAutenticado)) {
            cadena.doFilter(peticion, respuesta);
            return;
        }

        String delToken = VinculacionDispositivo.delToken(tokenAutenticado.getToken());
        String deLaPeticion = peticion.getHeader(VinculacionDispositivo.CABECERA);

        if (delToken != null && delToken.equals(deLaPeticion)) {
            if (registro.estaDadoDeBaja(delToken) && !esLaBaja(peticion)) {
                // Mismo motivo que el dispositivo ajeno: para el canal, un dispositivo dado de baja ya no esta
                // acreditado. El log no escribe el identificador (dato personal), solo el hecho.
                log.warn("Peticion rechazada: el dispositivo del token figura dado de baja. Sujeto={}",
                        tokenAutenticado.getName());
                rechazar(peticion, respuesta, "El dispositivo fue dado de baja");
                return;
            }
            cadena.doFilter(peticion, respuesta);
            return;
        }

        // Se registra el hecho, no los valores: el identificador de dispositivo
        // es un dato que identifica a una persona a lo largo del tiempo, y un
        // log es el sitio donde ese dato sobrevive mas tiempo y con menos
        // control. Para diagnosticar basta saber que sujeto fallo la
        // vinculacion y si la cabecera venia o no venia.
        log.warn("Peticion rechazada por vinculacion de dispositivo. Sujeto={}, cabecera {} presente={}",
                tokenAutenticado.getName(), VinculacionDispositivo.CABECERA, deLaPeticion != null);

        rechazar(peticion, respuesta,
                // El detail no repite el identificador esperado: seria decirle
                // a quien presento un token robado que valor tiene que falsear
                // para que la proxima vez funcione.
                "El token no corresponde a este dispositivo");
    }

    private static boolean esLaBaja(HttpServletRequest peticion) {
        return "POST".equals(peticion.getMethod()) && peticion.getRequestURI().endsWith(RUTA_DE_BAJA);
    }

    private void rechazar(HttpServletRequest peticion, HttpServletResponse respuesta, String detalle)
            throws IOException {
        // La cabecera WWW-Authenticate acompana a TODA respuesta 401 de este
        // proyecto: es la que le dice al cliente con que esquema deberia
        // identificarse. Ninguna 403 la lleva, porque a quien ya esta
        // identificado no se le pide repetir un login que no cambiaria nada.
        respuesta.setHeader(HttpHeaders.WWW_AUTHENTICATE, "Bearer");

        ProblemaMovil.escribir(escritor, peticion, respuesta,
                HttpStatus.UNAUTHORIZED.value(),
                MotivosError.DISPOSITIVO_NO_COINCIDE,
                "Sesion no valida",
                detalle);
    }
}
