package cl.duoc.bancoxyz.bff.mobile.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Un movimiento tal como lo ve el canal movil: <strong>tres campos y nada
 * mas</strong>.
 *
 * <p><b>Rol en la arquitectura.</b> Es la mitad mas pequena del recorte que
 * hace este BFF, y la que mas bytes ahorra, porque se multiplica por cinco en
 * cada respuesta. El movimiento del core
 * ({@code cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto}) trae cinco
 * campos; este trae tres. Los dos que faltan no se olvidaron:
 *
 * <ul>
 *   <li><b>{@code descripcion} se descarta.</b> Es el campo mas pesado de los
 *       cinco: texto libre del CSV legado, de largo variable y sin tope. En una
 *       lista de cinco filas de un telefono no cabe, asi que hoy viajaria para
 *       no dibujarse nunca. Peor todavia, el contrato advierte que puede
 *       contradecir al tipo (una fila marcada {@code RETIRO} con descripcion
 *       "Deposito mensual"): mandarla a una pantalla chica, donde no hay
 *       espacio para explicar cual de los dos manda, invita a que el usuario
 *       lea lo que no es.</li>
 *   <li><b>{@code origen} se descarta.</b> Distingue un movimiento sembrado
 *       del CSV de uno generado por un retiro en cajero. Es informacion de
 *       trazabilidad interna del banco: util para auditoria, irrelevante para
 *       quien mira su telefono en la micro.</li>
 * </ul>
 *
 * <p><b>Sobre el signo del monto.</b> Llega siempre positivo desde el core y
 * asi se reenvia. La direccion del dinero vive en {@code tipo}. Este canal no
 * la reinterpreta: si lo hiciera, el mismo movimiento se veria distinto en el
 * telefono y en el navegador, y el usuario no tendria forma de saber cual de
 * las dos pantallas mentia.
 *
 * @param fecha dia del movimiento, serializado como {@code yyyy-MM-dd} segun la
 *              seccion 5.1 del contrato
 * @param tipo  {@code DEPOSITO}, {@code RETIRO}, {@code COMPRA} o {@code PAGO},
 *              en mayusculas
 * @param monto importe siempre positivo, serializado como numero JSON y nunca
 *              como texto
 */
public record MovimientoMovilResponse(
        LocalDate fecha,
        String tipo,
        BigDecimal monto) {
}
