package cl.duoc.bancoxyz.bff.mobile.api.dto;

import java.time.Instant;

/**
 * Respuesta de la baja de dispositivo (M3), el endpoint exclusivo del canal
 * movil. Sus tres campos estan congelados en la seccion 5.11 del contrato.
 *
 * <p>Ningun otro canal tiene esta operacion, y esa es exactamente su funcion en
 * el proyecto: la misma ruta contra el puerto del canal web o del cajero
 * responde 404, que es la prueba de que los tres BFF no son intercambiables.
 * Que la operacion exista solo aqui no es un capricho de reparto, es una
 * consecuencia del canal: el dispositivo es un concepto que solo existe donde
 * hay un aparato personal al que atar la sesion.
 *
 * @param dispositivoId el identificador dado de baja
 * @param estado        valor literal {@code DADO_DE_BAJA}
 * @param dadoDeBajaEn  instante ISO-8601 en UTC. Se trunca a segundos para
 *                      coincidir con el formato congelado en la seccion 5.1:
 *                      Jackson imprimiria los milisegundos si estuvieran, y la
 *                      evidencia dejaria de parecerse al ejemplo del contrato
 */
public record BajaDispositivoResponse(String dispositivoId, String estado, Instant dadoDeBajaEn) {

    /** Unico valor posible de {@code estado}, congelado en el contrato. */
    public static final String ESTADO_DADO_DE_BAJA = "DADO_DE_BAJA";
}
