package cl.duoc.bancoxyz.bff.mobile.seguridad;

import org.springframework.security.oauth2.jwt.Jwt;

import cl.duoc.bancoxyz.comun.token.ClaimsToken;

/**
 * Los dos nombres, congelados, con los que este canal ata un token a un
 * telefono: la cabecera que trae el cliente y el claim que viaja dentro del
 * token.
 *
 * <h2>Que problema resuelve atar el token a un dispositivo</h2>
 *
 * <p>Un JWT es una credencial <em>al portador</em>: quien lo tiene, lo usa. No
 * hay nada dentro de un token corriente que diga desde donde se puede
 * presentar, asi que copiarlo equivale a copiar la identidad completa de su
 * dueno hasta que expire. En este canal ese riesgo es el mas alto de los tres,
 * y no por una razon informatica sino por una razon fisica: <b>el token del
 * canal movil vive dentro de un aparato que se pierde, se olvida sobre una mesa
 * y se roba</b>. Ademas es el token de vigencia mas larga del sistema, 60
 * minutos, elegida asi porque la aplicacion se abre y se cierra decenas de
 * veces al dia.
 *
 * <p>La vinculacion convierte el token en una credencial que ya no basta por si
 * sola: para usarlo hay que presentarlo <b>junto al identificador del mismo
 * aparato</b> al que se emitio. Quien copie el token de un telefono robado y lo
 * use desde otro recibe 401 aunque la firma sea perfecta y aunque falten 59
 * minutos para que expire. Es exactamente la compensacion de la vigencia larga:
 * el canal cambia "menos tiempo de vida" por "menos lugares donde vale".
 *
 * <h2>Lo que esta proteccion NO es, dicho para no exagerarla</h2>
 *
 * <p>El identificador de dispositivo lo envia el propio cliente y no esta
 * firmado por nadie: quien robe el token <em>y</em> vea el identificador (por
 * ejemplo capturando una peticion del telefono legitimo) puede reproducir
 * ambos. Es una barrera contra la copia simple del token, no una prueba
 * criptografica de la identidad del aparato. La version seria de esto es el
 * <em>proof of possession</em>: una clave privada dentro del almacen seguro del
 * telefono con la que cada peticion se firma. Se deja fuera por alcance, no por
 * desconocimiento, y por eso conviene describir la medida por lo que hace:
 * sube el costo de usar un token robado desde otro aparato.
 */
public final class VinculacionDispositivo {

    /**
     * Cabecera que el telefono envia en <b>cada</b> peticion. (El dispositivo
     * tambien se declara al pedir el codigo de autorizacion, como parametro
     * {@code device_id}, y de ahi pasa al token.) La grafia esta congelada en la seccion 3 del contrato: un
     * canal que escribiera {@code X-DeviceId} no fallaria al compilar y
     * rechazaria todas las peticiones con un 401 cuyo motivo apunta al
     * dispositivo, sin que nadie sospeche de la cabecera.
     */
    public static final String CABECERA = "X-Device-Id";

    /**
     * Claim propio del canal movil. Lo escribe el {@code auth-server} (desde
     * F5, ningun BFF emite tokens) con el valor del parametro {@code device_id}
     * que la app agrego a la solicitud de autorizacion; el nombre es el del
     * contrato de claims compartido, {@link ClaimsToken#DEVICE_ID}. (Antes de
     * F5 se llamaba {@code dispositivoId} y lo escribia este canal en su login.)
     * Que un token deba traer dispositivo es politica de ESTE canal, y por eso
     * el filtro que lo exige vive en este modulo.
     */
    public static final String CLAIM = ClaimsToken.DEVICE_ID;

    /**
     * Lee el identificador de dispositivo que el auth-server escribio en el
     * token al emitirlo.
     *
     * @param jwt token ya validado por el resource server
     * @return el identificador, o {@code null} si el token no lo trae
     */
    public static String delToken(Jwt jwt) {
        return jwt.getClaimAsString(CLAIM);
    }

    private VinculacionDispositivo() {
    }
}
