/**
 * DTO de <strong>respuesta</strong> del canal movil. Viven aqui, dentro de
 * {@code bff-mobile}, y no en {@code plataforma-comun}.
 *
 * <h2>Por que este paquete no puede estar en la libreria compartida</h2>
 *
 * <p>Es la invariante que define el proyecto entero. Un BFF existe para dar a
 * SU cliente exactamente la forma que ese cliente necesita. Si los tres
 * canales importaran el mismo record de respuesta, cualquier campo que uno
 * necesitara aparecerian en los tres, y el sistema volveria a ser una sola API
 * generica con tres puertos distintos, que es precisamente el problema que el
 * patron BFF viene a resolver.
 *
 * <p>Dicho al reves: que estos records esten duplicados en parte con los de
 * {@code bff-web} no es repeticion que haya que eliminar, es
 * <strong>duplicacion intencional</strong>. El dia que el equipo de la
 * aplicacion movil pida un campo mas, se toca este paquete y ningun otro
 * modulo se entera, ni se recompila, ni se arriesga.
 *
 * <h2>Que si se comparte, entonces</h2>
 *
 * <p>De {@code plataforma-comun} este modulo usa solo el MECANISMO: el puerto
 * {@code CoreClient} para hablar con el core, los DTO del CORE (que son el
 * contrato aguas arriba y son iguales para todos porque el core es uno solo) y
 * la forma base del cuerpo de error. Nunca la forma de una respuesta de canal.
 *
 * <h2>Regla de este paquete</h2>
 *
 * <p>Ningun record de aqui lleva un campo "por si acaso". El canal movil corre
 * sobre una red celular, donde cada byte se paga en datos, en bateria y en
 * tiempo de pantalla. Un campo que el telefono no dibuja es un campo que no
 * debe viajar.
 */
package cl.duoc.bancoxyz.bff.mobile.api.dto;
