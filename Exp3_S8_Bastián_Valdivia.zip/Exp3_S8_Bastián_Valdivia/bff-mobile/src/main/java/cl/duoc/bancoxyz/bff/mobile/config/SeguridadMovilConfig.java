package cl.duoc.bancoxyz.bff.mobile.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;

import cl.duoc.bancoxyz.bff.mobile.seguridad.EntryPointTokenMovil;
import cl.duoc.bancoxyz.bff.mobile.seguridad.FiltroDispositivoMovil;
import cl.duoc.bancoxyz.bff.mobile.seguridad.ManejadorAccesoDenegadoMovil;
import cl.duoc.bancoxyz.bff.mobile.aplicacion.RegistroDispositivos;
import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.oauth2.FiltroAutenticacionNoDisponible;

/**
 * El punto donde el canal movil declara su <strong>politica</strong> de
 * seguridad: quien puede entrar, con que credencial, con que token y a que
 * operaciones llega.
 *
 * <h2>Mecanismo compartido, politica propia: el eje de todo el proyecto</h2>
 *
 * <p>Los tres BFF comparten el <b>mecanismo</b>: HTTPS con certificado propio,
 * JWT firmado en RS256 por el servidor de autorizacion, validacion delegada en
 * el resource server (firma por JWKS, emisor y audiencia), sesion sin estado y
 * las mismas cabeceras de seguridad. No comparten la <b>politica</b>: factor
 * adicional (el dispositivo), claims que exige y permisos son distintos en cada
 * canal. Esta clase es el lado de la politica para el movil, y por eso existe
 * una equivalente, con otro contenido, en cada uno de los otros dos canales.
 *
 * <p>Desde F5 <b>este canal no emite tokens ni tiene login</b>: el usuario inicia
 * sesion en el {@code auth-server} (flujo {@code authorization_code} con PKCE,
 * cliente {@code mobile-app}, audiencia {@code bff-mobile}, 60 minutos) y aqui
 * solo se VALIDA el token. Lo que queda como politica propia es la regla del
 * dispositivo ({@link FiltroDispositivoMovil}) y los permisos por ruta.
 *
 * <h2>Como se lee la cadena de filtros</h2>
 *
 * <p>Un {@code SecurityFilterChain} es una lista ordenada de filtros por la que
 * pasa <b>toda</b> peticion antes de llegar a un controlador. Cada uno hace una
 * cosa y decide si la peticion sigue viva. En este canal el recorrido es:
 *
 * <ol>
 *   <li>el filtro del resource server lee la cabecera {@code Authorization},
 *       verifica firma (con las claves publicas del auth-server), emisor,
 *       vigencia y audiencia del token, y deja la identidad disponible para
 *       los siguientes;</li>
 *   <li>{@link FiltroDispositivoMovil} comprueba que el token venga del
 *       telefono al que se emitio y que ese telefono no este dado de baja;</li>
 *   <li>el filtro de autorizacion aplica las reglas de
 *       {@code authorizeHttpRequests} de mas abajo;</li>
 *   <li>si algo fallo, {@link EntryPointTokenMovil} escribe el 401 y
 *       {@link ManejadorAccesoDenegadoMovil} escribe el 403.</li>
 * </ol>
 *
 * <p>El orden reproduce el de la seccion 7.4 del contrato: autenticacion,
 * autoridad y despues titularidad, que es el unico nivel que no cabe aqui y se
 * comprueba en el servicio.
 */
@Configuration
public class SeguridadMovilConfig {

    /**
     * Las reglas del canal, en el orden en que se evaluan.
     *
     * <p><b>Las reglas se evaluan de arriba hacia abajo y gana la primera que
     * coincide</b>, asi que lo especifico va antes que lo general y
     * {@code anyRequest()} va siempre al final. Una regla abierta colocada
     * arriba anularia en silencio todo lo que viniera despues.
     */
    @Bean
    public SecurityFilterChain cadenaDeSeguridadMovil(HttpSecurity http,
                                                      EscritorErrorHttp escritor,
                                                      RegistroDispositivos dispositivos) throws Exception {

        EntryPointTokenMovil entryPoint = new EntryPointTokenMovil(escritor);
        ManejadorAccesoDenegadoMovil accesoDenegado = new ManejadorAccesoDenegadoMovil(escritor);

        http
                // CSRF DESHABILITADO, Y ESTA ES LA JUSTIFICACION.
                //
                // El ataque de falsificacion de peticion entre sitios funciona
                // asi: un sitio malicioso provoca desde el navegador de la
                // victima una peticion al banco, y el navegador ADJUNTA SOLO la
                // cookie de sesion porque esa es la regla del navegador. La
                // peticion llega firmada por la sesion de la victima sin que
                // ella haya hecho nada.
                //
                // Aqui la credencial no es una cookie: es la cabecera
                // Authorization, que solo se agrega si alguien escribe el
                // codigo que la agrega. Ningun navegador la adjunta sola. Sin
                // adjuncion automatica no hay vector de CSRF que defender, y el
                // token de proteccion CSRF seria una ceremonia que exige un
                // estado de servidor que este canal justamente no quiere tener.
                //
                // Deshabilitarlo sin explicarlo se lee como descuido; el motivo
                // de escribir el porque al lado es que la decision se pueda
                // revisar el dia que este canal acepte cookies. Si eso ocurre,
                // esta linea vuelve a ser necesaria.
                .csrf(csrf -> csrf.disable())

                // SESION SIN ESTADO. STATELESS no significa "no uses la sesion
                // si ya existe": significa que Spring Security NO crea ninguna
                // HttpSession y no consulta ninguna. Cada peticion trae su
                // prueba de identidad completa y se resuelve con ella sola.
                //
                // Tres consecuencias concretas:
                //  - No hay que replicar sesiones ni configurar afinidad de
                //    servidor para repartir la carga entre instancias.
                //  - La evidencia cruzada de tokens es limpia: sin sesion
                //    residual, ninguna peticion pasa "porque la anterior paso".
                //  - Cerrar sesion no es un concepto del servidor. El token
                //    vale hasta que expira, y eso es justamente lo que obliga a
                //    que la vigencia de 60 minutos venga acompanada de la
                //    vinculacion al dispositivo.
                .sessionManagement(sesion -> sesion.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                .authorizeHttpRequests(reglas -> reglas

                        // --- Lo unico publico del canal, y nada mas ----------
                        // La salud es publica para que el guion de arranque
                        // pueda esperar a que el canal este listo sin tener que
                        // autenticarse antes de que exista nadie a quien
                        // autenticar. Solo /health: exponer el resto de
                        // Actuator sin credencial regalaria la configuracion
                        // interna del servicio. Esta regla solo se ejerce si
                        // Actuator comparte el puerto del canal (pruebas);
                        // desde F1, en el despliegue, la salud esta en el
                        // puerto de gestion y en el del canal responde 404.
                        .requestMatchers(HttpMethod.GET, "/actuator/health").permitAll()

                        // --- Nivel de OPERACION: permiso fino por ruta -------
                        // Se escribe hasAuthority con el literal COMPLETO, tal
                        // como viaja en el claim authorities del token. En este
                        // proyecto NUNCA se usa hasRole: hasRole antepone
                        // "ROLE_" por su cuenta, y esa asimetria entre lo que
                        // dice la regla y lo que dice el token es la causa
                        // numero uno del 403 inexplicable. Con hasAuthority, el
                        // texto de esta linea y el contenido del token son la
                        // misma cadena, comparables a simple vista con el
                        // token decodificado de la evidencia.
                        .requestMatchers(HttpMethod.GET, "/v1/cuentas/*/resumen")
                            .hasAuthority("PERM_saldo:leer")

                        // La operacion exclusiva del canal movil. Tiene permiso
                        // PROPIO y no reutiliza el de saldo: dar de baja un
                        // dispositivo no se parece en nada a consultar un
                        // saldo, y un permiso que sirve para dos cosas
                        // distintas ya no describe ninguna.
                        .requestMatchers(HttpMethod.POST, "/v1/dispositivos/baja")
                            .hasAuthority("PERM_dispositivo:gestionar")

                        // --- Todo lo demas: identificarse es obligatorio -----
                        // Incluye /actuator/metrics/** en el puerto del canal
                        // (401 sin token; las metricas se leen en el puerto de
                        // gestion, que desde F1 tiene su propia cadena sin
                        // token). Va AL FINAL y es la red de
                        // seguridad: una ruta nueva que nadie recuerde declarar
                        // nace protegida, no abierta. Es la diferencia entre
                        // olvidarse de proteger y olvidarse de abrir, y solo el
                        // segundo olvido es seguro.
                        .anyRequest().authenticated())

                // El resource server: la maquinaria que valida el token. Toda
                // su configuracion vive en config-repo/bff-mobile.yml
                // (jwk-set-uri, issuer-uri, audiences, authorities-claim-name y
                // authority-prefix), sin una sola linea de Java de validacion.
                //
                // Lo unico que se ajusta aqui es a quien le pasa la palabra
                // cuando el token no sirve: este filtro tiene SU PROPIO punto
                // de entrada y no usa el de exceptionHandling. Configurar solo
                // uno de los dos es un error clasico y de sintoma confuso:
                // faltar el token produce un 401 con el formato del proyecto y
                // presentar un token invalido produce el error generico de
                // Spring, que ademas no lleva el campo motivo.
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(Customizer.withDefaults())
                        .authenticationEntryPoint(entryPoint)
                        .accessDeniedHandler(accesoDenegado))

                .exceptionHandling(errores -> errores
                        .authenticationEntryPoint(entryPoint)
                        .accessDeniedHandler(accesoDenegado))

                // La regla propia del canal, insertada justo DESPUES de la
                // validacion del token: cuando corre, la identidad ya esta
                // verificada, y todavia no se aplicaron las reglas de
                // autorizacion. Ese hueco es exactamente donde corresponde
                // comprobar algo que es autenticacion (401) y no permisos.
                .addFilterAfter(new FiltroDispositivoMovil(escritor, dispositivos),
                        BearerTokenAuthenticationFilter.class)

                // Si el auth-server no entrega sus claves, el token no se puede ni verificar: 503 en el formato
                // del canal, no un 401 ni un 500 (ver FiltroAutenticacionNoDisponible). Va ANTES del filtro de
                // tokens, que es donde nace la excepcion que atrapa.
                .addFilterBefore(new FiltroAutenticacionNoDisponible(escritor, "MOVIL"),
                        BearerTokenAuthenticationFilter.class);

        // Sobre las cabeceras de seguridad: no se configuran porque Spring
        // Security ya las emite por defecto y sus valores por defecto son los
        // correctos aqui. X-Content-Type-Options: nosniff impide que el
        // navegador adivine el tipo de una respuesta e interprete como script
        // algo que se declaro JSON; X-Frame-Options: DENY impide incrustar el
        // canal en un marco ajeno. HSTS se emite solo sobre conexiones seguras,
        // asi que aparece en HTTPS y no en una prueba local en plano: verlo
        // ausente en un MockMvc no es un fallo de configuracion.
        return http.build();
    }
}
