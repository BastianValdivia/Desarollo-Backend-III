package cl.duoc.bancoxyz.bff.mobile.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.filter.ShallowEtagHeaderFilter;

/**
 * Mecanismos de ancho de banda propios del canal movil.
 *
 * <p>Este canal es el unico de los tres cuyo cliente paga la red por megabyte y la sufre por
 * latencia. Sus optimizaciones atacan por eso una dimension concreta: <strong>bytes que salen
 * hacia el telefono</strong>. La cache de {@code CacheCuentaMovil} no sirve para eso (vive en el
 * servidor y solo ahorra el salto hacia el core); quien si sirve es lo que hay en este archivo.
 *
 * <h2>El ETag, y que hace exactamente</h2>
 *
 * <p>Un ETag es una etiqueta corta que identifica <em>la version</em> de una respuesta. El
 * servidor la manda en la cabecera {@code ETag}; el cliente la guarda y, la proxima vez que pide
 * el mismo recurso, la reenvia en {@code If-None-Match}. Si la respuesta que el servidor iba a
 * enviar sigue teniendo esa misma etiqueta, contesta <strong>304 Not Modified</strong> sin cuerpo,
 * y el cliente reutiliza lo que ya tenia.
 *
 * <p>Para el canal movil el numero concreto es este: el resumen M2 pesa 368 bytes; un 304 pesa
 * <strong>cero</strong> bytes de cuerpo. La aplicacion de un telefono consulta el saldo muchas
 * veces al dia y el saldo cambia pocas veces al dia, asi que la gran mayoria de esas consultas
 * puede resolverse sin transferir el cuerpo.
 *
 * <h2>La limitacion del ETag "superficial", dicha de frente</h2>
 *
 * <p>El filtro que se registra abajo se llama <em>Shallow</em>, superficial, y el nombre es una
 * advertencia honesta: para calcular la etiqueta necesita <strong>generar la respuesta completa
 * igual que siempre</strong> (llamar al core si hace falta, proyectar, serializar el JSON) y
 * recien entonces resumirla y compararla. Es decir:
 *
 * <ul>
 *   <li><strong>Ahorra red</strong>, que es lo caro del canal movil: eso es real y es el motivo
 *       de tenerlo.</li>
 *   <li><strong>No ahorra CPU del servidor</strong>, ni llamadas al core. Un 304 le cuesta al BFF
 *       casi lo mismo que un 200. Quien ahorra llamadas al core es la cache, que es otro
 *       mecanismo y ataca otra dimension.</li>
 * </ul>
 *
 * <p>Vale la pena decirlo escrito porque es la objecion que un lector exigente plantea, y porque
 * la conclusion sigue siendo la misma: en este canal el recurso escaso es el enlace del telefono,
 * no la CPU del servidor.
 *
 * <h2>Por que NO esta en el canal del cajero</h2>
 *
 * <p>Un 304 significa "usa la copia que ya tienes". Sobre una consulta de saldo hecha un instante
 * antes de entregar billetes, eso es exactamente el fallo que el canal del cajero existe para
 * evitar, con el agravante de que aqui el dato viejo lo guardaria el propio terminal. El cajero
 * no lleva ETag por la misma razon por la que no lleva cache: no hay ninguna cantidad de bytes
 * que compense entregar dinero contra un saldo que ya no es cierto.
 *
 * <h2>El choque entre ETag y gzip, y por que la etiqueta va marcada como "debil"</h2>
 *
 * <p>Esta es la parte de este archivo que no se deduce leyendo documentacion: se encontro
 * <strong>midiendo</strong>, y sin medir habria pasado inadvertida.
 *
 * <p>Al activar el filtro, la respuesta empezo a llegar con su cabecera {@code ETag}
 * correctamente... y <strong>dejo de venir comprimida</strong>, pese a que la compresion seguia
 * configurada y el cuerpo superaba el umbral. Las dos optimizaciones del canal se anulaban entre
 * si, y ninguna dio error.
 *
 * <p>La causa esta en Tomcat, que se niega a comprimir una respuesta que lleve un ETag
 * <em>fuerte</em>. Y tiene toda la razon en negarse: un ETag fuerte es una promesa de identidad
 * <strong>byte a byte</strong>, y comprimir cambia todos los bytes. Servir el mismo ETag para el
 * cuerpo plano y para el comprimido seria mentir sobre lo que la etiqueta significa.
 *
 * <p>La solucion no es renunciar a una de las dos, sino <strong>decir la verdad con la etiqueta
 * correcta</strong>. HTTP define dos clases de ETag:
 *
 * <ul>
 *   <li><strong>Fuerte</strong> ({@code "abc123"}): los bytes son identicos.</li>
 *   <li><strong>Debil</strong> ({@code W/"abc123"}): el contenido es <em>equivalente en
 *       significado</em>, aunque los bytes difieran.</li>
 * </ul>
 *
 * <p>Para lo que este canal necesita, "debil" es la afirmacion correcta y no una concesion: el
 * resumen comprimido y el resumen plano <em>son el mismo saldo</em>. Con la etiqueta debil, Tomcat
 * comprime, el 304 sigue funcionando igual, y las dos optimizaciones conviven. La comparacion
 * medida esta en la seccion 6 del documento de verificacion.
 *
 * <p>La leccion que vale mas alla de este caso: <strong>dos optimizaciones correctas por separado
 * pueden cancelarse al juntarse, y hacerlo sin producir ningun error</strong>. Es la razon de que
 * la regla de esta etapa sea medir el resultado y no confiar en que la configuracion diga lo que
 * uno cree.
 *
 * <h2>Efecto lateral util: este filtro es lo que hace efectivo el umbral de compresion</h2>
 *
 * <p>Para calcular la etiqueta, el filtro acumula la respuesta entera en memoria antes de
 * enviarla. Al hacerlo, queda sabiendo cuanto mide, y fija la cabecera
 * {@code Content-Length}. Eso importa mucho mas de lo que parece: sin {@code Content-Length}, la
 * respuesta sale en trozos ({@code Transfer-Encoding: chunked}) y Tomcat
 * <strong>no puede aplicar el umbral {@code min-response-size}</strong>, porque en el momento de
 * decidir si comprime todavia no sabe el tamano; ante la duda, comprime. El umbral configurado en
 * el {@code config-repo/bff-mobile.yml} quedaria de adorno. Con este filtro delante, el tamano se conoce
 * antes de decidir y el umbral hace lo que dice que hace. La medicion que lo demuestra esta en
 * {@code git show dd2e301:docs/verificacion-fase5-optimizacion.md}.
 */
@Configuration
public class OptimizacionMovilConfig {

    /**
     * Ruta sobre la que actua el ETag: el resumen de cuenta (M2), y nada mas.
     *
     * <h3>Dos trampas del patron, las dos descubiertas midiendo y no leyendo</h3>
     *
     * <p><strong>Trampa 1: el patron NO lleva el context-path.</strong> La primera version escrita
     * aqui fue {@code /api/mobile/v1/cuentas/*}, por razonar que un filtro de servlet ve la URL
     * completa. Es falso: con un {@code context-path} configurado, el contenedor ya esta
     * <em>dentro</em> de ese contexto y los patrones se resuelven relativos a el. Incluirlo hace
     * que el patron no case con nada.
     *
     * <p><strong>Trampa 2: un patron de servlet no admite un comodin en medio.</strong> Lo
     * natural seria escribir {@code /v1/cuentas/*}{@code /resumen} para apuntar exactamente a M2,
     * y la especificacion de servlets no lo permite: solo acepta coincidencia exacta
     * ({@code /a/b}), prefijo ({@code /a/*}), extension ({@code *.json}) y la raiz. Un patron con
     * el comodin en medio no da error de arranque: simplemente no casa nunca.
     *
     * <p>Las dos fallan de la misma forma, que es la peor: <strong>en silencio</strong>. La
     * aplicacion arranca, el bean se registra, el filtro existe, y no se activa jamas. No hay
     * excepcion ni linea en el log. El unico sintoma es que la respuesta no trae cabecera
     * {@code ETag}, y solo se ve mirandola. Fue asi como se detecto.
     *
     * <p>Se usa entonces el prefijo {@code /v1/cuentas/*}, que en este canal es equivalente a
     * "solo M2": el unico endpoint del movil bajo esa raiz es el resumen. La baja de dispositivo
     * (M3) cuelga de {@code /v1/dispositivos} y el login de {@code /auth}, asi que quedan fuera,
     * que es lo que se buscaba.
     *
     * <p>La leccion general: una configuracion que puede fallar sin avisar hay que
     * <strong>verla funcionar</strong>, no darla por hecha porque compila.
     */
    static final String RUTA_RESUMEN = "/v1/cuentas/*";

    /**
     * Registra el filtro de ETag <strong>solo sobre M2</strong>, y no sobre el canal entero.
     *
     * <p>El alcance acotado es la decision que importa de este bean, por tres razones:
     *
     * <ol>
     *   <li><strong>El login no debe llevar ETag.</strong> Su respuesta contiene un token nuevo
     *       cada vez; etiquetarla no ahorra nada y hacer que un cliente reutilice una respuesta de
     *       login por tener la misma etiqueta seria un error grave.</li>
     *   <li><strong>La baja de dispositivo (M3) tampoco.</strong> Es una operacion de escritura;
     *       un 304 sobre un POST no tiene ningun sentido.</li>
     *   <li><strong>El filtro cuesta memoria.</strong> Acumula cada respuesta entera antes de
     *       enviarla. Sobre 368 bytes eso es irrelevante; sobre todo el canal seria pagar ese
     *       costo en peticiones que nunca se van a beneficiar.</li>
     * </ol>
     *
     * <p>El orden {@code HIGHEST_PRECEDENCE + 100} lo coloca por delante del resto de filtros de
     * aplicacion pero por detras de la cadena de seguridad, que corre antes. El orden correcto es
     * ese y no el inverso: <strong>primero se comprueba quien pregunta, despues se decide si hace
     * falta enviarle el cuerpo</strong>. Si el ETag corriera antes que la seguridad, una peticion
     * sin token valido podria recibir un 304 y con el la confirmacion de que el recurso existe y
     * no ha cambiado, que es informacion que no le corresponde.
     */
    @Bean
    public FilterRegistrationBean<ShallowEtagHeaderFilter> filtroEtagResumen() {
        ShallowEtagHeaderFilter filtro = new ShallowEtagHeaderFilter();

        // ETIQUETA DEBIL (W/"..."), y de esto depende que la compresion del canal funcione.
        // Tomcat NO comprime una respuesta que lleve un ETag fuerte, porque un ETag fuerte
        // promete identidad byte a byte y comprimir cambia todos los bytes. Sin esta linea, el
        // ETag y gzip se anulan mutuamente y ninguno de los dos avisa: la respuesta sale con
        // etiqueta y sin comprimir, y el ahorro de la mitad de la transferencia desaparece.
        // Una etiqueta debil afirma "mismo contenido, quiza distintos bytes", que es
        // exactamente lo que ocurre aqui y por tanto lo honesto de declarar.
        filtro.setWriteWeakETag(true);

        FilterRegistrationBean<ShallowEtagHeaderFilter> registro =
                new FilterRegistrationBean<>(filtro);

        registro.addUrlPatterns(RUTA_RESUMEN);
        registro.setName("filtroEtagResumenMovil");
        registro.setOrder(Ordered.HIGHEST_PRECEDENCE + 100);

        return registro;
    }
}
