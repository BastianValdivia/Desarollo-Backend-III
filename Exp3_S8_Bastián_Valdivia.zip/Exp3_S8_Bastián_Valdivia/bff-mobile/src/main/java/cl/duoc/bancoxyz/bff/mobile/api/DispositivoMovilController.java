package cl.duoc.bancoxyz.bff.mobile.api;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.bancoxyz.bff.mobile.api.dto.BajaDispositivoResponse;
import cl.duoc.bancoxyz.bff.mobile.aplicacion.BajaDispositivoService;
import cl.duoc.bancoxyz.bff.mobile.seguridad.VinculacionDispositivo;

/**
 * Baja de dispositivo (M3): el endpoint <strong>exclusivo</strong> del canal
 * movil.
 *
 * <p>La misma ruta contra {@code bff-web} (8443) o {@code bff-atm} (8445)
 * responde 404. Esa asimetria es la evidencia de que los tres BFF no son tres
 * copias del mismo servicio con puertos distintos: cada canal publica las
 * operaciones que su cliente necesita, y solo esas.
 *
 * <h2>Que es {@code @AuthenticationPrincipal Jwt}</h2>
 *
 * <p>Cuando el resource server valida el token, deja el resultado (el JWT ya
 * verificado y con sus claims accesibles) en el contexto de seguridad de la
 * peticion. Esa anotacion se limita a inyectarlo aqui. Que llegue como
 * parametro tiene una consecuencia util: si este metodo se ejecuta, el token
 * <b>ya</b> paso firma, vigencia, audiencia, vinculacion de dispositivo y la
 * regla de autoridad. El controlador no tiene que comprobar nada de eso, y por
 * eso no hay un solo {@code if} de seguridad en el cuerpo.
 *
 * <p>El permiso exigido, {@code PERM_dispositivo:gestionar}, esta declarado en
 * el {@code SecurityFilterChain} y no con una anotacion sobre este metodo. El
 * proyecto no usa {@code @PreAuthorize} en ningun sitio: sin
 * {@code @EnableMethodSecurity} esa anotacion <b>se ignora en absoluto
 * silencio</b>, el codigo compila, arranca y parece correcto, y ninguna regla
 * se aplica. Un fallo que no da senal es peor que uno que revienta.
 */
@RestController
@RequestMapping("/v1/dispositivos")
public class DispositivoMovilController {

    private final BajaDispositivoService servicio;

    public DispositivoMovilController(BajaDispositivoService servicio) {
        this.servicio = servicio;
    }

    /**
     * Da de baja el dispositivo desde el que se opera.
     *
     * <p>No recibe cuerpo: el identificador se toma del claim del token. El
     * motivo completo esta en {@link BajaDispositivoService}, y se resume en que
     * un dispositivo solo puede darse de baja a si mismo.
     */
    @PostMapping("/baja")
    public BajaDispositivoResponse darDeBaja(@AuthenticationPrincipal Jwt jwt) {
        return servicio.darDeBaja(VinculacionDispositivo.delToken(jwt));
    }
}
