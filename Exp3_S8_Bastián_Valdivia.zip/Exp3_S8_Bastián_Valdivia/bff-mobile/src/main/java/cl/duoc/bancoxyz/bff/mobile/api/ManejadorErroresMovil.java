package cl.duoc.bancoxyz.bff.mobile.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import cl.duoc.bancoxyz.comun.core.CoreCredencialRechazadaException;
import cl.duoc.bancoxyz.comun.core.CoreException;
import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.bff.mobile.aplicacion.CuentaAjenaException;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.error.MotivosError;
import cl.duoc.bancoxyz.comun.error.RespuestaError;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Traduce cualquier fallo del canal movil a un cuerpo <strong>RFC 7807</strong>
 * ({@code application/problem+json}), con el envoltorio de la seccion 5.16 del
 * contrato y {@code canal} igual a {@code MOVIL}.
 *
 * <h2>Que es un RestControllerAdvice</h2>
 *
 * <p>Es una clase que Spring consulta cuando un controlador lanza una
 * excepcion. Gracias a ella, el controlador y el servicio no tienen un solo
 * {@code try/catch}: se limitan a lanzar, y la traduccion de excepcion a
 * codigo HTTP se escribe una vez, aqui. El beneficio practico es que ningun
 * camino puede olvidarse de traducir un error y terminar devolviendo la pagina
 * de error generica de Spring, que no se parece en nada al resto de la API.
 *
 * <h2>Por que el envoltorio es compartido y el contenido no</h2>
 *
 * <p>El record {@link RespuestaError} vive en {@code plataforma-comun} porque
 * que los tres canales devuelvan errores con la misma forma es una propiedad
 * de calidad: un cliente que sabe leer un error del web sabe leer uno del
 * movil. Pero QUE codigo HTTP corresponde a cada fallo, y con que texto, es
 * politica de canal y por eso se decide en esta clase, dentro de este modulo.
 *
 * <p>Este canal si incluye {@code detail}. El cajero lo omite, porque su
 * pantalla esta en la via publica y un detalle tecnico ahi es informacion
 * regalada a quien pase por delante; un telefono, en cambio, lo mira su dueno,
 * y un mensaje util evita una llamada a la mesa de ayuda. Este canal tampoco
 * lleva {@code codigoPantalla} ni {@code mensajePantalla}: esos dos campos
 * existen solo en el cajero.
 *
 * <h2>La traduccion, de un vistazo</h2>
 *
 * <table border="1">
 *   <caption>Excepcion del core y respuesta del canal movil</caption>
 *   <tr><th>Lo que ocurrio</th><th>HTTP</th><th>motivo</th></tr>
 *   <tr><td>La cuenta no existe en el core</td><td>404</td><td>{@code recurso_no_encontrado}</td></tr>
 *   <tr><td>Ruta o identificador que este canal no sirve</td><td>404</td><td>{@code recurso_no_encontrado}</td></tr>
 *   <tr><td>El core no responde, o responde 5xx</td><td>503</td><td>{@code core_no_disponible}</td></tr>
 *   <tr><td>El core rechaza la credencial de servicio</td><td>503</td><td>{@code core_no_disponible}</td></tr>
 *   <tr><td>Cualquier otro fallo del core</td><td>503</td><td>{@code core_no_disponible}</td></tr>
 * </table>
 */
@RestControllerAdvice
public class ManejadorErroresMovil {

    private static final Logger log = LoggerFactory.getLogger(ManejadorErroresMovil.class);

    /**
     * Valor del campo {@code canal} para este BFF, congelado en la seccion 5.16
     * del contrato.
     *
     * <p>Sirve para algo muy concreto durante la evidencia: cuando se lanzan
     * los tres canales a la vez y se comparan respuestas, este campo dice sin
     * ambiguedad cual de los tres proceso la peticion.
     */
    private static final String CANAL = "MOVIL";

    /**
     * La cuenta pedida no existe en el core.
     *
     * <p>Se responde <strong>404</strong>, que es lo correcto porque el recurso
     * de verdad no existe. Conviene contrastarlo con el caso que llega en la
     * fase de seguridad: pedir una cuenta que <em>si</em> existe pero es de
     * otra persona sera <strong>403 {@code cuenta_ajena}</strong> y no 404,
     * porque ahi el recurso existe y lo que falta es el derecho.
     */
    @ExceptionHandler(CoreRecursoNoEncontradoException.class)
    public ResponseEntity<RespuestaError> manejarNoEncontrado(CoreRecursoNoEncontradoException excepcion,
                                                              HttpServletRequest peticion) {
        // Nivel info y no error: pedir una cuenta que no existe es un error del
        // cliente, no una averia del servicio. Registrarlo como error llenaria
        // el log de ruido y taparia las averias de verdad.
        log.info("Cuenta no encontrada en el core: {}", excepcion.rutaSolicitada());

        return construir(HttpStatus.NOT_FOUND, "Recurso no encontrado",
                MotivosError.RECURSO_NO_ENCONTRADO,
                "No existe la cuenta solicitada", peticion);
    }

    /**
     * El core no respondio, supero el timeout o devolvio un 5xx.
     *
     * <p>Es <strong>503</strong> y no 500: 500 significa "yo me averie", y este
     * BFF esta perfectamente sano; lo que fallo es la dependencia. La
     * distincion no es academica, porque le dice al telefono que reintentar mas
     * tarde tiene sentido, cosa que no ocurre con un 500.
     *
     * <p>Que este caso tenga un motivo propio, {@code core_no_disponible}, es
     * lo que el proyecto llama degradacion controlada: el canal no se cuelga
     * junto con el core ni devuelve una respuesta inventada, responde rapido y
     * dice la verdad sobre lo que paso.
     */
    @ExceptionHandler(CoreNoDisponibleException.class)
    public ResponseEntity<RespuestaError> manejarCoreCaido(CoreNoDisponibleException excepcion,
                                                           HttpServletRequest peticion) {
        // Aqui si es nivel error, con la excepcion completa: hay algo caido que
        // alguien tiene que ir a mirar.
        log.error("El core no respondio a {}", excepcion.rutaSolicitada(), excepcion);

        return construir(HttpStatus.SERVICE_UNAVAILABLE, "Servicio no disponible",
                MotivosError.CORE_NO_DISPONIBLE,
                "El servicio no esta disponible en este momento, intente nuevamente", peticion);
    }

    /**
     * El core rechazo el token de servicio de este BFF (401 o 403).
     *
     * <p><b>Este es el metodo mas facil de escribir mal de toda la clase.</b> El
     * core respondio 401, y el reflejo es propagar ese 401 al telefono. Seria
     * un error grave por dos razones. La primera es que mentiria: un 401 en
     * este canal significa "tu sesion no sirve", y el usuario borraria su
     * sesion e intentaria iniciarla de nuevo una y otra vez sin que eso arregle
     * nada, porque la credencial que fallo no es la suya, es la del BFF contra
     * el core. La segunda es que filtraria un detalle de la arquitectura
     * interna a un cliente que no tiene por que saber que existe un core detras.
     *
     * <p>Visto desde el canal, un core que no acepta nuestra credencial es un
     * core del que no podemos obtener datos, y eso es exactamente
     * <strong>503</strong>. La causa real (una configuracion mal puesta, dos
     * secretos que dejaron de coincidir) queda en el log del servidor, que es
     * donde la puede leer quien la puede arreglar.
     */
    @ExceptionHandler(CoreCredencialRechazadaException.class)
    public ResponseEntity<RespuestaError> manejarCredencialRechazada(CoreCredencialRechazadaException excepcion,
                                                                     HttpServletRequest peticion) {
        log.error("El core rechazo el token de servicio del bff-mobile en {} (estado {}). "
                        + "Con 401, revise que el core y el auth-server coincidan en emisor y audiencia; "
                        + "con 403, que el cliente OAuth2 bff-mobile conserve el scope del endpoint.",
                excepcion.rutaSolicitada(), excepcion.estadoDelCore(), excepcion);

        return construir(HttpStatus.SERVICE_UNAVAILABLE, "Servicio no disponible",
                MotivosError.CORE_NO_DISPONIBLE,
                "El servicio no esta disponible en este momento, intente nuevamente", peticion);
    }

    /**
     * Cualquier otro fallo del core que este canal no distingue.
     *
     * <p>Captura la clase base {@link CoreException}, de modo que una excepcion
     * nueva en la libreria compartida no se escape hacia el manejador generico
     * y termine convertida en un 500.
     *
     * <p><b>Por que aqui no aparece {@code saldo_insuficiente}.</b> Existe una
     * {@code CoreSaldoInsuficienteException} y seria facil mapearla a 409 "por
     * si acaso". No se hace: este canal no tiene ninguna operacion que mueva
     * dinero, asi que esa rama jamas se ejecutaria. Un manejador con ramas
     * imposibles hace creer al que lo lee que el canal hace cosas que no hace.
     * Si algun dia el movil ejecutara un retiro, la rama se agrega junto con la
     * operacion, no antes.
     */
    @ExceptionHandler(CoreException.class)
    public ResponseEntity<RespuestaError> manejarFalloDelCore(CoreException excepcion,
                                                              HttpServletRequest peticion) {
        log.error("Respuesta inesperada del core en {}", excepcion.rutaSolicitada(), excepcion);

        return construir(HttpStatus.SERVICE_UNAVAILABLE, "Servicio no disponible",
                MotivosError.CORE_NO_DISPONIBLE,
                "El servicio no esta disponible en este momento, intente nuevamente", peticion);
    }

    /**
     * El token es valido y acredita otra cuenta.
     *
     * <p><strong>403</strong> con {@code cuenta_ajena}, y no 404: la cuenta
     * existe, lo que falta es el derecho. Tampoco es 401: sabemos perfectamente
     * quien es y por eso no se le pide volver a identificarse.
     *
     * <p>El {@code detail} si nombra la cuenta pedida, y eso no filtra nada: ese
     * numero lo escribio el propio cliente en la URL. Lo que no dice, ni puede
     * decir, es cual es la cuenta que el token si acredita.
     */
    @ExceptionHandler(CuentaAjenaException.class)
    public ResponseEntity<RespuestaError> manejarCuentaAjena(CuentaAjenaException excepcion,
                                                             HttpServletRequest peticion) {
        log.warn("Titularidad rechazada en el canal movil para la cuenta {}", excepcion.cuentaSolicitada());

        return construir(HttpStatus.FORBIDDEN, "Acceso denegado",
                MotivosError.CUENTA_AJENA,
                "El token no acredita titularidad sobre la cuenta " + excepcion.cuentaSolicitada(),
                peticion);
    }

    /**
     * Una ruta que este canal no sirve, o un identificador de cuenta que no es
     * un numero.
     *
     * <p><b>Por que los tres casos dan el mismo 404.</b> Desde fuera, "esta
     * ruta no existe en el canal movil", "este endpoint es de otro canal" y
     * "abc no identifica ninguna cuenta" son la misma informacion: lo que
     * pediste no esta aqui. Distinguirlos solo le serviria a quien sondea el
     * servicio para saber cuales de sus rutas adivinadas son correctas.
     *
     * <p>Este metodo es ademas el que produce la evidencia de endpoints
     * exclusivos: {@code /v1/admin/calidad-datos}, que solo existe en el canal
     * web, responde aqui 404 con {@code motivo} igual a
     * {@code recurso_no_encontrado}, que es la prueba de que los tres BFF no
     * son intercambiables.
     *
     * <p><b>Por que se declaran DOS excepciones de ruta y no una.</b> Spring
     * cambio de mecanismo: {@code NoHandlerFoundException} es la clasica y solo
     * se lanza si se activa una propiedad; desde Spring Framework 6.1 una ruta
     * sin controlador cae en el manejador de recursos estaticos y lanza
     * {@code NoResourceFoundException}. Declarar solo la primera deja la
     * segunda sin capturar, y entonces la atrapa el manejador general y
     * responde <strong>500 a lo que es un 404</strong>: un error de cliente
     * disfrazado de averia del servidor.
     */
    @ExceptionHandler({NoHandlerFoundException.class,
            NoResourceFoundException.class,
            MethodArgumentTypeMismatchException.class})
    public ResponseEntity<RespuestaError> manejarRutaInexistente(HttpServletRequest peticion) {
        return construir(HttpStatus.NOT_FOUND, "Recurso no encontrado",
                MotivosError.RECURSO_NO_ENCONTRADO,
                "No existe el recurso solicitado en el canal movil", peticion);
    }

    /**
     * La ruta existe pero no acepta ese verbo, por ejemplo un {@code POST}
     * sobre el resumen.
     *
     * <p>Es <strong>405</strong> y no 404: decir "no existe" cuando el recurso
     * si existe confundiria a quien esta integrando la aplicacion movil. La
     * cabecera {@code Allow}, que Spring agrega sola, le dice ademas que verbos
     * si puede usar.
     *
     * <p>El motivo {@code metodo_no_permitido} quedo congelado en la seccion
     * 7.1 del contrato en su version 1.1.0 y se escribe desde
     * {@link MotivosError}. Hasta entonces era un literal suelto, tomado
     * prestado del {@code core-service} para no inventar un segundo
     * vocabulario dentro del mismo sistema.
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<RespuestaError> manejarVerboNoSoportado(
            HttpRequestMethodNotSupportedException excepcion, HttpServletRequest peticion) {

        return construir(HttpStatus.METHOD_NOT_ALLOWED, "Metodo no permitido",
                MotivosError.METODO_NO_PERMITIDO,
                "El recurso existe pero no acepta el verbo " + excepcion.getMethod(), peticion);
    }

    /**
     * El cuerpo llego con un {@code Content-Type} que la ruta no consume, por ejemplo un
     * {@code curl -d} sin {@code -H 'Content-Type: application/json'}, que curl manda como
     * formulario.
     *
     * <p>Es un error del cliente y se responde 415, no 500: el 500 le diria a quien integra que
     * el canal esta roto cuando lo unico que falta es la cabecera. Sin este manejador, la red de
     * seguridad de mas abajo se lo tragaba. El {@code motivo} reutiliza {@code peticion_invalida},
     * del vocabulario congelado: la peticion viene mal y reintentarla igual siempre fallara, que
     * es justo lo que ese motivo dice. No se inventa un motivo nuevo, porque la seccion 7.1 del
     * contrato no lo contempla.
     */
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<RespuestaError> manejarTipoContenidoNoSoportado(
            HttpMediaTypeNotSupportedException excepcion, HttpServletRequest peticion) {
        log.info("Tipo de contenido no soportado en {} {}: {}",
                peticion.getMethod(), peticion.getRequestURI(), excepcion.getContentType());

        return construir(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "Tipo de contenido no soportado",
                MotivosError.PETICION_INVALIDA,
                "El cuerpo debe enviarse como application/json", peticion);
    }

    /**
     * El cuerpo falta o no es un JSON legible. Misma familia que el 415: falla del cliente, no del
     * canal, y por eso 400 y no 500. El detalle no copia el texto de la excepcion de Jackson, que
     * cita fragmentos del cuerpo recibido y nombres de clases.
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<RespuestaError> manejarCuerpoIlegible(
            HttpMessageNotReadableException excepcion, HttpServletRequest peticion) {
        log.info("Cuerpo ilegible en {} {}", peticion.getMethod(), peticion.getRequestURI());

        return construir(HttpStatus.BAD_REQUEST, "Peticion invalida",
                MotivosError.PETICION_INVALIDA,
                "El cuerpo de la peticion no es un JSON valido", peticion);
    }

    /**
     * La red de seguridad: cualquier fallo no previsto.
     *
     * <p>Existe para que <strong>ninguna</strong> respuesta de este canal se
     * salga del formato RFC 7807, ni siquiera cuando el error es un defecto del
     * propio codigo. Es el unico manejador que registra la traza completa,
     * porque aqui si hay una averia que alguien tiene que arreglar. Al telefono
     * le llega un texto neutro: un stacktrace en el cuerpo de la respuesta le
     * entrega a cualquiera el mapa de las clases internas y de las versiones de
     * las librerias, que es informacion util solo para quien quiera atacar el
     * sistema.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<RespuestaError> manejarInesperado(Exception excepcion,
                                                            HttpServletRequest peticion) {
        log.error("Fallo no controlado en {} {}", peticion.getMethod(), peticion.getRequestURI(), excepcion);

        return construir(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno",
                MotivosError.ERROR_INTERNO,
                "El canal movil no pudo completar la operacion", peticion);
    }

    /**
     * Arma la respuesta, siempre con el tipo de contenido
     * {@code application/problem+json}.
     *
     * <p>Ese tipo es parte del estandar y no un adorno: le dice al cliente,
     * desde la cabecera y sin mirar el cuerpo, que lo que viene describe un
     * problema. Fijarlo en un unico lugar garantiza que ningun manejador se
     * olvide de ponerlo.
     *
     * <p>{@code instance} se toma de {@code getRequestURI()}, que incluye el
     * {@code context-path}: el valor que se devuelve es
     * {@code /api/mobile/v1/cuentas/999/resumen}, exactamente la ruta que el
     * cliente pidio, y no la version interna sin prefijo. Un {@code instance}
     * que el cliente no reconoce no sirve para diagnosticar nada.
     */
    private ResponseEntity<RespuestaError> construir(HttpStatus estado, String titulo,
                                                     String motivo, String detalle,
                                                     HttpServletRequest peticion) {
        return ResponseEntity.status(estado)
                .contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .body(RespuestaError.de(estado.value(), motivo, titulo, detalle,
                        peticion.getRequestURI(), CANAL));
    }
}
