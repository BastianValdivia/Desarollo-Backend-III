package cl.duoc.bancoxyz.bff.mobile.aplicacion;

/**
 * El token es valido, pero acredita la titularidad de otra cuenta.
 *
 * <p>Se traduce a <strong>403 {@code cuenta_ajena}</strong>: el tercer nivel de
 * autorizacion del proyecto, el del <em>dato</em>. Los otros dos niveles (rol y
 * operacion) los resuelve la cadena de filtros con {@code requestMatchers},
 * porque dependen solo de la ruta y de las autoridades del token; este no puede
 * resolverse ahi, porque depende de comparar un claim con una variable de ruta.
 *
 * <h2>Las dos decisiones congeladas que esta excepcion materializa</h2>
 *
 * <ol>
 *   <li><b>Es 403 y no 404.</b> La cuenta existe; lo que falta es el derecho.
 *       Responder 404 seria mentir sobre el estado del sistema.</li>
 *   <li><b>La titularidad se comprueba ANTES de preguntarle al core.</b> Si se
 *       consultara primero la existencia, la API devolveria 404 para las
 *       cuentas que no existen y 403 para las que si, y esa diferencia
 *       convertiria el endpoint en un <b>detector de cuentas existentes</b>
 *       para cualquiera con un token valido: bastaria recorrer identificadores
 *       y anotar cuales responden 403. Comprobando primero la titularidad, una
 *       cuenta ajena e inexistente responde 403 igual que una ajena y real, y
 *       no se filtra nada. De paso, la peticion rechazada no genera ninguna
 *       llamada al core.</li>
 * </ol>
 *
 * <p>El {@code detail} de la respuesta si nombra la cuenta pedida, y eso no
 * filtra nada: ese numero lo escribio el propio cliente en la URL.
 *
 * @see cl.duoc.bancoxyz.bff.mobile.aplicacion.ResumenMovilService
 */
public class CuentaAjenaException extends RuntimeException {

    private final int cuentaSolicitada;

    public CuentaAjenaException(int cuentaSolicitada) {
        super("El token no acredita titularidad sobre la cuenta " + cuentaSolicitada + ".");
        this.cuentaSolicitada = cuentaSolicitada;
    }

    /** Cuenta que venia en la ruta, para el {@code detail} de la respuesta. */
    public int cuentaSolicitada() {
        return cuentaSolicitada;
    }
}
