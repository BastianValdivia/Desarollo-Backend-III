package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.bff.mobile.api.dto.MovimientoMovilResponse;
import cl.duoc.bancoxyz.bff.mobile.api.dto.ResumenMovilResponse;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.core.dto.ConsultaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaTransaccionesCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoProperties;

/**
 * Pruebas de la proyeccion del canal movil: de la cuenta completa del core al resumen de
 * telefono.
 *
 * <p><strong>Que se esta probando en realidad.</strong> No una traduccion de campos, sino la
 * afirmacion central de este canal y del eje de medicion de la fase: que el BFF movil
 * <em>recorta</em>. Una respuesta medida en 368 bytes frente a los 4.669 del core solo prueba
 * algo si el recorte es una regla del servidor y no una casualidad de los datos de hoy. Estas
 * pruebas fijan esa regla: el limite de cinco no depende de lo que pida el cliente, los
 * movimientos llevan tres campos y ninguno mas, y una cuenta sin movimientos devuelve una lista
 * vacia en vez de un nulo.
 *
 * <p>Ninguna levanta Spring ni la red: el servicio recibe un {@link CoreClient} escrito a mano.
 * Esa es la recompensa de tener la proyeccion en la capa de aplicacion y no dentro del metodo del
 * controlador.
 */
class ResumenMovilServiceTest {

    /** Titular y saldo congelados de la cuenta 116 (seccion 9 del contrato). */
    private static CuentaCoreDto cuenta116(List<MovimientoCoreDto> movimientos) {
        return new CuentaCoreDto(
                116, "Diana Prince", "HIPOTECA", new BigDecimal("12000.00"), 30, "CLP", movimientos);
    }

    private static MovimientoCoreDto movimiento(String fecha) {
        return new MovimientoCoreDto(
                LocalDate.parse(fecha), "DEPOSITO", new BigDecimal("1000.00"), "glosa del CSV", "CSV_SEMILLA");
    }

    /** Cuarenta y dos movimientos, la cantidad real de la cuenta 116 en el dataset. */
    private static List<MovimientoCoreDto> cuarentaYDos() {
        List<MovimientoCoreDto> lista = new ArrayList<>();
        for (int dia = 1; dia <= 42; dia++) {
            // Se parte de un 31 de diciembre a proposito: cualquier base cercana a febrero
            // hace que las fechas esperadas dependan del ano bisiesto, y una prueba que falla
            // por el calendario no dice nada sobre el recorte, que es lo que aqui se mide.
            lista.add(movimiento(LocalDate.of(2024, 12, 31).minusDays(dia).toString()));
        }
        return List.copyOf(lista);
    }


    /*
     * NOTA SOBRE ESTAS PRUEBAS TRAS LA ETAPA 7.
     *
     * El servicio ya no recibe el CoreClient directo sino CacheCuentaMovil, asi que el doble de
     * prueba se envuelve en ella. Conviene entender por que eso NO altera lo que estas pruebas
     * comprueban: aqui la cache se construye a mano con "new", fuera del contenedor de Spring, y
     * @Cacheable lo implementa un proxy que solo existe cuando el bean lo crea Spring. Una
     * instancia hecha con "new" no lleva proxy, de modo que CacheCuentaMovil se comporta como un
     * simple reenvio al CoreClient y cada llamada viaja.
     *
     * Eso es exactamente lo que queremos en estas pruebas, que son de la LOGICA del canal (que se
     * recorten 5 movimientos, que se rechace una cuenta ajena) y no del cacheo. Que la cache
     * funciona de verdad se comprueba aparte, en CacheCuentaMovilTest, levantando el contexto de
     * Spring, que es la unica forma de que el proxy exista.
     *
     * La moraleja general, que vale mas alla de este archivo: si una prueba de cache no levanta el
     * contexto, no esta probando la cache. Puede pasar en verde con la anotacion borrada.
     */

    /** Arma el servicio como lo hace Spring, pero a mano: cache sin proxy y un respaldo propio de la prueba. */
    private static ResumenMovilService servicio(CoreClient core) {
        RespaldoDeLecturas respaldo = RespaldoDeLecturas.paraPruebas(
                new RespaldoProperties(java.time.Duration.ofMinutes(10), 100));
        return new ResumenMovilService(new CacheCuentaMovil(core, respaldo), respaldo);
    }

    @Test
    @DisplayName("De 42 movimientos del core salen 5, y son los 5 primeros que el core entrego")
    void recortaACincoSinReordenar() {
        // El core entrega la lista ya ordenada de mas reciente a mas antiguo. El canal se limita
        // a tomar la cabeza: si aqui se ordenara de nuevo, el movil podria mostrar los cinco mas
        // ANTIGUOS sin que ninguna prueba de cantidad lo notara.
        ResumenMovilResponse respuesta =
                servicio(new CoreClientFalso(cuenta116(cuarentaYDos()))).obtenerResumen(116, 116);

        assertEquals(5, respuesta.ultimosMovimientos().size());
        assertEquals(LocalDate.parse("2024-12-30"), respuesta.ultimosMovimientos().get(0).fecha());
        assertEquals(LocalDate.parse("2024-12-26"), respuesta.ultimosMovimientos().get(4).fecha());
    }

    @Test
    @DisplayName("Cada movimiento del movil tiene exactamente tres campos: sin descripcion y sin origen")
    void elMovimientoDelMovilLlevaTresCamposYNadaMas() {
        // La prueba fuerte no es lo que el record trae, sino lo que NO puede traer. Si alguien
        // agregara "descripcion" para que el movil se parezca a web, esta linea cae.
        assertEquals(3, MovimientoMovilResponse.class.getRecordComponents().length,
                "El movimiento del canal movil debe tener solo fecha, tipo y monto");
    }

    @Test
    @DisplayName("El nombre completo del titular no sale del canal: viaja abreviado")
    void aplicaLaMinimizacionDeDatosAlTitular() {
        ResumenMovilResponse respuesta =
                servicio(new CoreClientFalso(cuenta116(List.of()))).obtenerResumen(116, 116);

        assertEquals("D. Prince", respuesta.titular());
        assertEquals(new BigDecimal("12000.00"), respuesta.saldo());
        assertEquals("CLP", respuesta.moneda());
    }

    @Test
    @DisplayName("Caso borde de la cuenta 130: la lista sale vacia, nunca nula y nunca como error")
    void cuentaSinMovimientosDevuelveListaVacia() {
        CuentaCoreDto cuenta130 = new CuentaCoreDto(
                130, "John Doe", "PRESTAMO", new BigDecimal("5000.00"), 25, "CLP", List.of());

        ResumenMovilResponse respuesta =
                servicio(new CoreClientFalso(cuenta130)).obtenerResumen(130, 130);

        assertTrue(respuesta.ultimosMovimientos().isEmpty(),
                "una cuenta sin movimientos debe devolver [] y nunca null");
        assertEquals("J. Doe", respuesta.titular());
    }

    @Test
    @DisplayName("Deja pasar la excepcion del core sin atraparla")
    void noAtrapaLosFallosDelCore() {
        // El servicio no lleva try/catch a proposito: la excepcion con nombre sube hasta el
        // manejador de errores del canal, que es el unico que sabe traducirla a RFC 7807 con el
        // campo canal en MOVIL.
        CoreClient core = new CoreClientFalso(null);

        assertThrows(CoreRecursoNoEncontradoException.class,
                () -> servicio(core).obtenerResumen(999, 999));
    }

    @Test
    @DisplayName("La cuenta ajena se rechaza ANTES de llamar al core, y por eso el doble no se usa")
    void cuentaAjenaNoLlegaAlCore() {
        // El doble lanza UnsupportedOperationException si alguien le pide algo. Aqui se le pasa uno
        // que si sabria responder: si la comprobacion de titularidad se hiciera despues de la
        // llamada, esta prueba pasaria igual y no probaria nada. Lo que se verifica es que la
        // excepcion sea CuentaAjenaException y no una del core, es decir que el viaje no ocurrio.
        CoreClient core = new CoreClientFalso(cuenta116(List.of()));

        assertThrows(CuentaAjenaException.class,
                () -> servicio(core).obtenerResumen(105, 116));
    }

    @Test
    @DisplayName("Una cuenta ajena que ademas no existe da cuenta_ajena, no 404")
    void cuentaAjenaEInexistenteNoDelataSuInexistencia() {
        // El doble no tiene cuenta, asi que responderia CoreRecursoNoEncontradoException si se le
        // preguntara. No se le pregunta: primero la titularidad. Esto es lo que impide que el
        // endpoint funcione como detector de cuentas existentes para cualquiera con token valido.
        CoreClient core = new CoreClientFalso(null);

        assertThrows(CuentaAjenaException.class,
                () -> servicio(core).obtenerResumen(999, 116));
    }

    @Test
    @DisplayName("Un token sin claim cuentaId no acredita nada: tambien es cuenta ajena")
    void tokenSinCuentaNoEsLlaveMaestra() {
        // El ejecutivo del canal web no lleva cuentaId, porque audita en vez de consultar su saldo.
        // Ese token no existe en este canal, pero la regla tiene que ser explicita: tratar la
        // ausencia del claim como "no aplica la comprobacion" convertiria un token incompleto en
        // una llave maestra sobre las 50 cuentas.
        CoreClient core = new CoreClientFalso(cuenta116(List.of()));

        assertThrows(CuentaAjenaException.class,
                () -> servicio(core).obtenerResumen(116, null));
    }

    /**
     * Doble de prueba escrito a mano, igual que en el canal cajero y por el mismo motivo: los
     * metodos que este canal no usa lanzan {@code UnsupportedOperationException}, de modo que si
     * el movil empezara a llamarlos la prueba lo dice en voz alta en vez de devolver un nulo.
     */
    private record CoreClientFalso(CuentaCoreDto cuenta) implements CoreClient {

        @Override
        public CuentaCoreDto obtenerCuenta(int cuentaId) {
            if (cuenta == null) {
                throw new CoreRecursoNoEncontradoException(
                        "cuenta inexistente", "/internal/v1/cuentas/" + cuentaId, null);
            }
            return cuenta;
        }

        @Override
        public SaldoCoreDto obtenerSaldo(int cuentaId) {
            // El movil necesita saldo Y movimientos en la misma pantalla: pedir los dos por
            // separado serian dos viajes al core para una sola respuesta.
            throw new UnsupportedOperationException("El movil resuelve la pantalla con una sola llamada");
        }

        @Override
        public PaginaMovimientosCoreDto obtenerMovimientos(int cuentaId, ConsultaMovimientosCoreDto consulta) {
            throw new UnsupportedOperationException("El movil no expone paginacion");
        }

        @Override
        public RetiroCoreDto ejecutarRetiro(int cuentaId, SolicitudRetiroCoreDto solicitud, String claveIdempotencia) {
            throw new UnsupportedOperationException("El retiro es exclusivo del cajero");
        }

        @Override
        public ReporteCalidadCoreDto obtenerCalidadDatos() {
            throw new UnsupportedOperationException("La auditoria es del canal web");
        }

        @Override
        public PaginaTransaccionesCoreDto obtenerTransaccionesNoConciliadas(int pagina, int tamano) {
            throw new UnsupportedOperationException("La auditoria es del canal web");
        }
    }
}
