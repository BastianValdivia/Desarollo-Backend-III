package cl.duoc.bancoxyz.bff.mobile.config;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import cl.duoc.bancoxyz.bff.mobile.seguridad.VinculacionDispositivo;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * El ETag del canal movil (M2), comprobado de extremo a extremo.
 *
 * <h2>Por que estas pruebas existen</h2>
 *
 * <p>Las tres afirmaciones que sostienen el ahorro de ancho de banda de este canal fallan, las
 * tres, <strong>en silencio</strong>. Ninguna produce un error, una excepcion ni una linea en el
 * log: simplemente el ahorro no aparece, y eso es facil de atribuir a cualquier otra cosa. Las
 * tres se descubrieron mirando la respuesta con {@code curl -D}, no leyendo el codigo:
 *
 * <ol>
 *   <li><strong>El patron del filtro.</strong> Un patron de servlet no admite comodin en medio, y
 *       tampoco lleva el {@code context-path}. Escrito mal, el filtro se registra, arranca y no
 *       casa con nada.</li>
 *   <li><strong>La etiqueta debil.</strong> Tomcat se niega a comprimir una respuesta con ETag
 *       fuerte, asi que ETag y gzip se anulaban mutuamente.</li>
 *   <li><strong>El {@code Cache-Control}.</strong> Con el {@code no-store} que Spring Security
 *       pone por defecto, el telefono no guarda copia, nunca envia {@code If-None-Match} y el
 *       304 no llega a ocurrir jamas.</li>
 * </ol>
 *
 * <p>Una optimizacion que puede desaparecer sin avisar necesita una prueba que la vigile. Esa es
 * la unica razon de este archivo.
 */
@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("Canal movil: ETag debil, 304 y Cache-Control que lo hace posible")
class EtagMovilTest {

    private static final String RUTA_RESUMEN = "/v1/cuentas/116/resumen";

    /**
     * Identificador de dispositivo de la seccion 8 del contrato.
     *
     * <p>Se escribe el literal en vez de reutilizar la constante de {@code TokenDePrueba}, que es
     * de otro paquete y no es publica. Ampliar su visibilidad solo para esta prueba seria cambiar
     * codigo existente por comodidad de una prueba nueva, y el literal viene igualmente del
     * contrato, que es la fuente de verdad de los dos sitios.
     */
    private static final String DISPOSITIVO = "dispositivo-demo-01";

    @Autowired
    private MockMvc mvc;

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }


    @Autowired
    private CacheManager gestorDeCaches;

    @MockBean
    private CoreClient core;

    @BeforeEach
    void preparar() {
        when(core.obtenerCuenta(116)).thenReturn(cuenta116());
        gestorDeCaches.getCacheNames()
                .forEach(nombre -> gestorDeCaches.getCache(nombre).clear());
    }

    @Test
    @DisplayName("M2 responde con ETag, y la etiqueta es DEBIL (empieza por W/)")
    void elResumenLlevaEtagDebil() throws Exception {
        MvcResult respuesta = pedirResumen().andExpect(status().isOk()).andReturn();

        String etag = respuesta.getResponse().getHeader(HttpHeaders.ETAG);

        assertThat(etag)
                .describedAs("sin ETag no hay 304 posible. Si es null, lo mas probable es que el "
                        + "patron de OptimizacionMovilConfig.RUTA_RESUMEN dejo de casar")
                .isNotNull();

        assertThat(etag)
                .describedAs("la etiqueta DEBE ser debil. Con una etiqueta fuerte, Tomcat se niega "
                        + "a comprimir la respuesta y el canal pierde la mitad de su ahorro de "
                        + "transferencia, sin que nada avise")
                .startsWith("W/\"");
    }

    @Test
    @DisplayName("reenviar el ETag en If-None-Match produce 304 y un cuerpo VACIO")
    void elSegundoViajeNoTraeCuerpo() throws Exception {
        String etag = pedirResumen().andReturn().getResponse().getHeader(HttpHeaders.ETAG);

        MvcResult segunda = mvc.perform(get(RUTA_RESUMEN)
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                        .header(VinculacionDispositivo.CABECERA, DISPOSITIVO)
                        .header(HttpHeaders.IF_NONE_MATCH, etag))
                .andExpect(status().isNotModified())
                .andReturn();

        // Este cero es el ahorro entero del mecanismo: el resumen pesa 368 bytes sin comprimir y
        // 193 comprimido; un 304 pesa 0. En un canal que se consulta muchas veces al dia y cuyo
        // saldo cambia pocas veces al dia, la mayoria de las consultas puede costar esto.
        assertThat(segunda.getResponse().getContentAsByteArray())
                .describedAs("un 304 no puede traer cuerpo: si lo trae, no se ahorro nada")
                .isEmpty();
    }

    @Test
    @DisplayName("M2 responde no-cache (no no-store), que es lo que permite el 304")
    void elCacheControlPermiteRevalidar() throws Exception {
        MvcResult respuesta = pedirResumen().andExpect(status().isOk()).andReturn();
        String cacheControl = respuesta.getResponse().getHeader(HttpHeaders.CACHE_CONTROL);

        // no-cache y no-store se parecen y significan cosas distintas:
        //   no-store  = no guardes ninguna copia         -> el ETag no serviria de nada
        //   no-cache  = guarda copia, pero revalidala    -> es exactamente el flujo del ETag
        // Si alguien "endurece" esta cabecera a no-store creyendo que mejora la seguridad, el
        // ETag seguira apareciendo en la respuesta y el 304 no volvera a ocurrir nunca.
        assertThat(cacheControl).contains("no-cache");
        assertThat(cacheControl)
                .describedAs("no-store aqui desactivaria el ETag en silencio")
                .doesNotContain("no-store");

        // private: la copia la guarda el telefono, nunca un intermediario compartido. El saldo de
        // un cliente no debe quedar en la cache de un proxy por el que pasan los datos de otros.
        assertThat(cacheControl).contains("private");
    }

    private org.springframework.test.web.servlet.ResultActions pedirResumen() throws Exception {
        return mvc.perform(get(RUTA_RESUMEN)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                .header(VinculacionDispositivo.CABECERA, DISPOSITIVO));
    }

    /** El token que el auth-server emite a cliente116 en mobile-app, atado a DISPOSITIVO. */
    private static String tokenMovil() {
        return EmisorDePrueba.compartido().clienteMovil116(DISPOSITIVO).emitir();
    }

    private static CuentaCoreDto cuenta116() {
        return new CuentaCoreDto(116, "Diana Prince", "CUENTA_VISTA",
                new BigDecimal("12000.00"), 30, "CLP",
                List.of(new MovimientoCoreDto(
                        LocalDate.of(2024, 12, 24), "COMPRA", new BigDecimal("2500.00"),
                        "Compra de prueba", "CSV_SEMILLA")));
    }
}
