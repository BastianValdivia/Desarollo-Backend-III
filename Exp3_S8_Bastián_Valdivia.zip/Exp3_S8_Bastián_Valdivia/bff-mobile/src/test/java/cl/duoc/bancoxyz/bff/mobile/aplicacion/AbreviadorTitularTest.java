package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Locale;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Pruebas de la abreviacion del titular, la regla de minimizacion de datos del canal movil.
 *
 * <p><strong>Por que una regla de tres lineas merece cinco pruebas.</strong> Porque no es
 * formateo: es el unico lugar del canal donde se decide cuanto dato personal sale hacia el
 * telefono. Un fallo aqui no rompe nada visible (la aplicacion sigue mostrando un nombre) y por
 * eso mismo puede vivir meses sin que nadie lo note, mientras el canal entrega mas de lo que
 * declara entregar. Las pruebas de las reglas silenciosas son las que mas valen.
 *
 * <p>Los casos elegidos son los tres borde que el javadoc del metodo declara resolver (nulo, en
 * blanco y una sola palabra) mas los dos que cambian el resultado sin que la prueba obvia lo
 * detecte: el nombre compuesto, donde recortar a la ultima palabra devolveria a otra persona, y
 * el locale, donde la respuesta cambiaria segun la configuracion regional de la maquina.
 */
class AbreviadorTitularTest {

    @Test
    @DisplayName("El caso congelado del contrato: Diana Prince se proyecta como D. Prince")
    void abreviaElNombreDePilaYConservaElApellido() {
        // La cuenta 116 y su titular son los valores congelados de la seccion 9 del contrato, y
        // el ejemplo literal de la seccion 5.10. Si esta linea cambia, cambia la evidencia.
        assertEquals("D. Prince", AbreviadorTitular.abreviar("Diana Prince"));
    }

    @Test
    @DisplayName("Un nombre compuesto conserva TODO el resto, no solo la ultima palabra")
    void noAdivinaCualDeLasPalabrasDelMedioEsElApellido() {
        // Recortar a la ultima palabra daria "A. Soto" y "J. Soto": dos personas distintas
        // colapsadas en el mismo texto. La minimizacion de datos no puede volverse corrupcion de
        // datos, asi que solo se abrevia aquello de lo que hay certeza.
        assertEquals("A. Perez Soto", AbreviadorTitular.abreviar("Ana Perez Soto"));
        assertEquals("J. Pablo Soto", AbreviadorTitular.abreviar("Juan Pablo Soto"));
    }

    @Test
    @DisplayName("Una sola palabra se devuelve entera: abreviarla dejaria de identificar a nadie")
    void noAbreviaLoQueNoTieneApellido() {
        // "M." no cumple la funcion que justificaba el recorte, que es que el usuario reconozca
        // su propia cuenta.
        assertEquals("Madonna", AbreviadorTitular.abreviar("Madonna"));
    }

    @Test
    @DisplayName("Un titular raro no le niega el saldo a un cliente: nulo y blanco pasan sin fallar")
    void losCasosBordeDevuelvenLaEntradaEnVezDeLanzar() {
        assertEquals(null, AbreviadorTitular.abreviar(null));
        assertEquals("", AbreviadorTitular.abreviar(""));
        assertEquals("   ", AbreviadorTitular.abreviar("   "));
    }

    @Test
    @DisplayName("La inicial no depende del locale de la maquina que ejecuta el BFF")
    void laMayusculaSeCalculaConLocaleRoot() {
        // En turco, "i".toUpperCase() con el locale por defecto no da "I" sino "I" con punto.
        // Sin Locale.ROOT, el mismo titular se abreviaria distinto en dos servidores del mismo
        // banco, que es un error que no aparece jamas en la maquina de quien programa.
        Locale original = Locale.getDefault();
        try {
            Locale.setDefault(Locale.forLanguageTag("tr"));
            assertEquals("I. Soto", AbreviadorTitular.abreviar("Ines Soto"));
        } finally {
            Locale.setDefault(original);
        }
    }
}
