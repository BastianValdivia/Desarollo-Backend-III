package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * La cache del canal movil, comprobada por su efecto sobre el core.
 *
 * <p>Levanta el contexto de Spring porque es la unica forma de que el proxy de {@code @Cacheable}
 * exista: una instancia creada con {@code new} no cachea, y una prueba escrita asi pasaria en verde
 * con la anotacion borrada.
 */
@SpringBootTest
@DisplayName("Cache del canal movil: TTL 30 s y la titularidad que se comprueba siempre")
class CacheCuentaMovilTest {

    @Autowired
    private CacheCuentaMovil cache;

    @Autowired
    private ResumenMovilService servicio;

    @Autowired
    private CacheManager gestorDeCaches;

    @MockBean
    private CoreClient core;

    /**
     * Una cache es estado que sobrevive entre metodos de prueba. Sin este borrado, el resultado de
     * cada prueba dependeria del orden en que JUnit las ejecute.
     */
    @BeforeEach
    void vaciarCache() {
        gestorDeCaches.getCacheNames()
                .forEach(nombre -> gestorDeCaches.getCache(nombre).clear());
        given(core.obtenerCuenta(anyInt())).willReturn(cuentaDemo(116));
    }

    @Test
    @DisplayName("cinco consultas del mismo resumen producen UNA llamada al core")
    void elResumenRepetidoNoViajaCincoVeces() {
        for (int i = 0; i < 5; i++) {
            servicio.obtenerResumen(116, 116);
        }

        verify(core, times(1)).obtenerCuenta(116);
    }

    @Test
    @DisplayName("con la cuenta cacheada, un titular ajeno sigue siendo rechazado")
    void elAciertoDeCacheNoSaltaLaTitularidad() {
        // Se calienta la cache con el titular legitimo...
        servicio.obtenerResumen(116, 116);
        assertThat(gestorDeCaches.getCache(CacheCuentaMovil.NOMBRE_CACHE).get(116)).isNotNull();

        // ...y ahora otro usuario pide la misma cuenta, que YA esta en memoria. Si la
        // comprobacion viviera dentro del metodo cacheado, no se ejecutaria y esto devolveria
        // los datos de otro cliente. Es el fallo que esta prueba existe para impedir.
        assertThatThrownBy(() -> servicio.obtenerResumen(116, 105))
                .isInstanceOf(CuentaAjenaException.class);
    }

    @Test
    @DisplayName("la cache se llama 'resumen-movil', como dice el contrato")
    void laCacheSeLlamaComoDiceElContrato() {
        cache.obtenerCuenta(116);

        // Un nombre mal escrito en el @Cacheable no da error: Spring crea una cache nueva en
        // silencio, y la dconfig-repo/bff-mobile.yml (con su TTL de 30 s y su tope de 2000 entradas) no
        // se usa nunca. El sintoma seria una cache que no expira jamas.
        assertThat(gestorDeCaches.getCacheNames()).contains(CacheCuentaMovil.NOMBRE_CACHE);
    }

    private static CuentaCoreDto cuentaDemo(int cuentaId) {
        return new CuentaCoreDto(cuentaId, "Diana Prince", "CUENTA_VISTA",
                new BigDecimal("12000.00"), 30, "CLP",
                List.of(new MovimientoCoreDto(
                        LocalDate.of(2024, 12, 24), "COMPRA", new BigDecimal("2500.00"),
                        "Compra de prueba", "CSV_SEMILLA")));
    }
}
