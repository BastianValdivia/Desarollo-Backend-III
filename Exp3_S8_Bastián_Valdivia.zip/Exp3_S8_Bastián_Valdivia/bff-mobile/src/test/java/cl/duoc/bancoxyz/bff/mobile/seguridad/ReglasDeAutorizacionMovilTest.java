package cl.duoc.bancoxyz.bff.mobile.seguridad;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import cl.duoc.bancoxyz.bff.mobile.aplicacion.RegistroDispositivos;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;

/**
 * Las reglas de seguridad del canal movil, ejercidas de extremo a extremo sobre
 * la cadena de filtros real.
 *
 * <h2>Por que estas pruebas valen mas que la media</h2>
 *
 * <p>Una regla de autorizacion que falla lo hace <b>en silencio</b>. Si la
 * vinculacion de dispositivo dejara de aplicarse, ningun log lo diria, ninguna
 * excepcion saltaria y la aplicacion movil seguiria funcionando exactamente
 * igual: solo que tambien desde un telefono ajeno. Lo mismo vale para el
 * prefijo de autoridades mal enlazado (todo responderia 403) o para una regla
 * de ruta que nadie declaro (todo respondera 200). Ninguno de esos tres fallos
 * produce un sintoma que apunte a su causa, y por eso se prueban.
 *
 * <p>Se usa {@code @SpringBootTest} con {@code MockMvc} y no una prueba de
 * unidad: lo que hay que verificar no es una clase, es el <b>orden</b> en que
 * la cadena de filtros aplica las reglas. Una prueba que instanciara el filtro
 * a mano pasaria aunque el filtro estuviera mal registrado, que es exactamente
 * el error que mas se comete.
 *
 * <p>El {@code CoreClient} se sustituye por un doble porque estas pruebas no
 * hablan del core: si el 403 se decide antes de llamarlo, como exige el
 * contrato, el doble ni siquiera se usa, y eso tambien se verifica.
 */
@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("Reglas de seguridad del canal movil")
class ReglasDeAutorizacionMovilTest {

    private static final String RUTA_RESUMEN = "/v1/cuentas/116/resumen";
    private static final String RUTA_BAJA = "/v1/dispositivos/baja";

    private static final String DISPOSITIVO = "dispositivo-demo-01";

    private final EmisorDePrueba emisor = EmisorDePrueba.compartido();

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;

    @MockBean
    private CoreClient core;

    @Autowired
    private RegistroDispositivos registroDeDispositivos;

    @BeforeEach
    void prepararCore() {
        when(core.obtenerCuenta(116)).thenReturn(cuenta116());

        // AISLAMIENTO ENTRE PRUEBAS, y no es una formalidad.
        //
        // El registro de bajas es un bean unico de todo el contexto, y una de
        // las pruebas de mas abajo da de baja el dispositivo compartido. Sin
        // esta linea, esa prueba se lo deja dado de baja a todas las que corran
        // despues, y el login de cualquiera de ellas responde
        // dispositivo_no_coincide en vez de lo que espera.
        //
        // La dependencia del orden existia desde el primer dia; quedo a la vista
        // recien cuando el login empezo a consultar la baja de verdad. Sirve de
        // recordatorio: que una suite este en verde no prueba que sus casos sean
        // independientes entre si.
        registroDeDispositivos.limpiar();
    }

    // =================================================================
    // 1. Sin credencial: 401, y con el motivo exacto del contrato
    // =================================================================

    @Nested
    @DisplayName("Sin token")
    class SinToken {

        @Test
        @DisplayName("El resumen responde 401 token_ausente y lleva WWW-Authenticate")
        void resumenSinTokenEs401() throws Exception {
            mvc.perform(get(RUTA_RESUMEN).header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isUnauthorized())
                    .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
                    .andExpect(jsonPath("$.motivo").value("token_ausente"))
                    .andExpect(jsonPath("$.canal").value("MOVIL"))
                    .andExpect(jsonPath("$.status").value(401))
                    // El envoltorio RFC 7807 completo, no una pagina de error de
                    // Spring: es lo que se pierde si falta el punto de entrada
                    // propio, y no se nota hasta que un guion busca "motivo".
                    .andExpect(jsonPath("$.type").value("https://bancoxyz.duoc.cl/errores/token-ausente"))
                    .andExpect(jsonPath("$.instance").value(RUTA_RESUMEN));
        }

        @Test
        @DisplayName("La baja de dispositivo tambien esta cerrada sin token")
        void bajaSinTokenEs401() throws Exception {
            mvc.perform(post(RUTA_BAJA).header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_ausente"));
        }

        @Test
        @DisplayName("Una cabecera Authorization sin el esquema Bearer cuenta como token ausente")
        void authorizationSinEsquemaBearerEs401() throws Exception {
            // El contrato lo dice literalmente: token_ausente cubre que no
            // llegue la cabecera Y que llegue sin el esquema Bearer.
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Basic Y2xpZW50ZTExNjpNb3YuMjAyNg==")
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_ausente"));
        }

        /**
         * Solo se ejerce porque en las pruebas el servicio y Actuator comparten puerto. En el
         * despliegue (desde F1) Actuator vive en un puerto de gestion aparte y sin token, y esta
         * ruta, pedida en el puerto del canal, responde 401 sin token y 404 con token. Lo que la
         * prueba protege es la red de seguridad {@code anyRequest().authenticated()}.
         */
        @Test
        @DisplayName("Las metricas exigen token: Actuator no queda abierto por ser Actuator")
        void metricasSinTokenEs401() throws Exception {
            mvc.perform(get("/actuator/metrics/jvm.memory.used"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_ausente"));
        }

        @Test
        @DisplayName("La salud si es publica, para que el guion de arranque pueda esperar")
        void saludEsPublica() throws Exception {
            mvc.perform(get("/actuator/health"))
                    .andExpect(status().isOk());
        }
    }

    // =================================================================
    // 2. Login: la credencial de tres partes de este canal
    // =================================================================

    @Nested
    @DisplayName("Vinculacion al dispositivo")
    class Vinculacion {

        @Test
        @DisplayName("Token correcto y dispositivo correcto: 200")
        void caminoFeliz() throws Exception {
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.cuentaId").value(116))
                    .andExpect(jsonPath("$.titular").value("D. Prince"));
        }

        @Test
        @DisplayName("El mismo token desde OTRO telefono: 401 dispositivo_no_coincide")
        void tokenRobadoDesdeOtroTelefonoEs401() throws Exception {
            // Es la prueba que justifica toda la medida: el token es perfecto,
            // la firma valida y le quedan 59 minutos de vida. No basta.
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                            .header(VinculacionDispositivo.CABECERA, "telefono-del-ladron"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
                    .andExpect(jsonPath("$.motivo").value("dispositivo_no_coincide"));

            verify(core, never()).obtenerCuenta(anyInt());
        }

        @Test
        @DisplayName("Sin la cabecera: tambien 401, porque no hay dispositivo acreditado")
        void tokenSinCabeceraDeDispositivoEs401() throws Exception {
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil()))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("dispositivo_no_coincide"));
        }

        @Test
        @DisplayName("El rechazo ocurre ANTES de la regla de autoridad: es 401, no 403")
        void elDispositivoSeComprubaAntesQueLosPermisos() throws Exception {
            // Token sin ningun permiso Y desde otro dispositivo. Si el filtro
            // estuviera registrado despues del de autorizacion, esto saldria
            // 403 y el orden del contrato (autenticacion, autoridad,
            // titularidad) estaria roto sin que nada mas lo delatara.
            String token = tokenConAutoridades(List.of("ROLE_CLIENTE_MOVIL"));

            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                            .header(VinculacionDispositivo.CABECERA, "otro-telefono"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("dispositivo_no_coincide"));
        }
    }

    // =================================================================
    // 4. Las dos barreras que hacen que un token de otro canal no sirva
    // =================================================================

    @Nested
    @DisplayName("Tokens del auth-server y barreras entre canales")
    class Barreras {

        @Test
        @DisplayName("Matriz 3x3, fila del canal movil: el token web y el del cajero, con firma valida, se rechazan por AUDIENCIA (401 audiencia_invalida)")
        void lasCeldasCruzadasSon401PorAudiencia() throws Exception {
            for (String ajeno : List.of(
                    emisor.clienteWeb116().emitir(),
                    emisor.tarjeta116().emitir(),
                    emisor.clienteMovil116(DISPOSITIVO).audiencia("core-service").emitir())) {
                mvc.perform(get(RUTA_RESUMEN)
                                .header(HttpHeaders.AUTHORIZATION, "Bearer " + ajeno)
                                .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                        .andExpect(status().isUnauthorized())
                        .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
                        .andExpect(jsonPath("$.motivo").value("audiencia_invalida"));
            }
            verify(core, never()).obtenerCuenta(anyInt());
        }

        @Test
        @DisplayName("La diagonal: el token movil con audiencia bff-mobile entra")
        void laDiagonalEntra() throws Exception {
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isOk());
        }

        @Test
        @DisplayName("Un token firmado con una clave que el auth-server no publica es 401 firma_invalida")
        void tokenFirmadoConOtraClaveEs401() throws Exception {
            String ajeno = emisor.clienteMovil116(DISPOSITIVO).firmadoPorOtraClave().emitir();
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + ajeno)
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isUnauthorized())
                    .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
                    .andExpect(jsonPath("$.motivo").value("firma_invalida"));
        }

        @Test
        @DisplayName("Un token de otro emisor (el emisor propio del S5) es 401 firma_invalida aunque este bien firmado")
        void otroEmisorSeRechaza() throws Exception {
            String deOtroEmisor = emisor.clienteMovil116(DISPOSITIVO)
                    .conEmisor("https://bancoxyz.duoc.cl/bff-mobile").emitir();
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + deOtroEmisor)
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("firma_invalida"));
        }

        @Test
        @DisplayName("Un token vencido es 401 token_expirado, y uno sin firma (alg none) tambien es 401")
        void vencidoYSinFirma() throws Exception {
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION,
                                    "Bearer " + emisor.clienteMovil116(DISPOSITIVO).vencido().emitir())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_expirado"));
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION,
                                    "Bearer " + emisor.clienteMovil116(DISPOSITIVO).emitirSinFirma())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isUnauthorized());
        }

        @Test
        @DisplayName("Un token valido SIN claim device_id no acredita dispositivo: 401 dispositivo_no_coincide, aunque la cabecera venga")
        void tokenSinDispositivo() throws Exception {
            String sinDispositivo = emisor.clienteMovil116(DISPOSITIVO).sin("device_id").emitir();
            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + sinDispositivo)
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("dispositivo_no_coincide"));
        }

        @Test
        @DisplayName("El canal ya no emite tokens ni tiene login: POST /auth/login es 401 sin token y 404 con uno")
        void yaNoHayLogin() throws Exception {
            mvc.perform(post("/auth/login").contentType("application/json")
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO)
                            .content("{\"usuario\":\"cliente116\",\"clave\":\"Cliente.2026\"}"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_ausente"));
            mvc.perform(post("/auth/login").contentType("application/json")
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO)
                            .content("{\"usuario\":\"cliente116\",\"clave\":\"Cliente.2026\"}"))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.motivo").value("recurso_no_encontrado"));
        }
    }

    @Nested
    @DisplayName("Autorizacion")
    class Autorizacion {

        @Test
        @DisplayName("Nivel de OPERACION: sin PERM_dispositivo:gestionar la baja da 403 permiso_insuficiente")
        void bajaSinElPermisoEs403() throws Exception {
            String sinPermiso = tokenConAutoridades(List.of("ROLE_CLIENTE_MOVIL", "PERM_saldo:leer"));

            mvc.perform(post(RUTA_BAJA)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + sinPermiso)
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"))
                    // Un 403 NUNCA lleva WWW-Authenticate: a quien ya se
                    // identifico no se le pide repetir un login que no
                    // cambiaria nada.
                    .andExpect(header().doesNotExist(HttpHeaders.WWW_AUTHENTICATE));
        }

        @Test
        @DisplayName("Nivel de OPERACION: sin PERM_saldo:leer el resumen da 403 permiso_insuficiente")
        void resumenSinElPermisoEs403() throws Exception {
            String sinPermiso = tokenConAutoridades(List.of("ROLE_CLIENTE_MOVIL"));

            mvc.perform(get(RUTA_RESUMEN)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + sinPermiso)
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"));
        }

        @Test
        @DisplayName("Nivel de DATO: la cuenta de otro da 403 cuenta_ajena y no llega al core")
        void cuentaAjenaEs403() throws Exception {
            mvc.perform(get("/v1/cuentas/105/resumen")
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("cuenta_ajena"))
                    .andExpect(jsonPath("$.status").value(403));

            // La titularidad se comprueba ANTES de llamar al core. Es lo que
            // impide que el endpoint funcione como detector de cuentas
            // existentes, y de paso ahorra el viaje.
            verify(core, never()).obtenerCuenta(105);
        }

        @Test
        @DisplayName("Una cuenta ajena que ademas no existe tambien da 403, nunca 404")
        void cuentaAjenaEInexistenteEs403() throws Exception {
            mvc.perform(get("/v1/cuentas/999/resumen")
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("cuenta_ajena"));

            verify(core, never()).obtenerCuenta(999);
        }
    }

    // =================================================================
    // 6. El endpoint exclusivo del canal
    // =================================================================

    @Nested
    @DisplayName("Baja de dispositivo, exclusiva del canal movil")
    class BajaDeDispositivo {

        @Test
        @DisplayName("Con el permiso correcto responde los tres campos congelados")
        void bajaExitosa() throws Exception {
            mvc.perform(post(RUTA_BAJA)
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isOk())
                    // El dispositivo sale del TOKEN, no de un cuerpo: un
                    // telefono solo puede darse de baja a si mismo.
                    .andExpect(jsonPath("$.dispositivoId").value(DISPOSITIVO))
                    .andExpect(jsonPath("$.estado").value("DADO_DE_BAJA"))
                    .andExpect(jsonPath("$.dadoDeBajaEn").exists());
        }

        @Test
        @DisplayName("Tras la baja, el token de ESE dispositivo deja de servir en el resto de las rutas: 401 dispositivo_no_coincide")
        void trasLaBajaElTokenDejaDeServir() throws Exception {
            String token = emisor.clienteMovil116("dispositivo-baja-01").emitir();
            mvc.perform(get(RUTA_RESUMEN).header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                            .header(VinculacionDispositivo.CABECERA, "dispositivo-baja-01"))
                    .andExpect(status().isOk());

            mvc.perform(post(RUTA_BAJA).header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                            .header(VinculacionDispositivo.CABECERA, "dispositivo-baja-01"))
                    .andExpect(status().isOk());

            mvc.perform(get(RUTA_RESUMEN).header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                            .header(VinculacionDispositivo.CABECERA, "dispositivo-baja-01"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
                    .andExpect(jsonPath("$.motivo").value("dispositivo_no_coincide"));
            // Y un token NUEVO del mismo dispositivo (otro inicio de sesion en el auth-server) tampoco sirve.
            String nuevo = emisor.clienteMovil116("dispositivo-baja-01").emitir();
            mvc.perform(get(RUTA_RESUMEN).header(HttpHeaders.AUTHORIZATION, "Bearer " + nuevo)
                            .header(VinculacionDispositivo.CABECERA, "dispositivo-baja-01"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("dispositivo_no_coincide"));
        }

        @Test
        @DisplayName("La baja es idempotente con el mismo token: repetirla devuelve el mismo instante, y no afecta a otros dispositivos")
        void laBajaEsIdempotenteYNoAlcanzaAOtros() throws Exception {
            String token = emisor.clienteMovil116("dispositivo-baja-02").emitir();
            String primera = mvc.perform(post(RUTA_BAJA).header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                            .header(VinculacionDispositivo.CABECERA, "dispositivo-baja-02"))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            String segunda = mvc.perform(post(RUTA_BAJA).header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                            .header(VinculacionDispositivo.CABECERA, "dispositivo-baja-02"))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            org.assertj.core.api.Assertions.assertThat(segunda).isEqualTo(primera);

            // El dispositivo de la demostracion sigue funcionando.
            mvc.perform(get(RUTA_RESUMEN).header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isOk());
        }

        @Test
        @DisplayName("Una ruta de otro canal responde 404, no 403: aqui no existe")
        void rutaDeOtroCanalEs404() throws Exception {
            // /v1/cuentas/{id}/resumen-mensual es exclusivo del canal web. Con
            // un token valido de este canal la respuesta correcta es 404: la
            // operacion no existe aqui. Un 403 diria "existe y no puedes", que
            // seria informacion sobre el sistema que este canal no publica.
            mvc.perform(get("/v1/cuentas/116/resumen-mensual")
                            .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenMovil())
                            .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.motivo").value("recurso_no_encontrado"));
        }
    }

    // =================================================================
    // Utilidades
    // =================================================================

    /** El token que el auth-server emite a cliente116 en mobile-app, atado al dispositivo de la demostracion. */
    private String tokenMovil() {
        return emisor.clienteMovil116(DISPOSITIVO).emitir();
    }

    /** El mismo token con otras autoridades (para probar las reglas de operacion). */
    private String tokenConAutoridades(List<String> autoridades) {
        return emisor.clienteMovil116(DISPOSITIVO).claim("authorities", autoridades).emitir();
    }

    private CuentaCoreDto cuenta116() {
        return new CuentaCoreDto(116, "Diana Prince", "HIPOTECA", new BigDecimal("12000.00"), 30, "CLP",
                List.of(new MovimientoCoreDto(LocalDate.of(2024, 3, 8), "DEPOSITO",
                        new BigDecimal("3000.00"), "Retiro parcial", "CSV_SEMILLA")));
    }
}
