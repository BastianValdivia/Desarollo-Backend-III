package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Instant;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * El registro de dispositivos dados de baja: la base de la regla que corta la sesion de un telefono dado de baja
 * ({@code FiltroDispositivoMovil}, probada de punta a punta en {@code ReglasDeAutorizacionMovilTest}).
 *
 * <p>Antes de F5 esta clase se llamaba {@code BajaImpideNuevoLoginTest}: la baja impedia que el MISMO telefono
 * obtuviera un token nuevo en el login de este canal. Ese login ya no existe aqui (es del auth-server), y la regla
 * paso a aplicarse en cada peticion; lo que sigue valiendo, y se fija aqui, es la semantica del registro: un
 * dispositivo nuevo no figura de baja, la baja es idempotente y no alcanza a otros dispositivos.
 */
class RegistroDispositivosTest {

    private static final String DISPOSITIVO = "dispositivo-de-prueba-01";

    @Test
    @DisplayName("un dispositivo recien registrado no figura dado de baja")
    void dispositivoNuevoNoEstaDadoDeBaja() {
        RegistroDispositivos registro = new RegistroDispositivos();

        assertThat(registro.estaDadoDeBaja(DISPOSITIVO)).isFalse();
    }

    @Test
    @DisplayName("tras la baja, el dispositivo figura dado de baja")
    void trasLaBajaElDispositivoFigura() {
        RegistroDispositivos registro = new RegistroDispositivos();

        registro.darDeBaja(DISPOSITIVO, Instant.parse("2026-09-11T12:00:00Z"));

        assertThat(registro.estaDadoDeBaja(DISPOSITIVO)).isTrue();
    }

    @Test
    @DisplayName("la baja es idempotente: repetirla conserva el instante original")
    void laBajaEsIdempotente() {
        RegistroDispositivos registro = new RegistroDispositivos();
        Instant primera = Instant.parse("2026-09-11T12:00:00Z");
        Instant segunda = Instant.parse("2026-09-11T18:30:00Z");

        Instant resultadoPrimera = registro.darDeBaja(DISPOSITIVO, primera);
        Instant resultadoSegunda = registro.darDeBaja(DISPOSITIVO, segunda);

        // El telefono con mala cobertura reintenta y el guion de evidencia se
        // ejecuta dos veces. La segunda llamada debe responder lo mismo que la
        // primera, o el cliente no puede distinguir "ya estaba de baja" de "se
        // dio de baja ahora".
        assertThat(resultadoPrimera).isEqualTo(primera);
        assertThat(resultadoSegunda).isEqualTo(primera);
    }

    @Test
    @DisplayName("la baja de un dispositivo no afecta a los demas")
    void laBajaNoAlcanzaAOtrosDispositivos() {
        RegistroDispositivos registro = new RegistroDispositivos();

        registro.darDeBaja(DISPOSITIVO, Instant.parse("2026-09-11T12:00:00Z"));

        assertThat(registro.estaDadoDeBaja("otro-dispositivo-02")).isFalse();
    }
}
