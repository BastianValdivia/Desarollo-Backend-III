package cl.duoc.bancoxyz.bff.mobile.aplicacion;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.bff.mobile.api.dto.BajaDispositivoResponse;

/**
 * Pruebas del endpoint exclusivo del canal, M3.
 *
 * <p>El reloj se inyecta fijo. Esa es toda la razon por la que existe el bean
 * {@code Clock} del canal: con {@code Instant.now()} escrito dentro del
 * servicio, afirmar sobre el instante exacto de la respuesta seria imposible y
 * la unica alternativa seria una prueba que comprueba que el campo "existe",
 * que es justo la que no detecta el fallo del formato.
 */
class BajaDispositivoServiceTest {

    private static final String DISPOSITIVO = "dispositivo-demo-01";

    /** Un instante con milisegundos a proposito, para ver si el servicio los recorta. */
    private static final Instant INSTANTE = Instant.parse("2026-09-11T03:18:43.987Z");

    private final Clock reloj = Clock.fixed(INSTANTE, ZoneOffset.UTC);

    @Test
    @DisplayName("Devuelve los tres campos congelados, con el instante truncado a segundos")
    void respondeLosTresCamposDelContrato() {
        BajaDispositivoResponse respuesta =
                new BajaDispositivoService(new RegistroDispositivos(), reloj).darDeBaja(DISPOSITIVO);

        assertEquals(DISPOSITIVO, respuesta.dispositivoId());
        assertEquals("DADO_DE_BAJA", respuesta.estado());
        // Sin el truncado, Jackson imprimiria 2026-09-11T03:18:43.987Z y la
        // evidencia dejaria de parecerse al ejemplo del contrato. Es la clase
        // de diferencia que hace dudar de si el formato pactado se cumplio.
        assertEquals(Instant.parse("2026-09-11T03:18:43Z"), respuesta.dadoDeBajaEn());
    }

    @Test
    @DisplayName("Repetir la baja devuelve el MISMO instante: la operacion es idempotente")
    void repetirLaBajaNoCambiaLaFecha() {
        // Importa por dos motivos concretos: un telefono con mala cobertura
        // reintenta, y el guion de evidencia se ejecuta dos veces seguidas. Si
        // cada intento sobrescribiera la fecha, la segunda ejecucion daria una
        // respuesta distinta a la primera y el cliente no podria distinguir
        // "ya estaba de baja" de "se dio de baja ahora".
        RegistroDispositivos registro = new RegistroDispositivos();
        BajaDispositivoService servicio = new BajaDispositivoService(registro, reloj);

        Instant primera = servicio.darDeBaja(DISPOSITIVO).dadoDeBajaEn();

        // Segundo intento con un reloj adelantado una hora: aun asi tiene que
        // devolver el instante de la primera baja.
        BajaDispositivoService masTarde = new BajaDispositivoService(
                registro, Clock.fixed(INSTANTE.plusSeconds(3600), ZoneOffset.UTC));

        assertEquals(primera, masTarde.darDeBaja(DISPOSITIVO).dadoDeBajaEn());
    }

    @Test
    @DisplayName("La baja de un dispositivo no da de baja a los demas")
    void cadaDispositivoEsIndependiente() {
        RegistroDispositivos registro = new RegistroDispositivos();
        new BajaDispositivoService(registro, reloj).darDeBaja(DISPOSITIVO);

        assertTrue(registro.estaDadoDeBaja(DISPOSITIVO));
        assertFalse(registro.estaDadoDeBaja("otro-telefono"),
                "El registro guarda dispositivos concretos, no un interruptor global del canal");
    }
}
