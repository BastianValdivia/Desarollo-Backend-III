package cl.duoc.bancoxyz.bff.mobile.resiliencia;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import cl.duoc.bancoxyz.bff.mobile.aplicacion.RegistroDispositivos;
import cl.duoc.bancoxyz.bff.mobile.seguridad.VinculacionDispositivo;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.CoreClientProperties;
import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.core.RestCoreClient;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.CoreClientResiliente;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.RetryRegistry;

/**
 * La resiliencia del canal movil de punta a punta (ver {@code ResilienciaWebTest}): decorador real,
 * configuracion real de {@code config-repo/}, y solo el adaptador HTTP simulado.
 *
 * <p>Particularidad del movil: la respuesta de respaldo debe salir con {@code Cache-Control: no-store} y SIN
 * ETag, para que el telefono no guarde ni revalide con el el saldo viejo despues de que el core vuelva.
 */
@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("Resiliencia del canal movil")
class ResilienciaMovilTest {

    private static final String DISPOSITIVO = "dispositivo-demo-01";

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private CoreClient core;
    @Autowired
    private CoreClientProperties propiedadesDelCliente;
    @Autowired
    private CircuitBreakerRegistry circuitos;
    @Autowired
    private RetryRegistry reintentos;
    @Autowired
    private BulkheadRegistry mamparos;
    @Autowired
    private CacheManager caches;
    @Autowired
    private RegistroDispositivos registroDeDispositivos;
    @Autowired
    private RespaldoDeLecturas respaldo;

    @MockBean
    private RestCoreClient http;

    private final EmisorDePrueba emisor = EmisorDePrueba.compartido();

    @BeforeEach
    void limpiar() {
        circuito().reset();
        olvidarLaCacheDelCanal();
        reset(http);
        registroDeDispositivos.limpiar();
        // El respaldo es estado compartido del contexto: sin vaciarlo, un caso hereda el dato del anterior.
        respaldo.vaciar();
    }

    private CircuitBreaker circuito() {
        return circuitos.circuitBreaker("core");
    }

    private void olvidarLaCacheDelCanal() {
        caches.getCacheNames().forEach(nombre -> caches.getCache(nombre).clear());
    }

    private static CoreNoDisponibleException caida() {
        return new CoreNoDisponibleException("el core no respondio", "/internal/v1/cuentas/116", null, null, null);
    }

    private static CuentaCoreDto cuenta116() {
        return new CuentaCoreDto(116, "Diana Prince", "HIPOTECA", new BigDecimal("12000.00"), 30, "CLP",
                List.of(new MovimientoCoreDto(LocalDate.of(2024, 3, 8), "DEPOSITO", new BigDecimal("3000.00"),
                        "Deposito", "CSV_SEMILLA")));
    }

    private MockHttpServletRequestBuilder resumen() {
        return get("/v1/cuentas/116/resumen")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + emisor.clienteMovil116(DISPOSITIVO).emitir())
                .header(VinculacionDispositivo.CABECERA, DISPOSITIVO);
    }

    @Test
    @DisplayName("El canal usa el decorador y recibe de config-repo los valores de Resilience4j (mamparo de 20)")
    void laConfiguracionDeConfigRepoLlegaALosMecanismos() {
        assertThat(core).isInstanceOf(CoreClientResiliente.class);
        // Los limites de tiempo son los del cliente HTTP (el TimeLimiter no aplica a llamadas bloqueantes).
        assertThat(propiedadesDelCliente.timeoutConexion().toMillis()).isEqualTo(500);
        assertThat(propiedadesDelCliente.timeoutLectura().toSeconds()).isEqualTo(2);
        assertThat(circuito().getCircuitBreakerConfig().getSlidingWindowSize()).isEqualTo(10);
        assertThat(circuito().getCircuitBreakerConfig().getFailureRateThreshold()).isEqualTo(70f);
        assertThat(circuito().getCircuitBreakerConfig().isAutomaticTransitionFromOpenToHalfOpenEnabled()).isTrue();
        assertThat(reintentos.retry("core").getRetryConfig().getMaxAttempts()).isEqualTo(3);
        assertThat(mamparos.bulkhead("core").getBulkheadConfig().getMaxConcurrentCalls()).isEqualTo(20);
        assertThat(reintentos.retry("auth-server").getRetryConfig().getMaxAttempts()).isEqualTo(2);
    }

    @Test
    @DisplayName("Con el core caido el resumen sale del ultimo dato conocido, marcado y SIN ETag ni cache en el telefono")
    void elCoreCaidoSirveElUltimoResumen() throws Exception {
        when(http.obtenerCuenta(116)).thenReturn(cuenta116());
        String fresco = mvc.perform(resumen())
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("X-Datos-Desactualizados"))
                .andExpect(header().exists(HttpHeaders.ETAG))
                .andReturn().getResponse().getContentAsString();

        olvidarLaCacheDelCanal();
        when(http.obtenerCuenta(116)).thenThrow(caida());

        String respaldo = mvc.perform(resumen())
                .andExpect(status().isOk())
                .andExpect(header().string("X-Datos-Desactualizados", "true"))
                .andExpect(header().exists("X-Datos-Antiguedad-Segundos"))
                .andExpect(header().string("Warning", "110 - \"Response is Stale\""))
                .andExpect(header().string("Cache-Control", "no-store"))
                .andExpect(header().doesNotExist(HttpHeaders.ETAG))
                .andReturn().getResponse().getContentAsString();

        assertThat(respaldo).isEqualTo(fresco);
    }

    @Test
    @DisplayName("Con el core caido y SIN dato previo: 503 core_no_disponible con el contrato de error del canal")
    void sinDatoPrevioEs503() throws Exception {
        when(http.obtenerCuenta(116)).thenThrow(caida());

        mvc.perform(resumen())
                .andExpect(status().isServiceUnavailable())
                .andExpect(header().doesNotExist("X-Datos-Desactualizados"))
                .andExpect(jsonPath("$.motivo").value("core_no_disponible"))
                .andExpect(jsonPath("$.canal").value("MOVIL"));
    }

    @Test
    @DisplayName("El respaldo NO salta la titularidad: un token de otra cuenta no ve el resumen guardado")
    void elRespaldoNoSaltaLaTitularidad() throws Exception {
        when(http.obtenerCuenta(116)).thenReturn(cuenta116());
        mvc.perform(resumen()).andExpect(status().isOk());
        olvidarLaCacheDelCanal();
        when(http.obtenerCuenta(116)).thenThrow(caida());

        // Token de la cuenta 105 pidiendo la 116.
        mvc.perform(get("/v1/cuentas/116/resumen")
                        .header(HttpHeaders.AUTHORIZATION,
                                "Bearer " + emisor.clienteMovil("cliente105", 105, DISPOSITIVO).emitir())
                        .header(VinculacionDispositivo.CABECERA, DISPOSITIVO))
                .andExpect(status().isForbidden())
                .andExpect(header().doesNotExist("X-Datos-Desactualizados"));
    }

    @Test
    @DisplayName("Treinta 404 seguidos no abren el circuito")
    void los404NoAbrenElCircuito() throws Exception {
        when(http.obtenerCuenta(116)).thenThrow(new CoreRecursoNoEncontradoException("404", "/x", "{}"));

        for (int i = 0; i < 30; i++) {
            mvc.perform(resumen()).andExpect(status().isNotFound());
        }

        assertThat(circuito().getState()).isEqualTo(CircuitBreaker.State.CLOSED);
        assertThat(circuito().getMetrics().getNumberOfFailedCalls()).isZero();
    }

    @Test
    @DisplayName("Con el circuito abierto el canal responde con el respaldo SIN llamar al core")
    void conElCircuitoAbiertoNoSeLlamaAlCore() throws Exception {
        when(http.obtenerCuenta(116)).thenReturn(cuenta116());
        mvc.perform(resumen()).andExpect(status().isOk());
        olvidarLaCacheDelCanal();

        when(http.obtenerCuenta(116)).thenThrow(caida());
        for (int i = 0; i < 3 && circuito().getState() != CircuitBreaker.State.OPEN; i++) {
            mvc.perform(resumen()).andExpect(status().isOk())
                    .andExpect(header().string("X-Datos-Desactualizados", "true"));
            olvidarLaCacheDelCanal();
        }
        assertThat(circuito().getState()).isEqualTo(CircuitBreaker.State.OPEN);

        clearInvocations(http);
        mvc.perform(resumen()).andExpect(status().isOk())
                .andExpect(header().string("X-Datos-Desactualizados", "true"));
        verifyNoInteractions(http);
    }
}
