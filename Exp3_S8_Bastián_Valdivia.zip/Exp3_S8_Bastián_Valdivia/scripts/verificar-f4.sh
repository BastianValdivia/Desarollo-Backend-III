#!/usr/bin/env bash
# =====================================================================
# verificar-f4.sh: comprobaciones de la fase F4 (OAuth2 entre servicios) contra el stack levantado con
# "docker compose up -d". Imprime PASS o FAIL con el dato real de cada una; el codigo de salida es 0 solo
# si todas pasan.
#
# Que comprueba, en el orden de los criterios de termino de F4:
#   1. El auth-server publica su descubrimiento OIDC y su JWKS por HTTPS, verificables con la CA interna
#      (y sin la CA, curl se niega: no se usa -k).
#   2. Los tokens que entrega a cada BFF (client_credentials): scopes exactos de D2, audiencia, emisor
#      fijo, vigencia de 5 minutos; y lo que rechaza (secreto incorrecto, scope ajeno, otros grants).
#   3. La MATRIZ del core, con tokens REALES pedidos al auth-server y llamadas hechas desde DENTRO de la
#      red interna (el core no se publica): sin token 401, token valido 200, scope insuficiente 403 y,
#      en particular, bff-web NO puede retirar (403).
#   4. Lo que el core rechaza con 401 aunque el token "parezca" bueno: vencido, de otra audiencia, de otro
#      emisor y firmado con una clave ajena. Estos tokens se forjan con scripts/FirmarTokenDeServicio.java
#      (un token real vencido tardaria 5 minutos en conseguirse y uno de otra audiencia no se puede pedir).
#   5. Cada BFF obtiene su token UNA vez y lo reutiliza: tras decenas de llamadas al core no pidio otro.
#   6. Los secretos de los clientes no estan en git, ni en el compose, ni en el entorno de los
#      contenedores, ni en las imagenes.
#   7. No queda ninguna referencia a la cabecera fija del S5 en codigo, scripts ni configuracion, y la
#      cabecera ya no abre nada.
#
# QUE MODIFICA. Un retiro de 1000 en la cuenta 150 (con el token del cajero, para comprobar el 200); al
# final ejecuta scripts/restablecer-demo.sh, que devuelve los saldos de la carga.
#
# Portabilidad: sin construcciones de bash 4 ni de GNU en el host; requiere docker, curl y python3.
# Solo funciona con ENTORNO=docker (el compose es lo que se verifica). Se probo en Linux; no se ha
# ejecutado en macOS ni en Windows.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
if [ "${ENTORNO:-docker}" != docker ]; then
  echo "ERROR: verificar-f4.sh verifica el compose: ejecutalo con ENTORNO=docker (el valor por defecto)." >&2
  exit 2
fi
source "$RAIZ/scripts/lib-entorno.sh"
source "$RAIZ/scripts/lib-login.sh"

FALLOS=0
TOTAL=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() {  # igual <descripcion> <esperado> <obtenido>
  if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi
}
json() { python3 -c "import sys,json; d=json.load(sys.stdin); print($1)" 2>/dev/null; }
# claim <token> <nombre>: valor de un claim del payload (base64 URL sin relleno)
claim() {
  python3 -c "
import base64,json,sys
p=sys.argv[1].split('.')[1]; p+='='*(-len(p)%4)
v=json.loads(base64.urlsafe_b64decode(p)).get(sys.argv[2]); print(json.dumps(v) if isinstance(v,(list,dict)) else v)" "$1" "$2"
}
# claim_json <token> <nombre>: igual que claim, pero siempre en JSON (un texto sale entre comillas)
claim_json() {
  python3 -c "
import base64,json,sys
p=sys.argv[1].split('.')[1]; p+='='*(-len(p)%4)
print(json.dumps(json.loads(base64.urlsafe_b64decode(p)).get(sys.argv[2])))" "$1" "$2"
}
# solicitud_token <cliente> <secreto> <scopes> [grant]: respuesta cruda del endpoint de tokens, con el codigo
solicitud_token() {
  curl -s -w '\n%{http_code}' "${TLS[@]}" -u "$1:$2" -d "grant_type=${4:-client_credentials}" \
    --data-urlencode "scope=$3" "$AUTH_URL/oauth2/token"
}

ISSUER="https://localhost:9000"

# ===============================================================================================
echo "== 1. auth-server: descubrimiento OIDC y JWKS por HTTPS, verificables con la CA interna =="
DISC="$(curl -s "${TLS[@]}" "$AUTH_URL/.well-known/openid-configuration")"
igual "el descubrimiento OIDC se obtiene por HTTPS con --cacert certs/ca.crt" "$ISSUER" "$(echo "$DISC" | json "d['issuer']")"
igual "token_endpoint" "$ISSUER/oauth2/token" "$(echo "$DISC" | json "d['token_endpoint']")"
igual "jwks_uri" "$ISSUER/oauth2/jwks" "$(echo "$DISC" | json "d['jwks_uri']")"
JWKS="$(curl -s "${TLS[@]}" "$AUTH_URL/oauth2/jwks")"
igual "el JWKS publica una clave RSA de firma RS256" "RSA RS256 sig" "$(echo "$JWKS" | json "' '.join([d['keys'][0]['kty'], d['keys'][0]['alg'], d['keys'][0]['use']])")"
igual "el JWKS no contiene la parte privada (sin d, p, q)" "True" "$(echo "$JWKS" | json "not any(k in d['keys'][0] for k in ('d','p','q','dp','dq','qi'))")"
curl -s -o /dev/null --max-time 10 "$AUTH_URL/oauth2/jwks"; RC=$?
igual "sin la CA, curl rechaza el certificado (codigo 60): no hace falta -k" 60 "$RC"
igual "el certificado lo firma la CA interna y trae SAN auth-server" "True" \
  "$(python3 - "$CA_CRT" <<'PY'
import ssl, socket, sys
ctx = ssl.create_default_context(cafile=sys.argv[1])
try:
    with ctx.wrap_socket(socket.create_connection(("localhost", 9000), timeout=10), server_hostname="localhost") as s:
        cert = s.getpeercert()
    sans = [v for k, v in cert["subjectAltName"]]
    print("auth-server" in sans and "localhost" in sans)
except Exception as e:
    print("ERROR", e)
PY
)"
igual "dos peticiones de descubrimiento dan el mismo JWKS (la clave de firma es persistente, no se genera por peticion)" \
  "$(echo "$JWKS" | json "d['keys'][0]['kid']")" "$(curl -s "${TLS[@]}" "$AUTH_URL/oauth2/jwks" | json "d['keys'][0]['kid']")"

# ===============================================================================================
echo "== 2. Tokens de servicio reales: scopes de D2, audiencia, emisor fijo y 5 minutos =="
verificar_cliente() {  # verificar_cliente <cliente> <scopes esperados ordenados> <audiencias esperadas ordenadas>
  local c="$1" TOK
  TOK="$(token_servicio "$c")"
  igual "$c: emisor (iss) fijo" "$ISSUER" "$(claim "$TOK" iss)"
  igual "$c: sujeto y client_id" "$c $c" "$(claim "$TOK" sub) $(claim "$TOK" client_id)"
  igual "$c: scopes exactos" "$2" "$(claim "$TOK" scope | json "' '.join(sorted(d))")"
  # Con una sola audiencia el claim aud sale como texto y con varias como arreglo (RFC 7519, 4.1.3).
  igual "$c: audiencia" "$3" "$(claim_json "$TOK" aud | json "' '.join(sorted(d if isinstance(d, list) else [d]))")"
  igual "$c: vigencia 300 s (5 minutos)" 300 "$(python3 -c "import sys; print(int(sys.argv[1]) - int(sys.argv[2]))" "$(claim "$TOK" exp)" "$(claim "$TOK" iat)")"
}
verificar_cliente bff-web "auditoria:leer cuentas:leer movimientos:leer" "auditoria-service core-service"
verificar_cliente bff-mobile "cuentas:leer" "core-service"
verificar_cliente bff-atm "retiros:ejecutar saldo:leer" "core-service"

echo "  -- el mismo flujo, visto desde DENTRO de la red interna (contenedor efimero, TLS verificado contra la CA)"
R="$(llamada_interna POST https://auth-server:9000/oauth2/token --basic "bff-atm:$(secreto_cliente bff-atm)" \
      --form "grant_type=client_credentials&scope=saldo%3Aleer+retiros%3Aejecutar")"
igual "https://auth-server:9000/oauth2/token responde 200 con el certificado verificado por la CA interna" "HTTP 200" "$(echo "$R" | head -1)"
TOK_INT="$(echo "$R" | tail -1 | json "d['access_token']")"
igual "el token pedido desde la red interna lleva el mismo emisor fijo" "$ISSUER" "$(claim "$TOK_INT" iss)"
igual "y la misma audiencia core-service" "core-service" "$(claim "$TOK_INT" aud)"

SEC_WEB="$(secreto_cliente bff-web)"
R="$(solicitud_token bff-web "secreto-incorrecto" "cuentas:leer")"
igual "un secreto incorrecto no entrega token (401 invalid_client)" "401 invalid_client" "$(echo "$R" | tail -1) $(echo "$R" | head -1 | json "d['error']")"
R="$(solicitud_token bff-web "$SEC_WEB" "saldo:leer")"
igual "bff-web no puede pedir el scope saldo:leer (invalid_scope)" "400 invalid_scope" "$(echo "$R" | tail -1) $(echo "$R" | head -1 | json "d['error']")"
R="$(solicitud_token bff-mobile "$(secreto_cliente bff-mobile)" "retiros:ejecutar")"
igual "bff-mobile no puede pedir retiros:ejecutar (invalid_scope)" "400 invalid_scope" "$(echo "$R" | tail -1) $(echo "$R" | head -1 | json "d['error']")"
R="$(solicitud_token bff-web "$(secreto_cliente bff-atm)" "cuentas:leer")"
igual "el secreto de otro cliente no sirve (401)" 401 "$(echo "$R" | tail -1)"
R="$(solicitud_token cliente-inexistente "x" "cuentas:leer")"
igual "un cliente desconocido no entrega token (401)" 401 "$(echo "$R" | tail -1)"
R="$(solicitud_token bff-web "$SEC_WEB" "cuentas:leer" password)"
igual "el grant password no existe (400 unsupported_grant_type)" "400 unsupported_grant_type" "$(echo "$R" | tail -1) $(echo "$R" | head -1 | json "d['error']")"

# ===============================================================================================
echo "== 3. Matriz del core con tokens reales, desde la red interna (el core no se publica) =="
T_WEB="$(token_servicio bff-web)"; T_MOV="$(token_servicio bff-mobile)"; T_ATM="$(token_servicio bff-atm)"
CUENTA=/internal/v1/cuentas/116; MOVS=/internal/v1/cuentas/116/movimientos; SALDO=/internal/v1/cuentas/116/saldo
RETIRO=/internal/v1/cuentas/150/retiros
CALIDAD=/internal/v1/admin/calidad-datos; NOCONC=/internal/v1/admin/transacciones-no-conciliadas
M='{"monto":1000}'
igual "sin token: GET cuenta responde 401" 401 "$(core_codigo - GET $CUENTA)"
igual "sin token: GET saldo responde 401" 401 "$(core_codigo - GET $SALDO)"
igual "sin token: POST retiro responde 401" 401 "$(core_codigo - POST $RETIRO "$M")"
igual "sin token: GET calidad de datos responde 401" 401 "$(core_codigo - GET $CALIDAD)"
igual "un texto que no es un JWT responde 401" 401 "$(core_codigo "esto-no-es-un-jwt" GET $CUENTA)"
echo "  -- bff-web (cuentas, movimientos, auditoria): lee, no mueve dinero"
igual "bff-web GET cuenta: 200" 200 "$(core_codigo "$T_WEB" GET $CUENTA)"
igual "bff-web GET movimientos: 200" 200 "$(core_codigo "$T_WEB" GET $MOVS)"
igual "bff-web GET calidad de datos: 200" 200 "$(core_codigo "$T_WEB" GET $CALIDAD)"
igual "bff-web GET no conciliadas: 200" 200 "$(core_codigo "$T_WEB" GET $NOCONC)"
igual "bff-web GET saldo: 403 (no tiene saldo:leer)" 403 "$(core_codigo "$T_WEB" GET $SALDO)"
igual "bff-web POST retiro: 403 (su token no mueve dinero)" 403 "$(core_codigo "$T_WEB" POST $RETIRO "$M")"
echo "  -- bff-mobile (solo cuentas:leer)"
igual "bff-mobile GET cuenta: 200" 200 "$(core_codigo "$T_MOV" GET $CUENTA)"
igual "bff-mobile GET movimientos: 403" 403 "$(core_codigo "$T_MOV" GET $MOVS)"
igual "bff-mobile GET saldo: 403" 403 "$(core_codigo "$T_MOV" GET $SALDO)"
igual "bff-mobile POST retiro: 403" 403 "$(core_codigo "$T_MOV" POST $RETIRO "$M")"
igual "bff-mobile GET calidad de datos: 403" 403 "$(core_codigo "$T_MOV" GET $CALIDAD)"
echo "  -- bff-atm (saldo:leer y retiros:ejecutar)"
igual "bff-atm GET saldo: 200" 200 "$(core_codigo "$T_ATM" GET $SALDO)"
igual "bff-atm POST retiro: 200" 200 "$(core_codigo "$T_ATM" POST $RETIRO "$M")"
igual "bff-atm GET cuenta: 403" 403 "$(core_codigo "$T_ATM" GET $CUENTA)"
igual "bff-atm GET movimientos: 403" 403 "$(core_codigo "$T_ATM" GET $MOVS)"
igual "bff-atm GET calidad de datos: 403" 403 "$(core_codigo "$T_ATM" GET $CALIDAD)"
echo "  -- el cuerpo de los rechazos es RFC 7807 con el motivo (llamadas desde un contenedor de la red interna)"
R="$(llamada_interna GET http://core-service:8080/internal/v1/cuentas/116)"
igual "401 sin token: HTTP 401 con WWW-Authenticate: Bearer" "HTTP 401 WWW-Authenticate: Bearer" "$(echo "$R" | sed -n '1p;2p' | paste -sd' ' -)"
igual "401 sin token: motivo token_ausente" "token_ausente" "$(echo "$R" | tail -1 | json "d['motivo']")"
R="$(llamada_interna POST http://core-service:8080/internal/v1/cuentas/150/retiros --bearer "$T_WEB" --json "$M")"
igual "bff-web intentando un retiro: HTTP 403" "HTTP 403" "$(echo "$R" | head -1)"
igual "403: WWW-Authenticate Bearer error insufficient_scope" 1 "$(echo "$R" | grep -c 'WWW-Authenticate: Bearer error="insufficient_scope"')"
igual "403: motivo permiso_insuficiente" "permiso_insuficiente" "$(echo "$R" | tail -1 | json "d['motivo']")"

# ===============================================================================================
echo "== 4. Lo que el core rechaza con 401 aunque el token parezca bueno =="
echo "  (tokens forjados con la clave REAL del auth-server, leida de su volumen en un contenedor efimero sin red)"
VENCIDO="$(firmar_token_servicio AUTH-SERVER "$ISSUER" core-service bff-web "cuentas:leer,movimientos:leer,auditoria:leer" -600)"
VIGENTE="$(firmar_token_servicio AUTH-SERVER "$ISSUER" core-service bff-web "cuentas:leer,movimientos:leer,auditoria:leer" 300)"
OTRA_AUD="$(firmar_token_servicio AUTH-SERVER "$ISSUER" auditoria-service bff-web "cuentas:leer,movimientos:leer,auditoria:leer" 300)"
OTRO_EMISOR="$(firmar_token_servicio AUTH-SERVER "https://otro-emisor.example" core-service bff-web "cuentas:leer" 300)"
AJENO="$(firmar_token_servicio NUEVA "$ISSUER" core-service bff-web "cuentas:leer,movimientos:leer,auditoria:leer" 300)"
igual "control: el mismo forjador, con todo correcto, produce un token que el core ACEPTA (200)" 200 "$(core_codigo "$VIGENTE" GET $CUENTA)"
igual "token VENCIDO (firmado con la clave real, hace 10 minutos): 401" 401 "$(core_codigo "$VENCIDO" GET $CUENTA)"
igual "token de OTRA AUDIENCIA (auditoria-service): 401" 401 "$(core_codigo "$OTRA_AUD" GET $CUENTA)"
igual "token de OTRO EMISOR: 401" 401 "$(core_codigo "$OTRO_EMISOR" GET $CUENTA)"
igual "token firmado con una CLAVE AJENA: 401" 401 "$(core_codigo "$AJENO" GET $CUENTA)"
R="$(llamada_interna GET http://core-service:8080/internal/v1/cuentas/116 --bearer "$VENCIDO")"
igual "el 401 de un token vencido: WWW-Authenticate Bearer error invalid_token y motivo token_invalido" "1 token_invalido" \
  "$(echo "$R" | grep -c 'WWW-Authenticate: Bearer error="invalid_token"') $(echo "$R" | tail -1 | json "d['motivo']")"
# La cabecera del S5 se arma por partes para que esta comprobacion no sea, ella misma, una linea que la
# busqueda de la seccion 7 encuentre.
CABECERA_VIEJA="X-Service-""Token"
igual "la cabecera fija del S5 ya no abre el core (401)" 401 "$("${COMPOSE[@]}" exec -T core-service sh -c \
  'wget -S -q -O /dev/null --header "$1: token-de-desarrollo-no-usar-en-produccion" http://127.0.0.1:8080/internal/v1/cuentas/116 2>&1 | grep -m1 "HTTP/" | awk "{print \$2}"' _ "$CABECERA_VIEJA")"

# ===============================================================================================
echo "== 5. Cada BFF obtiene su token UNA vez y lo reutiliza (no pide uno por peticion) =="
# Desde F5 los tokens de usuario los emite el auth-server (PKCE para web y movil, tarjeta y PIN para el cajero).
TA="$(token_cajero 4000000000000116 1234)"
TE="$(token_web ejecutivo1 Exec.2026)"
TM="$(token_movil cliente116 Cliente.2026 dispositivo-demo-01)"
obtenciones() {  # obtenciones <servicio>: cuantas veces ese BFF pidio un token desde que ARRANCO (lineas de su log)
  # El log de un contenedor sobrevive a "docker restart": se cuenta solo desde el ultimo arranque, que es el que usa el
  # calculo de mas abajo (segundos desde StartedAt).
  local id inicio
  id="$("${COMPOSE[@]}" ps -q "$1")"
  inicio="$(docker inspect -f '{{.State.StartedAt}}' "$id")"
  docker logs --since "$inicio" "$id" 2>&1 | grep -c "Token de servicio obtenido del auth-server"
}
# El primer uso tras el arranque puede coincidir con "el balanceador aun no ve al core": se espera a un 200.
for i in $(seq 1 30); do
  c="$(curl_bff -o /dev/null -w '%{http_code}' "$ATM/v1/cuentas/116/saldo-disponible" -H "Authorization: Bearer $TA")"
  [ "$c" = 200 ] && break; sleep 2
done
igual "el cajero alcanza al core con su token de servicio (200)" 200 "$c"
curl_bff -o /dev/null "$WEB/v1/admin/calidad-datos" -H "Authorization: Bearer $TE"
curl_bff -o /dev/null "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01'
A0="$(obtenciones bff-atm)"; W0="$(obtenciones bff-web)"; M0="$(obtenciones bff-mobile)"
K0="$(contador_core '/internal/v1/cuentas/%7BcuentaId%7D/saldo')"
OK=0
for i in $(seq 1 60); do
  c="$(curl_bff -o /dev/null -w '%{http_code}' "$ATM/v1/cuentas/116/saldo-disponible" -H "Authorization: Bearer $TA")"
  [ "$c" = 200 ] && OK=$((OK + 1))
done
for pag in $(seq 0 19); do
  curl_bff -o /dev/null "$WEB/v1/admin/transacciones-no-conciliadas?page=$pag&size=5" -H "Authorization: Bearer $TE"
done
A1="$(obtenciones bff-atm)"; W1="$(obtenciones bff-web)"; M1="$(obtenciones bff-mobile)"
K1="$(contador_core '/internal/v1/cuentas/%7BcuentaId%7D/saldo')"
igual "60 consultas de saldo por el cajero: todas 200" 60 "$OK"
igual "el core atendio esas 60 consultas de saldo (suma de las dos replicas)" 60 "$((K1 - K0))"
igual "bff-atm: tokens pedidos durante las 60 llamadas al core" 0 "$((A1 - A0))"
igual "bff-web: tokens pedidos durante 20 llamadas distintas al core" 0 "$((W1 - W0))"
igual "bff-mobile: tokens pedidos durante ese trafico" 0 "$((M1 - M0))"
for s in bff-web bff-mobile bff-atm; do
  total="$(obtenciones $s)"
  inicio="$(docker inspect -f '{{.State.StartedAt}}' "$("${COMPOSE[@]}" ps -q $s)")"
  segs="$(python3 -c "
import sys, datetime
t = datetime.datetime.fromisoformat(sys.argv[1].split('.')[0]).replace(tzinfo=datetime.timezone.utc)
print(int((datetime.datetime.now(datetime.timezone.utc) - t).total_seconds()))" "$inicio")"
  maximo=$((segs / 270 + 1))
  [ "$total" -ge 1 ] && [ "$total" -le "$maximo" ] && resultado PASS "$s: $total tokens pedidos desde que arranco hace $segs s (a lo sumo 1 por cada 270 s, la vigencia menos el margen)" \
    || resultado FAIL "$s: $total tokens pedidos en $segs s (esperado entre 1 y $maximo)"
done

# ===============================================================================================
echo "== 6. Los secretos de los clientes no estan en git, ni en el compose, ni en el entorno, ni en las imagenes =="
SECRETOS="$(for c in bff-web bff-mobile bff-atm; do secreto_cliente "$c"; echo; done | tr -d '\r')"
igual "los tres secretos existen y tienen 40 caracteres" 3 "$(echo "$SECRETOS" | awk 'length($0)==40' | wc -l | tr -d ' ')"
TODOS="$("${COMPOSE[@]}" ps -a -q)"
INSPECT="$(docker inspect $TODOS)"
CONFIG="$("${COMPOSE[@]}" config)"
EN_ENTORNO=0; EN_COMPOSE=0; EN_GIT=0
N_ARCHIVOS="$(contar_archivos_del_proyecto)"   # sin git (zip) se recorre el arbol: ver lib-entorno.sh
for s in $SECRETOS; do
  EN_ENTORNO=$((EN_ENTORNO + $(echo "$INSPECT" | grep -cF "$s")))
  EN_COMPOSE=$((EN_COMPOSE + $(echo "$CONFIG" | grep -cF "$s") + $(grep -cF "$s" docker-compose.yaml)))
  EN_GIT=$((EN_GIT + $(contar_archivos_con_texto "$s")))
done
# Un 0 sobre una lista vacia no demuestra nada: si no habia archivos que revisar, la comprobacion falla.
[ "$N_ARCHIVOS" -ge 100 ] || EN_GIT="solo $N_ARCHIVOS archivos en la lista: no se reviso nada"
igual "ningun secreto aparece en docker inspect de ningun contenedor" 0 "$EN_ENTORNO"
igual "ningun secreto aparece en docker-compose.yaml ni en docker compose config" 0 "$EN_COMPOSE"
igual "ningun secreto aparece en un $ORIGEN_ARCHIVOS" 0 "$EN_GIT"
EN_IMAGEN=0
for img in auth-server bff-web bff-mobile bff-atm core-service; do
  EN_IMAGEN=$((EN_IMAGEN + $(docker history --no-trunc "bancoxyz/$img:1.0.0" 2> /dev/null | grep -cE "$(echo "$SECRETOS" | paste -sd'|' -)")))
done
igual "ningun secreto aparece en las capas de las imagenes" 0 "$EN_IMAGEN"
igual "cada secreto vive en archivos 0400 del volumen de su servicio (dueno 10001)" "-r-------- 10001 10001" \
  "$("${COMPOSE[@]}" exec -T auth-server sh -c 'stat -c "%A %u %g" /run/secrets/propiedades/autorizacion.clientes.bff-web.secreto')"
igual "bff-web monta SOLO el secreto de su cliente (no ve el de los otros)" "spring.security.oauth2.client.registration.servicios-internos.client-secret" \
  "$("${COMPOSE[@]}" exec -T bff-web sh -c 'ls /run/secrets/propiedades | grep -i secret')"
igual "el core no recibe ningun secreto de cliente OAuth2" 0 "$("${COMPOSE[@]}" exec -T core-service sh -c 'ls /run/secrets/propiedades | grep -ci "client\|secreto"' | tr -d '\r')"

# ===============================================================================================
echo "== 7. Ninguna referencia a la cabecera fija del S5 en codigo, scripts ni configuracion =="
REFS="$(contar_archivos_con 'X-Service-[T]oken' planificacion evidencias)"
[ "$N_ARCHIVOS" -ge 100 ] || REFS="solo $N_ARCHIVOS archivos en la lista: no se reviso nada"
igual "busqueda de la cabecera fija en los archivos del proyecto (fuera de planificacion/, que conserva la historia de las fases, y de evidencias/, que son salidas de estos mismos scripts)" 0 "$REFS"
# Excepciones, ambas deliberadas: generar-secretos.sh BORRA el archivo viejo de volumenes anteriores a F4, y
# ConfigServerTest lo lista entre las claves que config-repo no puede contener (es una guarda, no un uso).
REFS_PROP="$(contar_archivos_con 'token-servicio|CORE_SEGURIDAD_TOKEN' planificacion evidencias scripts/verificar-f4.sh docker/secretos-init/generar-secretos.sh config-server/src/test/java/cl/duoc/bancoxyz/config/ConfigServerTest.java)"
[ "$N_ARCHIVOS" -ge 100 ] || REFS_PROP="solo $N_ARCHIVOS archivos en la lista: no se reviso nada"
igual "ni su propiedad (core.token-servicio) ni su variable de entorno" 0 "$REFS_PROP"
VIEJOS="$("${COMPOSE[@]}" exec -T core-service sh -c 'ls /run/secrets/propiedades | grep -c "token-servicio"' | tr -d '\r')"
igual "los volumenes no conservan el archivo de la credencial fija del S5" 0 "$VIEJOS"

echo
echo "Restableciendo los datos de demostracion..."
bash "$RAIZ/scripts/restablecer-demo.sh" > /dev/null

if [ "$FALLOS" -ne 0 ]; then echo "RESULTADO: $FALLOS de $TOTAL comprobaciones FAIL"; exit 1; fi
echo "RESULTADO: $TOTAL comprobaciones, todo PASS"
