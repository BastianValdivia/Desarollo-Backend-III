#!/usr/bin/env bash
# =====================================================================
# medir-despliegue.sh: la tabla de F8 (tamano de imagen, tiempo de arranque y memoria en reposo
# de cada servicio), medida sobre el stack real.
# =====================================================================
# Uso:
#   scripts/medir-despliegue.sh                 baja el stack (conserva volumenes), lo levanta SIN construir y mide
#   scripts/medir-despliegue.sh --frio          antes, "down -v": arranque en frio de verdad (secretos y datos nuevos)
#   scripts/medir-despliegue.sh --reposo 90     segundos de reposo antes de leer la memoria (por defecto 60)
#   scripts/medir-despliegue.sh --sin-bajar     no baja ni levanta nada: mide lo que ya esta corriendo (la columna de
#                                               arranque queda vacia, porque no se vio el arranque)
#
# Las imagenes deben existir (docker compose build): lo que se mide es el DESPLIEGUE, no la compilacion.
#
# Que mide y con que resolucion:
#   * Tamano de imagen, dos cifras porque dependen del motor: "Disco" es lo que informa "docker images" (lo que ocupa
#     la imagen ya descomprimida) y "Contenido" lo que informa "docker image inspect" (con el almacen de imagenes de
#     containerd, el de Docker 29 y de Docker Desktop reciente, es el tamano comprimido que se descarga; con el motor
#     clasico las dos cifras coinciden). Y el numero de capas.
#   * Arranque, dos cifras distintas porque responden a preguntas distintas:
#       "app (s)"    lo que la aplicacion dice de si misma ("Started X in N seconds" de Spring Boot): el costo
#                    de la JVM y del contexto, sin esperas de orquestacion. Resolucion de decimas.
#       "healthy (s)" desde que Docker inicia el contenedor hasta su primer "healthy" visto por el sondeo de
#                    este guion (cada segundo). Incluye el intervalo del HEALTHCHECK (10 s): el primer sondeo
#                    ocurre 10 s despues de iniciar, asi que ningun servicio puede dar menos de ~10 s aqui.
#       Un servicio no arranca hasta que sus dependencias estan sanas (depends_on), por eso el guion tambien
#       informa en que segundo desde "up" quedo listo cada uno ("listo a los (s)") y el total.
#   * Memoria y CPU: "docker stats --no-stream" tras el reposo, tres lecturas separadas por 2 s y la mediana, por replica (el
#     valor de una replica, no la suma).
#     Es memoria del contenedor tal como la ve Docker (RSS + cache de pagina), la misma que cuenta el limite.
#
# La medicion es de UNA corrida en la maquina donde se ejecuta (4 CPU en el entorno de desarrollo): es un
# orden de magnitud y sirve para comparar servicios entre si y antes/despues de un cambio, no es una garantia.
#
# Portabilidad: bash 3.2 (macOS) y Git Bash: sin arreglos asociativos, sin "date +%N"; el tiempo es la variable
# SECONDS. Requiere docker y python3.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
docker() { MSYS_NO_PATHCONV=1 command docker "$@"; }
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
COMPOSE=(docker compose -f docker-compose.yaml)

FRIO=0; REPOSO=60; BAJAR=1
while [ $# -gt 0 ]; do
  case "$1" in
    --frio) FRIO=1 ;;
    --reposo) shift; REPOSO="${1:?falta el numero de segundos}" ;;
    --sin-bajar) BAJAR=0 ;;
    *) echo "Uso: $0 [--frio] [--reposo SEGUNDOS] [--sin-bajar]" >&2; exit 2 ;;
  esac
  shift
done

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# Cuantos contenedores debe haber al final: la suma de "deploy.replicas" (1 si no lo dice) de cada servicio.
ESPERADOS="$("${COMPOSE[@]}" config --format json | python3 -c '
import json, sys
c = json.load(sys.stdin)
print(sum(int((s.get("deploy") or {}).get("replicas", 1)) for s in c["services"].values()))')"

TOTAL_S=""
if [ "$BAJAR" = 1 ]; then
  if [ "$FRIO" = 1 ]; then
    echo "Arranque en frio: docker compose down -v (se borran volumenes de secretos y de datos)"
    "${COMPOSE[@]}" down -v > /dev/null 2>&1
    # En Linux certs/ puede pertenecer a root (lo crea Docker); si no se borra, secretos-init reescribe ca.crt.
    rm -rf certs 2> /dev/null || echo "  (certs/ no se pudo borrar: lo reescribe secretos-init)"
  else
    "${COMPOSE[@]}" down > /dev/null 2>&1
  fi
  SECONDS=0
  # Sin --build: se mide el despliegue. "up -d" vuelve cuando los BFF estan iniciados, no sanos: se sondea.
  "${COMPOSE[@]}" up -d > "$TMP/up.log" 2>&1 &
  UP_PID=$!
  while [ "$SECONDS" -lt 900 ]; do
    ids="$("${COMPOSE[@]}" ps -a -q 2> /dev/null)"
    if [ -n "$ids" ]; then
      # shellcheck disable=SC2086
      docker inspect -f '{{.Name}}|{{.State.Status}}|{{.State.ExitCode}}|{{if .State.Health}}{{.State.Health.Status}}{{end}}' $ids 2> /dev/null \
        | while IFS='|' read -r nombre estado codigo salud; do
            nombre="${nombre#/}"
            if [ "$estado" = running ] || [ "$estado" = exited ]; then
              [ -f "$TMP/$nombre.run" ] || echo "$SECONDS" > "$TMP/$nombre.run"
            fi
            if { [ "$estado" = running ] && [ "$salud" = healthy ]; } || { [ "$estado" = exited ] && [ "$codigo" = 0 ]; }; then
              [ -f "$TMP/$nombre.ok" ] || echo "$SECONDS" > "$TMP/$nombre.ok"
            fi
          done
    fi
    LISTOS="$(ls "$TMP" 2> /dev/null | grep -c '\.ok$')"
    [ "$LISTOS" -ge "$ESPERADOS" ] && break
    sleep 1
  done
  TOTAL_S="$SECONDS"
  wait "$UP_PID" 2> /dev/null
  if [ "${LISTOS:-0}" -lt "$ESPERADOS" ]; then
    echo "ERROR: solo ${LISTOS:-0} de $ESPERADOS contenedores quedaron listos en 900 s" >&2
    "${COMPOSE[@]}" ps -a >&2
    exit 1
  fi
fi

echo "Todos los contenedores listos ($ESPERADOS). Reposo de ${REPOSO} s antes de leer la memoria..."
sleep "$REPOSO"

# Tres lecturas de memoria y CPU de todos los contenedores del proyecto, separadas por 2 s: "docker stats --no-stream" da
# una lectura instantanea (el CPU de un solo instante puede caer justo en una rafaga de recoleccion de basura o de
# compactacion de Kafka), asi que se informa la MEDIANA de las tres.
: > "$TMP/stats.txt"
for _ in 1 2 3; do
  docker stats --no-stream --format '{{.Name}}|{{.MemUsage}}|{{.CPUPerc}}' $("${COMPOSE[@]}" ps -q) >> "$TMP/stats.txt" 2> /dev/null
  sleep 2
done

: > "$TMP/datos.tsv"
for id in $("${COMPOSE[@]}" ps -a -q); do
  nombre="$(docker inspect -f '{{.Name}}' "$id")"; nombre="${nombre#/}"
  servicio="$(docker inspect -f '{{index .Config.Labels "com.docker.compose.service"}}' "$id")"
  imagen="$(docker inspect -f '{{.Config.Image}}' "$id")"
  tam="$(docker image inspect -f '{{.Size}}' "$imagen" 2> /dev/null || echo 0)"
  disco="$(docker images --format '{{.Size}}' "$imagen" 2> /dev/null | head -n 1)"
  limite="$(docker inspect -f '{{.HostConfig.Memory}}' "$id")"
  capas="$(docker image inspect -f '{{len .RootFS.Layers}}' "$imagen" 2> /dev/null || echo 0)"
  run="$(cat "$TMP/$nombre.run" 2> /dev/null || true)"
  ok="$(cat "$TMP/$nombre.ok" 2> /dev/null || true)"
  app="$(docker logs "$id" 2>&1 | grep -o 'Started [A-Za-z0-9_]* in [0-9.]* seconds' | tail -n 1 | awk '{print $4}')"
  stats="$(grep "^${nombre}|" "$TMP/stats.txt" || true)"
  mem="$(echo "$stats" | cut -d'|' -f2 | tr '\n' ';')"
  cpu="$(echo "$stats" | cut -d'|' -f3 | tr '\n' ';')"
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$nombre" "$servicio" "$imagen" "$tam" "$capas" "$run" "$ok" "$app" "$mem" "$cpu" "$disco" "$limite" >> "$TMP/datos.tsv"
done

python3 - "$TMP/datos.tsv" "${TOTAL_S:-}" "$REPOSO" <<'PY'
import sys, re
archivo, total, reposo = sys.argv[1], sys.argv[2], sys.argv[3]
orden = ["secretos-init", "postgres", "kafka", "kafka-init", "kafka-ui", "config-server", "eureka-server",
         "auth-server", "core-service", "notificaciones-service", "auditoria-service",
         "bff-web", "bff-mobile", "bff-atm"]

def a_mib(texto):
    m = re.match(r"([\d.]+)\s*([KMG]i?B)", texto.strip())
    if not m:
        return None
    v, u = float(m.group(1)), m.group(2)
    return v * {"KiB": 1 / 1024, "MiB": 1, "GiB": 1024, "kB": 1 / 1024, "MB": 1, "GB": 1024}.get(u, 1)

def a_mb(texto):
    m = re.match(r"([\d.]+)\s*([kKMG]?B)", (texto or "").strip())
    if not m:
        return None
    return float(m.group(1)) * {"B": 1e-6, "kB": 1e-3, "KB": 1e-3, "MB": 1, "GB": 1000}[m.group(2)]

servicios = {}
for linea in open(archivo, encoding="utf-8"):
    c = linea.rstrip("\n").split("\t")
    c += [""] * (12 - len(c))
    nombre, svc, imagen, tam, capas, run, ok, app, mem, cpu, disco, limite = c[:12]
    s = servicios.setdefault(svc, {"imagen": imagen, "tam": int(tam or 0), "disco": a_mb(disco), "capas": capas, "r": []})
    usos = sorted(v for v in (a_mib(m.partition("/")[0]) for m in mem.split(";") if m) if v is not None)
    cpus = sorted(float(c.rstrip("%")) for c in cpu.split(";") if c.endswith("%"))
    mediana = lambda xs: (xs[len(xs) // 2] if xs else None)
    s["r"].append({"run": run, "ok": ok, "app": app, "uso": mediana(usos),
                   "lim": (int(limite) / 1048576 if limite.isdigit() and int(limite) > 0 else None), "cpu": mediana(cpus)})

def fmt(v, d=0):
    return "n/d" if v is None else (f"{v:.{d}f}")

print()
print("| Servicio | Imagen | Disco (MB) | Contenido (MB) | Capas | Replicas | Arranque app (s) | Healthy tras iniciar (s) | Listo a los (s) | Memoria en reposo por replica (MiB) | Limite de memoria (MiB) | CPU en reposo |")
print("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
for svc in sorted(servicios, key=lambda x: orden.index(x) if x in orden else 99):
    s = servicios[svc]; r = s["r"]
    apps = [float(x["app"]) for x in r if x["app"]]
    sanos = [int(x["ok"]) - int(x["run"]) for x in r if x["ok"] and x["run"]]
    listos = [int(x["ok"]) for x in r if x["ok"]]
    usos = [x["uso"] for x in r if x["uso"] is not None]
    lims = [x["lim"] for x in r if x["lim"] is not None]
    cpus = [x["cpu"] for x in r if x["cpu"] is not None]
    # Una tarea unica (secretos-init, kafka-init) ya termino: no tiene memoria ni "healthy".
    tarea = svc in ("secretos-init", "kafka-init")
    print("| {} | `{}` | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} |".format(
        svc, s["imagen"], fmt(s["disco"]), fmt(s["tam"] / 1e6), s["capas"], len(r),
        (fmt(sum(apps) / len(apps), 1) if apps else "n/a"),
        ("termina" if tarea else (fmt(max(sanos)) if sanos else "n/d")),
        (fmt(max(listos)) if listos else "n/d"),
        ("n/a" if tarea or not usos else fmt(sum(usos) / len(usos), 0)),
        (fmt(lims[0], 0) if lims else "sin limite"),
        ("n/a" if tarea or not cpus else fmt(sum(cpus) / len(cpus), 1) + "%")))
total_mem = sum(x["uso"] for s in servicios.values() for x in s["r"] if x["uso"] is not None)
print()
print("Memoria total de todos los contenedores en reposo: {:.0f} MiB".format(total_mem))
if total:
    print("Tiempo desde 'docker compose up -d' hasta que todo esta listo: {} s".format(total))
print("Reposo antes de medir la memoria: {} s".format(reposo))
PY
