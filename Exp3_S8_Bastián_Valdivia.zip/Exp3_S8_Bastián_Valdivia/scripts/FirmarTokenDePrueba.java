import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Instant;
import java.util.Base64;

/**
 * Forjador de tokens de USUARIO para la evidencia: firma un JWT con la clave privada que se le indique (la del
 * auth-server) y con los claims, la audiencia y la vigencia que se pidan.
 *
 * <h2>Que lugar ocupa esto en la arquitectura</h2>
 * Ninguno, igual que {@link GenerarClaves}. No forma parte de ningun artefacto desplegable: vive en
 * {@code scripts/} y solo se ejecuta a mano cuando hay que producir evidencia. Nada del sistema en ejecucion lo
 * invoca. Un token VALIDO de una persona se pide siempre al auth-server ({@code login-web.sh},
 * {@code login-movil.sh}, {@code login-cajero.sh}).
 *
 * <h2>Por que hace falta una herramienta, desde F5</h2>
 * El auth-server emite el token que corresponde a una credencial real. Hay casos de la evidencia que NO se
 * pueden pedir por el login:
 * <ul>
 *   <li>una cuenta sin credencial sembrada (la 130, sin movimientos, o la 999, inexistente), para los casos borde;</li>
 *   <li>un token ya vencido (esperarlo costaria 3, 30 o 60 minutos);</li>
 *   <li>un token cuya audiencia nombra a otro canal, o un terminal que no existe, para probar las barreras de
 *       cada BFF con la FIRMA y el EMISOR validos, es decir las reglas propias de cada canal.</li>
 * </ul>
 * Antes de F5 esta herramienta firmaba con la clave de cada canal; ahora los canales no tienen clave de firma y
 * se firma con la unica que existe, la del auth-server, que en contenedores solo se lee dentro de un contenedor
 * efimero sin red que monta su volumen de secretos en solo lectura: la clave no sale nunca del volumen.
 *
 * <h2>Por que se escribe el JWT a mano y no con una libreria</h2>
 * Porque un JWT firmado es, literalmente, tres textos unidos por puntos: cabecera en Base64 URL,
 * cuerpo en Base64 URL, y la firma de {@code cabecera + "." + cuerpo} tambien en Base64 URL. La
 * JVM ya trae lo unico que no es texto ({@code Signature} con SHA256withRSA, que es lo que RS256
 * nombra). Meter una dependencia aqui obligaria a compilar con Maven un programa que existe
 * justamente para poder ejecutarse suelto, con {@code java Archivo.java}, sin nada instalado.
 *
 * <h2>Uso</h2>
 * <pre>
 *   java scripts/FirmarTokenDePrueba.java &lt;pem-privado&gt; &lt;kid|-&gt; &lt;emisor&gt; &lt;audiencia&gt; \
 *        &lt;sub&gt; &lt;cuentaId&gt; &lt;canal&gt; &lt;segundos-vigencia&gt; &lt;autoridades-separadas-por-coma&gt; [claims-extra]
 *
 *   # token web de la cuenta 130, que no tiene credencial sembrada
 *   java scripts/FirmarTokenDePrueba.java auth-server-private.pem - https://localhost:9000 bff-web \
 *        cliente130 130 WEB 600 'ROLE_CLIENTE_WEB,PERM_cuenta:leer'
 *
 *   # token del canal movil, atado a un dispositivo (claim device_id)
 *   java scripts/FirmarTokenDePrueba.java auth-server-private.pem - https://localhost:9000 bff-mobile \
 *        cliente130 130 MOVIL 3600 'ROLE_CLIENTE_MOVIL,PERM_saldo:leer' '"device_id":"dispositivo-demo-01"'
 *
 *   # token del cajero de un terminal que no existe
 *   java scripts/FirmarTokenDePrueba.java auth-server-private.pem - https://localhost:9000 bff-atm \
 *        400000******0116 116 ATM 180 'ROLE_CLIENTE_ATM,PERM_saldo:leer' '"terminal":"ATM-PIRATA-666"'
 * </pre>
 *
 * <p>El noveno argumento es obligatorio y el decimo, los claims extra, es opcional: se escribe
 * como fragmento JSON sin las llaves exteriores y sin coma final. Un {@code kid} de {@code -} significa "sin kid":
 * el BFF elige la clave del JWKS por tipo y algoritmo, que con una sola publicada es la correcta.
 * Imprime el token y nada mas, para poder capturarlo con {@code $(...)} en un guion.
 *
 * <p>Una vigencia negativa produce un token ya expirado, que es como se demuestra
 * {@code token_expirado} sin esperar a que pase el tiempo.
 */
public final class FirmarTokenDePrueba {

    /** Clase de utilidad: no tiene sentido instanciarla. */
    private FirmarTokenDePrueba() {
    }

    /**
     * Punto de entrada.
     *
     * @param args los nueve descritos en la documentacion de la clase, en ese orden
     * @throws Exception si la clave no se puede leer o la firma falla; ante cualquiera de las dos
     *                   lo unico sensato es abortar, porque un token a medias produciria una
     *                   evidencia que parece decir algo y no dice nada
     */
    public static void main(String[] args) throws Exception {
        if (args.length < 9 || args.length > 10) {
            System.err.println("Uso: java FirmarTokenDePrueba.java <pem-privado> <kid> <emisor> "
                    + "<audiencia> <sub> <cuentaId> <canal> <segundos> <autoridades,por,coma> "
                    + "[claims-extra-json]");
            System.exit(2);
        }

        // Decimo argumento OPCIONAL: un fragmento JSON con claims adicionales, sin las llaves
        // exteriores y sin coma final, por ejemplo:  "device_id":"dispositivo-demo-01"
        //
        // Existe porque el canal movil exige el claim device_id: su filtro compara ese valor
        // con la cabecera X-Device-Id y, si no coinciden, responde 401 dispositivo_no_coincide
        // antes de llegar al controlador. Sin este parametro no se puede forjar un token movil
        // utilizable, y la evidencia del canal movil sobre cuentas sin credencial sembrada (la
        // 130) quedaria sin poder producirse.
        //
        // Es OPCIONAL y va al final a proposito: las llamadas de nueve argumentos que ya existen
        // en la evidencia de la fase 3 siguen funcionando sin tocarlas.
        String claimsExtra = args.length == 10 ? args[9].trim() : "";

        Path pem = Path.of(args[0]);
        String kid = args[1];
        String emisor = args[2];
        String audiencia = args[3];
        String sub = args[4];
        long cuentaId = Long.parseLong(args[5]);
        String canal = args[6];
        long segundos = Long.parseLong(args[7]);
        String[] autoridades = args[8].split(",");

        long ahora = Instant.now().getEpochSecond();
        long expiracion = ahora + segundos;

        // TRAMPA QUE COSTO UN DIAGNOSTICO FALSO, ANOTADA PARA QUE NO SE REPITA.
        // Para forjar un token ya expirado se pasa una vigencia negativa, y la tentacion es
        // dejar iat en "ahora" y mover solo exp al pasado. Eso produce un token con exp ANTERIOR
        // a iat, y Spring Security lo rechaza en el DECODIFICADOR, antes de llegar a validar la
        // vigencia, con el mensaje "expiresAt must be after issuedAt". El canal responde entonces
        // 401 firma_invalida, que es su valor por defecto ante un token indecodificable, y la
        // evidencia parece estar denunciando un fallo del clasificador de motivos cuando en
        // realidad el token forjado era imposible.
        //
        // Un token expirado de verdad se emitio ANTES de expirar. Asi que cuando exp cae en el
        // pasado, iat se coloca un minuto antes que exp, que es lo que habria ocurrido de verdad.
        long emision = expiracion <= ahora ? expiracion - 60 : ahora;

        // Un kid de "-" significa "sin kid": desde F5 los canales validan con el JWKS del auth-server y eligen la clave
        // por tipo y algoritmo, y un kid que no coincida con el publicado se rechazaria antes de mirar nada mas.
        String cabecera = "-".equals(kid)
                ? "{\"alg\":\"RS256\"}"
                : "{\"kid\":\"" + kid + "\",\"alg\":\"RS256\"}";

        StringBuilder listaAutoridades = new StringBuilder();
        for (int i = 0; i < autoridades.length; i++) {
            if (i > 0) {
                listaAutoridades.append(',');
            }
            listaAutoridades.append('"').append(autoridades[i].trim()).append('"');
        }

        // La audiencia se escribe como ARREGLO de un elemento, que es la forma general del
        // RFC 7519. El emisor real del proyecto produce un string suelto porque la libreria
        // Nimbus colapsa el arreglo de un elemento al serializar, cosa que el mismo RFC permite
        // en su apartado 4.1.3. Que las dos formas se validen igual es, ademas, algo que esta
        // evidencia comprueba de paso.
        String cuerpo = "{"
                + "\"sub\":\"" + sub + "\","
                + "\"aud\":[\"" + audiencia + "\"],"
                + "\"iss\":\"" + emisor + "\","
                + "\"cuentaId\":" + cuentaId + ","
                + "\"canal\":\"" + canal + "\","
                + (claimsExtra.isEmpty() ? "" : claimsExtra + ",")
                + "\"iat\":" + emision + ","
                + "\"exp\":" + expiracion + ","
                + "\"authorities\":[" + listaAutoridades + "]"
                + "}";

        String parteFirmable = base64Url(cabecera.getBytes(StandardCharsets.UTF_8))
                + "." + base64Url(cuerpo.getBytes(StandardCharsets.UTF_8));

        Signature firmador = Signature.getInstance("SHA256withRSA");
        firmador.initSign(leerClavePrivada(pem));
        firmador.update(parteFirmable.getBytes(StandardCharsets.US_ASCII));

        System.out.println(parteFirmable + "." + base64Url(firmador.sign()));
    }

    /**
     * Lee una clave privada RSA desde un PEM en PKCS#8.
     *
     * <p>PEM es solo un envoltorio de texto: quitada la cabecera, el pie y los saltos de linea,
     * lo que queda es Base64 del DER que {@link PKCS8EncodedKeySpec} entiende directamente.
     *
     * @param pem ruta del archivo {@code -----BEGIN PRIVATE KEY-----}
     * @return la clave lista para firmar
     * @throws Exception si el archivo no existe o no esta en PKCS#8
     */
    private static PrivateKey leerClavePrivada(Path pem) throws Exception {
        String texto = Files.readString(pem)
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s", "");
        byte[] der = Base64.getDecoder().decode(texto);
        return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(der));
    }

    /**
     * Codifica en Base64 con alfabeto URL y sin relleno, que es lo que exige un JWT.
     *
     * <p>Sin {@code withoutPadding()} el resultado termina en {@code =}, que no es valido dentro
     * de un JWT y hace que el validador lo rechace por razones que no tienen nada que ver con lo
     * que la evidencia quiere demostrar.
     *
     * @param bytes datos a codificar
     * @return el texto codificado
     */
    private static String base64Url(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
