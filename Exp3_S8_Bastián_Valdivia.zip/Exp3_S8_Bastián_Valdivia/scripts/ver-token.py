#!/usr/bin/env python3
"""Muestra el contenido de un JWT: cabecera, payload y vigencia.

Que lugar ocupa esto en la arquitectura
---------------------------------------
Ninguno, igual que los otros dos programas de scripts/. Es una herramienta para producir
evidencia legible; nada del sistema en ejecucion la invoca.

Por que se puede leer un token sin ninguna clave
------------------------------------------------
Porque un JWT NO esta cifrado: esta FIRMADO. Son dos propiedades distintas y confundirlas
lleva al error de guardar datos sensibles dentro de un token creyendo que quedan protegidos.
Cualquiera que intercepte un token puede leer todos sus claims con estas quince lineas. Lo
que nadie puede hacer sin la clave privada es FABRICAR uno que el canal acepte, ni alterar
uno existente sin romper la firma.

Esa es justamente la razon por la que el token viaja siempre dentro de TLS (parte I de la
verificacion) y por la que ningun claim de este proyecto contiene nada que no pueda verse.

Por que hay que reponer el relleno del Base64
---------------------------------------------
Las tres partes de un JWT van en Base64 con alfabeto URL-safe y SIN el relleno de '=' del
final, porque el token tiene que poder viajar en una URL o en una cabecera. El decodificador
de Python si lo espera, asi que hay que reponerlo antes: tantos '=' como falten para que la
longitud sea multiplo de 4, que es lo que calcula "-len(p) % 4".

Uso
---
    python3 scripts/ver-token.py "$TOKEN"
"""
import base64
import datetime
import json
import sys


def parte(codificada):
    """Decodifica una de las partes del JWT y devuelve el diccionario que contiene."""
    relleno = '=' * (-len(codificada) % 4)
    return json.loads(base64.urlsafe_b64decode(codificada + relleno))


def main():
    if len(sys.argv) != 2:
        print("Uso: python3 scripts/ver-token.py <token>", file=sys.stderr)
        return 2

    # Se descarta la firma: es binario y no hay nada legible que mostrar en ella.
    cabecera, cuerpo, _firma = sys.argv[1].split('.')

    print("cabecera:", json.dumps(parte(cabecera)))

    claims = parte(cuerpo)
    print("payload :", json.dumps(claims, indent=2, ensure_ascii=False))

    # iat y exp son segundos desde 1970 en UTC. Se imprimen tambien como fecha legible
    # porque un numero de diez digitos no le dice nada a quien lee la evidencia, y la
    # diferencia entre ambos es la vigencia que el canal prometio en su application.yml.
    iat, exp = claims['iat'], claims['exp']
    utc = datetime.timezone.utc
    print("iat     :", datetime.datetime.fromtimestamp(iat, utc).isoformat())
    print("exp     :", datetime.datetime.fromtimestamp(exp, utc).isoformat())
    print("vigencia:", exp - iat, "segundos =", (exp - iat) // 60, "minutos")
    return 0


if __name__ == '__main__':
    sys.exit(main())
