#!/usr/bin/env bash
# =====================================================================
# verificar-f1.sh: comprobaciones de la fase F1 (Config Server y Eureka)
# contra los servicios locales ya levantados (scripts/levantar-local.sh).
# =====================================================================
# Cada comprobacion imprime PASS o FAIL con el dato real que la sostiene. El
# codigo de salida es 0 solo si todas pasan. No cambia nada permanente: la
# demostracion de refresh edita config-repo/application.yml y lo restaura al
# terminar (tambien si el guion se interrumpe).
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
# ENTORNO=docker (por defecto): contra los contenedores de docker-compose.yaml, con TLS verificado
# por certs/ca.crt y el Actuator/config-server consultados desde dentro de la red interna.
# ENTORNO=local: contra las JVM de scripts/levantar-local.sh. Ver scripts/lib-entorno.sh.
source "$RAIZ/scripts/lib-entorno.sh"

EUREKA=http://localhost:8761
GESTION=(core-service bff-web bff-mobile bff-atm)
# Los servicios de mensajeria (F7) y el auth-server (F5) solo viven en el compose: su puerto de gestion se comprueba
# (health, 404 de env, configprops y heapdump, endpoints expuestos) solo con ENTORNO=docker. No entran en GESTION
# porque esa lista tambien recorre el refresh de info.* y el registro en Eureka, que es de otra comprobacion.
GESTION_COMPOSE=()
if [ "$ENTORNO" = docker ]; then GESTION_COMPOSE=(auth-server notificaciones-service auditoria-service); fi
ARCHIVO_COMUN="config-repo/application.yml"
VALOR_INICIAL='Configuracion centralizada: valor inicial'
VALOR_NUEVO='Configuracion centralizada: valor cambiado en caliente'

FALLOS=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
json() {  # json <expresion python sobre d>   (lee JSON de stdin)
  python3 -c "import sys,json; d=json.load(sys.stdin); print($1)"
}
codigo() { curl_bff -o /dev/null -w '%{http_code}' "$@"; }
# Igual que codigo, pero reintenta SOLO mientras la respuesta sea 503 (hasta ~30 s). Un 503 justo
# despues de levantar o de reiniciar un servicio significa "el balanceador aun no tiene la lista de
# instancias del core" (el cliente de Eureka la baja cada 5 s), no un fallo del sistema. Cualquier
# otro codigo (401, 403, 404...) se devuelve de inmediato: un error real no se disimula con espera.
codigo_estable() {
  local c n=0
  while :; do
    c="$(codigo "$@")"
    if [ "$c" != 503 ] || [ "$n" -ge 15 ]; then echo "$c"; return; fi
    n=$((n + 1)); sleep 2
  done
}

# Puerto de gestion del servicio: en Docker es el 8081 de todos; en local, uno por servicio.
gestion_puerto() {
  if [ "$ENTORNO" = local ]; then puerto_gestion "$1"; else echo 8081; fi
}

# Restaura el valor de la demostracion pase lo que pase.
# Sin comillas dentro de ${var//patron/reemplazo}: el bash 3.2 de macOS las conserva como texto
# literal y habria escrito """valor""" en config-repo (YAML invalido, config-server no sano). Los dos
# valores son texto plano, sin comodines, asi que sin comillas el resultado es el mismo en bash 3.2 y 5.
restaurar() {
  if [ -f "$ARCHIVO_COMUN" ]; then
    contenido="$(<"$ARCHIVO_COMUN")"
    printf '%s\n' "${contenido//$VALOR_NUEVO/$VALOR_INICIAL}" > "$ARCHIVO_COMUN"
  fi
}
trap restaurar EXIT

echo "== 1. Eureka lista los cuatro servicios =="
APPS="$(curl -s -H 'Accept: application/json' "$EUREKA/eureka/apps")"
for app in CORE-SERVICE BFF-WEB BFF-MOBILE BFF-ATM; do
  estado="$(echo "$APPS" | json "[i['status'] for a in d['applications']['application'] if a['name']=='$app' for i in a['instance']]" 2>/dev/null)"
  # Desde F3 el core corre en DOS replicas en el compose (en las JVM locales sigue siendo una).
  esperado="['UP']"
  if [ "$app" = CORE-SERVICE ] && [ "$ENTORNO" = docker ]; then esperado="['UP', 'UP']"; fi
  if [ "$estado" = "$esperado" ]; then resultado PASS "$app registrado" "estado $estado"; else resultado FAIL "$app registrado" "estado: ${estado:-ausente}, esperado $esperado"; fi
done

echo "== 2. config-server entrega la configuracion de cada servicio y perfil =="
for svc in core-service bff-web bff-mobile bff-atm; do
  for perfil in local docker; do
    fuentes="$(config_get "/$svc/$perfil" | json "len([p for p in d['propertySources'] if '/$svc-$perfil.yml' in p['name'] or '/$svc.yml' in p['name']])" 2>/dev/null)"
    if [ "${fuentes:-0}" -ge 2 ]; then resultado PASS "GET /$svc/$perfil" "$fuentes archivos propios del servicio"; else resultado FAIL "GET /$svc/$perfil" "archivos propios: ${fuentes:-0}"; fi
  done
done

echo "== 3. Los BFF llaman al core por nombre logico =="
for svc in bff-web bff-mobile bff-atm; do
  url="$(config_get "/$svc/local" | json "[v for p in d['propertySources'] for k,v in p['source'].items() if k=='core.base-url'][0]" 2>/dev/null)"
  if [ "$url" = "http://core-service" ]; then resultado PASS "$svc core.base-url" "$url"; else resultado FAIL "$svc core.base-url" "${url:-sin valor}"; fi
done

echo "== 4. Login y consulta de cuenta del S5 en los tres canales (core resuelto por Eureka) =="
source "$(dirname "${BASH_SOURCE[0]}")/lib-login.sh"
tok() {  # tok <funcion de lib-login> <args...>: reintenta el login mientras no haya token (mismo motivo que codigo_estable)
  local t n=0
  while :; do
    t="$("$@" 2>/dev/null)"
    if [ -n "$t" ] || [ "$n" -ge 15 ]; then echo "$t"; return; fi
    n=$((n + 1)); sleep 2
  done
}
# Desde F5 el login es del auth-server: PKCE para web y movil, tarjeta y PIN para el cajero.
TW="$(tok token_web cliente116 Cliente.2026)"
TM="$(tok token_movil cliente116 Cliente.2026 dispositivo-demo-01)"
TA="$(tok token_cajero 4000000000000116 1234)"
c="$(codigo_estable $WEB/v1/cuentas/116 -H "Authorization: Bearer $TW")"
[ "$c" = 200 ] && resultado PASS "web: GET /v1/cuentas/116" "HTTP $c" || resultado FAIL "web: GET /v1/cuentas/116" "HTTP $c"
c="$(codigo_estable $MOV/v1/cuentas/116/resumen -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01')"
[ "$c" = 200 ] && resultado PASS "movil: GET /v1/cuentas/116/resumen" "HTTP $c" || resultado FAIL "movil: GET /v1/cuentas/116/resumen" "HTTP $c"
c="$(codigo_estable $ATM/v1/cuentas/116/saldo-disponible -H "Authorization: Bearer $TA")"
[ "$c" = 200 ] && resultado PASS "cajero: GET /v1/cuentas/116/saldo-disponible" "HTTP $c" || resultado FAIL "cajero: GET /v1/cuentas/116/saldo-disponible" "HTTP $c"

echo "== 5. Actuator solo en el puerto de gestion y sin endpoints sensibles =="
for par in "${GESTION[@]}" ${GESTION_COMPOSE[@]+"${GESTION_COMPOSE[@]}"}; do
  svc="$par"; p="$(gestion_puerto "$svc")"
  h="$(gestion "$svc" /actuator/health)"
  # Sin detalle: solo el estado (un BFF agrega la lista de grupos de health, "resiliencia", F6, sin ningun componente).
  estado="$(printf '%s' "$h" | json "d['status'] + ('+componentes' if 'components' in d else '')")"
  [ "$estado" = UP ] && resultado PASS "$svc health en :$p" "$h" || resultado FAIL "$svc health en :$p" "$h"
  for e in env configprops heapdump; do
    c="$(interno_codigo "$svc" "$p" /actuator/$e)"
    [ "$c" = 404 ] && resultado PASS "$svc /actuator/$e no expuesto" "HTTP $c" || resultado FAIL "$svc /actuator/$e no expuesto" "HTTP $c"
  done
  expuestos="$(gestion "$svc" /actuator | json "sorted(k for k in d['_links'] if k != 'self' and '-' not in k)" 2>/dev/null)"
  # Los servicios con Resilience4j exponen ademas sus seis endpoints: los BFF (F6) y, desde F7, el core (envio a Kafka del
  # relay), el auth-server (eventos de seguridad) y notificaciones-service (pasarela). El config-server, el eureka-server y
  # el auditoria-service (no usa Resilience4j), solo los cuatro de siempre.
  case "$svc" in
    bff-*|core-service|auth-server|notificaciones-service) esperado="['bulkheadevents', 'bulkheads', 'circuitbreakerevents', 'circuitbreakers', 'health', 'info', 'metrics', 'refresh', 'retries', 'retryevents']" ;;
    *)     esperado="['health', 'info', 'metrics', 'refresh']" ;;
  esac
  [ "$expuestos" = "$esperado" ] && resultado PASS "$svc endpoints expuestos" "$expuestos" || resultado FAIL "$svc endpoints expuestos" "$expuestos"
done
for u in "$WEB/actuator/health" "$MOV/actuator/health" "$ATM/actuator/health"; do
  c="$(codigo $u)"
  # Exactamente 404 (la ruta no existe en este puerto): "cualquier codigo distinto de 200" daba PASS tambien con 000
  # (servicio caido o conexion rechazada) y no demostraba nada.
  [ "$c" = 404 ] && resultado PASS "Actuator no responde en el puerto de servicio" "HTTP $c en $u" || resultado FAIL "Actuator no responde en el puerto de servicio (se esperaba 404)" "HTTP $c en $u"
done
c="$(interno_codigo core-service 8080 /actuator/health)"
# El core tiene default-deny desde F4: sin token, 401 (no 404).
[ "$c" = 401 ] && resultado PASS "Actuator no responde en el puerto de servicio del core" "HTTP $c en :8080/actuator/health" || resultado FAIL "Actuator no responde en el puerto de servicio del core (se esperaba 401)" "HTTP $c"

echo "== 6. Cambiar info.* en config-repo y POST /actuator/refresh cambia /actuator/info sin reiniciar =="
if ! grep -q "$VALOR_INICIAL" "$ARCHIVO_COMUN"; then
  resultado FAIL "valor inicial presente en $ARCHIVO_COMUN" "no se encontro '$VALOR_INICIAL'"
else
  contenido="$(<"$ARCHIVO_COMUN")"
  printf '%s\n' "${contenido//$VALOR_INICIAL/$VALOR_NUEVO}" > "$ARCHIVO_COMUN"
  for par in "${GESTION[@]}"; do
    svc="$par"
    antes="$(gestion "$svc" /actuator/info | json "d['demostracion']['mensaje']")"
    claves="$(gestion_post "$svc" /actuator/refresh)"
    despues="$(gestion "$svc" /actuator/info | json "d['demostracion']['mensaje']")"
    if [ "$antes" = "$VALOR_INICIAL" ] && [ "$despues" = "$VALOR_NUEVO" ]; then
      resultado PASS "$svc refresh" "'$antes' -> '$despues'; claves refrescadas $claves"
    else
      resultado FAIL "$svc refresh" "antes='$antes' despues='$despues'"
    fi
  done
  restaurar
  for par in "${GESTION[@]}"; do   # deja los servicios con el valor original
    gestion_post "$par" /actuator/refresh > /dev/null
  done
  # El refresh NO debe reconstruir el cliente de Eureka (eureka.client.refresh.enable=false en
  # config-repo/application.yml). Si lo hiciera, el balanceador quedaria sin instancias del core
  # unos segundos y esta consulta, hecha sin espera ni reintento, daria 503. Se usa el cajero
  # porque no tiene cache (web y movil podrian responder desde la suya y no probarian nada).
  c="$(codigo $ATM/v1/cuentas/116/saldo-disponible -H "Authorization: Bearer $TA")"
  [ "$c" = 200 ] && resultado PASS "cajero responde justo despues de los refresh, sin espera" "HTTP $c" || resultado FAIL "cajero responde justo despues de los refresh, sin espera" "HTTP $c"
fi

echo
if [ "$FALLOS" -eq 0 ]; then echo "RESULTADO: todo PASS"; else echo "RESULTADO: $FALLOS comprobaciones FAIL"; exit 1; fi
