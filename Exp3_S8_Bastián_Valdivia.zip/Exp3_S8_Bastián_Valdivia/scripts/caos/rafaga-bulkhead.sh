#!/usr/bin/env bash
# =====================================================================
# rafaga-bulkhead.sh: una rafaga de peticiones simultaneas contra el mamparo (bulkhead). F6, escenario 3.
# =====================================================================
# El mamparo limita cuantas llamadas SIMULTANEAS puede haber hacia el core: 20 en web y movil, 5 en el cajero
# (config-repo/bff-*.yml, resilience4j.bulkhead.instances.core.max-concurrent-calls). Lo que excede el limite se
# rechaza AL INSTANTE (max-wait-duration 0), sin ocupar un hilo de Tomcat esperando, y el canal responde con su
# respaldo: web y movil, el ultimo dato conocido marcado como desactualizado; el cajero, 503 con su pantalla E-090.
#
# Para que haya llamadas simultaneas el core se pone a 300 ms de latencia (config + refresh): mucho menos que el
# umbral de lentitud del circuito (1 s), de modo que el circuito NO abre y se ve solo el efecto del mamparo. (Con 600 ms,
# la contencion de 20 peticiones TLS simultaneas llevo algunas llamadas aceptadas a 1,15 s, por encima del umbral de
# lentitud, y con fallos viejos en la ventana el circuito del cajero abrio: medido, y por eso 300 ms.) La rafaga la
# dispara scripts/caos/cliente_caos.py con todos los hilos esperando en una barrera.
#
# Uso:  scripts/caos/rafaga-bulkhead.sh [--sin-movil]    (con movil son ~1 minuto mas: hay que esperar su cache)
# =====================================================================
set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib-caos.sh
source "$DIR/lib-caos.sh"
CON_MOVIL=1; [ "${1:-}" = "--sin-movil" ] && CON_MOVIL=0
trap restaurar_latencia EXIT

rechazos() { metrica_contador "$1" bancoxyz.core.rechazos "motivo:mamparo_lleno"; }
# Cuantos CALL_REJECTED guarda Actuator para el mamparo "core" desde el instante <epoch>. Actuator conserva solo los
# ultimos 100 eventos del mamparo (permitidos, terminados y rechazados mezclados), asi que contar el total antes y
# despues no sirve: una rafaga grande empuja fuera del buffer a los eventos viejos (se midio: 18 en vez de 20).
eventos_rechazo_desde() {
  gestion "$1" /actuator/bulkheadevents/core/CALL_REJECTED 2> /dev/null | python3 -c "
import sys, json, calendar, time
desde = int($2)
try:
    n = 0
    for e in json.load(sys.stdin)['bulkheadEvents']:
        t = calendar.timegm(time.strptime(e['creationTime'][:19], '%Y-%m-%dT%H:%M:%S'))
        n += 1 if t >= desde else 0
    print(n)
except Exception:
    print(0)"
}
limite() {  # el maximo configurado, leido de Actuator (no de este script)
  gestion "$1" "/actuator/metrics/resilience4j.bulkhead.max.allowed.concurrent.calls?tag=name:core" 2> /dev/null | python3 -c "
import sys, json
try:
    print(int(json.load(sys.stdin)['measurements'][0]['value']))
except Exception:
    print('?')"
}

echo "Escenario: rafaga contra el mamparo"
pedir_tokens
asegurar_circuitos_cerrados

titulo "0. Preparacion: el respaldo se llena con el core sano"
R="$(serie_web --n 1 | solo_resumen)"; igual "web: movimientos 200 fresco (queda como ultimo dato conocido)" 1 "$(valor_resumen "$R" http200_frescos)"
if [ "$CON_MOVIL" = 1 ]; then
  R="$(serie_movil --n 1 | solo_resumen)"; igual "movil: resumen 200 fresco" 1 "$(valor_resumen "$R" http200_frescos)"
fi
LIM_WEB="$(limite bff-web)"; LIM_MOV="$(limite bff-mobile)"; LIM_ATM="$(limite bff-atm)"
echo "  limites leidos de Actuator: web=$LIM_WEB movil=$LIM_MOV cajero=$LIM_ATM llamadas simultaneas"
fijar_latencia 300

titulo "1. Cajero: 20 peticiones simultaneas (limite $LIM_ATM)"
pedir_token_atm
R0="$(rechazos bff-atm)"; E0="$(date -u +%s)"
SAL="$(rafaga_atm --n 20)"; echo "$SAL" | sed 's/^/     /'; R="$(echo "$SAL" | solo_resumen)"
ACEPTADAS="$(valor_resumen "$R" http200)"; RECHAZADAS="$(valor_resumen "$R" http503)"
echo "  aceptadas (200): $ACEPTADAS   rechazadas (503): $RECHAZADAS"
afirmar "cajero: no se atendieron mas llamadas simultaneas que el limite" "$ACEPTADAS de $LIM_ATM" test "$ACEPTADAS" -le "$LIM_ATM"
afirmar "cajero: lo que excede el limite se rechazo" "$RECHAZADAS rechazadas" test "$RECHAZADAS" -ge $((20 - LIM_ATM))
igual "cajero: aceptadas + rechazadas = 20 (ninguna se perdio)" 20 $((ACEPTADAS + RECHAZADAS))
igual "cajero: las rechazadas son 503 core_no_disponible" "{\"core_no_disponible\":$RECHAZADAS}" "$(valor_resumen "$R" motivos)"
echo "     pantalla de las rechazadas: $(echo "$SAL" | awk -F'\t' '$2==503 {print $6}' | sort -u | tr '\n' ' ')"
igual "cajero: la metrica bancoxyz.core.rechazos{motivo=mamparo_lleno} subio en las rechazadas" "$RECHAZADAS" $(( $(rechazos bff-atm) - R0 ))
igual "cajero: Actuator guarda un CALL_REJECTED por cada una (bulkheadevents)" "$RECHAZADAS" "$(eventos_rechazo_desde bff-atm "$E0")"
echo "     (tiempo de las rechazadas: mediana $(echo "$SAL" | awk -F'\t' '$2==503 {print $7}' | sort -n | awk '{a[NR]=$1} END {print a[int((NR+1)/2)]}') ms; las aceptadas esperan los 300 ms de latencia)"
igual "cajero: ningun saldo en las rechazadas (con_saldo = aceptadas)" "$ACEPTADAS" "$(valor_resumen "$R" con_saldo)"
igual "cajero: el circuito sigue CLOSED (rechazar no es fallar)" CLOSED "$(estado_circuito bff-atm)"
igual "cajero: failedCalls = 0" 0 "$(metrica_circuito bff-atm failedCalls)"

titulo "2. Web: 60 peticiones simultaneas (limite $LIM_WEB)"
R0="$(rechazos bff-web)"; E0="$(date -u +%s)"
SAL="$(rafaga_web --n 60)"; echo "$SAL" | awk 'NR<=6 || /RESUMEN/' | sed 's/^/     /'; echo "     ... (60 lineas; se muestran las primeras y el resumen)"
R="$(echo "$SAL" | solo_resumen)"
FRESCAS="$(valor_resumen "$R" http200_frescos)"; RESPALDO="$(valor_resumen "$R" http200_desactualizados)"
echo "  atendidas por el core (frescas): $FRESCAS   respondidas con el respaldo (desactualizadas): $RESPALDO"
afirmar "web: no se atendieron mas llamadas simultaneas que el limite" "$FRESCAS de $LIM_WEB" test "$FRESCAS" -le "$LIM_WEB"
afirmar "web: lo que excede el limite se respondio con el respaldo marcado" "$RESPALDO desactualizadas" test "$RESPALDO" -ge $((60 - LIM_WEB))
igual "web: las 60 respuestas fueron 200 (ninguna se perdio ni dio 503)" 60 "$(valor_resumen "$R" http200)"
igual "web: la metrica de rechazos subio en las respondidas con respaldo" "$RESPALDO" $(( $(rechazos bff-web) - R0 ))
igual "web: Actuator guarda un CALL_REJECTED por cada una" "$RESPALDO" "$(eventos_rechazo_desde bff-web "$E0")"
igual "web: el circuito sigue CLOSED" CLOSED "$(estado_circuito bff-web)"

if [ "$CON_MOVIL" = 1 ]; then
  titulo "3. Movil: 40 peticiones simultaneas (limite $LIM_MOV), con la cache de 30 s vencida"
  echo "  esperando 31 s a que venza la cache del canal movil..."
  sleep 31
  R0="$(rechazos bff-mobile)"; E0="$(date -u +%s)"
  SAL="$(rafaga_movil --n 40)"; echo "$SAL" | awk 'NR<=4 || /RESUMEN/' | sed 's/^/     /'; echo "     ... (40 lineas)"
  R="$(echo "$SAL" | solo_resumen)"
  FRESCAS="$(valor_resumen "$R" http200_frescos)"; RESPALDO="$(valor_resumen "$R" http200_desactualizados)"
  echo "  frescas: $FRESCAS   respaldo (desactualizadas): $RESPALDO"
  afirmar "movil: no se atendieron mas llamadas simultaneas que el limite" "$FRESCAS de $LIM_MOV" test "$FRESCAS" -le "$LIM_MOV"
  afirmar "movil: lo que excede el limite se respondio con el respaldo marcado" "$RESPALDO desactualizadas" test "$RESPALDO" -ge $((40 - LIM_MOV))
  igual "movil: las 40 respuestas fueron 200" 40 "$(valor_resumen "$R" http200)"
  igual "movil: la metrica de rechazos subio en las respondidas con respaldo" "$RESPALDO" $(( $(rechazos bff-mobile) - R0 ))
  igual "movil: Actuator guarda un CALL_REJECTED por cada una" "$RESPALDO" "$(eventos_rechazo_desde bff-mobile "$E0")"
  igual "movil: el circuito sigue CLOSED" CLOSED "$(estado_circuito bff-mobile)"
fi

titulo "Cierre: sin latencia, todo sigue sano"
restaurar_latencia
pedir_tokens
R="$(serie_atm --n 3 | solo_resumen)"; igual "cajero: saldo 200 otra vez" 3 "$(valor_resumen "$R" http200_frescos)"
R="$(serie_web --n 3 | solo_resumen)"; igual "web: 200 frescos otra vez" 3 "$(valor_resumen "$R" http200_frescos)"
fin_caos
