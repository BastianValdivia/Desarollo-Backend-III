#!/usr/bin/env bash
# =====================================================================
# reinicio-automatico.sh: Docker reinicia SOLO un contenedor caido y el servicio vuelve a Eureka. F6, escenario 5.
# =====================================================================
# Todos los servicios del compose declaran  restart: unless-stopped.  Pero NO toda forma de terminar el proceso
# activa esa politica, y eso es lo que este guion determina midiendo, no suponiendo:
#
#   docker kill (SIGKILL)         NO reinicia: Docker lo trata como una detencion hecha por una persona
#   docker kill -s TERM           NO reinicia: igual (cualquier "docker kill" cuenta como detencion manual)
#   docker stop                   NO reinicia: detencion manual (es la que "unless-stopped" respeta)
#   docker exec ... kill -9 1     SIN EFECTO: el nucleo no entrega SIGKILL al PID 1 desde dentro de su propio
#                                 espacio de procesos, y el contenedor sigue como estaba
#   docker exec ... kill 1        SI reinicia: el proceso (la JVM, PID 1) recibe SIGTERM DESDE DENTRO, apaga y sale
#                                 con codigo 143. Docker no lo ve como una orden suya, sino como un contenedor que
#                                 termino solo, y aplica unless-stopped. Es lo mismo que pasa cuando la JVM sale
#                                 por un fallo propio (por ejemplo OutOfMemoryError con -XX:+ExitOnOutOfMemoryError).
#
# Sin argumentos: el control negativo (docker kill, que NO reinicia) y el positivo (kill 1 desde dentro, que SI),
# con la evidencia completa: RestartCount, hora de inicio, salud y registro en Eureka antes y despues.
# --matriz: prueba los cinco metodos (tarda unos 3 minutos).
#
# Se usa una replica del core: es un servicio que se registra en Eureka, y la otra replica sigue atendiendo.
#
# Uso:  scripts/caos/reinicio-automatico.sh [--matriz]
# =====================================================================
set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib-caos.sh
source "$DIR/lib-caos.sh"

# Pase lo que pase, las dos replicas quedan arriba.
volver_a_levantar() {
  local id
  for id in $("${COMPOSE[@]}" ps -a -q core-service); do
    [ "$(docker inspect -f '{{.State.Running}}' "$id" 2> /dev/null)" = true ] || docker start "$id" > /dev/null 2>&1
  done
}
trap volver_a_levantar EXIT

ID="$(ids_core | sed -n 1p)"
CORTO="${ID:0:12}"
NOMBRE="$(docker inspect -f '{{.Name}}' "$ID" | tr -d '/')"

reinicios() { docker inspect -f '{{.RestartCount}}' "$ID" 2> /dev/null || echo "?"; }
inicio_de() { docker inspect -f '{{.State.StartedAt}}' "$ID" 2> /dev/null || echo "?"; }
estado_eureka() {  # estado de ESTA replica en Eureka, o "ausente"
  local linea
  linea="$(eureka_instancias_core | grep "^$CORTO" | head -1 | awk '{print $2}')"
  echo "${linea:-ausente}"
}
esperar_eureka() {  # esperar_eureka <estado> <segundos>
  local i=0
  while [ "$(estado_eureka)" != "$1" ] && [ "$i" -lt "$2" ]; do sleep 1; i=$((i + 1)); done
  [ "$(estado_eureka)" = "$1" ]
}

# probar <etiqueta> <esperado: REINICIA|NO_REINICIA|SIN_EFECTO> <comando...>
probar() {
  local etiqueta="$1" esperado="$2" n0 t0 resultado i=0 detalle e; shift 2
  titulo "$etiqueta"
  esperar_core_sano 150 > /dev/null
  n0="$(reinicios)"; t0="$(inicio_de)"
  echo "  antes:   RestartCount=$n0  StartedAt=$t0  Eureka=$(estado_eureka)  salud=$(estado_contenedor "$ID")"
  echo "  comando: $*"
  "$@" > /dev/null 2>&1
  # Se observa 40 s (o hasta que Docker reinicie el contenedor, lo que ocurra DESPUES): cada segundo se anota el
  # estado de esta replica en Eureka, para ver la secuencia (por ejemplo UP -> ausente -> UP).
  SECUENCIA="UP"; ULTIMO="UP"
  while [ "$i" -lt 40 ]; do
    e="$(estado_eureka)"
    if [ "$e" != "$ULTIMO" ]; then SECUENCIA="$SECUENCIA -> $e"; ULTIMO="$e"; fi
    if [ "$(reinicios)" != "$n0" ] && [ "$i" -ge 5 ]; then break; fi
    i=$((i + 1)); sleep 1
  done
  detalle="RestartCount=$(reinicios)  estado=$(docker inspect -f '{{.State.Status}} exit={{.State.ExitCode}}' "$ID")  StartedAt=$(inicio_de)"
  if [ "$(reinicios)" != "$n0" ]; then
    resultado=REINICIA
  elif [ "$(inicio_de)" = "$t0" ] && [ "$(docker inspect -f '{{.State.Running}}' "$ID")" = true ]; then
    resultado=SIN_EFECTO
  else
    resultado=NO_REINICIA
  fi
  echo "  despues: $detalle"
  echo "  Eureka durante la observacion: $SECUENCIA"
  igual "$etiqueta: Docker $resultado" "$esperado" "$resultado"
  if [ "$resultado" = REINICIA ]; then
    if esperar_core_sano 150; then resultado_ok=SI; else resultado_ok=NO; fi
    igual "el contenedor vuelve a estar healthy solo, sin intervencion" SI "$resultado_ok"
    echo "  salud: $(estado_contenedor "$ID")   RestartCount=$(reinicios)   StartedAt=$(inicio_de)"
    if esperar_eureka UP 90; then resultado_ok=SI; else resultado_ok=NO; fi
    igual "el servicio vuelve a registrarse en Eureka (estado UP)" SI "$resultado_ok"
    echo "  Eureka, secuencia completa: $SECUENCIA -> $(estado_eureka)"
    echo "  Eureka (instanceId estado): $(eureka_instancias_core | tr '\n' ';')"
    echo "  log del contenedor, ultimas lineas de arranque:"
    docker logs --since "$(inicio_de)" "$ID" 2>&1 | grep -E "Started CoreServiceApplication|Tomcat started|registration status|Registered instance" | head -4 | cut -c1-200 | sed 's/^/     /'
  else
    # No reinicio: se levanta a mano para el siguiente caso.
    if [ "$(docker inspect -f '{{.State.Running}}' "$ID")" != true ]; then
      echo "  >> sigue detenido (como debe): se levanta a mano con docker start para seguir"
      docker start "$ID" > /dev/null
    fi
  fi
}

echo "Escenario: reinicio automatico (restart: unless-stopped) de $NOMBRE"
echo "  politica declarada: $(docker inspect -f '{{.HostConfig.RestartPolicy.Name}}' "$ID")"
igual "politica de reinicio del contenedor" unless-stopped "$(docker inspect -f '{{.HostConfig.RestartPolicy.Name}}' "$ID")"
echo "  instancias en Eureka: $(eureka_instancias_core | tr '\n' ';')"

if [ "${1:-}" = "--matriz" ]; then
  probar "docker kill (SIGKILL)"                     NO_REINICIA docker kill "$ID"
  probar "docker kill -s TERM"                       NO_REINICIA docker kill -s TERM "$ID"
  probar "docker stop"                               NO_REINICIA docker stop "$ID"
  probar "docker exec kill -9 1 (SIGKILL desde dentro)" SIN_EFECTO docker exec "$ID" kill -9 1
  probar "docker exec kill 1 (SIGTERM desde dentro)" REINICIA docker exec "$ID" kill 1
else
  probar "Control negativo: docker kill (lo que una persona hace a mano)" NO_REINICIA docker kill "$ID"
  probar "El proceso termina por si mismo: docker exec kill 1 (SIGTERM al PID 1 desde dentro)" REINICIA docker exec "$ID" kill 1
fi
fin_caos
