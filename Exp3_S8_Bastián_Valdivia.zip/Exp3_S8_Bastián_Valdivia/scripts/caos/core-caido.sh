#!/usr/bin/env bash
# =====================================================================
# core-caido.sh: el core se cae por completo (ambas replicas) y vuelve. F6, escenario 1.
# =====================================================================
# Que demuestra, con numeros y con los eventos de Actuator:
#   1. Con el core caido, el circuito de CADA BFF pasa de CLOSED a OPEN.
#   2. Web y movil siguen respondiendo 200 con el ULTIMO dato conocido, marcado como desactualizado
#      (X-Datos-Desactualizados: true); el cajero falla cerrado: 503 con su pantalla E-090, jamas un saldo
#      ni un folio.
#   3. Al volver el core, cada circuito pasa por HALF_OPEN y termina en CLOSED, y las respuestas vuelven a ser
#      frescas, sin la marca.
#
# Uso:  scripts/caos/core-caido.sh          (docker compose up -d --wait antes; tarda unos 3 minutos)
# Deja el stack como estaba (core levantado). Los retiros de prueba NO llegan a ejecutarse: el core esta caido.
# =====================================================================
set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib-caos.sh
source "$DIR/lib-caos.sh"

# Si el script se corta a mitad de la caida, el core queda detenido: se vuelve a levantar siempre.
volver_a_levantar() {
  if [ -z "$("${COMPOSE[@]}" ps -q --status running core-service 2> /dev/null)" ]; then
    echo "  >> restaurando: docker compose start core-service"
    "${COMPOSE[@]}" start core-service > /dev/null 2>&1
  fi
}
trap volver_a_levantar EXIT

# El circuito se mira justo despues del trafico de cada canal: abierto dura 10 s y pasa solo a HALF_OPEN.
comprobar_abierto() {  # comprobar_abierto <bff>
  esperar_estado "$1" OPEN 3 > /dev/null
  igual "circuito core de $1 ABIERTO" OPEN "$(estado_circuito "$1")"
  echo "     $(gestion "$1" /actuator/health/resiliencia | python3 -c "import sys,json; c=json.load(sys.stdin)['components']['circuitBreakers']['details']['core']['details']; print('/actuator/health/resiliencia: state=%s failureRate=%s notPermittedCalls=%s' % (c['state'], c['failureRate'], c['notPermittedCalls']))" 2> /dev/null)"
}

echo "Escenario: core caido (ambas replicas detenidas) y recuperacion"
pedir_tokens
asegurar_circuitos_cerrados

titulo "0. Punto de partida"
for bff in bff-web bff-mobile bff-atm; do
  igual "circuito core de $bff al empezar" CLOSED "$(estado_circuito "$bff")"
done
N0_WEB="$(marca_de_tiempo)"; N0_MOV="$(marca_de_tiempo)"; N0_ATM="$(marca_de_tiempo)"
SALDO_ANTES="$(sql_postgres core "SELECT saldo FROM cuenta WHERE id = 116" | tr -d '\r')"
echo "  saldo de la cuenta 116 antes: $SALDO_ANTES"

titulo "1. Con el core sano: se llena el respaldo (ultimo dato conocido)"
R="$(serie_web --n 1 | solo_resumen)"; igual "web: movimientos 200 fresco" "1" "$(valor_resumen "$R" http200_frescos)"
python3 "$CLIENTE_CAOS" serie --cacert "$CA_CRT" --url "$URL_W_FICHA" --header "Authorization: Bearer $TOKEN_WEB" --n 1 > /dev/null
R="$(serie_movil --n 1 | solo_resumen)"; igual "movil: resumen 200 fresco" "1" "$(valor_resumen "$R" http200_frescos)"
R="$(serie_atm --n 1 | solo_resumen)"; igual "cajero: saldo 200" "1" "$(valor_resumen "$R" http200_frescos)"
echo "  esperando 31 s a que venza la cache del canal movil (30 s): sin ella, el resumen tendria que viajar al core"
sleep 31

titulo "2. Se detienen las DOS replicas del core"
INICIO="$(date +%s)"
"${COMPOSE[@]}" stop core-service 2>&1 | sed 's/^/    /'
echo "  replicas del core en ejecucion: $("${COMPOSE[@]}" ps -q --status running core-service | wc -l | tr -d ' ')"

titulo "3. Trafico con el core caido (12 peticiones por canal, una cada 300 ms)"
pedir_tokens
echo "  -- web: GET movimientos (n codigo desactualizado antiguedad motivo pantalla ms)"
SAL="$(serie_web --n 12 --pausa-ms 300)"; echo "$SAL" | sed 's/^/     /'; R="$(echo "$SAL" | solo_resumen)"
igual "web: las 12 respuestas son 200" 12 "$(valor_resumen "$R" http200)"
afirmar "web: se sirvio el ultimo dato conocido marcado como desactualizado" "$(valor_resumen "$R" http200_desactualizados) de 12" test "$(valor_resumen "$R" http200_desactualizados)" -ge 1
comprobar_abierto bff-web
echo "  -- movil: GET resumen"
SAL="$(serie_movil --n 12 --pausa-ms 300)"; echo "$SAL" | sed 's/^/     /'; R="$(echo "$SAL" | solo_resumen)"
igual "movil: las 12 respuestas son 200" 12 "$(valor_resumen "$R" http200)"
afirmar "movil: se sirvio el ultimo dato conocido marcado como desactualizado" "$(valor_resumen "$R" http200_desactualizados) de 12" test "$(valor_resumen "$R" http200_desactualizados)" -ge 1
comprobar_abierto bff-mobile
echo "  -- cajero: GET saldo-disponible"
SAL="$(serie_atm --n 12 --pausa-ms 300)"; echo "$SAL" | sed 's/^/     /'; R="$(echo "$SAL" | solo_resumen)"
igual "cajero: las 12 respuestas son 503" 12 "$(valor_resumen "$R" http503)"
igual "cajero: ningun saldo entregado" 0 "$(valor_resumen "$R" con_saldo)"
afirmar "cajero: todas con motivo core_no_disponible" "$(valor_resumen "$R" motivos)" test "$(valor_resumen "$R" motivos)" = '{"core_no_disponible":12}'
comprobar_abierto bff-atm
echo "  -- cajero: POST retiro de 1000 (Idempotency-Key caos-retiro-1)"
pedir_token_atm
SAL="$(retiro_atm --n 1 --clave-prefijo caos-retiro)"; echo "$SAL" | sed 's/^/     /'; R="$(echo "$SAL" | solo_resumen)"
igual "cajero: el retiro responde 503" 1 "$(valor_resumen "$R" http503)"
igual "cajero: sin folio (no se simula ningun retiro)" 0 "$(valor_resumen "$R" con_folio)"

titulo "4. Docker no reinicia a los BFF por tener un circuito abierto"
echo "  health global de bff-web (lo que mira Docker): $(gestion bff-web /actuator/health | head -c 60)"
igual "el BFF sigue 'healthy' para Docker con el circuito abierto" "running/healthy" "$(estado_contenedor "$("${COMPOSE[@]}" ps -q bff-web)")"

titulo "5. Pasados 10 s sin trafico, los circuitos pasan solos a HALF_OPEN"
for bff in bff-web bff-mobile bff-atm; do
  esperar_estado "$bff" HALF_OPEN 25 > /dev/null
  igual "circuito core de $bff" HALF_OPEN "$(estado_circuito "$bff")"
done

titulo "6. Vuelve el core"
"${COMPOSE[@]}" start core-service 2>&1 | sed 's/^/    /'
if esperar_core_sano 240; then resultado PASS "las dos replicas del core vuelven a estar healthy" "$(( $(date +%s) - INICIO )) s desde que se detuvieron"
else resultado FAIL "el core no volvio a estar healthy en 240 s"; fi

titulo "7. Trafico de prueba: HALF_OPEN -> CLOSED (una peticion por segundo, hasta 150 s por canal)"
pedir_tokens
# El movil tarda mas: su cache de 30 s hace que solo UNA peticion cada 30 s llegue al core, y el circuito
# semiabierto necesita 3 llamadas de prueba exitosas (permitted-number-of-calls-in-half-open-state: 3).
recuperar_circuito bff-web 150
recuperar_circuito bff-atm 150
recuperar_circuito bff-mobile 150
for bff in bff-web bff-mobile bff-atm; do
  igual "circuito core de $bff" CLOSED "$(estado_circuito "$bff")"
done
pedir_token_atm
R="$(serie_web --n 3 | solo_resumen)"; igual "web: respuestas frescas otra vez" 3 "$(valor_resumen "$R" http200_frescos)"
R="$(serie_movil --n 3 | solo_resumen)"; igual "movil: respuestas 200 otra vez" 3 "$(valor_resumen "$R" http200)"
R="$(serie_atm --n 3 | solo_resumen)"; igual "cajero: saldo 200 otra vez" 3 "$(valor_resumen "$R" http200_frescos)"

titulo "8. Eventos de Actuator (/actuator/circuitbreakerevents/core/STATE_TRANSITION) de este escenario"
for par in "bff-web:$N0_WEB" "bff-mobile:$N0_MOV" "bff-atm:$N0_ATM"; do
  bff="${par%%:*}"; n0="${par##*:}"
  echo "  $bff:"
  transiciones_desde "$bff" "$n0" | sed 's/^/     /'
  igual "$bff: el ciclo CLOSED -> OPEN -> HALF_OPEN -> CLOSED aparece en los eventos" SI "$(ciclo_completo "$bff" "$n0")"
done

titulo "9. El cajero no invento nada"
SALDO_DESPUES="$(sql_postgres core "SELECT saldo FROM cuenta WHERE id = 116" | tr -d '\r')"
igual "saldo de la cuenta 116 sin cambios" "$SALDO_ANTES" "$SALDO_DESPUES"
igual "ninguna clave de idempotencia caos-retiro-* registrada" 0 "$(sql_postgres core "SELECT count(*) FROM idempotencia WHERE clave LIKE 'caos-retiro-%'" | tr -d '\r')"

fin_caos
