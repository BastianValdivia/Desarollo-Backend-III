#!/usr/bin/env python3
"""
cliente_caos.py: el cliente HTTP de los escenarios de caos (scripts/caos/*.sh).

Por que existe un cliente propio y no un bucle de curl. Los escenarios necesitan dos cosas que un bucle de
curl hace mal y que tienen que ser exactas para que el numero que se publica sea verdad:

  - una RAFAGA de N peticiones verdaderamente simultaneas (todos los hilos esperan en una barrera y salen a
    la vez), para medir el mamparo. Lanzar N procesos curl uno tras otro escalona las llegadas y hace que las
    primeras terminen antes de que lleguen las ultimas, con lo que el mamparo casi nunca se llena;
  - una SERIE de N peticiones con una accion (por ejemplo, detener una replica del core) disparada justo
    despues de la peticion K, para que la falla ocurra A MITAD del trafico y no antes ni despues.

Subcomandos:
  rafaga  N peticiones simultaneas.
  serie   N peticiones una tras otra (con pausa opcional) y una accion opcional tras la peticion K.

Cada peticion imprime una linea:  n codigo desactualizado antiguedad motivo ms  y, al final, un resumen
parseable que empieza por RESUMEN. Solo usa la libreria estandar de Python 3 (sin pip).
"""
import argparse
import http.client
import json
import shlex
import ssl
import subprocess
import sys
import threading
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor


def conectar(args):
    """Abre la conexion TLS (apreton de manos incluido) sin enviar nada todavia."""
    destino = urllib.parse.urlsplit(args.url)
    contexto = ssl.create_default_context(cafile=args.cacert)
    conexion = http.client.HTTPSConnection(destino.hostname, destino.port or 443, context=contexto,
                                           timeout=args.timeout)
    conexion.connect()
    return conexion


def una_peticion(args, numero, conexion=None):
    """Hace una peticion y devuelve un diccionario con lo que interesa de la respuesta."""
    destino = urllib.parse.urlsplit(args.url)
    cabeceras = {}
    for h in args.header or []:
        clave, valor = h.split(":", 1)
        cabeceras[clave.strip()] = valor.strip()
    cuerpo = None
    if args.metodo == "POST":
        cuerpo = args.cuerpo.encode()
        cabeceras.setdefault("Content-Type", "application/json")
        if args.clave_prefijo:
            cabeceras["Idempotency-Key"] = "%s-%d" % (args.clave_prefijo, numero)
    inicio = time.monotonic()
    try:
        if conexion is None:
            conexion = conectar(args)
        ruta = destino.path + ("?" + destino.query if destino.query else "")
        conexion.request(args.metodo, ruta, body=cuerpo, headers=cabeceras)
        respuesta = conexion.getresponse()
        texto = respuesta.read().decode("utf-8", "replace")
        codigo = respuesta.status
        desactualizado = (respuesta.getheader("X-Datos-Desactualizados") or "no")
        antiguedad = respuesta.getheader("X-Datos-Antiguedad-Segundos") or "-"
        conexion.close()
    except Exception as error:  # noqa: BLE001: el cliente de caos informa cualquier fallo, no lo oculta
        return {"n": numero, "codigo": 0, "desactualizado": "no", "antiguedad": "-",
                "motivo": "error_cliente:" + type(error).__name__, "ms": int((time.monotonic() - inicio) * 1000),
                "saldo": False, "folio": False, "pantalla": "-"}
    motivo, pantalla = "-", "-"
    try:
        datos = json.loads(texto)
        if isinstance(datos, dict):
            motivo = str(datos.get("motivo", "-"))
            pantalla = str(datos.get("codigoPantalla", "-"))
    except ValueError:
        pass
    return {"n": numero, "codigo": codigo, "desactualizado": desactualizado, "antiguedad": antiguedad,
            "motivo": motivo, "ms": int((time.monotonic() - inicio) * 1000),
            "saldo": "saldoDisponible" in texto, "folio": '"folio"' in texto, "pantalla": pantalla}


def imprimir(r):
    print("%d\t%d\t%s\t%s\t%s\t%s\t%d" % (r["n"], r["codigo"], r["desactualizado"], r["antiguedad"], r["motivo"],
                                           r["pantalla"], r["ms"]))
    sys.stdout.flush()


def resumen(resultados):
    ok = [r for r in resultados if r["codigo"] == 200]
    frescos = [r for r in ok if r["desactualizado"] != "true"]
    obsoletos = [r for r in ok if r["desactualizado"] == "true"]
    s503 = [r for r in resultados if r["codigo"] == 503]
    otros = [r for r in resultados if r["codigo"] not in (200, 503)]
    motivos = {}
    for r in resultados:
        if r["codigo"] != 200:
            motivos[r["motivo"]] = motivos.get(r["motivo"], 0) + 1
    ms = sorted(r["ms"] for r in resultados) or [0]
    print("RESUMEN total=%d http200=%d http200_frescos=%d http200_desactualizados=%d http503=%d otros=%d "
          "con_saldo=%d con_folio=%d ms_min=%d ms_mediana=%d ms_max=%d motivos=%s" % (
              len(resultados), len(ok), len(frescos), len(obsoletos), len(s503), len(otros),
              sum(1 for r in resultados if r["saldo"]), sum(1 for r in resultados if r["folio"]),
              ms[0], ms[len(ms) // 2], ms[-1], json.dumps(motivos, sort_keys=True, separators=(",", ":"))))


def rafaga(args):
    barrera = threading.Barrier(args.n)
    def tarea(numero):
        # Cada hilo abre su conexion TLS ANTES de la barrera: asi las N peticiones salen juntas y el
        # tiempo del apreton de manos no escalona las llegadas al servidor.
        conexion = conectar(args)
        barrera.wait()
        return una_peticion(args, numero, conexion)
    with ThreadPoolExecutor(max_workers=args.n) as pool:
        resultados = list(pool.map(tarea, range(1, args.n + 1)))
    for r in resultados:
        imprimir(r)
    resumen(resultados)


def serie(args):
    resultados = []
    accion = None
    for numero in range(1, args.n + 1):
        r = una_peticion(args, numero)
        resultados.append(r)
        imprimir(r)
        if args.accion and numero == args.accion_en:
            # La accion corre en segundo plano: la serie sigue sin esperarla, que es lo que pasa en un
            # incidente real (la replica muere mientras el trafico continua).
            print("ACCION tras la peticion %d: %s" % (numero, args.accion))
            sys.stdout.flush()
            # Sin shell: el comando se parte en argumentos y la salida se descarta desde aqui. Con shell=True, en
            # Windows (Python nativo) el comando pasaria por cmd.exe, donde "> /dev/null" no existe.
            accion = subprocess.Popen(shlex.split(args.accion), stdout=subprocess.DEVNULL)
        if args.pausa_ms:
            time.sleep(args.pausa_ms / 1000.0)
    if accion is not None:
        accion.wait()
    resumen(resultados)


def main():
    analizador = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analizador.add_argument("modo", choices=["rafaga", "serie"])
    analizador.add_argument("--url", required=True)
    analizador.add_argument("--cacert", required=True)
    analizador.add_argument("--n", type=int, required=True)
    analizador.add_argument("--header", action="append")
    analizador.add_argument("--metodo", default="GET", choices=["GET", "POST"])
    analizador.add_argument("--cuerpo", default="")
    analizador.add_argument("--clave-prefijo", default="")
    analizador.add_argument("--timeout", type=float, default=30.0)
    analizador.add_argument("--pausa-ms", type=int, default=0)
    analizador.add_argument("--accion", default="")
    analizador.add_argument("--accion-en", type=int, default=0)
    args = analizador.parse_args()
    {"rafaga": rafaga, "serie": serie}[args.modo](args)


if __name__ == "__main__":
    main()
