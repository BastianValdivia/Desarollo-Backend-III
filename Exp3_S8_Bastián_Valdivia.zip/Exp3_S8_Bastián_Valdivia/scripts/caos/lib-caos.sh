#!/usr/bin/env bash
# =====================================================================
# lib-caos.sh: piezas comunes de los escenarios de caos de la fase F6 (scripts/caos/*.sh).
# =====================================================================
# Se importa con "source" DESPUES de elegir el directorio de trabajo. Define:
#
#   resultado / igual / afirmar     contadores PASS/FAIL con el mismo formato que scripts/verificar-f3.sh
#   fin_caos                        imprime el total y sale con 0 (todo PASS) o 1
#   TOKEN_WEB TOKEN_MOVIL TOKEN_ATM (se piden con pedir_tokens; el del cajero dura solo 3 minutos)
#   URL_W_MOV URL_W_FICHA URL_M_RESUMEN URL_A_SALDO URL_A_RETIRO   las rutas que usan los escenarios
#   serie_web / serie_movil / serie_atm / rafaga_*     peticiones con scripts/caos/cliente_caos.py
#   estado_circuito <bff> [circuito]    CLOSED, OPEN o HALF_OPEN (Actuator del puerto de gestion)
#   metrica_circuito <bff> <campo>      un campo de /actuator/circuitbreakers (failedCalls, slowCalls...)
#   marca_de_tiempo                     el instante actual (epoch) para quedarse solo con los eventos del escenario
#   transiciones_desde <bff> <marca> [circuito]   las transiciones del circuito desde esa marca, en orden
#   metrica_contador <bff> <metrica> [tag:valor]    valor de un contador de Micrometer
#   fijar_latencia <ms> / restaurar_latencia        latencia inyectada en el core (config-repo + refresh)
#   ids_core / esperar_core_sano / esperar_estado   utilidades de contenedores
#   eureka_instancias_core              "instanceId estado" de cada instancia de core-service en Eureka
#
# Solo ENTORNO=docker: estos escenarios detienen contenedores, y las JVM locales de levantar-local.sh no
# estan pensadas para eso. Portable a bash 3.2 (macOS) y Git Bash: sin arreglos asociativos, sin mapfile,
# sin date +%N. Requiere docker, python3 y curl.
# =====================================================================
if [ "${ENTORNO:-docker}" != docker ]; then
  echo "ERROR: los escenarios de caos corren contra el compose: ejecutalos con ENTORNO=docker (el valor por defecto)." >&2
  exit 2
fi
unset JAVA_TOOL_OPTIONS
RAIZ="${RAIZ:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$RAIZ" || exit 2
# shellcheck source=../lib-entorno.sh
source "$RAIZ/scripts/lib-entorno.sh"
# shellcheck source=../lib-login.sh
source "$RAIZ/scripts/lib-login.sh"

CLIENTE_CAOS="$RAIZ/scripts/caos/cliente_caos.py"
CONFIG_CORE="$RAIZ/config-repo/core-service.yml"
DISPOSITIVO_CAOS="dispositivo-caos-01"

URL_W_MOV="$WEB/v1/cuentas/116/movimientos?page=0&size=20"   # sin cache en el canal: cada peticion viaja al core
URL_W_FICHA="$WEB/v1/cuentas/116"                              # con cache de 60 s en el canal
URL_M_RESUMEN="$MOVIL/v1/cuentas/116/resumen"                  # con cache de 30 s en el canal
URL_A_SALDO="$ATM/v1/cuentas/116/saldo-disponible"             # el cajero nunca cachea
URL_A_RETIRO="$ATM/v1/cuentas/116/retiros"

# ---------------------------------------------------------------------
# PASS / FAIL
# ---------------------------------------------------------------------
FALLOS=0
TOTAL=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() {  # igual <descripcion> <esperado> <obtenido>
  if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi
}
afirmar() {  # afirmar <descripcion> <dato> <comando de test...>   (test sobre el dato; ej.: afirmar "x" 5 test 5 -ge 3)
  local descripcion="$1" dato="$2"; shift 2
  if "$@" > /dev/null 2>&1; then resultado PASS "$descripcion" "$dato"; else resultado FAIL "$descripcion" "$dato"; fi
}
titulo() { printf '\n== %s ==\n' "$*"; }
fin_caos() {
  echo
  if [ "$FALLOS" -eq 0 ]; then echo "RESULTADO: $TOTAL comprobaciones, todas PASS"; else echo "RESULTADO: $FALLOS de $TOTAL comprobaciones FALLARON"; fi
  [ "$FALLOS" -eq 0 ]
  exit $?
}

# ---------------------------------------------------------------------
# Tokens de usuario (el del cajero vence a los 3 minutos: se vuelve a pedir cuando hace falta)
# ---------------------------------------------------------------------
pedir_token_atm() { TOKEN_ATM="$(token_cajero 4000000000000116 1234 atm-scl-001 "" 2> /dev/null)"; }
pedir_tokens() {
  TOKEN_WEB="$(token_web cliente116 Cliente.2026 2> /dev/null)"
  TOKEN_MOVIL="$(token_movil cliente116 Cliente.2026 "$DISPOSITIVO_CAOS" 2> /dev/null)"
  pedir_token_atm
  if [ -z "$TOKEN_WEB" ] || [ -z "$TOKEN_MOVIL" ] || [ -z "$TOKEN_ATM" ]; then
    echo "ERROR: no se pudieron pedir los tokens de login (ver scripts/login-*.sh)" >&2
    exit 2
  fi
}

# ---------------------------------------------------------------------
# Peticiones (cliente_caos.py imprime una linea por peticion y un RESUMEN al final)
# ---------------------------------------------------------------------
# Campos de cada linea: n  codigo  desactualizado  antiguedad  motivo  pantalla  ms
serie_web()   { python3 "$CLIENTE_CAOS" serie --cacert "$CA_CRT" --url "$URL_W_MOV" --header "Authorization: Bearer $TOKEN_WEB" "$@"; }
serie_movil() { python3 "$CLIENTE_CAOS" serie --cacert "$CA_CRT" --url "$URL_M_RESUMEN" --header "Authorization: Bearer $TOKEN_MOVIL" --header "X-Device-Id: $DISPOSITIVO_CAOS" "$@"; }
serie_atm()   { python3 "$CLIENTE_CAOS" serie --cacert "$CA_CRT" --url "$URL_A_SALDO" --header "Authorization: Bearer $TOKEN_ATM" "$@"; }
retiro_atm()  { python3 "$CLIENTE_CAOS" serie --cacert "$CA_CRT" --url "$URL_A_RETIRO" --metodo POST --cuerpo '{"monto":1000}' --header "Authorization: Bearer $TOKEN_ATM" "$@"; }
rafaga_web()   { python3 "$CLIENTE_CAOS" rafaga --cacert "$CA_CRT" --url "$URL_W_MOV" --header "Authorization: Bearer $TOKEN_WEB" "$@"; }
rafaga_movil() { python3 "$CLIENTE_CAOS" rafaga --cacert "$CA_CRT" --url "$URL_M_RESUMEN" --header "Authorization: Bearer $TOKEN_MOVIL" --header "X-Device-Id: $DISPOSITIVO_CAOS" "$@"; }
rafaga_atm()   { python3 "$CLIENTE_CAOS" rafaga --cacert "$CA_CRT" --url "$URL_A_SALDO" --header "Authorization: Bearer $TOKEN_ATM" "$@"; }

# valor_resumen <linea RESUMEN> <campo>: extrae campo=valor de la linea RESUMEN que imprime cliente_caos.py
valor_resumen() { printf '%s\n' "$1" | tr ' ' '\n' | grep "^$2=" | head -1 | cut -d= -f2-; }
# solo_resumen: de la salida completa de cliente_caos.py, deja la linea RESUMEN
solo_resumen() { grep '^RESUMEN' | tail -1; }

# ---------------------------------------------------------------------
# Actuator de Resilience4j en el puerto de gestion de cada BFF
# ---------------------------------------------------------------------
estado_circuito() {  # estado_circuito <bff> [circuito]
  gestion "$1" /actuator/circuitbreakers 2> /dev/null | python3 -c "
import sys, json
try:
    print(json.load(sys.stdin)['circuitBreakers']['${2:-core}']['state'])
except Exception:
    print('DESCONOCIDO')"
}
metrica_circuito() {  # metrica_circuito <bff> <campo>
  gestion "$1" /actuator/circuitbreakers 2> /dev/null | python3 -c "
import sys, json
try:
    print(json.load(sys.stdin)['circuitBreakers']['core']['$2'])
except Exception:
    print('?')"
}
# Marca de tiempo (epoch, en segundos) desde la que interesan los eventos de un escenario. Actuator guarda solo los
# ultimos 100 eventos de un circuito (llamadas buenas, rechazadas y transiciones mezcladas): contar eventos antes y
# despues no sirve, porque los viejos salen del buffer y el indice se corre (se midio en core-lento.sh con el movil, cuyo
# circuito abrio de verdad y el script no lo vio). Por eso se filtra por hora.
marca_de_tiempo() { date -u +%s; }
# Las transiciones del circuito <circuito> (por defecto "core") ocurridas desde la marca, una por linea y en orden:
# "HH:MM:SS.mmm CLOSED_TO_OPEN", "... OPEN_TO_HALF_OPEN", "... HALF_OPEN_TO_CLOSED".
transiciones_desde() {  # transiciones_desde <bff> <marca> [circuito]
  gestion "$1" "/actuator/circuitbreakerevents/${3:-core}/STATE_TRANSITION" 2> /dev/null | python3 -c "
import sys, json, calendar, time
desde = int($2)
try:
    for e in json.load(sys.stdin)['circuitBreakerEvents']:
        t = calendar.timegm(time.strptime(e['creationTime'][:19], '%Y-%m-%dT%H:%M:%S'))
        if t >= desde:
            print(e['creationTime'][11:23] + ' ' + e['stateTransition'])
except Exception:
    pass"
}
# ¿Aparecen, EN ESTE ORDEN, CLOSED_TO_OPEN, OPEN_TO_HALF_OPEN y HALF_OPEN_TO_CLOSED? (imprime SI o NO)
ciclo_completo() {  # ciclo_completo <bff> <marca> [circuito]
  transiciones_desde "$1" "$2" "${3:-core}" | python3 -c "
import sys
pendientes = ['CLOSED_TO_OPEN', 'OPEN_TO_HALF_OPEN', 'HALF_OPEN_TO_CLOSED']
for linea in sys.stdin:
    if pendientes and linea.split()[-1] == pendientes[0]:
        pendientes.pop(0)
print('NO' if pendientes else 'SI')"
}
metrica_contador() {  # metrica_contador <bff> <metrica> [tag:valor]  -> suma de COUNT/VALUE, 0 si aun no existe
  gestion "$1" "/actuator/metrics/$2${3:+?tag=$3}" 2> /dev/null | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print(int(sum(m['value'] for m in d['measurements'] if m['statistic'] in ('COUNT', 'VALUE'))))
except Exception:
    print(0)"
}
# recuperar_circuito <bff> [segundos]: manda una peticion por segundo hasta que el circuito core vuelva a CLOSED
# (el semiabierto necesita llamadas de prueba exitosas; sin trafico se queda en HALF_OPEN). Imprime cuanto tardo.
recuperar_circuito() {
  local bff="$1" limite="${2:-120}" i=0
  [ "$bff" = bff-atm ] && pedir_token_atm
  while [ "$(estado_circuito "$bff")" != CLOSED ] && [ "$i" -lt "$limite" ]; do
    case "$bff" in
      bff-web)    serie_web --n 1 > /dev/null 2>&1 ;;
      bff-mobile) serie_movil --n 1 > /dev/null 2>&1 ;;
      bff-atm)    serie_atm --n 1 > /dev/null 2>&1 ;;
    esac
    sleep 1; i=$((i + 1))
  done
  echo "     $bff: circuito core $(estado_circuito "$bff") tras $i s de trafico"
}
# limpiar_ventana <bff>: la ventana deslizante del circuito (las ultimas 10 llamadas) solo se reinicia cuando el
# circuito cambia de estado. Un escenario que deja fallos o llamadas lentas en una ventana de un circuito que sigue
# CLOSED los arrastra al siguiente. Se llena de llamadas buenas para empezar de cero. En el movil no se puede (su cache
# de 30 s deja pasar una llamada cada 30 s), y alli la ventana se reinicia al cerrarse tras un OPEN.
limpiar_ventana() {
  local bff="$1" i=0
  [ "$bff" = bff-mobile ] && return 0
  [ "$bff" = bff-atm ] && pedir_token_atm
  while [ "$i" -lt 14 ] && { [ "$(metrica_circuito "$bff" failedCalls)" != 0 ] || [ "$(metrica_circuito "$bff" slowCalls)" != 0 ]; }; do
    case "$bff" in
      bff-web) serie_web --n 1 > /dev/null 2>&1 ;;
      bff-atm) serie_atm --n 1 > /dev/null 2>&1 ;;
    esac
    i=$((i + 1))
  done
}
# dejar_circuito_limpio <bff> [segundos]: el circuito core en CLOSED y con la ventana limpia. Limpiar la ventana
# puede hacer abrir el circuito (con pocas llamadas buenas y tres lentas o fallidas viejas, 3 de 5 ya es 60%), asi
# que se repite hasta que quede CLOSED y sin fallos ni lentas en la ventana (maximo 3 vueltas).
dejar_circuito_limpio() {
  local bff="$1" limite="${2:-150}" ronda=0
  while [ "$ronda" -lt 3 ]; do
    [ "$(estado_circuito "$bff")" = CLOSED ] || recuperar_circuito "$bff" "$limite" > /dev/null
    limpiar_ventana "$bff"
    if [ "$(estado_circuito "$bff")" = CLOSED ]; then
      # En el movil no se puede limpiar la ventana (ver limpiar_ventana): basta con que este CLOSED.
      if [ "$bff" = bff-mobile ]; then return 0; fi
      if [ "$(metrica_circuito "$bff" failedCalls)" = 0 ] && [ "$(metrica_circuito "$bff" slowCalls)" = 0 ]; then return 0; fi
    fi
    ronda=$((ronda + 1))
  done
  return 1
}
# Los tres circuitos "core" en CLOSED y con la ventana limpia (escenario anterior, o arranque en frio).
asegurar_circuitos_cerrados() {
  local bff
  for bff in bff-web bff-mobile bff-atm; do
    dejar_circuito_limpio "$bff" 150
  done
}

# ---------------------------------------------------------------------
# Latencia inyectada en el core (config-repo/core-service.yml, caos.latencia-ms) + POST /actuator/refresh
# ---------------------------------------------------------------------
ids_core() { "${COMPOSE[@]}" ps -q core-service; }
refrescar_core() {  # POST /actuator/refresh en CADA replica; imprime las propiedades que cambiaron
  local id salida
  for id in $(ids_core); do
    salida="$(docker exec "$id" wget -qO- --header 'Content-Type: application/json' --post-data='{}' \
      http://127.0.0.1:8081/actuator/refresh 2> /dev/null)"
    echo "    refresh en ${id:0:12}: ${salida:-sin respuesta}"
  done
}
escribir_latencia() {  # escribe el valor en config-repo (el config-server lo lee de ahi en cada peticion)
  python3 - "$CONFIG_CORE" "$1" <<'PY'
import re, sys
ruta, valor = sys.argv[1], sys.argv[2]
texto = open(ruta, encoding="utf-8", newline="").read()
nuevo, n = re.subn(r"(?m)^(  latencia-ms:\s*)\d+", lambda m: m.group(1) + valor, texto)
if n != 1:
    sys.exit("ERROR: no se encontro 'latencia-ms' en %s" % ruta)
open(ruta, "w", encoding="utf-8", newline="").write(nuevo)
PY
}
fijar_latencia() {  # fijar_latencia <ms>
  echo "  >> latencia inyectada en el core: $1 ms (config-repo/core-service.yml + refresh)"
  escribir_latencia "$1" || exit 2
  refrescar_core
}
# Deja la latencia en 0 aunque el escenario termine mal. Se registra con:  trap restaurar_latencia EXIT
restaurar_latencia() {
  escribir_latencia 0 2> /dev/null
  if [ -n "$(ids_core)" ]; then refrescar_core > /dev/null 2>&1; fi
}

# ---------------------------------------------------------------------
# Contenedores
# ---------------------------------------------------------------------
estado_contenedor() {  # running/healthy, running/starting, exited/..., etc.
  docker inspect -f '{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}sin-healthcheck{{end}}' "$1" 2> /dev/null || echo ausente
}
esperar_core_sano() {  # esperar_core_sano [segundos]: las dos replicas healthy
  local limite="${1:-180}" inicio ahora ids id sanas total
  inicio="$(date +%s)"
  while :; do
    ids="$(ids_core)"; sanas=0; total=0
    for id in $ids; do total=$((total + 1)); [ "$(estado_contenedor "$id")" = running/healthy ] && sanas=$((sanas + 1)); done
    if [ "$total" -ge 2 ] && [ "$sanas" -eq "$total" ]; then return 0; fi
    ahora="$(date +%s)"
    [ $((ahora - inicio)) -ge "$limite" ] && return 1
    sleep 2
  done
}
# esperar_estado <bff> <ESTADO> <segundos>: espera a que el circuito core llegue a ese estado
esperar_estado() {
  local limite="${3:-30}" inicio ahora
  inicio="$(date +%s)"
  while [ "$(estado_circuito "$1")" != "$2" ]; do
    ahora="$(date +%s)"
    [ $((ahora - inicio)) -ge "$limite" ] && return 1
    sleep 1
  done
}
# Instancias de core-service que Eureka tiene registradas: "<instanceId> <estado>" (Eureka se publica en 127.0.0.1:8761).
eureka_instancias_core() {
  curl -s -H 'Accept: application/json' http://127.0.0.1:8761/eureka/apps/CORE-SERVICE 2> /dev/null | python3 -c "
import sys, json
try:
    inst = json.load(sys.stdin)['application']['instance']
    if isinstance(inst, dict):
        inst = [inst]
    for i in sorted(inst, key=lambda x: x['instanceId']):
        print(i['instanceId'], i['status'])
except Exception:
    pass"
}
