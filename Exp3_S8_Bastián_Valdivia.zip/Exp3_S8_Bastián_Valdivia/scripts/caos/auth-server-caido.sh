#!/usr/bin/env bash
# =====================================================================
# auth-server-caido.sh: se cae el auth-server y los BFF siguen con el token de servicio vigente. F6, item 3.
# =====================================================================
# Cada BFF obtiene su token de SERVICIO (client_credentials) del auth-server, lo guarda en memoria y lo renueva
# 30 s antes de que venza (vigencia 5 minutos). Este escenario lo demuestra con numeros:
#
#   A. Con el auth-server caido, el token vigente en cache sigue sirviendo: las peticiones al core salen bien,
#      porque nadie necesita hablar con el auth-server.
#   B. En los ultimos 30 s de vida del token el BFF INTENTA renovarlo, falla, lo avisa (WARN) y sigue usando el token
#      vigente hasta su vencimiento real. El circuito "auth-server" (reintentos + cortacircuitos propios) abre.
#   C. Vencido el token, no hay forma de hablar con el core: respuesta controlada (503 en el cajero, con E-090; en
#      web, el ultimo dato conocido marcado como desactualizado), nunca un 500 ni un cuelgue.
#   D. Al volver el auth-server todo se recupera solo.
#
# Para que el token del cajero (3 minutos de vida) no venza durante la prueba se forja uno de 15 minutos con la clave
# del auth-server (firmar_token); el de web y el de movil duran 30 y 60 minutos. Los tokens de USUARIO se
# validan con las claves publicas del auth-server (JWKS) que cada BFF ya tiene en memoria.
#
# Uso:  scripts/caos/auth-server-caido.sh      (tarda unos 6 minutos: hay que esperar a que venza el token de servicio)
# =====================================================================
set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib-caos.sh
source "$DIR/lib-caos.sh"

volver_a_levantar() {
  [ -n "$("${COMPOSE[@]}" ps -q --status running auth-server 2> /dev/null)" ] || { echo "  >> restaurando: docker compose start auth-server"; "${COMPOSE[@]}" start auth-server > /dev/null 2>&1; }
}
trap volver_a_levantar EXIT

# Epoch (segundos) de la hora que dice la ULTIMA linea "vigente hasta ..." del log de un BFF.
vence_a() {
  "${COMPOSE[@]}" logs --no-log-prefix "$1" 2>&1 | grep "Token de servicio obtenido" | tail -1 \
    | sed -e 's/.*vigente hasta \([0-9T:.\-]*\)Z.*/\1/' | python3 -c "
import sys, datetime
t = sys.stdin.read().strip()
print(int(datetime.datetime.fromisoformat(t[:26] + '+00:00').timestamp()))"
}
avisos_renovacion() { "${COMPOSE[@]}" logs --no-log-prefix "$1" 2>&1 | grep -c "No se pudo renovar el token de servicio"; }
estado_auth() { estado_circuito "$1" auth-server; }
ahora() { date +%s; }

echo "Escenario: el auth-server se cae; los BFF siguen con el token de servicio que ya tienen"
pedir_tokens
asegurar_circuitos_cerrados
ATM_FORJADO="$(firmar_token bff-atm '400000******0116' 116 ATM 900 'ROLE_CLIENTE_ATM,PERM_saldo:leer,PERM_retiro:ejecutar' '"terminal":"ATM-SCL-001"' 2> /dev/null | tail -1)"
[ -n "$ATM_FORJADO" ] && TOKEN_ATM="$ATM_FORJADO" || echo "  (no se pudo forjar un token del cajero largo; se usa el de 3 minutos)"

titulo "0. Los BFF arrancan de nuevo para tener un token de servicio recien pedido (vigencia 5 minutos)"
"${COMPOSE[@]}" restart bff-web bff-atm 2>&1 | sed 's/^/    /'
bash "$RAIZ/scripts/esperar-sano.sh" > /dev/null
serie_web --n 1 > /dev/null; serie_atm --n 1 > /dev/null
VENCE_WEB="$(vence_a bff-web)"; VENCE_ATM="$(vence_a bff-atm)"
echo "  el token de servicio de bff-web vence en $((VENCE_WEB - $(ahora))) s; el de bff-atm, en $((VENCE_ATM - $(ahora))) s"
igual "circuito auth-server de bff-web" CLOSED "$(estado_auth bff-web)"
afirmar "ambos tokens tienen mas de 4 minutos de vida" "$((VENCE_WEB - $(ahora))) s / $((VENCE_ATM - $(ahora))) s" test $((VENCE_ATM - $(ahora))) -ge 240 -a $((VENCE_WEB - $(ahora))) -ge 240
AVISOS_WEB0="$(avisos_renovacion bff-web)"; AVISOS_ATM0="$(avisos_renovacion bff-atm)"
N0_AUTH="$(marca_de_tiempo)"

titulo "1. Se detiene el auth-server"
"${COMPOSE[@]}" stop auth-server 2>&1 | sed 's/^/    /'
CODIGO="$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "${TLS[@]}" "$AUTH_URL/oauth2/jwks" 2> /dev/null)"
echo "  GET $AUTH_URL/oauth2/jwks -> HTTP ${CODIGO:-000} (sin respuesta: el login de usuarios nuevos no es posible)"

titulo "A. Token vigente en cache: el core sigue sirviendo"
R="$(serie_web --n 5 | solo_resumen)"; igual "web: 5 de 5 en 200 frescos" 5 "$(valor_resumen "$R" http200_frescos)"
R="$(serie_atm --n 5 | solo_resumen)"; igual "cajero: 5 de 5 en 200 con saldo" 5 "$(valor_resumen "$R" con_saldo)"
igual "no hubo ningun intento de renovar todavia (faltan mas de 30 s)" 0 $(( $(avisos_renovacion bff-web) - AVISOS_WEB0 ))

titulo "B. Ultimos 30 s del token: intenta renovar, falla, y sigue con el vigente"
LIMITE_MARGEN=$(( VENCE_WEB - 30 ))
echo "  esperando hasta el margen de renovacion (faltan $((LIMITE_MARGEN - $(ahora))) s); una peticion cada 5 s"
while [ "$(ahora)" -lt "$LIMITE_MARGEN" ]; do sleep 5; serie_web --n 1 > /dev/null; done
OK_WEB=0; OK_ATM=0; N=0
while [ "$(ahora)" -lt $(( VENCE_WEB - 4 )) ]; do
  N=$((N + 1))
  r="$(serie_web --n 1 | solo_resumen)"; [ "$(valor_resumen "$r" http200_frescos)" = 1 ] && OK_WEB=$((OK_WEB + 1))
  r="$(serie_atm --n 1 | solo_resumen)"; [ "$(valor_resumen "$r" http200)" = 1 ] && OK_ATM=$((OK_ATM + 1))
  sleep 2
done
echo "  en el margen se hicieron $N rondas: web 200 frescas=$OK_WEB, cajero 200=$OK_ATM"
igual "web: todas las peticiones del margen salieron bien con el token vigente" "$N" "$OK_WEB"
igual "cajero: todas las peticiones del margen salieron bien con el token vigente" "$N" "$OK_ATM"
afirmar "web: el log avisa que no pudo renovar y sigue con el vigente" "$(( $(avisos_renovacion bff-web) - AVISOS_WEB0 )) avisos" test $(( $(avisos_renovacion bff-web) - AVISOS_WEB0 )) -ge 1
"${COMPOSE[@]}" logs --no-log-prefix bff-web 2>&1 | grep "No se pudo renovar el token de servicio" | tail -1 | cut -c1-260 | sed 's/^/     /'
# El circuito abierto pasa solo a HALF_OPEN cada 10 s y vuelve a OPEN con la primera renovacion fallida: el estado en un
# instante cualquiera puede ser cualquiera de los dos. La prueba firme son los eventos.
echo "     circuito auth-server de bff-web en este instante: $(estado_auth bff-web)"
igual "circuito auth-server de bff-web: abrio (CLOSED -> OPEN en los eventos, el auth-server no responde)" SI "$([ "$(transiciones_desde bff-web "$N0_AUTH" auth-server | grep -c CLOSED_TO_OPEN)" -ge 1 ] && echo SI || echo NO)"
echo "     $(gestion bff-web /actuator/circuitbreakers | python3 -c "import sys,json; c=json.load(sys.stdin)['circuitBreakers']['auth-server']; print('auth-server: state=%s failedCalls=%s notPermittedCalls=%s' % (c['state'], c['failedCalls'], c['notPermittedCalls']))")"

titulo "C. Token vencido y auth-server caido: respuesta controlada"
while [ "$(ahora)" -le $(( VENCE_ATM + 3 )) ] || [ "$(ahora)" -le $(( VENCE_WEB + 3 )) ]; do sleep 2; done
SAL="$(serie_atm --n 3)"; echo "$SAL" | sed 's/^/     cajero: /'; R="$(echo "$SAL" | solo_resumen)"
igual "cajero: 503 controlado (falla cerrada), sin saldo" 3 "$(valor_resumen "$R" http503)"
igual "cajero: ningun saldo entregado" 0 "$(valor_resumen "$R" con_saldo)"
igual "cajero: pantalla E-090" '{"core_no_disponible":3}' "$(valor_resumen "$R" motivos)"
SAL="$(serie_web --n 3)"; echo "$SAL" | sed 's/^/     web: /'; R="$(echo "$SAL" | solo_resumen)"
igual "web: ninguna respuesta 500 (200 desactualizada o 503, ambas controladas)" 0 "$(valor_resumen "$R" otros)"
afirmar "web: sirve el ultimo dato conocido marcado como desactualizado" "$(valor_resumen "$R" http200_desactualizados) de 3" test "$(valor_resumen "$R" http200_desactualizados)" -ge 1

titulo "D. Vuelve el auth-server"
"${COMPOSE[@]}" start auth-server 2>&1 | sed 's/^/    /'
bash "$RAIZ/scripts/esperar-sano.sh" > /dev/null
pedir_tokens
recuperar_circuito bff-web 150
recuperar_circuito bff-atm 150
for i in 1 2 3 4 5 6 7 8 9 10 11 12; do [ "$(estado_auth bff-web)" = CLOSED ] && break; serie_web --n 1 > /dev/null; sleep 2; done
igual "circuito auth-server de bff-web" CLOSED "$(estado_auth bff-web)"
R="$(serie_web --n 3 | solo_resumen)"; igual "web: respuestas frescas otra vez" 3 "$(valor_resumen "$R" http200_frescos)"
R="$(serie_atm --n 3 | solo_resumen)"; igual "cajero: saldo otra vez" 3 "$(valor_resumen "$R" http200_frescos)"
titulo "Eventos del circuito auth-server de bff-web (de este escenario)"
transiciones_desde bff-web "$N0_AUTH" auth-server | sed 's/^/     /'
igual "el circuito auth-server de bff-web paso por CLOSED, OPEN, HALF_OPEN y CLOSED" SI "$(ciclo_completo bff-web "$N0_AUTH" auth-server)"
fin_caos
