#!/usr/bin/env bash
# =====================================================================
# core-lento.sh: el core responde, pero tarde. F6, escenario 2.
# =====================================================================
# Un core LENTO es distinto de uno CAIDO: acepta la conexion y contesta bien, solo que despues de mucho tiempo.
# No se consigue deteniendo un contenedor; por eso el core tiene una latencia inyectable por configuracion
# (caos.latencia-ms en config-repo/core-service.yml, @RefreshScope, 0 por defecto) que se activa con
# POST /actuator/refresh, sin reiniciar.
#
# Fase A (1500 ms, bajo el timeout de lectura de 2 s): las llamadas SALEN BIEN pero lentas (mas de 1 s). Ningun
#   error. Demuestra que el circuito abre por LENTITUD (slowCallRateThreshold 50%, slowCallDurationThreshold 1 s),
#   no solo por errores: failedCalls queda en 0 y slowCalls sube.
# Fase B (3000 ms, sobre el timeout): la lectura vence a los 2 s (timeout del cliente HTTP, porque el TimeLimiter de
#   Resilience4j no aplica a llamadas bloqueantes), se reintenta y el circuito cuenta fallas.
#
# Uso:  scripts/caos/core-lento.sh [--sin-movil]
#   El movil guarda 30 s la cuenta en su cache, asi que solo una peticion cada 30 s llega al core: abrir su circuito
#   con latencia toma unos 3 minutos. --sin-movil lo omite (la fase A queda en 1 minuto).
# Deja la latencia en 0 y los circuitos cerrados.
# =====================================================================
set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib-caos.sh
source "$DIR/lib-caos.sh"
CON_MOVIL=1; [ "${1:-}" = "--sin-movil" ] && CON_MOVIL=0
trap restaurar_latencia EXIT

echo "Escenario: core lento (latencia inyectada por configuracion)"
pedir_tokens
asegurar_circuitos_cerrados
SALIDA_MOVIL="$(mktemp)"

titulo "0. Linea base, core sano"
for bff in bff-web bff-mobile bff-atm; do igual "circuito core de $bff al empezar" CLOSED "$(estado_circuito "$bff")"; done
N0_WEB="$(marca_de_tiempo)"; N0_MOV="$(marca_de_tiempo)"; N0_ATM="$(marca_de_tiempo)"
R="$(serie_web --n 5 | solo_resumen)"; echo "  web, 5 peticiones: mediana $(valor_resumen "$R" ms_mediana) ms, maximo $(valor_resumen "$R" ms_max) ms"
R="$(serie_atm --n 5 | solo_resumen)"; echo "  cajero, 5 peticiones: mediana $(valor_resumen "$R" ms_mediana) ms, maximo $(valor_resumen "$R" ms_max) ms"

titulo "A. Latencia de 1500 ms (el core responde bien, pero lento)"
fijar_latencia 1500
if [ "$CON_MOVIL" = 1 ]; then
  echo "  (movil: 7 peticiones, una cada 31 s para saltar su cache de 30 s; corre en segundo plano)"
  ( for i in 1 2 3 4 5 6 7; do serie_movil --n 1 | sed -n 1p; [ "$i" -lt 7 ] && sleep 31; done > "$SALIDA_MOVIL" 2>&1 ) &
  PID_MOVIL=$!
fi
echo "  -- cajero: 10 peticiones seguidas (n codigo desactualizado antiguedad motivo pantalla ms)"
SAL="$(serie_atm --n 10)"; echo "$SAL" | sed 's/^/     /'; R="$(echo "$SAL" | solo_resumen)"
afirmar "cajero: las primeras llamadas salen bien pero lentas (>1000 ms)" "$(valor_resumen "$R" ms_max) ms" test "$(valor_resumen "$R" ms_max)" -ge 1000
igual "cajero: el circuito abrio" OPEN "$(estado_circuito bff-atm)"
echo "     failedCalls=$(metrica_circuito bff-atm failedCalls) slowCalls=$(metrica_circuito bff-atm slowCalls) slowCallRate=$(metrica_circuito bff-atm slowCallRate) notPermittedCalls=$(metrica_circuito bff-atm notPermittedCalls)"
igual "cajero: abrio SIN ningun error (failedCalls = 0): fue por lentitud" 0 "$(metrica_circuito bff-atm failedCalls)"
afirmar "cajero: slowCalls >= 3" "$(metrica_circuito bff-atm slowCalls)" test "$(metrica_circuito bff-atm slowCalls)" -ge 3
afirmar "cajero: ya abierto, rechaza al instante con 503 E-090 (<200 ms)" "$(valor_resumen "$R" http503) respuestas 503" test "$(valor_resumen "$R" http503)" -ge 3
echo "  -- web: 10 peticiones seguidas"
SAL="$(serie_web --n 10)"; echo "$SAL" | sed 's/^/     /'; R="$(echo "$SAL" | solo_resumen)"
igual "web: el circuito abrio" OPEN "$(estado_circuito bff-web)"
echo "     failedCalls=$(metrica_circuito bff-web failedCalls) slowCalls=$(metrica_circuito bff-web slowCalls) slowCallRate=$(metrica_circuito bff-web slowCallRate) notPermittedCalls=$(metrica_circuito bff-web notPermittedCalls)"
igual "web: abrio SIN ningun error (failedCalls = 0): fue por lentitud" 0 "$(metrica_circuito bff-web failedCalls)"
igual "web: todas las respuestas fueron 200 (las lentas, frescas; las demas, respaldo marcado)" 10 "$(valor_resumen "$R" http200)"
afirmar "web: con el circuito abierto sirve el ultimo dato, marcado como desactualizado" "$(valor_resumen "$R" http200_desactualizados) respuestas" test "$(valor_resumen "$R" http200_desactualizados)" -ge 3
if [ "$CON_MOVIL" = 1 ]; then
  echo "  -- movil: esperando sus 7 peticiones (unos 3 minutos)..."
  wait "$PID_MOVIL"
  sed 's/^/     /' "$SALIDA_MOVIL"
  igual "movil: el circuito abrio" "SI" "$([ "$(transiciones_desde bff-mobile "$N0_MOV" | grep -c CLOSED_TO_OPEN)" -ge 1 ] && echo SI || echo NO)"
fi

titulo "A. Se quita la latencia y los circuitos se recuperan solos"
restaurar_latencia
recuperar_circuito bff-web 150
recuperar_circuito bff-atm 150
[ "$CON_MOVIL" = 1 ] && recuperar_circuito bff-mobile 200
for bff in bff-web bff-atm; do igual "circuito core de $bff" CLOSED "$(estado_circuito "$bff")"; done
[ "$CON_MOVIL" = 1 ] && igual "circuito core de bff-mobile" CLOSED "$(estado_circuito bff-mobile)"

titulo "B. Latencia de 3000 ms (mas que el timeout de lectura de 2 s)"
fijar_latencia 3000
pedir_token_atm
N1_WEB="$(marca_de_tiempo)"
echo "  -- cajero: una peticion con el circuito cerrado (peor caso: 3 intentos de 2 s)"
SAL="$(serie_atm --n 1)"; echo "$SAL" | sed 's/^/     /'; R="$(echo "$SAL" | solo_resumen)"
igual "cajero: 503, falla cerrada" 1 "$(valor_resumen "$R" http503)"
igual "cajero: sin saldo" 0 "$(valor_resumen "$R" con_saldo)"
echo "     esa unica peticion tardo $(valor_resumen "$R" ms_max) ms antes de rendirse (timeout 2 s x 3 intentos + espera)"
echo "     failedCalls=$(metrica_circuito bff-atm failedCalls) slowCalls=$(metrica_circuito bff-atm slowCalls)  estado=$(estado_circuito bff-atm)"
afirmar "cajero: ahora SI hay errores registrados (los timeouts vencen)" "$(metrica_circuito bff-atm failedCalls)" test "$(metrica_circuito bff-atm failedCalls)" -ge 3
echo "  -- web: dos peticiones"
SAL="$(serie_web --n 2)"; echo "$SAL" | sed 's/^/     /'
restaurar_latencia
pedir_token_atm
recuperar_circuito bff-web 150
recuperar_circuito bff-atm 150
dejar_circuito_limpio bff-web
dejar_circuito_limpio bff-atm

titulo "C. Eventos de Actuator de este escenario"
for par in "bff-web:$N0_WEB" "bff-atm:$N0_ATM"; do
  bff="${par%%:*}"; n0="${par##*:}"
  echo "  $bff:"; transiciones_desde "$bff" "$n0" | sed 's/^/     /'
  igual "$bff: el ciclo CLOSED -> OPEN -> HALF_OPEN -> CLOSED aparece en los eventos" SI "$(ciclo_completo "$bff" "$n0")"
done
if [ "$CON_MOVIL" = 1 ]; then
  echo "  bff-mobile:"; transiciones_desde bff-mobile "$N0_MOV" | sed 's/^/     /'
  igual "bff-mobile: el ciclo CLOSED -> OPEN -> HALF_OPEN -> CLOSED aparece en los eventos" SI "$(ciclo_completo bff-mobile "$N0_MOV")"
fi
rm -f "$SALIDA_MOVIL"
git -C "$RAIZ" diff --quiet -- config-repo/core-service.yml 2> /dev/null && echo "  config-repo/core-service.yml quedo igual que en git (latencia 0)"
fin_caos
