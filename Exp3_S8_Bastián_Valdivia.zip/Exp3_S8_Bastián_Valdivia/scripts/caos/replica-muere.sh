#!/usr/bin/env bash
# =====================================================================
# replica-muere.sh: una de las dos replicas del core MUERE a mitad de 100 peticiones. F6, escenario 4.
# =====================================================================
# Criterio: las 100 peticiones terminan bien (200 con dato fresco), sin una sola respuesta de respaldo ni 503.
# Lo logra el Retry de Resilience4j (no el balanceador, que tiene sus reintentos desactivados): la llamada que cae
# en la replica muerta falla, se reintenta, y el balanceador (round robin) la manda a la otra replica. Mientras
# Eureka aun lista a la muerta (hasta unos 15 s con el perfil demo), cerca de la mitad de los primeros intentos
# fallan; el circuito NO abre porque la tasa de fallos (~50%) queda bajo el umbral del 70%.
#
# Se prueba dos veces: web (GET movimientos, sin cache) y cajero (GET saldo). Cada una mata una replica distinta
# con "docker kill" (SIGKILL: muerte brusca, sin darse de baja en Eureka) justo despues de la peticion 30.
# Al terminar, la replica muerta se vuelve a levantar.
#
# Uso:  scripts/caos/replica-muere.sh
# =====================================================================
set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib-caos.sh
source "$DIR/lib-caos.sh"

# Pase lo que pase, las dos replicas quedan arriba.
volver_a_levantar() {
  if [ "$("${COMPOSE[@]}" ps -q --status running core-service 2> /dev/null | wc -l | tr -d ' ')" -lt 2 ]; then
    echo "  >> restaurando: docker compose start core-service"
    "${COMPOSE[@]}" start core-service > /dev/null 2>&1
  fi
}
trap volver_a_levantar EXIT

reintentos_exitosos() { metrica_contador "$1" resilience4j.retry.calls "name:core&tag=kind:successful_with_retry"; }
reintentos_fallidos() { metrica_contador "$1" resilience4j.retry.calls "name:core&tag=kind:failed_with_retry"; }

# probar <etiqueta> <bff> <indice de replica 1|2> <funcion de serie> 
probar() {
  local etiqueta="$1" bff="$2" indice="$3" serie="$4" id nombre ok0 ko0 sal r
  id="$(ids_core | sed -n "${indice}p")"
  nombre="$(docker inspect -f '{{.Name}}' "$id" | tr -d '/')"
  titulo "$etiqueta: 100 peticiones; tras la 30 muere la replica $nombre (docker kill)"
  echo "  instancias en Eureka antes: $(eureka_instancias_core | tr '\n' ';')"
  ok0="$(reintentos_exitosos "$bff")"; ko0="$(reintentos_fallidos "$bff")"
  N0="$(marca_de_tiempo)"
  sal="$($serie --n 100 --pausa-ms 100 --accion "docker kill $id" --accion-en 30)"
  echo "$sal" | awk -F'\t' '/^ACCION/ {print "     " $0; next} /RESUMEN/ {next} $2 != 200 || $3 == "true" || $7 > 900 {print "     " $0}' | head -30
  echo "     (se listan solo las peticiones que NO fueron 200 frescas rapidas: mas de 900 ms, 503 o respaldo)"
  r="$(echo "$sal" | solo_resumen)"; echo "     $r" | cut -c1-260
  igual "$etiqueta: 100 de 100 peticiones respondidas 200" 100 "$(valor_resumen "$r" http200)"
  igual "$etiqueta: las 100 con dato FRESCO (ninguna de respaldo)" 100 "$(valor_resumen "$r" http200_frescos)"
  igual "$etiqueta: ningun 503" 0 "$(valor_resumen "$r" http503)"
  afirmar "$etiqueta: el Retry de Resilience4j rescato peticiones (successful_with_retry subio)" "+$(( $(reintentos_exitosos "$bff") - ok0 ))" test $(( $(reintentos_exitosos "$bff") - ok0 )) -ge 1
  igual "$etiqueta: ninguna peticion agoto sus reintentos (failed_with_retry no subio)" 0 $(( $(reintentos_fallidos "$bff") - ko0 ))
  igual "$etiqueta: el circuito sigue CLOSED (la tasa de fallos no llego al umbral)" CLOSED "$(estado_circuito "$bff")"
  igual "$etiqueta: el circuito nunca abrio durante la prueba" 0 "$(transiciones_desde "$bff" "$N0" | wc -l | tr -d ' ')"
  echo "  failedCalls=$(metrica_circuito "$bff" failedCalls) de bufferedCalls=$(metrica_circuito "$bff" bufferedCalls) (failureRate $(metrica_circuito "$bff" failureRate), umbral 70%)"
  echo "  instancias en Eureka despues: $(eureka_instancias_core | tr '\n' ';')"
  echo "  >> se vuelve a levantar la replica muerta"
  "${COMPOSE[@]}" start core-service > /dev/null 2>&1
  if esperar_core_sano 180; then resultado PASS "$etiqueta: las dos replicas vuelven a estar healthy"; else resultado FAIL "$etiqueta: el core no volvio a estar healthy"; fi
}

echo "Escenario: una replica del core muere durante 100 peticiones"
pedir_tokens
asegurar_circuitos_cerrados
echo "  replicas del core: $(ids_core | wc -l | tr -d ' ')   en Eureka: $(eureka_instancias_core | wc -l | tr -d ' ')"
probar "web" bff-web 1 serie_web
pedir_tokens
asegurar_circuitos_cerrados
probar "cajero" bff-atm 2 serie_atm
fin_caos
