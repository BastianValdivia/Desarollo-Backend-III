#!/usr/bin/env bash
# =====================================================================
# login-web.sh: inicio de sesion del canal WEB con authorization_code y PKCE, hecho con curl.
# =====================================================================
# Uso:  scripts/login-web.sh [usuario] [clave] [--token]
#
#   Sin argumentos usa cliente116 / Cliente.2026. Usuarios de demostracion del canal web:
#     cliente116 / Cliente.2026    cliente105 / Cliente.2026    ejecutivo1 / Exec.2026
#   --token  imprime SOLO el token de acceso (para usarlo en $(...)); sin el, imprime cada paso del flujo,
#            la respuesta del endpoint de tokens y los claims decodificados.
#
# Contra los contenedores (por defecto, con --cacert certs/ca.crt) o contra JVM locales (ENTORNO=local).
# Los pasos del flujo estan explicados en scripts/lib-login.sh. Una vez con el token:
#   curl --cacert certs/ca.crt -H "Authorization: Bearer $TOKEN" https://localhost:8443/api/web/v1/cuentas/116
# =====================================================================
set -uo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib-entorno.sh
. "$DIR/lib-entorno.sh"
# shellcheck source=lib-login.sh
. "$DIR/lib-login.sh"

SOLO_TOKEN=0; ARGS=()
for a in "$@"; do if [ "$a" = "--token" ]; then SOLO_TOKEN=1; else ARGS+=("$a"); fi; done
USUARIO="${ARGS[0]:-cliente116}"
CLAVE="${ARGS[1]:-$([ "$USUARIO" = ejecutivo1 ] && echo Exec.2026 || echo Cliente.2026)}"

if [ "$SOLO_TOKEN" = 1 ]; then
  token_web "$USUARIO" "$CLAVE"
  exit $?
fi

LOGIN_VERBOSO=1
echo "== Login web: usuario $USUARIO, cliente web-app (publico, PKCE), auth-server $AUTH_URL =="
JSON="$(login_pkce web-app "$REDIRECT_WEB" "$USUARIO" "$CLAVE")" || exit 1
TOKEN="$(printf '%s' "$JSON" | access_token_de)"
if [ -z "$TOKEN" ]; then echo "ERROR: sin token: $JSON" >&2; exit 1; fi
echo
echo "Respuesta del endpoint de tokens (el valor del token se abrevia):"
printf '%s' "$JSON" | python3 -c 'import sys,json; d=json.load(sys.stdin); d["access_token"]=d["access_token"][:24]+"..."; print(json.dumps(d))'
echo
echo "Claims del token (se leen sin clave porque un JWT esta firmado, no cifrado):"
python3 "$DIR/ver-token.py" "$TOKEN"
