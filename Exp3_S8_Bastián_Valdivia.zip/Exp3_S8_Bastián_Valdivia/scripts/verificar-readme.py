#!/usr/bin/env python3
# =====================================================================
# verificar-readme.py: las cifras del README contra la evidencia (regla 5 del plan: README, evidencia y codigo dicen
# lo mismo). Lo invoca scripts/verificar-entrega.sh, que convierte cada linea en un PASS o un FAIL.
# =====================================================================
# Salida: una linea por comprobacion con el formato  ESTADO|descripcion|dato  (ESTADO es PASS o FAIL).
#   1. la tabla "Comprobaciones por archivo" del README contra la linea RESULTADO de cada evidencia;
#   2. el total de pruebas y la tabla por modulo contra evidencias/salidas/00-pruebas-unitarias.txt;
#   3. que cada enlace relativo del README apunte a algo que existe.
# Se ejecuta desde la raiz del repositorio. Solo lee.
# =====================================================================
import re, glob, os

# Conteos que varian entre ejecuciones por causas conocidas (ver evidencias/INDICE.md).
TOLERANCIAS = {"21-compose-postgres-replicas-f3": 2}


def leer(ruta):
    with open(ruta, encoding="utf-8") as f:
        return f.read()

readme = leer("README.md")
salida = []

# 1. Tabla "Comprobaciones por archivo" del README contra la linea RESULTADO de cada evidencia.
pares = re.findall(r"`(\d\d-[a-z0-9-]+)`\s*\|\s*(\d+)", readme)
vistos = 0
for nombre, cifra in pares:
    archivos = glob.glob("evidencias/salidas/%s.txt" % nombre)
    if not archivos:
        salida.append("FAIL|README cita %s pero no existe esa evidencia|" % nombre)
        continue
    texto = leer(archivos[0])
    m = re.search(r"RESULTADO[^:\n]*:\s*(\d+) comprobaciones", texto)
    # Tres guiones (matriz 3x3, escalado y Eureka) no imprimen un total: se cuentan sus lineas PASS.
    real = m.group(1) if m else str(len(re.findall(r"^\s+PASS ", texto, re.M)))
    vistos += 1
    # Un solo archivo tiene una tolerancia declarada: cuantos retiros simultaneos llegan al core antes de que el mamparo
    # del cajero rechace el resto cambia entre ejecuciones, y con ello el conteo (92 y 91 vistos; esta dicho en el INDICE).
    tolerancia = TOLERANCIAS.get(nombre, 0)
    coincide = real.isdigit() and abs(int(real) - int(cifra)) <= tolerancia
    nota = "" if real == cifra or not coincide else " (dentro de la tolerancia declarada de %d)" % tolerancia
    salida.append("%s|README: %s tiene %s comprobaciones|evidencia: %s%s" % ("PASS" if coincide else "FAIL", nombre, cifra, real, nota))
if vistos < 14:
    salida.append("FAIL|README: se esperaban al menos 14 cifras por archivo contra la evidencia|%d" % vistos)

# 2. Total de pruebas y tabla por modulo contra 00-pruebas-unitarias.txt.
ruta00 = "evidencias/salidas/00-pruebas-unitarias.txt"
if os.path.exists(ruta00):
    t = leer(ruta00)
    total = re.search(r"PASS (\d+) pruebas ejecutadas", t)
    en_readme = re.search(r"ejecuta \*\*(\d+) pruebas\*\*", readme)
    if total and en_readme:
        salida.append("%s|README: total de pruebas|README %s, evidencia %s" % ("PASS" if total.group(1) == en_readme.group(1) else "FAIL", en_readme.group(1), total.group(1)))
    else:
        salida.append("FAIL|README: no se pudo leer el total de pruebas|")
    modulos = re.findall(r"Building (\S+) 1\.0\.0\s+\[\d+/\d+\]\n\[INFO\] Tests run: (\d+)", t)
    for modulo, n in modulos:
        fila = re.search(r"\|\s*`%s`\s*\|\s*(\d+)\s*\|" % re.escape(modulo), readme)
        if fila:
            salida.append("%s|README: pruebas de %s|README %s, evidencia %s" % ("PASS" if fila.group(1) == n else "FAIL", modulo, fila.group(1), n))
        else:
            salida.append("FAIL|README: falta la fila de pruebas de %s|" % modulo)
else:
    salida.append("FAIL|falta evidencias/salidas/00-pruebas-unitarias.txt|")

# 3. Los enlaces relativos del README (a archivos del repositorio) apuntan a algo que existe.
rotos = []
for destino in re.findall(r"\]\(([^)#]+?)(?:#[^)]*)?\)", readme):
    if destino.startswith(("http://", "https://", "mailto:")) or not destino.strip():
        continue
    if not os.path.exists(destino):
        rotos.append(destino)
salida.append("%s|README: todos los enlaces relativos existen|%s" % ("PASS" if not rotos else "FAIL", " ".join(rotos)))

for linea in salida:
    print(linea)
