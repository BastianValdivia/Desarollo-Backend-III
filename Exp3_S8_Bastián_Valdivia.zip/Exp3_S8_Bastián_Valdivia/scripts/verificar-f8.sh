#!/usr/bin/env bash
# =====================================================================
# verificar-f8.sh: comprobaciones de la fase F8 (despliegue con calidad de produccion) contra el stack levantado
# con "docker compose up -d". Imprime PASS o FAIL con el dato real de cada una; el codigo de salida es 0 solo si
# todas pasan. Solo lee: no modifica el sistema.
#
# Que comprueba, en el orden de los criterios de termino de F8:
#   1. Usuario no root: las 9 imagenes de servicio declaran UID 10001 y cada contenedor en marcha lo ejecuta asi;
#      secretos-init, la unica excepcion, corre como root pero sin red, sin capacidades salvo tres y de solo lectura.
#      Kafka, Kafka UI y PostgreSQL (imagenes ajenas) no ejecutan su proceso principal como root.
#   2. Sin secretos en las imagenes: ni en el historial de capas (docker history), ni en las variables de entorno
#      de la imagen, ni como archivos de claves o contrasenas dentro del sistema de archivos y de los .jar; y ningun
#      archivo de ese tipo versionado en git.
#   3. docker compose config no emite advertencias; ninguna imagen es "latest" ni va sin etiqueta; todas las
#      etiquetas de los Dockerfile y del compose fijan la version.
#   4. Limites de recursos: cada servicio de larga vida tiene limite de memoria, de CPU y de procesos, y todos
#      estan healthy CON esos limites; ninguno usa mas del 85 % de su limite de memoria en reposo.
#   5. Multiarquitectura: cada imagen base (las de los Dockerfile y las externas del compose) publica linux/amd64
#      y linux/arm64 (se consulta el registro: requiere conexion a Internet).
#
# Portabilidad: sin construcciones de bash 4 ni de GNU en el host; requiere docker (con buildx), git y python3.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
docker() { MSYS_NO_PATHCONV=1 command docker "$@"; }
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
COMPOSE=(docker compose -f docker-compose.yaml)
VERSION=1.0.0
# Los 9 microservicios propios (cada uno con su Dockerfile) y la tarea de secretos.
SERVICIOS=(config-server eureka-server auth-server core-service bff-web bff-mobile bff-atm notificaciones-service auditoria-service)
EXTERNOS=(postgres kafka kafka-ui)

FALLOS=0
TOTAL=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() {  # igual <descripcion> <esperado> <obtenido>
  if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi
}
cids() { "${COMPOSE[@]}" ps -a -q "$1"; }

bash "$RAIZ/scripts/esperar-sano.sh" || true

# ===============================================================================================
echo "== 1. Usuario no root =="
# ===============================================================================================
for s in "${SERVICIOS[@]}"; do
  igual "imagen $s: USER 10001:10001" "10001:10001" "$(docker image inspect -f '{{.Config.User}}' "bancoxyz/$s:$VERSION")"
  uids=""
  for id in $(cids "$s"); do
    uids="$uids$(docker exec "$id" id -u | tr -d '\r') "
  done
  # Todas las replicas del servicio, con el mismo UID.
  igual "contenedor(es) de $s: el proceso corre con UID 10001" "10001" "$(echo "$uids" | tr ' ' '\n' | grep -v '^$' | sort -u | tr '\n' ' ' | sed 's/ $//')"
done
SI="$(cids secretos-init | head -n 1)"
igual "secretos-init (excepcion documentada): corre como root solo unos segundos y termino" "exited 0" "$(docker inspect -f '{{.State.Status}} {{.State.ExitCode}}' "$SI")"
igual "secretos-init: sin red (network_mode none)" "none" "$(docker inspect -f '{{.HostConfig.NetworkMode}}' "$SI")"
igual "secretos-init: sin capacidades de Linux salvo CHOWN, DAC_OVERRIDE y FOWNER" "CHOWN DAC_OVERRIDE FOWNER" \
  "$(docker inspect -f '{{range .HostConfig.CapAdd}}{{.}} {{end}}' "$SI" | tr ' ' '\n' | grep -v '^$' | sed 's/^CAP_//' | tr '\n' ' ' | sed 's/ $//')"
igual "secretos-init: cap_drop ALL y sistema de archivos de solo lectura" "ALL true" \
  "$(docker inspect -f '{{range .HostConfig.CapDrop}}{{.}}{{end}} {{.HostConfig.ReadonlyRootfs}}' "$SI" | sed 's/^CAP_//')"
for s in "${EXTERNOS[@]}"; do
  id="$(cids "$s" | head -n 1)"
  # El proceso 1 (o el principal): para PostgreSQL, el que no es el del arranque de root. Se mira cada proceso
  # y se exige que el servidor ("postgres", "java", "kafka") no sea de root.
  quien="$(docker exec "$id" sh -c 'ps -o user=,args= 2>/dev/null || ps' | grep -E 'postgres -D|postgres$|java|kafka' | grep -v grep | awk '{print $1}' | sort -u | tr '\n' ' ' | sed 's/ $//')"
  case "$quien" in
    ""|*root*) resultado FAIL "$s: el proceso del servidor no corre como root" "usuarios: '$quien'" ;;
    *) resultado PASS "$s: el proceso del servidor no corre como root" "usuario: $quien" ;;
  esac
done

# ===============================================================================================
echo "== 2. Sin secretos en las imagenes =="
# ===============================================================================================
# Patron de un secreto en un comando o variable de una capa: CLAVE=valor (password, secret, token, key) o una clave PEM.
PATRON_CAPAS='(password|passwd|secret|token|api[_-]?key)[a-z_.-]*=[^ ]|BEGIN [A-Z ]*PRIVATE KEY'
for img in "${SERVICIOS[@]/#/bancoxyz/}" bancoxyz/secretos-init; do
  imagen="$img:$VERSION"
  n="$(docker history --no-trunc --format '{{.CreatedBy}}' "$imagen" | grep -ciE "$PATRON_CAPAS")"
  igual "docker history de $imagen: ninguna capa lleva una clave, contrasena o secreto" 0 "$n"
done
for img in "${SERVICIOS[@]/#/bancoxyz/}" bancoxyz/secretos-init; do
  imagen="$img:$VERSION"
  n="$(docker image inspect -f '{{range .Config.Env}}{{println .}}{{end}}' "$imagen" | grep -ciE '(password|secret|token|key)[a-z_]*=[^ ]')"
  igual "variables de entorno de $imagen: ninguna con aspecto de secreto" 0 "$n"
done
# Contenido real: archivos de claves o contrasenas en el sistema de archivos y dentro de cada .jar. Se excluyen solo
# las carpetas de certificados PUBLICOS que trae el sistema base: las CA del sistema (/etc/ssl), las de Java
# (lib/security/cacerts) y la CA publica del grupo de servidores de claves de gnupg (/usr/share/gnupg/*.pem, de
# Alpine). Ninguna es un secreto. Se ejecuta sin red.
BUSCAR='
find / -xdev \( -path /proc -o -path /sys -o -path /etc/ssl -o -path /usr/share/ca-certificates -o -path /usr/share/gnupg -o -path /opt/java/openjdk/lib/security \) -prune -o \
  -type f \( -name "*.p12" -o -name "*.pfx" -o -name "*.jks" -o -name "*.key" -o -name "*.pem" -o -name "*.crt" -o -name "*.password" -o -name "*.secret" -o -name ".env" \) -print 2>/dev/null
for j in $(find /application -name "*.jar" 2>/dev/null); do
  unzip -l "$j" 2>/dev/null | awk "{print \$4}" | grep -E "\.(p12|pfx|jks|key|pem|crt|password|secret)\$|(^|/)\.env\$" | sed "s|^|$j!|"
done'
for s in "${SERVICIOS[@]}"; do
  encontrados="$(docker run --rm --network none --entrypoint sh "bancoxyz/$s:$VERSION" -c "$BUSCAR" | tr -d '\r' | grep -v '^$' | wc -l | tr -d ' ')"
  igual "bancoxyz/$s: ningun archivo de claves, keystores ni contrasenas (sistema de archivos y .jar)" 0 "$encontrados"
done
encontrados="$(docker run --rm --network none --entrypoint sh "bancoxyz/secretos-init:$VERSION" -c "$BUSCAR" | tr -d '\r' | grep -v '^$' | wc -l | tr -d ' ')"
igual "bancoxyz/secretos-init: ningun archivo de claves, keystores ni contrasenas (genera los suyos al correr)" 0 "$encontrados"
if [ -e "$RAIZ/.git" ] && git -C "$RAIZ" rev-parse --git-dir > /dev/null 2>&1; then
  n="$(git -C "$RAIZ" ls-files | grep -ciE '\.(p12|pfx|jks|key|pem|crt|password|secret)$|(^|/)\.env$')"
  igual "git: ningun archivo de claves, keystores, certificados ni contrasenas versionado" 0 "$n"
else
  # Copia sin .git (el .zip): se revisa el arbol, sin las carpetas que genera el propio sistema (certs/, secrets/, run/...).
  n="$(cd "$RAIZ" && find . \( -name .git -o -name target -o -name run -o -name certs -o -name secrets -o -name respaldos -o -name dist \) -prune -o -type f -print \
    | sed 's#^\./##' | grep -ciE '\.(p12|pfx|jks|key|pem|crt|password|secret)$|(^|/)\.env$')"
  igual "copia sin .git: ningun archivo de claves, keystores, certificados ni contrasenas en el arbol" 0 "$n"
fi

# ===============================================================================================
echo "== 3. docker compose config sin advertencias y sin imagenes latest =="
# ===============================================================================================
SALIDA="$("${COMPOSE[@]}" config -q 2>&1)"
CODIGO=$?
igual "docker compose config -q: codigo de salida" 0 "$CODIGO"
igual "docker compose config -q: ninguna advertencia ni mensaje" "" "$SALIDA"
IMAGENES="$("${COMPOSE[@]}" config --images | sort -u)"
igual "compose: ninguna imagen con etiqueta latest ni sin etiqueta" 0 \
  "$(echo "$IMAGENES" | grep -cE ':latest$|^[^:]+$')"
echo "$IMAGENES" | sed 's/^/        imagen: /'
# Etiquetas que fijan version en los FROM de cada Dockerfile (maven:3.9.16-..., eclipse-temurin:21.0.12.1_1-...).
for f in */Dockerfile docker/secretos-init/Dockerfile; do
  malos="$(grep -E '^FROM ' "$f" | awk '{print $2}' | grep -vE ':[0-9]+\.[0-9]+\.[0-9]+' | tr '\n' ' ')"
  igual "$f: cada FROM fija la version exacta" "" "$(echo "$malos" | sed 's/ $//')"
done
EXT="$(echo "$IMAGENES" | grep -v '^bancoxyz/')"
malos="$(echo "$EXT" | grep -vE ':v?[0-9]+(\.[0-9]+)+' | tr '\n' ' ')"
igual "imagenes externas del compose: etiqueta con numero de version" "" "$(echo "$malos" | sed 's/ $//')"
sin_latest="$(grep -rnE '(^|[^a-zA-Z])image:.*:latest|^FROM .*:latest' docker-compose.yaml */Dockerfile docker/secretos-init/Dockerfile | wc -l | tr -d ' ')"
igual "ningun 'latest' en el compose ni en los Dockerfile" 0 "$sin_latest"

# ===============================================================================================
echo "== 4. Limites de recursos y salud con ellos =="
# ===============================================================================================
# Servicios de larga vida (las tareas unicas, secretos-init y kafka-init, no llevan limite de memoria sostenido).
LARGA_VIDA=(postgres kafka kafka-ui "${SERVICIOS[@]}")
for s in "${LARGA_VIDA[@]}"; do
  for id in $(cids "$s"); do
    nombre="$(docker inspect -f '{{.Name}}' "$id" | sed 's#^/##')"
    mem="$(docker inspect -f '{{.HostConfig.Memory}}' "$id")"
    cpu="$(docker inspect -f '{{.HostConfig.NanoCpus}}' "$id")"
    pids="$(docker inspect -f '{{.HostConfig.PidsLimit}}' "$id")"
    if [ "$mem" -gt 0 ] 2> /dev/null && [ "$cpu" -gt 0 ] 2> /dev/null && [ "${pids:-0}" -gt 0 ] 2> /dev/null; then
      resultado PASS "$nombre: limites de memoria, CPU y procesos" "$((mem / 1048576)) MiB, $(python3 -c "print($cpu/1e9)") CPU, $pids procesos"
    else
      resultado FAIL "$nombre: limites de memoria, CPU y procesos" "memoria=$mem cpu=$cpu pids=$pids"
    fi
    igual "$nombre: healthy con esos limites" "running healthy" "$(docker inspect -f '{{.State.Status}} {{.State.Health.Status}}' "$id")"
  done
done
# Margen: lo que ocupa cada contenedor frente a su limite (docker stats trae MemPerc).
ALTO="$(docker stats --no-stream --format '{{.Name}} {{.MemPerc}}' $("${COMPOSE[@]}" ps -q) 2> /dev/null \
  | awk '{p=$2; sub(/%/,"",p); if (p+0 > 85) print $1" "$2}')"
igual "ningun contenedor usa mas del 85 % de su limite de memoria" "" "$ALTO"
# La JVM debe leer el limite del contenedor, no la memoria de la maquina: -XX:MaxRAMPercentage=75 hace que el heap maximo
# sea el 75 % del LIMITE. Se pregunta al servicio en marcha por su heap maximo real (metrica jvm.memory.max del Actuator,
# que suma Eden, Survivor y Tenured: sale un poco bajo el 75 % exacto porque un Survivor se reserva). Se acepta entre el
# 65 % y el 76 % del limite; sin limite, la JVM tomaria el 75 % de la maquina entera y la comprobacion falla.
for s in core-service bff-web notificaciones-service; do
  id="$(cids "$s" | head -n 1)"
  limite="$(docker inspect -f '{{.HostConfig.Memory}}' "$id")"
  heap="$(docker exec "$id" wget -qO- 'http://127.0.0.1:8081/actuator/metrics/jvm.memory.max?tag=area:heap' 2> /dev/null \
    | python3 -c 'import sys,json; print(int(json.load(sys.stdin)["measurements"][0]["value"]))' 2> /dev/null)"
  pct="$(python3 -c "print(round(100.0 * ${heap:-0} / ${limite:-1}, 1))" 2> /dev/null)"
  if [ "${limite:-0}" -gt 0 ] && python3 -c "import sys; sys.exit(0 if 65 <= float('${pct:-0}') <= 76 else 1)" 2> /dev/null; then
    resultado PASS "$s: el heap maximo de la JVM es ~75 % del limite del contenedor" "$((heap / 1048576)) MiB de $((limite / 1048576)) MiB = ${pct} %"
  else
    resultado FAIL "$s: el heap maximo de la JVM es ~75 % del limite del contenedor" "heap=${heap:-?} limite=${limite:-?} (${pct:-?} %)"
  fi
done

# ===============================================================================================
echo "== 5. Imagenes base multiarquitectura (amd64 y arm64) =="
# ===============================================================================================
BASES="$( { grep -hE '^FROM ' */Dockerfile docker/secretos-init/Dockerfile | awk '{print $2}'; echo "$EXT"; } | sort -u)"
# El registro publico limita las consultas repetidas (HTTP 429, visto en ejecuciones reales desde una IP compartida): se
# reintenta hasta 6 veces con espera creciente (10, 20, ... 60 s) antes de dar el resultado por fallido.
plataformas_de() {
  local intento=0 salida
  while [ "$intento" -lt 6 ]; do
    salida="$(docker buildx imagetools inspect "$1" 2> /dev/null | awk '/^ +Platform:/ {print $2}' | grep -v unknown | sort -u)"
    if [ -n "$salida" ]; then echo "$salida"; return 0; fi
    intento=$((intento + 1)); sleep $((intento * 10))
  done
  return 1
}
for b in $BASES; do
  plataformas="$(plataformas_de "$b")"
  if echo "$plataformas" | grep -qx 'linux/amd64' && echo "$plataformas" | grep -qE '^linux/arm64'; then
    resultado PASS "$b publica linux/amd64 y linux/arm64" "$(echo "$plataformas" | grep -E '^linux/(amd64|arm64)' | tr '\n' ' ' | sed 's/ $//')"
  else
    resultado FAIL "$b publica linux/amd64 y linux/arm64" "plataformas: '$(echo "$plataformas" | tr '\n' ' ')' (sin conexion al registro o falta una)"
  fi
done

echo
echo "RESULTADO: $TOTAL comprobaciones, $FALLOS FAIL"
[ "$FALLOS" = 0 ] && echo "todo PASS" || echo "HAY FALLOS"
exit $((FALLOS > 0))
