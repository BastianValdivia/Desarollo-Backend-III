import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.ByteArrayOutputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Cuenta cuantos bytes ocupa un cuerpo JSON despues de pasarlo por gzip.
 *
 * <h2>Que lugar ocupa esto en la arquitectura</h2>
 * Ninguno, igual que {@code GenerarClaves} y {@code FirmarTokenDePrueba}. Vive en
 * {@code scripts/}, no entra en ningun artefacto desplegable y nada del sistema en
 * ejecucion lo invoca. Existe para producir un numero de la evidencia.
 *
 * <h2>Que pregunta contesta</h2>
 * El canal del cajero tiene la compresion <b>apagada</b>, y la afirmacion que respalda esa
 * decision es que comprimir su respuesta <b>costaria</b> bytes en vez de ahorrarlos. Esa
 * afirmacion no se puede medir con {@code curl} contra el cajero, justamente porque alli la
 * compresion esta apagada: no hay respuesta comprimida que pesar. Asi que se mide el cuerpo
 * real, fuera del servidor, con la misma libreria que usaria el servidor.
 *
 * <h2>Por que java.util.zip y no la orden gzip del sistema</h2>
 * Porque lo que se quiere predecir es lo que produciria <b>Tomcat</b>, y Tomcat comprime con
 * {@link GZIPOutputStream} de la propia JVM, con el nivel por defecto de {@code Deflater}. La
 * orden {@code gzip} del sistema usa otra implementacion, otro nivel por defecto y ademas
 * escribe el nombre del archivo dentro de la cabecera, lo que cambia el tamano. Mediria algo
 * parecido pero no lo mismo, y en cuerpos de 43 bytes esa diferencia es justamente la que
 * decide el resultado.
 *
 * <h2>De donde sale el coste fijo</h2>
 * Un miembro gzip son 10 bytes de cabecera mas 8 de cola (CRC de 4 y longitud de 4), 18 en
 * total, que estan siempre y no dependen del contenido. Por debajo de cierto tamano el ahorro
 * del algoritmo no alcanza a pagar esos 18 bytes y el resultado sale mas grande que la
 * entrada. Ese punto de equilibrio es lo que este programa permite localizar midiendo, en vez
 * de repetir de memoria la cifra de 1 o 2 KB que suele citarse.
 *
 * <h2>POR QUE RECIBE ARCHIVOS Y NO EL JSON EN LA LINEA DE ORDENES</h2>
 * Esta es la parte importante, y es una correccion a la primera version de este programa, que
 * si recibia los cuerpos como argumentos y por eso <b>mintio</b>.
 *
 * <p>La JVM decodifica los argumentos de la linea de ordenes con el juego de caracteres que
 * anuncia la propiedad {@code sun.jnu.encoding}, que sale del locale del sistema. En esta
 * maquina el locale es {@code POSIX} y esa propiedad vale {@code ANSI_X3.4-1968}, que es
 * US-ASCII. El dataset trae descripciones con eñe, y cada eñe son dos bytes UTF-8 que ASCII
 * no sabe decodificar: la JVM los sustituye por el caracter de reemplazo U+FFFD, que al
 * volver a codificarse en UTF-8 ocupa <b>tres</b> bytes. Cada byte no-ASCII de la entrada se
 * convertia asi en tres a la salida.
 *
 * <p>El sintoma medido: el cuerpo de la ficha web pesa 1973 bytes segun {@code curl} y este
 * programa informaba 1981. Ocho bytes de diferencia, que son exactamente los cuatro bytes
 * no-ASCII del cuerpo multiplicados por los dos bytes que cada uno ganaba. No fallaba nada, no
 * habia excepcion, y el numero equivocado era lo bastante parecido al bueno como para pasar
 * desapercibido. Las filas del cajero y del movil no lo delataron porque sus cuerpos son ASCII
 * puro y el error valia cero justo alli.
 *
 * <p>La leccion general: <b>un cuerpo HTTP es una secuencia de bytes, no un texto</b>, y en
 * cuanto se le deja cruzar una frontera que decodifica y vuelve a codificar (la linea de
 * ordenes, una variable de entorno, un portapapeles) deja de ser el mismo objeto. Por eso
 * ahora se leen archivos con {@link Files#readAllBytes}, que no interpreta nada.
 *
 * <h2>Uso</h2>
 * <pre>
 *   curl -ks "$URL" -H "..." &gt; /tmp/cuerpo.json
 *   java scripts/GzipCuestaBytes.java /tmp/cuerpo.json [mas-archivos...]
 * </pre>
 * Imprime una fila por archivo con el tamano plano, el comprimido y la variacion porcentual;
 * una variacion <b>positiva</b> significa que comprimir costo bytes.
 */
public final class GzipCuestaBytes {

    /** Clase de utilidad: no tiene sentido instanciarla. */
    private GzipCuestaBytes() {
    }

    /**
     * Punto de entrada.
     *
     * @param args rutas de los archivos con los cuerpos a pesar
     * @throws Exception si un archivo no existe o la compresion falla; ante cualquiera de las
     *                   dos lo unico sensato es abortar, porque una fila a medias produciria
     *                   una evidencia que parece decir algo y no dice nada
     */
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("Uso: java GzipCuestaBytes.java <archivo.json> [mas archivos...]");
            System.exit(2);
        }

        System.out.printf("  %-46s %8s %8s %10s%n", "cuerpo", "plano", "gzip", "variacion");
        System.out.println("  " + "-".repeat(76));

        for (String ruta : args) {
            // readAllBytes no decodifica: entrega los bytes tal como estan en el disco, que
            // son los mismos que viajaron por el cable. Aqui esta el arreglo del error
            // descrito arriba.
            byte[] plano = Files.readAllBytes(Path.of(ruta));

            ByteArrayOutputStream destino = new ByteArrayOutputStream();
            try (GZIPOutputStream gzip = new GZIPOutputStream(destino)) {
                gzip.write(plano);
            }
            // El cierre del try-with-resources es obligatorio ANTES de leer el tamano: hasta
            // que no se cierra, el flujo no ha volcado el bloque final ni la cola de 8 bytes,
            // y destino.size() devolveria un numero menor que el definitivo.
            int comprimido = destino.size();

            double variacion = (comprimido - plano.length) * 100.0 / plano.length;

            // La etiqueta se construye decodificando en UTF-8 A PROPOSITO y solo para mostrar.
            // El tamano ya esta calculado sobre los bytes crudos, asi que lo que pase aqui no
            // puede contaminar la medicion.
            String texto = new String(plano, StandardCharsets.UTF_8).replaceAll("\\s+", " ");
            String etiqueta = texto.length() > 44 ? texto.substring(0, 41) + "..." : texto;

            System.out.printf("  %-46s %8d %8d %+9.1f%%%n",
                    etiqueta, plano.length, comprimido, variacion);
        }
    }
}
