#!/usr/bin/env bash
# =====================================================================
# medir-canales.sh: la regla de oro de la fase 7 hecha comando.
# =====================================================================
# "No optimices nada que no puedas medir." Este script es el instrumento
# con el que se mide. Produce una tabla de tamano y tiempo por canal, y
# se ejecuta IGUAL antes y despues de cada cambio de configuracion; la
# comparacion de las dos salidas es la evidencia.
#
# Por que solo curl y python3, pudiendo usar jq:
#   jq esta instalado en esta maquina, pero puede no estarlo en la del
#   evaluador. Un script de evidencia que no corre en la maquina de quien
#   corrige no es evidencia: es una captura de pantalla con pasos extra.
#
# Por que 23 iteraciones y se descartan las 3 primeras:
#   la primera peticion a una aplicacion Spring Boot recien arrancada
#   tarda entre 300 y 800 ms por carga de clases y compilacion JIT. Ese
#   numero es real pero no representa el comportamiento en regimen, y sin
#   descartarlo la evidencia de "tiempos rapidos" se ve pesima por una
#   razon ajena al diseno. Se miden 23 y se informan las ultimas 20.
#
# Por que curl -k contra los BFF:
#   los tres sirven HTTPS con certificado autofirmado. -k le dice a curl
#   que no verifique la cadena. En produccion esto NO se hace: alli el
#   certificado lo firma una autoridad y curl lo valida sin ayuda.
#
# Uso:  ./scripts/medir-canales.sh [etiqueta]
#       La etiqueta aparece en el encabezado (por ejemplo "antes"/"despues").
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS          # regla operativa 1: sin esto, cada java/curl
                                 # arrastra 900 caracteres de ruido a la salida
# ENTORNO=docker (por defecto): contenedores, TLS verificado con certs/ca.crt; ENTORNO=local:
# JVM locales del S5 con curl -k. Ver scripts/lib-entorno.sh.
source "$(dirname "${BASH_SOURCE[0]}")/lib-entorno.sh"

source "$(dirname "${BASH_SOURCE[0]}")/lib-login.sh"

ETIQUETA="${1:-sin-etiqueta}"
REPETICIONES=23
DESCARTE=3


# Extractor congelado en el contrato (seccion 5.2): el campo se llama
# accessToken. Si se leyera "token", la variable quedaria vacia y las
# decenas de peticiones siguientes darian 401 en cascada, un sintoma que
# no apunta en absoluto a la causa.
LEER_TOKEN='import sys,json; print(json.load(sys.stdin)["accessToken"])'

echo "======================================================================"
echo " Medicion por canal  ---  etiqueta: ${ETIQUETA}"
echo " Fecha: $(date -Is)"
echo " ${REPETICIONES} repeticiones, se descartan las ${DESCARTE} primeras (calentamiento JIT)"
echo "======================================================================"

TW="$(token_web cliente116 Cliente.2026)"
TM="$(token_movil cliente116 Cliente.2026 dispositivo-demo-01)"
TA="$(token_cajero 4000000000000116 1234)"

# ---------------------------------------------------------------------
# medir <nombre> <acepta-gzip: si|no> <url> [cabeceras extra...]
#
# %{size_download} con --compressed informa los bytes que EFECTIVAMENTE
# viajaron por el cable, no el cuerpo ya descomprimido. Es decir, mide lo
# que queremos medir: transferencia, no tamano logico.
# ---------------------------------------------------------------------
medir() {
  local nombre="$1"; shift
  local gzip="$1"; shift
  local url="$1"; shift
  # ${acepta[@]+...}: un arreglo vacio con "set -u" da "unbound variable" en el bash 3.2 de macOS.
  local acepta=()
  [ "$gzip" = "si" ] && acepta=(--compressed)

  local salida
  salida=$(for _ in $(seq 1 $REPETICIONES); do
             curl_bff ${acepta[@]+"${acepta[@]}"} -o /dev/null \
                  -w '%{http_code} %{size_download} %{size_header} %{time_total}\n' \
                  "$url" "$@"
           done | tail -n $((REPETICIONES - DESCARTE)))

  echo "$salida" | python3 -c "
import sys
filas=[l.split() for l in sys.stdin if l.strip()]
codigos={f[0] for f in filas}
cuerpo=int(filas[-1][1]); cab=int(filas[-1][2])
ts=sorted(float(f[3])*1000 for f in filas)
n=len(ts)
prom=sum(ts)/n
p50=ts[n//2]; p95=ts[min(n-1,int(n*0.95))]
print(f'  {\"$nombre\":<34} {\"/\".join(sorted(codigos)):>5} {cuerpo:>7} {cab:>7} {prom:8.1f} {p50:8.1f} {p95:8.1f} {ts[-1]:8.1f}')
"
}

# El core no es alcanzable desde el host en Docker (sin puertos publicados): su fila de linea base
# se mide dentro de su contenedor y solo informa el tamano del cuerpo, que es lo que sirve de
# referencia. En local se mide como siempre, con curl.
medir_core() {
  if [ "$ENTORNO" = local ]; then
    medir "$1" no "http://127.0.0.1:8080$2" -H "Authorization: Bearer $(token_servicio "$(cliente_para_ruta "$2")")"
  else
    printf '  %-34s %5s %7s   (core no alcanzable desde el host: cuerpo medido dentro de su contenedor)\n' "$1" "200" "$(core_bytes "$2")"
  fi
}

printf '  %-34s %5s %7s %7s %8s %8s %8s %8s\n' \
       "peticion" "http" "cuerpo" "cabec." "prom_ms" "p50_ms" "p95_ms" "max_ms"
printf '  %s\n' "--------------------------------------------------------------------------------------------"

echo "  -- linea base: el core, sin BFF (es la referencia de tamano) --"
medir_core "core C2 cuenta completa"   /internal/v1/cuentas/116
medir_core "core C3 saldo"             /internal/v1/cuentas/116/saldo

echo "  -- canal web (8443) --"
medir "web W2 ficha (sin gzip)"        no  "$WEB/v1/cuentas/116"                    -H "Authorization: Bearer $TW"
medir "web W2 ficha (--compressed)"    si  "$WEB/v1/cuentas/116"                    -H "Authorization: Bearer $TW"
medir "web W3 movimientos (sin gzip)"  no  "$WEB/v1/cuentas/116/movimientos"        -H "Authorization: Bearer $TW"
medir "web W3 movimientos (--compr.)"  si  "$WEB/v1/cuentas/116/movimientos"        -H "Authorization: Bearer $TW"
medir "web W4 resumen-mensual (--c.)"  si  "$WEB/v1/cuentas/116/resumen-mensual"    -H "Authorization: Bearer $TW"

echo "  -- canal movil (8444) --"
medir "movil M2 resumen (sin gzip)"    no  "$MOVIL/v1/cuentas/116/resumen"          -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01'
medir "movil M2 resumen (--compressed)" si "$MOVIL/v1/cuentas/116/resumen"          -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01'

echo "  -- canal cajero (8445) --"
medir "atm A2 saldo (sin gzip)"        no  "$ATM/v1/cuentas/116/saldo-disponible"   -H "Authorization: Bearer $TA"
medir "atm A2 saldo (--compressed)"    si  "$ATM/v1/cuentas/116/saldo-disponible"   -H "Authorization: Bearer $TA"
medir "atm A4 denominaciones (--c.)"   si  "$ATM/v1/denominaciones"                 -H "Authorization: Bearer $TA"

echo
echo "  Lectura: 'cuerpo' son los bytes del cuerpo que viajaron por el cable."
echo "  Si una fila --compressed muestra MAS bytes que su par sin gzip, comprimir"
echo "  esta costando bytes en vez de ahorrarlos, y la optimizacion correcta es"
echo "  apagarla en ese canal."
