#!/usr/bin/env bash
# =====================================================================
# medir-escalado.sh: mide el ESCALADO del consumidor de notificaciones (F7). Procesa el MISMO lote de eventos con
# 1, 3 y 4 consumidores del grupo "notificaciones" y mide cuanto tarda en procesarlo todo (del primer evento al ultimo) y quedar con lag cero.
#
# Que demuestra, en orden:
#   1 consumidor   procesa las 3 particiones de cada topico: es la referencia.
#   3 consumidores cada uno toma una particion de cada topico: el tiempo baja casi a un tercio.
#   4 consumidores el cuarto queda OCIOSO (kafka-consumer-groups --members muestra 0 particiones): los topicos tienen 3
#                  particiones y una particion la atiende un solo consumidor del grupo. Agregar mas consumidores
#                  que particiones no acelera nada. Esa es la razon de elegir 3 particiones.
#
# El lote: LOTE eventos RETIRO_EJECUTADO sinteticos (por defecto 900), repartidos EXACTAMENTE en partes iguales entre
# las 3 particiones (la clave de cada uno se elige con el mismo particionador que usa Kafka), con eventId nuevos
# en cada repeticion. Todos de las cuentas 9100 a 9102 (no existen en el banco). Cada evento cuesta lo que la pasarela
# simulada tarda (notificaciones.pasarela.latencia-ms, 20 ms) mas una escritura en la base.
#
# Para que la medicion sea de las notificaciones y no de la maquina, DETIENE auditoria-service durante las pruebas (si
# no, competiria por los 4 CPU con los consumidores; al volver procesa el lote igual y no se queda nada), y al
# terminar deja las 2 replicas de notificaciones del compose y borra de las bases los eventos sinteticos.
#
# Uso:  scripts/medir-escalado.sh [LOTE] [REPETICIONES]     (por defecto 900 y 2; tambien LOTE y REPETICIONES)
# Dura unos 6 a 8 minutos (levantar una replica cuesta ~40 s). Solo ENTORNO=docker.
# Portabilidad: bash 3.2 y Git Bash; requiere docker y python3.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
if [ "${ENTORNO:-docker}" != docker ]; then
  echo "ERROR: medir-escalado.sh mide el compose: ejecutalo con ENTORNO=docker (el valor por defecto)." >&2
  exit 2
fi
source "$RAIZ/scripts/lib-entorno.sh"
source "$RAIZ/scripts/lib-kafka.sh"

LOTE="${1:-${LOTE:-900}}"
REPETICIONES="${2:-${REPETICIONES:-2}}"
FILTRO='^bancoxyz\.(retiros|seguridad)\.v1$'
sql_n() { sql_postgres "$1" "$2" 2> /dev/null | tr -d '[:space:]'; }
ahora_ms() { python3 -c 'import time; print(int(time.time() * 1000))'; }

limpiar() {
  sql_postgres notificaciones "DELETE FROM notificacion WHERE destinatario LIKE 'titular-cuenta-910_'; DELETE FROM evento_procesado WHERE event_id NOT IN (SELECT event_id FROM notificacion) AND tipo = 'RETIRO_EJECUTADO' AND procesado_en > now() - interval '3 hours';" > /dev/null 2>&1
  sql_postgres auditoria "DELETE FROM evento_auditado WHERE cuenta_id BETWEEN 9100 AND 9199;" > /dev/null 2>&1
}
restaurar() {
  "${COMPOSE[@]}" up -d --scale notificaciones-service=2 --no-recreate notificaciones-service > /dev/null 2>&1
  "${COMPOSE[@]}" start auditoria-service > /dev/null 2>&1
}
trap 'restaurar; exit 130' INT TERM

lag_notificaciones_cero() { [ "$(lag_del_grupo notificaciones "$FILTRO")" = 0 ]; }

miembros_del_grupo() {  # "<consumidores> <particiones asignadas> <consumidores ociosos>"
  kafka_cli kafka-consumer-groups.sh --bootstrap-server localhost:9092 --describe --group notificaciones --members 2> /dev/null | tr -d '\r' \
    | awk '$1 == "notificaciones" && $NF ~ /^[0-9]+$/ { n++; p += $NF; if ($NF == 0) o++ } END { print n + 0, p + 0, o + 0 }'
}

estabilizar() {  # estabilizar <consumidores esperados>: espera N miembros, 6 particiones asignadas y lag 0
  local esperados="$1" i=0 estado
  while [ "$i" -lt 240 ]; do
    estado="$(miembros_del_grupo)"
    if [ "$(echo "$estado" | awk '{print $1}')" = "$esperados" ] && [ "$(echo "$estado" | awk '{print $2}')" = 6 ] \
      && [ "$(lag_del_grupo notificaciones "$FILTRO")" = 0 ]; then
      return 0
    fi
    sleep 2
    i=$((i + 1))
  done
  return 1
}

escalar() {  # escalar <n>: deja n replicas de notificaciones sanas
  "${COMPOSE[@]}" up -d --scale notificaciones-service="$1" --no-recreate notificaciones-service > /dev/null 2>&1
  local i=0
  while [ "$i" -lt 180 ]; do
    local ids sanos=0 total=0 id
    ids="$("${COMPOSE[@]}" ps -q notificaciones-service)"
    for id in $ids; do
      total=$((total + 1))
      [ "$(docker inspect -f '{{.State.Health.Status}}' "$id" 2> /dev/null)" = healthy ] && sanos=$((sanos + 1))
    done
    [ "$total" = "$1" ] && [ "$sanos" = "$1" ] && return 0
    sleep 2
    i=$((i + 1))
  done
  return 1
}

generar_lote() {  # imprime LOTE lineas "clave|json", repartidas por igual entre las 3 particiones
  local k0 k1 k2
  k0="$(clave_para_particion 0 3 9100)"; k1="$(clave_para_particion 1 3 9100)"; k2="$(clave_para_particion 2 3 9100)"
  python3 - "$LOTE" "$k0" "$k1" "$k2" << 'PY'
import json, sys, uuid
lote, claves = int(sys.argv[1]), sys.argv[2:5]
for i in range(lote):
    p = i % 3
    ev = {"eventId": str(uuid.uuid4()), "tipo": "RETIRO_EJECUTADO", "version": 1, "ocurridoEn": "2026-10-03T12:00:00Z",
          "origen": "medir-escalado.sh", "datos": {"cuentaId": 9100 + p, "folio": "RET-ESCALADO-%d" % i, "monto": 1000,
          "saldoAnterior": 5000, "saldoPosterior": 4000, "movimientoId": i, "moneda": "CLP"}}
    print("%s|%s" % (claves[p], json.dumps(ev)))
PY
}

echo "Medicion del escalado: lote de $LOTE eventos, $REPETICIONES repeticion(es) por configuracion"
echo "Pasarela simulada: latencia de $(grep -m1 'latencia-ms:' config-repo/notificaciones-service.yml | awk '{print $2}') ms por evento (config-repo/notificaciones-service.yml)"
"${COMPOSE[@]}" stop auditoria-service > /dev/null 2>&1
limpiar

RESULTADOS=""
for N in 1 3 4; do
  printf '\n== %s consumidor(es) ==\n' "$N"
  escalar "$N" || { echo "ERROR: no se pudieron levantar $N replicas sanas"; restaurar; exit 1; }
  estabilizar "$N" || { echo "ERROR: el grupo no se estabilizo con $N consumidores"; restaurar; exit 1; }
  echo "  miembros del grupo (consumidor, particiones asignadas):"
  kafka_cli kafka-consumer-groups.sh --bootstrap-server localhost:9092 --describe --group notificaciones --members 2> /dev/null | tr -d '\r' \
    | awk '$1 == "notificaciones" { printf "    %-34s %s particion(es)\n", $3, $NF }'
  tiempos=""
  for r in $(seq 1 "$REPETICIONES"); do
    ANTES="$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE destinatario LIKE 'titular-cuenta-910_'")"
    generar_lote > /tmp/lote-escalado.$$ 2> /dev/null
    T0="$(ahora_ms)"
    producir bancoxyz.retiros.v1 < /tmp/lote-escalado.$$
    TP="$(ahora_ms)"
    TPRIMERO=""
    while :; do
      HECHO="$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE destinatario LIKE 'titular-cuenta-910_'")"
      [ -z "$TPRIMERO" ] && [ "$((HECHO - ANTES))" -ge 1 ] && TPRIMERO="$(ahora_ms)"
      [ "$((HECHO - ANTES))" -ge "$LOTE" ] && break
      [ "$(( $(ahora_ms) - T0 ))" -gt 300000 ] && { echo "ERROR: el lote no termino en 5 minutos"; break; }
      sleep 0.3
    done
    T1="$(ahora_ms)"
    # El tiempo se cuenta desde que se procesa el PRIMER evento hasta el ultimo: el arranque del productor de consola
    # (una JVM, ~2 s, igual en todas las filas) no es parte de lo que se mide. Se informa ademas el total.
    ms=$((T1 - ${TPRIMERO:-$T0}))
    total=$((T1 - T0))
    esperar_hasta 60 lag_notificaciones_cero
    LAG="$(lag_del_grupo notificaciones "$FILTRO")"
    printf '  repeticion %s: %s eventos procesados en %s ms (%s eventos/s; con el arranque del productor: %s ms; publicar el lote: %s ms), lag final %s\n' \
      "$r" "$((HECHO - ANTES))" "$ms" "$((LOTE * 1000 / ms))" "$total" "$((TP - T0))" "$LAG"
    tiempos="$tiempos $ms"
    rm -f /tmp/lote-escalado.$$
  done
  MIEMBROS="$(miembros_del_grupo)"
  RESULTADOS="$RESULTADOS$N|$tiempos|$MIEMBROS
"
done

echo
echo "== Tabla de escalado ($LOTE eventos, mismo lote en cada fila) =="
printf '%-12s %-24s %-14s %-12s %-10s %s\n' "Consumidores" "Procesamiento (ms)" "Promedio (ms)" "Eventos/s" "Aceleracion" "Consumidores ociosos"
# La aceleracion se calcula respecto de la fila de 1 consumidor.
python3 - "$LOTE" "$RESULTADOS" << 'PY'
import sys
lote = int(sys.argv[1])
filas = [l.split("|") for l in sys.argv[2].strip().split("\n") if l]
datos = []
for n, tiempos, miembros in filas:
    t = [int(x) for x in tiempos.split()]
    datos.append((int(n), t, sum(t) / len(t), miembros.split()))
base = datos[0][2]
for n, t, prom, miembros in datos:
    print("%-12d %-24s %-14.0f %-12.1f %-11.2f %s" % (n, " / ".join(map(str, t)), prom, lote * 1000 / prom, base / prom, miembros[2] if len(miembros) > 2 else "?"))
PY

echo
echo "== Restaurando: 2 replicas de notificaciones, auditoria en marcha, eventos sinteticos borrados =="
restaurar
dos_replicas() { [ "$("${COMPOSE[@]}" ps -q notificaciones-service | wc -l | tr -d ' ')" = 2 ]; }
esperar_hasta 180 dos_replicas
"$RAIZ/scripts/esperar-sano.sh" 300 > /dev/null 2>&1
lag_auditoria_cero() { [ "$(lag_del_grupo auditoria "$FILTRO")" = 0 ]; }
esperar_hasta 180 lag_auditoria_cero
limpiar
echo "  notificaciones: $("${COMPOSE[@]}" ps -q notificaciones-service | wc -l | tr -d ' ') replicas; eventos sinteticos restantes: $(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE destinatario LIKE 'titular-cuenta-910_'")"
