#!/usr/bin/env bash
# =====================================================================
# verificar-entrega.sh: el criterio 6 de la pauta (Entrega: codigo fuente, documentacion y evidencia de
# ejecucion) comprobado sobre el repositorio y sobre las evidencias que genera scripts/verificar.sh.
# =====================================================================
# Solo lee: no modifica nada ni necesita el stack levantado (salvo la comprobacion de secretos en las evidencias,
# que lee los secretos de los volumenes y la omite, diciendolo, si el stack esta abajo).
#
# Que comprueba:
#   1. CODIGO     los 9 microservicios tienen modulo Maven, Dockerfile y estan en el POM padre; el compose y el
#                 .dockerignore existen con su nombre exacto; los .sh tienen fin de linea LF; ningun documento oficial
#                 del curso esta versionado.
#   2. DOCUMENTACION  README definitivo (sus secciones, sin restos del S5, sin rayas largas y con cada cifra de sus
#                 tablas igual a la evidencia); propuesta tecnica, guia de estudio y contrato de eventos; una bitacora
#                 por fase.
#   3. EVIDENCIA  evidencias/INDICE.md existe, cada archivo que cita existe, cada archivo de evidencias/salidas y de
#                 evidencias/capturas esta citado; hay evidencia de arranque, salud y resultado de CADA uno de los 9
#                 microservicios (con todo PASS); las capturas pedidas existen.
#   4. SECRETOS   ningun valor secreto del sistema (secretos de clientes, contrasenas de bases y de la CA) aparece en
#                 las evidencias.
#
# Portabilidad: bash 3.2 y Git Bash; requiere python3 (y git, si es un clon, para listar lo versionado).
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
docker() { MSYS_NO_PATHCONV=1 command docker "$@"; }
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
FALLOS=0
TOTAL=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() { if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi; }
existe() { if [ -e "$2" ]; then resultado PASS "$1" "$2"; else resultado FAIL "$1" "falta $2"; fi; }

MICROSERVICIOS=(config-server eureka-server auth-server core-service bff-web bff-mobile bff-atm notificaciones-service auditoria-service)
ES_GIT=0
# Se exige .git en la raiz: una copia descomprimida dentro de otro repositorio no es este repositorio.
[ -e .git ] && git rev-parse --git-dir > /dev/null 2>&1 && ES_GIT=1
versionados() { if [ "$ES_GIT" = 1 ]; then git ls-files; else find . -type f -not -path './.git/*' -not -path '*/target/*' | sed 's#^\./##'; fi; }

echo "== 1. Codigo fuente =="
for s in "${MICROSERVICIOS[@]}"; do
  existe "$s: modulo Maven" "$s/pom.xml"
  existe "$s: Dockerfile" "$s/Dockerfile"
  igual "$s: declarado en <modules> del POM padre" 1 "$(grep -c "<module>$s</module>" pom.xml)"
done
existe "secretos-init: Dockerfile (tarea unica que genera los secretos)" docker/secretos-init/Dockerfile
existe "docker-compose.yaml (nombre exacto de la pauta)" docker-compose.yaml
existe ".dockerignore" .dockerignore
existe ".gitattributes (fin de linea LF para los .sh)" .gitattributes
igual "docker-compose.yaml sin la clave 'version' (obsoleta)" 0 "$(grep -cE '^version:' docker-compose.yaml)"
CR=0
for f in $(versionados | grep -E '\.sh$|Dockerfile$|docker-compose\.yaml$'); do
  # Un CR al final de linea rompe el shebang y las continuaciones de linea dentro de contenedores Linux.
  [ -f "$f" ] && grep -q "$(printf '\r')" "$f" && { CR=$((CR + 1)); echo "        con CRLF: $f"; }
done
igual "ningun .sh, Dockerfile ni compose con fin de linea CRLF" 0 "$CR"
igual "ningun documento oficial del curso versionado (docs/enunciado, PBY2203_*)" 0 \
  "$(versionados | grep -cE '^docs/enunciado/|PBY2203_.*\.(docx|pdf)$')"

echo "== 2. Documentacion =="
existe "README.md" README.md
igual "README: seccion de objetivo" 1 "$(grep -ciE '^#+ .*objetivo' README.md | awk '{print ($1>0)?1:0}')"
igual "README: seccion de estructura del codigo" 1 "$(grep -ciE '^#+ .*estructura' README.md | awk '{print ($1>0)?1:0}')"
igual "README: instrucciones para ejecutar" 1 "$(grep -ciE '^#+ .*(ejecutar|ejecuci)' README.md | awk '{print ($1>0)?1:0}')"
existe "contrato de eventos (docs/eventos.md)" docs/eventos.md
existe "plan maestro" planificacion/PLAN_NOTA_MAXIMA.md
for f in F0 F1 F2 F3 F4 F5 F6 F7 F8-F9 F10; do existe "bitacora $f" "planificacion/bitacora/$f.md"; done
existe "propuesta tecnica (docs/propuesta-tecnica.md)" docs/propuesta-tecnica.md
existe "guia de estudio (docs/guia-de-estudio.md)" docs/guia-de-estudio.md
existe "scripts/empaquetar-entrega.sh (genera el .zip de la entrega)" scripts/empaquetar-entrega.sh

# El README tiene que ser el DE ESTA entrega y no basta con que tenga tres titulos: se exigen sus secciones,
# que no quede el aviso del S5, que enlace a la propuesta tecnica y al indice de evidencias, que no use
# rayas largas y que cada cifra de sus tablas coincida con la evidencia (regla 5 del plan).
# (El titulo con tilde se busca como "mo ejecutar": un rango [oó] en grep -E depende de la configuracion regional y
# falla con UTF-8 mal declarado, como ocurrio en la primera ejecucion de esta comprobacion.)
for seccion in 'Arquitectura' 'Requisitos' 'mo ejecutar' 'Seguridad' 'Resiliencia' 'Eventos con Kafka' 'Despliegue' 'Trazabilidad' 'Decisiones de dise' 'Limitaciones'; do
  igual "README: seccion '$seccion'" 1 "$(grep -cE "^## .*$seccion" README.md | awk '{print ($1>0)?1:0}')"
done
igual "README: sin el aviso de 'proyecto que evoluciona' del S5" 0 "$(grep -ciE 'este proyecto evoluciona|todav[ií]a no recoge' README.md)"
igual "README: enlaza docs/propuesta-tecnica.md" 1 "$(grep -c 'docs/propuesta-tecnica.md' README.md | awk '{print ($1>0)?1:0}')"
igual "README: enlaza evidencias/INDICE.md" 1 "$(grep -c 'evidencias/INDICE.md' README.md | awk '{print ($1>0)?1:0}')"
igual "README y documentos de docs/: sin rayas largas (em dash)" 0 "$(cat README.md docs/*.md | grep -c "$(printf '\342\200\224')")"
while IFS='|' read -r estado desc dato; do
  [ -n "$estado" ] && resultado "$estado" "$desc" "$dato"
done < <(python3 scripts/verificar-readme.py)

echo "== 3. Evidencia de ejecucion =="
existe "evidencias/INDICE.md" evidencias/INDICE.md
if [ -f evidencias/INDICE.md ]; then
  # Cada ruta evidencias/... citada en el indice debe existir; cada archivo de salidas y capturas, estar citado.
  citados="$(grep -oE 'evidencias/(salidas|capturas)/[A-Za-z0-9._-]+' evidencias/INDICE.md | sort -u)"
  faltan=""
  for c in $citados; do [ -f "$c" ] || faltan="$faltan $c"; done
  igual "todo archivo citado en INDICE.md existe" "" "$(echo "$faltan" | sed 's/^ //')"
  sin_citar=""
  for f in evidencias/salidas/*.txt evidencias/capturas/*.png; do
    [ -f "$f" ] || continue
    echo "$citados" | grep -qx "$f" || sin_citar="$sin_citar $f"
  done
  igual "todo archivo de evidencias/salidas y evidencias/capturas esta citado en INDICE.md" "" "$(echo "$sin_citar" | sed 's/^ //')"
fi
for s in "${MICROSERVICIOS[@]}"; do
  f="$(ls evidencias/salidas/*-ms-$s.txt 2> /dev/null | head -n 1)"
  if [ -z "$f" ]; then resultado FAIL "evidencia de ejecucion de $s (arranque, salud y resultado)" "falta evidencias/salidas/NN-ms-$s.txt"; continue; fi
  ok=1
  for bloque in '== 1. ARRANQUE' '== 2. SALUD' '== 3. RESULTADO' 'todo PASS'; do grep -q "$bloque" "$f" || ok=0; done
  [ "$ok" = 1 ] && resultado PASS "evidencia de $s: arranque, salud y resultado, todo PASS" "$f" || resultado FAIL "evidencia de $s: arranque, salud y resultado, todo PASS" "$f incompleto"
done
for c in eureka kafka-ui login-auth-server; do
  f="$(ls evidencias/capturas/*"$c"*.png 2> /dev/null | head -n 1)"
  if [ -n "$f" ] && [ "$(wc -c < "$f")" -gt 5000 ]; then resultado PASS "captura de $c" "$f ($(wc -c < "$f" | tr -d ' ') bytes)"; else resultado FAIL "captura de $c" "falta o esta vacia en evidencias/capturas/"; fi
done
# Cada salida que verificar.sh genera termina con su codigo de salida: ninguna debe tener un FAIL.
# (Se excluye la salida de este mismo guion, que se esta escribiendo mientras corre: se juzga por su codigo de salida.)
FALLAN="$(grep -lE '^ +FAIL ' evidencias/salidas/*.txt 2> /dev/null | grep -v -- '-entrega\.txt$' | tr '\n' ' ' | sed 's/ $//')"
igual "ninguna otra evidencia en evidencias/salidas contiene un FAIL" "" "$FALLAN"

echo "== 4. Secretos fuera de las evidencias =="
if docker compose -f docker-compose.yaml ps -q auth-server 2> /dev/null | grep -q .; then
  # Se leen los valores reales de los secretos de los volumenes y se buscan, uno por uno, en las evidencias.
  # Los valores no se imprimen: solo se cuenta cuantos aparecen.
  hallazgos=0; revisados=0
  for svc in auth-server core-service bff-web postgres; do
    # Un valor por linea: cada archivo de /run/secrets/propiedades (nombre = propiedad, contenido = valor) y,
    # en PostgreSQL, sus *.password.
    while IFS= read -r valor; do
      valor="$(printf '%s' "$valor" | tr -d '\r')"
      [ "${#valor}" -ge 8 ] || continue
      revisados=$((revisados + 1))
      if grep -rqF -- "$valor" evidencias 2> /dev/null; then hallazgos=$((hallazgos + 1)); echo "        un valor secreto de $svc aparece en las evidencias"; fi
    done < <(docker compose -f docker-compose.yaml exec -T "$svc" sh -c 'for f in /run/secrets/propiedades/* /run/secrets/*.password; do [ -f "$f" ] && { cat "$f"; echo; }; done' 2> /dev/null)
  done
  [ "$revisados" -ge 3 ] && resultado PASS "se revisaron $revisados valores secretos reales de los volumenes" || resultado FAIL "se revisaron pocos secretos" "$revisados"
  igual "ningun valor secreto aparece en evidencias/" 0 "$hallazgos"
else
  resultado PASS "stack detenido: la comprobacion de valores secretos se omite (se hace con el stack arriba)"
fi

echo
echo "RESULTADO: $TOTAL comprobaciones, $FALLOS FAIL"
[ "$FALLOS" = 0 ] && echo "todo PASS" || echo "HAY FALLOS"
exit $((FALLOS > 0))
