#!/usr/bin/env bash
# =====================================================================
# verificar-f5.sh: comprobaciones del login de usuarios (F5, criterio 1 de la pauta) contra el stack levantado con
# "docker compose up -d". Imprime PASS o FAIL con el dato real de cada una; el codigo de salida es 0 solo si todas
# pasan.
#
# Lo que NO repite: la matriz 3x3, la titularidad y los permisos por canal ya los prueban
# scripts/verificar-no-regresion.sh y scripts/verificar-matriz-3x3.sh, y el servidor de recursos del core,
# scripts/verificar-f4.sh. Este guion prueba el servidor de autorizacion como tal, con sus rechazos:
#
#   1. Web: authorization_code con PKCE; el token trae emisor, audiencia bff-web, vigencia de 1800 s y sirve.
#   2. Movil: PKCE y device_id; el token trae device_id, vigencia de 3600 s, y atado a ese dispositivo.
#   3. Cajero: grant de extension tarjeta y PIN; el token trae el terminal, vigencia de 180 s y sirve.
#   4. Lo que el auth-server rechaza: codigo canjeado con otro code_verifier, solicitud sin PKCE, redirect URI no
#      registrada, movil sin device_id, el grant "password" (prohibido por la RFC 9700), cliente desconocido.
#   5. Cajero: terminal desconocido o con secreto errado (401), PIN errado (400), tarjeta bloqueada al tercer fallo
#      durante 15 minutos (el PIN correcto tampoco la libera), y liberada al reiniciar el auth-server (el contador
#      vive en memoria; es una decision documentada en la bitacora de F5).
#
# QUE MODIFICA. Usa la tarjeta 106 (PIN 5678) para el bloqueo y reinicia el auth-server para liberarla (el resto de
# los servicios sigue con su token de servicio vigente). No falla a proposito la clave de ningun usuario web o movil
# (3 fallos bloquean 15 minutos). Dura alrededor de 1 minuto.
#
# Portabilidad: sin construcciones de bash 4 ni de GNU en el host; requiere docker, curl y python3. Solo ENTORNO=docker.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
if [ "${ENTORNO:-docker}" != docker ]; then
  echo "ERROR: verificar-f5.sh verifica el compose: ejecutalo con ENTORNO=docker (el valor por defecto)." >&2
  exit 2
fi
source "$RAIZ/scripts/lib-entorno.sh"
source "$RAIZ/scripts/lib-login.sh"

FALLOS=0
TOTAL=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() { if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi; }
claim() {  # claim <token> <nombre>
  python3 -c "
import base64,json,sys
p=sys.argv[1].split('.')[1]; p+='='*(-len(p)%4)
print(json.loads(base64.urlsafe_b64decode(p)).get(sys.argv[2]))" "$1" "$2"
}
# La audiencia puede ser un texto o una lista: se normaliza a "a,b" (ordenada).
audiencia() {  # audiencia <token>
  python3 -c "
import base64,json,sys
p=sys.argv[1].split('.')[1]; p+='='*(-len(p)%4)
a=json.loads(base64.urlsafe_b64decode(p)).get('aud', [])
print(','.join(sorted([a] if isinstance(a, str) else a)))" "$1"
}
vigencia() { echo $(( $(claim "$1" exp) - $(claim "$1" iat) )); }
codigo() { curl_bff -o /dev/null -w '%{http_code}' "$@"; }
# Reintenta mientras la respuesta sea 503 (justo tras reiniciar un servicio el balanceador aun no tiene instancias).
codigo_estable() {
  local c n=0
  while :; do
    c="$(codigo "$@")"
    if [ "$c" != 503 ] || [ "$n" -ge 30 ]; then echo "$c"; return; fi
    n=$((n + 1)); sleep 2
  done
}
# Solicitud a /oauth2/authorize SIN sesion: imprime "<estado> <donde-redirige>" (la redireccion al login indica
# que el servidor acepto la solicitud; cualquier otra cosa es un rechazo).
authorize() {  # authorize <client_id> <redirect_uri> [nombre=valor ...]
  local cliente="$1" redirect="$2"; shift 2
  local extra=() p
  for p in "$@"; do extra+=(--data-urlencode "$p"); done
  curl -s "${TLS[@]}" -G -D - -o /dev/null --data-urlencode "response_type=code" --data-urlencode "client_id=$cliente" \
    --data-urlencode "redirect_uri=$redirect" --data-urlencode "state=xyz" ${extra[@]+"${extra[@]}"} "$AUTH_URL/oauth2/authorize" \
    | tr -d '\r' | awk 'NR==1 {estado=$2} tolower($1)=="location:" {loc=$2} END {print estado, loc}'
}
CHALLENGE="E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"   # ejemplo de la RFC 7636 (cualquier S256 valido sirve aqui)

echo "== 1. Web: authorization_code con PKCE =="
RW="$(login_pkce web-app "$REDIRECT_WEB" cliente116 Cliente.2026 2> /dev/null)"
TW="$(printf '%s' "$RW" | access_token_de)"
igual "el flujo completo (authorize, login con CSRF, codigo, canje con code_verifier) entrega un token" yes "$([ -n "$TW" ] && echo yes || echo no)"
igual "tipo de token Bearer" Bearer "$(printf '%s' "$RW" | python3 -c 'import sys,json; print(json.load(sys.stdin).get("token_type"))')"
igual "emisor fijo" "https://localhost:9000" "$(claim "$TW" iss)"
igual "audiencia solo bff-web" "bff-web" "$(audiencia "$TW")"
igual "vigencia (exp - iat) de 1800 s" 1800 "$(vigencia "$TW")"
igual "el token sirve en el BFF web (GET /v1/cuentas/116)" 200 "$(codigo_estable "$WEB/v1/cuentas/116" -H "Authorization: Bearer $TW")"
igual "sin token el mismo recurso da 401" 401 "$(codigo "$WEB/v1/cuentas/116")"
resp="$(codigo -X POST "$WEB/v1/auth/login" -H 'Content-Type: application/json' -d '{}')"
case "$resp" in 401|403|404|405) resultado PASS "el BFF web ya no tiene endpoint de login propio (respuesta $resp, sin token)" ;; *) resultado FAIL "el BFF web aun responde en /v1/auth/login" "$resp" ;; esac

echo "== 2. Movil: PKCE y device_id =="
RM="$(login_pkce mobile-app "$REDIRECT_MOVIL" cliente116 Cliente.2026 device_id=dispositivo-demo-01 2> /dev/null)"
TM="$(printf '%s' "$RM" | access_token_de)"
igual "el flujo entrega un token" yes "$([ -n "$TM" ] && echo yes || echo no)"
igual "audiencia solo bff-mobile" "bff-mobile" "$(audiencia "$TM")"
igual "claim device_id" dispositivo-demo-01 "$(claim "$TM" device_id)"
igual "vigencia (exp - iat) de 3600 s" 3600 "$(vigencia "$TM")"
igual "con su dispositivo: 200" 200 "$(codigo_estable "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01')"
igual "desde otro dispositivo: 401" 401 "$(codigo "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: telefono-robado-99')"

echo "== 3. Cajero: grant tarjeta y PIN =="
RA="$(login_cajero_json 4000000000000116 1234 2> /dev/null)"
TA="$(printf '%s' "$RA" | access_token_de)"
igual "tarjeta 116 con su PIN entrega un token" yes "$([ -n "$TA" ] && echo yes || echo no)"
igual "audiencia solo bff-atm" "bff-atm" "$(audiencia "$TA")"
igual "claim terminal" ATM-SCL-001 "$(claim "$TA" terminal | tr 'a-z' 'A-Z')"
igual "el sub no lleva el numero de tarjeta completo (enmascarado)" 1 "$(claim "$TA" sub | grep -c '\*')"
igual "vigencia (exp - iat) de 180 s" 180 "$(vigencia "$TA")"
igual "el token sirve en el BFF del cajero (saldo)" 200 "$(codigo_estable "$ATM/v1/cuentas/116/saldo-disponible" -H "Authorization: Bearer $TA")"

echo "== 4. Lo que el servidor de autorizacion rechaza =="
r="$(LOGIN_VERIFIER_FORZADO="verificador-equivocado-0123456789-0123456789-abcdefgh" login_pkce web-app "$REDIRECT_WEB" cliente116 Cliente.2026 2> /dev/null)"
igual "un codigo canjeado con otro code_verifier: invalid_grant (un codigo interceptado no sirve)" invalid_grant \
  "$(printf '%s' "$r" | python3 -c 'import sys,json; print(json.load(sys.stdin).get("error"))')"
r="$(authorize web-app "$REDIRECT_WEB")"
case "$r" in *"/login"*) resultado FAIL "web-app sin PKCE (sin code_challenge) debe rechazarse" "$r" ;; *) resultado PASS "web-app sin PKCE: rechazado" "$r" ;; esac
r="$(authorize web-app "$REDIRECT_WEB" "code_challenge=$CHALLENGE" "code_challenge_method=S256")"
case "$r" in *"/login"*) resultado PASS "web-app con PKCE S256: aceptado (redirige al formulario de login)" "$r" ;; *) resultado FAIL "web-app con PKCE debe aceptarse" "$r" ;; esac
r="$(authorize web-app "https://sitio-ajeno.example/callback" "code_challenge=$CHALLENGE" "code_challenge_method=S256")"
case "$r" in *"/login"*) resultado FAIL "redirect_uri no registrada debe rechazarse" "$r" ;; *) resultado PASS "redirect_uri no registrada: rechazada" "$r" ;; esac
r="$(authorize mobile-app "$REDIRECT_MOVIL" "code_challenge=$CHALLENGE" "code_challenge_method=S256")"
case "$r" in *"/login"*) resultado FAIL "mobile-app sin device_id debe rechazarse" "$r" ;; *) resultado PASS "mobile-app sin device_id: rechazado" "$r" ;; esac
r="$(authorize cliente-inventado "$REDIRECT_WEB" "code_challenge=$CHALLENGE" "code_challenge_method=S256")"
case "$r" in *"/login"*) resultado FAIL "cliente desconocido debe rechazarse" "$r" ;; *) resultado PASS "cliente desconocido: rechazado" "$r" ;; esac
SECRETO_WEB="$(secreto_cliente bff-web)"
r="$(printf 'user = "bff-web:%s"\n' "$SECRETO_WEB" | curl -s "${TLS[@]}" -K - -d grant_type=password -d username=cliente116 -d password=Cliente.2026 "$AUTH_URL/oauth2/token")"
igual "el grant 'password' (prohibido por la RFC 9700) no existe: unauthorized_client o unsupported_grant_type" 1 \
  "$(printf '%s' "$r" | python3 -c 'import sys,json; print(1 if json.load(sys.stdin).get("error") in ("unauthorized_client","unsupported_grant_type") else 0)' 2> /dev/null)"
r="$(printf 'user = "bff-web:%s"\n' "$SECRETO_WEB" | curl -s "${TLS[@]}" -K - -d grant_type=client_credentials --data-urlencode "scope=retiros:ejecutar" "$AUTH_URL/oauth2/token")"
igual "un scope que el cliente no tiene registrado (bff-web pide retiros:ejecutar): invalid_scope" invalid_scope \
  "$(printf '%s' "$r" | python3 -c 'import sys,json; print(json.load(sys.stdin).get("error"))' 2> /dev/null)"

echo "== 5. Cajero: terminal, PIN y bloqueo =="
igual "terminal desconocido: 401 invalid_client" "401 invalid_client" "$(codigo_login_cajero 4000000000000116 1234 atm-scl-999) $(motivo_login_cajero 4000000000000116 1234 atm-scl-999)"
igual "terminal registrado con secreto errado: 401" 401 "$(codigo_login_cajero 4000000000000116 1234 atm-scl-001 secreto-equivocado)"
igual "tarjeta inexistente: 400 credenciales_invalidas (igual que un PIN errado: no revela que tarjetas existen)" credenciales_invalidas "$(motivo_login_cajero 4000000000009999 1234)"
igual "PIN errado (1.er intento de la tarjeta 106)" credenciales_invalidas "$(motivo_login_cajero 4000000000000106 1111)"
igual "PIN errado (2.o intento)" credenciales_invalidas "$(motivo_login_cajero 4000000000000106 2222)"
igual "PIN errado (3.er intento): la tarjeta queda bloqueada" pin_bloqueado "$(motivo_login_cajero 4000000000000106 3333)"
igual "bloqueada: ni el PIN correcto la libera (15 minutos)" pin_bloqueado "$(motivo_login_cajero 4000000000000106 5678)"
igual "otra tarjeta (116) no se ve afectada" token "$(motivo_login_cajero 4000000000000116 1234)"
echo "      reiniciando el auth-server para liberar la tarjeta (el contador esta en memoria)..."
"${COMPOSE[@]}" restart auth-server > /dev/null 2>&1
bash "$RAIZ/scripts/esperar-sano.sh" > /dev/null 2>&1
liberada() { [ "$(motivo_login_cajero 4000000000000106 5678)" = token ]; }
n=0; until liberada || [ "$n" -ge 20 ]; do n=$((n + 1)); sleep 3; done
igual "tras reiniciar el auth-server, la tarjeta 106 vuelve a autenticar con su PIN" token "$(motivo_login_cajero 4000000000000106 5678)"
# El auth-server reiniciado conserva su clave de firma (volumen): un token anterior sigue verificandose.
igual "el token de antes del reinicio sigue siendo valido (la clave de firma es persistente)" 200 "$(codigo_estable "$WEB/v1/cuentas/116" -H "Authorization: Bearer $TW")"

echo
echo "RESULTADO: $TOTAL comprobaciones, $FALLOS FAIL"
[ "$FALLOS" = 0 ] && echo "todo PASS" || echo "HAY FALLOS"
exit $((FALLOS > 0))
