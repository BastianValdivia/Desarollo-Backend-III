#!/usr/bin/env bash
# =====================================================================
# esperar-sano.sh: espera a que todos los servicios del compose esten "healthy".
# =====================================================================
# Por que existe. "docker compose up -d" (sin --wait) vuelve en cuanto los contenedores de los
# BFF estan creados e iniciados, y nada depende de ellos, asi que no los espera: el comando
# termina con el core ya sano pero con los tres BFF todavia "starting" (del orden de 15 a
# 20 segundos mas, segun la medicion de planificacion/bitacora/F2.md, seccion 5.1). Quien
# ejecute un curl o un script de verificacion justo despues choca con esa ventana y ve un
# rechazo de conexion que no es un defecto del sistema. Este guion cierra el hueco: los scripts de
# verificacion y medicion lo llaman antes de comprobar nada, y el evaluador puede usarlo solo.
#
# Uso:  scripts/esperar-sano.sh [segundos]     (por defecto 300; tambien ESPERA_SEGUNDOS)
#
# Salida: 0 si todos estan healthy; 1 si se agota el tiempo (dice cuales faltan);
#         2 si no hay ningun contenedor (el stack no se levanto: docker compose up -d).
#
# Portabilidad: bash 3.2 de macOS y Git Bash (sin arreglos asociativos ni date %N), solo docker.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
docker() { MSYS_NO_PATHCONV=1 command docker "$@"; }
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
COMPOSE=(docker compose -f docker-compose.yaml)
# core-service tiene DOS replicas (F3): un servicio esta sano solo si lo estan todas sus replicas. El auth-server
# (F4) tambien se espera: todos los guiones de login le piden tokens nada mas arrancar. Desde F7 tambien Kafka y
# los dos consumidores de eventos (notificaciones-service tiene dos replicas, como el core).
SERVICIOS=(postgres kafka config-server eureka-server auth-server core-service notificaciones-service auditoria-service bff-web bff-mobile bff-atm)
LIMITE="${1:-${ESPERA_SEGUNDOS:-300}}"

# Estado de salud de un servicio: "running/healthy" solo si TODAS sus replicas lo estan; si no, el estado
# de la primera que no lo este ("running/starting", "ausente"...), tal como lo informa Docker.
estado_de() {
  local ids id e peor=""
  ids="$("${COMPOSE[@]}" ps -a -q "$1" 2>/dev/null)"
  if [ -z "$ids" ]; then echo ausente; return; fi
  for id in $ids; do
    e="$(docker inspect -f '{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}sin-healthcheck{{end}}' "$id" 2>/dev/null || echo ausente)"
    if [ "$e" != "running/healthy" ] && [ -z "$peor" ]; then peor="$e"; fi
  done
  echo "${peor:-running/healthy}"
}

SECONDS=0
ultimo=""
while :; do
  pendientes=""
  hay_alguno=0
  for s in "${SERVICIOS[@]}"; do
    e="$(estado_de "$s")"
    [ "$e" != ausente ] && hay_alguno=1
    [ "$e" = "running/healthy" ] || pendientes="$pendientes $s($e)"
  done
  if [ -z "$pendientes" ]; then
    echo "Todos los servicios estan healthy (${SECONDS} s de espera)."
    exit 0
  fi
  # Sin ningun contenedor no hay nada que esperar: el stack no esta levantado.
  if [ "$hay_alguno" = 0 ]; then
    echo "ERROR: no hay contenedores del proyecto. Levanta el stack: docker compose up -d --build" >&2
    exit 2
  fi
  if [ "$SECONDS" -ge "$LIMITE" ]; then
    echo "ERROR: tras $LIMITE s siguen sin estar healthy:$pendientes" >&2
    exit 1
  fi
  if [ "$pendientes" != "$ultimo" ]; then
    echo "Esperando a que esten healthy:$pendientes"
    ultimo="$pendientes"
  fi
  sleep 2
done
