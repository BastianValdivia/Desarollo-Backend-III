#!/usr/bin/env bash
# =====================================================================
# lib-login.sh: el inicio de sesion de los tres canales, hecho con curl.
# =====================================================================
# Se importa con "source" (despues de lib-entorno.sh, que decide si se habla con contenedores o con JVM
# locales y deja AUTH_URL, TLS y compania). Lo usan scripts/login-web.sh, login-movil.sh y login-cajero.sh
# (que imprimen los claims del token) y los scripts de verificacion (que solo necesitan el token).
#
# Que hace el flujo web y movil (authorization_code con PKCE, RFC 7636), paso por paso. Es lo que haria
# un navegador o una app, escrito a mano para poder verlo y automatizarlo:
#
#   0. La aplicacion inventa un code_verifier aleatorio (un secreto de UN solo uso) y calcula su huella:
#      code_challenge = base64url(SHA-256(code_verifier)).
#   1. GET  /oauth2/authorize?response_type=code&client_id=..&redirect_uri=..&state=..&code_challenge=..
#      Sin sesion, el servidor responde 302 al formulario de login y abre una sesion (cookie JSESSIONID).
#   2. GET  /login                 devuelve el formulario HTML, con un campo oculto _csrf.
#   3. POST /login                 usuario, clave y el _csrf del paso 2 (sin el, el servidor responde 403:
#      es la defensa contra el login CSRF). Si es correcto, 302 de vuelta a /oauth2/authorize.
#   4. GET  /oauth2/authorize      (el 302 del paso 3). Ahora hay sesion: 302 a la redirect URI con ?code=..
#      Esa redirect URI es de loopback (http://127.0.0.1:<puerto>/callback): aqui NO se sigue, solo se lee el
#      codigo de la cabecera Location, que es lo que haria la aplicacion que escucha ahi.
#   5. POST /oauth2/token          grant_type=authorization_code, el codigo y el code_verifier del paso 0.
#      El servidor calcula SHA-256(code_verifier) y la compara con el code_challenge del paso 1: un codigo
#      interceptado no sirve sin el code_verifier, que nunca viajo por la red hasta este momento.
#
# Portabilidad: bash 3.2 (el de macOS) y Git Bash. Solo curl y python3 en el host.
# =====================================================================

REDIRECT_WEB="${REDIRECT_WEB:-http://127.0.0.1:3000/callback}"
REDIRECT_MOVIL="${REDIRECT_MOVIL:-http://127.0.0.1:3001/callback}"

# LOGIN_VERIFIER_FORZADO (solo para las pruebas de rechazo de verificar-f5.sh): canjea el codigo con ESTE
# code_verifier en lugar del verdadero, para mostrar que un codigo interceptado no sirve sin el verifier.

# Escribe un paso en stderr solo si LOGIN_VERBOSO=1 (los scripts de login lo activan; los de verificacion no).
_paso() { [ "${LOGIN_VERBOSO:-0}" = 1 ] && echo "$@" >&2; return 0; }

# Valor de una cabecera de respuesta, de un volcado de cabeceras (curl -D -). Sin distinguir mayusculas.
_cabecera() { tr -d '\r' | grep -i "^$1:" | head -1 | sed -e "s/^[^:]*: *//"; }

# Primer parametro de una URL (en su query): _param <nombre>, la URL por stdin. Decodifica porcentajes.
_param() {
  python3 -c '
import sys, urllib.parse
q = urllib.parse.urlparse(sys.stdin.read().strip()).query
v = urllib.parse.parse_qs(q).get(sys.argv[1], [""])
print(v[0])' "$1"
}

# login_pkce <client_id> <redirect_uri> <usuario> <clave> [nombre=valor ...]
#   Hace el flujo completo y escribe en stdout el JSON de la respuesta del endpoint de tokens. Los
#   nombre=valor extra son parametros adicionales de /oauth2/authorize (el movil manda device_id).
#   Termina con codigo distinto de 0 y un mensaje claro en stderr si cualquier paso falla.
login_pkce() {
  local cliente="$1" redirect="$2" usuario="$3" clave="$4"; shift 4
  local jar cab html csrf destino ubicacion codigo estado estado_recibido verifier desafio pares extra
  local -a extras=()
  jar="$(mktemp)"
  trap 'rm -f "$jar"' RETURN

  pares="$(python3 -c '
import os, base64, hashlib
v = base64.urlsafe_b64encode(os.urandom(32)).rstrip(b"=").decode()
c = base64.urlsafe_b64encode(hashlib.sha256(v.encode()).digest()).rstrip(b"=").decode()
s = base64.urlsafe_b64encode(os.urandom(12)).rstrip(b"=").decode()
print(v, c, s)')"
  verifier="${pares%% *}"; pares="${pares#* }"; desafio="${pares%% *}"; estado="${pares#* }"
  _paso "0. code_verifier (secreto de un solo uso, no sale de aqui hasta el paso 5): ${verifier}"
  _paso "   code_challenge = base64url(SHA-256(code_verifier))                       : ${desafio}"

  for extra in "$@"; do extras+=(--data-urlencode "$extra"); done

  # Paso 1: pedir autorizacion sin sesion.
  cab="$(curl -s "${TLS[@]}" -c "$jar" -b "$jar" -G -D - -o /dev/null \
    --data-urlencode "response_type=code" --data-urlencode "client_id=$cliente" \
    --data-urlencode "redirect_uri=$redirect" --data-urlencode "state=$estado" \
    --data-urlencode "code_challenge=$desafio" --data-urlencode "code_challenge_method=S256" \
    ${extras[@]+"${extras[@]}"} "$AUTH_URL/oauth2/authorize")"
  ubicacion="$(printf '%s' "$cab" | _cabecera location)"
  _paso "1. GET /oauth2/authorize (sin sesion)  -> $(printf '%s' "$cab" | head -1 | tr -d '\r')  Location: $ubicacion"
  case "$ubicacion" in
    */login) ;;
    *)
      # Rechazo ANTES del login (PKCE ausente, device_id invalido, redirect URI no registrada...).
      echo "ERROR: el servidor rechazo la solicitud de autorizacion: $(printf '%s' "$cab" | head -1 | tr -d '\r') $ubicacion" >&2
      return 1 ;;
  esac

  # Paso 2: el formulario y su token CSRF.
  html="$(curl -s "${TLS[@]}" -c "$jar" -b "$jar" "$AUTH_URL/login")"
  csrf="$(printf '%s' "$html" | sed -n 's/.*name="_csrf" value="\([^"]*\)".*/\1/p' | head -1)"
  if [ -z "$csrf" ]; then
    echo "ERROR: el formulario de login no trae el campo _csrf" >&2
    return 1
  fi
  _paso "2. GET /login                          -> formulario HTML con _csrf=${csrf}"

  # Paso 3: enviar el formulario.
  cab="$(curl -s "${TLS[@]}" -c "$jar" -b "$jar" -D - -o /dev/null \
    --data-urlencode "username=$usuario" --data-urlencode "password=$clave" --data-urlencode "_csrf=$csrf" \
    "$AUTH_URL/login")"
  destino="$(printf '%s' "$cab" | _cabecera location)"
  _paso "3. POST /login (usuario $usuario)  -> $(printf '%s' "$cab" | head -1 | tr -d '\r')  Location: $destino"
  case "$destino" in
    *"/oauth2/authorize"*) ;;
    *)
      echo "ERROR: el servidor no acepto las credenciales de $usuario (Location: ${destino:-ninguna})" >&2
      return 1 ;;
  esac

  # Paso 4: volver a /oauth2/authorize, ya con sesion. La redireccion final es a la redirect URI de
  # loopback y NO se sigue: solo se lee el codigo de la cabecera Location.
  cab="$(curl -s "${TLS[@]}" -c "$jar" -b "$jar" -D - -o /dev/null "$destino")"
  ubicacion="$(printf '%s' "$cab" | _cabecera location)"
  _paso "4. GET /oauth2/authorize (con sesion)  -> $(printf '%s' "$cab" | head -1 | tr -d '\r')  Location: $ubicacion"
  case "$ubicacion" in
    "$redirect"*) ;;
    *) echo "ERROR: no se obtuvo la redireccion a $redirect (Location: ${ubicacion:-ninguna})" >&2; return 1 ;;
  esac
  codigo="$(printf '%s' "$ubicacion" | _param code)"
  estado_recibido="$(printf '%s' "$ubicacion" | _param state)"
  if [ -z "$codigo" ]; then
    echo "ERROR: el servidor no entrego codigo: error=$(printf '%s' "$ubicacion" | _param error)" \
      "($(printf '%s' "$ubicacion" | _param error_description))" >&2
    return 1
  fi
  if [ "$estado_recibido" != "$estado" ]; then
    echo "ERROR: el parametro state no coincide (se envio $estado y volvio $estado_recibido)" >&2
    return 1
  fi
  _paso "   codigo de autorizacion: ${codigo}   (state verificado)"

  # Paso 5: canjear el codigo con el code_verifier.
  _paso "5. POST /oauth2/token (code + code_verifier)"
  curl -s "${TLS[@]}" --data-urlencode "grant_type=authorization_code" --data-urlencode "client_id=$cliente" \
    --data-urlencode "redirect_uri=$redirect" --data-urlencode "code=$codigo" \
    --data-urlencode "code_verifier=${LOGIN_VERIFIER_FORZADO:-$verifier}" "$AUTH_URL/oauth2/token"
}

# Extrae access_token de la respuesta JSON del endpoint de tokens; vacio si no hay.
access_token_de() {
  python3 -c 'import sys, json
try:
    print(json.load(sys.stdin).get("access_token", ""))
except Exception:
    print("")'
}

# token_web <usuario> <clave>: imprime solo el token de acceso (para usarlo en $(...)).
token_web() {
  local json
  json="$(login_pkce web-app "$REDIRECT_WEB" "$1" "$2")" || return 1
  _token_o_error "$json"
}

# token_movil <usuario> <clave> <device_id>
token_movil() {
  local json
  json="$(login_pkce mobile-app "$REDIRECT_MOVIL" "$1" "$2" "device_id=$3")" || return 1
  _token_o_error "$json"
}

_token_o_error() {
  local token
  token="$(printf '%s' "$1" | access_token_de)"
  if [ -z "$token" ]; then
    echo "ERROR: el servidor no entrego token: $1" >&2
    return 1
  fi
  printf '%s' "$token"
}

# ---------------------------------------------------------------------
# Cajero: grant de extension tarjeta y PIN (sin navegador, sin PKCE)
# ---------------------------------------------------------------------
# El terminal (cliente confidencial atm-scl-001) se autentica con su secreto en la cabecera Authorization: Basic
# y manda la tarjeta y el PIN en el cuerpo de un POST a /oauth2/token, con el grant_type de extension
#   urn:bancoxyz:params:oauth:grant-type:tarjeta-pin
# El grant "password" no se usa: la RFC 9700 lo prohibe. Solo un terminal registrado puede usar este.
GRANT_TARJETA_PIN="urn:bancoxyz:params:oauth:grant-type:tarjeta-pin"
TERMINAL_POR_DEFECTO="${TERMINAL_POR_DEFECTO:-atm-scl-001}"

# login_cajero_json <tarjeta> <pin> [terminal] [secreto]
#   Escribe en stdout el cuerpo JSON de la respuesta (token o error). El secreto del terminal se lee del
#   auth-server (secreto_terminal) salvo que se pase. Se entrega a curl por stdin (-K -) y no por la linea de
#   comandos, para que no se vea en la lista de procesos. LOGIN_CURL_EXTRA agrega argumentos a curl.
login_cajero_json() {
  local tarjeta="$1" pin="$2" terminal="${3:-$TERMINAL_POR_DEFECTO}" secreto="${4:-}"
  if [ -z "$secreto" ]; then
    secreto="$(secreto_terminal "$terminal" 2> /dev/null)" || secreto=""
    # Un terminal que no existe no tiene secreto que leer: se usa uno inventado para que el SERVIDOR lo rechace.
    [ -n "$secreto" ] || secreto="secreto-inventado-de-un-terminal-no-registrado"
  fi
  printf 'user = "%s:%s"\n' "$terminal" "$secreto" | curl -s "${TLS[@]}" -K - \
    ${LOGIN_CURL_EXTRA[@]+"${LOGIN_CURL_EXTRA[@]}"} \
    --data-urlencode "grant_type=$GRANT_TARJETA_PIN" --data-urlencode "numero_tarjeta=$tarjeta" \
    --data-urlencode "pin=$pin" "$AUTH_URL/oauth2/token"
}

# token_cajero <tarjeta> <pin> [terminal] [secreto]: imprime solo el token (para $(...)).
token_cajero() {
  local json
  json="$(login_cajero_json "$@")" || return 1
  _token_o_error "$json"
}

# ---------------------------------------------------------------------
# Compatibilidad con los guiones de verificacion y medicion
# ---------------------------------------------------------------------
# Los guiones del S5 leen la respuesta de login de cada BFF como {accessToken, tipoToken, expiraEn}. Desde F5 el
# login es del auth-server y su respuesta es la de OAuth 2.0 ({access_token, token_type, expires_in}). Estas
# funciones hacen el login de verdad (PKCE o tarjeta y PIN) y devuelven el JSON en la forma del S5, para que el
# resto de cada guion no cambie. Un login que falla no imprime nada y devuelve distinto de cero, con su causa en
# stderr.
_forma_s5() {
  python3 -c 'import sys, json
try:
    d = json.load(sys.stdin)
    print(json.dumps({"accessToken": d.get("access_token", ""), "tipoToken": d.get("token_type", ""),
                      "expiraEn": d.get("expires_in"), "error": d.get("error")}))
except Exception:
    print(json.dumps({"accessToken": "", "tipoToken": "", "expiraEn": None, "error": "respuesta_ilegible"}))'
}

# login_web_s5 <usuario> <clave>
login_web_s5() {
  local json
  json="$(login_pkce web-app "$REDIRECT_WEB" "$1" "$2" 2> /dev/null)" || json=""
  printf '%s' "$json" | _forma_s5
}

# login_movil_s5 <usuario> <clave> [dispositivo]
login_movil_s5() {
  local json
  json="$(login_pkce mobile-app "$REDIRECT_MOVIL" "$1" "$2" "device_id=${3:-dispositivo-demo-01}" 2> /dev/null)" || json=""
  printf '%s' "$json" | _forma_s5
}

# login_cajero_s5 <tarjeta> <pin> [terminal]
login_cajero_s5() {
  login_cajero_json "$1" "$2" "${3:-}" 2> /dev/null | _forma_s5
}

# codigo_login_cajero <tarjeta> <pin> [terminal]: solo el codigo HTTP del endpoint de tokens (200, 400, 401).
codigo_login_cajero() {
  local LOGIN_CURL_EXTRA=(-o /dev/null -w '%{http_code}')
  login_cajero_json "$@"
}

# motivo_login_cajero <tarjeta> <pin> [terminal]: error_description del auth-server (credenciales_invalidas,
# pin_bloqueado) o el error (invalid_client...), o "token" si el login dio un token.
motivo_login_cajero() {
  login_cajero_json "$@" | python3 -c 'import sys, json
d = json.load(sys.stdin)
print("token" if "access_token" in d else d.get("error_description") or d.get("error"))' 2> /dev/null
}
