#!/usr/bin/env bash
# =====================================================================
# levantar-local.sh: los siete servicios como JVM locales (perfil local).
# =====================================================================
# Orden de arranque, y por que:
#   1. config-server y eureka-server: no dependen de nadie y todos los demas
#      dependen de ellos (sin config-server un servicio no arranca, y sin
#      Eureka no se registra ni encuentra al core).
#   2. auth-server (F4): el core descarga de el las claves con que valida tokens y los BFF le piden
#      su token de servicio. En local habla HTTP en 127.0.0.1:9000 (config-repo/auth-server-local.yml);
#      en contenedores, HTTPS con la CA interna.
#   3. core-service: los BFF lo llaman por su nombre logico.
#   4. los tres BFF, en paralelo.
#
# SECRETOS DE LOS CLIENTES OAuth2 (F4): el auth-server y cada BFF necesitan compartir el secreto del
# cliente de ese BFF. Este guion los genera ALEATORIOS en la primera ejecucion, los guarda en
# run/secretos-locales.env (carpeta ignorada por git, modo 600; detener-local.sh lo borra) y los entrega a
# cada proceso por la variable SPRING_APPLICATION_JSON. No estan en el repositorio ni en los jar.
#
# Cada servicio escribe su log en run/<nombre>.log y su PID en
# run/<nombre>.pid (run/ esta en .gitignore). Se espera a que el Actuator de
# cada uno, en su puerto de gestion, responda UP.
#
# PostgreSQL (F3): el core guarda su estado en una base. Si en 127.0.0.1:5432 no responde nadie, este
# guion levanta una DESECHABLE (contenedor postgres:16.15-alpine3.24 "bancoxyz-postgres-local", usuario y base
# "core") y detener-local.sh la elimina: cada ejecucion parte de la carga inicial. Si ya tienes un
# PostgreSQL propio en ese puerto, crea en el la base y el usuario "core" y exporta
# SPRING_DATASOURCE_PASSWORD con su contrasena antes de lanzar este guion.
#
# Requisitos: JDK 21 y haber ejecutado antes
#   ./scripts/generar-secretos.sh   (los secretos viajan dentro de los .jar)
#   ./mvnw -B verify                (o: ./mvnw -B -DskipTests package)
# Se lanza desde cualquier directorio. Para detenerlos: scripts/detener-local.sh
# =====================================================================
set -u
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
mkdir -p run

# Contrasena del keystore TLS de cada BFF. El jar ya NO lleva ninguna por defecto (desde F2 los
# secretos de contenedores vienen de un volumen); en local se la damos por entorno, con el mismo
# valor por defecto con que scripts/generar-secretos.sh crea los keystores. Si se genero con otra
# (exportando estas variables antes de generar), hay que exportar la misma aqui.
export BFF_WEB_KEYSTORE_PASSWORD="${BFF_WEB_KEYSTORE_PASSWORD:-cambiar-en-produccion}"
export BFF_MOBILE_KEYSTORE_PASSWORD="${BFF_MOBILE_KEYSTORE_PASSWORD:-cambiar-en-produccion}"
export BFF_ATM_KEYSTORE_PASSWORD="${BFF_ATM_KEYSTORE_PASSWORD:-cambiar-en-produccion}"
# Contrasena de la base "core" local: el jar no lleva ninguna (config-repo tampoco). Valor de
# desarrollo para la base desechable de abajo; con una base propia, exporta la tuya.
export SPRING_DATASOURCE_PASSWORD="${SPRING_DATASOURCE_PASSWORD:-desarrollo-local}"

# Base de datos local del core. Devuelve 0 si algo escucha ya en 5432 o si pudo levantar la desechable.
asegurar_postgres() {
  if (exec 3<> /dev/tcp/127.0.0.1/5432) 2> /dev/null; then
    echo "  PostgreSQL ya responde en 127.0.0.1:5432 (se usa tal cual)"
    return 0
  fi
  if ! command -v docker > /dev/null 2>&1; then
    echo "ERROR: el core necesita PostgreSQL en 127.0.0.1:5432 (base y usuario 'core') y no hay Docker para levantar uno." >&2
    return 1
  fi
  docker rm -f bancoxyz-postgres-local > /dev/null 2>&1
  docker run -d --name bancoxyz-postgres-local -p 127.0.0.1:5432:5432 \
    -e POSTGRES_USER=core -e POSTGRES_DB=core -e POSTGRES_PASSWORD="$SPRING_DATASOURCE_PASSWORD" \
    postgres:16.15-alpine3.24 > /dev/null || return 1
  for _ in $(seq 1 30); do
    if docker exec bancoxyz-postgres-local pg_isready -q -U core -d core 2> /dev/null; then
      echo "  PostgreSQL desechable listo (contenedor bancoxyz-postgres-local, 127.0.0.1:5432)"
      return 0
    fi
    sleep 1
  done
  echo "ERROR: PostgreSQL no quedo listo en 30 s" >&2
  return 1
}

# nombre | modulo | puerto de gestion (ver config-repo/*-local.yml)
SERVICIOS=(
  "config-server|config-server|8085"
  "eureka-server|eureka-server|8086"
  "auth-server|auth-server|8087"
  "core-service|core-service|8081"
  "bff-web|bff-web|8082"
  "bff-mobile|bff-mobile|8083"
  "bff-atm|bff-atm|8084"
)

# Secretos de los clientes OAuth2 de esta ejecucion (ver el encabezado). Se leen del archivo si existe y,
# si no, se crean. Variables SECRETO_WEB, SECRETO_MOBILE, SECRETO_ATM (clientes de servicio) y SECRETO_TERMINAL
# (el terminal atm-scl-001 del cajero, F5).
preparar_secretos_locales() {
  local archivo="run/secretos-locales.env" nombre
  # Cada secreto se agrega si falta: un archivo de una ejecucion anterior (sin el del terminal del cajero,
  # que llego en F5) se completa en lugar de fallar.
  ( umask 077
    touch "$archivo"
    for nombre in WEB MOBILE ATM TERMINAL; do
      grep -q "^SECRETO_$nombre=" "$archivo" \
        || echo "SECRETO_$nombre=$(LC_ALL=C tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 40)" >> "$archivo"
    done )
  # shellcheck disable=SC1090
  . "$archivo"
}

# JSON con los secretos que necesita un servicio (SPRING_APPLICATION_JSON). Vacio si no necesita ninguno.
json_de_secretos() {
  case "$1" in
    auth-server)
      printf '{"autorizacion":{"clientes":{"bff-web":{"secreto":"%s"},"bff-mobile":{"secreto":"%s"},"bff-atm":{"secreto":"%s"}},"terminales":{"atm-scl-001":{"secreto":"%s"}}}}' \
        "$SECRETO_WEB" "$SECRETO_MOBILE" "$SECRETO_ATM" "$SECRETO_TERMINAL" ;;
    bff-web)    json_de_cliente "$SECRETO_WEB" ;;
    bff-mobile) json_de_cliente "$SECRETO_MOBILE" ;;
    bff-atm)    json_de_cliente "$SECRETO_ATM" ;;
  esac
}
json_de_cliente() {
  printf '{"spring":{"security":{"oauth2":{"client":{"registration":{"servicios-internos":{"client-secret":"%s"}}}}}}}' "$1"
}

lanzar() {
  local nombre="$1" modulo="$2"
  local jar="$modulo/target/$modulo-1.0.0.jar"
  if [ ! -f "$jar" ]; then
    echo "ERROR: falta $jar. Compila primero: ./mvnw -B -DskipTests package" >&2
    return 1
  fi
  if [ -f "run/$nombre.pid" ] && kill -0 "$(cat "run/$nombre.pid")" 2>/dev/null; then
    echo "  $nombre ya esta en marcha (PID $(cat "run/$nombre.pid"))"
    return 0
  fi
  local json
  json="$(json_de_secretos "$nombre")"
  if [ -n "$json" ]; then
    SPRING_APPLICATION_JSON="$json" java -jar "$jar" > "run/$nombre.log" 2>&1 &
  else
    java -jar "$jar" > "run/$nombre.log" 2>&1 &
  fi
  echo $! > "run/$nombre.pid"
  echo "  $nombre lanzado (PID $!), log en run/$nombre.log"
}

esperar() {
  local nombre="$1" puerto="$2" intentos=90
  while [ "$intentos" -gt 0 ]; do
    if curl -fs "http://127.0.0.1:$puerto/actuator/health" 2>/dev/null | grep -q '"status":"UP"'; then
      echo "  $nombre UP (gestion :$puerto)"
      return 0
    fi
    if [ -f "run/$nombre.pid" ] && ! kill -0 "$(cat "run/$nombre.pid")" 2>/dev/null; then
      echo "ERROR: $nombre termino al arrancar. Ultimas lineas de run/$nombre.log:" >&2
      tail -n 15 "run/$nombre.log" >&2
      return 1
    fi
    sleep 2
    intentos=$((intentos - 1))
  done
  echo "ERROR: $nombre no respondio UP en 180 s. Revisa run/$nombre.log" >&2
  return 1
}

fase() {  # fase <servicio>...  : lanza todos los de la fase y luego espera a cada uno
  local s nombre modulo puerto
  for s in "$@"; do
    IFS='|' read -r nombre modulo puerto <<< "$s"
    lanzar "$nombre" "$modulo" || exit 1
  done
  for s in "$@"; do
    IFS='|' read -r nombre modulo puerto <<< "$s"
    esperar "$nombre" "$puerto" || exit 1
  done
}

preparar_secretos_locales

echo "1/4 Plataforma: config-server y eureka-server"
fase "${SERVICIOS[0]}" "${SERVICIOS[1]}"
echo "2/4 Seguridad: auth-server (emisor de tokens)"
fase "${SERVICIOS[2]}"
echo "3/4 Dominio: PostgreSQL y core-service"
asegurar_postgres || exit 1
fase "${SERVICIOS[3]}"
echo "4/4 Canales: bff-web, bff-mobile, bff-atm"
fase "${SERVICIOS[4]}" "${SERVICIOS[5]}" "${SERVICIOS[6]}"

# "UP" en Actuator no significa "ya registrado en Eureka": el registro y la descarga de la lista
# tardan unos segundos (5 s de latido con el perfil demo). Se espera a verlos a los cinco.
echo "Esperando a que Eureka liste auth-server, core-service, bff-web, bff-mobile y bff-atm..."
for _ in $(seq 1 30); do
  apps="$(curl -s -H 'Accept: application/json' http://localhost:8761/eureka/apps 2>/dev/null)"
  if echo "$apps" | grep -q '"AUTH-SERVER"' && echo "$apps" | grep -q '"CORE-SERVICE"' \
     && echo "$apps" | grep -q '"BFF-WEB"' && echo "$apps" | grep -q '"BFF-MOBILE"' \
     && echo "$apps" | grep -q '"BFF-ATM"'; then
    echo "  los cinco registrados"
    registrados=1
    break
  fi
  sleep 2
done
[ "${registrados:-0}" = 1 ] || { echo "ERROR: Eureka no lista los cinco servicios tras 60 s" >&2; exit 1; }

echo
echo "Todo arriba. Dashboard de Eureka: http://localhost:8761"
echo "Para detener: scripts/detener-local.sh"
