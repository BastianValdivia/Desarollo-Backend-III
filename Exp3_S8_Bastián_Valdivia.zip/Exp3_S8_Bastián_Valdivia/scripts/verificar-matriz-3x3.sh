#!/usr/bin/env bash
# =====================================================================
# verificar-matriz-3x3.sh: los tres tokens contra los tres canales.
# =====================================================================
# La afirmacion que este guion comprueba es que un token emitido para un
# canal NO sirve en los otros dos. Desde F5 los tres tokens los emite el
# MISMO servidor (el auth-server, con una sola clave de firma), asi que la
# unica barrera entre canales es la AUDIENCIA: cada canal declara la suya
# y rechaza los tokens cuyo claim aud no la nombra. Los tokens se obtienen
# de verdad, con los scripts de login (PKCE para web y movil, tarjeta y PIN
# para el cajero).
#
# La matriz tiene nueve celdas: las tres de la diagonal deben responder
# 200 y las seis restantes 401. Un 200 fuera de la diagonal significaria
# que un canal acepta credenciales de otro.
#
# Se ejecuta despues de cualquier cambio de configuracion, porque es la
# propiedad mas facil de romper sin querer: basta tocar una audiencia o
# una ruta de clave en un application.yml.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
# ENTORNO=docker (por defecto): contenedores, TLS verificado con certs/ca.crt.
# ENTORNO=local: JVM locales del S5, con curl -k. Ver scripts/lib-entorno.sh.
source "$(dirname "${BASH_SOURCE[0]}")/lib-entorno.sh"

source "$(dirname "${BASH_SOURCE[0]}")/lib-login.sh"

TW="$(token_web cliente116 Cliente.2026)"
TM="$(token_movil cliente116 Cliente.2026 dispositivo-demo-01)"
TA="$(token_cajero 4000000000000116 1234)"
if [ -z "$TW" ] || [ -z "$TM" ] || [ -z "$TA" ]; then echo "ERROR: no se pudo obtener alguno de los tres tokens del auth-server" >&2; exit 2; fi

# probar <token> <url> [cabeceras...]  -> imprime el codigo HTTP
probar() {
  local t="$1"; shift
  local u="$1"; shift
  curl_bff -o /dev/null -w '%{http_code}' "$u" -H "Authorization: Bearer $t" "$@"
}

W=$WEB/v1/cuentas/116
M=$MOVIL/v1/cuentas/116/resumen
A=$ATM/v1/cuentas/116/saldo-disponible
CAB_M=(-H 'X-Device-Id: dispositivo-demo-01')
CAB_A=()

echo "=================================================================="
echo " Matriz 3x3: que token sirve en que canal"
echo " Diagonal esperada 200; las otras seis celdas, 401"
echo "=================================================================="
printf '\n%-16s %10s %10s %10s\n' "token \\ canal" "web:8443" "movil:8444" "atm:8445"
printf '%s\n' "------------------------------------------------------------"
printf '%-16s %10s %10s %10s\n' "web"    "$(probar "$TW" "$W")" "$(probar "$TW" "$M" "${CAB_M[@]}")" "$(probar "$TW" "$A" "${CAB_A[@]+"${CAB_A[@]}"}")"
printf '%-16s %10s %10s %10s\n' "movil"  "$(probar "$TM" "$W")" "$(probar "$TM" "$M" "${CAB_M[@]}")" "$(probar "$TM" "$A" "${CAB_A[@]+"${CAB_A[@]}"}")"
printf '%-16s %10s %10s %10s\n' "cajero" "$(probar "$TA" "$W")" "$(probar "$TA" "$M" "${CAB_M[@]}")" "$(probar "$TA" "$A" "${CAB_A[@]+"${CAB_A[@]}"}")"
echo
echo "Cualquier 200 fuera de la diagonal es un fallo de aislamiento entre"
echo "canales, no un detalle de configuracion."
