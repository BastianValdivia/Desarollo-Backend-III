#!/usr/bin/env bash
# =====================================================================
# verificar-f2.sh: comprobaciones de la fase F2 (contenedores) contra el stack levantado
# con "docker compose up -d". Imprime PASS o FAIL con el dato real de cada una; el codigo
# de salida es 0 solo si todas pasan. La lista de no regresion del S5 esta aparte:
# scripts/verificar-no-regresion.sh.
#
# Que NO modifica: solo lee (docker ps/inspect/history/exec, curl). Lo unico que ejecuta
# ademas es "docker compose run --rm secretos-init" para demostrar que es idempotente, y
# esa ejecucion no cambia nada por definicion (lo comprueba con huellas antes y despues).
#
# Portabilidad: sin construcciones de bash 4 ni de GNU en el host (arreglos asociativos,
# sha256sum), para que corra con el bash 3.2 de macOS y en Git Bash. Requiere docker, curl y
# python3. Se probo en Linux; no se ha ejecutado en macOS ni en Windows.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
# Git Bash reescribe las rutas Unix de los argumentos ("/run/secrets/...", "volumen:/s:ro") y
# rompe docker exec y docker run -v; la variable lo desactiva solo para docker y no tiene
# efecto en macOS ni en Linux. Python no pasa por aqui: necesita la conversion de rutas.
docker() { MSYS_NO_PATHCONV=1 command docker "$@"; }
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
COMPOSE=(docker compose -f docker-compose.yaml)
CA_CRT="$RAIZ/certs/ca.crt"
VERSION=1.0.0
CONSTRUIDOS=(config-server eureka-server auth-server core-service bff-web bff-mobile bff-atm notificaciones-service auditoria-service)
LARGA_VIDA=("${CONSTRUIDOS[@]}")
TODAS_IMAGENES=(secretos-init "${CONSTRUIDOS[@]}")
BFFS=(bff-web bff-mobile bff-atm)
# case y no "declare -A": los arreglos asociativos son de bash 4 y macOS trae el 3.2.
puerto_de() { case "$1" in bff-web) echo 8443 ;; bff-mobile) echo 8444 ;; bff-atm) echo 8445 ;; esac; }
ruta_de() { case "$1" in bff-web) echo /api/web ;; bff-mobile) echo /api/mobile ;; bff-atm) echo /api/atm ;; esac; }
# sha256sum es de GNU; macOS trae shasum. Se usa el que exista y, si no hay ninguno, la
# huella queda vacia y la seccion 9 falla (ver abajo) en vez de comparar vacio con vacio.
sha256() { if command -v sha256sum > /dev/null 2>&1; then sha256sum "$@"; else shasum -a 256 "$@"; fi; }

FALLOS=0; TOTAL=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() { if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi; }
# Desde F3 core-service tiene dos replicas: "ps -q" devuelve dos ids. Las comprobaciones de F2 miran
# atributos del SERVICIO (imagen, redes, puertos, reinicio) que son iguales en ambas, asi que usan la
# primera. Las dos replicas se verifican en scripts/verificar-f3.sh.
cid() { "${COMPOSE[@]}" ps -a -q "$1" | head -n 1; }
imagen() { echo "bancoxyz/$1:$VERSION"; }

# "up -d" vuelve con los BFF aun arrancando: se espera a que todos esten healthy para que la
# seccion 1 mida el sistema y no la ventana de arranque. Si se agota el tiempo, la seccion 1 lo
# informa como FAIL con el estado real de cada servicio.
bash "$RAIZ/scripts/esperar-sano.sh" || true

echo "== 1. Todos los servicios sanos y la tarea unica terminada bien =="
for s in postgres "${LARGA_VIDA[@]}"; do
  igual "$s esta healthy" "running healthy" "$(docker inspect -f '{{.State.Status}} {{.State.Health.Status}}' "$(cid "$s")")"
done
igual "secretos-init termino con codigo 0" "exited 0" "$(docker inspect -f '{{.State.Status}} {{.State.ExitCode}}' "$(cid secretos-init)")"

echo "== 2. Cada servicio tiene su imagen bancoxyz/<servicio>:$VERSION =="
for s in "${TODAS_IMAGENES[@]}"; do
  igual "imagen $(imagen "$s") existe y la usa el contenedor" "$(imagen "$s")" "$(docker inspect -f '{{.Config.Image}}' "$(cid "$s")")"
done

echo "== 3. Usuario no root con UID fijo 10001 (docker inspect y proceso en ejecucion) =="
for s in "${CONSTRUIDOS[@]}"; do
  igual "$s: Config.User de la imagen" "10001:10001" "$(docker inspect -f '{{.Config.User}}' "$(imagen "$s")")"
  igual "$s: el proceso corre con uid" "10001" "$("${COMPOSE[@]}" exec -T "$s" id -u | tr -d '\r')"
done
igual "secretos-init: unico proceso como root (tiene que hacer chown), sin red" "root none" "$(docker inspect -f '{{if .Config.User}}{{.Config.User}}{{else}}root{{end}} {{.HostConfig.NetworkMode}}' "$(cid secretos-init)")"

echo "== 4. HEALTHCHECK, capas y construccion en dos etapas =="
for s in "${CONSTRUIDOS[@]}"; do
  hc="$(docker inspect -f '{{json .Config.Healthcheck.Test}}' "$(imagen "$s")")"
  case "$hc" in *wget*8081/actuator/health*) resultado PASS "$s: HEALTHCHECK de la imagen apunta al puerto de gestion" "$hc" ;; *) resultado FAIL "$s: HEALTHCHECK de la imagen" "$hc" ;; esac
  capas="$(docker history --no-trunc --format '{{.CreatedBy}}' "$(imagen "$s")" | grep -c 'COPY /build/extracted/')"
  igual "$s: cuatro capas del jar copiadas por separado (dependencies, loader, snapshot, application)" 4 "$capas"
  herr="$(docker run --rm --entrypoint sh "$(imagen "$s")" -c 'for t in mvn javac git; do command -v $t; done' 2>&1 | tr '\n' ' ')"
  igual "$s: la imagen final no trae Maven, javac ni git (solo el JRE)" "" "${herr% }"
  ep="$(docker inspect -f '{{json .Config.Entrypoint}}' "$(imagen "$s")")"
  case "$ep" in *MaxRAMPercentage*application.jar*) resultado PASS "$s: ENTRYPOINT java con memoria relativa al contenedor" "$ep" ;; *) resultado FAIL "$s: ENTRYPOINT" "$ep" ;; esac
done

echo "== 5. Red: el core sin puertos y solo en la red interna; BFF publicados; Eureka solo en loopback =="
igual "core-service: puertos publicados (PortBindings)" "{}" "$(docker inspect -f '{{json .HostConfig.PortBindings}}' "$(cid core-service)")"
igual "core-service: redes" "bancoxyz_interna" "$(docker inspect -f '{{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}' "$(cid core-service)" | tr -d ' ')"
igual "config-server: puertos publicados" "{}" "$(docker inspect -f '{{json .HostConfig.PortBindings}}' "$(cid config-server)")"
igual "la red interna es internal=true" "true" "$(docker network inspect bancoxyz_interna -f '{{.Internal}}')"
igual "la red borde NO es internal" "false" "$(docker network inspect bancoxyz_borde -f '{{.Internal}}')"
c="$(curl -s -m 4 -o /dev/null -w '%{http_code}' http://localhost:8080/internal/v1/cuentas/116)"
igual "core desde el host: http://localhost:8080 no responde" "000" "$c"
c="$(curl -s -m 4 -o /dev/null -w '%{http_code}' http://127.0.0.1:8081/actuator/health)"
igual "puerto de gestion 8081 desde el host: no responde" "000" "$c"
for s in "${BFFS[@]}"; do
  p="$(puerto_de "$s")"
  igual "$s publica $p/tcp" "[{\"HostIp\":\"\",\"HostPort\":\"$p\"}]" "$(docker inspect -f "{{json (index .HostConfig.PortBindings \"$p/tcp\")}}" "$(cid "$s")")"
done
igual "eureka-server publica 8761 solo en 127.0.0.1" '[{"HostIp":"127.0.0.1","HostPort":"8761"}]' "$(docker inspect -f '{{json (index .HostConfig.PortBindings "8761/tcp")}}' "$(cid eureka-server)")"
igual "eureka: dashboard responde en 127.0.0.1:8761" 200 "$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8761/)"

echo "== 6. HTTPS con la CA y sin ella =="
[ -f "$CA_CRT" ] && resultado PASS "certs/ca.crt existe en el host" "$(ls certs | tr '\n' ' ')" || resultado FAIL "certs/ca.crt existe en el host"
igual "certs/ contiene SOLO ca.crt" "ca.crt" "$(ls certs | tr '\n' ' ' | sed 's/ $//')"
for s in "${BFFS[@]}"; do
  p="$(puerto_de "$s")"; r="$(ruta_de "$s")"
  igual "$s con --cacert certs/ca.crt: llega a la aplicacion (401 sin token)" 401 "$(curl -s --cacert "$CA_CRT" -o /dev/null -w '%{http_code}' "https://localhost:$p$r/v1/cuentas/116")"
  curl -s -o /dev/null "https://localhost:$p$r/v1/cuentas/116"; rc=$?
  igual "$s sin la CA: curl rechaza el certificado (codigo de salida 60)" 60 "$rc"
  igual "$s con -k: conecta (solo para contrastar; -k desactiva la verificacion)" 401 "$(curl -sk -o /dev/null -w '%{http_code}' "https://localhost:$p$r/v1/cuentas/116")"
done

echo "== 7. Ningun secreto dentro de las imagenes =="
PATRON_HISTORIA='BEGIN [A-Z ]*PRIVATE KEY|\.p12|\.jks|key-store-password|cambiar-en-produccion|token-de-desarrollo|PASSWORD=|SECRET=|TOKEN='
for s in "${TODAS_IMAGENES[@]}"; do
  h="$(docker history --no-trunc --format '{{.CreatedBy}}' "$(imagen "$s")" | grep -ciE "$PATRON_HISTORIA")"
  igual "$s: docker history sin claves, contrasenas ni rutas de secretos" 0 "$h"
  # Archivos con nombre de keystore o clave, y cualquier archivo de texto con una clave PRIVADA
  # dentro. Los certificados PUBLICOS de las CA del sistema (base Alpine) no son secretos.
  f="$(docker run --rm --entrypoint sh "$(imagen "$s")" -c 'find / -xdev \( -name "*.p12" -o -name "*.pfx" -o -name "*.jks" -o -name "*.key" \) -not -path "/proc/*" 2>/dev/null; grep -rIls "PRIVATE KEY" / --exclude-dir=proc --exclude-dir=sys --exclude-dir=dev 2>/dev/null' | tr '\n' ' ')"
  igual "$s: sin keystores ni claves privadas en el sistema de archivos de la imagen" "" "${f% }"
done
for s in "${CONSTRUIDOS[@]}"; do
  # El jar sale por stdout y lo guarda bash: con "docker cp" habria que pasarle a docker una
  # ruta del host, que Git Bash dejaria sin convertir por MSYS_NO_PATHCONV. Si docker falla, el
  # archivo queda vacio, python3 no puede abrirlo, "n" queda vacio y la comprobacion falla.
  tmp="$(mktemp -d)"
  docker run --rm --entrypoint cat "$(imagen "$s")" /application/application.jar > "$tmp/application.jar" 2> /dev/null
  n="$(python3 -c 'import sys, zipfile
nombres = zipfile.ZipFile(sys.argv[1]).namelist()
print(len([n for n in nombres if any(x in n for x in ("secrets/", ".p12", ".pem", ".key", ".crt", ".jks"))]))' "$tmp/application.jar" 2> /dev/null)"
  rm -rf "$tmp"
  igual "$s: application.jar sin carpeta secrets ni claves" 0 "$n"
done
for s in "${LARGA_VIDA[@]}"; do
  e="$(docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' "$(cid "$s")" | grep -ciE 'pass|secret|token|key')"
  igual "$s: variables de entorno del contenedor sin contrasenas ni claves" 0 "$e"
done

echo "== 8. Volumenes de secretos: uno por servicio, dueno 10001, permisos minimos =="
inspeccionar() {  # inspeccionar <volumen> -> "uid:gid modo ruta" de todo su contenido
  docker run --rm --entrypoint sh -v "$1:/s:ro" "$(imagen secretos-init)" -c 'find /s -mindepth 1 -exec stat -c "%u:%g %a %n" {} +' | sort -k3
}
for s in bff-web bff-mobile bff-atm core-service; do
  salida="$(inspeccionar "bancoxyz_secretos-$s")"
  mal="$(echo "$salida" | awk '$1 != "10001:10001" || ($2 != "400" && $2 != "500")' | wc -l | tr -d ' ')"
  igual "bancoxyz_secretos-$s: todo con dueno 10001:10001 y modo 400/500" 0 "$mal"
done
igual "bff-web monta SOLO su volumen (no ve claves de otros)" "bancoxyz_secretos-bff-web" "$(docker inspect -f '{{range .Mounts}}{{.Name}} {{end}}' "$(cid bff-web)" | tr -d ' ')"
igual "core-service monta SOLO su volumen" "bancoxyz_secretos-core-service" "$(docker inspect -f '{{range .Mounts}}{{.Name}} {{end}}' "$(cid core-service)" | tr -d ' ')"
igual "el volumen de la CA solo lo monta secretos-init" "bancoxyz-secretos-init-1" "$(docker ps -a --filter volume=bancoxyz_secretos-ca --format '{{.Names}}' | tr '\n' ' ' | sed 's/ $//')"
igual "bff-web lee su keystore desde el volumen" "10001 400" "$("${COMPOSE[@]}" exec -T bff-web stat -c '%u %a' /run/secrets/tls/bff-web.p12 | tr -d '\r')"
igual "volumen de secretos montado de solo lectura" "false" "$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/run/secrets"}}{{.RW}}{{end}}{{end}}' "$(cid bff-web)")"

echo "== 9. secretos-init es idempotente =="
huella() { docker run --rm --entrypoint sh -v bancoxyz_secretos-ca:/ca:ro -v bancoxyz_secretos-bff-web:/w:ro -v bancoxyz_secretos-bff-mobile:/m:ro -v bancoxyz_secretos-bff-atm:/a:ro -v bancoxyz_secretos-core-service:/c:ro -v bancoxyz_secretos-postgres:/p:ro "$(imagen secretos-init)" -c 'find /ca /w /m /a /c /p -type f -exec sha256sum {} + | sort -k2 | sha256sum'; }
ANTES="$(huella)"; CA_ANTES="$(sha256 "$CA_CRT" | cut -d' ' -f1)"
# Una huella vacia (docker o sha256sum/shasum fallaron) haria pasar la comparacion sin comprobar nada.
[ -n "$ANTES" ] && [ -n "$CA_ANTES" ] && resultado PASS "huellas de referencia calculadas (no vacias)" "${ANTES:0:16}... ${CA_ANTES:0:16}..." || resultado FAIL "huellas de referencia calculadas (no vacias)" "volumenes='${ANTES}' ca='${CA_ANTES}'"
SALIDA="$("${COMPOSE[@]}" run --rm secretos-init 2>&1)"
DESPUES="$(huella)"; CA_DESPUES="$(sha256 "$CA_CRT" | cut -d' ' -f1)"
igual "segunda ejecucion: huella de todos los volumenes sin cambios" "$ANTES" "$DESPUES"
igual "segunda ejecucion: certs/ca.crt sin cambios" "$CA_ANTES" "$CA_DESPUES"
conservados="$(echo "$SALIDA" | grep -c 'se conserva')"; generados="$(echo "$SALIDA" | grep -cE 'generando|firmado por la CA|claves de firma de tokens|truststore con la CA|credencial de servicio -> |generada')"
igual "segunda ejecucion: todo 'se conserva' y nada generado" "conservados>0 generados=0" "conservados$([ "$conservados" -gt 0 ] && echo '>0' || echo '=0') generados=$generados"

echo "== 10. Eureka registra los cuatro servicios por su IP de la red interna =="
IPS="$(curl -s -H 'Accept: application/json' http://127.0.0.1:8761/eureka/apps | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(' '.join(sorted(a['name']+'='+i['ipAddr']+':'+i['status'] for a in d['applications']['application'] for i in a['instance'])))")"
for a in BFF-ATM BFF-MOBILE BFF-WEB CORE-SERVICE; do
  case "$IPS" in *"$a=172.31.250."*":UP"*) resultado PASS "$a registrado UP con IP de la red interna" "$(echo "$IPS" | tr ' ' '\n' | grep "^$a=")" ;; *) resultado FAIL "$a registrado UP con IP de la red interna" "$IPS" ;; esac
done

echo "== 11. Politica de reinicio y archivo de compose =="
for s in "${LARGA_VIDA[@]}"; do
  igual "$s: restart" "unless-stopped" "$(docker inspect -f '{{.HostConfig.RestartPolicy.Name}}' "$(cid "$s")")"
done
igual "docker compose config sin advertencias" "" "$("${COMPOSE[@]}" config -q 2>&1)"
igual "docker-compose.yaml sin la clave 'version'" 0 "$(grep -c '^version:' docker-compose.yaml)"
igual "nombre del proyecto" "bancoxyz" "$("${COMPOSE[@]}" config --format json | python3 -c 'import sys,json; print(json.load(sys.stdin)["name"])')"

echo
if [ "$FALLOS" -eq 0 ]; then echo "RESULTADO: $TOTAL comprobaciones, todo PASS"; else echo "RESULTADO: $FALLOS de $TOTAL comprobaciones FAIL"; exit 1; fi
