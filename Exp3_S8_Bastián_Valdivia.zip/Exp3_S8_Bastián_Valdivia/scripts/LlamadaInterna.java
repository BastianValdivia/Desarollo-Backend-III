import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;

/**
 * Hace UNA llamada HTTP desde dentro de la red interna de Docker e imprime su estado, la cabecera
 * {@code WWW-Authenticate} (si la hay) y el cuerpo. Sirve para mostrar, con la verificacion TLS real, lo que
 * ven los servicios entre si: pedir un token al auth-server por {@code https://auth-server:9000} y llamar al
 * core por {@code http://core-service:8080}.
 *
 * <h2>Que lugar ocupa esto en la arquitectura</h2>
 * Ninguno: es una herramienta de evidencia, como {@code FirmarTokenDePrueba.java}. Existe porque la unica
 * herramienta HTTP de las imagenes del proyecto es el {@code wget} de BusyBox, que no imprime el cuerpo de una
 * respuesta 4xx, justo lo que hay que ver en una matriz de seguridad. Corre en un contenedor efimero con la
 * imagen {@code secretos-init} (que trae el JDK 21), unido a la red {@code interna} y con el truststore de la CA
 * interna montado en solo lectura (ver {@code llamada_interna} en {@code lib-entorno.sh}): confia en esa CA y en
 * nada mas, igual que los BFF.
 *
 * <h2>Uso</h2>
 * <pre>
 * java LlamadaInterna.java GET|POST &lt;url&gt; [--basic usuario:clave] [--bearer token] [--form cuerpo-urlencoded]
 *                          [--json cuerpo] [--cabecera "Nombre: valor"]...
 * </pre>
 * Salida: la primera linea es {@code HTTP <codigo>}; despues, si existe, {@code WWW-Authenticate: ...}; una
 * linea vacia y el cuerpo.
 */
public final class LlamadaInterna {

    private LlamadaInterna() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.err.println("Uso: java LlamadaInterna.java GET|POST <url> [--basic u:c] [--bearer t] "
                    + "[--form cuerpo] [--json cuerpo] [--cabecera 'N: v']");
            System.exit(2);
        }
        String metodo = args[0];
        HttpRequest.Builder peticion = HttpRequest.newBuilder(URI.create(args[1])).timeout(Duration.ofSeconds(15));
        String cuerpo = null;
        for (int i = 2; i < args.length; i += 2) {
            String valor = args[i + 1];
            switch (args[i]) {
                case "--basic" -> peticion.header("Authorization", "Basic "
                        + Base64.getEncoder().encodeToString(valor.getBytes(StandardCharsets.UTF_8)));
                case "--bearer" -> peticion.header("Authorization", "Bearer " + valor);
                case "--form" -> {
                    peticion.header("Content-Type", "application/x-www-form-urlencoded");
                    cuerpo = valor;
                }
                case "--json" -> {
                    peticion.header("Content-Type", "application/json");
                    cuerpo = valor;
                }
                case "--cabecera" -> {
                    int dosPuntos = valor.indexOf(':');
                    peticion.header(valor.substring(0, dosPuntos).trim(), valor.substring(dosPuntos + 1).trim());
                }
                default -> throw new IllegalArgumentException("opcion desconocida: " + args[i]);
            }
        }
        peticion.method(metodo, cuerpo == null ? BodyPublishers.noBody() : BodyPublishers.ofString(cuerpo));

        HttpResponse<String> respuesta = HttpClient.newHttpClient()
                .send(peticion.build(), HttpResponse.BodyHandlers.ofString());
        System.out.println("HTTP " + respuesta.statusCode());
        respuesta.headers().firstValue("WWW-Authenticate")
                .ifPresent(v -> System.out.println("WWW-Authenticate: " + v));
        System.out.println();
        System.out.println(respuesta.body());
    }
}
