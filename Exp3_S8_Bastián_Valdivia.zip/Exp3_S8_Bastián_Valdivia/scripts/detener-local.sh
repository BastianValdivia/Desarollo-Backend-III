#!/usr/bin/env bash
# =====================================================================
# detener-local.sh: detiene los servicios lanzados con levantar-local.sh.
# =====================================================================
# Lee los PID de run/*.pid y envia SIGTERM (cierre ordenado: cada servicio se
# da de baja de Eureka antes de salir). Los BFF primero y la plataforma al
# final, al reves del arranque.
# =====================================================================
set -u
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"

for nombre in bff-atm bff-mobile bff-web core-service auth-server eureka-server config-server; do
  pidfile="run/$nombre.pid"
  [ -f "$pidfile" ] || continue
  pid="$(cat "$pidfile")"
  if kill -0 "$pid" 2>/dev/null; then
    kill "$pid"
    for _ in $(seq 1 20); do
      kill -0 "$pid" 2>/dev/null || break
      sleep 1
    done
    if kill -0 "$pid" 2>/dev/null; then
      echo "  $nombre no cerro en 20 s, se fuerza"
      kill -9 "$pid"
    else
      echo "  $nombre detenido"
    fi
  else
    echo "  $nombre ya no estaba en marcha"
  fi
  rm -f "$pidfile"
done

# Los secretos de cliente OAuth2 de esta ejecucion (los genero levantar-local.sh): una ejecucion nueva
# genera otros.
rm -f run/secretos-locales.env

# La base desechable que levanto levantar-local.sh (si la hubo): se elimina, asi la proxima ejecucion
# parte de la carga inicial. Una base PostgreSQL propia del usuario no se toca.
if command -v docker > /dev/null 2>&1 && docker inspect bancoxyz-postgres-local > /dev/null 2>&1; then
  docker rm -f bancoxyz-postgres-local > /dev/null 2>&1 && echo "  base PostgreSQL desechable eliminada"
fi
