#!/usr/bin/env bash
# =====================================================================
# login-cajero.sh: inicio de sesion del CAJERO con el grant de extension tarjeta y PIN, hecho con curl.
# =====================================================================
# Uso:  scripts/login-cajero.sh [tarjeta] [pin] [--terminal ID] [--secreto S] [--token]
#
#   Sin argumentos usa la tarjeta 4000000000000116 con su PIN 1234 desde el terminal atm-scl-001.
#   Tarjetas de demostracion (las del S5):
#     4000000000000116 / 1234  cuenta 116, saldo y retiro      4000000000000106 / 5678  cuenta 106, saldo y retiro
#     4000000000000105 / 4321  cuenta 105, SOLO saldo          4000000000000150 / 9999  cuenta 150, SOLO saldo
#   --terminal  otro terminal (por ejemplo atm-scl-999) para ver como el servidor rechaza a uno no registrado.
#   --secreto   secreto del terminal; por defecto se lee del auth-server (en un cajero real viviria en su equipo).
#   --token     imprime SOLO el token de acceso (para usarlo en $(...)).
#
# La peticion es un POST a /oauth2/token con el secreto del terminal en la cabecera Authorization: Basic y,
# en el cuerpo, grant_type=urn:bancoxyz:params:oauth:grant-type:tarjeta-pin, numero_tarjeta y pin. El tercer
# PIN errado seguido bloquea la tarjeta (error_description=pin_bloqueado) durante 15 minutos.
# Una vez con el token:
#   curl --cacert certs/ca.crt -H "Authorization: Bearer $TOKEN" https://localhost:8445/api/atm/v1/cuentas/116/saldo-disponible
# =====================================================================
set -uo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib-entorno.sh
. "$DIR/lib-entorno.sh"
# shellcheck source=lib-login.sh
. "$DIR/lib-login.sh"

SOLO_TOKEN=0; TERMINAL_ID="$TERMINAL_POR_DEFECTO"; SECRETO=""; POS=()
while [ $# -gt 0 ]; do
  case "$1" in
    --token)    SOLO_TOKEN=1 ;;
    --terminal) shift; TERMINAL_ID="${1:?falta el id del terminal}" ;;
    --secreto)  shift; SECRETO="${1:?falta el secreto}" ;;
    *)          POS+=("$1") ;;
  esac
  shift
done
TARJETA="${POS[0]:-4000000000000116}"
PIN="${POS[1]:-1234}"

if [ "$SOLO_TOKEN" = 1 ]; then
  token_cajero "$TARJETA" "$PIN" "$TERMINAL_ID" "$SECRETO"
  exit $?
fi

echo "== Login del cajero: terminal $TERMINAL_ID, tarjeta ****${TARJETA: -4}, auth-server $AUTH_URL =="
echo "POST $AUTH_URL/oauth2/token   (Authorization: Basic <terminal:secreto>)"
echo "     grant_type=$GRANT_TARJETA_PIN"
echo "     numero_tarjeta=$TARJETA  pin=****"
LOGIN_CURL_EXTRA=(-w $'\n%{http_code}')
SALIDA="$(login_cajero_json "$TARJETA" "$PIN" "$TERMINAL_ID" "$SECRETO")"
ESTADO="${SALIDA##*$'\n'}"
JSON="${SALIDA%$'\n'*}"
echo "HTTP $ESTADO"
TOKEN="$(printf '%s' "$JSON" | access_token_de)"
if [ -z "$TOKEN" ]; then
  echo "$JSON"
  exit 1
fi
echo
echo "Respuesta del endpoint de tokens (el valor del token se abrevia):"
printf '%s' "$JSON" | python3 -c 'import sys,json; d=json.load(sys.stdin); d["access_token"]=d["access_token"][:24]+"..."; print(json.dumps(d))'
echo
echo "Claims del token (se leen sin clave porque un JWT esta firmado, no cifrado):"
python3 "$DIR/ver-token.py" "$TOKEN"
