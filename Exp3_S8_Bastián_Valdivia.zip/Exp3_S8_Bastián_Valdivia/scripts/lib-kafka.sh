#!/usr/bin/env bash
# =====================================================================
# lib-kafka.sh: utilidades de los guiones de la fase F7 (mensajeria con Kafka). Se importa con "source" DESPUES de
# lib-entorno.sh (de el salen COMPOSE, docker y sql_postgres). Solo ENTORNO=docker: Kafka vive en el compose.
#
# Define:
#   kafka_cli <herramienta.sh> <args...>   ejecuta una herramienta de /opt/kafka/bin dentro del contenedor kafka
#   kafka_consola <topico> [max-mensajes]  lee un topico desde el principio con sus claves y particiones
#   describir_grupo <grupo>                salida cruda de kafka-consumer-groups --describe
#   lag_del_grupo <grupo> <filtro-topico>  suma del LAG de las particiones de los topicos que cumplen el filtro (egrep)
#   particiones_por_cliente <grupo> <filtro>  "cliente cuantas": cuantas particiones tiene cada consumidor del grupo
#   producir <topico>                      envia a un topico las lineas "clave|mensaje" que lleguen por stdin
#   clave_para_particion <n> <particiones> <desde>   una clave de texto que el particionador por defecto de Kafka
#                                          (murmur2) lleva a la particion n
#   esperar_hasta <segundos> <comando...>  repite el comando cada segundo hasta que salga con 0; 0 si lo logro
#   outbox_pendientes                      eventos del outbox del core que aun no salieron
#   esperar_kafka_sano                     espera a que el contenedor kafka este healthy
#
# Portabilidad: bash 3.2 (macOS) y Git Bash, sin arreglos asociativos; requiere docker y python3.
# =====================================================================

kafka_cli() {
  local herramienta="$1"; shift
  "${COMPOSE[@]}" exec -T kafka "/opt/kafka/bin/$herramienta" "$@"
}

kafka_consola() {
  local topico="$1" maximo="${2:-0}"
  local limite=()
  [ "$maximo" -gt 0 ] && limite=(--max-messages "$maximo")
  kafka_cli kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic "$topico" --from-beginning \
    --timeout-ms 8000 --property print.key=true --property print.partition=true \
    ${limite[@]+"${limite[@]}"} 2> /dev/null
}

describir_grupo() {
  kafka_cli kafka-consumer-groups.sh --bootstrap-server localhost:9092 --describe --group "$1" 2> /dev/null | tr -d '\r'
}

# Columnas de --describe: GROUP TOPIC PARTITION CURRENT-OFFSET LOG-END-OFFSET LAG CONSUMER-ID HOST CLIENT-ID
lag_del_grupo() {
  describir_grupo "$1" | awk -v filtro="$2" '$2 ~ filtro && $6 ~ /^[0-9]+$/ { suma += $6; n++ } END { if (n == 0) print "sin-datos"; else print suma + 0 }'
}

particiones_por_cliente() {
  describir_grupo "$1" | awk -v filtro="$2" '$2 ~ filtro && $9 != "-" { c[$9]++ } END { for (k in c) print k, c[k] }' | sort
}

producir() {
  kafka_cli kafka-console-producer.sh --bootstrap-server localhost:9092 --topic "$1" \
    --property parse.key=true --property "key.separator=|" 2> /dev/null
}

# murmur2 de Kafka (el del particionador por defecto), para elegir claves con una particion conocida.
clave_para_particion() {
  python3 - "$1" "$2" "$3" << 'PY'
import sys
def murmur2(data):
    length = len(data); seed = 0x9747b28c; m = 0x5bd1e995; r = 24
    h = (seed ^ length) & 0xffffffff
    length4 = length // 4
    for i in range(length4):
        i4 = i * 4
        k = (data[i4] & 0xff) | ((data[i4+1] & 0xff) << 8) | ((data[i4+2] & 0xff) << 16) | ((data[i4+3] & 0xff) << 24)
        k = (k * m) & 0xffffffff
        k ^= (k & 0xffffffff) >> r
        k = (k * m) & 0xffffffff
        h = (h * m) & 0xffffffff
        h ^= k
    rest = length % 4
    off = length & ~3
    if rest == 3: h ^= (data[off+2] & 0xff) << 16
    if rest >= 2: h ^= (data[off+1] & 0xff) << 8
    if rest >= 1:
        h ^= (data[off] & 0xff)
        h = (h * m) & 0xffffffff
    h ^= (h & 0xffffffff) >> 13
    h = (h * m) & 0xffffffff
    h ^= (h & 0xffffffff) >> 15
    return h & 0xffffffff
destino, particiones, desde = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
n = desde
while True:
    clave = str(n)
    if ((murmur2(clave.encode()) & 0x7fffffff) % particiones) == destino:
        print(clave); break
    n += 1
PY
}

esperar_hasta() {
  local limite="$1"; shift
  local i=0
  while [ "$i" -lt "$limite" ]; do
    if "$@" > /dev/null 2>&1; then return 0; fi
    sleep 1
    i=$((i + 1))
  done
  return 1
}

outbox_pendientes() {
  sql_postgres core "SELECT count(*) FROM outbox WHERE publicado IS NULL" 2> /dev/null | tr -d '[:space:]'
}

kafka_sano() {
  [ "$(docker inspect -f '{{.State.Health.Status}}' "$("${COMPOSE[@]}" ps -q kafka)" 2> /dev/null)" = healthy ]
}

esperar_kafka_sano() { esperar_hasta "${1:-120}" kafka_sano; }
