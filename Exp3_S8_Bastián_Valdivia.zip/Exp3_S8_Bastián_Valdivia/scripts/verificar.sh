#!/usr/bin/env bash
# =====================================================================
# verificar.sh: UN comando que levanta el sistema, ejecuta todas las comprobaciones y dice PASS o FAIL por criterio
# de la pauta. Es el camino del evaluador.
# =====================================================================
#   scripts/verificar.sh                   levanta con "docker compose up -d --build --wait" (construye las imagenes) y
#                                          verifica TODO, incluidos los escenarios de caos (unos 33 minutos con las imagenes
#                                          ya construidas, medidos en 4 CPU; la construccion depende de la red)
#   scripts/verificar.sh --rapido          sin caos ni medicion de escalado (unos 11 minutos). Termina con codigo 0 y la
#                                          frase "PASS PARCIAL": pasa lo que ejecuto, pero NO verifica el criterio 4
#   scripts/verificar.sh --sin-construir   usa las imagenes que ya existen (docker compose build, o el guion de
#                                          construccion del entorno de desarrollo) en lugar de construir
#
# Otras opciones:
#   --frio             antes de levantar: "docker compose down -v" (volumenes de secretos y datos nuevos: arranque en frio)
#   --sin-caos         omite scripts/caos/ (criterio 4: los escenarios de falla inyectada)
#   --sin-escalado     omite scripts/medir-escalado.sh (criterio 5: tabla de escalado con 1, 3 y 4 consumidores)
#   --con-pruebas      ejecuta antes ./mvnw -B verify (necesita JDK 21 y Docker; el contenedor de PostgreSQL y el de Kafka
#                      de las pruebas los levanta Testcontainers; unos 4,5 minutos mas)
#   --solo C1,C3       solo los criterios indicados (C1 a C6 y RN, la no regresion del S5); el arranque siempre se hace
#   --bajar            al terminar, "docker compose down" (sin -v: conserva datos y secretos)
#   --detalle          muestra en pantalla la salida de cada comprobacion (por defecto solo el resumen)
#   --salidas DIR      carpeta de las evidencias (por defecto evidencias/salidas)
#
# QUE HACE. Cada paso ejecuta un guion del proyecto y escribe evidencias/salidas/NN-<nombre>.txt con el comando, la
# fecha, el entorno, la salida LITERAL del guion (sin la linea "Picked up JAVA_TOOL_OPTIONS" que algunas JVM imprimen)
# y su codigo de salida. Al final imprime una tabla PASS o FAIL por criterio de la pauta y termina con codigo 0 solo si
# todo paso. evidencias/INDICE.md dice que demuestra cada archivo.
#
#   C1 OAuth2.0           verificar-f4 (servidor de recursos), verificar-f5 (login), matriz 3x3
#   C2 Imagenes Docker    verificar-f2, verificar-f8 (no root, sin secretos, versiones, limites, multiarquitectura),
#                         tabla medida de tamano, arranque y memoria
#   C3 docker-compose     verificar-f1 (Config Server, Eureka, Actuator), verificar-f3 (PostgreSQL y dos replicas),
#                         reinicio automatico
#   C4 Resilience4j       scripts/caos/: core caido, core lento, rafaga contra el mamparo, replica que muere,
#                         auth-server caido
#   C5 Kafka              verificar-f7 (eventos, DLT, auditoria, panel) y escalado con 1, 3 y 4 consumidores
#   C6 Entrega            evidencia de arranque, salud y resultado de CADA microservicio, y verificar-entrega
#   RN No regresion S5    verificar-no-regresion (la lista 3.1 del plan)
#
# MODIFICA el estado de demostracion (retiros de las cuentas 116 y 106, reinicios de servicios, topicos de prueba) y lo
# restablece al final de cada paso con scripts/restablecer-demo.sh. Los escenarios de caos detienen servicios y los
# vuelven a levantar. Edita y restaura archivos de config-repo/: ejecutalo en un clon, no mientras editas esos archivos.
#
# Prerrequisitos: Docker con Compose v2.20 o superior (y buildx), bash, curl y python3. Para --con-pruebas, ademas JDK 21.
# Las herramientas Java de prueba corren dentro de un contenedor (imagen bancoxyz/secretos-init). Portabilidad: bash 3.2
# (macOS) y Git Bash; no se ejecuto en macOS ni en Windows (ver README, limitaciones).
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
# Git Bash reescribe las rutas Unix de los argumentos de docker; la variable lo evita y no tiene efecto en macOS ni Linux.
docker() { MSYS_NO_PATHCONV=1 command docker "$@"; }
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
COMPOSE=(docker compose -f docker-compose.yaml)

CONSTRUIR=1; FRIO=0; CAOS=1; ESCALADO=1; PRUEBAS=0; SOLO=""; BAJAR=0; DETALLE=0; SALIDAS="evidencias/salidas"
while [ $# -gt 0 ]; do
  case "$1" in
    --sin-construir) CONSTRUIR=0 ;;
    --rapido) CAOS=0; ESCALADO=0 ;;
    --frio) FRIO=1 ;;
    --sin-caos) CAOS=0 ;;
    --sin-escalado) ESCALADO=0 ;;
    --con-pruebas) PRUEBAS=1 ;;
    --solo) shift; SOLO="${1:?falta la lista de criterios, por ejemplo C1,C3}" ;;
    --bajar) BAJAR=1 ;;
    --detalle) DETALLE=1 ;;
    --salidas) shift; SALIDAS="${1:?falta la carpeta}" ;;
    -h|--help) grep -E '^#' "$0" | sed -n '2,62p' | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Opcion desconocida: $1 (ver scripts/verificar.sh --help)" >&2; exit 2 ;;
  esac
  shift
done

# ---------------------------------------------------------------------
# Resultados: arreglos paralelos (bash 3.2 no tiene arreglos asociativos)
# ---------------------------------------------------------------------
P_ARCHIVO=(); P_CRIT=(); P_TITULO=(); P_RC=(); P_PASS=(); P_FAIL=(); P_SEG=()
INICIO_TOTAL=$SECONDS

quiero() {  # quiero <criterio>: 0 si el criterio esta entre los pedidos con --solo (o no se pidio ninguno)
  [ -z "$SOLO" ] && return 0
  case ",$SOLO," in *",$1,"*) return 0 ;; *) return 1 ;; esac
}

ENTORNO_TEXTO="$(printf 'docker %s | compose %s | %s | %s CPU, %s MiB de memoria' \
  "$(docker version --format '{{.Server.Version}}' 2> /dev/null)" "$(docker compose version --short 2> /dev/null)" \
  "$(uname -sr)" "$(docker info --format '{{.NCPU}}' 2> /dev/null)" "$(docker info --format '{{.MemTotal}}' 2> /dev/null | awk '{printf "%d", $1/1048576}')")"

mkdir -p "$SALIDAS"

# ejecutar <archivo> <criterio> <titulo> <comando mostrado> <comando...>
#   Ejecuta el comando, guarda su salida literal en $SALIDAS/<archivo>.txt y registra el resultado del paso.
ejecutar() {
  local archivo="$1" crit="$2" titulo="$3" mostrado="$4"; shift 4
  local ruta="$SALIDAS/$archivo.txt" inicio=$SECONDS rc npass nfail
  printf '>> [%s] %-34s %s\n' "$crit" "$archivo" "$titulo"
  {
    echo "# Evidencia: $titulo"
    echo "# Criterio de la pauta: $crit"
    echo "# Comando: $mostrado"
    echo "# Fecha (UTC): $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    echo "# Entorno: $ENTORNO_TEXTO"
    echo "# ----------------------------------------------------------------------"
  } > "$ruta"
  if [ "$DETALLE" = 1 ]; then
    "$@" 2>&1 | grep -v 'Picked up JAVA_TOOL_OPTIONS' | tee -a "$ruta"
  else
    "$@" 2>&1 | grep -v 'Picked up JAVA_TOOL_OPTIONS' >> "$ruta"
  fi
  rc=${PIPESTATUS[0]}
  echo "# ----------------------------------------------------------------------" >> "$ruta"
  echo "# Codigo de salida: $rc   (duracion: $((SECONDS - inicio)) s)" >> "$ruta"
  npass="$(grep -cE '^ +PASS ' "$ruta")"
  nfail="$(grep -cE '^ +FAIL ' "$ruta")"
  P_ARCHIVO+=("$archivo"); P_CRIT+=("$crit"); P_TITULO+=("$titulo"); P_RC+=("$rc"); P_PASS+=("$npass"); P_FAIL+=("$nfail"); P_SEG+=("$((SECONDS - inicio))")
  if [ "$rc" = 0 ] && [ "$nfail" = 0 ]; then
    if [ "$npass" = 0 ]; then printf '   PASS  (codigo de salida 0, %s s)\n' "$((SECONDS - inicio))"
    else printf '   PASS  (%s comprobaciones, %s s)\n' "$npass" "$((SECONDS - inicio))"; fi
  else
    printf '   FAIL  (codigo de salida %s, %s PASS, %s FAIL, %s s)  ->  %s\n' "$rc" "$npass" "$nfail" "$((SECONDS - inicio))" "$ruta"
    grep -E '^ +FAIL ' "$ruta" | head -n 10 | sed 's/^/        /'
    [ "$nfail" = 0 ] && tail -n 8 "$ruta" | grep -v '^#' | sed 's/^/        /'
  fi
  return 0
}

# Despues de cada paso que consume saldo: vuelve a los saldos de la carga (no toca nada mas).
restablecer() { bash scripts/restablecer-demo.sh > /dev/null 2>&1 || true; }
esperar_todo() { bash scripts/esperar-sano.sh 420 > /dev/null 2>&1 || true; }

# ---------------------------------------------------------------------
echo "================================================================"
echo " Banco XYZ, Exp3 S8: verificacion integral (scripts/verificar.sh)"
echo "================================================================"
echo " Entorno: $ENTORNO_TEXTO"
echo " Opciones: construir=$CONSTRUIR frio=$FRIO caos=$CAOS escalado=$ESCALADO pruebas=$PRUEBAS solo=${SOLO:-todo}"
echo " Evidencias: $SALIDAS/"
echo

# ---------------------------------------------------------------------
# Prerrequisitos
# ---------------------------------------------------------------------
falta=""
for c in docker curl python3; do command -v "$c" > /dev/null 2>&1 || falta="$falta $c"; done
if [ -n "$falta" ]; then echo "ERROR: faltan herramientas en el equipo:$falta" >&2; exit 2; fi
if ! docker info > /dev/null 2>&1; then echo "ERROR: el demonio de Docker no responde (Docker Desktop debe estar en marcha)." >&2; exit 2; fi
VER_COMPOSE="$(docker compose version --short 2> /dev/null | sed 's/^v//')"
MAYOR="${VER_COMPOSE%%.*}"; RESTO="${VER_COMPOSE#*.}"; MENOR="${RESTO%%.*}"
if [ -z "$VER_COMPOSE" ] || [ "$MAYOR" -lt 2 ] 2> /dev/null || { [ "$MAYOR" = 2 ] && [ "$MENOR" -lt 20 ]; } 2> /dev/null; then
  echo "ERROR: se necesita Docker Compose v2.20 o superior (hay: '${VER_COMPOSE:-ninguno}'). Actualiza Docker Desktop." >&2
  exit 2
fi
if [ "$PRUEBAS" = 1 ] && ! command -v java > /dev/null 2>&1; then echo "ERROR: --con-pruebas necesita JDK 21 en el PATH." >&2; exit 2; fi

# ---------------------------------------------------------------------
# Arranque (camino del evaluador)
# ---------------------------------------------------------------------
if [ "$PRUEBAS" = 1 ]; then
  # La salida completa de Maven pasa de 10 000 lineas (los registros de las aplicaciones bajo prueba, con sus ERROR
  # esperados cuando una prueba provoca una falla a proposito): la evidencia conserva lo que prueba el resultado, que es
  # el total de cada modulo, el resumen del reactor y el veredicto, y suma el total.
  pruebas_unitarias() {
    local log rc
    log="$(mktemp)"
    ./mvnw -B verify > "$log" 2>&1
    rc=$?
    grep -E '^\[INFO\] Building [a-z-]+ [0-9.]+ +\[[0-9]+/[0-9]+\]|^\[INFO\] Tests run: [0-9]+, Failures: [0-9]+, Errors: [0-9]+, Skipped: [0-9]+$|^\[INFO\] Reactor Summary|^\[INFO\] [a-z-]+ \.+ (SUCCESS|FAILURE|SKIPPED)|^\[INFO\] BUILD|^\[INFO\] Total time' "$log" | grep -v 'Picked up'
    echo
    awk '/^\[INFO\] Tests run: [0-9]+, Failures: [0-9]+, Errors: [0-9]+, Skipped: [0-9]+$/ {
           gsub(/[^0-9 ]/, " "); t += $1; f += $2; e += $3; o += $4 }
         END { printf "TOTAL %d %d %d %d\n", t, f, e, o }' "$log" | {
      read -r _ total fallas errores omitidas
      if [ "$rc" = 0 ] && [ "${total:-0}" -gt 0 ] && [ "$fallas" = 0 ] && [ "$errores" = 0 ] && [ "$omitidas" = 0 ]; then
        echo "  PASS $total pruebas ejecutadas: $fallas fallas, $errores errores, $omitidas omitidas  (ninguna se salta ni se deshabilita)"
      else
        echo "  FAIL pruebas: total=$total fallas=$fallas errores=$errores omitidas=$omitidas codigo de Maven=$rc"
        grep -E '^\[ERROR\]' "$log" | head -n 40
      fi
    }
    rm -f "$log"
    return "$rc"
  }
  ejecutar 00-pruebas-unitarias C6 "Pruebas unitarias y de integracion (Maven, Testcontainers con PostgreSQL y Kafka reales)" "./mvnw -B verify" pruebas_unitarias
fi

arrancar() {
  if [ "$FRIO" = 1 ]; then
    echo "\$ docker compose down -v        (arranque en frio: volumenes de secretos y de datos nuevos)"
    "${COMPOSE[@]}" down -v 2>&1
    rm -rf certs
  fi
  local t0=$SECONDS rc
  if [ "$CONSTRUIR" = 1 ]; then
    echo "\$ docker compose up -d --build --wait"
    "${COMPOSE[@]}" up -d --build --wait 2>&1
  else
    echo "\$ docker compose up -d --wait        (con las imagenes ya construidas)"
    "${COMPOSE[@]}" up -d --wait 2>&1
  fi
  rc=$?
  echo
  echo "# 'up' tardo $((SECONDS - t0)) s y devolvio $rc"
  # Compose v2 antiguos no esperan la tarea unica terminada: el guion de espera cierra ese hueco.
  bash scripts/esperar-sano.sh 420 2>&1
  [ "$rc" = 0 ] && rc=$?
  echo
  echo "\$ docker compose ps -a"
  "${COMPOSE[@]}" ps -a
  return "$rc"
}
ejecutar 01-arranque C3 "Arranque del sistema completo con un solo comando" \
  "docker compose up -d $([ "$CONSTRUIR" = 1 ] && echo --build) --wait" arrancar
if [ ! -f certs/ca.crt ]; then echo "ERROR: el arranque no dejo certs/ca.crt; no se puede seguir." >&2; exit 1; fi
# A partir de aqui los guiones usan ENTORNO=docker (el valor por defecto) y esperan al stack por su cuenta.
restablecer

# ---------------------------------------------------------------------
# C2: imagenes Docker
# ---------------------------------------------------------------------
if quiero C2; then
  ejecutar 10-imagenes-f2 C2 "Imagenes: usuario no root, capas, HEALTHCHECK, secretos fuera de las imagenes, volumenes" \
    "scripts/verificar-f2.sh" bash scripts/verificar-f2.sh
  ejecutar 11-imagenes-f8 C2 "Despliegue: UID 10001, sin secretos en capas, compose sin advertencias, sin latest, limites, multiarquitectura" \
    "scripts/verificar-f8.sh" bash scripts/verificar-f8.sh
  # Reinicia el stack (down y up SIN construir) para medir el arranque; deja todo sano al terminar.
  ejecutar 12-tabla-despliegue C2 "Tabla medida: tamano de imagen, arranque y memoria en reposo de cada servicio" \
    "scripts/medir-despliegue.sh --reposo 45" bash scripts/medir-despliegue.sh --reposo 45
  esperar_todo
fi

# ---------------------------------------------------------------------
# C3: docker-compose.yaml
# ---------------------------------------------------------------------
if quiero C3; then
  ejecutar 20-compose-config-eureka-f1 C3 "Config Server, Eureka, Actuator en puerto de gestion y refresh sin reiniciar" \
    "scripts/verificar-f1.sh" bash scripts/verificar-f1.sh
  esperar_todo
  ejecutar 21-compose-postgres-replicas-f3 C3 "PostgreSQL, dos replicas del core, retiros simultaneos, reinicio y aislamiento de bases" \
    "scripts/verificar-f3.sh" bash scripts/verificar-f3.sh
  esperar_todo
  restablecer
fi

# ---------------------------------------------------------------------
# C1: OAuth 2.0
# ---------------------------------------------------------------------
if quiero C1; then
  ejecutar 30-oauth2-servidor-recursos-f4 C1 "OAuth2 entre servicios: OIDC, tokens de servicio, matriz 401/403/200 del core, reutilizacion del token" \
    "scripts/verificar-f4.sh" bash scripts/verificar-f4.sh
  ejecutar 31-oauth2-login-usuarios-f5 C1 "OAuth2 de usuarios: PKCE, grant de tarjeta y PIN, rechazos y bloqueo de PIN" \
    "scripts/verificar-f5.sh" bash scripts/verificar-f5.sh
  esperar_todo
  # El guion imprime la tabla 3x3; aqui se lee celda por celda y se escribe un PASS o FAIL por cada una de las nueve.
  matriz_3x3() {
    local salida rc fila canal esperado i j codigo
    salida="$(bash scripts/verificar-matriz-3x3.sh 2>&1)"; rc=$?
    echo "$salida"
    echo
    echo "== Celda por celda (diagonal 200, las seis restantes 401) =="
    i=0
    for fila in web movil cajero; do
      i=$((i + 1)); j=0
      for canal in web movil atm; do
        j=$((j + 1))
        codigo="$(echo "$salida" | awk -v f="$fila" '$1 == f {print $(1 + '"$j"')}')"
        if [ "$i" = "$j" ]; then esperado=200; else esperado=401; fi
        if [ "$codigo" = "$esperado" ]; then echo "  PASS token $fila en el canal $canal: $codigo"; else echo "  FAIL token $fila en el canal $canal: esperado $esperado, obtenido '$codigo'"; rc=1; fi
      done
    done
    return "$rc"
  }
  ejecutar 32-oauth2-matriz-3x3 C1 "Matriz 3x3 de audiencias: la diagonal 200 y las seis celdas cruzadas 401" \
    "scripts/verificar-matriz-3x3.sh" matriz_3x3
  restablecer
fi

# ---------------------------------------------------------------------
# RN: no regresion del S5
# ---------------------------------------------------------------------
if quiero RN; then
  ejecutar 40-no-regresion-s5 RN "No regresion del S5: la lista 3.1 del plan (carga, 401, vigencias, titularidad, dispositivo, retiro atomico...)" \
    "scripts/verificar-no-regresion.sh" bash scripts/verificar-no-regresion.sh
  restablecer
fi

# ---------------------------------------------------------------------
# C6: evidencia de cada microservicio (arranque, salud y resultado)
# ---------------------------------------------------------------------
if quiero C6; then
  restablecer
  N=70
  # El cajero va antes que los consumidores: el resultado de notificaciones y auditoria es el evento de su retiro.
  for s in config-server eureka-server auth-server core-service bff-web bff-mobile bff-atm notificaciones-service auditoria-service; do
    ejecutar "$N-ms-$s" C6 "Evidencia del microservicio $s: arranque, salud y resultado" \
      "scripts/evidencia-microservicio.sh $s" bash scripts/evidencia-microservicio.sh "$s"
    N=$((N + 1))
  done
  restablecer
fi

# ---------------------------------------------------------------------
# C5: Kafka
# ---------------------------------------------------------------------
if quiero C5; then
  ejecutar 60-kafka-eventos-f7 C5 "Kafka: outbox, dos grupos de consumidores, reparto de particiones, DLT, auditoria, panel y eventos de seguridad" \
    "scripts/verificar-f7.sh" bash scripts/verificar-f7.sh
  esperar_todo
  if [ "$ESCALADO" = 1 ]; then
    comprobar_escalado() {
      # La aceleracion con 3 consumidores debe ser al menos 2,0 y el cuarto consumidor debe quedar ocioso.
      bash scripts/medir-escalado.sh | tee "$TMPDIR_V/escalado.txt"
      local rc=${PIPESTATUS[0]}
      echo
      echo "== Comprobaciones sobre la tabla =="
      local ac3 oc4
      ac3="$(awk '$1 == 3 {print $(NF-1)}' "$TMPDIR_V/escalado.txt" | head -n 1 | tr ',' '.')"
      oc4="$(awk '$1 == 4 {print $NF}' "$TMPDIR_V/escalado.txt" | head -n 1)"
      if python3 -c "import sys; sys.exit(0 if float('${ac3:-0}') >= 2.0 else 1)" 2> /dev/null; then echo "  PASS aceleracion con 3 consumidores >= 2,0  (${ac3})"; else echo "  FAIL aceleracion con 3 consumidores >= 2,0  (obtenido '${ac3:-nada}')"; rc=1; fi
      if [ "${oc4:-0}" -ge 1 ] 2> /dev/null; then echo "  PASS con 4 consumidores el cuarto queda ocioso (0 particiones)  (ociosos: $oc4)"; else echo "  FAIL el cuarto consumidor debia quedar ocioso  (obtenido '${oc4:-nada}')"; rc=1; fi
      return "$rc"
    }
    TMPDIR_V="$(mktemp -d)"
    ejecutar 61-kafka-escalado C5 "Kafka: el mismo lote con 1, 3 y 4 consumidores (tabla de escalado)" "scripts/medir-escalado.sh" comprobar_escalado
    rm -rf "$TMPDIR_V"
    esperar_todo
  fi
  restablecer
fi

# ---------------------------------------------------------------------
# C4: Resilience4j (escenarios de caos)
# ---------------------------------------------------------------------
if quiero C4 && [ "$CAOS" = 1 ]; then
  ejecutar 50-resiliencia-core-caido C4 "Core caido: circuito CLOSED, OPEN, HALF_OPEN y CLOSED en los tres BFF" \
    "scripts/caos/core-caido.sh" bash scripts/caos/core-caido.sh
  esperar_todo
  ejecutar 51-resiliencia-core-lento C4 "Core lento: el circuito abre por llamadas lentas, no por errores" \
    "scripts/caos/core-lento.sh" bash scripts/caos/core-lento.sh
  esperar_todo
  ejecutar 52-resiliencia-rafaga-mamparo C4 "Rafaga simultanea: el mamparo rechaza el exceso al instante" \
    "scripts/caos/rafaga-bulkhead.sh" bash scripts/caos/rafaga-bulkhead.sh
  esperar_todo
  ejecutar 53-resiliencia-replica-muere C4 "Una replica del core muere durante 100 peticiones: 100 de 100 con 200" \
    "scripts/caos/replica-muere.sh" bash scripts/caos/replica-muere.sh
  esperar_todo
  ejecutar 54-resiliencia-auth-server-caido C4 "Auth-server caido: los BFF siguen con el token de servicio vigente" \
    "scripts/caos/auth-server-caido.sh" bash scripts/caos/auth-server-caido.sh
  esperar_todo
  restablecer
elif quiero C4; then
  echo ">> [C4] escenarios de caos omitidos (--rapido / --sin-caos): el criterio 4 NO queda verificado en esta corrida"
fi

# ---------------------------------------------------------------------
# C3 (continuacion): reinicio automatico (restart: unless-stopped)
# ---------------------------------------------------------------------
if quiero C3 && [ "$CAOS" = 1 ]; then
  ejecutar 22-compose-reinicio-automatico C3 "Reinicio automatico: restart unless-stopped solo actua cuando el proceso termina por si mismo" \
    "scripts/caos/reinicio-automatico.sh" bash scripts/caos/reinicio-automatico.sh
  esperar_todo
elif quiero C3; then
  echo ">> [C3] reinicio automatico omitido (--rapido / --sin-caos)"
fi

# ---------------------------------------------------------------------
# C2 (continuacion): los limites de recursos aguantaron toda la verificacion
# ---------------------------------------------------------------------
if quiero C2; then
  limites_tras_la_carga() {
    local id nombre oom fallos=0
    echo "\$ docker inspect -f '{{.State.OOMKilled}}' <cada contenedor>   (el nucleo mata al que pasa su limite de memoria)"
    for id in $("${COMPOSE[@]}" ps -a -q); do
      nombre="$(docker inspect -f '{{.Name}}' "$id" | sed 's#^/##')"
      oom="$(docker inspect -f '{{.State.OOMKilled}}' "$id")"
      if [ "$oom" = false ]; then echo "  PASS $nombre: nunca fue terminado por falta de memoria (OOMKilled=false)"; else echo "  FAIL $nombre: OOMKilled=$oom"; fallos=1; fi
    done
    esperar_todo
    echo
    echo "\$ docker stats --no-stream   (memoria frente a su limite, tras toda la verificacion)"
    docker stats --no-stream --format 'table {{.Name}}\t{{.MemUsage}}\t{{.MemPerc}}\t{{.PIDs}}' $("${COMPOSE[@]}" ps -q)
    return "$fallos"
  }
  ejecutar 13-limites-tras-la-carga C2 "Limites de recursos: ningun contenedor fue terminado por falta de memoria durante toda la verificacion" \
    "docker inspect (OOMKilled) y docker stats" limites_tras_la_carga
fi

# ---------------------------------------------------------------------
# C6: capturas de pantalla (opcional: necesitan Node y Playwright, que el resto del proyecto no usa)
# ---------------------------------------------------------------------
if quiero C6; then
  # Se toman AL FINAL de la verificacion: los topicos de Kafka ya tienen mensajes y los grupos de consumidores existen.
  if command -v node > /dev/null 2>&1 && node -e "require('playwright')" > /dev/null 2>&1; then
    ejecutar 80-capturas C6 "Capturas: dashboard de Eureka, Kafka UI (topicos y grupos) y login del auth-server" \
      "node scripts/capturar-pantallas.js evidencias/capturas" node scripts/capturar-pantallas.js evidencias/capturas
  else
    echo ">> [C6] capturas no regeneradas (no hay Node con Playwright en este equipo): se conservan las de evidencias/capturas/"
  fi
fi

# ---------------------------------------------------------------------
# C6: la entrega (codigo, documentacion y evidencia)
# ---------------------------------------------------------------------
if quiero C6; then
  ejecutar 79-entrega C6 "Entrega: codigo, documentacion, indice de evidencias, evidencia de cada microservicio y secretos fuera de ellas" \
    "scripts/verificar-entrega.sh" bash scripts/verificar-entrega.sh
fi

# ---------------------------------------------------------------------
# Resumen por criterio
# ---------------------------------------------------------------------
nombre_criterio() {
  case "$1" in
    C1) echo "C1  OAuth2.0 (20 pts)" ;;
    C2) echo "C2  Imagenes Docker (20 pts)" ;;
    C3) echo "C3  docker-compose.yaml (20 pts)" ;;
    C4) echo "C4  Resilience4j (20 pts)" ;;
    C5) echo "C5  Kafka (15 pts)" ;;
    C6) echo "C6  Entrega (5 pts)" ;;
    RN) echo "RN  No regresion del S5" ;;
  esac
}
echo
echo "================================================================"
echo " RESUMEN POR CRITERIO DE LA PAUTA"
echo "================================================================"
GLOBAL=0
PARCIAL=0
for c in C1 C2 C3 C4 C5 C6 RN; do
  pasos=0; malos=0; checks=0; fallas=0; i=0
  while [ "$i" -lt "${#P_ARCHIVO[@]}" ]; do
    if [ "${P_CRIT[$i]}" = "$c" ]; then
      pasos=$((pasos + 1)); checks=$((checks + P_PASS[$i])); fallas=$((fallas + P_FAIL[$i]))
      { [ "${P_RC[$i]}" != 0 ] || [ "${P_FAIL[$i]}" != 0 ]; } && malos=$((malos + 1))
    fi
    i=$((i + 1))
  done
  if [ "$pasos" = 0 ]; then
    if [ "$c" = C4 ] && [ "$CAOS" = 0 ]; then printf ' %-32s NO VERIFICADO (se omitieron los escenarios de caos)\n' "$(nombre_criterio "$c")"; PARCIAL=1
    elif [ -n "$SOLO" ]; then printf ' %-32s omitido (--solo)\n' "$(nombre_criterio "$c")"
    else printf ' %-32s sin pasos\n' "$(nombre_criterio "$c")"; GLOBAL=1; fi
    continue
  fi
  if [ "$malos" = 0 ]; then
    printf ' %-32s PASS   (%s pasos, %s comprobaciones PASS)\n' "$(nombre_criterio "$c")" "$pasos" "$checks"
  else
    printf ' %-32s FAIL   (%s de %s pasos con fallas, %s comprobaciones FAIL)\n' "$(nombre_criterio "$c")" "$malos" "$pasos" "$fallas"
    GLOBAL=1
  fi
done
echo
echo " Pasos ejecutados: ${#P_ARCHIVO[@]}   Evidencias en: $SALIDAS/   Duracion total: $(( (SECONDS - INICIO_TOTAL) / 60 )) min $(( (SECONDS - INICIO_TOTAL) % 60 )) s"
i=0
while [ "$i" -lt "${#P_ARCHIVO[@]}" ]; do
  if [ "${P_RC[$i]}" != 0 ] || [ "${P_FAIL[$i]}" != 0 ]; then echo "   FAIL en ${P_ARCHIVO[$i]}: ${P_TITULO[$i]}"; fi
  i=$((i + 1))
done

if [ "$BAJAR" = 1 ]; then
  echo
  echo "\$ docker compose down   (--bajar)"
  "${COMPOSE[@]}" down 2>&1 | tail -n 3
fi

echo
if [ "$GLOBAL" != 0 ]; then
  echo " RESULTADO GLOBAL: FAIL"
elif [ "$PARCIAL" != 0 ] || { [ "$CAOS" = 0 ] && quiero C3; }; then
  # Una ejecucion con --rapido o --sin-caos pasa lo que ejecuto, pero NO verifica el criterio 4 ni el reinicio automatico:
  # se dice en voz alta para que nadie la tome por la verificacion completa.
  echo " RESULTADO GLOBAL: PASS PARCIAL (todo lo ejecutado paso; el criterio 4 y el reinicio automatico NO se verificaron: ejecuta sin --rapido)"
else
  echo " RESULTADO GLOBAL: PASS"
fi
exit "$GLOBAL"
