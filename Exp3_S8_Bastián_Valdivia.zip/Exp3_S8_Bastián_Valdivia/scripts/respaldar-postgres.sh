#!/usr/bin/env bash
# =====================================================================
# respaldar-postgres.sh: copia de seguridad y restauracion de las bases del sistema.
# =====================================================================
# La guia de aprendizaje pide "habilitar copias de seguridad" de los datos que manejan los contenedores.
# Este guion respalda las tres bases de PostgreSQL (core, auditoria y notificaciones) con pg_dump en formato
# comprimido y las restaura con pg_restore. Es un respaldo MANUAL: no corre solo ni en horario (programarlo es
# una tarea de operacion, por ejemplo con cron o con el programador de tareas del equipo anfitrion, que
# invocaria este mismo guion).
#
# Uso:
#   scripts/respaldar-postgres.sh                       respalda las tres bases en respaldos/<fecha>/
#   scripts/respaldar-postgres.sh restaurar <carpeta>   restaura desde esa carpeta (ver mas abajo)
#
# Que hace restaurar, y por que se detienen los servicios: pg_restore borra y recrea las tablas
# (--clean), y un servicio con la base abierta mantiene conexiones y bloqueos sobre ellas. Por eso se
# detienen los servicios que usan las bases (core, notificaciones y auditoria), se restaura y se vuelven a
# iniciar. Los datos que no estaban en el respaldo se pierden: restaurar devuelve la base al momento de la
# copia. Los consumidores de Kafka, al volver, retoman desde su offset; sus tablas de idempotencia hacen que
# los eventos ya procesados antes de la copia no se apliquen dos veces.
#
# El respaldo contiene datos de demostracion, no secretos: las contrasenas de las bases viven en los
# volumenes de secretos y no se copian. La carpeta respaldos/ esta en .gitignore y en .dockerignore.
# Se ejecuta como superusuario por el socket local del contenedor (como restablecer-demo.sh).
#
# Requiere el sistema levantado (docker compose up -d --wait). Compatible con el bash 3.2 de macOS.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
# Git Bash convierte las rutas que empiezan con "/" al pasarlas a docker.exe; se desactiva.
docker() { MSYS_NO_PATHCONV=1 command docker "$@"; }

BASES="core auditoria notificaciones"
SERVICIOS_CON_BASE="core-service notificaciones-service auditoria-service"

postgres_listo() {
  [ "$(docker compose ps -q postgres 2> /dev/null | head -n 1)" != "" ] \
    && docker compose exec -T postgres pg_isready -U postgres > /dev/null 2>&1
}

if ! postgres_listo; then
  echo "ERROR: PostgreSQL no esta en marcha. Levanta el sistema con: docker compose up -d --wait" >&2
  exit 1
fi

MODO="${1:-respaldar}"

case "$MODO" in
  respaldar)
    DESTINO="respaldos/$(date -u +%Y%m%dT%H%M%SZ)"
    mkdir -p "$DESTINO" || exit 1
    for b in $BASES; do
      # -Fc: formato comprimido que pg_restore entiende. La salida va a un archivo del anfitrion.
      if ! docker compose exec -T postgres pg_dump -U postgres -d "$b" -Fc > "$DESTINO/$b.dump"; then
        echo "ERROR: fallo el respaldo de la base '$b'" >&2
        rm -rf "$DESTINO"
        exit 1
      fi
      if [ ! -s "$DESTINO/$b.dump" ]; then
        echo "ERROR: el respaldo de '$b' quedo vacio" >&2
        exit 1
      fi
      echo "  respaldo de '$b': $DESTINO/$b.dump ($(wc -c < "$DESTINO/$b.dump" | tr -d ' ') bytes)"
    done
    echo "Respaldo completo en $DESTINO"
    echo "Para restaurarlo: scripts/respaldar-postgres.sh restaurar $DESTINO"
    ;;

  restaurar)
    ORIGEN="${2:-}"
    if [ -z "$ORIGEN" ] || [ ! -d "$ORIGEN" ]; then
      echo "Uso: scripts/respaldar-postgres.sh restaurar <carpeta con los .dump>" >&2
      exit 1
    fi
    for b in $BASES; do
      [ -s "$ORIGEN/$b.dump" ] || { echo "ERROR: falta $ORIGEN/$b.dump" >&2; exit 1; }
    done
    echo "Deteniendo los servicios que usan las bases: $SERVICIOS_CON_BASE"
    # shellcheck disable=SC2086
    docker compose stop $SERVICIOS_CON_BASE > /dev/null || exit 1
    FALLO=0
    for b in $BASES; do
      # --clean --if-exists: borra lo que haya antes de recrearlo. Se conserva el dueno original (el usuario del
      # servicio), porque sin --no-owner pg_restore devuelve cada tabla a su rol y el servicio sigue pudiendo usarla.
      if docker compose exec -T postgres pg_restore -U postgres -d "$b" --clean --if-exists < "$ORIGEN/$b.dump"; then
        echo "  restaurada la base '$b'"
      else
        echo "ERROR: fallo la restauracion de '$b'" >&2
        FALLO=1
      fi
    done
    echo "Iniciando de nuevo los servicios"
    # shellcheck disable=SC2086
    docker compose start $SERVICIOS_CON_BASE > /dev/null
    [ "$FALLO" = 0 ] && echo "Restauracion completa." || { echo "Restauracion con errores." >&2; exit 1; }
    ;;

  *)
    echo "Uso: scripts/respaldar-postgres.sh [restaurar <carpeta>]" >&2
    exit 1
    ;;
esac
