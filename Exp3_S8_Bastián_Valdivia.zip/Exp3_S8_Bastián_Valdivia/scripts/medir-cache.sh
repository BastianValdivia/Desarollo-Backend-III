#!/usr/bin/env bash
# =====================================================================
# medir-cache.sh: la prueba DURA de "consumo de recursos".
# =====================================================================
# Que la respuesta de un canal tarde menos NO demuestra que la cache
# sirva. El tiempo tambien baja por el calentamiento del JIT y por la
# reutilizacion de la conexion TLS, asi que un cronometro mas bajo no
# prueba absolutamente nada sobre el consumo aguas arriba.
#
# Lo que si lo demuestra es que el CORE RECIBA MENOS PETICIONES. Este
# script se lo pregunta al propio core, leyendo su contador
# http.server.requests (Actuator del core, en su puerto de gestion desde F1; en el S5 era
# el endpoint C8 del contrato en el puerto de servicio). Es evidencia emitida
# por el servidor, no por el cliente, y por eso es dificil de discutir.
#
# COMO SE LEE EL RESULTADO, que tiene un matiz que conviene entender.
# Los contadores del core son acumulativos, y el guion informa el DELTA.
# En un canal con cache, ese delta sale:
#   1  si la cache estaba vacia: la primera peticion falla y viaja.
#   0  si otra ejecucion recien consulto la misma cuenta y el dato sigue
#      dentro de su TTL.
# Las dos son correctas y las dos demuestran lo mismo, porque lo que se
# afirma no es "el delta vale 1" sino "N peticiones al BFF NO producen N
# llamadas al core". Por eso el veredicto de abajo compara contra N.
#
# En el canal del cajero, en cambio, el delta tiene que ser EXACTAMENTE N:
# alli cualquier numero menor seria un fallo de seguridad, no un ahorro.
#
# Uso:  ./scripts/medir-cache.sh
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
# ENTORNO=docker (por defecto): contenedores, TLS verificado con certs/ca.crt; ENTORNO=local:
# JVM locales del S5 con curl -k. Ver scripts/lib-entorno.sh.
source "$(dirname "${BASH_SOURCE[0]}")/lib-entorno.sh"

source "$(dirname "${BASH_SOURCE[0]}")/lib-login.sh"

# Desde F2 el core no es alcanzable desde el host: su contador de peticiones se lee con
# gestion() (lib-entorno.sh), dentro de su contenedor, en el puerto de gestion.

# La URI de la metrica lleva llaves: /internal/v1/cuentas/{cuentaId}.
# Hay que pasarlas PORCENTAJE-CODIFICADAS (%7B y %7D).
#   - sin codificar, Tomcat rechaza la peticion con 400 Bad Request,
#     porque las llaves no son caracteres validos en una URL;
#   - y ademas curl interpreta {} como su propia sintaxis de repeticion
#     de URL, asi que ni siquiera llega a enviar lo que uno escribio.
# Las dos cosas fallan de forma poco obvia, de ahi el comentario.
URI_CUENTA='%2Finternal%2Fv1%2Fcuentas%2F%7BcuentaId%7D'
URI_SALDO='%2Finternal%2Fv1%2Fcuentas%2F%7BcuentaId%7D%2Fsaldo'

LEER_TOKEN='import sys,json; print(json.load(sys.stdin)["accessToken"])'

# contador <uri-codificada> -> cuantas peticiones ha recibido el core en esa ruta
contador() { contador_core "$1"; }

TW="$(token_web cliente116 Cliente.2026)"
TM="$(token_movil cliente116 Cliente.2026 dispositivo-demo-01)"
TA="$(token_cajero 4000000000000116 1234)"

echo "======================================================================"
echo " Llamadas que el CORE recibe de verdad, por canal"
echo " Fecha: $(date -Is)"
echo "======================================================================"

# ---------------------------------------------------------------- WEB
echo
echo "--- CANAL WEB: cache 'cuenta-web', TTL 60 s -------------------------"
ANTES=$(contador "$URI_CUENTA")
for _ in 1 2 3 4 5; do
  curl_bff -o /dev/null "$WEB/v1/cuentas/116" -H "Authorization: Bearer $TW"
done
for _ in 1 2; do
  curl_bff -o /dev/null "$WEB/v1/cuentas/116/resumen-mensual" -H "Authorization: Bearer $TW"
done
DESPUES=$(contador "$URI_CUENTA")
LLAMADAS=$((DESPUES - ANTES))
echo "  Peticiones al BFF : 7  (5 fichas W2 + 2 resumenes mensuales W4)"
echo "  Llamadas al core  : $LLAMADAS"
if [ "$LLAMADAS" -le 1 ]; then
  echo "  VEREDICTO: CORRECTO. 7 peticiones produjeron $LLAMADAS llamada(s)."
else
  echo "  VEREDICTO: FALLO. Se esperaba 0 o 1; la cache no esta actuando."
fi
echo "  W2 y W4 son operaciones DISTINTAS que necesitan el MISMO recurso del"
echo "  core. Sin cache serian 7 llamadas."

# -------------------------------------------------------------- MOVIL
echo
echo "--- CANAL MOVIL: cache 'resumen-movil', TTL 30 s --------------------"
ANTES=$(contador "$URI_CUENTA")
for _ in 1 2 3 4 5; do
  curl_bff -o /dev/null "$MOVIL/v1/cuentas/116/resumen" \
       -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01'
done
DESPUES=$(contador "$URI_CUENTA")
LLAMADAS=$((DESPUES - ANTES))
echo "  Peticiones al BFF : 5"
echo "  Llamadas al core  : $LLAMADAS"
if [ "$LLAMADAS" -le 1 ]; then
  echo "  VEREDICTO: CORRECTO. 5 peticiones produjeron $LLAMADAS llamada(s)."
else
  echo "  VEREDICTO: FALLO. Se esperaba 0 o 1; la cache no esta actuando."
fi

# ------------------------------------------------------------- CAJERO
echo
echo "--- CANAL CAJERO: SIN cache, y esto es lo que hay que demostrar -----"
ANTES=$(contador "$URI_SALDO")
for _ in 1 2 3 4 5; do
  curl_bff -o /dev/null "$ATM/v1/cuentas/116/saldo-disponible" \
       -H "Authorization: Bearer $TA"
done
DESPUES=$(contador "$URI_SALDO")
LLAMADAS=$((DESPUES - ANTES))
echo "  Peticiones al BFF : 5"
echo "  Llamadas al core  : $LLAMADAS"
if [ "$LLAMADAS" -eq 5 ]; then
  echo "  VEREDICTO: CORRECTO. Cada consulta viajo al core, como debe ser."
else
  echo "  VEREDICTO: FALLO GRAVE. Alguien introdujo una cache de saldo en el"
  echo "             canal que entrega billetes. Ver bff-atm/pom.xml."
fi
echo
echo "  AQUI EL NUMERO BUENO ES 5, NO 1. En este canal, cinco consultas"
echo "  tienen que producir cinco viajes al core: el cajero entrega billetes"
echo "  contra ese saldo y no puede responder con un valor guardado. Si esta"
echo "  linea dijera 1, seria un FALLO grave, no una optimizacion."

# ------------------------------------- denominaciones: la cache descartada
echo
echo "--- CAJERO, endpoint A4 denominaciones ------------------------------"
ANTES_C=$(contador "$URI_CUENTA"); ANTES_S=$(contador "$URI_SALDO")
for _ in 1 2 3 4 5; do
  curl_bff -o /dev/null "$ATM/v1/denominaciones" \
       -H "Authorization: Bearer $TA"
done
DESPUES_C=$(contador "$URI_CUENTA"); DESPUES_S=$(contador "$URI_SALDO")
echo "  Peticiones al BFF : 5"
echo "  Llamadas al core  : $(( (DESPUES_C - ANTES_C) + (DESPUES_S - ANTES_S) ))"
echo
echo "  CERO, y por eso este endpoint NO lleva cache pese a que el plan la"
echo "  proponia con TTL de 300 s. No llama al core: sirve un objeto en"
echo "  memoria leido de la propia configuracion del canal. Una cache aqui"
echo "  no ahorraria ninguna llamada, ninguna E/S y ningun calculo; solo"
echo "  agregaria el costo del proxy. Seria una casilla marcada sin nada"
echo "  detras, y la regla de esta etapa es que una optimizacion sin numero"
echo "  es una creencia."
echo
echo "======================================================================"
