#!/usr/bin/env bash
# =====================================================================
# medir-final.sh: la medicion definitiva del proyecto, en un solo guion.
# =====================================================================
# Reune las cinco preguntas de la etapa de cierre y las contesta con
# numeros medidos, no con numeros recordados:
#
#   1. Cuanto ahorra cada canal frente al core, en bytes y en tiempo.
#   2. Que hace la cache donde la hay: primera peticion contra siguientes.
#   3. Por que comprimir la respuesta del cajero costaria bytes.
#   4. Que pasa con la cuenta 130, que no tiene movimientos.
#   5. Cuanto cuesta el ETag y cuanto ahorra de verdad.
#
# METODO, que aqui importa tanto como el resultado
# ------------------------------------------------
# a) TODAS las repeticiones de una medicion viajan por UNA sola conexion
#    TLS. Se consigue pasandole a curl la misma URL N veces en una unica
#    invocacion. Sin esto cada medicion paga un handshake de unos 9 ms
#    que no tiene nada que ver con lo que se quiere medir y que sepulta
#    las diferencias entre canales, que son de 1 a 3 ms.
#
# b) Se DESCARTAN las primeras peticiones. La primera a una aplicacion
#    Spring recien arrancada tarda cientos de milisegundos por carga de
#    clases y compilacion JIT, y ademas paga el handshake del punto (a).
#    Ese numero es real pero no describe el regimen permanente.
#
# c) Se informa la MEDIANA, no el promedio. Un unico valor atipico (una
#    pausa del recolector de basura, el planificador del sistema que se
#    lleva la CPU un instante) arrastra el promedio y deja la mediana
#    intacta. Con 10 muestras basta un solo pico de 50 ms para inventar
#    5 ms de diferencia que no existe.
#
# d) Cada endpoint se mide DOS veces: con y sin "Accept-Encoding: gzip".
#    La diferencia entre esas dos filas es el efecto REAL de la
#    compresion, medido, y no lo que promete el archivo de configuracion.
#
# e) Se miden BYTES Y TIEMPO. Informar solo bytes es contar la mitad de
#    la historia: la compresion cuesta CPU y la cache cuesta memoria.
#
# Uso:  ./scripts/medir-final.sh
#       Requiere los cuatro servicios levantados.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS          # regla operativa 1
# ENTORNO=docker (por defecto): contenedores, TLS verificado con certs/ca.crt; ENTORNO=local:
# JVM locales del S5 con curl -k. Ver scripts/lib-entorno.sh.
source "$(dirname "${BASH_SOURCE[0]}")/lib-entorno.sh"

source "$(dirname "${BASH_SOURCE[0]}")/lib-login.sh"

REPS=${REPS:-15}                 # peticiones por medicion, en una conexion
DESCARTE=${DESCARTE:-5}          # las primeras se tiran (handshake + JIT)

# Desde F2 el core no es alcanzable desde el host: se le habla con core_get/gestion
# (lib-entorno.sh), dentro de su contenedor.

# Las llaves de la URI de la metrica van porcentaje-codificadas: sin
# codificar, Tomcat responde 400 y curl ademas interpreta {} como su
# propia sintaxis de repeticion de URL.
URI_CUENTA='%2Finternal%2Fv1%2Fcuentas%2F%7BcuentaId%7D'
URI_SALDO='%2Finternal%2Fv1%2Fcuentas%2F%7BcuentaId%7D%2Fsaldo'

# El campo se llama accessToken (contrato, seccion 5.2). Leer "token"
# dejaria la variable vacia y las decenas de peticiones siguientes darian
# 401 en cascada, un sintoma que no apunta en absoluto a la causa.
LEER='import sys,json; print(json.load(sys.stdin)["accessToken"])'

# ---------------------------------------------------------------------
# medir <nombre> <gzip:si|no> <url> [cabeceras...]
# Imprime: codigos HTTP, mediana de bytes del cuerpo, bytes de cabecera,
# y mediana / minimo / maximo del tiempo total en milisegundos.
#
# %{size_download} con --compressed informa los bytes que EFECTIVAMENTE
# viajaron por el cable, no el cuerpo ya descomprimido: mide transferencia,
# que es lo que se quiere medir, y no tamano logico.
# ---------------------------------------------------------------------
medir() {
  local nombre="$1"; shift
  local gzip="$1";   shift
  local url="$1";    shift
  # ${acepta[@]+...}: un arreglo vacio con "set -u" da "unbound variable" en el bash 3.2 de macOS.
  local acepta=()
  [ "$gzip" = "si" ] && acepta=(--compressed)

  local urls=()
  for _ in $(seq 1 "$REPS"); do urls+=(-o /dev/null "$url"); done

  curl_bff ${acepta[@]+"${acepta[@]}"} "$@" \
       -w '%{http_code} %{size_download} %{size_header} %{time_total}\n' \
       "${urls[@]}" \
  | python3 -c "
import sys
f=[l.split() for l in sys.stdin if l.strip()][$DESCARTE:]
def mediana(v):
    v=sorted(v); n=len(v)
    return v[n//2] if n%2 else (v[n//2-1]+v[n//2])/2
cod='/'.join(sorted({x[0] for x in f}))
by=mediana([int(x[1]) for x in f]); cb=mediana([int(x[2]) for x in f])
ms=[float(x[3])*1000 for x in f]
print(f'  {\"$nombre\":<38} {cod:>7} {by:>8.0f} {cb:>7.0f} {mediana(ms):9.2f} {min(ms):8.2f} {max(ms):8.2f} {len(f):>4}')
"
}

# El core no es alcanzable desde el host en Docker (sin puertos publicados): su fila de linea
# base se mide dentro de su contenedor y solo informa el tamano del cuerpo (sin gzip ni tiempos).
# En local se mide como siempre, con curl.
medir_core() {  # medir_core <nombre> <gzip:si|no> <ruta>
  if [ "$ENTORNO" = local ]; then
    medir "$1" "$2" "http://127.0.0.1:8080$3" -H "Authorization: Bearer $(token_servicio "$(cliente_para_ruta "$3")")"
  elif [ "$2" = si ]; then
    printf '  %-38s (omitida: sin acceso desde el host no se puede medir gzip del core)\n' "$1"
  else
    printf '  %-38s %7s %8s   (cuerpo medido dentro del contenedor del core)\n' "$1" "200" "$(core_bytes "$3")"
  fi
}

cabecera() {
  printf '  %-38s %7s %8s %7s %9s %8s %8s %4s\n' \
    "medicion" "http" "bytes" "cabec" "mediana" "min" "max" "n"
  printf '  %s\n' "$(printf '%.0s-' $(seq 1 96))"
}

cont() { contador_core "$1"; }

echo "======================================================================"
echo " MEDICION FINAL   ---   $(date -Is)"
echo " ${REPS} peticiones por medicion sobre una sola conexion TLS;"
echo " se descartan las ${DESCARTE} primeras y se informa la MEDIANA de las $((REPS-DESCARTE))."
echo "======================================================================"

if ! herramientas_java_disponibles; then
  echo "ERROR: faltan las herramientas Java de medicion (firmar tokens de la cuenta 130 y gzip)." >&2
  if [ "$ENTORNO" = local ]; then echo "       Instala un JDK 21 (ENTORNO=local usa el java del equipo)." >&2
  else echo "       Falta la imagen $IMAGEN_HERRAMIENTAS: ejecuta docker compose up -d --build." >&2; fi
  exit 2
fi

TW="$(token_web cliente116 Cliente.2026)"
TM="$(token_movil cliente116 Cliente.2026 dispositivo-demo-01)"
TA="$(token_cajero 4000000000000116 1234)"

# Tokens para la cuenta 130. No hay credencial sembrada para esa cuenta en
# ningun canal (contrato, seccion 8), asi que se firman con la clave del
# auth-server mediante la herramienta de evidencia del propio proyecto
# (firmar_token en lib-entorno.sh). El canal los valida contra el JWKS del
# auth-server como a cualquier otro: no se debilita nada.
T130W=$(firmar_token bff-web cliente130 130 WEB 3600 \
  'ROLE_CLIENTE_WEB,PERM_cuenta:leer,PERM_movimientos:leer,PERM_resumen:leer')
T130A=$(firmar_token bff-atm 4000000000000130 130 ATM 3600 \
  'ROLE_CLIENTE_ATM,PERM_saldo:leer' '"terminal":"ATM-SCL-001"')
# El movil necesita ademas el claim device_id: su filtro lo compara con la cabecera
# X-Device-Id y sin el responde 401 dispositivo_no_coincide.
T130M=$(firmar_token bff-mobile cliente130 130 MOVIL 3600 \
  'ROLE_CLIENTE_MOVIL,PERM_saldo:leer,PERM_dispositivo:gestionar' \
  '"device_id":"dispositivo-demo-01"')

echo
echo "######################################################################"
echo "# 1. TABLA POR CANAL, CUENTA 116"
echo "######################################################################"
echo
cabecera
echo "  -- LINEA BASE: el core sin BFF (HTTP plano, sin TLS, sin compresion) --"
medir_core "core C2 cuenta 116 completa"      no /internal/v1/cuentas/116
medir_core "core C2 con Accept-Encoding gzip" si /internal/v1/cuentas/116
medir_core "core C3 saldo 116"                no /internal/v1/cuentas/116/saldo
echo
echo "  -- CANAL WEB 8443: compresion 1024 B, cache cuenta-web 60 s --"
medir "web W2 ficha 116  sin gzip"       no "$WEB/v1/cuentas/116"                 -H "Authorization: Bearer $TW"
medir "web W2 ficha 116  con gzip"       si "$WEB/v1/cuentas/116"                 -H "Authorization: Bearer $TW"
medir "web W3 movimientos sin gzip"      no "$WEB/v1/cuentas/116/movimientos"     -H "Authorization: Bearer $TW"
medir "web W3 movimientos con gzip"      si "$WEB/v1/cuentas/116/movimientos"     -H "Authorization: Bearer $TW"
medir "web W4 resumen-mensual sin gzip"  no "$WEB/v1/cuentas/116/resumen-mensual" -H "Authorization: Bearer $TW"
medir "web W4 resumen-mensual con gzip"  si "$WEB/v1/cuentas/116/resumen-mensual" -H "Authorization: Bearer $TW"
echo
echo "  -- CANAL MOVIL 8444: compresion 256 B, cache resumen-movil 30 s, ETag debil --"
medir "movil M2 resumen 116 sin gzip"    no "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01'
medir "movil M2 resumen 116 con gzip"    si "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01'
echo
echo "  -- CANAL CAJERO 8445: compresion APAGADA, sin cache --"
medir "atm A2 saldo 116 sin gzip"        no "$ATM/v1/cuentas/116/saldo-disponible" -H "Authorization: Bearer $TA"
medir "atm A2 saldo 116 con gzip"        si "$ATM/v1/cuentas/116/saldo-disponible" -H "Authorization: Bearer $TA"
medir "atm A4 denominaciones con gzip"   si "$ATM/v1/denominaciones"               -H "Authorization: Bearer $TA"

echo
echo "######################################################################"
echo "# 2. EFECTO DE LA CACHE: PRIMERA PETICION CONTRA LAS SIGUIENTES"
echo "######################################################################"
echo
echo "  Se espera 65 s a que caduquen los dos TTL (web 60 s, movil 30 s)."
sleep 65

# frio_vs_caliente <nombre> <url-calentamiento> <url-medida> <uri-metrica> [cabeceras...]
#
# El calentamiento apunta a una cuenta AJENA al token: devuelve 403 sin
# llegar al servicio, asi que paga el handshake TLS y el JIT sin poblar la
# cache. Sin ese paso, la "primera" peticion incluiria los 9 ms del
# handshake y el numero no diria nada sobre la cache.
frio_vs_caliente() {
  local nombre="$1"; shift; local calent="$1"; shift
  local url="$1";    shift; local uri="$1";    shift
  local urls=(); for _ in 1 2 3 4 5; do urls+=(-o /dev/null "$calent"); done
  for _ in $(seq 1 10); do urls+=(-o /dev/null "$url"); done
  local antes despues salida
  antes=$(cont "$uri")
  salida=$(curl_bff "$@" -w '%{http_code} %{size_download} %{time_total}\n' "${urls[@]}" | tail -n 10)
  despues=$(cont "$uri")
  echo "--- $nombre"
  echo "$salida" | python3 -c "
import sys
f=[l.split() for l in sys.stdin if l.strip()]
ms=[float(x[2])*1000 for x in f]
frio=ms[0]; cal=sorted(ms[1:]); n=len(cal)
med=cal[n//2] if n%2 else (cal[n//2-1]+cal[n//2])/2
print(f'  http={f[0][0]}  bytes={f[0][1]}')
print(f'  peticion 1 (cache vacia)          : {frio:7.2f} ms')
print(f'  peticiones 2-10 (mediana de {n})    : {med:7.2f} ms')
print(f'  diferencia                        : {frio-med:7.2f} ms  ({(frio-med)/frio*100:.1f}%)')
"
  echo "  llamadas al core en las 10 peticiones: $((despues - antes))"
  echo
}

frio_vs_caliente "WEB W2 ficha 116 (cache cuenta-web, TTL 60 s)" \
  "$WEB/v1/cuentas/999" "$WEB/v1/cuentas/116" "$URI_CUENTA" -H "Authorization: Bearer $TW"
frio_vs_caliente "MOVIL M2 resumen 116 (cache resumen-movil, TTL 30 s)" \
  "$MOVIL/v1/cuentas/999/resumen" "$MOVIL/v1/cuentas/116/resumen" "$URI_CUENTA" \
  -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01'
frio_vs_caliente "CAJERO A2 saldo 116 (SIN cache, a proposito)" \
  "$ATM/v1/cuentas/999/saldo-disponible" "$ATM/v1/cuentas/116/saldo-disponible" "$URI_SALDO" \
  -H "Authorization: Bearer $TA"

echo "######################################################################"
echo "# 3. CUANTO COSTARIA COMPRIMIR LA RESPUESTA DEL CAJERO"
echo "######################################################################"
echo
echo "  Se gzipean los cuerpos REALES con java.util.zip, la misma libreria"
echo "  con la que Tomcat comprime. Un miembro gzip arrastra 18 bytes fijos"
echo "  de cabecera y cola que no dependen del contenido; por debajo de"
echo "  cierto tamano ese coste fijo no se amortiza nunca."
echo
# Los cuerpos se vuelcan a ARCHIVOS y el medidor los lee como bytes crudos.
# Pasarlos como argumentos de la linea de ordenes los corrompe: la JVM decodifica
# argv con sun.jnu.encoding, que en un locale POSIX es US-ASCII, y cada byte no
# ASCII (las eñes del dataset) se vuelve U+FFFD y pasa a ocupar tres bytes. Ese
# error inflaba el cuerpo de la ficha web de 1973 a 1981 bytes sin dar ningun
# aviso, y valia cero justo en las filas del cajero, que son ASCII puro.
TMP=$(mktemp -d)
curl_bff "$ATM/v1/cuentas/116/saldo-disponible" -H "Authorization: Bearer $TA" > "$TMP/a2.json"
curl_bff "$ATM/v1/denominaciones"               -H "Authorization: Bearer $TA" > "$TMP/a4.json"
curl_bff "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01' > "$TMP/m2.json"
curl_bff "$WEB/v1/cuentas/116"           -H "Authorization: Bearer $TW" > "$TMP/w2.json"
gzip_cuesta_bytes "$TMP/a2.json" "$TMP/a4.json" "$TMP/m2.json" "$TMP/w2.json"
echo
echo "  Y el punto de equilibrio exacto, recortando el arreglo de"
echo "  movimientos del cuerpo real del movil de 0 a 5 elementos:"
echo
python3 -c "
import json,sys,os
d=json.load(open(sys.argv[1])); m=d['ultimosMovimientos']; dst=sys.argv[2]
for n in range(len(m)+1):
    d2=dict(d); d2['ultimosMovimientos']=m[:n]
    with open(os.path.join(dst,f'v{n}.json'),'wb') as f:
        f.write(json.dumps(d2,separators=(',',':'),ensure_ascii=False).encode('utf-8'))
" "$TMP/m2.json" "$TMP"
gzip_cuesta_bytes "$TMP"/v*.json
rm -rf "$TMP"

echo
echo "######################################################################"
echo "# 4. CUENTA 130: CERO MOVIMIENTOS, Y LA VENTAJA DEL WEB SE INVIERTE"
echo "######################################################################"
echo
cabecera
medir_core "core C2 cuenta 130 completa"     no /internal/v1/cuentas/130
medir_core "core C3 saldo 130"               no /internal/v1/cuentas/130/saldo
medir "web W2 ficha 130 sin gzip"       no "$WEB/v1/cuentas/130"                 -H "Authorization: Bearer $T130W"
medir "web W2 ficha 130 con gzip"       si "$WEB/v1/cuentas/130"                 -H "Authorization: Bearer $T130W"
medir "movil M2 resumen 130 sin gzip"   no "$MOVIL/v1/cuentas/130/resumen" -H "Authorization: Bearer $T130M" -H 'X-Device-Id: dispositivo-demo-01'
medir "movil M2 resumen 130 con gzip"   si "$MOVIL/v1/cuentas/130/resumen" -H "Authorization: Bearer $T130M" -H 'X-Device-Id: dispositivo-demo-01'
medir "atm A2 saldo 130 sin gzip"       no "$ATM/v1/cuentas/130/saldo-disponible" -H "Authorization: Bearer $T130A"
echo
echo "  Cuerpos literales:"
echo "  core  : $(core_get /internal/v1/cuentas/130)"
echo "  web   : $(curl_bff "$WEB/v1/cuentas/130" -H "Authorization: Bearer $T130W")"
echo "  movil : $(curl_bff "$MOVIL/v1/cuentas/130/resumen" -H "Authorization: Bearer $T130M" -H 'X-Device-Id: dispositivo-demo-01')"
echo "  cajero: $(curl_bff "$ATM/v1/cuentas/130/saldo-disponible" -H "Authorization: Bearer $T130A")"

echo
echo "######################################################################"
echo "# 5. EL ETAG DEL MOVIL: QUE AHORRA Y QUE NO"
echo "######################################################################"
echo
ETAG=$(curl_bff -o /dev/null -D - "$MOVIL/v1/cuentas/116/resumen" \
       -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01' \
       | grep -i '^etag:' | tr -d '\r' | sed 's/^[Ee][Tt][Aa][Gg]: //')
echo "  ETag emitido: $ETAG"
echo "  (la W/ del principio lo marca como DEBIL; con un ETag fuerte Tomcat"
echo "   se niega a comprimir, y las dos optimizaciones se anulan sin error)"
echo
cabecera
medir "movil M2 200 completo sin gzip"   no "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01'
medir "movil M2 200 completo con gzip"   si "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01'
medir "movil M2 304 If-None-Match"       si "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01' -H "If-None-Match: $ETAG"
echo
echo "======================================================================"
echo " Fin de la medicion  ---  $(date -Is)"
echo "======================================================================"
