#!/usr/bin/env bash
# =====================================================================
# lib-entorno.sh: diferencias entre correr contra CONTENEDORES o contra JVM LOCALES.
# =====================================================================
# Los guiones de verificacion y medicion se escribieron en el S5 contra procesos locales
# (curl -k a https://127.0.0.1, core en :8080, Actuator en puertos de gestion locales).
# Desde F2 el entorno principal son los contenedores de docker-compose.yaml, y alli:
#
#   - los BFF se verifican con la CA del proyecto:  curl --cacert certs/ca.crt
#     (el certificado lo firma la CA interna que genera secretos-init; sin la CA, curl
#     rechaza la conexion, que es lo correcto, y "-k" ya no hace falta);
#   - el core NO es alcanzable desde el host (sin puertos publicados, red interna);
#   - el Actuator de cada servicio vive en su puerto de gestion (8081), que tampoco se
#     publica.
#
# Este archivo se importa con "source" y decide el entorno con la variable ENTORNO:
#   ENTORNO=docker  (por defecto)  contenedores levantados con docker compose up -d; al importarlo
#                                  espera (scripts/esperar-sano.sh) a que todos esten healthy
#   ENTORNO=local                  JVM locales levantadas con scripts/levantar-local.sh
#
# Portabilidad: el archivo evita construcciones de bash 4 y de GNU (arreglos asociativos,
# date +%N, sha256sum en el host) para que corra con el bash 3.2 de macOS y en Git Bash.
# Requiere python3 y curl en el host, ademas de Docker (ni JDK ni Maven en ENTORNO=docker).
#
# Define (para quien lo importa):
#   docker ...               envoltorio que desactiva la conversion de rutas de Git Bash (ver abajo)
#   WEB MOVIL ATM            URL base de cada canal
#   TLS                      argumentos de curl para HTTPS:  --cacert certs/ca.crt  (docker)
#                            o -k, porque en local los certificados son autofirmados (local)
#   curl_bff ...             curl silencioso hacia un BFF, con la verificacion TLS que corresponde
#   gestion <servicio> <ruta>   GET al Actuator (puerto de gestion) del servicio, imprime el cuerpo
#   gestion_post <servicio> <ruta>   POST vacio al Actuator (refresh)
#   interno_codigo <servicio> <puerto> <ruta>   codigo HTTP de un GET hecho DENTRO de la red
#                            interna (en docker, desde el contenedor del servicio)
#   config_get <ruta>        GET al config-server (no se publica al host), imprime el cuerpo
#   core_get <ruta>          GET al core con un token de servicio, imprime el cuerpo
#   secreto_terminal <atm-scl-001>   secreto del terminal del cajero (cliente confidencial del grant tarjeta y PIN)
#   token_servicio <bff-web|bff-mobile|bff-atm> [scopes...]   token de acceso (client_credentials) que
#                            el auth-server entrega a ese BFF, con los scopes pedidos (por defecto, todos
#                            los de ese cliente). Cada llamada pide uno nuevo.
#   core_con_token <token> <ruta>   GET al core con ese token exacto (para probar tokens malos)
#   core_codigo <token|-> <metodo> <ruta> [cuerpo-json]   codigo HTTP de una llamada al core; "-" no manda token
#   core_bytes <ruta>        tamano en bytes del cuerpo de core_get
#   gestion_core_todas <ruta>   GET al Actuator de CADA replica del core (una linea por replica).
#                            Desde F3 el core corre en dos replicas: una metrica que cuenta
#                            peticiones solo vale si se suman las de todas.
#   sql_postgres <base> <sentencia>   SQL como superusuario por el socket local del contenedor de
#                            PostgreSQL (docker) o de la base desechable local (local); imprime sin
#                            formato (-tA). No usa la red: no necesita contrasena ni puertos.
#   herramientas_java_disponibles   0 si se pueden ejecutar las herramientas Java de prueba
#   firmar_token <audiencia> <sub> <cuenta> <canal> <seg> <autoridades> [extra]   JWT de usuario forjado con la clave
#                            del auth-server (FirmarTokenDePrueba.java), para los casos que el auth-server no emite
#   llamada_interna <args...>  una llamada HTTP desde un contenedor efimero UNIDO A LA RED INTERNA (docker), con
#                            TLS verificado contra la CA interna (LlamadaInterna.java): imprime "HTTP <codigo>",
#                            WWW-Authenticate y el cuerpo. Solo ENTORNO=docker.
#   firmar_token_servicio <args...>  JWT de servicio forjado con la clave del auth-server o con una ajena
#                            (FirmarTokenDeServicio.java): para mostrar lo que el core rechaza
#   gzip_cuesta_bytes <archivos...> tamano plano y gzip de cuerpos (GzipCuestaBytes.java)
#                            En docker corren en un contenedor efimero (imagen secretos-init,
#                            que trae el JDK 21): el host solo necesita Docker.
# =====================================================================
RAIZ="${RAIZ:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
ENTORNO="${ENTORNO:-docker}"
unset JAVA_TOOL_OPTIONS

WEB="${WEB:-https://localhost:8443/api/web}"
MOVIL="${MOVIL:-https://localhost:8444/api/mobile}"
MOV="$MOVIL"
ATM="${ATM:-https://localhost:8445/api/atm}"

# Git Bash (Windows) reescribe como rutas de Windows los argumentos que parecen rutas Unix
# (/run/secrets/..., /actuator/...) y tambien "volumen:/ruta:ro", y asi rompe cualquier
# "docker exec", "docker run -v" o "docker compose exec" que lleve una ruta de CONTENEDOR.
# MSYS_NO_PATHCONV=1 lo desactiva; en macOS y Linux la variable no tiene efecto. Se pone solo
# delante de docker (y no con export) para no tocar a java ni a python, que si necesitan que
# Git Bash les convierta las rutas del host.
docker() { MSYS_NO_PATHCONV=1 command docker "$@"; }

# Con la conversion desactivada, "-f /c/Users/..." llegaria tal cual a docker.exe, que no lo
# entiende. cygpath (solo existe en Git Bash y Cygwin) da la forma "C:/Users/..." que si
# entiende; en macOS y Linux no existe y RAIZ ya vale.
if command -v cygpath > /dev/null 2>&1; then RAIZ_NATIVA="$(cygpath -m "$RAIZ")"; else RAIZ_NATIVA="$RAIZ"; fi
COMPOSE=(docker compose -f "$RAIZ_NATIVA/docker-compose.yaml")

case "$ENTORNO" in
  docker)
    CA_CRT="${CA_CRT:-$RAIZ/certs/ca.crt}"
    if [ ! -f "$CA_CRT" ]; then
      echo "ERROR: falta $CA_CRT. Levanta el stack (docker compose up -d): secretos-init lo crea." >&2
      exit 2
    fi
    TLS=(--cacert "$CA_CRT")
    # Los guiones usan python3 en decenas de puntos. Si no existe (o es el alias de la Tienda de Windows, que no ejecuta
    # nada), cada uno fallaria mas adelante con un mensaje que no apunta a la causa: se avisa aqui, una sola vez.
    if ! python3 -c 'import sys' > /dev/null 2>&1; then
      echo "ERROR: python3 no funciona en este equipo (los guiones lo necesitan). En Windows, instala Python 3 desde python.org" >&2
      echo "       y desactiva el alias de la Tienda (Configuracion > Aplicaciones > Alias de ejecucion de aplicaciones)." >&2
      exit 2
    fi
    # "docker compose up -d" vuelve con los BFF aun arrancando (nada depende de ellos): sin esta
    # espera, un guion lanzado justo despues del up chocaria con una ventana de unos 15 a 20 s en
    # que el HTTPS de los BFF todavia no responde y fallaria sin que el sistema tenga un defecto.
    # La salida va a stderr: los guiones de login con --token imprimen SOLO el token en stdout y se usan como
    # TOKEN=$(scripts/login-web.sh --token); una linea de estado en stdout se colaria dentro del token.
    bash "$RAIZ/scripts/esperar-sano.sh" >&2 || exit 2
    AUTH_URL="${AUTH_URL:-https://localhost:9000}"
    # El secreto de cada cliente OAuth2 vive en el volumen del auth-server (el unico que lo monta); los
    # BFF tienen cada uno el suyo en el suyo. Para las pruebas se lee del auth-server, que los tiene los tres.
    secreto_cliente() {
      "${COMPOSE[@]}" exec -T auth-server cat "/run/secrets/propiedades/autorizacion.clientes.$1.secreto"
    }
    # El core no escucha en el host: se le habla desde dentro de su contenedor, con un token de servicio
    # que se pide al auth-server (publicado en el 9000). Se elige el cliente por la ruta, como lo haria el
    # sistema: el saldo es del cajero y lo demas (cuentas, movimientos, administracion) del BFF web.
    # El secreto del terminal del cajero (F5), que el auth-server tiene por ser quien lo verifica.
    secreto_terminal() {
      "${COMPOSE[@]}" exec -T auth-server cat "/run/secrets/propiedades/autorizacion.terminales.$1.secreto"
    }
    core_get() {
      core_con_token "$(token_servicio "$(cliente_para_ruta "$1")")" "$1"
    }
    core_con_token() {  # core_con_token <token> <ruta>
      "${COMPOSE[@]}" exec -T core-service sh -c \
        'wget -qO- --header "Authorization: Bearer $1" "http://127.0.0.1:8080$2"' _ "$1" "$2"
    }
    # Codigo HTTP de una llamada al core hecha desde dentro de su contenedor. wget de BusyBox no imprime el
    # cuerpo de un 4xx ni su codigo, asi que se lee de la cabecera (-S). Token "-" = sin token.
    core_codigo() {  # core_codigo <token|-> <metodo> <ruta> [cuerpo-json]
      "${COMPOSE[@]}" exec -T core-service sh -c '
        cab=""; [ "$1" != "-" ] && cab="Authorization: Bearer $1"
        if [ "$2" = POST ]; then
          wget -S -q -O /dev/null ${cab:+--header "$cab"} --header "Content-Type: application/json" \
            --header "Idempotency-Key: f4-$$-$(date +%s)" --post-data "$4" "http://127.0.0.1:8080$3" 2>&1
        else
          wget -S -q -O /dev/null ${cab:+--header "$cab"} "http://127.0.0.1:8080$3" 2>&1
        fi | grep -m1 "HTTP/" | awk "{print \$2}"' _ "$1" "$2" "$3" "${4:-}"
    }
    gestion() { "${COMPOSE[@]}" exec -T "$1" wget -qO- "http://127.0.0.1:8081$2"; }
    # Cada replica del core es un contenedor distinto: se recorren por id (compose exec solo elige una).
    gestion_core_todas() {
      local id
      for id in $("${COMPOSE[@]}" ps -q core-service); do
        docker exec "$id" wget -qO- "http://127.0.0.1:8081$1" 2> /dev/null
        echo
      done
    }
    sql_postgres() {
      "${COMPOSE[@]}" exec -T postgres psql -v ON_ERROR_STOP=1 -q -U postgres -d "$1" -tA -c "$2"
    }
    gestion_post() { "${COMPOSE[@]}" exec -T "$1" wget -qO- --header 'Content-Type: application/json' --post-data='{}' "http://127.0.0.1:8081$2"; }
    # wget de BusyBox sale con error ante un 404 y no imprime el codigo: se lee de la cabecera (-S).
    interno_codigo() {
      "${COMPOSE[@]}" exec -T "$1" sh -c 'wget -S -q -O /dev/null "$1" 2>&1 | grep -m1 "HTTP/" | awk "{print \$2}"' _ "http://127.0.0.1:$2$3"
    }
    config_get() { "${COMPOSE[@]}" exec -T config-server wget -qO- "http://127.0.0.1:8888$1"; }
    ;;
  local)
    TLS=(-k)
    # El auth-server local habla HTTP en 127.0.0.1 (config-repo/auth-server-local.yml). Los secretos de los
    # clientes los genero scripts/levantar-local.sh y los dejo en run/secretos-locales.env (ignorado por git).
    AUTH_URL="${AUTH_URL:-http://localhost:9000}"
    secreto_cliente() {
      local archivo="$RAIZ/run/secretos-locales.env" var
      [ -f "$archivo" ] || { echo "ERROR: falta $archivo: levanta primero con scripts/levantar-local.sh" >&2; return 1; }
      case "$1" in bff-web) var=SECRETO_WEB ;; bff-mobile) var=SECRETO_MOBILE ;; bff-atm) var=SECRETO_ATM ;; esac
      ( . "$archivo"; printf '%s' "${!var}" )
    }
    # El secreto del terminal del cajero (F5), en el mismo archivo.
    secreto_terminal() {
      local archivo="$RAIZ/run/secretos-locales.env"
      [ -f "$archivo" ] || { echo "ERROR: falta $archivo: levanta primero con scripts/levantar-local.sh" >&2; return 1; }
      ( . "$archivo"; printf '%s' "$SECRETO_TERMINAL" )
    }
    # Un case y no "declare -A": los arreglos asociativos son de bash 4 y macOS trae el 3.2.
    puerto_gestion() {
      case "$1" in
        core-service) echo 8081 ;; bff-web) echo 8082 ;; bff-mobile) echo 8083 ;;
        bff-atm) echo 8084 ;; config-server) echo 8085 ;; eureka-server) echo 8086 ;;
      esac
    }
    core_get() { core_con_token "$(token_servicio "$(cliente_para_ruta "$1")")" "$1"; }
    core_con_token() { curl -s -H "Authorization: Bearer $1" "http://127.0.0.1:8080$2"; }
    core_codigo() {  # core_codigo <token|-> <metodo> <ruta> [cuerpo-json]
      local cab=()
      [ "$1" != "-" ] && cab=(-H "Authorization: Bearer $1")
      if [ "$2" = POST ]; then
        curl -s -o /dev/null -w '%{http_code}' -X POST "${cab[@]+"${cab[@]}"}" -H 'Content-Type: application/json' \
          -H "Idempotency-Key: f4-$$-$(date +%s)" -d "${4:-}" "http://127.0.0.1:8080$3"
      else
        curl -s -o /dev/null -w '%{http_code}' "${cab[@]+"${cab[@]}"}" "http://127.0.0.1:8080$3"
      fi
    }
    gestion() { curl -s "http://127.0.0.1:$(puerto_gestion "$1")$2"; }
    gestion_core_todas() { gestion core-service "$1"; echo; }
    # La base local es el contenedor desechable que levanta scripts/levantar-local.sh (la base se
    # llama siempre "core"; el primer argumento solo existe para igualar la firma de docker).
    sql_postgres() {
      docker exec -e PGPASSWORD="${SPRING_DATASOURCE_PASSWORD:-desarrollo-local}" bancoxyz-postgres-local \
        psql -v ON_ERROR_STOP=1 -q -U core -d core -tA -c "$2"
    }
    gestion_post() { curl -s -X POST "http://127.0.0.1:$(puerto_gestion "$1")$2"; }
    interno_codigo() { curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$2$3"; }
    config_get() { curl -s "http://127.0.0.1:8888$1"; }
    ;;
  *)
    echo "ERROR: ENTORNO debe ser 'docker' o 'local' (vale '$ENTORNO')" >&2
    exit 2
    ;;
esac

curl_bff() { curl -s "${TLS[@]}" "$@"; }

# ---------------------------------------------------------------------
# Tokens de servicio (F4): el core ya no acepta una cabecera fija, exige un token del auth-server
# ---------------------------------------------------------------------
# Scopes que tiene registrados cada cliente (config-repo/auth-server.yml); es lo que se pide por defecto.
scopes_de_cliente() {
  case "$1" in
    bff-web)    echo "cuentas:leer movimientos:leer auditoria:leer" ;;
    bff-mobile) echo "cuentas:leer" ;;
    bff-atm)    echo "saldo:leer retiros:ejecutar" ;;
  esac
}

# Que cliente usaria el sistema para pedir esa ruta del core: el saldo y el retiro son del cajero; el resto
# (cuenta, movimientos, administracion), del BFF web.
cliente_para_ruta() {
  case "$1" in
    */saldo|*/retiros) echo bff-atm ;;
    *)                 echo bff-web ;;
  esac
}

# token_servicio <cliente> [scopes...]: pide un token con client_credentials y client_secret_basic. Imprime solo
# el valor del token. Cada llamada pide uno nuevo (cuesta unos 30 ms): a diferencia de los BFF, que lo guardan en
# memoria y lo reutilizan (TokenServicioInterceptor), aqui no se puede guardar nada entre una llamada y otra
# porque quien la invoca casi siempre lo hace dentro de $(...), un subproceso que olvida lo que asigna.
token_servicio() {
  local cliente="$1"; shift
  local scopes="${*:-$(scopes_de_cliente "$cliente")}"
  local secreto respuesta token
  secreto="$(secreto_cliente "$cliente")" || return 1
  respuesta="$(curl -s "${TLS[@]}" -u "$cliente:$secreto" -d grant_type=client_credentials \
    --data-urlencode "scope=$scopes" "$AUTH_URL/oauth2/token")"
  token="$(printf '%s' "$respuesta" | python3 -c 'import sys,json; print(json.load(sys.stdin).get("access_token",""))' 2> /dev/null)"
  if [ -z "$token" ]; then
    echo "ERROR: el auth-server no entrego un token para $cliente: $respuesta" >&2
    return 1
  fi
  printf '%s' "$token"
}

core_bytes() { core_get "$1" | wc -c | tr -d ' '; }

# La metrica http.server.requests del core para una URI (porcentaje-codificada), SUMADA sobre todas
# las replicas: con dos replicas, los BFF reparten las llamadas y cada una solo cuenta las suyas.
# Devuelve el COUNT acumulado, o 0 si el core aun no recibio ninguna.
contador_core() {
  gestion_core_todas "/actuator/metrics/http.server.requests?tag=uri:$1" 2>/dev/null | python3 -c '
import sys, json
total = 0
for linea in sys.stdin:
    linea = linea.strip()
    if not linea:
        continue
    try:
        d = json.loads(linea)
    except Exception:
        continue
    for m in d.get("measurements", []):
        if m["statistic"] == "COUNT":
            total += int(m["value"])
print(total)'
}

# ---------------------------------------------------------------------
# Herramientas Java de prueba (scripts/FirmarTokenDePrueba.java y GzipCuestaBytes.java)
# ---------------------------------------------------------------------
# Son programas de un solo archivo que necesitan un JDK. Para que Docker sea el UNICO prerrequisito
# del evaluador (como anuncia el README), en ENTORNO=docker se ejecutan DENTRO de un contenedor
# efimero con la imagen bancoxyz/secretos-init, que ya trae el JDK 21 completo y que
# "docker compose up -d --build" deja construida. El contenedor corre sin red, monta scripts/ de
# solo lectura y, para firmar, el volumen de secretos del BFF tambien de solo lectura: la clave
# privada no sale nunca del volumen, ni al host ni a un archivo temporal. En ENTORNO=local se usa
# el java del equipo, que existe por fuerza porque las JVM locales se compilaron con JDK 21.
IMAGEN_HERRAMIENTAS="${IMAGEN_HERRAMIENTAS:-bancoxyz/secretos-init:1.0.0}"

# Los volumenes con nombre de Compose se llaman <proyecto>_<volumen>; el proyecto es "bancoxyz"
# (clave name: de docker-compose.yaml) salvo que alguien lo cambie con COMPOSE_PROJECT_NAME.
volumen_secretos() { echo "${COMPOSE_PROJECT_NAME:-bancoxyz}_secretos-$1"; }

# ---------------------------------------------------------------------
# Archivos del proyecto, con git o sin git.
# El proyecto tambien se recibe como .zip, y una copia descomprimida no tiene .git: ahi "git ls-files" y
# "git grep" fallan con "fatal: not a git repository" y, como no encuentran nada, una comprobacion del tipo
# "ningun secreto en un archivo versionado: 0" pasaria SIN haber mirado ningun archivo. Estas funciones dan la
# misma lista con o sin git para que la comprobacion siempre mire algo, y quien las usa lo dice en su mensaje
# (ver $ORIGEN_ARCHIVOS) y exige que la lista no este vacia.
# Se pregunta por RAIZ/.git y no solo por "git rev-parse": una copia descomprimida DENTRO de otro repositorio
# git (una carpeta de tareas, por ejemplo) hace que git responda por el repositorio de afuera.
# ---------------------------------------------------------------------
if [ -e "$RAIZ/.git" ] && git -C "$RAIZ" rev-parse --git-dir > /dev/null 2>&1; then
  ES_REPOSITORIO_GIT=1
  ORIGEN_ARCHIVOS="archivo versionado por git"
else
  ES_REPOSITORIO_GIT=0
  ORIGEN_ARCHIVOS="archivo de la copia (sin .git: se recorre el arbol, sin target/, run/, certs/, secrets/, respaldos/ ni dist/)"
fi

# Imprime, separadas por NUL y relativas a la raiz, las rutas de los archivos del proyecto.
archivos_del_proyecto() {
  if [ "$ES_REPOSITORIO_GIT" = 1 ]; then
    (cd "$RAIZ" && git ls-files -z)
  else
    (cd "$RAIZ" && find . \( -name .git -o -name target -o -name run -o -name certs -o -name secrets \
      -o -name respaldos -o -name dist -o -name __pycache__ \) -prune -o -type f -print | sed 's#^\./##' | tr '\n' '\0')
  fi
}

# contar_archivos_con <regex extendida> [ruta excluida]...  -> cuantos archivos del proyecto la contienen
# (sin distinguir mayusculas). Una ruta excluida es un archivo o una carpeta, relativa a la raiz.
contar_archivos_con() {
  local patron="$1"; shift
  local excluir="" e
  for e in "$@"; do excluir="$excluir|$(printf '%s' "$e" | sed 's/[][\\.*^$+?(){}|]/\\&/g')"; done
  (cd "$RAIZ" && archivos_del_proyecto | xargs -0 grep -ilE -- "$patron" 2> /dev/null) \
    | if [ -n "$excluir" ]; then grep -vE "^(${excluir#|})(/|\$)"; else cat; fi | grep -c . | tr -d ' '
}

# contar_archivos_con_texto <texto literal>  -> cuantos archivos del proyecto lo contienen (distingue mayusculas).
contar_archivos_con_texto() {
  (cd "$RAIZ" && archivos_del_proyecto | xargs -0 grep -lF -- "$1" 2> /dev/null) | grep -c . | tr -d ' '
}

# Cuantos archivos hay en la lista (para exigir que no este vacia).
contar_archivos_del_proyecto() { archivos_del_proyecto | tr -cd '\0' | wc -c | tr -d ' '; }

# Ruta del equipo en la forma que entiende docker.exe (en Git Bash, C:/...; en macOS y Linux, igual).
ruta_nativa() { if command -v cygpath > /dev/null 2>&1; then cygpath -m "$1"; else echo "$1"; fi; }

# Devuelve 0 si las herramientas Java se pueden ejecutar en este entorno. Quien la llama decide
# como informar su ausencia: no es un fallo del sistema bajo prueba, es una herramienta que falta.
herramientas_java_disponibles() {
  if [ "$ENTORNO" = local ]; then
    command -v java > /dev/null 2>&1
  else
    docker image inspect "$IMAGEN_HERRAMIENTAS" > /dev/null 2>&1
  fi
}

# firmar_token <audiencia> <sub> <cuentaId> <canal> <segundos> <autoridades,por,coma> [claims-extra-json]
# Imprime un JWT con los claims de un token de USUARIO del auth-server (audiencia, canal, cuenta, autoridades y
# los extras que se pidan, por ejemplo '"device_id":"dispositivo-demo-01"' o '"terminal":"ATM-SCL-001"'), FIRMADO
# con la clave real del auth-server (FirmarTokenDePrueba.java). Es la herramienta de evidencia para los casos que
# el auth-server no emite por su cuenta: una cuenta sin credencial sembrada (la 130 o la 999), un token vencido,
# un terminal que no existe. Un token valido de una persona se pide SIEMPRE al auth-server (login-*.sh).
#
# Desde F5 los BFF no tienen clave de firma: la unica clave es la del auth-server, que en docker solo se lee dentro
# de un contenedor efimero sin red que monta su volumen de secretos en solo lectura (no sale nunca del volumen).
# El token no lleva kid: el BFF elige del JWKS la clave por tipo y algoritmo, que con una sola publicada es la
# correcta. segundos negativo = token ya vencido.
firmar_token() {
  local audiencia="$1" sub="$2" cuenta="$3" canal="$4" segundos="$5" autoridades="$6" extra="${7:-}"
  local emisor
  if [ "$ENTORNO" = local ]; then
    emisor="${EMISOR_TOKENS:-http://localhost:9000}"
    java "$RAIZ/scripts/FirmarTokenDePrueba.java" "$RAIZ/auth-server/src/main/resources/secrets/auth-server-private.pem" \
      - "$emisor" "$audiencia" "$sub" "$cuenta" "$canal" "$segundos" "$autoridades" ${extra:+"$extra"}
  else
    emisor="${EMISOR_TOKENS:-https://localhost:9000}"
    docker run --rm --network none --entrypoint java \
      -v "$(ruta_nativa "$RAIZ")/scripts:/herramientas:ro" \
      -v "$(volumen_secretos auth-server):/run/secrets:ro" \
      "$IMAGEN_HERRAMIENTAS" /herramientas/FirmarTokenDePrueba.java /run/secrets/firma/auth-server-private.pem \
      - "$emisor" "$audiencia" "$sub" "$cuenta" "$canal" "$segundos" "$autoridades" ${extra:+"$extra"}
  fi
}

# llamada_interna <argumentos de LlamadaInterna.java...>: ver el encabezado. El contenedor efimero se une a la red
# "interna" del compose (internal: true, sin salida a Internet) y monta el truststore de la CA interna que
# secretos-init dejo en el volumen del core (solo lectura; el contenedor corre como root y puede leer los archivos
# 0400 de dueno 10001, que es lo que un servicio de la red interna NO puede hacer con los de otro).
llamada_interna() {
  docker run --rm --network "${COMPOSE_PROJECT_NAME:-bancoxyz}_interna" --entrypoint sh \
    -v "$(ruta_nativa "$RAIZ")/scripts:/herramientas:ro" \
    -v "$(volumen_secretos core-service):/s:ro" \
    "$IMAGEN_HERRAMIENTAS" -c '
      exec java -Djavax.net.ssl.trustStore=/s/truststore/truststore.p12 -Djavax.net.ssl.trustStoreType=PKCS12 \
        -Djavax.net.ssl.trustStorePassword="$(cat /s/truststore/truststore.password)" \
        /herramientas/LlamadaInterna.java "$@"' _ "$@"
}

# firmar_token_servicio <argumentos de FirmarTokenDeServicio...>: la clave que se pasa en el primer argumento es
# la palabra NUEVA (clave aleatoria, token falsificado) o la clave privada REAL del auth-server, que en docker se
# lee de su volumen de secretos (montado solo lectura en un contenedor efimero y sin red) y en local de
# auth-server/src/main/resources/secrets. En ese caso se pasa la palabra AUTH-SERVER en su lugar.
firmar_token_servicio() {
  local clave="$1"; shift
  if [ "$ENTORNO" = local ]; then
    [ "$clave" = AUTH-SERVER ] && clave="$RAIZ/auth-server/src/main/resources/secrets/auth-server-private.pem"
    java "$RAIZ/scripts/FirmarTokenDeServicio.java" "$clave" "$@"
  else
    [ "$clave" = AUTH-SERVER ] && clave=/run/secrets/firma/auth-server-private.pem
    docker run --rm --network none --entrypoint java \
      -v "$(ruta_nativa "$RAIZ")/scripts:/herramientas:ro" \
      -v "$(volumen_secretos auth-server):/run/secrets:ro" \
      "$IMAGEN_HERRAMIENTAS" /herramientas/FirmarTokenDeServicio.java "$clave" "$@"
  fi
}

# gzip_cuesta_bytes <archivo...>: GzipCuestaBytes sobre archivos que viven TODOS en una misma
# carpeta (en Docker se monta esa carpeta de solo lectura y se pasan los nombres base).
gzip_cuesta_bytes() {
  if [ "$ENTORNO" = local ]; then
    java "$RAIZ/scripts/GzipCuestaBytes.java" "$@"
  else
    local carpeta nombres=() f
    carpeta="$(cd "$(dirname "$1")" && pwd)"
    for f in "$@"; do nombres+=("/datos/$(basename "$f")"); done
    # La carpeta la crea mktemp con modo 0700 y su contenido (cuerpos de respuesta del sistema,
    # sin secretos) tiene que poder leerlo el usuario del contenedor.
    chmod 755 "$carpeta"
    docker run --rm --network none --entrypoint java \
      -v "$(ruta_nativa "$RAIZ")/scripts:/herramientas:ro" \
      -v "$(ruta_nativa "$carpeta"):/datos:ro" \
      "$IMAGEN_HERRAMIENTAS" /herramientas/GzipCuestaBytes.java "${nombres[@]}"
  fi
}
