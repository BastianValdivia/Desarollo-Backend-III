#!/usr/bin/env bash
# =====================================================================
# login-movil.sh: inicio de sesion del canal MOVIL con authorization_code y PKCE, hecho con curl.
# =====================================================================
# Uso:  scripts/login-movil.sh [usuario] [clave] [device_id] [--token]
#
#   Sin argumentos usa cliente116 / Cliente.2026 y el dispositivo dispositivo-demo-01. En el canal movil
#   solo existe cliente116 (cliente105 y ejecutivo1 no tienen canal movil: el servidor no les da codigo).
#   El device_id viaja como parametro adicional de la solicitud de autorizacion y el servidor lo escribe
#   en el claim device_id del token: el token queda atado a ese dispositivo, y el BFF movil lo compara con
#   la cabecera X-Device-Id de cada peticion.
#   --token  imprime SOLO el token de acceso (para usarlo en $(...)).
#
# Los pasos del flujo estan explicados en scripts/lib-login.sh. Una vez con el token:
#   curl --cacert certs/ca.crt -H "Authorization: Bearer $TOKEN" -H "X-Device-Id: dispositivo-demo-01" \
#        https://localhost:8444/api/mobile/v1/cuentas/116/resumen
# =====================================================================
set -uo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib-entorno.sh
. "$DIR/lib-entorno.sh"
# shellcheck source=lib-login.sh
. "$DIR/lib-login.sh"

SOLO_TOKEN=0; ARGS=()
for a in "$@"; do if [ "$a" = "--token" ]; then SOLO_TOKEN=1; else ARGS+=("$a"); fi; done
USUARIO="${ARGS[0]:-cliente116}"
CLAVE="${ARGS[1]:-$([ "$USUARIO" = ejecutivo1 ] && echo Exec.2026 || echo Cliente.2026)}"
DISPOSITIVO="${ARGS[2]:-dispositivo-demo-01}"

if [ "$SOLO_TOKEN" = 1 ]; then
  token_movil "$USUARIO" "$CLAVE" "$DISPOSITIVO"
  exit $?
fi

LOGIN_VERBOSO=1
echo "== Login movil: usuario $USUARIO, dispositivo $DISPOSITIVO, cliente mobile-app (publico, PKCE), auth-server $AUTH_URL =="
JSON="$(login_pkce mobile-app "$REDIRECT_MOVIL" "$USUARIO" "$CLAVE" "device_id=$DISPOSITIVO")" || exit 1
TOKEN="$(printf '%s' "$JSON" | access_token_de)"
if [ -z "$TOKEN" ]; then echo "ERROR: sin token: $JSON" >&2; exit 1; fi
echo
echo "Respuesta del endpoint de tokens (el valor del token se abrevia):"
printf '%s' "$JSON" | python3 -c 'import sys,json; d=json.load(sys.stdin); d["access_token"]=d["access_token"][:24]+"..."; print(json.dumps(d))'
echo
echo "Claims del token (se leen sin clave porque un JWT esta firmado, no cifrado):"
python3 "$DIR/ver-token.py" "$TOKEN"
