#!/usr/bin/env bash
# =====================================================================
# medir-arranque.sh: cuanto tarda el stack en quedar sano.
# =====================================================================
# Desde F8 la medicion completa (arranque, pero tambien tamano de imagen, memoria en reposo y limites de cada
# servicio) vive en scripts/medir-despliegue.sh, que conoce todos los servicios del compose (esta version de F2 solo
# conocia ocho y no esperaba a Kafka, al auth-server ni a los consumidores). Este guion se conserva con su nombre y sus
# opciones porque la documentacion lo cita:
#
#   scripts/medir-arranque.sh           arranque con los volumenes de secretos existentes
#   scripts/medir-arranque.sh --frio    antes, "docker compose down -v" (arranque en frio de verdad)
#
# Imprime la misma tabla que medir-despliegue.sh (la columna "Listo a los (s)" es el segundo, desde "docker compose up -d",
# en que quedo listo cada servicio; "Arranque app" es lo que dice Spring Boot de si mismo). Sin reposo previo a la lectura
# de la memoria: para eso, usar medir-despliegue.sh directamente.
# =====================================================================
exec bash "$(dirname "${BASH_SOURCE[0]}")/medir-despliegue.sh" --reposo 0 "$@"
