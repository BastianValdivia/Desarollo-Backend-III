#!/usr/bin/env bash
# =====================================================================
# evidencia-microservicio.sh: la evidencia de ejecucion de UN microservicio, como la piden las instrucciones
# de la actividad ("capturas de pantalla o salidas de consola mostrando la ejecucion de cada microservicio y los
# resultados generados").
# =====================================================================
# Uso:  scripts/evidencia-microservicio.sh <servicio>
#       servicio: config-server | eureka-server | auth-server | core-service | bff-web | bff-mobile | bff-atm |
#                 notificaciones-service | auditoria-service
#
# Imprime tres bloques por servicio, cada uno con comprobaciones PASS o FAIL sobre el dato real:
#   1. ARRANQUE   imagen y usuario, estado, instante de inicio, reinicios y la linea "Started ... in N seconds"
#                 del propio registro del servicio (una por replica).
#   2. SALUD      el HEALTHCHECK de Docker, /actuator/health del puerto de gestion y, si el servicio es cliente
#                 de Eureka, su registro (instancias y estado).
#   3. RESULTADO  una operacion propia del servicio, de verdad, con su respuesta literal: la configuracion que
#                 entrega el config-server, los servicios que lista Eureka, el token y el descubrimiento OIDC del
#                 auth-server, una cuenta del core leida de PostgreSQL, el login y una consulta de cada canal, un
#                 retiro del cajero y el evento que provoca en notificaciones y en auditoria.
# El codigo de salida es 0 solo si todas las comprobaciones pasan.
#
# Orden recomendado (verificar.sh lo respeta): los consumidores van DESPUES del cajero, porque su resultado es el
# evento del retiro que el cajero acaba de hacer. El retiro se deshace con scripts/restablecer-demo.sh.
#
# Portabilidad: bash 3.2 (macOS) y Git Bash; requiere docker, curl y python3. Solo ENTORNO=docker.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
SERVICIO="${1:-}"
case "$SERVICIO" in
  config-server|eureka-server|auth-server|core-service|bff-web|bff-mobile|bff-atm|notificaciones-service|auditoria-service) ;;
  *) echo "Uso: $0 <config-server|eureka-server|auth-server|core-service|bff-web|bff-mobile|bff-atm|notificaciones-service|auditoria-service>" >&2; exit 2 ;;
esac
if [ "${ENTORNO:-docker}" != docker ]; then
  echo "ERROR: evidencia-microservicio.sh corre contra los contenedores (ENTORNO=docker)." >&2
  exit 2
fi
source "$RAIZ/scripts/lib-entorno.sh"
source "$RAIZ/scripts/lib-login.sh"
source "$RAIZ/scripts/lib-kafka.sh"

FALLOS=0
TOTAL=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() {  # igual <descripcion> <esperado> <obtenido>
  if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi
}
mayor_o_igual() {  # mayor_o_igual <descripcion> <minimo> <obtenido>
  if [ "$3" -ge "$2" ] 2> /dev/null; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado >= $2, obtenido '$3'"; fi
}
json() { python3 -c "import sys,json; d=json.load(sys.stdin); print($1)" 2> /dev/null; }
sql_n() { sql_postgres "$1" "$2" 2> /dev/null | tr -d '[:space:]'; }
cids() { "${COMPOSE[@]}" ps -a -q "$SERVICIO"; }
claim() {  # claim <token> <nombre>
  python3 -c "
import base64,json,sys
p=sys.argv[1].split('.')[1]; p+='='*(-len(p)%4)
print(json.loads(base64.urlsafe_b64decode(p)).get(sys.argv[2]))" "$1" "$2"
}
# La audiencia puede ser un texto o una lista: se normaliza a "a,b" (ordenada).
audiencia() {  # audiencia <token>
  python3 -c "
import base64,json,sys
p=sys.argv[1].split('.')[1]; p+='='*(-len(p)%4)
a=json.loads(base64.urlsafe_b64decode(p)).get('aud', [])
print(','.join(sorted([a] if isinstance(a, str) else a)))" "$1"
}
mostrar() { sed 's/^/    /'; }

echo "################ $SERVICIO ################"
echo "fecha: $(date -u '+%Y-%m-%dT%H:%M:%SZ')   imagen esperada: bancoxyz/$SERVICIO:1.0.0"

# ---------------------------------------------------------------------
echo
echo "== 1. ARRANQUE =="
# ---------------------------------------------------------------------
echo "\$ docker compose ps $SERVICIO"
"${COMPOSE[@]}" ps "$SERVICIO" | mostrar
N=0
for id in $(cids); do
  N=$((N + 1))
  nombre="$(docker inspect -f '{{.Name}}' "$id" | sed 's#^/##')"
  echo "\$ docker inspect $nombre"
  docker inspect -f 'estado={{.State.Status}} iniciado={{.State.StartedAt}} reinicios={{.RestartCount}} usuario={{.Config.User}} imagen={{.Config.Image}}' "$id" | mostrar
  echo "\$ docker logs $nombre | grep 'Started .* in'"
  linea="$(docker logs "$id" 2>&1 | grep -E 'Started [A-Za-z0-9_]+ in [0-9.]+ seconds' | tail -n 1)"
  echo "    $linea"
  igual "$nombre: en ejecucion, sin reinicios y con la imagen del proyecto" "running 0 bancoxyz/$SERVICIO:1.0.0" \
    "$(docker inspect -f '{{.State.Status}} {{.RestartCount}} {{.Config.Image}}' "$id")"
  [ -n "$linea" ] && resultado PASS "$nombre: el registro de Spring Boot informa 'Started ... in N seconds'" || resultado FAIL "$nombre: sin linea 'Started'"
done
case "$SERVICIO" in
  core-service|notificaciones-service) igual "replicas en ejecucion" 2 "$N" ;;
  *) igual "replicas en ejecucion" 1 "$N" ;;
esac

# ---------------------------------------------------------------------
echo
echo "== 2. SALUD =="
# ---------------------------------------------------------------------
for id in $(cids); do
  nombre="$(docker inspect -f '{{.Name}}' "$id" | sed 's#^/##')"
  echo "\$ docker inspect -f '{{.State.Health.Status}}' $nombre"
  igual "$nombre: HEALTHCHECK de Docker" healthy "$(docker inspect -f '{{.State.Health.Status}}' "$id")"
  echo "\$ docker exec $nombre wget -qO- http://127.0.0.1:8081/actuator/health"
  salud="$(docker exec "$id" wget -qO- http://127.0.0.1:8081/actuator/health 2> /dev/null)"
  echo "    $salud"
  igual "$nombre: /actuator/health del puerto de gestion" UP "$(echo "$salud" | json "d['status']")"
done
case "$SERVICIO" in
  config-server|eureka-server) echo "  (no es cliente de Eureka: no se registra)" ;;
  *)
    NOMBRE_EUREKA="$(echo "$SERVICIO" | tr 'a-z' 'A-Z')"
    echo "\$ curl -s -H 'Accept: application/json' http://localhost:8761/eureka/apps/$NOMBRE_EUREKA"
    apps="$(curl -s -H 'Accept: application/json' "http://localhost:8761/eureka/apps/$NOMBRE_EUREKA")"
    echo "$apps" | python3 -c '
import sys, json
d = json.load(sys.stdin)["application"]
for i in d["instance"]:
    print("    instancia {}  ip {}  estado {}".format(i["instanceId"], i["ipAddr"], i["status"]))' 2> /dev/null
    esperadas=1; case "$SERVICIO" in core-service|notificaciones-service) esperadas=2 ;; esac
    igual "Eureka: instancias UP de $SERVICIO" "$(python3 -c "print(' '.join(['UP'] * $esperadas))")" \
      "$(echo "$apps" | json "' '.join(i['status'] for i in d['application']['instance'])")"
    ;;
esac

# ---------------------------------------------------------------------
echo
echo "== 3. RESULTADO =="
# ---------------------------------------------------------------------
case "$SERVICIO" in

  config-server)
    echo "\$ GET http://config-server:8888/bff-web/docker,demo,bff   (dentro de la red interna)"
    cfg="$(config_get /bff-web/docker,demo,bff)"
    echo "$cfg" | python3 -c '
import sys, json
d = json.load(sys.stdin)
print("    name={} profiles={}".format(d["name"], d["profiles"]))
for p in d["propertySources"]:
    print("    fuente: {}  ({} propiedades)".format(p["name"].split("/config-repo/")[-1], len(p["source"])))' | head -20
    mayor_o_igual "el config-server entrega al menos 5 fuentes de configuracion para bff-web (comun, servicio y perfiles)" 5 \
      "$(echo "$cfg" | json "len(d['propertySources'])")"
    igual "la configuracion de bff-web trae el core por su nombre logico (core.base-url)" "http://core-service" \
      "$(echo "$cfg" | json "[v for p in d['propertySources'] for k,v in p['source'].items() if k=='core.base-url'][0]")"
    ;;

  eureka-server)
    echo "\$ curl -s -H 'Accept: application/json' http://localhost:8761/eureka/apps"
    apps="$(curl -s -H 'Accept: application/json' http://localhost:8761/eureka/apps)"
    echo "$apps" | python3 -c '
import sys, json
for a in json.load(sys.stdin)["applications"]["application"]:
    print("    {:24} {} instancia(s): {}".format(a["name"], len(a["instance"]), ", ".join(sorted(set(i["status"] for i in a["instance"])))))'
    igual "Eureka registra los 7 servicios clientes (auth, core, 3 BFF, notificaciones y auditoria)" 7 "$(echo "$apps" | json "len(d['applications']['application'])")"
    igual "todas las instancias estan UP" "" "$(echo "$apps" | json "' '.join(i['instanceId'] for a in d['applications']['application'] for i in a['instance'] if i['status']!='UP')")"
    mayor_o_igual "instancias totales (core x2, notificaciones x2 y los demas)" 9 "$(echo "$apps" | json "sum(len(a['instance']) for a in d['applications']['application'])")"
    echo "\$ curl -s -o /dev/null -w '%{http_code}' http://localhost:8761/   (el dashboard, solo en 127.0.0.1)"
    igual "el dashboard de Eureka responde 200" 200 "$(curl -s -o /dev/null -w '%{http_code}' http://localhost:8761/)"
    ;;

  auth-server)
    echo "\$ curl --cacert certs/ca.crt https://localhost:9000/.well-known/openid-configuration"
    oidc="$(curl -s "${TLS[@]}" "$AUTH_URL/.well-known/openid-configuration")"
    echo "$oidc" | python3 -c '
import sys, json
d = json.load(sys.stdin)
for k in ("issuer", "authorization_endpoint", "token_endpoint", "jwks_uri", "grant_types_supported", "code_challenge_methods_supported"):
    print("    {}: {}".format(k, d.get(k)))'
    igual "emisor fijo del auth-server" "https://localhost:9000" "$(echo "$oidc" | json "d['issuer']")"
    igual "PKCE con S256 anunciado" True "$(echo "$oidc" | json "'S256' in d['code_challenge_methods_supported']")"
    echo "\$ curl --cacert certs/ca.crt https://localhost:9000/oauth2/jwks"
    jwks="$(curl -s "${TLS[@]}" "$AUTH_URL/oauth2/jwks")"
    echo "$jwks" | python3 -c '
import sys, json
for k in json.load(sys.stdin)["keys"]:
    print("    clave publica: kty={} alg={} use={} kid={}".format(k["kty"], k.get("alg"), k.get("use"), k["kid"]))'
    mayor_o_igual "el JWKS publica al menos una clave RSA" 1 "$(echo "$jwks" | json "len(d['keys'])")"
    echo "\$ POST /oauth2/token grant_type=client_credentials (cliente bff-atm, secreto leido del volumen)"
    TS="$(token_servicio bff-atm)"
    echo "    claim iss: $(claim "$TS" iss)"; echo "    claim aud: $(audiencia "$TS")"; echo "    claim scope: $(claim "$TS" scope)"
    echo "    vigencia (exp - iat): $(( $(claim "$TS" exp) - $(claim "$TS" iat) )) s"
    igual "token de servicio del BFF del cajero: audiencia core-service" "core-service" "$(audiencia "$TS")"
    igual "...vigencia de 300 s" 300 "$(( $(claim "$TS" exp) - $(claim "$TS" iat) ))"
    echo "\$ POST /oauth2/token con un secreto de cliente incorrecto"
    c="$(curl -s -o /dev/null -w '%{http_code}' "${TLS[@]}" -u "bff-atm:incorrecto" -d grant_type=client_credentials "$AUTH_URL/oauth2/token")"
    igual "un secreto de cliente incorrecto da 401" 401 "$c"
    ;;

  core-service)
    echo "\$ GET http://core-service:8080/internal/v1/cuentas/116   (desde dentro de la red interna, con un token OAuth2 de servicio)"
    cuenta="$(core_get /internal/v1/cuentas/116)"
    echo "    $cuenta" | cut -c1-600
    igual "la cuenta 116 se lee del core (cuentaId)" 116 "$(echo "$cuenta" | json "d.get('cuentaId', d.get('id'))")"
    echo "\$ psql core: estado persistido en PostgreSQL"
    echo "    cuentas: $(sql_n core 'SELECT count(*) FROM cuenta')   movimientos de la carga: $(sql_n core "SELECT count(*) FROM movimiento WHERE origen <> 'RETIRO_ATM'")"
    igual "la base 'core' tiene las 50 cuentas de la carga" 50 "$(sql_n core 'SELECT count(*) FROM cuenta')"
    igual "...y los 686 movimientos de la carga" 686 "$(sql_n core "SELECT count(*) FROM movimiento WHERE origen <> 'RETIRO_ATM'")"
    echo "\$ psql core: migraciones de Flyway aplicadas"
    sql_postgres core "SELECT version || ' ' || description || ' ' || success FROM flyway_schema_history ORDER BY installed_rank" | mostrar
    igual "Flyway: todas las migraciones aplicadas con exito" 0 "$(sql_n core 'SELECT count(*) FROM flyway_schema_history WHERE NOT success')"
    echo "\$ el core autentica con OAuth2: sin token 401, con token sin el scope 403"
    igual "sin token: 401" 401 "$(core_codigo - GET /internal/v1/cuentas/116)"
    igual "token del BFF movil (solo cuentas:leer) pidiendo el saldo del cajero: 403" 403 \
      "$(core_codigo "$(token_servicio bff-mobile)" GET /internal/v1/cuentas/116/saldo)"
    echo "\$ cada peticion deja su linea 'atendida por la instancia <id>' (reparto entre las dos replicas)"
    for id in $(cids); do
      echo "    $(docker inspect -f '{{.Name}}' "$id" | sed 's#^/##'): $(docker logs "$id" 2>&1 | grep -c 'atendida por la instancia') peticiones atendidas (ultima: $(docker logs "$id" 2>&1 | grep 'atendida por la instancia' | tail -n 1 | sed 's/^.*GET/GET/' | cut -c1-100))"
    done
    ;;

  bff-web)
    echo "\$ login web (authorization_code + PKCE contra el auth-server) y GET $WEB/v1/cuentas/116"
    T="$(token_web cliente116 Cliente.2026)"
    echo "    claims: sub=$(claim "$T" sub) aud=$(audiencia "$T") scope=$(claim "$T" scope) vigencia=$(( $(claim "$T" exp) - $(claim "$T" iat) )) s"
    cuerpo="$(curl_bff -w '\n%{http_code}' "$WEB/v1/cuentas/116" -H "Authorization: Bearer $T")"
    echo "    HTTP $(printf '%s\n' "$cuerpo" | tail -n 1)"
    printf '%s\n' "$cuerpo" | sed '$d' | cut -c1-500 | mostrar
    igual "GET /v1/cuentas/116 con el token del cliente116" 200 "$(printf '%s\n' "$cuerpo" | tail -n 1)"
    igual "sin token: 401" 401 "$(curl_bff -o /dev/null -w '%{http_code}' "$WEB/v1/cuentas/116")"
    igual "la cuenta de otro titular (105): 403" 403 "$(curl_bff -o /dev/null -w '%{http_code}' "$WEB/v1/cuentas/105" -H "Authorization: Bearer $T")"
    echo "\$ panel del ejecutivo: GET $WEB/v1/admin/panel (ejecutivo1)"
    TE="$(token_web ejecutivo1 Exec.2026)"
    panel="$(curl_bff "$WEB/v1/admin/panel" -H "Authorization: Bearer $TE")"
    echo "$panel" | cut -c1-500 | mostrar
    igual "panel del ejecutivo: calidad de datos disponible" True "$(echo "$panel" | json "d['calidadDatos']['disponible']")"
    echo "\$ Resilience4j del BFF web (puerto de gestion)"
    gestion bff-web /actuator/circuitbreakers | python3 -c '
import sys, json
for n, c in sorted(json.load(sys.stdin)["circuitBreakers"].items()):
    print("    circuito {}: {}".format(n, c["state"]))'
    igual "circuito 'core' CLOSED" CLOSED "$(gestion bff-web /actuator/circuitbreakers | json "d['circuitBreakers']['core']['state']")"
    ;;

  bff-mobile)
    echo "\$ login movil (authorization_code + PKCE, con device_id) y GET $MOVIL/v1/cuentas/116/resumen"
    T="$(token_movil cliente116 Cliente.2026 dispositivo-demo-01)"
    echo "    claims: sub=$(claim "$T" sub) aud=$(audiencia "$T") device_id=$(claim "$T" device_id) vigencia=$(( $(claim "$T" exp) - $(claim "$T" iat) )) s"
    cuerpo="$(curl_bff -w '\n%{http_code}' "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $T" -H 'X-Device-Id: dispositivo-demo-01')"
    echo "    HTTP $(printf '%s\n' "$cuerpo" | tail -n 1)"
    printf '%s\n' "$cuerpo" | sed '$d' | cut -c1-500 | mostrar
    igual "resumen de la cuenta 116 con el dispositivo del token" 200 "$(printf '%s\n' "$cuerpo" | tail -n 1)"
    igual "el mismo token desde otro dispositivo: 401" 401 \
      "$(curl_bff -o /dev/null -w '%{http_code}' "$MOVIL/v1/cuentas/116/resumen" -H "Authorization: Bearer $T" -H 'X-Device-Id: telefono-robado-99')"
    igual "vigencia del token movil: 3600 s" 3600 "$(( $(claim "$T" exp) - $(claim "$T" iat) ))"
    igual "circuito 'core' CLOSED" CLOSED "$(gestion bff-mobile /actuator/circuitbreakers | json "d['circuitBreakers']['core']['state']")"
    ;;

  bff-atm)
    echo "\$ login del cajero (grant tarjeta y PIN, terminal atm-scl-001) y consulta de saldo"
    T="$(token_cajero 4000000000000116 1234)"
    echo "    claims: sub=$(claim "$T" sub) aud=$(audiencia "$T") terminal=$(claim "$T" terminal) vigencia=$(( $(claim "$T" exp) - $(claim "$T" iat) )) s"
    saldo="$(curl_bff -w '\n%{http_code}' "$ATM/v1/cuentas/116/saldo-disponible" -H "Authorization: Bearer $T")"
    echo "    saldo: HTTP $(printf '%s\n' "$saldo" | tail -n 1)  $(printf '%s\n' "$saldo" | sed '$d' | cut -c1-300)"
    igual "saldo disponible de la cuenta 116" 200 "$(printf '%s\n' "$saldo" | tail -n 1)"
    CLAVE="evidencia-$(date +%s)"
    echo "\$ POST $ATM/v1/cuentas/116/retiros  (Idempotency-Key: $CLAVE, monto 1000)"
    r1="$(curl_bff -w '\n%{http_code}' -X POST "$ATM/v1/cuentas/116/retiros" -H "Authorization: Bearer $T" -H 'Content-Type: application/json' -H "Idempotency-Key: $CLAVE" -d '{"monto":1000}')"
    echo "    HTTP $(printf '%s\n' "$r1" | tail -n 1)  $(printf '%s\n' "$r1" | sed '$d' | cut -c1-400)"
    FOLIO="$(printf '%s\n' "$r1" | sed '$d' | json "d['folio']")"
    igual "retiro de 1000: 201 o 200 con folio" "yes" "$([ -n "$FOLIO" ] && echo yes || echo no)"
    r2="$(curl_bff -X POST "$ATM/v1/cuentas/116/retiros" -H "Authorization: Bearer $T" -H 'Content-Type: application/json' -H "Idempotency-Key: $CLAVE" -d '{"monto":1000}')"
    echo "\$ el mismo POST repetido (reintento): folio $(echo "$r2" | json "d['folio']")"
    igual "el reintento con la misma Idempotency-Key devuelve el mismo folio (no descuenta dos veces)" "$FOLIO" "$(echo "$r2" | json "d['folio']")"
    igual "vigencia del token del cajero: 180 s" 180 "$(( $(claim "$T" exp) - $(claim "$T" iat) ))"
    igual "sin token: 401" 401 "$(curl_bff -o /dev/null -w '%{http_code}' "$ATM/v1/cuentas/116/saldo-disponible")"
    igual "circuito 'core' CLOSED" CLOSED "$(gestion bff-atm /actuator/circuitbreakers | json "d['circuitBreakers']['core']['state']")"
    ;;

  notificaciones-service)
    echo "\$ psql notificaciones: ultimas notificaciones (resultado de procesar los eventos de Kafka)"
    sql_postgres notificaciones "SELECT id || ' | ' || tipo || ' | ' || canal || ' | ' || estado || ' | ' || left(mensaje, 90) FROM notificacion ORDER BY id DESC LIMIT 3" | mostrar
    mayor_o_igual "notificaciones guardadas (>= 1: el retiro del cajero)" 1 "$(sql_n notificaciones 'SELECT count(*) FROM notificacion')"
    igual "idempotencia: ninguna notificacion sin su evento_procesado" 0 \
      "$(sql_n notificaciones 'SELECT count(*) FROM notificacion n LEFT JOIN evento_procesado e ON e.event_id = n.event_id WHERE e.event_id IS NULL')"
    echo "\$ kafka-consumer-groups --describe --group notificaciones (extracto)"
    describir_grupo notificaciones | awk '/^GROUP/ || $2 ~ /^bancoxyz\.(retiros|seguridad)\.v1$/ { print "    " $0 }'
    REPARTO="$(particiones_por_cliente notificaciones '^bancoxyz\.(retiros|seguridad)\.v1$')"
    igual "las dos replicas son consumidores distintos del grupo" 2 "$(echo "$REPARTO" | grep -c .)"
    igual "se reparten las 6 particiones (3 por topico)" 6 "$(echo "$REPARTO" | awk '{s += $2} END {print s + 0}')"
    echo "\$ circuitos de la pasarela simulada (Resilience4j, puerto de gestion)"
    gestion notificaciones-service /actuator/circuitbreakers | python3 -c '
import sys, json
for n, c in sorted(json.load(sys.stdin)["circuitBreakers"].items()):
    print("    circuito {}: {}".format(n, c["state"]))'
    igual "circuito de la pasarela CLOSED" CLOSED "$(gestion notificaciones-service /actuator/circuitbreakers | json "d['circuitBreakers']['pasarela']['state']")"
    ;;

  auditoria-service)
    echo "\$ psql auditoria: eventos auditados por tipo"
    sql_postgres auditoria "SELECT tipo || ': ' || count(*) FROM evento_auditado GROUP BY tipo ORDER BY tipo" | mostrar
    mayor_o_igual "eventos auditados (>= 1: el retiro del cajero)" 1 "$(sql_n auditoria 'SELECT count(*) FROM evento_auditado')"
    echo "\$ GET http://auditoria-service:8110/internal/v1/auditoria/resumen   (token del BFF web con auditoria:leer)"
    TS="$(token_servicio bff-web)"
    resp="$(llamada_interna GET http://auditoria-service:8110/internal/v1/auditoria/resumen --bearer "$TS" 2> /dev/null)"
    echo "$resp" | mostrar | cut -c1-400
    igual "la API de auditoria responde 200 con el scope auditoria:leer" 200 "$(echo "$resp" | head -n 1 | awk '{print $2}')"
    igual "sin token la API responde 401" 401 "$(llamada_interna GET http://auditoria-service:8110/internal/v1/auditoria/resumen 2> /dev/null | head -n 1 | awk '{print $2}')"
    echo "\$ kafka-consumer-groups --describe --group auditoria (extracto)"
    describir_grupo auditoria | awk '/^GROUP/ || $2 ~ /^bancoxyz\.(retiros|seguridad)\.v1$/ { print "    " $0 }'
    igual "el grupo auditoria no tiene lag" 0 "$(lag_del_grupo auditoria '^bancoxyz\.(retiros|seguridad)\.v1$')"
    ;;
esac

echo
echo "RESULTADO $SERVICIO: $TOTAL comprobaciones, $FALLOS FAIL"
[ "$FALLOS" = 0 ] && echo "todo PASS" || echo "HAY FALLOS"
exit $((FALLOS > 0))
