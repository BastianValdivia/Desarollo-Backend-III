#!/usr/bin/env bash
# =====================================================================
# generar-secretos.sh: todo el material criptografico del proyecto.
# =====================================================================
#
# QUE HACE
# --------
# Por cada uno de los tres canales (bff-web, bff-mobile, bff-atm) deja dos
# archivos dentro de <canal>/src/main/resources/secrets/ :
#
#   <canal>.p12           Keystore PKCS12 con la clave y el certificado TLS del canal.
#                         Es lo que Tomcat presenta al navegador en el saludo inicial
#                         de HTTPS. Lo genera keytool.
#   <canal>.crt           El certificado publico solo, en texto. No es secreto: es la
#                         mitad que se entrega a cualquiera que se conecte. Sirve para
#                         "curl --cacert <canal>.crt", que verifica de verdad en vez de
#                         saltarse la verificacion como hace "curl -k".
#
# Y en auth-server/src/main/resources/secrets/ el par RSA de FIRMA de tokens
# (auth-server-private.pem y auth-server-public.pem): el unico del sistema.
#
# LOS CANALES YA NO TIENEN CLAVE DE FIRMA (F5)
# --------------------------------------------
# Hasta F4 cada canal tenia ademas su propio par RSA (<canal>-private.pem y
# <canal>-public.pem), porque cada BFF emitia y validaba sus propios tokens. Desde F5 el
# unico emisor es el auth-server: los canales solo VALIDAN, con la clave publica que
# este publica en /oauth2/jwks. Este script ya no genera esos pares, y si encuentra los
# de una ejecucion anterior los retira (una clave privada de firma que nadie usa es
# superficie de ataque sin ningun beneficio).
#
# TLS Y FIRMA SON DOS COSAS DISTINTAS Y SE GUARDAN SEPARADAS
# ----------------------------------------------------------
#   TLS (el .p12)  protege el TRANSPORTE. Responde a "nadie en la red puede leer ni
#                  alterar lo que viaja entre el cliente y este canal".
#   Firma (el PEM) protege una AFIRMACION. Responde a "este token lo emitio el
#                  auth-server y nadie lo ha modificado despues".
#
# Una clave criptografica debe tener un proposito unico. Ademas tienen ciclos de vida
# distintos: renovar un certificado TLS que caduca no deberia invalidar de golpe todos
# los tokens en circulacion, y eso solo se cumple si las claves estan separadas.
#
# POR QUE UN CERTIFICADO POR CANAL Y NO UNO COMPARTIDO
# ---------------------------------------------------
# Porque los tres BFF son tres servicios independientes, y compartir material
# criptografico entre ellos contradiria esa independencia. Cada certificado lleva su
# propio CN (CN=bff-web, CN=bff-mobile, CN=bff-atm), de modo que un "keytool -list -v"
# sobre los tres keystores muestra tres identidades distintas.
#
# POR QUE NO SE USA openssl EN NINGUN PASO
# ----------------------------------------
# Porque el proyecto declara un unico prerrequisito: el JDK 21. openssl no viene ni con
# Windows ni con el JDK. Como los secretos no se versionan (ver abajo), quien clone el
# repositorio tiene que poder generarlos; si la unica via dependiera de una herramienta
# que no tiene, no podria levantar absolutamente nada. Aqui solo se usan keytool y java,
# que estan dentro del JDK.
#
# POR QUE ESTOS ARCHIVOS NO SE VERSIONAN
# --------------------------------------
# Una clave privada subida a un repositorio queda en el historial de Git de forma
# permanente, aunque despues se borre el archivo. En un repositorio publico eso es un
# incidente de seguridad real, no una formalidad. El .gitignore excluye .p12, .crt, .pem,
# .jks y .key; lo unico versionado de estas carpetas es un .gitkeep, para que la ruta
# exista en un clon recien hecho y este script tenga donde escribir.
#
# USO
# ---
#   scripts/generar-secretos.sh              genera lo que falte y conserva lo que exista
#   scripts/generar-secretos.sh --forzar     borra lo existente y lo regenera
#
# Es idempotente: ejecutarlo dos veces seguidas no cambia nada y lo dice archivo por
# archivo. Regenerar por accidente la clave de firma del auth-server invalidaria todos los
# tokens, y el sintoma (401 de pronto, en todas partes) no apunta a la causa.

# REGLA OPERATIVA DEL PROYECTO, PRIMERA LINEA DE TODO SCRIPT.
# En este entorno la variable JAVA_TOOL_OPTIONS esta fijada, y con ella toda invocacion
# de java, keytool, jps o mvn imprime en la salida de error una linea de unos 900
# caracteres que incluye una contrasena de truststore. Esa linea contaminaria la salida
# de este script, que es justamente el que genera los secretos.
unset JAVA_TOOL_OPTIONS

# -e  aborta al primer comando que falle. En un generador de secretos esto no es opcional:
#     seguir adelante tras un fallo dejaria material a medias, que es peor que no tener
#     ninguno porque el servicio arranca y falla mas tarde, lejos de la causa.
# -u  aborta si se usa una variable no definida, que es como se cuela un nombre de archivo
#     vacio y se termina escribiendo en una ruta equivocada.
# -o pipefail  hace que una tuberia falle si falla cualquier tramo, no solo el ultimo.
set -euo pipefail

# Salida de keytool en ingles y sin sorpresas de configuracion regional. Lo que este
# script imprime es evidencia del proyecto y debe verse igual en cualquier maquina.
export LC_ALL=C

# ---------------------------------------------------------------------
# Rutas y parametros
# ---------------------------------------------------------------------

# La raiz del repositorio se deduce de la ubicacion de este archivo, nunca del directorio
# desde el que se invoca. Asi "scripts/generar-secretos.sh" y "./generar-secretos.sh"
# desde dentro de scripts/ hacen exactamente lo mismo.
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# FUENTE UNICA DE CANALES de este script. El nombre del canal es a la vez el nombre del
# modulo Maven, el alias dentro del keystore, el CN del certificado y el prefijo de los
# cuatro archivos. Que sea un solo literal es lo que impide que el alias y el
# server.ssl.key-alias del YAML se separen sin que nadie lo note.
CANALES=(bff-web bff-mobile bff-atm)

# Validez del certificado en dias. 3650 son diez anos.
#
# Un certificado autofirmado de desarrollo con validez corta es una bomba de relojeria:
# el dia que caduca, el handshake TLS empieza a fallar en una maquina donde "no se toco
# nada", y el mensaje de error habla de la cadena de confianza y no de la fecha. En
# produccion la cifra seria la contraria (certificados cortos, renovados de forma
# automatica por la autoridad que los firma), precisamente porque alli si hay quien los
# renueve.
VALIDEZ_DIAS=3650

# Longitud de la clave RSA del certificado TLS. Misma cifra que la clave de firma.
TAMANO_CLAVE=2048

# Contrasena por defecto del keystore. Lleva la palabra "produccion" dentro a proposito:
# si alguna vez aparece en un log o en una evidencia, salta a la vista que no es un
# secreto real.
#
# Cada canal puede sobreescribirla con su propia variable de entorno
# (BFF_WEB_KEYSTORE_PASSWORD, BFF_MOBILE_KEYSTORE_PASSWORD, BFF_ATM_KEYSTORE_PASSWORD),
# que son exactamente los mismos nombres que lee el application.yml de cada BFF. De ese
# modo, cambiar la contrasena de verdad es exportar una variable antes de generar y antes
# de arrancar, sin editar ni un archivo. En produccion no habria valor por defecto y el
# material vendria de un gestor de secretos.
CLAVE_POR_DEFECTO="cambiar-en-produccion"

# ---------------------------------------------------------------------
# Argumentos
# ---------------------------------------------------------------------

FORZAR=false
case "${1:-}" in
  --forzar) FORZAR=true ;;
  "")       ;;
  *)        echo "Uso: $(basename "$0") [--forzar]" >&2; exit 2 ;;
esac

# Contadores para el resumen final. Un script que genera secretos tiene que decir con
# precision que toco y que no: "listo" no es una respuesta cuando lo que esta en juego
# es si el servicio va a encontrar su clave.
CREADOS=0
CONSERVADOS=0

# ---------------------------------------------------------------------
# Comprobaciones previas
# ---------------------------------------------------------------------

# Fallar aqui, con un mensaje que nombra la herramienta que falta, es mucho mejor que
# fallar a mitad de la generacion con un "command not found" suelto.
for herramienta in keytool java; do
  if ! command -v "$herramienta" >/dev/null 2>&1; then
    echo "ERROR: no se encuentra '$herramienta'. Instala el JDK 21 y vuelve a intentarlo." >&2
    exit 1
  fi
done

echo "Generando material criptografico del proyecto"
echo "Raiz: $RAIZ"
if $FORZAR; then
  echo "Modo: --forzar (se borra y se regenera todo)"
else
  echo "Modo: conservador (no se pisa nada que ya exista)"
fi
echo

# ---------------------------------------------------------------------
# Generacion, canal por canal
# ---------------------------------------------------------------------

for CANAL in "${CANALES[@]}"; do

  DESTINO="$RAIZ/$CANAL/src/main/resources/secrets"

  # Nombre de la variable de entorno de este canal: bff-web -> BFF_WEB_KEYSTORE_PASSWORD.
  VARIABLE_CLAVE="$(echo "$CANAL" | tr 'a-z-' 'A-Z_')_KEYSTORE_PASSWORD"
  # Expansion indirecta de bash: toma el VALOR de la variable cuyo NOMBRE esta en
  # VARIABLE_CLAVE, y si no existe usa la contrasena por defecto.
  CLAVE="${!VARIABLE_CLAVE:-$CLAVE_POR_DEFECTO}"

  KEYSTORE="$DESTINO/$CANAL.p12"
  CERTIFICADO="$DESTINO/$CANAL.crt"
  PRIVADA="$DESTINO/$CANAL-private.pem"
  PUBLICA="$DESTINO/$CANAL-public.pem"

  echo "== $CANAL =="

  mkdir -p "$DESTINO"

  # El .gitkeep es lo unico de esta carpeta que SI se versiona. Sin el, git no registra
  # directorios vacios, la ruta no existiria en un clon recien hecho y este script
  # tendria que crearla; peor aun, alguien podria concluir que faltan archivos del
  # repositorio. El texto de dentro explica la carpeta a quien la abra.
  if [ ! -f "$DESTINO/.gitkeep" ]; then
    cat > "$DESTINO/.gitkeep" <<'FIN'
Esta carpeta guarda el material criptografico de este canal y su contenido NO se versiona.
Se genera con scripts/generar-secretos.sh antes de compilar. Este archivo existe solo para
que la ruta exista en un clon recien hecho.
FIN
  fi

  if $FORZAR; then
    rm -f "$KEYSTORE" "$CERTIFICADO" "$PRIVADA" "$PUBLICA"
  fi

  # --- 1) Keystore TLS -------------------------------------------------
  if [ -f "$KEYSTORE" ]; then
    echo "  keystore TLS ya existe, se conserva -> $KEYSTORE"
    CONSERVADOS=$((CONSERVADOS + 1))
  else
    # -ext SAN=... es la parte que mas se olvida y la que mas ruido causa.
    # curl y los navegadores comprueban el nombre del servidor contra el SAN (Subject
    # Alternative Name), NO contra el CN, desde hace anos. Sin SAN, hasta un certificado
    # perfectamente valido produce un error de nombre al conectarse a localhost.
    # Se incluyen las dos formas de nombrar esta misma maquina porque las evidencias usan
    # las dos: "localhost" (un nombre) y "127.0.0.1" (la direccion a la que resuelve).
    keytool -genkeypair \
      -alias "$CANAL" \
      -keyalg RSA \
      -keysize "$TAMANO_CLAVE" \
      -sigalg SHA256withRSA \
      -validity "$VALIDEZ_DIAS" \
      -storetype PKCS12 \
      -keystore "$KEYSTORE" \
      -storepass "$CLAVE" \
      -dname "CN=$CANAL, OU=Banco XYZ, O=Duoc UC, L=Santiago, C=CL" \
      -ext "SAN=dns:localhost,ip:127.0.0.1"
    chmod 600 "$KEYSTORE" 2>/dev/null || true
    echo "  keystore TLS (PKCS12, CN=$CANAL) -> $KEYSTORE"
    CREADOS=$((CREADOS + 1))
  fi

  # --- 2) Certificado publico en PEM -----------------------------------
  if [ -f "$CERTIFICADO" ]; then
    echo "  certificado ya existe, se conserva -> $CERTIFICADO"
    CONSERVADOS=$((CONSERVADOS + 1))
  else
    # -rfc pide la salida en texto (PEM) en vez de binario (DER). Es el formato que
    # entiende "curl --cacert".
    keytool -exportcert -rfc \
      -alias "$CANAL" \
      -keystore "$KEYSTORE" \
      -storetype PKCS12 \
      -storepass "$CLAVE" \
      -file "$CERTIFICADO"
    echo "  certificado publico (PEM)        -> $CERTIFICADO"
    CREADOS=$((CREADOS + 1))
  fi

  # --- 3) Claves de firma de una ejecucion anterior (F4 y antes): ya no existen -------
  # Desde F5 el canal no firma tokens (los emite el auth-server), asi que su par RSA de firma sobra.
  if [ -f "$PRIVADA" ] || [ -f "$PUBLICA" ]; then
    rm -f "$PRIVADA" "$PUBLICA"
    echo "  claves de firma de una version anterior retiradas (el canal ya no firma tokens)"
  fi

  echo
done

# ---------------------------------------------------------------------
# El auth-server (F4): solo el par de firma, sin keystore TLS
# ---------------------------------------------------------------------
# En el flujo con JVM locales el auth-server habla HTTP en 127.0.0.1 (config-repo/auth-server-local.yml),
# asi que no necesita certificado; si necesita su clave de firma, que es el unico emisor de tokens del
# sistema. Es PERSISTENTE como en contenedores: se lee de archivos y no se genera en cada arranque, de modo
# que reiniciarlo no invalida los tokens vigentes. Misma regla que los canales: si falta una de las dos
# claves se regenera el par completo, y --forzar lo regenera todo.
DESTINO_AUTH="$RAIZ/auth-server/src/main/resources/secrets"
PRIVADA_AUTH="$DESTINO_AUTH/auth-server-private.pem"
PUBLICA_AUTH="$DESTINO_AUTH/auth-server-public.pem"
echo "== auth-server =="
mkdir -p "$DESTINO_AUTH"
if [ ! -f "$DESTINO_AUTH/.gitkeep" ]; then
  cat > "$DESTINO_AUTH/.gitkeep" <<'FIN'
Esta carpeta guarda el material criptografico de este servicio y su contenido NO se versiona.
Se genera con scripts/generar-secretos.sh antes de compilar. Este archivo existe solo para
que la ruta exista en un clon recien hecho.
FIN
fi
if $FORZAR; then
  rm -f "$PRIVADA_AUTH" "$PUBLICA_AUTH"
fi
if [ -f "$PRIVADA_AUTH" ] && [ -f "$PUBLICA_AUTH" ]; then
  echo "  claves de firma ya existen, se conservan -> $PRIVADA_AUTH"
  CONSERVADOS=$((CONSERVADOS + 2))
else
  rm -f "$PRIVADA_AUTH" "$PUBLICA_AUTH"
  java "$RAIZ/scripts/GenerarClaves.java" "$DESTINO_AUTH" auth-server
  CREADOS=$((CREADOS + 2))
fi
echo

# ---------------------------------------------------------------------
# Resumen
# ---------------------------------------------------------------------

echo "---------------------------------------------------------------------"
echo "Resumen: $CREADOS archivos generados, $CONSERVADOS conservados."
echo
echo "Que quedo, y donde:"
for CANAL in "${CANALES[@]}"; do
  echo "  $CANAL/src/main/resources/secrets/"
  printf '      %-22s %s\n' "$CANAL.p12"          "keystore TLS que sirve HTTPS en este canal"
  printf '      %-22s %s\n' "$CANAL.crt"          "certificado publico, para curl --cacert"
done
echo "  auth-server/src/main/resources/secrets/"
printf '      %-22s %s\n' "auth-server-private.pem" "clave de firma de TODOS los tokens (PKCS#8)"
printf '      %-22s %s\n' "auth-server-public.pem"  "su clave publica (X.509)"
echo
echo "Identidad de los tres certificados (CN distinto por canal, comprobado en el keystore):"
for CANAL in "${CANALES[@]}"; do
  VARIABLE_CLAVE="$(echo "$CANAL" | tr 'a-z-' 'A-Z_')_KEYSTORE_PASSWORD"
  CLAVE="${!VARIABLE_CLAVE:-$CLAVE_POR_DEFECTO}"
  DUENO=$(keytool -list -v \
            -keystore "$RAIZ/$CANAL/src/main/resources/secrets/$CANAL.p12" \
            -storetype PKCS12 -storepass "$CLAVE" -alias "$CANAL" \
          | grep -m1 '^Owner:')
  printf '  %-12s %s\n' "$CANAL" "$DUENO"
done
echo
echo "NADA DE ESTO SE VERSIONA."
echo "  El .gitignore excluye .p12, .crt, .pem, .jks y .key; de estas carpetas solo se"
echo "  versiona el .gitkeep. Una clave privada subida a un repositorio queda en el"
echo "  historial de Git para siempre, aunque despues se borre el archivo."
echo "  Comprobacion rapida:  git status --ignored --short | grep secrets"
echo
echo "Siguiente paso: compilar DESPUES de generar. Maven copia src/main/resources dentro"
echo "del jar al empaquetar, asi que un jar construido antes que los secretos no los lleva"
echo "adentro y el arranque falla con un mensaje sobre el key store que no menciona el"
echo "verdadero motivo."
echo "  ./mvnw -B clean package"
echo "---------------------------------------------------------------------"
