#!/usr/bin/env node
// =====================================================================
// capturar-pantallas.js: las capturas de pantalla de la evidencia (F9), con Chromium sin interfaz (Playwright).
// =====================================================================
// Toma tres capturas de un sistema EN MARCHA (docker compose up -d --wait) y las deja en evidencias/capturas/:
//
//   01-eureka-dashboard.png       el dashboard de Eureka (http://localhost:8761) con los servicios registrados. Espera a
//                                 que desaparezca el aviso "EMERGENCY! EUREKA MAY BE INCORRECTLY CLAIMING INSTANCES ARE UP",
//                                 que Eureka muestra el primer minuto porque aun no calcula bien su umbral de renovaciones.
//   02-kafka-ui-topicos.png       Kafka UI (http://localhost:8090): los topicos bancoxyz.retiros.v1 y bancoxyz.seguridad.v1
//                                 con sus particiones, y los de reintento y DLT de cada consumidor.
//   03-kafka-ui-grupos.png        Kafka UI: los grupos de consumidores "notificaciones" y "auditoria".
//   04-login-auth-server.png      la pagina de login del auth-server (https://localhost:9000/login), con el certificado
//                                 verificado contra la CA interna.
//
// Uso:    node scripts/capturar-pantallas.js [carpeta-de-salida]     (por defecto evidencias/capturas)
// Requiere Node 18 o superior y el paquete "playwright" con un Chromium instalado:
//     npm install playwright && npx playwright install chromium
// En el entorno de desarrollo de este proyecto el Chromium ya existe: NODE_PATH=$(npm root -g) y
// PLAYWRIGHT_BROWSERS_PATH apuntan a el. El resto del proyecto NO necesita Node: estas capturas son un extra de la
// evidencia, y verificar.sh no depende de este guion.
//
// TLS. La pagina de login se sirve con un certificado que firma la CA interna del proyecto (certs/ca.crt). No se usa
// ignoreHTTPSErrors: se le pasa a Chromium la huella SPKI (SHA-256 de la clave publica) de ESA CA con
// --ignore-certificate-errors-spki-list, de modo que solo se acepta una cadena que pase por ella; con cualquier otra
// autoridad la pagina no carga.
// =====================================================================
const { chromium } = require('playwright');
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const RAIZ = path.resolve(__dirname, '..');
const SALIDA = path.resolve(process.argv[2] || path.join(RAIZ, 'evidencias', 'capturas'));
const CA = path.join(RAIZ, 'certs', 'ca.crt');

// Huella SPKI de la CA: base64(SHA-256(DER de la clave publica)), el formato que espera Chromium.
function huellaSpki(archivoCa) {
  const pem = fs.readFileSync(archivoCa);
  const publica = execFileSync('openssl', ['x509', '-pubkey', '-noout'], { input: pem });
  const der = execFileSync('openssl', ['pkey', '-pubin', '-outform', 'der'], { input: publica });
  return require('crypto').createHash('sha256').update(der).digest('base64');
}

async function esperar(pagina, descripcion, condicion, ms) {
  try {
    await pagina.waitForFunction(condicion, null, { timeout: ms });
  } catch (e) {
    throw new Error(`No se cumplio a tiempo: ${descripcion}`);
  }
}

(async () => {
  fs.mkdirSync(SALIDA, { recursive: true });
  if (!fs.existsSync(CA)) throw new Error(`Falta ${CA}: levanta el sistema primero (docker compose up -d --wait)`);
  const navegador = await chromium.launch({
    headless: true,
    args: [`--ignore-certificate-errors-spki-list=${huellaSpki(CA)}`],
  });
  const contexto = await navegador.newContext({ viewport: { width: 1440, height: 900 }, locale: 'es-CL' });
  const pagina = await contexto.newPage();

  // 1. Eureka: sin el aviso de emergencia y con los siete servicios clientes registrados.
  const SERVICIOS = ['AUDITORIA-SERVICE', 'AUTH-SERVER', 'BFF-ATM', 'BFF-MOBILE', 'BFF-WEB', 'CORE-SERVICE', 'NOTIFICACIONES-SERVICE'];
  await pagina.goto('http://localhost:8761/', { waitUntil: 'networkidle' });
  const listo = () => pagina.waitForFunction((nombres) => {
    const t = document.body.innerText;
    return !t.includes('EMERGENCY') && nombres.every((n) => t.includes(n));
  }, SERVICIOS, { timeout: 240000 });
  try {
    await listo();
  } catch (e) {
    // Si Eureka sigue en autopreservacion, se espera un ciclo de renovacion mas y se recarga.
    await pagina.waitForTimeout(35000);
    await pagina.reload({ waitUntil: 'networkidle' });
    await listo();
  }
  await pagina.screenshot({ path: path.join(SALIDA, '01-eureka-dashboard.png'), fullPage: true });
  console.log('01-eureka-dashboard.png: los 7 servicios registrados y sin aviso EMERGENCY');

  // 2. Kafka UI: topicos.
  await pagina.goto('http://localhost:8090/ui/clusters/bancoxyz/all-topics', { waitUntil: 'networkidle' });
  await esperar(pagina, 'la lista de topicos con bancoxyz.retiros.v1', () => document.body.innerText.includes('bancoxyz.retiros.v1'), 60000);
  await pagina.screenshot({ path: path.join(SALIDA, '02-kafka-ui-topicos.png'), fullPage: true });
  console.log('02-kafka-ui-topicos.png');

  // 3. Kafka UI: grupos de consumidores.
  await pagina.goto('http://localhost:8090/ui/clusters/bancoxyz/consumer-groups', { waitUntil: 'networkidle' });
  await esperar(pagina, 'los grupos notificaciones y auditoria', () => {
    const t = document.body.innerText;
    return t.includes('notificaciones') && t.includes('auditoria');
  }, 60000);
  await pagina.screenshot({ path: path.join(SALIDA, '03-kafka-ui-grupos.png'), fullPage: true });
  console.log('03-kafka-ui-grupos.png');

  // 4. Login del auth-server (formulario de Spring Authorization Server), por HTTPS verificado con la CA interna.
  const respuesta = await pagina.goto('https://localhost:9000/login', { waitUntil: 'networkidle' });
  if (!respuesta || respuesta.status() !== 200) throw new Error(`/login respondio ${respuesta && respuesta.status()}`);
  await esperar(pagina, 'el formulario de login', () => !!document.querySelector('input[name="username"]'), 30000);
  await pagina.screenshot({ path: path.join(SALIDA, '04-login-auth-server.png'), fullPage: true });
  console.log('04-login-auth-server.png: HTTP', respuesta.status());

  await navegador.close();
})().catch((e) => {
  console.error('ERROR:', e.message);
  process.exit(1);
});
