#!/usr/bin/env bash
# =====================================================================
# restablecer-demo.sh: devuelve los saldos de las cuentas al valor de la carga inicial.
# =====================================================================
# Hasta F2 el estado del core vivia en memoria y bastaba reiniciarlo para volver al punto de
# partida. Desde F3 el estado esta en PostgreSQL y sobrevive a los reinicios (esa es la gracia), asi
# que las comprobaciones que retiran dinero (la cuenta 116 parte con 12000 y la 106 con 5000) dejan
# huella: una segunda ejecucion encontraria otros saldos. Este guion deshace SOLO lo que hicieron los
# retiros del cajero, y nada mas:
#
#   1. devuelve a cada cuenta lo que se le retiro (suma de sus movimientos con origen RETIRO_ATM);
#   2. borra esos movimientos;
#   3. borra el registro de claves de idempotencia (las claves de las pruebas no deben "recordarse").
#
# No toca las cuentas, los 686 movimientos de la carga, el lote sin conciliar ni el reporte de calidad,
# y no reinicia nada. Las tres sentencias van en una transaccion: o se deshace todo o nada.
# Los folios (secuencia) NO se reinician: son unicos para siempre, tambien entre una demostracion y otra.
#
# Se ejecuta como superusuario por el socket local del contenedor de PostgreSQL, sin red ni
# contrasena: es una herramienta de demostracion y de pruebas, no una operacion del sistema.
#
# Uso:  scripts/restablecer-demo.sh        (ENTORNO=docker por defecto; ENTORNO=local para las JVM locales)
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
source "$RAIZ/scripts/lib-entorno.sh"

sql_postgres core "
BEGIN;
UPDATE cuenta c SET saldo = c.saldo + r.total
  FROM (SELECT cuenta_id, SUM(monto) AS total FROM movimiento WHERE origen = 'RETIRO_ATM' GROUP BY cuenta_id) r
 WHERE c.id = r.cuenta_id;
DELETE FROM movimiento WHERE origen = 'RETIRO_ATM';
DELETE FROM idempotencia;
COMMIT;" > /dev/null || { echo "ERROR: no se pudo restablecer la base 'core'" >&2; exit 1; }

echo "Datos de demostracion restablecidos: saldos de la carga inicial, sin retiros ni claves de idempotencia."
echo "  cuenta 116: $(sql_postgres core 'SELECT saldo FROM cuenta WHERE id = 116')   cuenta 106: $(sql_postgres core 'SELECT saldo FROM cuenta WHERE id = 106')"
