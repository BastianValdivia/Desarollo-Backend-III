import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

/**
 * Generador del par de claves RSA con el que cada canal FIRMA sus tokens.
 *
 * <h2>Que lugar ocupa esto en la arquitectura</h2>
 * Ninguno: esta clase NO forma parte del sistema desplegado. Es una herramienta de
 * construccion, del mismo rango que el script que la invoca. Vive en {@code scripts/} y no
 * en {@code src/main/java} a proposito: nada de lo que corre en produccion debe ser capaz de
 * fabricarse una clave de firma nueva. Quien puede firmar tokens es el emisor del canal, y lo
 * hace con la clave que esta herramienta dejo escrita en disco ANTES de que el servicio
 * arrancara.
 *
 * <h2>Por que existe, si ya existe keytool</h2>
 * {@code keytool} genera pares de claves de maravilla, pero los guarda dentro de un almacen
 * (un keystore PKCS12), que es un archivo binario con contrasena. Eso es exactamente lo que
 * Tomcat quiere para TLS, y por eso los tres keystores del proyecto los produce
 * {@code keytool}. Para la firma de tokens, en cambio, hace falta otra cosa:
 *
 * <ul>
 *   <li>Spring Boot sabe leer la clave PUBLICA de validacion desde un archivo PEM, con la
 *       propiedad {@code spring.security.oauth2.resourceserver.jwt.public-key-location}.</li>
 *   <li>Para la clave PRIVADA de firma NO hay ninguna propiedad equivalente. Spring valida
 *       tokens por configuracion, pero emitirlos es tarea de cada aplicacion, asi que el
 *       emisor se escribe en Java y la clave se le inyecta como {@code RSAPrivateKey}.</li>
 * </ul>
 *
 * Spring Security trae un conversor que entiende PEM, pero solo dos formatos concretos, y son
 * los dos que este programa escribe:
 *
 * <ul>
 *   <li><b>PKCS#8</b> para la privada, cabecera {@code -----BEGIN PRIVATE KEY-----}. Es el
 *       formato que devuelve {@link java.security.PrivateKey#getEncoded()} en Java.
 *       No confundir con PKCS#1 ({@code BEGIN RSA PRIVATE KEY}), que es el que suele escribir
 *       {@code openssl genrsa} y que el conversor de Spring NO acepta.</li>
 *   <li><b>X.509 SubjectPublicKeyInfo</b> para la publica, cabecera
 *       {@code -----BEGIN PUBLIC KEY-----}, que es lo que devuelve
 *       {@link java.security.PublicKey#getEncoded()}.</li>
 * </ul>
 *
 * Dicho de otro modo: Java ya produce nativamente los bytes en el formato correcto. Lo unico
 * que agrega este programa es el envoltorio PEM, que es puro texto: codificar esos bytes en
 * Base64, partirlos en lineas de 64 caracteres y ponerles cabecera y pie.
 *
 * <h2>Por que no se usa openssl en ningun paso</h2>
 * Porque el proyecto declara UN solo prerrequisito: el JDK 21. {@code openssl} no viene con
 * Windows ni con el JDK. Como los secretos no se versionan (una clave privada publicada en un
 * repositorio es un incidente de seguridad real, y el historial de Git la conserva aunque
 * despues se borre el archivo), quien clone el repositorio tiene que poder generarlos. Si la
 * unica via para generarlos dependiera de una herramienta que esa persona no tiene, el sistema
 * entero seria inarrancable en su maquina.
 *
 * <h2>Por que la clave de firma es distinta de la clave del certificado TLS</h2>
 * Se podria reutilizar la clave que {@code keytool} ya puso dentro del keystore, y funcionaria.
 * No se hace porque una clave criptografica debe tener un proposito unico. TLS protege el
 * transporte entre el cliente y el canal; la firma del token acredita quien emitio una
 * credencial. Son dos afirmaciones distintas, con ciclos de vida distintos: rotar un
 * certificado TLS que caduca no deberia invalidar todos los tokens en circulacion, y eso solo
 * es cierto si las claves estan separadas.
 *
 * <h2>Como se ejecuta</h2>
 * <pre>
 *   java scripts/GenerarClaves.java bff-web/src/main/resources/secrets bff-web
 * </pre>
 * Sin compilar, sin Maven y sin dependencias: desde Java 11 el lanzador ejecuta un archivo
 * fuente de una sola clase directamente. Lo normal es no invocarlo a mano, sino a traves de
 * {@code scripts/generar-secretos.sh}, que genera ademas los keystores TLS.
 *
 * <h2>Reparto de responsabilidades con el script</h2>
 * Este programa es el MECANISMO: sabe fabricar un par de claves y escribirlo en PEM. La
 * POLITICA (que canales existen, donde viven sus secretos, si se regenera o no) la decide el
 * script. Desde F5 solo el auth-server firma tokens, asi que este programa genera su unico par de
 * claves de firma (los BFF ya no tienen).
 * La unica politica que este programa si impone es negarse a pisar archivos existentes: es una
 * salvaguarda, no una decision de diseno, y esta explicada en {@link #main(String[])}.
 */
public final class GenerarClaves {

    /**
     * Longitud de la clave RSA, en bits. Congelada en 2048 por el contrato.
     *
     * <p>2048 es el minimo que hoy se considera aceptable para RSA. 1024 esta roto en la
     * practica y cualquier revision seria lo marcaria. 4096 seria mas conservador, pero
     * multiplica por unas seis veces el costo de cada firma sin aportar nada frente al modelo
     * de amenaza de este proyecto, en el que los tokens viven entre 3 y 60 minutos.
     */
    private static final int TAMANO_CLAVE_BITS = 2048;

    /** Algoritmo del par de claves. RSA, porque la firma congelada del contrato es RS256. */
    private static final String ALGORITMO = "RSA";

    /**
     * Ancho de linea del cuerpo Base64 dentro del PEM.
     *
     * <p>64 caracteres no es decorativo: es lo que fija el estandar PEM y lo que esperan los
     * lectores estrictos. Un PEM con el Base64 en una sola linea kilometrica es aceptado por
     * unas herramientas y rechazado por otras, y ese es justo el tipo de fallo que aparece
     * tarde y en la maquina de otra persona.
     */
    private static final int ANCHO_LINEA_PEM = 64;

    /** Clase de utilidad: no tiene sentido instanciarla. */
    private GenerarClaves() {
    }

    /**
     * Punto de entrada.
     *
     * @param args exactamente dos: el directorio de destino y el nombre del canal
     *             (por ejemplo {@code bff-web}), que se usa como prefijo de los dos archivos
     * @throws Exception si falla la escritura en disco o si la JVM no ofrece RSA, dos
     *                   condiciones ante las cuales lo unico sensato es abortar ruidosamente:
     *                   una herramienta de generacion de secretos que "sigue adelante" tras un
     *                   error deja al proyecto con material a medias, que es peor que no tener
     *                   ninguno
     */
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Uso: java GenerarClaves.java <directorio-destino> <nombre-canal>");
            System.err.println("Ejemplo: java GenerarClaves.java bff-web/src/main/resources/secrets bff-web");
            // Codigo 2 y no 1 para distinguir "me llamaste mal" de "lo intente y fallo".
            // El script que invoca esto trata los dos casos igual, pero una persona depurando
            // a mano agradece la diferencia.
            System.exit(2);
        }

        Path directorio = Path.of(args[0]);
        String canal = args[1];

        Path clavePrivada = directorio.resolve(canal + "-private.pem");
        Path clavePublica = directorio.resolve(canal + "-public.pem");

        // Salvaguarda, no politica: el script ya comprueba la existencia antes de llegar aqui.
        // Esta segunda comprobacion protege a quien ejecute el programa a mano. Sobreescribir
        // una clave de firma en silencio invalidaria de golpe todos los tokens emitidos, y el
        // sintoma (401 por todas partes, de pronto) no apunta en absoluto a la causa.
        if (Files.exists(clavePrivada) || Files.exists(clavePublica)) {
            System.err.println("ABORTADO: ya existen claves para el canal '" + canal + "' en " + directorio);
            System.err.println("  " + clavePrivada);
            System.err.println("  " + clavePublica);
            System.err.println("Borralas a mano si de verdad quieres regenerarlas, o usa: generar-secretos.sh --forzar");
            System.exit(3);
        }

        Files.createDirectories(directorio);

        KeyPair par = generarPar();

        // getEncoded() de la privada devuelve DER en PKCS#8 y el de la publica DER en X.509
        // SubjectPublicKeyInfo. Son exactamente los dos formatos que Spring espera, asi que no
        // hay ninguna conversion que hacer: solo envolver en PEM.
        escribirPem(clavePrivada, "PRIVATE KEY", par.getPrivate().getEncoded());
        escribirPem(clavePublica, "PUBLIC KEY", par.getPublic().getEncoded());

        restringirPermisos(clavePrivada);

        System.out.println("  clave privada (PKCS#8) -> " + clavePrivada);
        System.out.println("  clave publica (X.509)  -> " + clavePublica);
    }

    /**
     * Fabrica el par RSA.
     *
     * <p>No se pasa un {@code SecureRandom} explicito: {@code KeyPairGenerator} ya usa el
     * generador criptografico por defecto de la plataforma. Pasarle un {@code Random} corriente
     * seria el error clasico y catastrofico, porque haria la clave predecible.
     *
     * @return un par de claves RSA recien generado
     * @throws NoSuchAlgorithmException si esta JVM no ofrece RSA, algo que en un JDK estandar
     *                                  no ocurre
     */
    private static KeyPair generarPar() throws NoSuchAlgorithmException {
        KeyPairGenerator generador = KeyPairGenerator.getInstance(ALGORITMO);
        generador.initialize(TAMANO_CLAVE_BITS);
        return generador.generateKeyPair();
    }

    /**
     * Escribe una clave ya codificada en DER como archivo PEM.
     *
     * <p>PEM es solo un envoltorio de texto sobre bytes binarios: cabecera, el binario en
     * Base64 partido en lineas, y pie. Existe porque los bytes crudos no sobreviven a un copiar
     * y pegar, a un correo ni a un archivo de configuracion, y el texto si.
     *
     * @param destino   ruta del archivo a crear
     * @param etiqueta  lo que va entre guiones en la cabecera y el pie, por ejemplo
     *                  {@code PRIVATE KEY}. No es un comentario: los lectores de PEM se apoyan
     *                  en esa etiqueta para saber que formato esperar dentro
     * @param der       la clave en DER, tal como la devuelve {@code getEncoded()}
     * @throws IOException si el archivo no se puede escribir
     */
    private static void escribirPem(Path destino, String etiqueta, byte[] der) throws IOException {
        // getMimeEncoder parte la salida en lineas por si solo. El separador se fija a "\n"
        // explicito y no al de la plataforma: un PEM con finales de linea de Windows (CRLF)
        // generado en una maquina y leido en otra es una fuente de fallos gratuita.
        Base64.Encoder codificador = Base64.getMimeEncoder(
                ANCHO_LINEA_PEM, new byte[] { '\n' });

        String pem = "-----BEGIN " + etiqueta + "-----\n"
                + codificador.encodeToString(der) + "\n"
                + "-----END " + etiqueta + "-----\n";

        Files.writeString(destino, pem, StandardCharsets.US_ASCII);
    }

    /**
     * Deja la clave privada legible solo por su dueno (permisos 600 en sistemas POSIX).
     *
     * <p>Por que es mejor esfuerzo y no un requisito: Windows no tiene permisos POSIX, y el
     * proyecto tiene que poder generarse alli. Fallar por esto dejaria sin arrancar un sistema
     * completo a cambio de un endurecimiento que en esa plataforma se expresa de otra manera.
     * Se avisa por consola y se sigue, que es la conducta honesta: ni se calla, ni se muere.
     *
     * @param archivo la clave privada recien escrita
     */
    private static void restringirPermisos(Path archivo) {
        try {
            Files.setPosixFilePermissions(archivo, PosixFilePermissions.fromString("rw-------"));
        } catch (UnsupportedOperationException | IOException e) {
            System.out.println("  aviso: no se pudieron restringir los permisos de " + archivo
                    + " (normal en Windows): " + e.getMessage());
        }
    }
}
