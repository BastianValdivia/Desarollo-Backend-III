#!/usr/bin/env bash
# =====================================================================
# verificar-f3.sh: comprobaciones de la fase F3 (PostgreSQL y core en dos replicas) contra el stack
# levantado con "docker compose up -d". Imprime PASS o FAIL con el dato real de cada una; el codigo de
# salida es 0 solo si todas pasan.
#
# Que comprueba, en el orden de los criterios de termino de F3:
#   1. PostgreSQL: servicio sano, sin puertos publicados, solo en la red interna, con volumen.
#   2. La carga dio los numeros del S5 (50 cuentas, 686 movimientos, descartes) y ocurrio UNA vez.
#   3. Retiros simultaneos sobre la misma cuenta, repartidos entre las dos replicas del core: exitos
#      exactos segun el saldo, saldo final que cuadra y nunca negativo.
#   4. La misma Idempotency-Key en la otra replica devuelve el mismo folio y no descuenta dos veces.
#   5. Reiniciar el core (docker compose restart core-service) conserva los retiros.
#   6. Eureka muestra dos instancias de core-service y las peticiones se reparten entre ambas.
#   7. Cada base tiene su propio usuario y ese usuario no puede leer otra base.
#   8. Las contrasenas de la base no estan en el compose, ni en el entorno de los contenedores, ni en git.
#
# QUE MODIFICA. Los retiros de las secciones 3 a 5 cambian saldos de las cuentas 106, 116 y 117 y
# reinician core-service (solo el). Antes y despues ejecuta scripts/restablecer-demo.sh, que deja los
# saldos de la carga inicial. No toca la carga ni los demas servicios.
#
# Portabilidad: sin construcciones de bash 4 ni de GNU en el host; requiere docker, curl y python3.
# Solo funciona con ENTORNO=docker (el compose es lo que se verifica). Se probo en Linux; no se ha
# ejecutado en macOS ni en Windows.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
if [ "${ENTORNO:-docker}" != docker ]; then
  echo "ERROR: verificar-f3.sh verifica el compose: ejecutalo con ENTORNO=docker (el valor por defecto)." >&2
  exit 2
fi
source "$RAIZ/scripts/lib-entorno.sh"
source "$RAIZ/scripts/lib-login.sh"

FALLOS=0
TOTAL=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() {  # igual <descripcion> <esperado> <obtenido>
  if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi
}
json() { python3 -c "import sys,json; d=json.load(sys.stdin); print($1)" 2>/dev/null; }
sql() { sql_postgres core "$1" 2>/dev/null | tr -d '\r'; }
cuenta_de() { echo "$1" | grep -c "$2"; }

# Replicas del core: un contenedor por cada una (Compose las numera -1 y -2).
IDS=($("${COMPOSE[@]}" ps -q core-service))
R1="${IDS[0]:-}"; R2="${IDS[1]:-}"

# -----------------------------------------------------------------------------------------------
# Herramientas de las pruebas: se ejecutan DENTRO de cada replica (el core no se publica al host).
# -----------------------------------------------------------------------------------------------
# rafaga_en <contenedor> <cuenta> <prefijo-de-clave> <n> <monto> <inicio>: lanza n retiros A LA VEZ desde
# dentro de ese contenedor (n procesos wget en paralelo) contra SU PROPIO core, y escribe un codigo HTTP
# por linea. <inicio> es una hora (segundos desde 1970) comun a todas las rafagas: cada proceso espera
# a esa hora antes de disparar. Sin ella, la rafaga que arranca primero terminaria antes de que empiece
# la otra, y no habria competencia entre replicas. El token de servicio es el del BFF del cajero (el unico con
# retiros:ejecutar), pedido al auth-server desde el equipo: vale 5 minutos, de sobra para una rafaga.
rafaga_en() {
  docker exec "$1" sh -c '
    token="$6"
    i=1
    while [ "$i" -le "$3" ]; do
      ( while [ "$(date +%s)" -lt "$5" ]; do :; done
        wget -S -q -O /dev/null --header "Content-Type: application/json" --header "Authorization: Bearer $token" \
          --header "Idempotency-Key: $2-$i" --post-data "{\"monto\":$4}" \
          "http://127.0.0.1:8080/internal/v1/cuentas/$1/retiros" 2>&1 | grep -m1 "HTTP/" | awk "{print \$2}" ) &
      i=$((i + 1))
    done
    wait' _ "$2" "$3" "$4" "$5" "$6" "$(token_servicio bff-atm)" 2> /dev/null
}
# retiro_con_clave_en <contenedor> <cuenta> <clave> <monto>: un retiro; imprime el cuerpo JSON de la respuesta.
retiro_con_clave_en() {
  docker exec "$1" sh -c '
    wget -q -O - --header "Content-Type: application/json" --header "Authorization: Bearer $4" \
      --header "Idempotency-Key: $2" --post-data "{\"monto\":$3}" "http://127.0.0.1:8080/internal/v1/cuentas/$1/retiros"' _ "$2" "$3" "$4" "$(token_servicio bff-atm)" 2> /dev/null
}
# core_post_codigo <contenedor> <cuenta> <clave> <monto>: igual que retiro_con_clave_en, pero imprime solo el
# codigo HTTP (wget no imprime el cuerpo de un 4xx, y aqui se quiere justamente ver el 422).
core_post_codigo() {
  docker exec "$1" sh -c '
    wget -S -O /dev/null --header "Content-Type: application/json" --header "Authorization: Bearer $4" \
      --header "Idempotency-Key: $2" --post-data "{\"monto\":$3}" "http://127.0.0.1:8080/internal/v1/cuentas/$1/retiros" 2>&1 \
      | sed -n "s|.*HTTP/[0-9.]* \\([0-9][0-9][0-9]\\).*|\\1|p" | tail -1' _ "$2" "$3" "$4" "$(token_servicio bff-atm)" 2> /dev/null
}
# metrica_en <contenedor> <uri-codificada>: peticiones que ESA replica ha atendido para esa ruta.
metrica_en() {
  docker exec "$1" wget -qO- "http://127.0.0.1:8081/actuator/metrics/http.server.requests?tag=uri:$2" 2> /dev/null \
    | python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
    print(int([m["value"] for m in d["measurements"] if m["statistic"] == "COUNT"][0]))
except Exception:
    print(0)'
}
saldo_de() { sql "SELECT saldo FROM cuenta WHERE id = $1" | sed 's/\.00$//'; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "Restableciendo los datos de demostracion (saldos de la carga inicial)..."
bash "$RAIZ/scripts/restablecer-demo.sh" > /dev/null || { echo "ERROR: no se pudo restablecer" >&2; exit 2; }

# ===============================================================================================
echo "== 1. PostgreSQL: sano, sin puertos publicados, solo en la red interna, con volumen =="
# ===============================================================================================
PG="$("${COMPOSE[@]}" ps -q postgres)"
igual "postgres esta healthy" "running healthy" "$(docker inspect -f '{{.State.Status}} {{.State.Health.Status}}' "$PG")"
igual "postgres: imagen con la version exacta fijada" "postgres:16.15-alpine3.24" "$(docker inspect -f '{{.Config.Image}}' "$PG")"
igual "postgres: sin puertos publicados (PortBindings)" "{}" "$(docker inspect -f '{{json .HostConfig.PortBindings}}' "$PG")"
igual "postgres: solo en la red interna" "bancoxyz_interna" "$(docker inspect -f '{{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}' "$PG" | tr -d ' ')"
if (exec 3<> /dev/tcp/127.0.0.1/5432) 2> /dev/null; then
  resultado FAIL "el puerto 5432 NO escucha en el equipo" "algo responde en 127.0.0.1:5432"
else
  resultado PASS "el puerto 5432 NO escucha en el equipo" "conexion rechazada"
fi
igual "postgres: datos en un volumen con nombre" "bancoxyz_postgres-datos" "$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/var/lib/postgresql/data"}}{{.Name}}{{end}}{{end}}' "$PG")"
igual "postgres: servidor 16" "16" "$(sql 'SHOW server_version_num' | cut -c1-2)"
igual "postgres: las contrasenas se exigen tambien por TCP desde 127.0.0.1 (scram-sha-256)" "scram-sha-256" \
  "$("${COMPOSE[@]}" exec -T postgres psql -U postgres -d postgres -tA -c "SELECT auth_method FROM pg_hba_file_rules WHERE address = '127.0.0.1' LIMIT 1" 2>/dev/null | tr -d '\r')"
igual "core-service tiene DOS replicas, cada una en su contenedor" "2" "${#IDS[@]}"
igual "core-service: los dos contenedores estan healthy" "running healthy running healthy" \
  "$(docker inspect -f '{{.State.Status}} {{.State.Health.Status}}' "$R1" "$R2" | tr '\n' ' ' | sed 's/ $//')"
igual "core-service: sin puertos publicados en ninguna replica" "{} {}" \
  "$(docker inspect -f '{{json .HostConfig.PortBindings}}' "$R1" "$R2" | tr '\n' ' ' | sed 's/ $//')"
igual "core-service: nombres sin container_name (los pone Compose)" "bancoxyz-core-service-1 bancoxyz-core-service-2" \
  "$(docker inspect -f '{{.Name}}' "$R1" "$R2" | sed 's#^/##' | sort | tr '\n' ' ' | sed 's/ $//')"

# ===============================================================================================
echo "== 2. La carga en PostgreSQL da los numeros del S5, y ocurrio una sola vez =="
# ===============================================================================================
igual "tabla cuenta" 50 "$(sql 'SELECT count(*) FROM cuenta')"
igual "movimientos de la carga (origen CSV_SEMILLA)" 686 "$(sql "SELECT count(*) FROM movimiento WHERE origen = 'CSV_SEMILLA'")"
igual "transacciones sin conciliar" 1000 "$(sql 'SELECT count(*) FROM transaccion_no_conciliada')"
igual "flyway_schema_history: versiones aplicadas con exito, una vez cada una (V4 es el outbox de F7)" "1 2 3 4" \
  "$(sql "SELECT string_agg(version, ' ' ORDER BY installed_rank) FROM flyway_schema_history WHERE success")"
igual "reporte de calidad guardado (cuentas, movimientos, sin conciliar)" "50 686 1000" \
  "$(sql "SELECT cuentas_consolidadas || ' ' || movimientos_cargados || ' ' || transacciones_no_conciliadas FROM reporte_calidad")"
igual "descartes por motivo guardados (EDAD, FECHA, MONTO, SALDO, TIPO)" "362 0 314 207 326" \
  "$(sql "SELECT string_agg(cantidad::text, ' ' ORDER BY motivo) FROM reporte_calidad_descarte")"
igual "duplicadas descartadas por archivo (movimientos, cuentas, sin conciliar)" "0 9 0" \
  "$(sql "SELECT string_agg(duplicadas_descartadas::text, ' ' ORDER BY orden) FROM reporte_calidad_archivo")"
# La misma cifra, ahora por la API (BFF web, ejecutivo) que lee el reporte de la base.
TE="$(token_web ejecutivo1 Exec.2026)"
CAL="$(curl_bff "$WEB/v1/admin/calidad-datos" -H "Authorization: Bearer $TE")"
igual "API calidad-datos (ejecutivo): cuentas, movimientos, sin conciliar" "50 686 1000" \
  "$(echo "$CAL" | json "str(d['cuentasConsolidadas'])+' '+str(d['movimientosCargados'])+' '+str(d['transaccionesNoConciliadas'])")"
# Quien migro: el log de las replicas. Solo si los contenedores conservan el log del primer arranque.
MIGRARON="$(for id in "$R1" "$R2"; do docker logs "$id" 2>&1 | grep -c 'Migrating schema "public" to version "2'; done | tr '\n' ' ' | sed 's/ $//')"
case "$MIGRARON" in
  "1 0"|"0 1") resultado PASS "la carga la hizo UNA sola replica (la otra espero el bloqueo de Flyway y vio la version 2 aplicada)" "migraciones a la version 2 por replica: $MIGRARON" ;;
  "0 0") echo "  INFO  los logs del primer arranque ya no estan (los contenedores se recrearon): la evidencia es flyway_schema_history, arriba" ;;
  *) resultado FAIL "la carga la hizo UNA sola replica" "migraciones a la version 2 por replica: $MIGRARON" ;;
esac

# ===============================================================================================
echo "== 3. Retiros simultaneos sobre la misma cuenta, repartidos entre las dos replicas =="
# ===============================================================================================
CLAVE="f3-$(date +%s)-$$"
igual "estado inicial: la cuenta 106 tiene 5000" 5000 "$(saldo_de 106)"
# El log de cada replica es acumulativo: se mide la diferencia entre antes y despues de la rafaga.
logs_retiros() { docker logs "$1" 2>&1 | grep -c "POST /internal/v1/cuentas/$2/retiros -> "; }
LA1="$(logs_retiros "$R1" 106)"; LA2="$(logs_retiros "$R2" 106)"
# 10 retiros de 1000: 5 lanzados A LA VEZ dentro de la replica 1 y 5 dentro de la replica 2, ambas
# rafagas disparadas a la misma hora (ver rafaga_en). Cada replica llama a SU core, que tiene su propio pool de conexiones: no
# comparten memoria, asi que la unica exclusion posible es la de PostgreSQL.
INICIO=$(( $(date +%s) + 4 ))
( rafaga_en "$R1" 106 "$CLAVE-a" 5 1000 "$INICIO" > "$TMP/r1" ) &
( rafaga_en "$R2" 106 "$CLAVE-b" 5 1000 "$INICIO" > "$TMP/r2" ) &
wait
CODIGOS="$(cat "$TMP/r1" "$TMP/r2" | sort | uniq -c | awk '{print $2"x"$1}' | tr '\n' ' ' | sed 's/ $//')"
EXITOS="$(cat "$TMP/r1" "$TMP/r2" | grep -c '^200$')"
RECHAZOS="$(cat "$TMP/r1" "$TMP/r2" | grep -c '^409$')"
EXITOS_R1="$(grep -c '^200$' "$TMP/r1")"; EXITOS_R2="$(grep -c '^200$' "$TMP/r2")"
echo "  INFO  codigos recibidos: $CODIGOS (replica 1 logro $EXITOS_R1, replica 2 logro $EXITOS_R2)"
igual "10 retiros de 1000 sobre 5000: exitos (200)" 5 "$EXITOS"
igual "10 retiros de 1000 sobre 5000: rechazos por saldo insuficiente (409)" 5 "$RECHAZOS"
igual "saldo final de la cuenta 106" 0 "$(saldo_de 106)"
igual "movimientos de retiro registrados: uno por cada descuento" 5 "$(sql "SELECT count(*) FROM movimiento WHERE cuenta_id = 106 AND origen = 'RETIRO_ATM'")"
igual "folios emitidos distintos" 5 "$(sql "SELECT count(DISTINCT folio) FROM idempotencia WHERE clave LIKE '$CLAVE-%' AND folio IS NOT NULL")"
# Reparto: las dos replicas atendieron peticiones de retiro (cuentan en el log de cada una).
L1=$(( $(logs_retiros "$R1" 106) - LA1 )); L2=$(( $(logs_retiros "$R2" 106) - LA2 ))
igual "cada replica atendio 5 retiros sobre la cuenta 106 (segun su propio log)" "5 5" "$L1 $L2"

# Segunda prueba, con mas presion y un tope distinto: 20 retiros de 1000 sobre 12000 (cuenta 116): 12 y 8.
INICIO=$(( $(date +%s) + 4 ))
( rafaga_en "$R1" 116 "$CLAVE-c" 10 1000 "$INICIO" > "$TMP/r1" ) &
( rafaga_en "$R2" 116 "$CLAVE-d" 10 1000 "$INICIO" > "$TMP/r2" ) &
wait
EXITOS="$(cat "$TMP/r1" "$TMP/r2" | grep -c '^200$')"; RECHAZOS="$(cat "$TMP/r1" "$TMP/r2" | grep -c '^409$')"
echo "  INFO  20 retiros sobre 12000: la replica 1 logro $(grep -c '^200$' "$TMP/r1"), la replica 2 logro $(grep -c '^200$' "$TMP/r2")"
igual "20 retiros de 1000 sobre 12000: exitos" 12 "$EXITOS"
igual "20 retiros de 1000 sobre 12000: rechazos" 8 "$RECHAZOS"
igual "saldo final de la cuenta 116" 0 "$(saldo_de 116)"
igual "ninguna cuenta del banco tiene saldo negativo" 0 "$(sql 'SELECT count(*) FROM cuenta WHERE saldo < 0')"
igual "la base impide el saldo negativo por si misma (restriccion CHECK)" "cuenta_saldo_no_negativo" \
  "$("${COMPOSE[@]}" exec -T postgres psql -U postgres -d core -tA -c "SELECT conname FROM pg_constraint WHERE conrelid = 'cuenta'::regclass AND contype = 'c' AND conname = 'cuenta_saldo_no_negativo'" 2>/dev/null | tr -d '\r')"

# Tercera prueba, por el CAMINO REAL: 10 retiros simultaneos por HTTPS contra el BFF del cajero. El BFF
# no sabe cuantas replicas hay: llama a http://core-service y el balanceador (Eureka) las reparte.
bash "$RAIZ/scripts/restablecer-demo.sh" > /dev/null
T106="$(token_cajero 4000000000000106 5678)"
LB1="$(logs_retiros "$R1" 106)"; LB2="$(logs_retiros "$R2" 106)"
for i in 1 2 3 4 5 6 7 8 9 10; do
  ( curl_bff -o /dev/null -w '%{http_code}\n' -X POST "$ATM/v1/cuentas/106/retiros" -H "Authorization: Bearer $T106" \
      -H 'Content-Type: application/json' -H "Idempotency-Key: $CLAVE-bff-$i" -d '{"monto":1000}' > "$TMP/bff$i" ) &
done
wait
EXITOS="$(cat "$TMP"/bff* | grep -c '^200$')"; RECHAZOS="$(cat "$TMP"/bff* | grep -c '^409$')"; MAMPARO="$(cat "$TMP"/bff* | grep -c '^503$')"
B1=$(( $(logs_retiros "$R1" 106) - LB1 )); B2=$(( $(logs_retiros "$R2" 106) - LB2 ))
# Desde F6 el cajero tiene un mamparo de 5 llamadas simultaneas al core (decision D6): los retiros que llegan con el
# mamparo lleno reciben 503 al instante y NO llegan al core (ninguna replica los ve). Los demas se reparten entre las
# replicas y el core atiende 5 y rechaza el resto por saldo.
echo "  INFO  por el BFF del cajero: la replica 1 recibio $B1 retiros y la replica 2 recibio $B2; 409=$RECHAZOS, 503 del mamparo=$MAMPARO"
igual "10 retiros simultaneos por el BFF del cajero sobre 5000: exitos" 5 "$EXITOS"
igual "10 retiros simultaneos por el BFF del cajero: los otros 5 se rechazan (409 por saldo o 503 del mamparo del cajero)" 5 "$((RECHAZOS + MAMPARO))"
igual "saldo final de la cuenta 106 tras la prueba por el BFF" 0 "$(saldo_de 106)"
LLEGARON=$((10 - MAMPARO))
[ "$B1" -gt 0 ] && [ "$B2" -gt 0 ] && [ $((B1 + B2)) -eq "$LLEGARON" ] \
  && resultado PASS "el balanceador repartio los $LLEGARON retiros que llegaron al core entre LAS DOS replicas" "replica 1 = $B1, replica 2 = $B2" \
  || resultado FAIL "el balanceador repartio los $LLEGARON retiros que llegaron al core entre LAS DOS replicas" "replica 1 = $B1, replica 2 = $B2"

# ===============================================================================================
echo "== 4. Idempotencia entre replicas: la misma Idempotency-Key en la otra replica =="
# ===============================================================================================
bash "$RAIZ/scripts/restablecer-demo.sh" > /dev/null
SALDO0="$(saldo_de 117)"
A="$(retiro_con_clave_en "$R1" 117 "$CLAVE-idem" 1000)"
B="$(retiro_con_clave_en "$R2" 117 "$CLAVE-idem" 1000)"
FA="$(echo "$A" | json "d['folio']")"; FB="$(echo "$B" | json "d['folio']")"
igual "el reintento en la OTRA replica devuelve el mismo folio" "$FA" "$FB"
[ -n "$FA" ] && resultado PASS "el folio tiene la forma RET-aaaammdd-nnnnnn" "$FA" || resultado FAIL "el folio tiene la forma RET-aaaammdd-nnnnnn" "vacio"
igual "el saldo bajo UNA sola vez (1000)" "$((SALDO0 - 1000))" "$(saldo_de 117)"
igual "un solo movimiento de retiro para esa clave" 1 "$(sql "SELECT count(*) FROM movimiento WHERE cuenta_id = 117 AND origen = 'RETIRO_ATM'")"
igual "una sola fila en idempotencia para esa clave" 1 "$(sql "SELECT count(*) FROM idempotencia WHERE clave = '$CLAVE-idem'")"

# La clave de idempotencia vale POR CUENTA: la misma cadena en otra cuenta es otro retiro, no el comprobante
# ajeno; y la misma cadena en la misma cuenta con otro importe se rechaza sin descontar.
SALDO_130="$(saldo_de 130)"
C="$(retiro_con_clave_en "$R1" 130 "$CLAVE-idem" 1000)"
FC="$(echo "$C" | json "d['folio']")"
[ -n "$FC" ] && [ "$FC" != "$FA" ] \
  && resultado PASS "la MISMA clave en OTRA cuenta no recibe el comprobante ajeno (folio propio)" "cuenta 117: $FA, cuenta 130: $FC" \
  || resultado FAIL "la MISMA clave en OTRA cuenta no recibe el comprobante ajeno" "cuenta 117: $FA, cuenta 130: $FC"
igual "y a la otra cuenta SI se le descuento (no se confirmo sin ejecutar)" "$((SALDO_130 - 1000))" "$(saldo_de 130)"
igual "una fila de idempotencia por cuenta para esa clave" 2 "$(sql "SELECT count(*) FROM idempotencia WHERE clave = '$CLAVE-idem'")"
CODIGO="$(core_post_codigo "$R1" 117 "$CLAVE-idem" 3000)"
igual "la misma clave en la misma cuenta con OTRO importe se rechaza (HTTP)" 422 "$CODIGO"
igual "y no descuenta: el saldo de la cuenta 117 sigue igual" "$((SALDO0 - 1000))" "$(saldo_de 117)"

# ===============================================================================================
echo "== 5. Reiniciar el core conserva los retiros =="
# ===============================================================================================
# Se deja un estado reconocible: un retiro de 2000 sobre la cuenta 116 (que el restablecimiento de la
# seccion 4 dejo en 12000) y otro de 1000 sobre la 117 (que ya tiene el de la seccion 4).
retiro_con_clave_en "$R1" 116 "$CLAVE-antes" 2000 > /dev/null
ANTES_116="$(saldo_de 116)"; ANTES_117="$(saldo_de 117)"
ANTES_MOV="$(sql "SELECT count(*) FROM movimiento WHERE origen = 'RETIRO_ATM'")"
ANTES_FOLIO="$(sql "SELECT folio FROM idempotencia WHERE clave = '$CLAVE-antes'")"
echo "  INFO  antes del reinicio: saldo 116 = $ANTES_116, saldo 117 = $ANTES_117, movimientos de retiro = $ANTES_MOV, ultimo folio = $ANTES_FOLIO"
"${COMPOSE[@]}" restart core-service > /dev/null 2>&1
bash "$RAIZ/scripts/esperar-sano.sh" > /dev/null || true
IDS=($("${COMPOSE[@]}" ps -q core-service)); R1="${IDS[0]:-}"; R2="${IDS[1]:-}"
igual "tras el reinicio, las dos replicas vuelven a estar healthy" "running healthy running healthy" \
  "$(docker inspect -f '{{.State.Status}} {{.State.Health.Status}}' "$R1" "$R2" | tr '\n' ' ' | sed 's/ $//')"
igual "cuenta 116 (por la API del core): el saldo sigue descontado" "$ANTES_116" "$(core_get /internal/v1/cuentas/116/saldo | json "int(d['saldo'])")"
igual "cuenta 117 (por la API del core): el saldo sigue descontado" "$ANTES_117" "$(core_get /internal/v1/cuentas/117/saldo | json "int(d['saldo'])")"
igual "los movimientos de retiro siguen todos" "$ANTES_MOV" "$(sql "SELECT count(*) FROM movimiento WHERE origen = 'RETIRO_ATM'")"
igual "la carga no se repitio: sigue habiendo 50 cuentas" 50 "$(sql 'SELECT count(*) FROM cuenta')"
igual "flyway_schema_history sin cambios (versiones 1 a 4, una vez)" "1 2 3 4" "$(sql "SELECT string_agg(version, ' ' ORDER BY installed_rank) FROM flyway_schema_history WHERE success")"
# El reintento de una clave anterior al reinicio sigue siendo idempotente (la clave esta en la base).
D="$(retiro_con_clave_en "$R2" 116 "$CLAVE-antes" 2000)"
igual "una clave usada ANTES del reinicio devuelve el mismo folio DESPUES" "$ANTES_FOLIO" "$(echo "$D" | json "d['folio']")"
igual "y no vuelve a descontar" "$ANTES_116" "$(saldo_de 116)"
# Los folios nuevos siguen despues de los anteriores (una secuencia, no un contador del proceso que vuelve a 1).
E="$(retiro_con_clave_en "$R1" 130 "$CLAVE-despues" 1000)"
FOLIO_NUEVO="$(echo "$E" | json "d['folio']")"
[ "${FOLIO_NUEVO##*-}" -gt "${ANTES_FOLIO##*-}" ] 2> /dev/null \
  && resultado PASS "el folio tras el reinicio es MAYOR que el de antes (no vuelve a 000001)" "$ANTES_FOLIO -> $FOLIO_NUEVO" \
  || resultado FAIL "el folio tras el reinicio es MAYOR que el de antes" "$ANTES_FOLIO -> $FOLIO_NUEVO"

# ===============================================================================================
echo "== 6. Eureka muestra dos instancias de core-service y las peticiones se reparten entre ambas =="
# ===============================================================================================
# Tras el reinicio los BFF tardan unos segundos en volver a ver al core (el cliente de Eureka baja la
# lista cada 5 s): se espera a que el cajero lo alcance.
TA="$(token_cajero 4000000000000116 1234)"
SALDO_URL="$ATM/v1/cuentas/116/saldo-disponible"
for _ in $(seq 1 30); do
  [ "$(curl_bff -o /dev/null -w '%{http_code}' "$SALDO_URL" -H "Authorization: Bearer $TA")" = 200 ] && break
  sleep 2
done
INST="$(curl -s -H 'Accept: application/json' http://127.0.0.1:8761/eureka/apps/CORE-SERVICE | python3 -c "
import sys, json
a = json.load(sys.stdin)['application']
print(len(a['instance']), ' '.join(sorted(i['instanceId'] + '=' + i['ipAddr'] + ':' + i['status'] for i in a['instance'])))" 2>/dev/null)"
case "$INST" in
  "2 "*":UP "*":UP") resultado PASS "Eureka lista DOS instancias de CORE-SERVICE, las dos UP" "$INST" ;;
  *) resultado FAIL "Eureka lista DOS instancias de CORE-SERVICE, las dos UP" "$INST" ;;
esac
HOSTS="$(docker inspect -f '{{.Config.Hostname}}' "$R1" "$R2" | sort | tr '\n' ' ' | sed 's/ $//')"
IDS_EUREKA="$(echo "$INST" | tr ' ' '\n' | grep core-service | sed 's/:core-service.*//' | sort | tr '\n' ' ' | sed 's/ $//')"
igual "los instanceId de Eureka son los nombres de host de los dos contenedores" "$HOSTS" "$IDS_EUREKA"
# Reparto: 20 consultas de saldo por el cajero (que no cachea) -> BFF -> balanceador -> core. La
# metrica de cada replica cuenta SOLO las que ella atendio.
URI_SALDO='%2Finternal%2Fv1%2Fcuentas%2F%7BcuentaId%7D%2Fsaldo'
M1_0="$(metrica_en "$R1" "$URI_SALDO")"; M2_0="$(metrica_en "$R2" "$URI_SALDO")"
for _ in $(seq 1 20); do
  curl_bff -o /dev/null "$SALDO_URL" -H "Authorization: Bearer $TA"
done
M1_1="$(metrica_en "$R1" "$URI_SALDO")"; M2_1="$(metrica_en "$R2" "$URI_SALDO")"
D1=$((M1_1 - M1_0)); D2=$((M2_1 - M2_0))
echo "  INFO  peticiones de saldo atendidas: replica 1 = $D1, replica 2 = $D2"
igual "las 20 peticiones llegaron al core (suma de las dos replicas)" 20 "$((D1 + D2))"
[ "$D1" -gt 0 ] && [ "$D2" -gt 0 ] && resultado PASS "AMBAS replicas atendieron peticiones (el balanceador reparte)" "replica 1 = $D1, replica 2 = $D2" \
  || resultado FAIL "AMBAS replicas atendieron peticiones" "replica 1 = $D1, replica 2 = $D2"
[ "$D1" -ge 5 ] && [ "$D2" -ge 5 ] && resultado PASS "ninguna replica quedo con menos de un cuarto del trafico" "replica 1 = $D1, replica 2 = $D2" \
  || resultado FAIL "ninguna replica quedo con menos de un cuarto del trafico" "replica 1 = $D1, replica 2 = $D2"
# El log de cada replica dice quien atendio cada peticion (filtro RegistroPeticionesFilter).
for id in "$R1" "$R2"; do
  n="$(docker logs "$id" 2>&1 | grep -c "atendida por la instancia $(docker inspect -f '{{.Config.Hostname}}' "$id")")"
  [ "$n" -gt 0 ] && resultado PASS "el log de $(docker inspect -f '{{.Name}}' "$id" | sed 's#^/##') identifica su instancia en cada peticion" "$n lineas" \
    || resultado FAIL "el log de $(docker inspect -f '{{.Name}}' "$id") identifica su instancia" "0 lineas"
done

# ===============================================================================================
echo "== 7. Cada base tiene su propio usuario y ese usuario no puede leer otra base =="
# ===============================================================================================
# Desde dentro del contenedor de PostgreSQL, por TCP (127.0.0.1) para que se exija la contrasena, con la
# contrasena de CADA usuario leida de su archivo de secretos. psql sale con error si no puede conectar.
conectar_como() {  # conectar_como <usuario> <base> <sentencia> : imprime el resultado o el error de psql
  "${COMPOSE[@]}" exec -T postgres sh -c \
    'PGPASSWORD="$(cat /run/secrets/$1.password)" PGCONNECT_TIMEOUT=5 psql -h 127.0.0.1 -U "$1" -d "$2" -tA -c "$3" 2>&1' _ "$1" "$2" "$3" | tr -d '\r' | head -n 1
}
for u in core auditoria notificaciones; do
  igual "$u se conecta a SU base $u" "$u|$u" "$(conectar_como "$u" "$u" 'SELECT current_user || chr(124) || current_database()')"
  for otra in core auditoria notificaciones postgres template1; do
    [ "$otra" = "$u" ] && continue
    salida="$(conectar_como "$u" "$otra" 'SELECT 1')"
    case "$salida" in
      *"permission denied for database"*|*"no CONNECT privilege"*|*"not have CONNECT"*) resultado PASS "$u NO puede conectarse a la base $otra" "$salida" ;;
      *) resultado FAIL "$u NO puede conectarse a la base $otra" "$salida" ;;
    esac
  done
done
igual "el usuario core no es superusuario ni puede crear bases ni roles" "false|false|false|false" \
  "$(sql "SELECT rolsuper || '|' || rolcreatedb || '|' || rolcreaterole || '|' || rolreplication FROM pg_roles WHERE rolname = 'core'")"
igual "cada base pertenece a su usuario" "auditoria=auditoria core=core notificaciones=notificaciones" \
  "$("${COMPOSE[@]}" exec -T postgres psql -U postgres -d postgres -tA -c "SELECT string_agg(datname || '=' || pg_get_userbyid(datdba), ' ' ORDER BY datname) FROM pg_database WHERE datname IN ('core','auditoria','notificaciones')" | tr -d '\r')"
salida="$("${COMPOSE[@]}" exec -T postgres sh -c 'PGPASSWORD=contrasena-equivocada PGCONNECT_TIMEOUT=5 psql -h 127.0.0.1 -U core -d core -tA -c "SELECT 1" 2>&1' | tr -d '\r' | head -n 1)"
case "$salida" in *"password authentication failed"*) resultado PASS "una contrasena equivocada se rechaza por TCP" "$salida" ;; *) resultado FAIL "una contrasena equivocada se rechaza por TCP" "$salida" ;; esac
salida="$("${COMPOSE[@]}" exec -T postgres sh -c 'PGCONNECT_TIMEOUT=5 psql -w -h 127.0.0.1 -U core -d core -tA -c "SELECT 1" 2>&1' | tr -d '\r' | head -n 1)"
case "$salida" in *"password"*|*"fe_sendauth"*) resultado PASS "sin contrasena no se entra por TCP" "$salida" ;; *) resultado FAIL "sin contrasena no se entra por TCP" "$salida" ;; esac
igual "volumen de secretos de PostgreSQL: dueno 70:70 (usuario postgres), modo 400/500" 0 \
  "$(docker run --rm --entrypoint sh -v bancoxyz_secretos-postgres:/s:ro "$IMAGEN_HERRAMIENTAS" -c 'find /s -mindepth 1 -exec stat -c "%u:%g %a" {} +' | awk '$1 != "70:70" || ($2 != "400" && $2 != "500")' | wc -l | tr -d ' ')"
igual "el core solo monta su volumen de secretos (no el de PostgreSQL)" "bancoxyz_secretos-core-service" \
  "$(docker inspect -f '{{range .Mounts}}{{.Name}} {{end}}' "$R1" | tr -d ' ')"

# ===============================================================================================
echo "== 8. Las contrasenas de la base no estan en el compose, ni en el entorno, ni en git =="
# ===============================================================================================
PWS=""
for u in postgres core auditoria notificaciones; do
  pw="$("${COMPOSE[@]}" exec -T postgres cat "/run/secrets/$u.password" | tr -d '\r\n')"
  [ "${#pw}" -ge 32 ] && PWS="$PWS $pw"
done
igual "las cuatro contrasenas existen y tienen 40 caracteres" 4 "$(echo $PWS | wc -w | tr -d ' ')"
TODOS="$("${COMPOSE[@]}" ps -a -q)"
INSPECT="$(docker inspect $TODOS)"
CONFIG="$("${COMPOSE[@]}" config)"
EN_ENTORNO=0; EN_COMPOSE=0; EN_GIT=0
N_ARCHIVOS="$(contar_archivos_del_proyecto)"   # sin git (zip) se recorre el arbol: ver lib-entorno.sh
for pw in $PWS; do
  EN_ENTORNO=$((EN_ENTORNO + $(echo "$INSPECT" | grep -cF "$pw")))
  EN_COMPOSE=$((EN_COMPOSE + $(echo "$CONFIG" | grep -cF "$pw") + $(grep -cF "$pw" docker-compose.yaml)))
  EN_GIT=$((EN_GIT + $(contar_archivos_con_texto "$pw")))
done
# Un 0 sobre una lista vacia no demuestra nada: si no habia archivos que revisar, la comprobacion falla.
[ "$N_ARCHIVOS" -ge 100 ] || EN_GIT="solo $N_ARCHIVOS archivos en la lista: no se reviso nada"
igual "ninguna contrasena aparece en docker inspect de ningun contenedor" 0 "$EN_ENTORNO"
igual "ninguna contrasena aparece en docker-compose.yaml ni en docker compose config" 0 "$EN_COMPOSE"
igual "ninguna contrasena aparece en un $ORIGEN_ARCHIVOS" 0 "$EN_GIT"
igual "postgres recibe la contrasena del superusuario solo como RUTA de un archivo" "POSTGRES_PASSWORD_FILE=/run/secrets/postgres.password" \
  "$(docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' "$PG" | grep -i pass)"
HIST="$(docker history --no-trunc postgres:16.15-alpine3.24 2>/dev/null | grep -ciE 'password=|POSTGRES_PASSWORD=[^ ]')"
igual "la imagen de postgres no trae ninguna contrasena en sus capas" 0 "$HIST"

echo "== 9. Tabla outbox (preparada en V1, definitiva desde V4 de F7) =="
igual "columnas de outbox" "id tipo clave creado publicado payload event_id topico" \
  "$(sql "SELECT string_agg(column_name, ' ' ORDER BY ordinal_position) FROM information_schema.columns WHERE table_name = 'outbox'")"
igual "outbox.payload es texto (se publica exactamente lo escrito)" "text" "$(sql "SELECT data_type FROM information_schema.columns WHERE table_name = 'outbox' AND column_name = 'payload'")"

echo
echo "Restableciendo los datos de demostracion..."
bash "$RAIZ/scripts/restablecer-demo.sh" > /dev/null

if [ "$FALLOS" -ne 0 ]; then echo "RESULTADO: $FALLOS de $TOTAL comprobaciones FAIL"; exit 1; fi
echo "RESULTADO: $TOTAL comprobaciones, todo PASS"
