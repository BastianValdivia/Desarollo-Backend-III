#!/usr/bin/env bash
# =====================================================================
# medir-recursos.sh: la segunda mitad del criterio, la que suele faltar.
# =====================================================================
# El descriptor pide optimizar "el tamano de las respuestas Y el consumo
# de recursos". Son dos cosas unidas por una conjuncion, no sinonimos. El
# tamano se mide con medir-canales.sh; los recursos se miden aqui.
#
# Y se miden EN EL SERVIDOR, no en el cliente: un evaluador estricto
# distingue entre configuracion DECLARADA (un numero en un yml) y consumo
# DEMOSTRADO. Este guion pregunta a cada BFF por su propio estado, de modo
# que lo que sale no es lo que pedimos sino lo que hay.
#
# Uso:  ./scripts/medir-recursos.sh
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
# ENTORNO=docker (por defecto): contenedores, TLS verificado con certs/ca.crt; ENTORNO=local:
# JVM locales del S5 con curl -k. Ver scripts/lib-entorno.sh.
source "$(dirname "${BASH_SOURCE[0]}")/lib-entorno.sh"

# metrica <servicio> <nombre> -> primer valor de la medicion
#
# Desde F1 Actuator vive en el puerto de gestion de cada BFF (HTTP, sin prefijo y SIN token). En
# Docker ese puerto (8081) no se publica: se consulta dentro del contenedor con gestion().
metrica() {
  local servicio="$1" nombre="$2"
  gestion "$servicio" "/actuator/metrics/$nombre" \
  | python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
    print(round(d["measurements"][0]["value"], 2))
except Exception:
    print("n/d")'
}

printf '%-10s %14s %14s %14s %14s\n' \
  "canal" "hilos_max_cfg" "hilos_vivos" "hilos_ocupados" "memoria_MB"
printf '%s\n' "---------------------------------------------------------------------------"

fila() {
  local nombre="$1" base="$2"
  local maxcfg vivos ocupados mem
  maxcfg=$(metrica   "$base" tomcat.threads.config.max)
  vivos=$(metrica    "$base" jvm.threads.live)
  ocupados=$(metrica "$base" tomcat.threads.busy)
  mem=$(metrica      "$base" jvm.memory.used)
  # jvm.memory.used llega en bytes; se pasa a MB para que se pueda leer
  mem=$(python3 -c "print(round($mem/1048576, 1))" 2>/dev/null || echo "$mem")
  printf '%-10s %14s %14s %14s %14s\n' "$nombre" "$maxcfg" "$vivos" "$ocupados" "$mem"
}

fila "web"    bff-web
fila "movil"  bff-mobile
fila "cajero" bff-atm

echo
echo "hilos_max_cfg es la prueba de que el pool declarado en el application.yml"
echo "se aplico de verdad: 200 en web, 100 en movil, 50 en cajero. Si los tres"
echo "dijeran 200, el bloque server.tomcat del yml no se estaria leyendo."
echo
echo "hilos_ocupados es 0 en reposo: desde F1 la pregunta entra por el puerto"
echo "de gestion y no ocupa un hilo del pool del canal. El numero interesante"
echo "es el pico bajo carga."
echo
echo "Si las columnas de hilos dicen n/d, falta server.tomcat.mbeanregistry."
echo "enabled: true en el application.yml del canal: sin el, Micrometer no"
echo "publica ninguna metrica tomcat.threads.* y el pool queda declarado pero"
echo "no medible."
