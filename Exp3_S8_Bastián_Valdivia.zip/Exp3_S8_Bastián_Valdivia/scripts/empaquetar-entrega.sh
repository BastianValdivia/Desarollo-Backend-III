#!/usr/bin/env bash
# =====================================================================
# empaquetar-entrega.sh: genera el .zip de la entrega (codigo, README y evidencias en UNA sola carpeta).
# =====================================================================
# La actividad pide: "todos deben estar en una misma carpeta" y un archivo comprimido con la nomenclatura
# ExpX_Sx_nombresyapellidos (ejemplo: Exp3_S8_Pedro_Alvarez_Leiva). Este guion crea
#
#     Exp3_S8_<Nombres_Apellidos>.zip
#       └── Exp3_S8_<Nombres_Apellidos>/      <- la carpeta unica: codigo, README.md, docs/, evidencias/, ...
#
# Uso:   scripts/empaquetar-entrega.sh Pedro_Alvarez_Leiva [--salida DIRECTORIO]
#
#   <Nombres_Apellidos>   tus nombres y apellidos separados por guion bajo, sin espacios ni tildes (como en el
#                         ejemplo de la actividad). El guion no valida que sea tu nombre: solo que sea un nombre de
#                         archivo seguro.
#   --salida DIRECTORIO   donde dejar el .zip (por defecto, dist/ dentro del repositorio, que esta en .gitignore).
#
# QUE ENTRA. Solo lo que forma parte del proyecto: los archivos versionados mas los nuevos que aun no ignora
# .gitignore (asi no se pierde un documento recien escrito que falte por commitear). Si no hay git (por ejemplo, si
# trabajas desde una copia descomprimida), se recorre el arbol aplicando las mismas exclusiones.
#
# QUE NUNCA ENTRA, aunque exista en tu carpeta de trabajo (el filtro se aplica ademas de .gitignore, por si algo se
# escapo de el):
#   - secretos: *.p12, *.jks, *.key, *.pem, *.crt, .env, y todo lo que haya dentro de una carpeta secrets/ (salvo su
#     .gitkeep vacio); respaldos/ (copias de las bases); certs/ (la CA interna se regenera al levantar el sistema);
#   - target/ y run/ (compilados y estado local), dist/ (otros zips), .git/;
#   - los documentos oficiales del curso: docs/enunciado/ y cualquier PBY2203_*.docx|pdf (llevan aviso de derechos
#     reservados de Duoc UC y no se redistribuyen).
# Despues de crear el zip se vuelve a abrir y se comprueba: que tenga una sola carpeta raiz, que esten los archivos
# imprescindibles, que no haya nada de lo prohibido y que ningun archivo de texto contenga una clave privada.
#
# Portabilidad: bash 3.2 (macOS) y Git Bash; usa python3 (que el resto de los guiones ya exigen) para escribir el zip,
# porque el comando `zip` no viene en Git Bash. Conserva el bit de ejecucion de los .sh (los monta Docker en Linux).
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ" || exit 1

NOMBRE=""
SALIDA="$RAIZ/dist"
while [ $# -gt 0 ]; do
  case "$1" in
    --salida) shift; SALIDA="${1:-}"; [ -n "$SALIDA" ] || { echo "ERROR: --salida necesita un directorio" >&2; exit 1; } ;;
    -h|--help) sed -n '2,32p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*) echo "ERROR: opcion desconocida: $1" >&2; exit 1 ;;
    *) [ -z "$NOMBRE" ] && NOMBRE="$1" || { echo "ERROR: sobra el argumento '$1'" >&2; exit 1; } ;;
  esac
  shift
done

if [ -z "$NOMBRE" ]; then
  echo "Uso: scripts/empaquetar-entrega.sh <Nombres_Apellidos> [--salida DIRECTORIO]" >&2
  echo "Ejemplo: scripts/empaquetar-entrega.sh Pedro_Alvarez_Leiva" >&2
  exit 1
fi
command -v python3 > /dev/null 2>&1 || { echo "ERROR: se necesita python3" >&2; exit 1; }

mkdir -p "$SALIDA" || { echo "ERROR: no se pudo crear $SALIDA" >&2; exit 1; }
SALIDA="$(cd "$SALIDA" && pwd)"

# La logica vive en Python: validar el nombre, listar, filtrar, escribir y volver a leer el zip.
RAIZ="$RAIZ" SALIDA="$SALIDA" NOMBRE="$NOMBRE" python3 - <<'PYEOF'
import os, re, stat, subprocess, sys, time, zipfile

raiz = os.environ["RAIZ"]
salida = os.environ["SALIDA"]
nombre = os.environ["NOMBRE"]

# --- 1. Nombre: letras, digitos y guion bajo; al menos dos partes (nombres y apellidos) ---
if not re.fullmatch(r"[A-Za-z0-9]+(_[A-Za-z0-9]+)+", nombre):
    print("ERROR: '%s' no sirve como nombre. Usa solo letras sin tildes y digitos separados por guion bajo,"
          " con al menos dos partes (ejemplo: Pedro_Alvarez_Leiva)." % nombre, file=sys.stderr)
    sys.exit(1)
carpeta = "Exp3_S8_" + nombre
destino = os.path.join(salida, carpeta + ".zip")

# --- 2. Que archivos entran ---
def listar_con_git():
    try:
        r = subprocess.run(["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
                           cwd=raiz, capture_output=True, check=True)
    except (OSError, subprocess.CalledProcessError):
        return None
    return [p for p in r.stdout.decode("utf-8").split("\0") if p]

def listar_sin_git():
    out = []
    for dirpath, dirnames, filenames in os.walk(raiz):
        dirnames[:] = [d for d in dirnames if d not in (".git",)]
        for f in filenames:
            out.append(os.path.relpath(os.path.join(dirpath, f), raiz).replace(os.sep, "/"))
    return out

# --- 3. Que NUNCA entra (ademas de .gitignore) ---
EXT_SECRETAS = (".p12", ".jks", ".key", ".pem", ".crt")
def prohibido(ruta):
    partes = ruta.split("/")
    base = partes[-1]
    if partes[0] in ("target", "run", "dist", "certs", "respaldos", ".git"):
        return "carpeta local (%s/)" % partes[0]
    if "target" in partes[:-1]:
        return "compilados (target/)"
    if ruta.startswith("docs/enunciado/") or re.match(r"^PBY2203_", base):
        return "documento oficial del curso"
    if "secrets" in partes[:-1] and base != ".gitkeep":
        return "contenido de una carpeta secrets/"
    if base.lower().endswith(EXT_SECRETAS) or base == ".env" or base.startswith(".env."):
        return "archivo de secretos"
    return None

candidatos = listar_con_git()
origen = "git (versionados y nuevos no ignorados)"
if candidatos is None:
    candidatos = listar_sin_git()
    origen = "recorrido del arbol (sin git)"
archivos, excluidos = [], []
for ruta in sorted(set(candidatos)):
    absoluta = os.path.join(raiz, ruta)
    if not os.path.isfile(absoluta) or os.path.islink(absoluta):
        continue          # borrado sin commitear, o enlace simbolico
    motivo = prohibido(ruta)
    (excluidos if motivo else archivos).append((ruta, motivo))
archivos = [r for r, _ in archivos]
if not archivos:
    print("ERROR: no se encontro ningun archivo para empaquetar", file=sys.stderr)
    sys.exit(1)

# --- 4. Escribir el zip: una sola carpeta raiz, LF intacto, bit de ejecucion conservado ---
if os.path.exists(destino):
    os.remove(destino)
with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for ruta in archivos:
        absoluta = os.path.join(raiz, ruta)
        modo = os.stat(absoluta).st_mode
        t = time.localtime(os.path.getmtime(absoluta))
        info = zipfile.ZipInfo(carpeta + "/" + ruta, date_time=(max(t.tm_year, 1980), t.tm_mon, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.create_system = 3   # Unix: asi el modo viaja en external_attr
        ejecutable = bool(modo & stat.S_IXUSR) or ruta.endswith(".sh") or ruta in ("mvnw",)
        info.external_attr = ((stat.S_IFREG | (0o755 if ejecutable else 0o644)) & 0xFFFF) << 16
        with open(absoluta, "rb") as f:
            z.writestr(info, f.read())

# --- 5. Volver a abrirlo y comprobarlo ---
errores = []
with zipfile.ZipFile(destino) as z:
    if z.testzip() is not None:
        errores.append("el zip esta danado: " + z.testzip())
    nombres = z.namelist()
    raices = {n.split("/")[0] for n in nombres}
    if raices != {carpeta}:
        errores.append("el zip debe tener UNA carpeta raiz (%s) y tiene: %s" % (carpeta, sorted(raices)))
    for imprescindible in ("README.md", "docker-compose.yaml", "pom.xml", "docs/propuesta-tecnica.md",
                           "docs/guia-de-estudio.md", "evidencias/INDICE.md", "evidencias/salidas/00-pruebas-unitarias.txt",
                           "CLAUDE.md", ".gitattributes"):
        if carpeta + "/" + imprescindible not in nombres:
            errores.append("falta " + imprescindible)
    for n in nombres:
        interno = n[len(carpeta) + 1:]
        motivo = prohibido(interno)
        if motivo:
            errores.append("no debia entrar (%s): %s" % (motivo, interno))
    claves = []
    for n in nombres:
        datos = z.read(n)
        if b"\0" in datos[:4096]:
            continue      # binario (imagenes)
        # Una clave de verdad es la cabecera PEM seguida de lineas base64; el texto "-----BEGIN PRIVATE KEY-----" a
        # secas aparece legitimamente en el codigo que LEE o ESCRIBE claves (scripts/*.java).
        if re.search(rb"-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----\s*[A-Za-z0-9+/=]{40,}", datos):
            claves.append(n)
    if claves:
        errores.append("contiene una clave privada en texto: " + ", ".join(claves))
    peso = os.path.getsize(destino)

print("Origen de la lista: %s" % origen)
print("Excluidos por el filtro (ademas de .gitignore): %d" % len(excluidos))
por_motivo = {}
for ruta, motivo in excluidos:
    por_motivo.setdefault(motivo, []).append(ruta)
for motivo in sorted(por_motivo):
    rutas = por_motivo[motivo]
    print("   %-40s %d archivo(s), por ejemplo %s" % (motivo, len(rutas), rutas[0]))
if errores:
    os.remove(destino)   # un zip que no paso la comprobacion no debe quedar para subirlo por error
    print("ERROR: la comprobacion del zip fallo (se borro el zip):", file=sys.stderr)
    for e in errores:
        print("   - " + e, file=sys.stderr)
    sys.exit(1)
print("Zip creado y comprobado: %s" % destino)
print("   %d archivos, %.1f MiB, una sola carpeta raiz: %s/" % (len(archivos), peso / 1048576.0, carpeta))
print("   comprobado: sin secretos, sin certs/, sin target/, sin docs/enunciado/, sin claves privadas en texto")
PYEOF
