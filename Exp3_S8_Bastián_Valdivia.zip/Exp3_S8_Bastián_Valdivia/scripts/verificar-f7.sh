#!/usr/bin/env bash
# =====================================================================
# verificar-f7.sh: comprobaciones de la fase F7 (mensajeria con Kafka) contra el stack levantado con
# "docker compose up -d". Imprime PASS o FAIL con el dato real de cada una; el codigo de salida es 0 solo si todas
# pasan.
#
# Que comprueba, en el orden de los criterios de termino de F7:
#   1. Infraestructura: Kafka sano, sin puertos publicados y solo en la red interna; topicos con 3 particiones;
#      kafka-ui solo en 127.0.0.1:8090; los servicios nuevos sanos y registrados en Eureka.
#   2. Un retiro produce un evento que llega a NOTIFICACIONES y a AUDITORIA; un reintento con la misma
#      Idempotency-Key no produce un segundo evento.
#   3. Las dos replicas de notificaciones se reparten las particiones (describe del grupo) y el lag queda en cero.
#   4. Con Kafka DETENIDO los retiros siguen funcionando, un login fallido no espera a Kafka, los eventos quedan
#      pendientes (outbox) y se entregan al volver Kafka.
#   5. Un mensaje invalido termina en la DLT sin bloquear el consumo (el siguiente de su particion se procesa), y un
#      fallo transitorio de la pasarela pasa por los topicos de reintento antes de la DLT.
#   6. auditoria-service exige token con auditoria:leer (401 sin token, 401 con otra audiencia, 403 sin el scope, 200),
#      el panel del ejecutivo de bff-web la consume y sale SIN esa seccion (avisandolo) si el servicio cae.
#   7. Los eventos de seguridad (PIN errado) llegan a la auditoria y a las notificaciones.
#
# QUE MODIFICA. Retiros de la cuenta 116 (se restablecen al principio y al final con scripts/restablecer-demo.sh),
# eventos sinteticos de las cuentas 9001 a 9003 (se borran de las bases al terminar), un PIN errado de la tarjeta
# 150 (se limpia con su PIN correcto). Detiene y vuelve a levantar kafka y auditoria-service, y edita (y restaura)
# config-repo/notificaciones-service.yml para la seccion 5. Dura unos 4 minutos.
#
# Portabilidad: sin construcciones de bash 4 ni de GNU en el host; requiere docker, curl y python3. Solo ENTORNO=docker.
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
if [ "${ENTORNO:-docker}" != docker ]; then
  echo "ERROR: verificar-f7.sh verifica el compose: ejecutalo con ENTORNO=docker (el valor por defecto)." >&2
  exit 2
fi
source "$RAIZ/scripts/lib-entorno.sh"
source "$RAIZ/scripts/lib-login.sh"
source "$RAIZ/scripts/lib-kafka.sh"

FALLOS=0
TOTAL=0
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() {  # igual <descripcion> <esperado> <obtenido>
  if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi
}
mayor_o_igual() {  # mayor_o_igual <descripcion> <minimo> <obtenido>
  if [ "$3" -ge "$2" ] 2> /dev/null; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado >= $2, obtenido '$3'"; fi
}
json() { python3 -c "import sys,json; d=json.load(sys.stdin); print($1)" 2> /dev/null; }
sql_n() { sql_postgres "$1" "$2" 2> /dev/null | tr -d '[:space:]'; }
ahora_ms() { python3 -c 'import time; print(int(time.time() * 1000))'; }
codigo_http() { curl -s -o /dev/null -w '%{http_code}' "$@"; }

CONFIG_NOTIF="$RAIZ/config-repo/notificaciones-service.yml"
COPIA_CONFIG="$(mktemp)"
cp "$CONFIG_NOTIF" "$COPIA_CONFIG"

limpiar() {
  cp "$COPIA_CONFIG" "$CONFIG_NOTIF" 2> /dev/null
  rm -f "$COPIA_CONFIG"
  for id in $("${COMPOSE[@]}" ps -q notificaciones-service 2> /dev/null); do
    docker exec "$id" wget -qO- --header 'Content-Type: application/json' --post-data='{}' http://127.0.0.1:8081/actuator/refresh > /dev/null 2>&1
  done
  # Si algo se interrumpio con Kafka o auditoria detenidos, se levantan de nuevo.
  "${COMPOSE[@]}" start kafka auditoria-service > /dev/null 2>&1
  # Eventos sinteticos de esta verificacion (cuentas 9001 a 9003): no son del banco y no deben quedar en las bases.
  sql_postgres notificaciones "DELETE FROM notificacion WHERE destinatario IN ('titular-cuenta-9001','titular-cuenta-9002','titular-cuenta-9003'); DELETE FROM evento_procesado WHERE event_id NOT IN (SELECT event_id FROM notificacion) AND procesado_en > now() - interval '1 hour' AND tipo = 'RETIRO_EJECUTADO' AND event_id NOT IN (SELECT event_id FROM notificacion);" > /dev/null 2>&1
  sql_postgres auditoria "DELETE FROM evento_auditado WHERE cuenta_id IN (9001, 9002, 9003);" > /dev/null 2>&1
}
trap limpiar EXIT

echo "== Preparacion: datos de demostracion restablecidos y stack sano =="
scripts/restablecer-demo.sh > /dev/null 2>&1
"$RAIZ/scripts/esperar-sano.sh" 300 > /dev/null 2>&1 && echo "  stack sano" || echo "  AVISO: el stack no esta sano; las comprobaciones lo diran"

# ---------------------------------------------------------------------
echo "== 1. Infraestructura de mensajeria =="
ID_KAFKA="$("${COMPOSE[@]}" ps -q kafka)"
igual "kafka esta healthy" healthy "$(docker inspect -f '{{.State.Health.Status}}' "$ID_KAFKA" 2> /dev/null)"
igual "kafka no publica puertos al host" "{}" "$(docker inspect -f '{{json .HostConfig.PortBindings}}' "$ID_KAFKA" 2> /dev/null)"
redes_kafka="$(docker inspect -f '{{range $k, $v := .NetworkSettings.Networks}}{{$k}} {{end}}' "$ID_KAFKA" 2> /dev/null | tr -d '\n' | sed 's/ *$//')"
igual "kafka vive solo en la red interna" "bancoxyz_interna" "$redes_kafka"
for topico in bancoxyz.retiros.v1 bancoxyz.seguridad.v1; do
  particiones="$(kafka_cli kafka-topics.sh --bootstrap-server localhost:9092 --describe --topic "$topico" 2> /dev/null | grep -o 'PartitionCount: [0-9]*' | awk '{print $2}')"
  igual "topico $topico con 3 particiones" 3 "$particiones"
done
ID_UI="$("${COMPOSE[@]}" ps -q kafka-ui)"
igual "kafka-ui publicado solo en 127.0.0.1:8090" "127.0.0.1:8090" "$(docker port "$ID_UI" 8080 2> /dev/null | head -1)"
igual "kafka-ui responde (health)" 200 "$(codigo_http http://127.0.0.1:8090/actuator/health)"
igual "kafka-ui usa una version fija (no latest)" "kafbat/kafka-ui:v1.5.0" "$(docker inspect -f '{{.Config.Image}}' "$ID_UI" 2> /dev/null)"
for servicio in notificaciones-service auditoria-service; do
  sanos=0; total=0
  for id in $("${COMPOSE[@]}" ps -q "$servicio"); do
    total=$((total + 1))
    [ "$(docker inspect -f '{{.State.Health.Status}}' "$id")" = healthy ] && sanos=$((sanos + 1))
  done
  igual "$servicio: todas sus replicas healthy" "$total/$total" "$sanos/$total"
done
eureka="$(curl -s -H 'Accept: application/json' http://127.0.0.1:8761/eureka/apps 2> /dev/null)"
igual "Eureka: 2 instancias de notificaciones-service" 2 "$(echo "$eureka" | json "len([a for a in d['applications']['application'] if a['name']=='NOTIFICACIONES-SERVICE'][0]['instance'])")"
igual "Eureka: 1 instancia de auditoria-service" 1 "$(echo "$eureka" | json "len([a for a in d['applications']['application'] if a['name']=='AUDITORIA-SERVICE'][0]['instance'])")"

# ---------------------------------------------------------------------
echo "== 2. Un retiro produce un evento que llega a notificaciones y a auditoria =="
TOKEN_CAJERO="$(token_cajero 4000000000000116 1234 2> /dev/null)"
CLAVE="f7-verificacion-$(date +%s)"
RESP="$(curl -s "${TLS[@]}" -X POST "$ATM/v1/cuentas/116/retiros" -H "Authorization: Bearer $TOKEN_CAJERO" \
  -H 'Content-Type: application/json' -H "Idempotency-Key: $CLAVE" -d '{"monto":1000}')"
FOLIO="$(echo "$RESP" | json "d['folio']")"
resultado "$([ -n "$FOLIO" ] && echo PASS || echo FAIL)" "el retiro del cajero responde con folio" "$FOLIO"
esta_en_notif() { [ "$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE mensaje LIKE '%$FOLIO%'")" = 1 ]; }
esta_en_audit() { [ "$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE datos->>'folio' = '$FOLIO'")" = 1 ]; }
esperar_hasta 40 esta_en_notif && resultado PASS "el evento llego a notificaciones (1 notificacion con el folio)" "$FOLIO" || resultado FAIL "el evento no llego a notificaciones" "$FOLIO"
esperar_hasta 40 esta_en_audit && resultado PASS "el evento llego a auditoria (1 evento con el folio)" "$FOLIO" || resultado FAIL "el evento no llego a auditoria" "$FOLIO"
igual "el mensaje de notificaciones dice cuenta y saldo" "1" "$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE mensaje LIKE '%cuenta 116%$FOLIO%Saldo disponible: \$11.000%'")"
RESP2="$(curl -s "${TLS[@]}" -X POST "$ATM/v1/cuentas/116/retiros" -H "Authorization: Bearer $TOKEN_CAJERO" \
  -H 'Content-Type: application/json' -H "Idempotency-Key: $CLAVE" -d '{"monto":1000}')"
igual "un reintento con la misma Idempotency-Key devuelve el mismo folio" "$FOLIO" "$(echo "$RESP2" | json "d['folio']")"
sleep 4
igual "y no produce un segundo evento (outbox con un solo evento de ese folio)" 1 "$(sql_n core "SELECT count(*) FROM outbox WHERE payload LIKE '%$FOLIO%'")"
igual "el outbox queda sin pendientes" 0 "$(outbox_pendientes)"

# ---------------------------------------------------------------------
echo "== 3. Reparto de particiones entre las replicas y lag en cero =="
lag_cero() { [ "$(lag_del_grupo notificaciones '^bancoxyz\.(retiros|seguridad)\.v1$')" = 0 ]; }
esperar_hasta 60 lag_cero
echo "  --- kafka-consumer-groups --describe --group notificaciones (extracto) ---"
describir_grupo notificaciones | awk '/^GROUP/ || $2 ~ /^bancoxyz\.(retiros|seguridad)\.v1$/ { print "    " $0 }'
REPARTO="$(particiones_por_cliente notificaciones '^bancoxyz\.(retiros|seguridad)\.v1$')"
igual "notificaciones: las 2 replicas son consumidores distintos del grupo" 2 "$(echo "$REPARTO" | grep -c .)"
igual "notificaciones: se reparten las 6 particiones (3 por topico)" 6 "$(echo "$REPARTO" | awk '{s += $2} END {print s + 0}')"
igual "notificaciones: cada replica tiene al menos 2 particiones" 0 "$(echo "$REPARTO" | awk '$2 < 2 {n++} END {print n + 0}')"
igual "notificaciones: lag total en cero" 0 "$(lag_del_grupo notificaciones '^bancoxyz\.(retiros|seguridad)\.v1$')"
lag_audit_cero() { [ "$(lag_del_grupo auditoria '^bancoxyz\.(retiros|seguridad)\.v1$')" = 0 ]; }
esperar_hasta 60 lag_audit_cero
igual "auditoria (grupo propio): una sola replica con las 6 particiones" "6" "$(particiones_por_cliente auditoria '^bancoxyz\.(retiros|seguridad)\.v1$' | awk '{s += $2} END {print s + 0}')"
igual "auditoria: lag total en cero" 0 "$(lag_del_grupo auditoria '^bancoxyz\.(retiros|seguridad)\.v1$')"

# ---------------------------------------------------------------------
echo "== 4. Con Kafka detenido los retiros siguen y los eventos se entregan al volver =="
BASE_NOTIF="$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE tipo='RETIRO_EJECUTADO'")"
BASE_AUDIT="$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE tipo='RETIRO_EJECUTADO'")"
"${COMPOSE[@]}" stop kafka > /dev/null 2>&1
igual "kafka detenido" "" "$("${COMPOSE[@]}" ps -q --status running kafka)"
OK=0; FOLIOS=""
for i in 1 2 3 4 5; do
  r="$(curl -s -w '\n%{http_code}' "${TLS[@]}" -X POST "$ATM/v1/cuentas/116/retiros" -H "Authorization: Bearer $TOKEN_CAJERO" \
    -H 'Content-Type: application/json' -H "Idempotency-Key: f7-sin-kafka-$i-$(date +%s)" -d '{"monto":1000}')"
  [ "$(echo "$r" | tail -1)" = 200 ] && OK=$((OK + 1))
  FOLIOS="$FOLIOS $(echo "$r" | head -1 | json "d['folio']")"
done
igual "5 retiros con Kafka detenido: los 5 responden 200" 5 "$OK"
igual "los 5 eventos esperan en el outbox" 5 "$(outbox_pendientes)"
echo "  outbox pendientes con Kafka detenido: $(outbox_pendientes)"
T0="$(ahora_ms)"
CODIGO_LOGIN="$(curl -s -o /dev/null -w '%{http_code}' "${TLS[@]}" -u "atm-scl-001:$(secreto_terminal atm-scl-001)" \
  --data-urlencode grant_type=urn:bancoxyz:params:oauth:grant-type:tarjeta-pin --data-urlencode numero_tarjeta=4000000000000150 \
  --data-urlencode pin=0000 "$AUTH_URL/oauth2/token")"
MS="$(( $(ahora_ms) - T0 ))"
igual "un PIN errado con Kafka detenido responde 400 (credenciales invalidas)" 400 "$CODIGO_LOGIN"
[ "$MS" -lt 1500 ] && resultado PASS "el login fallido no espera a Kafka (menos de 1,5 s)" "${MS} ms" || resultado FAIL "el login fallido esperaba a Kafka" "${MS} ms"
"${COMPOSE[@]}" start kafka > /dev/null 2>&1
esperar_kafka_sano 120 && resultado PASS "kafka vuelve healthy" || resultado FAIL "kafka no volvio healthy"
outbox_vacio() { [ "$(outbox_pendientes)" = 0 ]; }
esperar_hasta 120 outbox_vacio && resultado PASS "el outbox se vacia al volver Kafka (0 pendientes)" || resultado FAIL "el outbox no se vacio" "$(outbox_pendientes) pendientes"
entregados() { [ "$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE tipo='RETIRO_EJECUTADO'")" -ge $((BASE_AUDIT + 5)) ] && [ "$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE tipo='RETIRO_EJECUTADO'")" -ge $((BASE_NOTIF + 5)) ]; }
esperar_hasta 90 entregados && resultado PASS "los 5 eventos llegaron a auditoria y a notificaciones" || resultado FAIL "los eventos no llegaron a los dos consumidores"
FOLIOS_MALOS=""
for f in $FOLIOS; do
  [ "$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE datos->>'folio'='$f'")" = 1 ] || FOLIOS_MALOS="$FOLIOS_MALOS $f"
done
# Un solo resultado: PASS si todos estan exactamente una vez, FAIL con los folios que no (antes se imprimia un PASS
# incondicional detras de los FAIL del bucle y la salida se contradecia).
if [ -z "$FOLIOS_MALOS" ]; then
  resultado PASS "ninguno de los 5 folios esta duplicado ni ausente en auditoria (idempotencia)"
else
  resultado FAIL "folios ausentes o duplicados en auditoria" "${FOLIOS_MALOS# }"
fi
esperar_hasta 120 lag_cero
esperar_hasta 120 lag_audit_cero
igual "lag en cero tras la recuperacion (notificaciones)" 0 "$(lag_del_grupo notificaciones '^bancoxyz\.(retiros|seguridad)\.v1$')"
# El PIN errado que se hizo con Kafka detenido tambien se entrega al volver (cola en memoria del auth-server).
pin_llego() { [ "$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE tipo='PIN_INCORRECTO' AND sujeto='400000******0150'")" -ge 1 ]; }
esperar_hasta 60 pin_llego \
  && resultado PASS "el PIN_INCORRECTO emitido con Kafka detenido llego despues (cola del auth-server)" \
  || resultado FAIL "el PIN_INCORRECTO emitido con Kafka detenido no llego"
token_cajero 4000000000000150 9999 > /dev/null 2>&1   # PIN correcto: limpia el contador de fallos de la tarjeta 150

# ---------------------------------------------------------------------
echo "== 5. Mensaje invalido a la DLT sin bloquear, y reintentos no bloqueantes =="
CLAVE_P="$(clave_para_particion 0 3 9001)"   # una clave cuya particion es la 0; las dos claves de abajo caen juntas
BASURA="mensaje-invalido-f7-$(date +%s)"
EVENTO_SANO="$(python3 - << 'PY'
import json, uuid
print(json.dumps({"eventId": str(uuid.uuid4()), "tipo": "RETIRO_EJECUTADO", "version": 1, "ocurridoEn": "2026-10-03T12:00:00Z",
  "origen": "verificar-f7.sh", "datos": {"cuentaId": 9001, "folio": "RET-F7-SANO", "monto": 1000, "saldoAnterior": 5000,
  "saldoPosterior": 4000, "movimientoId": 1, "moneda": "CLP"}}))
PY
)"
ID_SANO="$(echo "$EVENTO_SANO" | json "d['eventId']")"
T0="$(ahora_ms)"
printf '%s|%s\n%s|%s\n' "$CLAVE_P" "$BASURA" "$CLAVE_P" "$EVENTO_SANO" | producir bancoxyz.retiros.v1
sano_procesado() { [ "$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE event_id='$ID_SANO'")" = 1 ]; }
esperar_hasta 40 sano_procesado && resultado PASS "el evento valido publicado DESPUES del invalido (misma particion) se procesa: la particion no se bloquea" "$(( $(ahora_ms) - T0 )) ms" || resultado FAIL "el evento valido no se proceso: la particion parece bloqueada"
muerta_notif() { [ "$(sql_n notificaciones "SELECT count(*) FROM carta_muerta WHERE payload='$BASURA'")" = 1 ]; }
muerta_audit() { [ "$(sql_n auditoria "SELECT count(*) FROM carta_muerta WHERE payload='$BASURA'")" = 1 ]; }
esperar_hasta 40 muerta_notif && resultado PASS "el mensaje invalido quedo en la carta muerta de notificaciones" || resultado FAIL "el mensaje invalido no llego a la DLT de notificaciones"
esperar_hasta 40 muerta_audit && resultado PASS "el mensaje invalido quedo en la carta muerta de auditoria" || resultado FAIL "el mensaje invalido no llego a la DLT de auditoria"
igual "el invalido esta en el topico bancoxyz.retiros.v1-notificaciones-dlt (una vez, sin reintentos)" 1 "$(kafka_consola bancoxyz.retiros.v1-notificaciones-dlt | grep -c "$BASURA")"
igual "y en el topico bancoxyz.retiros.v1-auditoria-dlt" 1 "$(kafka_consola bancoxyz.retiros.v1-auditoria-dlt | grep -c "$BASURA")"
igual "un mensaje invalido NO pasa por los topicos de reintento" 0 "$(for t in $(kafka_cli kafka-topics.sh --bootstrap-server localhost:9092 --list 2> /dev/null | tr -d '\r' | grep 'retiros.v1-notificaciones-retry'); do kafka_consola "$t"; done | grep -c "$BASURA")"
echo "  motivo registrado: $(sql_postgres notificaciones "SELECT left(motivo, 90) FROM carta_muerta WHERE payload='$BASURA'" 2> /dev/null | head -1)"

echo "  -- pasarela caida: reintentos no bloqueantes y luego la DLT (tarda unos 45 s) --"
sed -i.bak 's/^\(    tasa-fallo:\) .*/\1 1.0/' "$CONFIG_NOTIF" && rm -f "$CONFIG_NOTIF.bak"
refrescar_notificaciones() {
  for id in $("${COMPOSE[@]}" ps -q notificaciones-service); do
    docker exec "$id" wget -qO- --header 'Content-Type: application/json' --post-data='{}' http://127.0.0.1:8081/actuator/refresh > /dev/null 2>&1
  done
}
refrescar_notificaciones
EVENTO_FALLA="$(python3 - << 'PY'
import json, uuid
print(json.dumps({"eventId": str(uuid.uuid4()), "tipo": "RETIRO_EJECUTADO", "version": 1, "ocurridoEn": "2026-10-03T12:00:00Z",
  "origen": "verificar-f7.sh", "datos": {"cuentaId": 9002, "folio": "RET-F7-PASARELA-CAIDA", "monto": 1000, "saldoAnterior": 5000,
  "saldoPosterior": 4000, "movimientoId": 2, "moneda": "CLP"}}))
PY
)"
ID_FALLA="$(echo "$EVENTO_FALLA" | json "d['eventId']")"
printf '%s|%s\n' "$CLAVE_P" "$EVENTO_FALLA" | producir bancoxyz.retiros.v1
en_reintento() { for t in $(kafka_cli kafka-topics.sh --bootstrap-server localhost:9092 --list 2> /dev/null | tr -d '\r' | grep 'retiros.v1-notificaciones-retry'); do kafka_consola "$t" ; done | grep -q "$ID_FALLA"; }
esperar_hasta 40 en_reintento && resultado PASS "con la pasarela caida el evento paso por un topico de reintento (no bloqueante)" || resultado FAIL "el evento no aparecio en un topico de reintento"
en_dlt() { [ "$(sql_n notificaciones "SELECT count(*) FROM carta_muerta WHERE payload LIKE '%$ID_FALLA%'")" = 1 ]; }
esperar_hasta 90 en_dlt && resultado PASS "agotados los reintentos, el evento termino en la DLT" || resultado FAIL "el evento no termino en la DLT"
igual "y no se notifico (la pasarela estaba caida)" 0 "$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE event_id='$ID_FALLA'")"
echo "  motivo registrado: $(sql_postgres notificaciones "SELECT left(motivo, 100) FROM carta_muerta WHERE payload LIKE '%$ID_FALLA%'" 2> /dev/null | head -1)"
cp "$COPIA_CONFIG" "$CONFIG_NOTIF"
refrescar_notificaciones
EVENTO_RECUPERADO="$(echo "$EVENTO_SANO" | python3 -c 'import sys,json,uuid; d=json.load(sys.stdin); d["eventId"]=str(uuid.uuid4()); d["datos"]["cuentaId"]=9003; d["datos"]["folio"]="RET-F7-RECUPERADO"; print(json.dumps(d))')"
ID_REC="$(echo "$EVENTO_RECUPERADO" | json "d['eventId']")"
recuperado() { printf '%s|%s\n' "$CLAVE_P" "$EVENTO_RECUPERADO" | producir bancoxyz.retiros.v1; [ "$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE event_id='$ID_REC'")" = 1 ]; }
# El circuito de la pasarela sigue abierto hasta 10 s: se reintenta la publicacion hasta que se procesa.
for i in 1 2 3 4 5 6; do [ "$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE event_id='$ID_REC'")" = 1 ] && break; [ "$i" = 1 ] && printf '%s|%s\n' "$CLAVE_P" "$EVENTO_RECUPERADO" | producir bancoxyz.retiros.v1; sleep 5; done
igual "restablecida la pasarela, los eventos nuevos se procesan de nuevo" 1 "$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE event_id='$ID_REC'")"

# ---------------------------------------------------------------------
echo "== 6. auditoria-service exige auditoria:leer y el panel del ejecutivo la consume =="
URL_AUDIT="http://auditoria-service:8110/internal/v1/auditoria/resumen"
codigo_interno() { llamada_interna GET "$URL_AUDIT" "$@" 2> /dev/null | head -1 | awk '{print $2}'; }
igual "sin token: 401" 401 "$(codigo_interno)"
T_WEB_COMPLETO="$(token_servicio bff-web 2> /dev/null)"
T_WEB_SIN_SCOPE="$(token_servicio bff-web cuentas:leer 2> /dev/null)"
T_MOVIL="$(token_servicio bff-mobile 2> /dev/null)"
igual "token del BFF movil (audiencia solo core-service, sin el scope): 401" 401 "$(codigo_interno --bearer "$T_MOVIL")"
igual "token del BFF web con otro scope (audiencia correcta, sin auditoria:leer): 403" 403 "$(codigo_interno --bearer "$T_WEB_SIN_SCOPE")"
igual "token del BFF web con auditoria:leer: 200" 200 "$(codigo_interno --bearer "$T_WEB_COMPLETO")"
igual "las claims del token del BFF web llevan la audiencia auditoria-service" 1 "$(echo "$T_WEB_COMPLETO" | cut -d. -f2 | python3 -c 'import sys,base64,json; p=sys.stdin.read().strip(); p+="="*(-len(p)%4); d=json.loads(base64.urlsafe_b64decode(p)); sc = d["scope"]; sc = sc.split() if isinstance(sc, str) else sc; aud = d["aud"]; aud = [aud] if isinstance(aud, str) else aud; print(1 if "auditoria-service" in aud and "auditoria:leer" in sc else 0)')"
T_EJEC="$(token_web ejecutivo1 Exec.2026 2> /dev/null)"
T_CLI="$(token_web cliente116 Cliente.2026 2> /dev/null)"
PANEL="$(curl -s "${TLS[@]}" "$WEB/v1/admin/panel" -H "Authorization: Bearer $T_EJEC")"
igual "panel del ejecutivo: seccion de actividad disponible" True "$(echo "$PANEL" | json "d['actividad']['disponible']")"
mayor_o_igual "panel: la actividad trae el total de eventos auditados" 1 "$(echo "$PANEL" | json "d['actividad']['resumen']['total']")"
igual "panel: la calidad de datos esta disponible (50 cuentas)" 50 "$(echo "$PANEL" | json "d['calidadDatos']['reporte']['cuentasConsolidadas']")"
igual "panel sin token: 401" 401 "$(codigo_http "${TLS[@]}" "$WEB/v1/admin/panel")"
igual "panel con el token de un cliente: 403" 403 "$(codigo_http "${TLS[@]}" "$WEB/v1/admin/panel" -H "Authorization: Bearer $T_CLI")"
"${COMPOSE[@]}" stop auditoria-service > /dev/null 2>&1
# El cuerpo y el codigo se separan con "sed '$d'" (quita la ultima linea) y no con "head -n -1": un conteo negativo es
# una extension de GNU y el head de BSD (macOS) lo rechaza con "illegal line count".
PANEL2="$(curl -s -w '\n%{http_code}' "${TLS[@]}" "$WEB/v1/admin/panel" -H "Authorization: Bearer $T_EJEC")"
PANEL2_CUERPO="$(printf '%s\n' "$PANEL2" | sed '$d')"
igual "con auditoria detenida el panel responde 200" 200 "$(printf '%s\n' "$PANEL2" | tail -n 1)"
igual "...y marca la actividad como no disponible" False "$(echo "$PANEL2_CUERPO" | json "d['actividad']['disponible']")"
echo "  aviso: $(echo "$PANEL2_CUERPO" | json "d['actividad']['aviso']")"
igual "...con la calidad de datos intacta" True "$(echo "$PANEL2_CUERPO" | json "d['calidadDatos']['disponible']")"
"${COMPOSE[@]}" start auditoria-service > /dev/null 2>&1
panel_completo() { [ "$(curl -s "${TLS[@]}" "$WEB/v1/admin/panel" -H "Authorization: Bearer $T_EJEC" | json "d['actividad']['disponible']")" = True ]; }
esperar_hasta 150 panel_completo && resultado PASS "al volver auditoria, el panel recupera la seccion (el circuito se cierra solo)" || resultado FAIL "el panel no recupero la seccion de actividad"
igual "una ruta inexistente de la API de auditoria es 404 (no 500)" 404 "$(llamada_interna GET "http://auditoria-service:8110/internal/v1/auditoria/nada" --bearer "$T_WEB_COMPLETO" 2> /dev/null | head -1 | awk '{print $2}')"
for e in env configprops heapdump; do
  igual "auditoria-service: /actuator/$e no existe en el puerto de gestion (404)" 404 "$(interno_codigo auditoria-service 8081 /actuator/$e)"
done
igual "circuito 'auditoria' de bff-web registrado en Actuator" 1 "$(gestion bff-web /actuator/circuitbreakers | json "1 if 'auditoria' in d['circuitBreakers'] else 0")"

# ---------------------------------------------------------------------
echo "== 7. Eventos de seguridad del auth-server =="
ANTES_SEG="$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE tipo='PIN_INCORRECTO' AND sujeto='400000******0150'")"
curl -s -o /dev/null "${TLS[@]}" -u "atm-scl-001:$(secreto_terminal atm-scl-001)" \
  --data-urlencode grant_type=urn:bancoxyz:params:oauth:grant-type:tarjeta-pin --data-urlencode numero_tarjeta=4000000000000150 \
  --data-urlencode pin=0000 "$AUTH_URL/oauth2/token"
seg_llego() { [ "$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE tipo='PIN_INCORRECTO' AND sujeto='400000******0150'")" -gt "$ANTES_SEG" ]; }
esperar_hasta 40 seg_llego && resultado PASS "un PIN errado publica PIN_INCORRECTO en bancoxyz.seguridad.v1 y llega a la auditoria" || resultado FAIL "el evento de seguridad no llego a la auditoria"
igual "...con la tarjeta enmascarada (sin el numero completo)" 0 "$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE datos::text LIKE '%4000000000000150%'")"
correo_llego() { [ "$(sql_n notificaciones "SELECT count(*) FROM notificacion WHERE canal='EMAIL' AND mensaje LIKE '%400000******0150%'")" -ge 1 ]; }
esperar_hasta 40 correo_llego \
  && resultado PASS "y llega a notificaciones como un correo al equipo de seguridad" || resultado FAIL "el evento de seguridad no llego a notificaciones"

# Un numero_tarjeta sobredimensionado (1,2 MB) no debe bloquear la cola de eventos del auth-server: el sujeto del
# evento queda acotado a "****", asi que Kafka no lo rechaza, el circuito no se abre y un PIN errado legitimo posterior
# llega igual a la auditoria. Hace falta el secreto del terminal (el sujeto lo controla quien llama, no cualquiera).
TARJETA_ENORME="$(mktemp)"
python3 -c 'import sys; sys.stdout.write("9" * 1200000)' > "$TARJETA_ENORME"
c="$(curl -s -o /dev/null -w '%{http_code}' "${TLS[@]}" -u "atm-scl-001:$(secreto_terminal atm-scl-001)" \
  --data-urlencode grant_type=urn:bancoxyz:params:oauth:grant-type:tarjeta-pin --data-urlencode "numero_tarjeta@$TARJETA_ENORME" \
  --data-urlencode pin=0000 "$AUTH_URL/oauth2/token")"
rm -f "$TARJETA_ENORME"
igual "una tarjeta desconocida de 1,2 MB se rechaza con 400 (invalid_grant)" 400 "$c"
ANTES_SEG2="$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE tipo='PIN_INCORRECTO' AND sujeto='400000******0150'")"
curl -s -o /dev/null "${TLS[@]}" -u "atm-scl-001:$(secreto_terminal atm-scl-001)" \
  --data-urlencode grant_type=urn:bancoxyz:params:oauth:grant-type:tarjeta-pin --data-urlencode numero_tarjeta=4000000000000150 \
  --data-urlencode pin=0000 "$AUTH_URL/oauth2/token"
seg_llego2() { [ "$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE tipo='PIN_INCORRECTO' AND sujeto='400000******0150'")" -gt "$ANTES_SEG2" ]; }
esperar_hasta 40 seg_llego2 && resultado PASS "...y un PIN errado legitimo posterior llega a la auditoria (la cola no queda bloqueada)" || resultado FAIL "tras el evento sobredimensionado, el siguiente no llego a la auditoria"
igual "...sin eventos de seguridad pendientes en el auth-server" 0.0 "$(gestion auth-server /actuator/metrics/eventos.seguridad.pendientes | json "d['measurements'][0]['value']")"
igual "...con el sujeto del evento acotado (ninguno de mas de 64 caracteres en la auditoria)" 0 "$(sql_n auditoria "SELECT count(*) FROM evento_auditado WHERE tipo='PIN_INCORRECTO' AND length(sujeto) > 64")"
igual "...y el circuito 'kafka' del auth-server sigue CLOSED" CLOSED "$(gestion auth-server /actuator/circuitbreakers | json "d['circuitBreakers']['kafka']['state']")"
token_cajero 4000000000000150 9999 > /dev/null 2>&1

echo
echo "== Restableciendo datos de demostracion =="
scripts/restablecer-demo.sh 2> /dev/null | tail -2
echo
echo "RESULTADO: $TOTAL comprobaciones, $FALLOS FAIL"
[ "$FALLOS" = 0 ] && echo "todo PASS" || echo "HAY FALLOS"
exit $((FALLOS > 0))
