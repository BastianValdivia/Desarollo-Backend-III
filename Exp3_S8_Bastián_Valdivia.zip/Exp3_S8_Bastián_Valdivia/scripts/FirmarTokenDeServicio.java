import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Instant;
import java.util.Base64;

/**
 * Forja un token de SERVICIO (como los que emite el auth-server) para demostrar lo que el core rechaza:
 * un token vencido, uno de otra audiencia o uno firmado con una clave que no es la del auth-server.
 *
 * <h2>Que lugar ocupa esto en la arquitectura</h2>
 * Ninguno: no forma parte del sistema desplegado. Es una herramienta de evidencia, igual que
 * {@code FirmarTokenDePrueba.java} (que forja los tokens de usuario de los canales). Un token VALIDO se
 * pide siempre al auth-server con {@code client_credentials}; esta herramienta existe porque un token
 * vencido o de otra audiencia no se puede conseguir de el sin esperar cinco minutos o sin cambiar su
 * configuracion.
 *
 * <h2>Uso</h2>
 * <pre>
 * java FirmarTokenDeServicio.java &lt;pem-privado|NUEVA&gt; &lt;emisor&gt; &lt;audiencias,por,coma&gt; &lt;sub&gt;
 *                                 &lt;scopes,por,coma&gt; &lt;segundos&gt;
 * </pre>
 * <ul>
 *   <li>{@code pem-privado}: la clave privada del auth-server (PKCS#8). La palabra {@code NUEVA} genera
 *       una clave aleatoria que el core no conoce (token falsificado).</li>
 *   <li>{@code segundos}: vigencia a partir de ahora; un valor negativo produce un token ya vencido.</li>
 * </ul>
 * Imprime el JWT en una linea. No lleva {@code kid}: el core elige la clave del JWKS por tipo y
 * algoritmo, que con una sola clave publicada es la correcta.
 *
 * <p>La clave privada del auth-server solo se lee dentro de un contenedor efimero que monta su volumen
 * de secretos en solo lectura (ver {@code firmar_token_servicio} en {@code lib-entorno.sh}); nunca sale
 * del volumen.
 */
public final class FirmarTokenDeServicio {

    private FirmarTokenDeServicio() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 6) {
            System.err.println("Uso: java FirmarTokenDeServicio.java <pem-privado|NUEVA> <emisor> "
                    + "<audiencias,por,coma> <sub> <scopes,por,coma> <segundos>");
            System.exit(2);
        }
        PrivateKey clave = "NUEVA".equals(args[0]) ? claveAleatoria() : leerClavePrivada(Path.of(args[0]));
        String emisor = args[1];
        String[] audiencias = args[2].split(",");
        String sub = args[3];
        String[] scopes = args[4].split(",");
        long segundos = Long.parseLong(args[5]);

        long ahora = Instant.now().getEpochSecond();
        long expiracion = ahora + segundos;
        // Un token vencido de verdad se emitio ANTES de vencer: con exp en el pasado, iat va un minuto
        // antes que exp. Si iat quedara en "ahora" el token seria imposible (exp anterior a iat) y el
        // decodificador lo rechazaria por eso y no por estar vencido.
        long emision = expiracion <= ahora ? expiracion - 60 : ahora;

        String cabecera = "{\"alg\":\"RS256\"}";
        String cuerpo = "{"
                + "\"sub\":\"" + sub + "\","
                + "\"aud\":" + lista(audiencias) + ","
                + "\"iss\":\"" + emisor + "\","
                + "\"client_id\":\"" + sub + "\","
                + "\"scope\":" + lista(scopes) + ","
                + "\"iat\":" + emision + ","
                + "\"exp\":" + expiracion
                + "}";

        String firmable = base64Url(cabecera.getBytes(StandardCharsets.UTF_8)) + "."
                + base64Url(cuerpo.getBytes(StandardCharsets.UTF_8));
        Signature firmador = Signature.getInstance("SHA256withRSA");
        firmador.initSign(clave);
        firmador.update(firmable.getBytes(StandardCharsets.US_ASCII));
        System.out.println(firmable + "." + base64Url(firmador.sign()));
    }

    private static String lista(String[] valores) {
        StringBuilder texto = new StringBuilder("[");
        for (int i = 0; i < valores.length; i++) {
            if (i > 0) {
                texto.append(',');
            }
            texto.append('"').append(valores[i].trim()).append('"');
        }
        return texto.append(']').toString();
    }

    private static PrivateKey claveAleatoria() throws Exception {
        KeyPairGenerator generador = KeyPairGenerator.getInstance("RSA");
        generador.initialize(2048);
        return generador.generateKeyPair().getPrivate();
    }

    private static PrivateKey leerClavePrivada(Path pem) throws Exception {
        String texto = Files.readString(pem)
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s", "");
        byte[] der = Base64.getDecoder().decode(texto);
        return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(der));
    }

    private static String base64Url(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
