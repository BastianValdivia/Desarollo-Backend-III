#!/usr/bin/env bash
# =====================================================================
# verificar-no-regresion.sh: la lista de no regresion del S5 (plan, seccion 3.1)
# contra el sistema en marcha.
# =====================================================================
# Cada fila de la lista del plan es un comportamiento del S5 que tiene que seguir
# siendo verdad en cada fase. El numero entre corchetes es el de la evidencia que
# lo demostraba en el S5. Cada comprobacion imprime PASS o FAIL con el dato real
# que la sostiene; el codigo de salida es 0 solo si todas pasan.
#
#   ENTORNO=docker  (por defecto)  contra los contenedores de docker-compose.yaml
#                                  (curl --cacert certs/ca.crt, sin -k)
#   ENTORNO=local                  contra las JVM de scripts/levantar-local.sh (curl -k)
#
# ESTADO INICIAL. Las comprobaciones de retiro consumen saldo: la cuenta 116 parte con 12000 y la 106
# con 5000. Desde F3 el estado esta en PostgreSQL y sobrevive a los reinicios, asi que reiniciar el core
# ya no devuelve el estado inicial. Si el script detecta que los saldos ya no son los de la carga (una
# ejecucion anterior), llama a scripts/restablecer-demo.sh, que deshace SOLO los retiros del cajero y
# las claves de idempotencia (no toca la carga ni reinicia nada), y lo dice.
#
# Uso:  scripts/verificar-no-regresion.sh
# =====================================================================
set -u
unset JAVA_TOOL_OPTIONS
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
source "$RAIZ/scripts/lib-entorno.sh"
source "$RAIZ/scripts/lib-login.sh"

FALLOS=0
TOTAL=0
NO_VERIFICADOS=0
if [ "$ENTORNO" = local ]; then
  FALTA_HERRAMIENTA="falta java (JDK 21) en el equipo para firmar los tokens de prueba"
else
  FALTA_HERRAMIENTA="falta la imagen $IMAGEN_HERRAMIENTAS; ejecuta docker compose up -d --build"
fi
resultado() {  # resultado <PASS|FAIL> <descripcion> [dato]
  TOTAL=$((TOTAL + 1))
  printf '  %-4s %s%s\n' "$1" "$2" "${3:+  ($3)}"
  [ "$1" = PASS ] || FALLOS=$((FALLOS + 1))
}
igual() {  # igual <descripcion> <esperado> <obtenido>
  if [ "$2" = "$3" ]; then resultado PASS "$1" "$3"; else resultado FAIL "$1" "esperado '$2', obtenido '$3'"; fi
}
json() { python3 -c "import sys,json; d=json.load(sys.stdin); print($1)" 2>/dev/null; }
codigo() { curl_bff -o /dev/null -w '%{http_code}' "$@"; }
# Reintenta SOLO mientras la respuesta sea 503: justo despues de levantar o reiniciar un servicio
# el balanceador aun no tiene la lista de instancias (el cliente de Eureka la baja cada 5 s).
codigo_estable() {
  local c n=0
  while :; do
    c="$(codigo "$@")"
    if [ "$c" != 503 ] || [ "$n" -ge 30 ]; then echo "$c"; return; fi
    n=$((n + 1)); sleep 2
  done
}
# Desde F5 el login es del auth-server (authorization_code con PKCE para web y movil, tarjeta y PIN para el
# cajero): estas funciones lo hacen de verdad (scripts/lib-login.sh) y devuelven {accessToken, tipoToken, expiraEn}.
login_web()    { login_web_s5 "$@"; }
login_movil()  { login_movil_s5 "$@"; }
login_cajero() { login_cajero_s5 "$@"; }
token_de() { json "d['accessToken']"; }
# claim <token> <nombre>: valor de un claim del payload (base64 URL sin relleno)
claim() {
  python3 -c "
import base64,json,sys
p=sys.argv[1].split('.')[1]; p+='='*(-len(p)%4)
v=json.loads(base64.urlsafe_b64decode(p)).get(sys.argv[2]); print(v)" "$1" "$2"
}
cab_movil() { echo -H "X-Device-Id: dispositivo-demo-01"; }

echo "Entorno: $ENTORNO ($([ "$ENTORNO" = docker ] && echo "TLS verificado con ${CA_CRT#$RAIZ/}" || echo "curl -k, certificados autofirmados del S5"))"

# ---------------------------------------------------------------------
echo "== 0. Estado inicial del core (cuentas 116 y 106) =="
# ---------------------------------------------------------------------
saldo_core() { core_get "/internal/v1/cuentas/$1/saldo" | json "int(d['saldo'])"; }
S116="$(saldo_core 116)"; S106="$(saldo_core 106)"
if [ "$S116" != 12000 ] || [ "$S106" != 5000 ]; then
  echo "  El core no esta en su estado inicial (116=$S116, 106=$S106; esperado 12000 y 5000)."
  echo "  Restableciendo los saldos de la carga con scripts/restablecer-demo.sh (solo deshace retiros)..."
  bash "$RAIZ/scripts/restablecer-demo.sh" > /dev/null || echo "  (no se pudo restablecer)"
  S116="$(saldo_core 116)"; S106="$(saldo_core 106)"
fi
igual "cuenta 116 con saldo inicial 12000" 12000 "$S116"
igual "cuenta 106 con saldo inicial 5000" 5000 "$S106"
# Tras un reinicio, los BFF tardan unos segundos en volver a ver al core (el cliente de Eureka baja
# la lista cada 5 s): se espera a que el cajero, que no cachea, lo alcance.
TA0="$(login_cajero 4000000000000116 1234 | token_de)"
[ -n "$TA0" ] && igual "el cajero alcanza al core" 200 "$(codigo_estable "$ATM/v1/cuentas/116/saldo-disponible" -H "Authorization: Bearer $TA0")"

# ---------------------------------------------------------------------
echo "== [04] Carga del dataset: 50 cuentas, 686 movimientos y descartes informados =="
# ---------------------------------------------------------------------
TE="$(login_web ejecutivo1 Exec.2026 | token_de)"
codigo_estable "$WEB/v1/admin/calidad-datos" -H "Authorization: Bearer $TE" > /dev/null
CAL="$(curl_bff "$WEB/v1/admin/calidad-datos" -H "Authorization: Bearer $TE")"
igual "cuentas consolidadas" 50 "$(echo "$CAL" | json "d['cuentasConsolidadas']")"
igual "movimientos cargados" 686 "$(echo "$CAL" | json "d['movimientosCargados']")"
# El orden de las claves del JSON cambia de una ejecucion a otra (es un mapa): se compara ordenado.
igual "descartes por motivo" "[('EDAD_FUERA_DE_RANGO', 362), ('FECHA_ILEGIBLE', 0), ('MONTO_NO_POSITIVO', 314), ('SALDO_INVALIDO', 207), ('TIPO_INVALIDO', 326)]" "$(echo "$CAL" | json "sorted(d['descartesPorMotivo'].items())")"
igual "duplicadas descartadas por archivo" "[0, 9, 0]" "$(echo "$CAL" | json "[a['duplicadasDescartadas'] for a in d['archivos']]")"
# Los numeros tambien salen de PostgreSQL, no solo de la API: la carga ocurrio una vez (migracion V2 de
# Flyway) y los 686 movimientos de la carga siguen intactos aunque ya haya retiros.
CARGA="$(sql_postgres core "SELECT (SELECT count(*) FROM cuenta) || ' ' || (SELECT count(*) FROM movimiento WHERE origen = 'CSV_SEMILLA') || ' ' || (SELECT count(*) FROM transaccion_no_conciliada) || ' ' || (SELECT count(*) FROM flyway_schema_history WHERE version = '2' AND success)" 2>/dev/null)"
igual "PostgreSQL: cuentas, movimientos de la carga, sin conciliar y carga aplicada una vez" "50 686 1000 1" "$CARGA"

# ---------------------------------------------------------------------
echo "== [07, 09, 10] HTTPS en los tres BFF, cada uno con su propia identidad =="
# ---------------------------------------------------------------------
identidad() {  # identidad <puerto> -> "CN=... TLSv..." verificando contra la CA (docker) o sin verificar (local)
  python3 - "$1" "${CA_CRT:-}" <<'PY'
import socket, ssl, sys, subprocess
puerto, ca = int(sys.argv[1]), sys.argv[2]
if ca:
    ctx = ssl.create_default_context(cafile=ca)
    with socket.create_connection(("localhost", puerto), timeout=10) as s, ctx.wrap_socket(s, server_hostname="localhost") as t:
        c = t.getpeercert()
        cn = dict(x[0] for x in c["subject"])["commonName"]
        emisor = dict(x[0] for x in c["issuer"])["commonName"]
        san = ",".join(v for k, v in c["subjectAltName"])
        print(f"CN={cn} emisor='{emisor}' SAN={san} {t.version()}")
else:
    ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
    with socket.create_connection(("localhost", puerto), timeout=10) as s, ctx.wrap_socket(s, server_hostname="localhost") as t:
        print(f"(local, sin verificar) {t.version()}")
PY
}
for par in "8443 bff-web" "8444 bff-mobile" "8445 bff-atm"; do
  set -- $par
  id="$(identidad "$1" 2>&1)"
  if [ "$ENTORNO" = docker ]; then
    case "$id" in
      "CN=$2 "*) resultado PASS "$2 :$1 presenta su propio certificado, verificado con la CA" "$id" ;;
      *) resultado FAIL "$2 :$1 presenta su propio certificado, verificado con la CA" "$id" ;;
    esac
  else
    case "$id" in *TLSv1*) resultado PASS "$2 :$1 sirve TLS" "$id" ;; *) resultado FAIL "$2 :$1 sirve TLS" "$id" ;; esac
  fi
done

# ---------------------------------------------------------------------
echo "== [12] Sin token, los tres canales responden 401 =="
# ---------------------------------------------------------------------
W="$WEB/v1/cuentas/116"; M="$MOVIL/v1/cuentas/116/resumen"; A="$ATM/v1/cuentas/116/saldo-disponible"
igual "web sin token" 401 "$(codigo_estable "$W")"
igual "movil sin token" 401 "$(codigo_estable "$M")"
igual "cajero sin token" 401 "$(codigo_estable "$A")"

# ---------------------------------------------------------------------
echo "== [13] Vigencia del token por canal: 1800, 3600 y 180 s =="
# ---------------------------------------------------------------------
RW="$(login_web cliente116 Cliente.2026)"; RM="$(login_movil cliente116 Cliente.2026)"; RA="$(login_cajero 4000000000000116 1234)"
TW="$(echo "$RW" | token_de)"; TM="$(echo "$RM" | token_de)"; TA="$(echo "$RA" | token_de)"
vigencia() {  # vigencia <canal> <respuesta-de-login> <token> <esperado>
  local exp iat
  exp="$(claim "$3" exp)"; iat="$(claim "$3" iat)"
  # expires_in de la respuesta OAuth 2.0 se calcula contra el reloj en el instante de responder: puede ser 1 menos
  # que la vigencia (1799 de 1800). El dato exacto es exp - iat del JWT.
  local ei; ei="$(echo "$2" | json "d['expiraEn']")"
  [ "$ei" -ge $(($4 - 1)) ] && [ "$ei" -le "$4" ] \
    && resultado PASS "$1: expires_in de la respuesta de login (en $(($4 - 1)) a $4)" "$ei" \
    || resultado FAIL "$1: expires_in de la respuesta de login" "esperado $(($4 - 1)) o $4, obtenido '$ei'"
  igual "$1: exp - iat del JWT" "$4" "$((exp - iat))"
}
vigencia web "$RW" "$TW" 1800
vigencia movil "$RM" "$TM" 3600
vigencia cajero "$RA" "$TA" 180

# ---------------------------------------------------------------------
echo "== [15] Matriz 3x3: el token de un canal no sirve en otro =="
# ---------------------------------------------------------------------
probar() { codigo_estable "$2" -H "Authorization: Bearer $1" "${@:3}"; }
MAT="$(for t in "$TW" "$TM" "$TA"; do
  printf '%s %s %s\n' "$(probar "$t" "$W")" "$(probar "$t" "$M" -H 'X-Device-Id: dispositivo-demo-01')" "$(probar "$t" "$A")"
done)"
igual "fila del token web (web, movil, cajero)" "200 401 401" "$(echo "$MAT" | sed -n 1p)"
igual "fila del token movil" "401 200 401" "$(echo "$MAT" | sed -n 2p)"
igual "fila del token cajero" "401 401 200" "$(echo "$MAT" | sed -n 3p)"

# ---------------------------------------------------------------------
echo "== [16] Titularidad: un token de la cuenta 116 pidiendo la 105 recibe 403 =="
# ---------------------------------------------------------------------
igual "web 116 pide 105" 403 "$(codigo "$WEB/v1/cuentas/105" -H "Authorization: Bearer $TW")"
igual "movil 116 pide 105" 403 "$(codigo "$MOVIL/v1/cuentas/105/resumen" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01')"
igual "cajero 116 pide 105" 403 "$(codigo "$ATM/v1/cuentas/105/saldo-disponible" -H "Authorization: Bearer $TA")"

# ---------------------------------------------------------------------
echo "== [17] Permisos distintos dentro del mismo canal (cliente y ejecutivo) =="
# ---------------------------------------------------------------------
igual "web: cliente en el panel del ejecutivo" 403 "$(codigo "$WEB/v1/admin/calidad-datos" -H "Authorization: Bearer $TW")"
igual "web: ejecutivo en el panel del ejecutivo" 200 "$(codigo "$WEB/v1/admin/calidad-datos" -H "Authorization: Bearer $TE")"
T105="$(login_cajero 4000000000000105 4321 | token_de)"
igual "cajero: tarjeta sin permiso de retiro intenta retirar" 403 "$(codigo -X POST "$ATM/v1/cuentas/105/retiros" -H "Authorization: Bearer $T105" -H 'Content-Type: application/json' -d '{"monto":1000}')"

# ---------------------------------------------------------------------
echo "== [18] Movil: el token queda atado al dispositivo =="
# ---------------------------------------------------------------------
igual "mismo dispositivo" 200 "$(codigo "$M" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01')"
igual "otro dispositivo" 401 "$(codigo "$M" -H "Authorization: Bearer $TM" -H 'X-Device-Id: telefono-robado-99')"

# ---------------------------------------------------------------------
echo "== [19] Cajero: solo autentican los terminales autorizados =="
# ---------------------------------------------------------------------
# Desde F5 el terminal se autentica en el auth-server (cliente atm-scl-001 con su secreto) y solo el puede
# emitir tokens de cajero. Un terminal que no esta registrado no obtiene token.
igual "terminal registrado atm-scl-001: el auth-server emite el token" 200 "$(codigo_login_cajero 4000000000000116 1234 atm-scl-001)"
igual "terminal desconocido atm-scl-999: el auth-server responde 401 invalid_client" "401 invalid_client" "$(codigo_login_cajero 4000000000000116 1234 atm-scl-999) $(motivo_login_cajero 4000000000000116 1234 atm-scl-999)"

# ---------------------------------------------------------------------
echo "== [21] Optimizacion por canal: tamanos, gzip, cache y ETag =="
# ---------------------------------------------------------------------
CORE_B="$(core_bytes /internal/v1/cuentas/116)"
bytes() { curl_bff -o /dev/null -w '%{size_download}' "$@"; }
WB="$(bytes "$W" -H "Authorization: Bearer $TW")"; WBZ="$(bytes --compressed "$W" -H "Authorization: Bearer $TW")"
MB="$(bytes "$M" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01')"
AB="$(bytes "$A" -H "Authorization: Bearer $TA")"; ABZ="$(bytes --compressed "$A" -H "Authorization: Bearer $TA")"
[ "$WB" -lt "$CORE_B" ] && resultado PASS "web responde menos bytes que el core" "web $WB < core $CORE_B" || resultado FAIL "web responde menos bytes que el core" "web $WB, core $CORE_B"
[ "$MB" -lt "$CORE_B" ] && resultado PASS "movil responde menos bytes que el core" "movil $MB < core $CORE_B" || resultado FAIL "movil responde menos bytes que el core" "movil $MB, core $CORE_B"
[ "$AB" -lt "$CORE_B" ] && resultado PASS "cajero responde menos bytes que el core" "cajero $AB < core $CORE_B" || resultado FAIL "cajero responde menos bytes que el core" "cajero $AB, core $CORE_B"
[ "$WBZ" -lt "$WB" ] && resultado PASS "web comprime con gzip" "$WB -> $WBZ bytes" || resultado FAIL "web comprime con gzip" "$WB -> $WBZ bytes"
igual "cajero NO comprime (a proposito: su cuerpo es de unos 43 bytes)" "$AB" "$ABZ"
ETAG="$(curl_bff -o /dev/null -D - "$M" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01' | grep -i '^etag:' | tr -d '\r' | sed 's/^[Ee][Tt][Aa][Gg]: //')"
case "$ETAG" in W/*) resultado PASS "movil emite un ETag debil" "$ETAG" ;; *) resultado FAIL "movil emite un ETag debil" "${ETAG:-sin ETag}" ;; esac
igual "movil con If-None-Match responde 304" 304 "$(codigo "$M" -H "Authorization: Bearer $TM" -H 'X-Device-Id: dispositivo-demo-01' -H "If-None-Match: $ETAG")"
URI_CUENTA='%2Finternal%2Fv1%2Fcuentas%2F%7BcuentaId%7D'; URI_SALDO='%2Finternal%2Fv1%2Fcuentas%2F%7BcuentaId%7D%2Fsaldo'
a="$(contador_core "$URI_CUENTA")"; for _ in 1 2 3 4 5; do codigo "$W" -H "Authorization: Bearer $TW" > /dev/null; done; b="$(contador_core "$URI_CUENTA")"
[ $((b - a)) -le 1 ] && resultado PASS "cache web: 5 peticiones, a lo mas 1 llamada al core" "$((b - a)) llamada(s)" || resultado FAIL "cache web" "$((b - a)) llamadas"
a="$(contador_core "$URI_SALDO")"; for _ in 1 2 3 4 5; do codigo "$A" -H "Authorization: Bearer $TA" > /dev/null; done; b="$(contador_core "$URI_SALDO")"
igual "cajero sin cache: 5 peticiones, 5 llamadas al core" 5 "$((b - a))"

# ---------------------------------------------------------------------
echo "== [23] Retiro atomico e idempotente =="
# ---------------------------------------------------------------------
CLAVE="verif-$(date +%s)-$$"
retiro() { curl_bff -X POST "$ATM/v1/cuentas/$1/retiros" -H "Authorization: Bearer $2" -H 'Content-Type: application/json' -H "Idempotency-Key: $3" -d "{\"monto\":$4}" -w '\n%{http_code}'; }
R1="$(retiro 116 "$TA" "$CLAVE" 1000)"; R2="$(retiro 116 "$TA" "$CLAVE" 1000)"
igual "primer retiro de 1000" 200 "$(echo "$R1" | tail -1)"
igual "reintento con la misma Idempotency-Key responde 200" 200 "$(echo "$R2" | tail -1)"
igual "el reintento devuelve el mismo folio" "$(echo "$R1" | head -1 | json "d['folio']")" "$(echo "$R2" | head -1 | json "d['folio']")"
igual "el saldo bajo UNA sola vez (12000 -> 11000)" 11000 "$(saldo_core 116)"
igual "monto no multiplo de 1000" "422 monto_no_multiplo" "$(retiro 116 "$TA" "m-$CLAVE" 1500 | { read -r l; read -r c; echo "$c $(echo "$l" | json "d['motivo']")"; })"
igual "monto sobre el tope por operacion" "422 supera_tope_transaccion" "$(retiro 116 "$TA" "t-$CLAVE" 15000 | { read -r l; read -r c; echo "$c $(echo "$l" | json "d['motivo']")"; })"
igual "el canal web no expone retiros (lo que no existe no se puede atacar)" 404 "$(codigo -X POST "$WEB/v1/cuentas/116/retiros" -H "Authorization: Bearer $TW" -H 'Content-Type: application/json' -d '{"monto":1000}')"
# Concurrencia: la cuenta 106 tiene 5000. Diez retiros SIMULTANEOS de 1000 (claves distintas) tienen
# que dar exactamente cinco exitos, cinco rechazos 409 por saldo insuficiente y saldo final 0:
# ni un exito de mas (se pagaria dinero que no existe) ni uno de menos.
T106="$(login_cajero 4000000000000106 5678 | token_de)"
DIR="$(mktemp -d)"
for i in $(seq 1 10); do
  ( retiro 106 "$T106" "conc-$CLAVE-$i" 1000 | tail -1 > "$DIR/$i"; echo >> "$DIR/$i" ) &
done
wait
EXITOS="$(cat "$DIR"/* | grep -c '^200$')"; RECHAZOS="$(cat "$DIR"/* | grep -c '^409$')"; MAMPARO="$(cat "$DIR"/* | grep -c '^503$')"
rm -rf "$DIR"
# Desde F6 el cajero tiene un mamparo de 5 llamadas simultaneas al core (decision D6): de 10 retiros simultaneos, los
# que llegan con el mamparo lleno reciben 503 al instante SIN tocar el core (no descuentan nada); los demas llegan al core,
# que atiende 5 y rechaza el resto por saldo (409). Lo que prueba este caso no cambia: el retiro es atomico, entran
# exactamente 5 y el saldo no baja de cero. Lo que cambia es COMO se rechazan los otros 5.
igual "10 retiros simultaneos de 1000 sobre 5000: exitos" 5 "$EXITOS"
igual "10 retiros simultaneos: los otros 5 se rechazan (409 por saldo o 503 del mamparo del cajero)" 5 "$((RECHAZOS + MAMPARO))"
echo "  INFO  rechazos por saldo (409): $RECHAZOS; por el mamparo del cajero (503, no llegaron al core): $MAMPARO"
igual "saldo final de la cuenta 106" 0 "$(saldo_core 106)"

# ---------------------------------------------------------------------
echo "== [24, 25] Casos borde: la cuenta 130 sin movimientos y una cuenta inexistente =="
# ---------------------------------------------------------------------
# Ni la 130 ni la 999 tienen credencial sembrada en el auth-server. Se firman tokens con la herramienta de
# evidencia (scripts/FirmarTokenDePrueba.java) y la clave del auth-server, que es la UNICA clave de firma desde F5:
# el canal los valida con el JWKS del auth-server como a cualquier otro, no se debilita nada. La herramienta
# necesita un JDK, pero el equipo del evaluador solo tiene que tener Docker: en ENTORNO=docker corre en un contenedor
# efimero (lib-entorno.sh, firmar_token) y la clave privada no sale del volumen del auth-server.
forjar() {  # forjar <canal:web|movil|cajero> <cuenta>
  case "$1" in
    web)    firmar_token bff-web "cliente$2" "$2" WEB 600 'ROLE_CLIENTE_WEB,PERM_cuenta:leer,PERM_movimientos:leer,PERM_resumen:leer' ;;
    movil)  firmar_token bff-mobile "cliente$2" "$2" MOVIL 600 'ROLE_CLIENTE_MOVIL,PERM_saldo:leer,PERM_dispositivo:gestionar' '"device_id":"dispositivo-demo-01"' ;;
    cajero) firmar_token bff-atm "400000******$2" "$2" ATM 600 'ROLE_CLIENTE_ATM,PERM_saldo:leer' '"terminal":"ATM-SCL-001"' ;;
  esac
}
if herramientas_java_disponibles; then
  # Regla propia del cajero en el BFF: aunque la firma, el emisor, la audiencia y la vigencia sean validas, un token
  # cuyo terminal no esta registrado se rechaza (401 terminal_no_registrado).
  TPIRATA="$(firmar_token bff-atm "400000******0116" 116 ATM 180 'ROLE_CLIENTE_ATM,PERM_saldo:leer' '"terminal":"ATM-PIRATA-666"')"
  igual "cajero: token con un terminal no registrado (ATM-PIRATA-666)" 401 "$(codigo "$ATM/v1/cuentas/116/saldo-disponible" -H "Authorization: Bearer $TPIRATA")"
  for cta in 130 999; do
    TWc="$(forjar web $cta)"; TMc="$(forjar movil $cta)"; TAc="$(forjar cajero $cta)"
    if [ "$cta" = 130 ]; then
      R="$(curl_bff "$WEB/v1/cuentas/130" -H "Authorization: Bearer $TWc" -w '\n%{http_code}')"
      igual "web: cuenta 130 existe" 200 "$(echo "$R" | tail -1)"
      igual "web: cuenta 130 sin movimientos" 0 "$(echo "$R" | head -1 | json "len(d['movimientos'])")"
      igual "movil: cuenta 130 existe" 200 "$(codigo "$MOVIL/v1/cuentas/130/resumen" -H "Authorization: Bearer $TMc" -H 'X-Device-Id: dispositivo-demo-01')"
      igual "cajero: cuenta 130 existe" 200 "$(codigo "$ATM/v1/cuentas/130/saldo-disponible" -H "Authorization: Bearer $TAc")"
    else
      igual "web: cuenta inexistente 999" 404 "$(codigo "$WEB/v1/cuentas/999" -H "Authorization: Bearer $TWc")"
      igual "movil: cuenta inexistente 999" 404 "$(codigo "$MOVIL/v1/cuentas/999/resumen" -H "Authorization: Bearer $TMc" -H 'X-Device-Id: dispositivo-demo-01')"
      igual "cajero: cuenta inexistente 999" 404 "$(codigo "$ATM/v1/cuentas/999/saldo-disponible" -H "Authorization: Bearer $TAc")"
    fi
  done
else
  # Falta una HERRAMIENTA, no se rompio el sistema: se dice con todas las letras que esta parte NO se
  # verifico (ni PASS ni FAIL) y el resumen final lo recuerda; no se da por buena en silencio.
  NO_VERIFICADOS=$((NO_VERIFICADOS + 1))
  echo "  NO VERIFICADO  casos borde 130 y 999 en los tres canales  ($FALTA_HERRAMIENTA)"
fi

# Los retiros de las comprobaciones dejan la cuenta 116 en 11000 y la 106 en 0: quien corra esta lista y luego pruebe un
# retiro a mano en la 106 recibiria 409 y creeria que algo esta roto. Se devuelven los saldos de la carga al terminar,
# como ya hace verificar-f3.sh (solo en el entorno de contenedores, que es donde existe restablecer-demo.sh).
if [ "${ENTORNO:-docker}" = docker ]; then
  echo
  echo "  Restableciendo los saldos de la carga al terminar (scripts/restablecer-demo.sh)..."
  bash "$RAIZ/scripts/restablecer-demo.sh" > /dev/null && echo "  saldos de la carga restablecidos" || echo "  (no se pudo restablecer)"
fi

echo
if [ "$FALLOS" -ne 0 ]; then echo "RESULTADO: $FALLOS de $TOTAL comprobaciones FAIL"; exit 1; fi
if [ "$NO_VERIFICADOS" -ne 0 ]; then
  echo "RESULTADO: $TOTAL comprobaciones PASS, pero $NO_VERIFICADOS bloque(s) NO VERIFICADO(S) por falta de herramienta (ver arriba)"
  exit 3
fi
echo "RESULTADO: $TOTAL comprobaciones, todo PASS"
