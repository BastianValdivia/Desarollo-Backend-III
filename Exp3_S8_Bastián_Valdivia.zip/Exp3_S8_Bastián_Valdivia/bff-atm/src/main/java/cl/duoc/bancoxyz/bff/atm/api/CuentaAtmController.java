package cl.duoc.bancoxyz.bff.atm.api;

import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.bancoxyz.bff.atm.aplicacion.ConsultaSaldoAtmService;
import cl.duoc.bancoxyz.bff.atm.aplicacion.RetiroAtmService;
import cl.duoc.bancoxyz.bff.atm.api.dto.RetiroAtmResponse;
import cl.duoc.bancoxyz.bff.atm.api.dto.SaldoDisponibleAtmResponse;
import cl.duoc.bancoxyz.bff.atm.api.dto.SolicitudRetiroAtm;

/**
 * Controlador del recurso "cuenta" en el canal cajero: A2, la consulta de saldo, y A3, el retiro.
 *
 * <h2>Que es un controlador y que no es</h2>
 *
 * <p>Es la capa que habla HTTP: traduce una peticion entrante en una llamada a la capa de
 * aplicacion, y el resultado de esa llamada en una respuesta. Nada mas. Aqui no hay reglas de
 * negocio, no hay traduccion de DTO y no hay {@code try/catch}: si algo falla, la excepcion sube
 * hasta {@link ManejadorErroresAtm}, que es el unico lugar del canal donde se decide como se ve un
 * error desde afuera. Un controlador delgado no es una moda: es lo que permite cambiar el protocolo
 * (manana, mensajeria en vez de HTTP) sin tocar la logica.
 *
 * <h2>La ruta real no es la que esta escrita aqui</h2>
 *
 * <p>Este controlador declara {@code /v1/cuentas/...}, pero el canal tiene el {@code context-path}
 * {@code /api/atm} configurado en {@code config-repo/bff-atm.yml}. La URL que responde de verdad es:
 *
 * <pre>
 * https://localhost:8445/api/atm/v1/cuentas/116/saldo-disponible
 * </pre>
 *
 * <p>Actuator ya no depende de ese prefijo: desde la fase F1 vive en un puerto de gestion aparte,
 * sin {@code context-path} y sin token ({@code http://127.0.0.1:8084/actuator/health} en local).
 * Pedir {@code /api/atm/actuator/health} en el puerto de servicio responde 404, y es el origen del
 * 404 mas frecuente del proyecto.
 *
 * <h2>Que es @AuthenticationPrincipal Jwt, para quien recien pregunto que es un puerto</h2>
 *
 * <p>Cuando la cadena de filtros valida el token, guarda el resultado en el contexto de seguridad de
 * la peticion. Esa anotacion le pide a Spring que lo inyecte como parametro, ya verificado. Es
 * importante entender lo que <b>no</b> hace: no valida nada. Si el token fuera invalido, la peticion
 * no habria llegado hasta este metodo. Lo que llega aqui es un token cuya firma, vigencia y
 * audiencia ya estan comprobadas, y por eso se puede leer su claim {@code cuentaId} y creerselo.
 */
@RestController
@RequestMapping("/v1/cuentas")
public class CuentaAtmController {

    /**
     * Nombre congelado de la cabecera de idempotencia (seccion 3 del contrato).
     *
     * <p>Este canal la <b>reenvia</b> al core y no guarda nada con ella: la idempotencia protege una
     * mutacion de estado, y el estado tiene un unico dueno.
     */
    public static final String CABECERA_IDEMPOTENCIA = "Idempotency-Key";

    private final ConsultaSaldoAtmService consultaSaldo;
    private final RetiroAtmService retiro;

    public CuentaAtmController(ConsultaSaldoAtmService consultaSaldo, RetiroAtmService retiro) {
        this.consultaSaldo = consultaSaldo;
        this.retiro = retiro;
    }

    /**
     * A2: devuelve <b>dos campos y nada mas</b>, {@code saldoDisponible} y {@code moneda}.
     *
     * <p>Es la respuesta mas pequena de todo el sistema y la carta de presentacion del canal. Lo que
     * NO viaja es tan importante como lo que viaja: ni el nombre del titular, ni su edad, ni el tipo
     * de cuenta, ni un solo movimiento. Quien mira esa pantalla esta de pie en la calle y cualquiera
     * puede mirar por encima de su hombro.
     *
     * <p><b>Sobre el tipo del parametro.</b> Se declara {@code int} y no {@code String}: asi Spring
     * rechaza por si mismo una ruta como {@code /cuentas/abc/saldo-disponible} antes de que llegue
     * una sola linea de logica, y la peticion no sale nunca hacia el core. Validar en el borde es
     * mas barato que validar adentro.
     *
     * <p><b>Sobre {@code produces}.</b> Se declara explicito para que la respuesta lleve siempre
     * {@code application/json}, y para que quede a la vista el contraste con el manejador de
     * errores, que responde {@code application/problem+json}: desde la cabecera, y sin leer el
     * cuerpo, el firmware sabe si lo que viene es un saldo o un problema.
     *
     * <p><b>Por que tambien recibe el token.</b> Porque la autoridad {@code PERM_saldo:leer} que
     * exige la cadena de filtros solo dice que esta tarjeta puede consultar saldos, no que pueda
     * consultar <b>este</b> saldo. La titularidad se comprueba dentro del servicio, contra el claim
     * {@code cuentaId}.
     *
     * @param cuentaId identificador de la cuenta, entre 101 y 150 en el dataset sembrado
     */
    /**
     * Saldo disponible (A2): dos campos, 43 bytes, y <strong>ninguna copia en ninguna parte</strong>.
     *
     * <h3>La regla de oro de este canal, escrita donde se aplica</h3>
     *
     * <p>Este numero es contra el que una maquina entrega billetes. Si esta viejo, la maquina
     * entrega dinero que ya no existe, y el dinero ya salio cuando el sistema se entera. De ahi
     * sale una regla que el proyecto sostiene en cuatro sitios distintos, a proposito:
     *
     * <ol>
     *   <li><strong>En bff-atm/pom.xml</strong>: el modulo no declara la libreria de cache, asi
     *       que no hay implementacion con TTL ni autoconfiguracion. Y en
     *       {@code ElCajeroNoCacheaTest}, una prueba de arquitectura que explora el paquete del
     *       canal y falla si aparece cualquier anotacion de cache, sobre una clase o sobre un
     *       metodo. Es la prueba, y no el pom, la que da la garantia fuerte: la anotacion
     *       {@code @Cacheable} compila igual en este modulo, porque vive en spring-context.</li>
     *   <li><strong>En plataforma-comun</strong>: {@code RestCoreClient} no lleva anotacion de
     *       cache, para que este canal no herede una que nadie decidio para el.</li>
     *   <li><strong>Aqui</strong>: la respuesta viaja con {@code no-store}, que prohibe al
     *       terminal y a cualquier intermediario guardar una copia.</li>
     *   <li><strong>Sin ETag</strong>: el canal no registra el filtro que si tiene el movil,
     *       porque un 304 significa "reutiliza lo que tienes" y eso es justo lo prohibido.</li>
     * </ol>
     *
     * <p><strong>Por que se escribe la cabecera si Spring Security ya la pone.</strong> Es cierto
     * que hoy la cadena de seguridad anade {@code no-store} a todas las respuestas del canal. Pero
     * eso es una consecuencia de una configuracion general que alguien puede cambiar por un motivo
     * ajeno a este endpoint, y el dia que la cambie nada avisara de que se llevo por delante la
     * regla mas importante del cajero. Escrita aqui, la garantia deja de ser un efecto secundario
     * de otra decision y pasa a ser una propiedad de este endpoint, con su prueba automatizada
     * apuntandole.
     *
     * <p><strong>Y por que {@code no-store} y no {@code no-cache}.</strong> Los dos nombres se
     * parecen y significan cosas distintas: {@code no-cache} permite guardar una copia siempre que
     * se revalide antes de usarla; {@code no-store} prohibe guardarla. El canal movil usa el
     * primero, porque alli reutilizar un cuerpo ya descargado ahorra datos moviles y no hace dano.
     * Aqui se usa el segundo: no queremos que exista ninguna copia de este saldo en el terminal,
     * ni siquiera una que prometa revalidarse, porque el firmware de un cajero es el sitio donde
     * menos control tenemos sobre lo que ocurre con esa copia.
     */
    @GetMapping(path = "/{cuentaId}/saldo-disponible", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SaldoDisponibleAtmResponse> consultarSaldoDisponible(
            @PathVariable int cuentaId,
            @AuthenticationPrincipal Jwt token) {

        SaldoDisponibleAtmResponse saldo = consultaSaldo.consultarSaldoDisponible(cuentaId, token);

        return ResponseEntity.ok()
                .cacheControl(CacheControl.noStore())
                // Pragma y Expires son los equivalentes de HTTP/1.0 a Cache-Control, y aqui hay
                // que ponerlos A MANO por un efecto que solo se ve midiendo: Spring Security
                // anade las TRES cabeceras juntas, pero su escritor comprueba antes si la
                // respuesta ya trae Cache-Control y, si la trae, no escribe NINGUNA. Al fijar
                // Cache-Control en la linea de arriba se perdieron las otras dos sin que nada
                // avisara. Se detecto mirando la respuesta con curl -D, no leyendo el codigo.
                //
                // Podrian darse por prescindibles, ya que Cache-Control manda en todo cliente
                // moderno. Se conservan porque el cliente de ESTE canal es el firmware de un
                // cajero, que es el software mas viejo y menos actualizable del sistema, y
                // porque el costo de equivocarse aqui es un saldo reutilizado antes de entregar
                // billetes. En el canal movil, donde el cliente es una aplicacion actual y lo
                // que esta en juego son bytes, no se hace esta concesion.
                .header("Pragma", "no-cache")
                .header("Expires", "0")
                .body(saldo);
    }

    /**
     * A3: el retiro de efectivo, exclusivo de este canal.
     *
     * <p>El mismo POST contra los puertos 8443 o 8444 devuelve 404, y esa es la prueba mas directa
     * de que los tres BFF no son intercambiables.
     *
     * <p>Antes de que este metodo se ejecute ya pasaron dos controles: el token es valido y lleva la
     * autoridad {@code PERM_retiro:ejecutar}. Dentro faltan dos mas, en este orden: la titularidad
     * de la cuenta y las reglas de monto del canal. El saldo lo decide el core.
     *
     * <p><b>La cabecera de idempotencia se declara opcional</b> por la misma razon que el cuerpo del
     * login: exigirla produciria un 400 del framework, y este canal no emite 400. Que hacer cuando
     * falta es una decision de negocio, y las decisiones de negocio no se toman en el controlador.
     */
    @PostMapping(path = "/{cuentaId}/retiros",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public RetiroAtmResponse retirar(
            @PathVariable int cuentaId,
            @RequestBody(required = false) SolicitudRetiroAtm solicitud,
            @RequestHeader(value = CABECERA_IDEMPOTENCIA, required = false) String claveIdempotencia,
            @AuthenticationPrincipal Jwt token) {

        return retiro.retirar(
                cuentaId,
                solicitud == null ? null : solicitud.monto(),
                claveIdempotencia,
                token);
    }
}
