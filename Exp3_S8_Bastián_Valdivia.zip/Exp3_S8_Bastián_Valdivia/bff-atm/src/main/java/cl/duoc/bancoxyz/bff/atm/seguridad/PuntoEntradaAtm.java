package cl.duoc.bancoxyz.bff.atm.seguridad;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.bff.atm.api.dto.RespuestaErrorAtm;
import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Responde los 401 del canal: las peticiones que llegan sin token o con un token que no vale.
 *
 * <h2>Que es un "punto de entrada de autenticacion"</h2>
 *
 * <p>El nombre viene de la epoca de los formularios de login: era el sitio al que se mandaba al
 * visitante para que se identificara. En una API sin sesion no hay a donde mandarlo, asi que este
 * punto de entrada hace lo unico que tiene sentido: responder 401 y decir en un campo por que.
 *
 * <h2>La nota que ahorra una tarde: esto NO pasa por el manejador de errores</h2>
 *
 * <p>{@code ManejadorErroresAtm} es un {@code @RestControllerAdvice}, y un advice solo ve lo que
 * ocurre <b>dentro</b> del DispatcherServlet, es decir despues de que la peticion haya sido
 * despachada a un controlador. Un 401 se decide <b>antes</b>, en la cadena de filtros, cuando
 * todavia no hay controlador al que despachar. Por eso el JSON se escribe aqui a mano sobre el
 * {@link HttpServletResponse} (estado, {@code Content-Type} y cuerpo, en ese orden) en lugar de
 * devolver un objeto y confiar en que alguien lo serialice.
 *
 * <p>Si no se hiciera asi, los dos escenarios que la evaluacion de seguridad mira de cerca (el 401
 * y el 403) devolverian la pagina de error generica de Spring, que no se parece en nada al resto de
 * la API: sin {@code motivo}, sin {@code canal} y sin los dos campos de pantalla del cajero.
 *
 * <h2>Por que lleva WWW-Authenticate y el 403 no</h2>
 *
 * <p>Esa cabecera significa "identificate, y hazlo asi". Tiene sentido exacto en un 401, donde el
 * servidor no sabe quien es el que llama. En un 403 seria un consejo equivocado: a quien ya esta
 * identificado y no tiene permiso se lo estaria mandando a repetir un login que no va a cambiar
 * nada.
 */
@Component
public class PuntoEntradaAtm implements AuthenticationEntryPoint {

    private static final Logger log = LoggerFactory.getLogger(PuntoEntradaAtm.class);

    private final EscritorErrorHttp escritor;

    public PuntoEntradaAtm(EscritorErrorHttp escritor) {
        this.escritor = escritor;
    }

    @Override
    public void commence(HttpServletRequest peticion,
                         HttpServletResponse respuesta,
                         AuthenticationException fallo) throws IOException {

        String motivo = MotivoDelFalloDeToken.clasificar(fallo);

        /*
         * El detalle del fallo se registra, no se responde. Hacia adentro interesa saber si el token
         * venia manipulado o simplemente vencido; hacia afuera, en via publica, cualquier matiz de
         * mas es una pista sobre como esta construida la validacion.
         */
        log.info("401 {} en {} {}: {}", motivo, peticion.getMethod(), peticion.getRequestURI(),
                fallo.getMessage());

        respuesta.setHeader(HttpHeaders.WWW_AUTHENTICATE, "Bearer");
        escritor.escribir(respuesta, HttpStatus.UNAUTHORIZED.value(),
                RespuestaErrorAtm.de(HttpStatus.UNAUTHORIZED.value(), motivo,
                        "No autenticado", peticion.getRequestURI()));
    }
}
