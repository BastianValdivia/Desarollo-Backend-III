package cl.duoc.bancoxyz.bff.atm.api.dto;

import java.math.BigDecimal;
import java.util.List;

/**
 * Respuesta del retiro (A3): los cuatro campos del core mas el desglose que agrega este canal.
 *
 * <h2>Que es "valor que agrega el BFF" y por que este es el ejemplo mas claro</h2>
 *
 * <p>Un BFF no es un reenviador de peticiones. Los cuatro primeros campos vienen tal cual del core,
 * que es quien movio el dinero; el quinto no existe en ninguna parte del backend de dominio y se
 * calcula aqui, porque las denominaciones son configuracion de <b>esta maquina</b> y el core no
 * sabe, ni tiene por que saber, que hay una gaveta con billetes al otro lado. El mismo retiro
 * pedido desde otro canal no tendria desglose y no le faltaria nada.
 *
 * <p>La consecuencia practica esta en la seccion 11, decision 2 del contrato: {@code desglose}
 * pertenece a la respuesta del cajero y no a la del core. Asi se cumple la lista de campos
 * congelada sin contaminar el backend de dominio con un concepto de presentacion.
 *
 * <h2>El folio y la idempotencia</h2>
 *
 * <p>El {@code folio} identifica la operacion en el banco. Ante un {@code Idempotency-Key}
 * repetido, el core devuelve <b>el mismo folio</b> sin volver a mover dinero: esa igualdad es la
 * evidencia observable de que el reintento no duplico el retiro.
 *
 * @param folio          identificador unico y estable de la operacion
 * @param saldoAnterior  saldo antes del retiro
 * @param montoRetirado  lo que efectivamente salio de la cuenta
 * @param saldoPosterior saldo despues del retiro
 * @param desglose       billetes que entrega esta maquina, de mayor a menor
 */
public record RetiroAtmResponse(
        String folio,
        BigDecimal saldoAnterior,
        BigDecimal montoRetirado,
        BigDecimal saldoPosterior,
        List<DenominacionEntregadaAtm> desglose) {
}
