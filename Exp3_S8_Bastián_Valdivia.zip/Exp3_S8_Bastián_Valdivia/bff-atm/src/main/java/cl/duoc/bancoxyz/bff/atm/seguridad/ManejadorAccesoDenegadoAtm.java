package cl.duoc.bancoxyz.bff.atm.seguridad;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.bff.atm.api.dto.RespuestaErrorAtm;
import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.error.MotivosError;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Responde los 403 que decide la cadena de filtros: token valido al que le falta una autoridad.
 *
 * <h2>401 y 403 no son dos formas de decir "no"</h2>
 *
 * <p>Son dos respuestas a dos preguntas distintas, y confundirlas es el error conceptual mas comun
 * de esta capa. <b>401</b> dice "no se quien eres": falta la credencial o no vale. <b>403</b> dice
 * "se perfectamente quien eres y aun asi no puedes": la credencial es impecable y no alcanza. Para
 * el que llama, la diferencia es accionable: ante un 401 vuelve a autenticarse, ante un 403 no
 * tiene sentido que lo intente.
 *
 * <h2>Este 403 es el del permiso, no el de la cuenta ajena</h2>
 *
 * <p>El canal produce dos 403 distintos y conviene no mezclarlos:
 *
 * <ul>
 *   <li>{@code permiso_insuficiente}, que se decide <b>aqui</b>: la tarjeta de solo consulta intenta
 *       un retiro. Habla de la <b>operacion</b>: no puedes retirar, con ninguna cuenta.</li>
 *   <li>{@code cuenta_ajena}, que se decide en el servicio y viaja por el manejador de errores: el
 *       token de la cuenta 116 pide la 105. Habla del <b>dato</b>: puedes consultar saldos, pero no
 *       ese.</li>
 * </ul>
 *
 * <p>Son los niveles 2 y 3 de la seccion 6.4 del contrato, cada uno con su propia prueba, y estan
 * en sitios distintos porque responden preguntas distintas: la cadena de filtros compara el token
 * contra la regla de la ruta; la titularidad necesita ademas el dato de la URL.
 */
@Component
public class ManejadorAccesoDenegadoAtm implements AccessDeniedHandler {

    private static final Logger log = LoggerFactory.getLogger(ManejadorAccesoDenegadoAtm.class);

    private final EscritorErrorHttp escritor;

    public ManejadorAccesoDenegadoAtm(EscritorErrorHttp escritor) {
        this.escritor = escritor;
    }

    @Override
    public void handle(HttpServletRequest peticion,
                       HttpServletResponse respuesta,
                       AccessDeniedException fallo) throws IOException {

        log.info("403 permiso_insuficiente en {} {}: {}",
                peticion.getMethod(), peticion.getRequestURI(), fallo.getMessage());

        // Sin cabecera WWW-Authenticate, a diferencia del 401: quien llama ya esta identificado y
        // repetir el login no le va a dar el permiso que le falta.
        escritor.escribir(respuesta, HttpStatus.FORBIDDEN.value(),
                RespuestaErrorAtm.de(HttpStatus.FORBIDDEN.value(), MotivosError.PERMISO_INSUFICIENTE,
                        "Acceso denegado", peticion.getRequestURI()));
    }
}
