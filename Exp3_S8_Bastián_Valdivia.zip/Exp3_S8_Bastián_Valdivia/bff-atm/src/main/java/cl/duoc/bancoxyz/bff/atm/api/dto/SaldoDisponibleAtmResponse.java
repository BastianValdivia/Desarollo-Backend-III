package cl.duoc.bancoxyz.bff.atm.api.dto;

import java.math.BigDecimal;

/**
 * Respuesta del endpoint A2, {@code GET /api/atm/v1/cuentas/{id}/saldo-disponible}.
 *
 * <p><b>Es la respuesta mas pequena de todo el sistema, y eso es el punto.</b> Dos campos:
 * {@code saldoDisponible} y {@code moneda}. Nada mas. Sin titular, sin edad, sin tipo de cuenta y
 * sin un solo movimiento.
 *
 * <h2>Por que este record vive en bff-atm y no en plataforma-comun</h2>
 *
 * <p>Es la invariante que define el proyecto. Si los tres canales compartieran la forma de su
 * respuesta, los tres devolverian lo mismo y no habria nada que optimizar por canal: el patron BFF
 * se quedaria sin razon de ser. Lo que se comparte entre modulos es el <b>mecanismo</b> (como se
 * habla con el core), nunca el <b>que</b> se devuelve. Por eso este archivo esta aqui, en el modulo
 * del cajero, y ni bff-web ni bff-mobile pueden importarlo.
 *
 * <h2>Por que los nombres no son los del core</h2>
 *
 * <p>El core devuelve {@code {cuentaId, saldo, moneda}} y este canal responde
 * {@code {saldoDisponible, moneda}}. Son dos contratos distintos, congelados por separado en la
 * seccion 5.5 del contrato, y la traduccion entre ambos ocurre en la capa de aplicacion. Reutilizar
 * el DTO del core para ahorrarse esa traduccion romperia el contrato por dos campos a la vez: el
 * nombre del saldo y la presencia de {@code cuentaId}.
 *
 * <p><b>Y por que se cae {@code cuentaId}.</b> Porque el cliente ya sabe que cuenta pidio: lo puso
 * el mismo en la URL. Devolverselo es gastar bytes en repetirle algo que tiene delante. En un canal
 * cuya respuesta completa pesa poco mas de cuarenta bytes, ese campo no seria un detalle: seria una
 * fraccion apreciable del total.
 *
 * <h2>Por que esta clase no lleva {@code @JsonInclude(NON_NULL)}</h2>
 *
 * <p>Los otros dos canales si la usan para ahorrar campos vacios. Aqui se prefiere lo contrario, y
 * es deliberado: quien consume esta respuesta es el firmware de una maquina, que suele leer un
 * contrato rigido y puede romperse si un campo desaparece. Predictibilidad por sobre bytes, cuando
 * los bytes en juego son dos campos que nunca son nulos.
 *
 * @param saldoDisponible saldo consolidado de la cuenta. {@code BigDecimal} y nunca {@code double}:
 *                        el dinero no admite el redondeo binario de la coma flotante
 * @param moneda          literal {@code CLP}, tal como lo reporta el core
 */
public record SaldoDisponibleAtmResponse(
        BigDecimal saldoDisponible,
        String moneda) {
}
