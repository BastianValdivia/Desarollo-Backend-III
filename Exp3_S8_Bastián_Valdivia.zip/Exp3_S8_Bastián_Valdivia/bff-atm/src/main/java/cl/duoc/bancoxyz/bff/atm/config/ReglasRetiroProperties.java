package cl.duoc.bancoxyz.bff.atm.config;

import java.math.BigDecimal;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Las tres reglas de monto que este canal aplica <b>antes</b> de pedirle un retiro al core, leidas
 * de {@code config-repo/bff-atm.yml} bajo el prefijo {@code atm.retiro}.
 *
 * <h2>Por que estas reglas viven en el cajero y no en el core</h2>
 *
 * <p>Porque no son reglas del dinero, son reglas de <b>esta maquina</b>. El core sabe si una cuenta
 * tiene saldo; no sabe, ni tiene por que saber, que este cajero entrega billetes de 1.000 y que por
 * eso no puede despachar 1.500. Otro canal del mismo banco (una transferencia web, por ejemplo)
 * mueve 1.500 pesos sin problema. Poner el multiplo en el core le impondria a todos los canales una
 * limitacion que solo tiene sentido frente a una maquina que entrega papel.
 *
 * <h2>El orden de validacion esta congelado y no es cosmetico</h2>
 *
 * <p>Seccion 7.3 del contrato: primero <b>multiplo</b>, despues <b>minimo y tope</b>, y solo al
 * final <b>saldo</b>, que ya decide el core. El orden importa porque un mismo monto puede violar
 * dos reglas a la vez y el cliente merece saber cual le estan reprochando: 500 no es multiplo de
 * 1.000 <em>y</em> esta bajo el minimo, y la respuesta congelada es {@code monto_no_multiplo}. Si
 * cada implementacion eligiera su orden, la misma peticion daria motivos distintos en dos
 * ejecuciones y la evidencia dejaria de probar lo que dice probar.
 *
 * <h2>Por que son BigDecimal y no int</h2>
 *
 * <p>Porque el monto que llega en el cuerpo de la peticion es {@code BigDecimal} (seccion 5.1 del
 * contrato: los importes nunca son {@code double}) y comparar dinero contra un {@code int} obliga a
 * una conversion en cada regla. Se declara del mismo tipo que el dato que se compara, y las
 * comparaciones se hacen con {@code compareTo}, no con {@code equals}: para {@code BigDecimal},
 * {@code 1000} y {@code 1000.00} son iguales en valor pero distintos en {@code equals}, porque
 * {@code equals} tambien compara la escala. Es la trampa clasica de este tipo.
 *
 * @param multiplo        todo retiro debe ser multiplo exacto de este valor
 * @param minimo          monto minimo por operacion
 * @param topeTransaccion monto maximo por operacion, que no es el maximo diario
 */
@ConfigurationProperties(prefix = "atm.retiro")
public record ReglasRetiroProperties(
        BigDecimal multiplo,
        BigDecimal minimo,
        BigDecimal topeTransaccion) {

    /**
     * Valida al arrancar, no en la primera peticion.
     *
     * <p>Las dos ultimas comprobaciones parecen paranoia y no lo son: verifican que la
     * configuracion sea <b>satisfacible</b>. Con {@code multiplo: 1000} y {@code minimo: 1500} no
     * existe ningun monto que pase las dos primeras reglas, asi que el cajero rechazaria
     * absolutamente todo retiro con un 422 perfectamente formado y nadie sabria por que. Un fallo
     * que responde correctamente a cada peticion es mucho mas caro de diagnosticar que uno que
     * impide arrancar.
     */
    public ReglasRetiroProperties {
        exigirPositivo(multiplo, "atm.retiro.multiplo");
        exigirPositivo(minimo, "atm.retiro.minimo");
        exigirPositivo(topeTransaccion, "atm.retiro.tope-transaccion");

        if (minimo.remainder(multiplo).signum() != 0) {
            throw new IllegalStateException(
                    "atm.retiro.minimo (" + minimo + ") debe ser multiplo de atm.retiro.multiplo ("
                            + multiplo + "). Si no lo es, ningun monto puede pasar las dos primeras "
                            + "validaciones y el cajero rechaza todo retiro sin que se vea la causa.");
        }
        if (topeTransaccion.compareTo(minimo) < 0) {
            throw new IllegalStateException(
                    "atm.retiro.tope-transaccion (" + topeTransaccion + ") es menor que "
                            + "atm.retiro.minimo (" + minimo + "): no queda ningun monto valido.");
        }
    }

    private static void exigirPositivo(BigDecimal valor, String propiedad) {
        if (valor == null || valor.signum() <= 0) {
            throw new IllegalStateException(
                    "La propiedad " + propiedad + " debe estar declarada y ser mayor que cero. "
                            + "Ningun parametro del cajero va como constante en el codigo "
                            + "(seccion 7.3 del contrato): cambiar el tope de una maquina debe ser "
                            + "editar una linea y reiniciar, no recompilar.");
        }
    }
}
