package cl.duoc.bancoxyz.bff.atm.seguridad;

import java.util.List;
import java.util.Locale;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.jwt.JwtValidationException;

import cl.duoc.bancoxyz.comun.error.MotivosError;

/**
 * Traduce el fallo que reporta el validador de tokens al literal de {@code motivo} del contrato.
 *
 * <h2>Por que hace falta traducir, si el validador ya sabe que paso</h2>
 *
 * <p>Spring Security valida el token dentro de un filtro y, cuando algo falla, colapsa todos los
 * casos en un unico tipo de excepcion pensado para no revelar informacion hacia afuera. Eso esta
 * bien para el cliente y es incomodo para nosotros: el contrato congela motivos distintos de 401
 * ({@code token_ausente}, {@code token_expirado}, {@code firma_invalida}, {@code audiencia_invalida} y,
 * propio de este canal, {@code terminal_no_registrado}) y los guiones de evidencia leen ese campo. Esta clase
 * es el unico sitio donde se decide cual se escribe.
 *
 * <h2>El orden de las comprobaciones esta congelado: firma, vigencia, audiencia</h2>
 *
 * <p>Importa porque un mismo token puede fallar dos validaciones a la vez, y el guion de evidencia
 * lee el {@code motivo} y no solo el codigo. La consecuencia mas visible es la matriz 3x3 de los
 * tres tokens contra los tres canales: <b>desde F5 las seis celdas fuera de la diagonal son
 * {@code audiencia_invalida}</b>. Los tres canales validan contra la misma clave de firma, la del
 * {@code auth-server}, asi que el token del vecino pasa la firma y la vigencia y lo detiene la unica
 * barrera que queda entre canales: el claim {@code aud}. (Antes de F5, con una clave por canal, esas
 * celdas eran {@code firma_invalida}.)
 *
 * <p>{@code terminal_no_registrado} es la regla propia de este canal: el token no trae el claim
 * {@code terminal}, o trae uno que no figura en {@code atm.acceso.terminales-autorizados}. Se comprueba
 * DESPUES de la audiencia (un token de otro canal es, ante todo, de otro canal) y antes del valor por
 * defecto.
 *
 * <h2>Por que se mira el texto del error y no un codigo</h2>
 *
 * <p>Es la parte fea de esta clase y conviene decirlo en vez de disimularlo. Los validadores de
 * Spring Security entregan todos el mismo codigo de error ({@code invalid_token}) y solo se
 * distinguen por su descripcion en ingles. No hay un enumerado que consultar. La alternativa seria
 * sustituir el decodificador entero por uno propio para poder distinguir los casos, y eso es
 * exactamente lo que este proyecto no quiere hacer: reimplementar la validacion de tokens.
 *
 * <p>Dos cosas acotan el riesgo. La primera es que esa descripcion <b>no sale nunca hacia el
 * cliente</b>: se convierte en uno de los literales del contrato y nada mas. La segunda es
 * que el valor por defecto cuando ninguna pista coincide es {@code firma_invalida}, que es el caso
 * mas restrictivo y el correcto ante un token que no se pudo decodificar por cualquier otro motivo.
 */
final class MotivoDelFalloDeToken {

    /**
     * @param fallo excepcion que recibio el punto de entrada de autenticacion
     * @return uno de los literales de 401 de la seccion 7.1 del contrato
     */
    static String clasificar(AuthenticationException fallo) {
        /*
         * Sin cabecera Authorization (o con una que no usa el esquema Bearer) el filtro del resource
         * server ni siquiera intenta decodificar nada: la peticion sigue como anonima y muere mas
         * adelante, al comprobar la autorizacion. Por eso la ausencia de token no llega aqui como un
         * error de token, sino como "no habia autenticacion", y es el caso por defecto.
         */
        if (!(fallo instanceof OAuth2AuthenticationException falloDeToken)) {
            return MotivosError.TOKEN_AUSENTE;
        }

        List<String> pistas = descripcionesDe(falloDeToken);

        // Primero vigencia: un token expirado que ademas trae otra audiencia se reporta como
        // expirado, porque el orden congelado es firma, vigencia y despues audiencia.
        if (pistas.stream().anyMatch(p -> p.contains("expired") || p.contains("used before"))) {
            return MotivosError.TOKEN_EXPIRADO;
        }
        if (pistas.stream().anyMatch(p -> p.contains("aud"))) {
            return MotivosError.AUDIENCIA_INVALIDA;
        }
        // La regla del cajero (SeguridadAtmConfig#validadorDelCajero): el token no trae un terminal registrado.
        if (pistas.stream().anyMatch(p -> p.contains("terminal"))) {
            return MotivosError.TERMINAL_NO_REGISTRADO;
        }
        return MotivosError.FIRMA_INVALIDA;
    }

    /**
     * Recoge, en minusculas, los textos de error disponibles.
     *
     * <p>Un token puede violar varias reglas a la vez y el validador las acumula todas, asi que hay
     * que mirar la lista completa y no solo la primera: si solo se mirara una, el motivo dependeria
     * del orden en que Spring encadeno sus validadores, que es justo lo que el contrato no quiere
     * dejar al azar.
     */
    private static List<String> descripcionesDe(OAuth2AuthenticationException fallo) {
        if (fallo.getCause() instanceof JwtValidationException validacion) {
            return validacion.getErrors().stream()
                    .map(OAuth2Error::getDescription)
                    .filter(descripcion -> descripcion != null)
                    .map(descripcion -> descripcion.toLowerCase(Locale.ROOT))
                    .toList();
        }

        String mensaje = fallo.getMessage();
        return mensaje == null ? List.of() : List.of(mensaje.toLowerCase(Locale.ROOT));
    }

    private MotivoDelFalloDeToken() {
    }
}
