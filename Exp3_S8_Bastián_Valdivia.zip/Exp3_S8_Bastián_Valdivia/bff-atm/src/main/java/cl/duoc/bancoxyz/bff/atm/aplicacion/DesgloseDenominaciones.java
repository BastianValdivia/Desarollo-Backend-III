package cl.duoc.bancoxyz.bff.atm.aplicacion;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import cl.duoc.bancoxyz.bff.atm.api.dto.DenominacionEntregadaAtm;

/**
 * Reparte un monto en billetes, del mas grande al mas pequeno.
 *
 * <h2>Por que esto vive en el cajero y el core no sabe que existe</h2>
 *
 * <p>El core mueve saldos: para el, un retiro de 3.000 es una resta. Los billetes son un concepto de
 * <b>presentacion de este canal</b>, porque solo esta maquina tiene una gaveta con papel dentro. La
 * seccion 11, decision 2 del contrato lo congela asi: {@code desglose} pertenece a la respuesta del
 * cajero y no a la del core. Meterlo en el backend de dominio contaminaria con una idea de cajero a
 * los otros dos canales, que no entregan nada fisico.
 *
 * <h2>Por que el algoritmo codicioso es correcto AQUI y no en general</h2>
 *
 * <p>Tomar siempre el billete mas grande que quepa se llama algoritmo codicioso, y con un juego de
 * monedas cualquiera <b>no</b> garantiza la mejor solucion: con billetes de 1, 3 y 4, para pagar 6
 * el codicioso entrega 4+1+1 (tres billetes) cuando 3+3 (dos) es mejor. Funciona aqui por una
 * propiedad concreta del juego configurado: cada denominacion es multiplo de todas las menores
 * (1.000, 2.000, 5.000, 10.000 sobre una base de 1.000), y en esa familia el codicioso si es
 * optimo. Conviene saberlo porque el dia que alguien agregue un billete de 3.000 al YAML, esta
 * frase deja de ser cierta y el desglose empezara a entregar mas billetes de los necesarios sin
 * fallar nunca.
 *
 * <h2>Por que el resto siempre es cero</h2>
 *
 * <p>El monto ya paso la validacion de multiplo de 1.000 y la lista de billetes incluye el de
 * 1.000, asi que el bucle siempre termina en cero. No se lanza excepcion si no fuera asi: cuando
 * este metodo se ejecuta, <b>el core ya movio el dinero</b>, y fallar despues de eso convertiria un
 * retiro correcto en un 500 sin devolver el saldo. El desglose es informacion para la pantalla, no
 * una segunda validacion.
 */
public final class DesgloseDenominaciones {

    /**
     * @param monto          cantidad ya retirada, multiplo de la denominacion menor
     * @param denominaciones billetes disponibles, en orden ascendente (lo garantiza AtmProperties)
     * @return una entrada por cada billete que se entrega al menos una vez, de mayor a menor
     */
    public static List<DenominacionEntregadaAtm> repartir(BigDecimal monto, List<Integer> denominaciones) {
        List<DenominacionEntregadaAtm> desglose = new ArrayList<>();
        long restante = monto.longValueExact();

        // Se recorre al reves porque la lista viene ascendente y aqui hace falta de mayor a menor.
        for (int i = denominaciones.size() - 1; i >= 0 && restante > 0; i--) {
            long billete = denominaciones.get(i);
            long cantidad = restante / billete;
            if (cantidad > 0) {
                desglose.add(new DenominacionEntregadaAtm(billete, cantidad));
                restante -= cantidad * billete;
            }
        }

        return List.copyOf(desglose);
    }

    private DesgloseDenominaciones() {
    }
}
