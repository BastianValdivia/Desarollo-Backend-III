package cl.duoc.bancoxyz.bff.atm.aplicacion;

import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.bff.atm.api.dto.SaldoDisponibleAtmResponse;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;

/**
 * Capa de aplicacion del endpoint A2: pide el saldo al core y lo <b>traduce</b> a la forma exacta
 * que necesita una pantalla de cajero.
 *
 * <h2>Que hace exactamente un BFF, visto en doce lineas de codigo</h2>
 *
 * <p>Esta clase es el patron entero en miniatura. Hay un servicio aguas arriba, el
 * {@code core-service}, que habla en terminos generales de "una cuenta" porque sirve a tres clientes
 * distintos. Y hay un cliente muy concreto, una maquina en la calle, que solo necesita dos datos.
 * El BFF es la pieza que traduce de lo general a lo especifico, y ese recorte es literalmente el
 * valor que aporta: sin el, o el core crece una variante por canal, o el cajero recibe y descarta
 * datos que nadie va a mirar.
 *
 * <h2>Por que se llama a {@code obtenerSaldo} y no a {@code obtenerCuenta}</h2>
 *
 * <p>Esta es la decision mas importante del archivo, y la que separa una optimizacion real de una
 * cosmetica.
 *
 * <ul>
 *   <li>{@code obtenerCuenta(116)} devuelve la cuenta canonica completa: titular, tipo, edad,
 *       moneda, saldo y <b>los 42 movimientos</b>. Son varios kilobytes.</li>
 *   <li>{@code obtenerSaldo(116)} devuelve tres campos.</li>
 * </ul>
 *
 * <p>Si aqui se llamara al primero y despues se descartaran los campos sobrantes, la respuesta al
 * cajero pesaria exactamente lo mismo, pero el costo ya estaria pagado: el core habria serializado
 * los 42 movimientos, habrian viajado por la red hasta el BFF y este los habria deserializado para
 * tirarlos a la basura. <b>Recortar despues de recibir no es optimizar.</b> La optimizacion real es
 * no pedirlo, y por eso el contrato aguas arriba ofrece el endpoint estrecho C3.
 *
 * <h2>Por que este servicio NO cachea el saldo</h2>
 *
 * <p>La ausencia de una anotacion de cache aqui es deliberada y hay que saber defenderla: un saldo
 * de hace sesenta segundos, en un cajero, significa entregar dinero que ya no existe. Con un TTL de
 * un minuto se podrian hacer dos retiros del saldo total dentro de ese minuto. Es una decision de
 * <b>correctitud</b>, no de rendimiento, y es la razon por la cual la anotacion de cache no puede
 * vivir en el cliente compartido del core: el mismo metodo lo consume el canal movil, que si puede
 * cachear, y una clase compartida no puede tener dos comportamientos.
 *
 * <h2>Por que la traduccion vive aqui y no en el controlador</h2>
 *
 * <p>El controlador se ocupa del protocolo: recibe una peticion HTTP y devuelve una respuesta HTTP.
 * En cuanto le agregamos la traduccion, empieza a mezclar dos responsabilidades y deja de poder
 * probarse sin levantar un servidor. Con la traduccion aqui, este metodo se prueba llamandolo con un
 * {@link CoreClient} de mentira, sin red y sin Spring.
 */
@Service
public class ConsultaSaldoAtmService {

    private final CoreClient core;
    private final GuardiaTitularidad guardia;

    /**
     * Recibe el {@link CoreClient} y el guardia de titularidad por constructor.
     *
     * <p><b>Que es esto para quien recien empieza.</b> {@code CoreClient} es una <i>interfaz</i>: un
     * contrato que dice que se le puede pedir al core, sin decir como se le pide. La implementacion
     * real, {@code RestCoreClient}, vive en la libreria compartida y es la unica clase del sistema
     * que sabe que el core se alcanza por HTTP. Este servicio depende del contrato, no de la
     * implementacion, y por eso se puede probar sin red.
     *
     * <p>La inyeccion es por constructor y no por campo con {@code @Autowired} porque asi el objeto
     * no puede existir a medio construir: si falta la dependencia, falla el arranque, no la primera
     * peticion. Ademas el campo puede ser {@code final}, que es la forma de decir en Java "esto no
     * cambia despues de construido".
     */
    public ConsultaSaldoAtmService(CoreClient core, GuardiaTitularidad guardia) {
        this.core = core;
        this.guardia = guardia;
    }

    /**
     * Consulta el saldo de una cuenta y devuelve los dos unicos campos que el cajero expone.
     *
     * <p><b>La primera linea es la comprobacion de titularidad, y su posicion es parte de la
     * regla.</b> La autoridad {@code PERM_saldo:leer} que ya verifico la cadena de filtros dice que
     * esta tarjeta puede consultar saldos; no dice que pueda consultar <b>este</b> saldo. Sin la
     * comparacion entre el claim {@code cuentaId} del token y la variable de ruta, cualquiera con
     * una tarjeta valida leeria el saldo de las otras 49 cuentas cambiando un numero en la URL.
     *
     * <p>Va <b>antes</b> de llamar al core, y eso tiene dos consecuencias exigibles: una cuenta
     * ajena e inexistente responde 403 {@code cuenta_ajena} y no 404 (de lo contrario, comparar las
     * dos respuestas convertiria el canal en un detector de cuentas existentes), y la peticion
     * rechazada no cuesta ni una llamada al core.
     *
     * <p>Tampoco hay aqui ningun {@code try/catch}. Es deliberado: si el core no responde o la
     * cuenta no existe, el {@link CoreClient} lanza una excepcion con nombre, esa excepcion sube
     * hasta el manejador de errores del canal y alli se convierte en el cuerpo RFC 7807 que
     * corresponda. Atraparla aqui solo serviria para volver a lanzarla.
     *
     * @param cuentaId identificador de la cuenta, tal como vino en la ruta
     * @param token    token ya validado por la cadena de filtros, portador del claim cuentaId
     * @return los dos campos congelados de A2
     */
    public SaldoDisponibleAtmResponse consultarSaldoDisponible(int cuentaId, Jwt token) {
        guardia.exigirTitularidad(token, cuentaId);

        SaldoCoreDto saldoDelCore = core.obtenerSaldo(cuentaId);

        if (saldoDelCore == null) {
            // Solo puede ocurrir si el core responde 200 con cuerpo vacio, es decir si el contrato
            // aguas arriba se rompio. Se falla con un mensaje que nombra la causa; sin esta linea,
            // el sintoma seria un NullPointerException en la linea siguiente, que no dice nada.
            throw new IllegalStateException(
                    "El core respondio sin cuerpo al consultar el saldo de la cuenta " + cuentaId);
        }

        // AQUI OCURRE EL RECORTE, y conviene verlo escrito:
        //   entra  {cuentaId, saldo, moneda}   <- contrato del core, seccion 5.5
        //   sale   {saldoDisponible, moneda}   <- contrato del cajero, seccion 5.5
        // Se cae cuentaId, porque el cliente lo puso el mismo en la URL, y el saldo cambia de
        // nombre. Dos contratos distintos, y esta linea es la frontera entre ambos.
        return new SaldoDisponibleAtmResponse(saldoDelCore.saldo(), saldoDelCore.moneda());
    }
}
