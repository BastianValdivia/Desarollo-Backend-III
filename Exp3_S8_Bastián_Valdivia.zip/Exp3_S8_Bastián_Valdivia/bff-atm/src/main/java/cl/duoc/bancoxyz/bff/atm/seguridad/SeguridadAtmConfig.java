package cl.duoc.bancoxyz.bff.atm.seguridad;

import java.time.Duration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2ErrorCodes;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtTimestampValidator;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;

import cl.duoc.bancoxyz.bff.atm.config.AccesoAtmProperties;
import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.oauth2.FiltroAutenticacionNoDisponible;
import cl.duoc.bancoxyz.comun.token.ClaimsToken;

/**
 * La cadena de filtros del canal cajero: quien puede entrar y a que.
 *
 * <h2>Que es una "cadena de filtros", para quien recien pregunto que es un puerto</h2>
 *
 * <p>Antes de que una peticion llegue a un controlador, atraviesa una fila de filtros, cada uno con
 * una tarea. En este canal los que importan son tres: uno lee la cabecera {@code Authorization} y
 * valida el token, otro compara el resultado con las reglas de abajo, y un tercero convierte un
 * rechazo en una respuesta HTTP. Un controlador de este modulo solo se ejecuta si la peticion
 * atraveso la fila entera. Esa es la propiedad que hace que la seguridad no dependa de que alguien
 * se acuerde de comprobarla dentro de cada metodo.
 *
 * <h2>Mecanismo compartido, politica propia</h2>
 *
 * <p>Los tres BFF usan el mismo mecanismo: HTTPS con certificado propio, JWT firmado en RS256 por el
 * servidor de autorizacion, validacion delegada en el resource server (firma por JWKS, emisor y
 * audiencia), sesion sin estado y las mismas cabeceras de seguridad. Ningun BFF emite ni firma tokens:
 * desde F5 el cajero se autentica en el {@code auth-server} con el grant de extension
 * {@code tarjeta-pin} (tarjeta, PIN y terminal registrado, token de 3 minutos), y este canal solo lo
 * valida. Lo que <b>no</b> se comparte es la politica, y esta clase es donde la de este canal se
 * escribe: el token debe venir de un terminal registrado ({@link #validadorDelCajero}) y cada ruta exige
 * la autoridad que le corresponde. Uniformidad en el mecanismo y especificidad en la politica no se
 * contradicen: son dos capas distintas.
 *
 * <h2>Las reglas, y por que el orden es parte de la regla</h2>
 *
 * <p>Se evaluan de arriba abajo y gana la primera que coincide, asi que lo especifico va antes que
 * lo general y {@code anyRequest()} va siempre al final. Con {@code anyRequest().authenticated()}
 * arriba, las lineas de abajo no se leerian jamas y una ruta que deberia exigir un permiso concreto
 * se contentaria con cualquier token valido, sin que nada fallara ni avisara.
 *
 * <p>La unica ruta abierta es la salud, porque el guion de arranque necesita esperar a que el servicio
 * responda antes de tener ninguna credencial (el login ya no esta aqui: el token se pide al
 * {@code auth-server}, ver {@code scripts/login-cajero.sh}). Esta regla de la salud solo se ejerce cuando Actuator
 * comparte el puerto del canal (el perfil de prueba); desde F1, en el despliegue, Actuator vive en
 * un puerto de gestion aparte cuya cadena {@code SeguridadPuertoGestionConfig} deja pasar sin
 * token. {@code /actuator/metrics} sigue cubierto por {@code anyRequest().authenticated()}: en el
 * puerto del canal responde 401 sin token (y 404 con token, porque ahi no esta publicado), y las
 * metricas se leen en el puerto de gestion.
 */
@Configuration
public class SeguridadAtmConfig {

    /** Tolerancia de reloj del canal: 5 segundos, para un token que dura 3 minutos. */
    private static final Duration TOLERANCIA_DE_RELOJ = Duration.ofSeconds(5);

    /**
     * Literales de autoridad de este canal, copiados a la letra de la seccion 6.1 del contrato.
     *
     * <p>Se declaran como constantes por una razon muy concreta: la misma cadena aparece en el
     * {@code config-repo/auth-server.yml} (dentro de las autoridades de cada tarjeta) y en las reglas de abajo.
     * Si las dos copias divergieran en un caracter, el resultado seria un 403 en una ruta cuyo
     * token, leido a ojo, parece llevar el permiso correcto. Con constantes, al menos una de las dos
     * mitades deja de compilar; y una prueba automatica comprueba que las del YAML coinciden.
     */
    public static final String PERM_SALDO_LEER = "PERM_saldo:leer";

    public static final String PERM_RETIRO_EJECUTAR = "PERM_retiro:ejecutar";

    @Bean
    SecurityFilterChain cadenaDeFiltros(HttpSecurity http,
                                        PuntoEntradaAtm puntoEntrada,
                                        ManejadorAccesoDenegadoAtm accesoDenegado,
                                        EscritorErrorHttp escritor) throws Exception {
        http
                /*
                 * CSRF DESACTIVADO, Y AQUI ESTA LA JUSTIFICACION, QUE ES LO QUE LO SEPARA DE UN
                 * DESCUIDO.
                 *
                 * El ataque que CSRF previene consiste en que una pagina cualquiera provoque una
                 * peticion al banco desde el navegador de la victima, aprovechando que el navegador
                 * adjunta AUTOMATICAMENTE las cookies del banco. La credencial viaja sola, sin que
                 * el atacante necesite leerla.
                 *
                 * Aqui no hay cookie ni sesion: la credencial viaja en la cabecera Authorization, y
                 * esa cabecera no la pone nadie por su cuenta, hay que escribirla en cada peticion.
                 * Sin adjuntado automatico no existe el vector. Y el cliente de este canal ni
                 * siquiera es un navegador: es el firmware de una maquina.
                 *
                 * Dejarlo activo, en cambio, tendria un costo real: el filtro exigiria un token CSRF
                 * en cada POST, el terminal no lo mandaria y el retiro devolveria 403 sin que el
                 * cuerpo explicara por que.
                 */
                .csrf(AbstractHttpConfigurer::disable)

                /*
                 * SESION SIN ESTADO. El servidor no guarda nada entre peticiones: cada una trae su
                 * propia prueba de identidad o no es nadie. Tres consecuencias:
                 *
                 * 1. Un cajero no puede dejar "la sesion abierta" de la persona anterior.
                 * 2. La matriz de cruce de tokens es limpia: una peticion que debia fallar no puede
                 *    pasar por una sesion residual que quedo de la peticion anterior.
                 * 3. El canal escala sin estado compartido, que es la razon por la que este estilo
                 *    se impuso en las APIs.
                 */
                .sessionManagement(sesion -> sesion.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                .authorizeHttpRequests(reglas -> reglas
                        // A5: la salud se consulta sin credencial (el guion de arranque espera
                        // al servicio antes de tener token). Esta regla solo se ejerce si Actuator comparte
                        // el puerto del canal (pruebas); en el despliegue la salud esta en el
                        // puerto de gestion (F1) y esta ruta, en el del canal, responde 404.
                        .requestMatchers(HttpMethod.GET, "/actuator/health").permitAll()

                        /*
                         * A3, la operacion critica. Nivel 2 de autorizacion del contrato: el
                         * permiso de OPERACION. La tarjeta de solo consulta llega hasta aqui con un
                         * token perfectamente valido y se va con un 403, que es la unica forma de
                         * producir ese codigo en este canal (un token de otro canal falla antes, por
                         * firma, y devuelve 401).
                         *
                         * El asterisco cubre un solo segmento de la ruta, que es justo el {id}. No
                         * es una comprobacion de que la cuenta sea tuya: eso no puede hacerse aqui y
                         * lo hace GuardiaTitularidad.
                         */
                        .requestMatchers(HttpMethod.POST, "/v1/cuentas/*/retiros")
                        .hasAuthority(PERM_RETIRO_EJECUTAR)

                        // A2 y A4: consulta. La misma autoridad para las dos, porque las dos
                        // responden a "mostrame cifras", no a "mueve dinero".
                        .requestMatchers(HttpMethod.GET, "/v1/cuentas/*/saldo-disponible")
                        .hasAuthority(PERM_SALDO_LEER)
                        .requestMatchers(HttpMethod.GET, "/v1/denominaciones")
                        .hasAuthority(PERM_SALDO_LEER)

                        /*
                         * Red de seguridad: todo lo demas exige al menos un token valido. Va al
                         * final y cubre A6 (/actuator/metrics) y cualquier ruta futura. Que el caso
                         * por defecto sea "cerrado" es la diferencia entre olvidarse de proteger algo
                         * nuevo y olvidarse de abrirlo: el segundo olvido se nota de inmediato, el
                         * primero no se nota nunca.
                         */
                        .anyRequest().authenticated())

                /*
                 * VALIDACION DEL TOKEN. Esta linea activa el filtro que lee "Authorization: Bearer
                 * ..." y verifica firma, algoritmo, exp, nbf y audiencia. El COMO esta enteramente
                 * en config-repo/bff-atm.yml: public-key-location, audiences, authorities-claim-name y
                 * authority-prefix. Cero Java de validacion, que es la decision correcta y no un
                 * atajo (ver el comentario de las dependencias en el pom).
                 *
                 * Los dos manejadores se declaran DOS VECES a proposito, aqui y en
                 * exceptionHandling. No es redundancia: el resource server instala sus propios
                 * manejadores dentro de su configurador, y si solo se pusieran en exceptionHandling,
                 * un token invalido (no ausente) se responderia con el formato por defecto de Spring
                 * en lugar del RFC 7807 del contrato. Se descubre tarde, porque el caso "sin token"
                 * si saldria bien.
                 */
                .oauth2ResourceServer(recurso -> recurso
                        .authenticationEntryPoint(puntoEntrada)
                        .accessDeniedHandler(accesoDenegado)
                        .jwt(Customizer.withDefaults()))

                .exceptionHandling(manejo -> manejo
                        .authenticationEntryPoint(puntoEntrada)
                        .accessDeniedHandler(accesoDenegado))

                /*
                 * Si el auth-server no entrega sus claves, el token no se puede ni verificar: 503 en el
                 * formato del canal, no un 401 ni un 500 (ver FiltroAutenticacionNoDisponible). Va antes del
                 * filtro de tokens, que es donde nace la excepcion que atrapa.
                 */
                .addFilterBefore(new FiltroAutenticacionNoDisponible(escritor, "ATM"),
                        BearerTokenAuthenticationFilter.class);

        /*
         * No se tocan las cabeceras de seguridad: Spring Security ya emite por defecto
         * X-Content-Type-Options: nosniff, X-Frame-Options: DENY, Cache-Control: no-store y, sobre
         * una conexion segura, HSTS. Escribirlas a mano solo abriria la posibilidad de escribirlas
         * peor.
         *
         * Tampoco se configura CORS: no hay ninguno. CORS es el permiso que un navegador pide para
         * que una pagina de otro origen hable con esta API, y el cliente de este canal es el
         * firmware de un cajero, que no es un navegador y no tiene origen. Una lista de origenes
         * permitidos aqui seria decorativa.
         */
        return http.build();
    }

    /**
     * La regla del cajero y la tolerancia de reloj de este canal, como validador ADICIONAL del token.
     *
     * <p>Spring Boot construye el decodificador del resource server con {@code jwk-set-uri},
     * {@code issuer-uri} y {@code audiences} (firma, emisor, vigencia y audiencia) y agrega al final todo
     * {@code OAuth2TokenValidator<Jwt>} que exista como bean. Este agrega dos cosas:
     *
     * <ol>
     *   <li><b>Que el token venga de un terminal registrado.</b> El claim {@code terminal} (lo escribe el
     *       auth-server) debe estar y figurar en {@code atm.acceso.terminales-autorizados}. Si no, el token se
     *       rechaza como un 401 {@code terminal_no_registrado} (pantalla E-012), aunque su firma y su audiencia
     *       sean perfectas.</li>
     *   <li><b>5 segundos de tolerancia de reloj</b> en lugar de los 60 por defecto. El token del cajero dura
     *       3 minutos; con 60 s de gracia viviria un tercio mas. Es la misma tolerancia que tenia este canal en
     *       el S5, cuando validaba con un decodificador propio.</li>
     * </ol>
     *
     * <p>La descripcion del error de terminal contiene la palabra {@code terminal}: es la pista que
     * {@code MotivoDelFalloDeToken} traduce al motivo del contrato (la descripcion nunca sale hacia el cliente).
     */
    @Bean
    OAuth2TokenValidator<Jwt> validadorDelCajero(AccesoAtmProperties acceso) {
        OAuth2TokenValidator<Jwt> terminalRegistrado = jwt -> {
            String terminal = jwt.getClaimAsString(ClaimsToken.TERMINAL);
            if (acceso.terminalAutorizado(terminal)) {
                return OAuth2TokenValidatorResult.success();
            }
            return OAuth2TokenValidatorResult.failure(new OAuth2Error(OAuth2ErrorCodes.INVALID_TOKEN,
                    "El token no proviene de un terminal registrado", null));
        };
        return new DelegatingOAuth2TokenValidator<>(new JwtTimestampValidator(TOLERANCIA_DE_RELOJ), terminalRegistrado);
    }
}
