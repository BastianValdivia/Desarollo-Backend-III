package cl.duoc.bancoxyz.bff.atm.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import cl.duoc.bancoxyz.comun.error.RespuestaError;

/**
 * Cuerpo de error del canal cajero, en formato RFC 7807
 * ({@code application/problem+json}), segun la seccion 5.16 del contrato.
 *
 * <h2>Que comparte con los otros canales y que no</h2>
 *
 * <p>El envoltorio es el mismo en los tres canales, y eso es calidad: un cliente que ya sabe leer un
 * error de web sabe leer uno del cajero. El contenido cambia por canal, y eso es adaptacion. Este
 * record es exactamente esa idea puesta en codigo:
 *
 * <ul>
 *   <li><b>Seis campos comunes:</b> {@code type}, {@code title}, {@code status}, {@code instance},
 *       {@code canal} y {@code motivo}.</li>
 *   <li><b>Dos campos que solo existen aqui:</b> {@code codigoPantalla} y
 *       {@code mensajePantalla}.</li>
 *   <li><b>Un campo que el cajero deliberadamente NO tiene:</b> {@code detail}.</li>
 * </ul>
 *
 * <h2>Por que falta {@code detail}, que si llevan web y movil</h2>
 *
 * <p>Porque un cajero es una maquina desatendida en la via publica y cualquiera puede leer su
 * pantalla o su trafico. Un {@code detail} del tipo "El token no acredita titularidad sobre la
 * cuenta 105" le confirma a quien sondea la maquina que esa cuenta existe. Aqui el campo no se
 * envia vacio ni nulo: <b>no esta declarado</b>. Un campo que no existe no se puede filtrar por
 * descuido en una rama de codigo que alguien agregue el mes que viene, y ese es el mismo principio
 * que gobierna el canal entero: lo que no existe no se puede atacar.
 *
 * <h2>Por que este record se declara aqui en vez de reutilizar {@link RespuestaError}</h2>
 *
 * <p>Un record de Java no se puede heredar ni extender, asi que "el envoltorio comun mas dos campos"
 * no se expresa con herencia. Se podria haber metido los dos campos del cajero en la clase
 * compartida, pero entonces web y movil cargarian con dos campos que no significan nada para ellos y
 * el envoltorio comun se habria convertido en el envoltorio del cajero. Se prefiere repetir seis
 * nombres de campo una vez: es la duplicacion intencional que el patron BFF acepta a cambio de que
 * ningun canal imponga su forma a los demas.
 *
 * <p>Lo que si se reutiliza de la libreria es el <b>mecanismo</b>: {@link RespuestaError#uriDeMotivo}
 * deriva el campo {@code type} a partir del motivo, de modo que los tres canales publican
 * exactamente el mismo catalogo de URI y es imposible que {@code type} y {@code motivo} se
 * contradigan.
 *
 * @param type            URI del catalogo de errores, derivada del motivo
 * @param title           titulo corto y estable
 * @param status          codigo HTTP, que debe coincidir con el de la respuesta real
 * @param instance        ruta pedida, con el {@code context-path} {@code /api/atm} incluido
 * @param canal           literal {@code ATM}
 * @param motivo          valor congelado de la seccion 7.1. Es el campo que leen los guiones de
 *                        evidencia
 * @param codigoPantalla  codigo corto para la pantalla, formato {@code E-NNN}
 * @param mensajePantalla texto breve para esa misma pantalla, sin tildes
 */
public record RespuestaErrorAtm(
        String type,
        String title,
        int status,
        String instance,
        String canal,
        String motivo,

        /*
         * NON_NULL solo en estos dos campos, y no en el record completo.
         *
         * Motivo: el contrato congela catorce motivos con codigo de pantalla, y ninguno cubre
         * recurso_no_encontrado. Cuando no hay fila congelada, estos dos campos valen null y
         * desaparecen del JSON, en vez de viajar como "codigoPantalla": null, que le diria al
         * firmware que el campo existe y esta vacio. Los seis campos comunes no llevan la
         * anotacion porque nunca son nulos: si alguno lo fuera, se quiere ver el null en la
         * respuesta y corregirlo, no que se esfume en silencio.
         */
        @JsonInclude(JsonInclude.Include.NON_NULL) String codigoPantalla,
        @JsonInclude(JsonInclude.Include.NON_NULL) String mensajePantalla) {

    /** Valor del campo {@code canal} para este BFF. Congelado en la seccion 5.16 del contrato. */
    public static final String CANAL = "ATM";

    /**
     * Unica forma de construir un error de este canal.
     *
     * <p><b>Por que una fabrica y no el constructor normal.</b> Porque tres de los ocho campos se
     * <em>derivan</em> del motivo: {@code type} por la regla de guiones del contrato, y el par de
     * pantalla por la tabla de la seccion 7.2. Derivarlos aqui, en un solo lugar, hace estructural
     * lo que de otro modo seria disciplina: es imposible construir una respuesta cuyo {@code type}
     * no corresponda a su {@code motivo}, o que muestre {@code E-042} junto a un motivo que no es
     * saldo insuficiente.
     *
     * @param estado    codigo HTTP que ademas viaja en el cuerpo
     * @param motivo    constante de {@code MotivosError}
     * @param titulo    titulo corto y estable
     * @param instancia ruta pedida, con context-path
     */
    public static RespuestaErrorAtm de(int estado, String motivo, String titulo, String instancia) {
        PantallaCajero.Pantalla pantalla = PantallaCajero.paraMotivo(motivo);

        return new RespuestaErrorAtm(
                RespuestaError.uriDeMotivo(motivo),
                titulo,
                estado,
                instancia,
                CANAL,
                motivo,
                pantalla == null ? null : pantalla.codigo(),
                pantalla == null ? null : pantalla.mensaje());
    }
}
