package cl.duoc.bancoxyz.bff.atm.aplicacion;

import java.math.BigDecimal;

import org.springframework.http.HttpStatus;

import cl.duoc.bancoxyz.comun.error.MotivosError;

/**
 * La unica excepcion que este canal lanza por una regla propia, con el estado HTTP y el
 * {@code motivo} congelado que le corresponden.
 *
 * <h2>Por que una sola clase con fabricas y no cuatro clases hermanas</h2>
 *
 * <p>Cada uno de los cuatro casos necesita exactamente dos datos: un codigo HTTP y un literal de
 * {@code motivo}. Con cuatro subclases, esa pareja quedaria repartida en cuatro archivos y nadie
 * podria comprobar de un vistazo que el 422 va con {@code monto_no_multiplo} y no con
 * {@code peticion_invalida}. Con una sola clase, los metodos estaticos de mas abajo <b>son</b> la
 * tabla de la seccion 7.1 del contrato escrita en Java, y revisarla contra el documento es leer
 * veinte lineas seguidas.
 *
 * <p>El coste de esta decision es que el manejador de errores no puede distinguir los casos con
 * {@code @ExceptionHandler} distintos. No lo necesita: precisamente porque la excepcion ya trae el
 * estado y el motivo, el manejador tiene un unico metodo que los copia a la respuesta. La
 * traduccion deja de ser una cadena de {@code if} y pasa a ser un dato.
 *
 * <h2>Por que el mensaje nunca sale hacia el cliente</h2>
 *
 * <p>Los mensajes de aqui son explicitos ("el token acredita la cuenta 116 y se pidio la 105")
 * porque van al log, que lo lee quien opera el sistema. La respuesta del canal cajero <b>no lleva
 * campo {@code detail}</b>, asi que ninguno de estos textos llega a la pantalla ni al que este de
 * pie frente a la maquina. Es la misma razon por la que el cajero responde 404 donde los otros
 * canales responden 405: lo que se cuenta hacia afuera en via publica es el minimo.
 */
public class ReglaAtmException extends RuntimeException {

    private final HttpStatus estado;
    private final String motivo;
    private final String titulo;

    private ReglaAtmException(HttpStatus estado, String motivo, String titulo, String mensajeParaElLog) {
        super(mensajeParaElLog);
        this.estado = estado;
        this.motivo = motivo;
        this.titulo = titulo;
    }

    // ----------------------------------------------------------------------------------------
    // 403: se quien eres y no puedes.
    // ----------------------------------------------------------------------------------------

    /**
     * El claim {@code cuentaId} del token no coincide con el {@code {id}} de la ruta.
     *
     * <p>Es 403 y no 404 aunque la cuenta pedida no exista, y esa eleccion esta congelada: si el
     * canal respondiera 404 para las cuentas inexistentes y 403 para las ajenas, la diferencia
     * entre las dos respuestas convertiria el endpoint en un <b>detector de cuentas existentes</b>
     * para cualquiera con un token valido. Por eso la titularidad se comprueba antes que la
     * existencia y la peticion muere aqui, sin llegar al core.
     */
    public static ReglaAtmException cuentaAjena(Integer cuentaDelToken, int cuentaPedida) {
        return new ReglaAtmException(HttpStatus.FORBIDDEN, MotivosError.CUENTA_AJENA,
                "Acceso denegado",
                "El token acredita la cuenta " + cuentaDelToken + " y se pidio la cuenta "
                        + cuentaPedida + ".");
    }

    // ----------------------------------------------------------------------------------------
    // 422: la peticion se entiende perfectamente y una regla de negocio del canal la rechaza.
    //
    // Los tres llevan motivo DISTINTO a proposito. Un unico "monto_invalido" seria mas corto de
    // escribir y dejaria al operador del cajero sin saber si debe teclear otra cifra, una mayor o
    // una menor, que es justo lo que la pantalla existe para decirle.
    // ----------------------------------------------------------------------------------------

    public static ReglaAtmException montoNoMultiplo(BigDecimal monto, BigDecimal multiplo) {
        return new ReglaAtmException(HttpStatus.UNPROCESSABLE_ENTITY, MotivosError.MONTO_NO_MULTIPLO,
                "Operacion rechazada",
                "El monto " + monto + " no es multiplo de " + multiplo + ".");
    }

    public static ReglaAtmException montoBajoMinimo(BigDecimal monto, BigDecimal minimo) {
        return new ReglaAtmException(HttpStatus.UNPROCESSABLE_ENTITY, MotivosError.MONTO_BAJO_MINIMO,
                "Operacion rechazada",
                "El monto " + monto + " esta bajo el minimo de " + minimo + ".");
    }

    public static ReglaAtmException superaTopeTransaccion(BigDecimal monto, BigDecimal tope) {
        return new ReglaAtmException(HttpStatus.UNPROCESSABLE_ENTITY,
                MotivosError.SUPERA_TOPE_TRANSACCION, "Operacion rechazada",
                "El monto " + monto + " supera el tope por transaccion de " + tope + ".");
    }

    public HttpStatus estado() {
        return estado;
    }

    public String motivo() {
        return motivo;
    }

    public String titulo() {
        return titulo;
    }
}
