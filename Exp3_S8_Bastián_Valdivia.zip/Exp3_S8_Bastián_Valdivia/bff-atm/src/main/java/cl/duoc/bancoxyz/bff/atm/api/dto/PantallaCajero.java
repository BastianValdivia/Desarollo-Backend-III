package cl.duoc.bancoxyz.bff.atm.api.dto;

import java.util.Map;

import cl.duoc.bancoxyz.comun.error.MotivosError;

/**
 * Tabla congelada que traduce un {@code motivo} de error al par
 * {@code codigoPantalla} + {@code mensajePantalla} que se muestra en la pantalla del cajero
 * (seccion 7.2 del contrato).
 *
 * <h2>Por que esta tabla vive en bff-atm y no en plataforma-comun</h2>
 *
 * <p>Porque es el ejemplo mas limpio de la frontera entre mecanismo y politica. El vocabulario de
 * motivos ({@code saldo_insuficiente}, {@code core_no_disponible}...) es compartido: esta en
 * {@link MotivosError}, dentro de la libreria, para que los tres canales escriban la misma cadena.
 * Pero que {@code core_no_disponible} se muestre como {@code E-090} con el texto
 * {@code Servicio no disponible} es una decision de este canal y de ningun otro: web y movil no
 * tienen pantalla de cajero ni codigos de dos letras y tres digitos. Dicho corto: el diccionario es
 * compartido, las frases del cajero son suyas.
 *
 * <h2>Por que los textos van sin tildes</h2>
 *
 * <p>Es la unica excepcion declarada a la regla de escribir el espanol con tildes correctas, y esta
 * anotada en el contrato para que no se lea como un descuido: estas cadenas viajan al firmware de
 * una maquina cuya pantalla no siempre soporta el juego de caracteres completo. Una tilde que el
 * firmware no sabe dibujar se convierte en un simbolo raro justo en el momento en que el usuario
 * necesita entender que paso.
 *
 * <h2>Como se leen los codigos</h2>
 *
 * <p>La familia dice de que habla la pantalla, y por eso no hay que memorizar numero por numero:
 * {@code E-01x} la tarjeta y su PIN, {@code E-02x} la sesion, {@code E-03x} los permisos,
 * {@code E-04x} el estado de la cuenta o de la operacion, {@code E-05x} el monto, {@code E-09x} el
 * servicio.
 *
 * <h2>Por que el 404 dice "Cuenta no disponible" y no "La cuenta no existe"</h2>
 *
 * <p>Es la misma decision que hace que este canal responda 404 donde los otros responden 405. Una
 * pantalla que distinga "no existe" de "existe y no es tuya" convierte al cajero en un detector de
 * cuentas existentes para cualquiera que pruebe numeros en via publica. El codigo HTTP y el
 * {@code motivo} si distinguen los dos casos (404 {@code recurso_no_encontrado} contra 403
 * {@code cuenta_ajena}), porque eso lo lee quien opera el sistema; el texto de la pantalla, que lo
 * lee cualquiera que pase por delante, no.
 *
 * <h2>Por que el 500 tiene fila propia y separada del 503</h2>
 *
 * <p>Para quien esta frente a la maquina, {@code E-090} y {@code E-091} significan lo mismo: hoy no
 * se puede operar. Para quien diagnostica significan cosas opuestas: {@code E-090} dice "el core no
 * responde, revisa el core" y {@code E-091} dice "el canal fallo por su cuenta, revisa el canal".
 * Un solo codigo para los dos casos manda al operador a mirar el servicio equivocado la mitad de
 * las veces, y esa es justamente la informacion que un codigo de pantalla existe para dar.
 *
 * <h2>Por que un motivo puede no estar en la tabla</h2>
 *
 * <p>No hay fila para {@code peticion_invalida} ni para {@code metodo_no_permitido} porque este
 * canal no los emite nunca: no expone parametros de consulta y responde 404 a los verbos que no
 * corresponden. Una fila para un motivo que el canal no puede producir seria una transcripcion que
 * nadie podria verificar contra una respuesta real. El metodo {@link #paraMotivo(String)} sigue
 * devolviendo {@code null} para cualquier motivo sin fila, que es la respuesta correcta ante un
 * caso que el contrato no cubre: omitir los dos campos, nunca inventar un codigo {@code E-0xx}.
 */
final class PantallaCajero {

    /**
     * Par de valores que se agregan al cuerpo de error, y solo en este canal.
     *
     * @param codigo  codigo corto, formato {@code E-NNN}
     * @param mensaje texto breve para la pantalla, sin tildes
     */
    record Pantalla(String codigo, String mensaje) {
    }

    /**
     * Las dieciseis filas de la seccion 7.2, escritas una sola vez.
     *
     * <p>Se usan las constantes de {@link MotivosError} como claves en lugar de las cadenas
     * literales: si alguien cambia la grafia de un motivo en la libreria, esta tabla deja de
     * compilar en vez de quedarse callada devolviendo un mapa que ya no coincide con nada.
     *
     * <p>Las filas de autenticacion, autorizacion y retiro ya estan aqui aunque este canal todavia
     * no pueda producirlas: la tabla es una transcripcion del contrato, no un inventario de lo que
     * hay implementado hoy. Transcribirla completa de una vez evita el error tipico de copiarla por
     * partes y terminar con dos filas que no coinciden con el documento.
     */
    private static final Map<String, Pantalla> POR_MOTIVO = Map.ofEntries(
            Map.entry(MotivosError.CREDENCIALES_INVALIDAS, new Pantalla("E-010", "Tarjeta o PIN incorrectos")),
            Map.entry(MotivosError.PIN_BLOQUEADO, new Pantalla("E-011", "Tarjeta bloqueada")),
            Map.entry(MotivosError.TERMINAL_NO_REGISTRADO, new Pantalla("E-012", "Terminal no autorizado")),
            Map.entry(MotivosError.TOKEN_AUSENTE, new Pantalla("E-021", "Sesion no iniciada")),
            Map.entry(MotivosError.TOKEN_EXPIRADO, new Pantalla("E-020", "Sesion expirada")),
            Map.entry(MotivosError.FIRMA_INVALIDA, new Pantalla("E-022", "Sesion no valida")),
            Map.entry(MotivosError.AUDIENCIA_INVALIDA, new Pantalla("E-023", "Sesion no valida")),
            Map.entry(MotivosError.PERMISO_INSUFICIENTE, new Pantalla("E-030", "Operacion no permitida")),
            Map.entry(MotivosError.CUENTA_AJENA, new Pantalla("E-031", "Cuenta no asociada a la tarjeta")),
            Map.entry(MotivosError.RECURSO_NO_ENCONTRADO, new Pantalla("E-040", "Cuenta no disponible")),
            Map.entry(MotivosError.SALDO_INSUFICIENTE, new Pantalla("E-042", "Fondos insuficientes")),
            Map.entry(MotivosError.MONTO_NO_MULTIPLO, new Pantalla("E-050", "Monto debe ser multiplo de 1.000")),
            Map.entry(MotivosError.MONTO_BAJO_MINIMO, new Pantalla("E-051", "Monto bajo el minimo")),
            Map.entry(MotivosError.SUPERA_TOPE_TRANSACCION, new Pantalla("E-052", "Monto sobre el maximo por operacion")),
            Map.entry(MotivosError.ERROR_INTERNO, new Pantalla("E-091", "Falla del sistema")),
            Map.entry(MotivosError.CORE_NO_DISPONIBLE, new Pantalla("E-090", "Servicio no disponible")));

    /**
     * Devuelve la fila del motivo, o {@code null} si el contrato no congela ninguna.
     *
     * <p>Se devuelve {@code null} a proposito y no un par de cadenas vacias: una cadena vacia
     * aparaceria en el JSON como {@code "codigoPantalla": ""}, que le dice al firmware que hay un
     * codigo y que es vacio. El {@code null}, combinado con la serializacion del cuerpo de error,
     * hace que el campo simplemente no exista, que es la informacion correcta.
     */
    static Pantalla paraMotivo(String motivo) {
        return POR_MOTIVO.get(motivo);
    }

    private PantallaCajero() {
    }
}
