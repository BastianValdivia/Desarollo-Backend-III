package cl.duoc.bancoxyz.bff.atm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Punto de entrada del <strong>bff-atm</strong>, el Backend for Frontend del canal cajero.
 *
 * <p>Escucha en el puerto 8445 bajo el context-path {@code /api/atm}. Su cliente es una maquina
 * fisica en via publica: desatendida, sin teclado alfanumerico y a la vista de cualquiera.
 *
 * <p>Es el canal mas pequeno de los tres y, al mismo tiempo, el unico que mueve dinero. Sus
 * decisiones de diseno se derivan de ese contexto y no de una preferencia estetica:
 *
 * <ul>
 *   <li>La respuesta mas reducida del proyecto: saldo disponible y moneda, nada mas. Sin nombre
 *       del titular, sin edad y sin tipo de cuenta, porque quien mira esa pantalla esta en la
 *       calle.</li>
 *   <li>Credencial de tarjeta mas PIN, terminal validado contra lista blanca y bloqueo tras tres
 *       intentos fallidos.</li>
 *   <li>Sesion de 3 minutos sin renovacion: el usuario se retira de la maquina y la sesion no
 *       puede quedar viva detras de el.</li>
 *   <li>Y una ausencia deliberada que hay que saber defender: <strong>no cachea el saldo</strong>.
 *       Un saldo con 60 segundos de antiguedad en un cajero significa entregar dinero que ya no
 *       existe. Es una decision de correctitud, no de rendimiento.</li>
 * </ul>
 *
 * <p>La operacion de retiro es exclusiva de este canal: el mismo POST contra los puertos 8443 o
 * 8444 devuelve 404, y esa es la prueba mas directa de que los tres BFF no son intercambiables.
 * La idempotencia de ese retiro, en cambio, <em>no</em> vive aqui: este modulo solo reenvia la
 * cabecera {@code Idempotency-Key} al core, porque la idempotencia protege una mutacion de
 * estado y el estado tiene un unico dueno.
 *
 * <p>Esta clase no contiene logica: en Spring Boot la clase principal es solo el disparador.
 */
@SpringBootApplication(
        /*
         * Sin esta enumeracion, el escaneo por defecto cubriria solo cl.duoc.bancoxyz.bff.atm y
         * los beans de la libreria compartida no existirian. Ver la explicacion extendida en
         * BffWebApplication: se prefiere esta linea visible antes que el mecanismo de
         * auto-configuracion, que falla en silencio cuando algo no calza.
         */
        scanBasePackages = {"cl.duoc.bancoxyz.bff.atm", "cl.duoc.bancoxyz.comun"}
)
/*
 * @SpringBootApplication escanea componentes pero no propiedades. Sin esta anotacion, una clase
 * @ConfigurationProperties no se registra como bean y el arranque muere con un mensaje que no
 * apunta a la causa. En este modulo importa especialmente, porque las reglas del retiro
 * (multiplo, minimo, tope y denominaciones) van todas externalizadas a config-repo/bff-atm.yml y ninguna
 * como constante en el codigo.
 */
// Se escanea SOLO cl.duoc.bancoxyz.comun.core, no el paquete comun completo: es el unico paquete de la
// libreria compartida que declara propiedades (la direccion y los tiempos del cliente del core). Escanear
// mas obligaria a cada BFF a declarar un bloque de configuracion que quiza no necesita, y un bloque ausente
// fallaria al arrancar con un mensaje que no apunta a la causa. Desde F5 ningun BFF emite tokens, asi que
// la libreria ya no trae politica de token que declarar: solo valida (ver ConfianzaEnElAuthServerConfig).
@ConfigurationPropertiesScan({"cl.duoc.bancoxyz.bff.atm", "cl.duoc.bancoxyz.comun.core"})
public class BffAtmApplication {

    public static void main(String[] args) {
        SpringApplication.run(BffAtmApplication.class, args);
    }
}
