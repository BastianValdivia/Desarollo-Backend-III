package cl.duoc.bancoxyz.bff.atm.aplicacion;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.bff.atm.api.dto.RetiroAtmResponse;
import cl.duoc.bancoxyz.bff.atm.config.AtmProperties;
import cl.duoc.bancoxyz.bff.atm.config.ReglasRetiroProperties;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto;

/**
 * La operacion critica del sistema: entregar dinero.
 *
 * <h2>El reparto de responsabilidades, que es lo primero que hay que entender aqui</h2>
 *
 * <p>Este servicio <b>no</b> resta saldos ni decide si alcanza el dinero. Eso lo hace el core, de
 * forma atomica y idempotente, y ya esta probado alli: veinte retiros simultaneos de 1.000 sobre un
 * saldo de 12.000 dan doce exitos, ocho rechazos y saldo cero. Duplicar esa comprobacion aqui
 * seria peor que inutil: entre el momento en que este canal mirara el saldo y el momento en que el
 * core lo modificara existiria una ventana en la que otro retiro podria colarse, y el canal habria
 * dado un permiso que ya no es cierto. <b>El estado tiene un unico dueno y las decisiones sobre el
 * estado se toman donde vive el estado.</b>
 *
 * <p>Lo que si aporta este canal, y que el core no puede aportar, es todo lo que depende de que al
 * otro lado haya una maquina con billetes y una persona de pie frente a ella:
 *
 * <ul>
 *   <li>La <b>titularidad</b>: que la cuenta de la URL sea la cuenta de la tarjeta.</li>
 *   <li>Las <b>reglas del monto</b>: multiplo, minimo y tope, cada una con su motivo propio.</li>
 *   <li>El <b>reenvio</b> de {@code Idempotency-Key}, sin guardar nada.</li>
 *   <li>El <b>desglose</b> en billetes de lo que efectivamente se retiro.</li>
 * </ul>
 *
 * <h2>Por que el canal no guarda nada de la idempotencia</h2>
 *
 * <p>Porque la idempotencia protege una <b>mutacion de estado</b>, y el estado vive en el core. Si
 * este BFF llevara su propio registro de claves ya vistas, habria dos registros que pueden
 * discrepar: bastaria reiniciar el canal para que una clave ya usada volviera a parecer nueva y el
 * retiro se ejecutara dos veces. La cabecera se reenvia tal cual y la decision se toma una sola vez,
 * en un solo sitio.
 */
@Service
public class RetiroAtmService {

    private static final Logger log = LoggerFactory.getLogger(RetiroAtmService.class);

    private final CoreClient core;
    private final GuardiaTitularidad guardia;
    private final ReglasRetiroProperties reglas;
    private final AtmProperties atm;

    public RetiroAtmService(CoreClient core,
                            GuardiaTitularidad guardia,
                            ReglasRetiroProperties reglas,
                            AtmProperties atm) {
        this.core = core;
        this.guardia = guardia;
        this.reglas = reglas;
        this.atm = atm;
    }

    /**
     * Ejecuta un retiro.
     *
     * <p>El orden de las cuatro comprobaciones esta congelado en el contrato y cada paso responde a
     * una pregunta distinta: <b>titularidad</b> (es tu cuenta?), <b>multiplo</b> (puede esta
     * maquina componer esa cifra?), <b>minimo y tope</b> (esta dentro de lo que este canal
     * permite?) y <b>saldo</b> (tienes ese dinero?, que decide el core con un 409).
     *
     * @param cuentaId          cuenta de la ruta
     * @param monto             monto pedido, posiblemente nulo si el cuerpo venia incompleto
     * @param claveIdempotencia valor de {@code Idempotency-Key}, posiblemente nulo
     * @param token             token ya validado, de donde sale el claim {@code cuentaId}
     */
    public RetiroAtmResponse retirar(int cuentaId, BigDecimal monto, String claveIdempotencia, Jwt token) {
        guardia.exigirTitularidad(token, cuentaId);

        BigDecimal montoValidado = validarMonto(monto);

        RetiroCoreDto retiro = core.ejecutarRetiro(
                cuentaId,
                new SolicitudRetiroCoreDto(montoValidado),
                resolverClaveIdempotencia(claveIdempotencia));

        log.info("Retiro {} ejecutado sobre la cuenta {}: {} entregados, saldo {} -> {}.",
                retiro.folio(), cuentaId, retiro.montoRetirado(),
                retiro.saldoAnterior(), retiro.saldoPosterior());

        /*
         * El desglose se calcula sobre lo que el core dice que retiro, no sobre lo que se pidio. Hoy
         * son el mismo numero, pero la respuesta de una operacion siempre se construye con el
         * resultado de la operacion: el dia que el core aplique un redondeo o un cobro, la pantalla
         * seguiria contando billetes que la gaveta no entrego.
         */
        return new RetiroAtmResponse(
                retiro.folio(),
                retiro.saldoAnterior(),
                retiro.montoRetirado(),
                retiro.saldoPosterior(),
                DesgloseDenominaciones.repartir(retiro.montoRetirado(), atm.denominaciones()));
    }

    /**
     * Aplica las tres reglas de monto en el orden congelado de la seccion 7.3 del contrato.
     *
     * <p>El orden es la parte que importa. Un mismo monto puede violar dos reglas a la vez, y 500
     * (que no es multiplo de 1.000 <em>y</em> esta bajo el minimo de 1.000) debe responder
     * {@code monto_no_multiplo}. Si cada implementacion eligiera su orden, la misma peticion daria
     * motivos distintos segun quien la escribio y la evidencia dejaria de comparar lo mismo.
     */
    private BigDecimal validarMonto(BigDecimal monto) {
        if (monto == null) {
            /*
             * Un cuerpo sin monto se trata como monto bajo el minimo, y no como peticion invalida:
             * este canal no emite 400 (seccion 7.1) y "no hay cifra" es, para un cajero, lo mismo
             * que una cifra que no alcanza el minimo. La pantalla E-051 le dice al operador lo
             * unico que puede hacer al respecto, que es teclear una cifra mayor.
             */
            throw ReglaAtmException.montoBajoMinimo(null, reglas.minimo());
        }

        if (monto.remainder(reglas.multiplo()).signum() != 0) {
            throw ReglaAtmException.montoNoMultiplo(monto, reglas.multiplo());
        }
        if (monto.compareTo(reglas.minimo()) < 0) {
            throw ReglaAtmException.montoBajoMinimo(monto, reglas.minimo());
        }
        if (monto.compareTo(reglas.topeTransaccion()) > 0) {
            throw ReglaAtmException.superaTopeTransaccion(monto, reglas.topeTransaccion());
        }

        return monto;
    }

    /**
     * Devuelve la clave que se reenviara al core, inventando una si el terminal no mando ninguna.
     *
     * <p>Quien genera la clave es siempre el cliente, porque solo el sabe si esta reintentando el
     * mismo retiro o pidiendo uno nuevo: dos peticiones identicas son una repeticion si hubo un
     * timeout de por medio y dos operaciones distintas si el usuario quiso sacar dinero dos veces.
     * Cuando el terminal no la manda, lo unico honesto es tratar la peticion como un intento nuevo;
     * lo que se pierde es la proteccion ante reintentos, y se pierde por decision del terminal, no
     * por algo que este canal pueda arreglar. Inventar aqui una clave estable (por ejemplo a partir
     * de cuenta y monto) seria mucho peor: convertiria dos retiros legitimos y seguidos de 2.000 en
     * uno solo, y el cliente se iria con la mitad de su dinero.
     */
    private String resolverClaveIdempotencia(String claveIdempotencia) {
        if (claveIdempotencia != null && !claveIdempotencia.isBlank()) {
            return acotarLargo(claveIdempotencia);
        }
        log.warn("Retiro sin cabecera Idempotency-Key: se trata como intento nuevo y un reintento "
                + "por timeout retiraria dos veces.");
        return "sin-clave-" + UUID.randomUUID();
    }

    /**
     * Largo maximo de la clave que acepta el core (columna {@code varchar(200)} de su registro de
     * idempotencia, F3). Se repite aqui, y no se importa, porque este modulo no conoce al core mas
     * que por su contrato HTTP.
     */
    static final int LARGO_MAXIMO_CLAVE_CORE = 200;

    /**
     * Si la clave del terminal pasa del largo que el core acepta, la reemplaza por su resumen SHA-256.
     *
     * <p>Por que no se rechaza con un 400: este canal no emite 400 (contrato, seccion 7.1), y el
     * terminal no tiene nada que corregir en su pantalla. Por que un resumen y no un recorte: dos
     * claves distintas que comparten los primeros 200 caracteres colisionarian, y un retiro
     * legitimo se tomaria por el reintento de otro. El resumen es <em>determinista</em>, de modo que
     * un reintento con la misma clave larga produce el mismo resumen y sigue siendo idempotente.
     * Las claves normales (hasta 200 caracteres) pasan intactas.
     */
    private static String acotarLargo(String clave) {
        if (clave.length() <= LARGO_MAXIMO_CLAVE_CORE) {
            return clave;
        }
        try {
            byte[] resumen = MessageDigest.getInstance("SHA-256").digest(clave.getBytes(StandardCharsets.UTF_8));
            return "sha256-" + HexFormat.of().formatHex(resumen);
        } catch (NoSuchAlgorithmException inexistente) {
            // SHA-256 es obligatorio en toda JVM (lo exige la especificacion de Java SE).
            throw new IllegalStateException("La JVM no trae SHA-256", inexistente);
        }
    }
}
