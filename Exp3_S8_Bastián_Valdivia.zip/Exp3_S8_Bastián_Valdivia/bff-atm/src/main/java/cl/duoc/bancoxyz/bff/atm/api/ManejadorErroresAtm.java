package cl.duoc.bancoxyz.bff.atm.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import cl.duoc.bancoxyz.bff.atm.aplicacion.ReglaAtmException;
import cl.duoc.bancoxyz.bff.atm.api.dto.RespuestaErrorAtm;
import cl.duoc.bancoxyz.comun.core.CoreClaveIdempotenciaReutilizadaException;
import cl.duoc.bancoxyz.comun.core.CoreCredencialRechazadaException;
import cl.duoc.bancoxyz.comun.core.CoreException;
import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.core.CoreSaldoInsuficienteException;
import cl.duoc.bancoxyz.comun.error.MotivosError;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Convierte cualquier fallo del canal cajero en un cuerpo RFC 7807 con la forma que este canal, y
 * solo este canal, publica.
 *
 * <h2>Que es un {@code @RestControllerAdvice}, para quien no lo ha visto</h2>
 *
 * <p>Es una clase que Spring consulta cuando un controlador lanza una excepcion. En lugar de que
 * cada metodo tenga su propio {@code try/catch}, los casos se escriben <b>una sola vez</b> aqui. El
 * beneficio practico es doble: los controladores quedan limpios, y ningun camino puede olvidarse de
 * traducir un error y terminar devolviendo la pagina de error generica del servidor, que no se
 * parece en nada al resto de la API.
 *
 * <h2>Por que la traduccion vive en el canal y no en la libreria compartida</h2>
 *
 * <p>El {@link CoreException} dice QUE paso ("el core no respondio", "el recurso no existe"). Esta
 * clase decide COMO se ve eso desde afuera: con que codigo HTTP, con que titulo y con que codigo de
 * pantalla. Eso ultimo es politica, y la politica es de cada canal: ante el mismo core caido, web
 * responde 503 con un {@code detail} explicativo y el cajero responde 503 con {@code E-090} y sin
 * {@code detail}. Si esta traduccion viviera en {@code plataforma-comun}, los tres canales estarian
 * obligados a responder igual y dejarian de estar adaptados a su cliente.
 *
 * <h2>Las tres decisiones propias de este canal, que conviene leer juntas</h2>
 *
 * <ol>
 *   <li><b>Nunca se envia {@code detail}.</b> No es que se omita: el record de respuesta ni siquiera
 *       declara el campo. Un cajero no le cuenta detalles tecnicos a la calle.</li>
 *   <li><b>Ante la duda, 404.</b> Una ruta desconocida, un verbo que no corresponde o un id que no
 *       es un numero devuelven todos {@code recurso_no_encontrado}. Un canal que respondiera 400
 *       aqui y 405 alla le estaria dando a quien sondea la maquina un mapa gratuito de lo que existe
 *       y lo que no.</li>
 *   <li><b>El core que rechaza la credencial de servicio NO se traduce en 401.</b> Ver el metodo
 *       correspondiente: es el error mas facil de cometer en todo el proyecto.</li>
 * </ol>
 *
 * <h2>Que parte de los errores pasa por aqui y que parte no</h2>
 *
 * <p>Esta es la division que mas confusion causa al depurar, asi que conviene tenerla escrita:
 *
 * <ul>
 *   <li>Pasan por aqui los fallos que ocurren <b>dentro</b> de un controlador: las reglas propias
 *       del canal ({@link ReglaAtmException}: terminal no registrado, credenciales, PIN bloqueado,
 *       cuenta ajena y las tres del monto), los fallos al hablar con el core y cualquier defecto
 *       inesperado.</li>
 *   <li><b>No</b> pasan por aqui los 401 por token ausente o invalido ni el 403 por falta de
 *       autoridad. Esos los decide la cadena de filtros, <b>antes</b> de que exista un controlador
 *       al que despachar, y por eso los escriben a mano {@code PuntoEntradaAtm} y
 *       {@code ManejadorAccesoDenegadoAtm}. Buscar aqui por que un 401 sale con el formato
 *       equivocado es buscar en el archivo que no es.</li>
 * </ul>
 *
 * <p>Los dos caminos producen el mismo cuerpo porque los dos usan {@code RespuestaErrorAtm}, que es
 * el unico sitio donde se decide como se ve un error de este canal.
 */
@RestControllerAdvice
public class ManejadorErroresAtm {

    private static final Logger log = LoggerFactory.getLogger(ManejadorErroresAtm.class);

    /**
     * La cuenta pedida no existe en el dominio (el core respondio 404).
     *
     * <p>Se registra en nivel {@code info} y no {@code error}: pedir una cuenta inexistente es
     * funcionamiento normal de una API publica, no una averia. Un log que grite ante cada 404 acaba
     * lleno de ruido y hace que los fallos de verdad pasen desapercibidos.
     *
     * <p><b>La distincion que hay que tener clara.</b> Esto es "no existe". "Existe y no es tuya" es
     * un caso distinto que devolvera 403 {@code cuenta_ajena} cuando el canal tenga tokens, y que ni
     * siquiera llegara a salir a la red: se corta comparando el claim del token con la variable de
     * ruta. Responder 404 a una cuenta ajena convertiria la API en un detector de cuentas existentes
     * por diferencia de respuestas.
     */
    @ExceptionHandler(CoreRecursoNoEncontradoException.class)
    public ResponseEntity<RespuestaErrorAtm> manejarNoEncontrado(CoreRecursoNoEncontradoException excepcion,
                                                                HttpServletRequest peticion) {
        log.info("Recurso inexistente en {} {}: {}",
                peticion.getMethod(), peticion.getRequestURI(), excepcion.getMessage());

        return noEncontrado(peticion);
    }

    /**
     * El core no respondio, respondio 5xx, o rechazo el token de servicio de este BFF (401 o 403).
     *
     * <p><b>Por que la credencial rechazada se trata como dependencia caida y no como 401.</b> Es el
     * error mas tentador del proyecto. Si el core rechaza el token de servicio, el problema es de
     * despliegue o de permisos: el auth-server y el core no coinciden en emisor o audiencia, o el
     * cliente OAuth2 de este canal perdio un scope. El usuario del cajero no tiene ninguna culpa ni ningun remedio. Devolverle un 401 le
     * dice "vuelve a identificarte", cosa que no va a arreglar nada, y ademas manda a quien
     * diagnostique el problema a mirar la autenticacion del canal, que es el unico lugar donde el fallo no
     * esta. Lo correcto es declarar la dependencia inutilizable, responder 503 y dejar el diagnostico
     * real en el log del servidor, que es donde lo puede leer un operador y no un transeunte.
     *
     * <p>Este es tambien el metodo que sostiene la evidencia de <b>degradacion controlada</b>: se
     * detiene el core, se repite la consulta de saldo y el canal responde un 503 bien formado, con
     * {@code E-090} en la pantalla, en el tiempo del timeout configurado. Que un sistema falle de
     * forma prevista y descriptible cuando su dependencia se cae es tan parte de la calidad como que
     * funcione cuando todo esta bien.
     *
     * <p><b>Por que captura tambien la clase base {@link CoreException}.</b> Para que la garantia sea
     * total: cualquier fallo al hablar con el core, incluido uno que este codigo no previo, sale por
     * aqui como 503 y nunca como una pagina de error generica. Desde la vereda, "el core respondio
     * algo que no entiendo" y "el core no respondio" son la misma situacion: la maquina no puede
     * operar. La diferencia queda en el log, que es donde sirve.
     */
    @ExceptionHandler({CoreNoDisponibleException.class,
            CoreCredencialRechazadaException.class,
            CoreException.class})
    public ResponseEntity<RespuestaErrorAtm> manejarCoreInutilizable(CoreException excepcion,
                                                                    HttpServletRequest peticion) {
        // Nivel error y con la excepcion completa: aqui si hay algo que un operador debe arreglar.
        // El detalle tecnico se queda de este lado; al cliente solo le llega E-090.
        log.error("El core quedo inutilizable para {} {} (ruta del core: {}, estado: {})",
                peticion.getMethod(), peticion.getRequestURI(),
                excepcion.rutaSolicitada(), excepcion.estadoDelCore(), excepcion);

        return construir(HttpStatus.SERVICE_UNAVAILABLE, MotivosError.CORE_NO_DISPONIBLE,
                "Servicio no disponible", peticion);
    }

    /**
     * Rutas que este canal no sirve, verbos que no corresponden e identificadores que no son numeros.
     *
     * <p>Los tres casos responden lo mismo, <b>404 {@code recurso_no_encontrado}</b>, y esa
     * uniformidad es la decision de diseno:
     *
     * <ul>
     *   <li>{@code POST /v1/cuentas/116/retiros} todavia no existe en este canal, y
     *       {@code /v1/resumen-mensual} no existira nunca: es de web. Las dos son "aqui no hay
     *       nada".</li>
     *   <li>Un {@code POST} contra el saldo podria responder 405 con la cabecera {@code Allow}, que
     *       es lo estandar y lo correcto en una API para desarrolladores. Aqui no: esa respuesta le
     *       confirma a quien sondea la maquina que la ruta existe y le dice ademas con que verbo
     *       usarla. Un canal en via publica prefiere no distinguir.</li>
     *   <li>{@code /v1/cuentas/abc/saldo-disponible} es 404 por la misma razon, y con una ventaja
     *       adicional: la peticion muere en el borde y no llega a generar ninguna llamada al core.
     *       Los tres canales coinciden en este punto: un identificador que no es un numero no
     *       nombra ninguna cuenta, igual que un identificador que no existe. El canal web si
     *       conserva un 400 propio, pero solo para sus <em>parametros de consulta</em>
     *       ({@code ?desde}, {@code ?tipo}), que este canal no expone.</li>
     * </ul>
     *
     * <p><b>Por que se declaran {@code NoHandlerFoundException} y {@code NoResourceFoundException}.</b>
     * Spring cambio de mecanismo: la primera es la clasica y solo se lanza si se activa una propiedad;
     * desde Spring Framework 6.1, una ruta sin controlador cae en el manejador de recursos estaticos y
     * termina lanzando la segunda. Declarar solo una deja la otra sin capturar, y entonces la atrapa
     * la red de seguridad de mas abajo y <b>responde 500 a lo que es un 404</b>: un error de cliente
     * disfrazado de averia del servidor. Es exactamente el tipo de detalle que solo aparece probando
     * de verdad una ruta inexistente.
     */
    @ExceptionHandler({NoHandlerFoundException.class,
            NoResourceFoundException.class,
            HttpRequestMethodNotSupportedException.class,
            MethodArgumentTypeMismatchException.class})
    public ResponseEntity<RespuestaErrorAtm> manejarRutaDesconocida(HttpServletRequest peticion) {
        log.info("Ruta no servida por este canal: {} {}", peticion.getMethod(), peticion.getRequestURI());

        return noEncontrado(peticion);
    }

    /**
     * Las reglas propias de este canal, con el estado y el motivo que cada una ya trae consigo.
     *
     * <p>Un unico metodo cubre siete casos (401 terminal no registrado, 401 credenciales invalidas,
     * 423 PIN bloqueado, 403 cuenta ajena y los tres 422 del monto) porque la excepcion no dice solo
     * "algo salio mal": dice exactamente con que codigo y con que {@code motivo} congelado hay que
     * responder. La traduccion deja de ser una cadena de {@code instanceof} y pasa a ser una copia
     * de dos campos, y no existe la posibilidad de que un caso nuevo se olvide de pasar por aqui.
     *
     * <p>Se registra en nivel {@code info}: un PIN equivocado o un monto que no es multiplo de 1.000
     * son funcionamiento normal de un cajero, no averias. Lo unico que sube a {@code warn} es el
     * bloqueo de una tarjeta, y lo hace desde el servicio que lo decide.
     */
    @ExceptionHandler(ReglaAtmException.class)
    public ResponseEntity<RespuestaErrorAtm> manejarReglaDelCanal(ReglaAtmException excepcion,
                                                                  HttpServletRequest peticion) {
        log.info("{} {} rechazado con {}: {}", peticion.getMethod(), peticion.getRequestURI(),
                excepcion.motivo(), excepcion.getMessage());

        return construir(excepcion.estado(), excepcion.motivo(), excepcion.titulo(), peticion);
    }

    /**
     * El core rechazo el retiro por falta de saldo (respondio 409).
     *
     * <p><b>Por que este caso tiene metodo propio y no cae en el de "core inutilizable".</b> Porque
     * {@link CoreSaldoInsuficienteException} hereda de {@link CoreException}, y sin esta declaracion
     * saldria por el manejador de mas arriba convertida en un <b>503</b>: el canal diria "el banco no
     * esta disponible" cuando lo que pasa es que la cuenta no tiene fondos. Spring elige siempre el
     * manejador mas especifico, asi que basta con declararlo; pero si alguien borrara este metodo,
     * el fallo no seria un error de compilacion sino una respuesta perfectamente formada y
     * completamente equivocada.
     *
     * <p><b>Por que es 409 y no 422.</b> Los tres motivos de 422 dicen "esa cifra no se puede pedir
     * nunca en esta maquina" y no cambian con el tiempo. El 409 dice "esa cifra no se puede pedir
     * AHORA", porque el saldo es estado y el estado cambia: el mismo retiro de 8.000 que hoy falla
     * funciona manana si entra un deposito. Un conflicto con el estado actual es exactamente lo que
     * significa 409.
     *
     * <p>Y es el core quien lo decide, no este canal: preguntar aqui por el saldo antes de retirar
     * abriria una ventana entre la consulta y el retiro en la que otra operacion podria colarse.
     */
    @ExceptionHandler(CoreSaldoInsuficienteException.class)
    public ResponseEntity<RespuestaErrorAtm> manejarSaldoInsuficiente(CoreSaldoInsuficienteException excepcion,
                                                                      HttpServletRequest peticion) {
        log.info("Retiro rechazado por saldo insuficiente en {}: {}",
                peticion.getRequestURI(), excepcion.getMessage());

        return construir(HttpStatus.CONFLICT, MotivosError.SALDO_INSUFICIENTE,
                "Operacion rechazada", peticion);
    }

    /**
     * El core rechazo el retiro porque la {@code Idempotency-Key} ya se uso en esa cuenta con otro
     * importe (respondio 422 {@code clave_idempotencia_reutilizada}).
     *
     * <p>Tiene metodo propio por la misma razon que el saldo insuficiente: hereda de
     * {@link CoreException} y sin esta declaracion saldria como un 503 "servicio no disponible", cuando
     * el banco esta sano y lo defectuoso es la peticion (el firmware reuso una clave para otra
     * operacion). Es 422 y no 409 porque reintentar igual siempre fallara: hace falta una clave nueva.
     * El motivo no tiene fila en la tabla de pantallas, asi que la respuesta sale sin
     * {@code codigoPantalla}.
     */
    @ExceptionHandler(CoreClaveIdempotenciaReutilizadaException.class)
    public ResponseEntity<RespuestaErrorAtm> manejarClaveReutilizada(
            CoreClaveIdempotenciaReutilizadaException excepcion, HttpServletRequest peticion) {
        log.info("Retiro rechazado por Idempotency-Key reutilizada en {}: {}",
                peticion.getRequestURI(), excepcion.getMessage());

        return construir(HttpStatus.UNPROCESSABLE_ENTITY, MotivosError.CLAVE_IDEMPOTENCIA_REUTILIZADA,
                "Operacion rechazada", peticion);
    }

    /**
     * Un cuerpo que este canal no puede leer, o que no viene en JSON.
     *
     * <p>La respuesta natural en cualquier API seria 400 {@code peticion_invalida}. <b>Este canal no
     * puede darla</b>: la seccion 7.1 del contrato declara que el cajero no emite 400, y la tabla de
     * pantallas de la 7.2 no tiene fila para ese motivo, de modo que un 400 saldria sin
     * {@code codigoPantalla} y el firmware no sabria que mostrar.
     *
     * <p>Se responde entonces 401 {@code credenciales_invalidas}, que si tiene fila en la tabla de
     * pantallas (E-010). Antes de F5 la eleccion tenia todo el sentido en el login de este canal: un
     * login cuyo cuerpo no se entiende no trae credenciales. El login ya no esta aqui (es del
     * auth-server), pero el caso sigue existiendo en el retiro: la unica ruta con cuerpo.
     *
     * <p>Queda una consecuencia que conviene declarar en vez de disimular: un retiro con el cuerpo
     * mal formado, enviado por un terminal averiado, sale con ese 401 en lugar de con un mensaje sobre
     * el monto. Se acepta a cambio de no introducir en el canal un codigo de estado que su tabla de
     * pantallas no sabe nombrar.
     */
    @ExceptionHandler({HttpMessageNotReadableException.class, HttpMediaTypeNotSupportedException.class})
    public ResponseEntity<RespuestaErrorAtm> manejarCuerpoIlegible(Exception excepcion,
                                                                   HttpServletRequest peticion) {
        log.info("Cuerpo ilegible en {} {}: {}",
                peticion.getMethod(), peticion.getRequestURI(), excepcion.getMessage());

        return construir(HttpStatus.UNAUTHORIZED, MotivosError.CREDENCIALES_INVALIDAS,
                "No autenticado", peticion);
    }

    /**
     * Red de seguridad: cualquier fallo no previsto.
     *
     * <p>Existe para que <b>ninguna</b> respuesta de este canal se salga del formato RFC 7807, ni
     * siquiera cuando el error es un defecto del propio codigo. Es el unico manejador que registra
     * con la traza completa, porque aqui si hay una averia que alguien tiene que arreglar, y el
     * unico que responde 500.
     *
     * <p><b>Sobre el motivo elegido.</b> La version 1.1.0 del contrato congelo el motivo del 500,
     * {@code error_interno}, y su fila de pantalla, {@code E-091} con el texto
     * {@code Falla del sistema}. Antes este metodo escribia el literal a mano y omitia los dos
     * campos de pantalla, que era lo correcto mientras el documento no los cubriera.
     *
     * <p><b>Por que {@code E-091} y no reutilizar {@code E-090}.</b> Para quien esta frente a la
     * maquina los dos significan lo mismo: hoy no se puede operar. Para quien diagnostica significan
     * cosas opuestas: {@code E-090} dice "el core no responde" y {@code E-091} dice "el canal fallo
     * por su cuenta". Un solo codigo para los dos casos manda al operador a mirar el servicio
     * equivocado la mitad de las veces.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<RespuestaErrorAtm> manejarInesperado(Exception excepcion,
                                                               HttpServletRequest peticion) {
        log.error("Fallo no controlado en {} {}", peticion.getMethod(), peticion.getRequestURI(), excepcion);

        return construir(HttpStatus.INTERNAL_SERVER_ERROR, MotivosError.ERROR_INTERNO,
                "Error interno", peticion);
    }

    /**
     * Un solo lugar para el 404, para que los dos caminos que lo producen no puedan divergir.
     *
     * <p>Desde la version 1.1.0 del contrato este 404 si lleva pantalla: {@code E-040} con el texto
     * {@code Cuenta no disponible}. El texto evita a proposito decir "la cuenta no existe": una
     * pantalla que distinga "no existe" de "existe y no es tuya" convierte al cajero en un detector
     * de cuentas existentes para cualquiera que pruebe numeros en via publica. El {@code motivo} si
     * distingue los dos casos, porque eso lo lee quien opera el sistema y no quien pasa por delante.
     */
    private ResponseEntity<RespuestaErrorAtm> noEncontrado(HttpServletRequest peticion) {
        return construir(HttpStatus.NOT_FOUND, MotivosError.RECURSO_NO_ENCONTRADO,
                "Recurso no encontrado", peticion);
    }

    /**
     * Arma la respuesta, fijando siempre {@code application/problem+json}.
     *
     * <p>Ese tipo de contenido es parte del estandar y no un adorno: le dice al cliente, desde la
     * cabecera y sin mirar el cuerpo, que lo que viene describe un problema. Fijarlo en un unico
     * lugar garantiza que ningun manejador se olvide de ponerlo.
     *
     * <p>El campo {@code instance} sale de {@code getRequestURI()}, que incluye el
     * {@code context-path}: la ruta que se publica en el error es la misma que el cliente escribio
     * ({@code /api/atm/v1/...}) y no la ruta interna del controlador. Publicar la interna obligaria a
     * quien lee la evidencia a reconstruir mentalmente el prefijo.
     *
     * <p><b>Sobre la cabecera {@code WWW-Authenticate}.</b> El contrato exige que la lleven
     * <b>todas</b> las respuestas 401 y <b>ninguna</b> 403. Esa cabecera significa "identificate, y
     * hazlo con este esquema": es informacion util para quien todavia no se ha identificado y un
     * consejo equivocado para quien ya lo hizo y solo carece de permiso. Se pone aqui, en el unico
     * sitio por donde pasan todas las respuestas de error, para que ningun manejador nuevo pueda
     * olvidarla ni ponerla donde no toca.
     */
    private ResponseEntity<RespuestaErrorAtm> construir(HttpStatus estado, String motivo,
                                                        String titulo, HttpServletRequest peticion) {
        ResponseEntity.BodyBuilder respuesta = ResponseEntity.status(estado)
                .contentType(MediaType.APPLICATION_PROBLEM_JSON);

        if (estado == HttpStatus.UNAUTHORIZED) {
            respuesta.header(HttpHeaders.WWW_AUTHENTICATE, "Bearer");
        }

        return respuesta.body(
                RespuestaErrorAtm.de(estado.value(), motivo, titulo, peticion.getRequestURI()));
    }
}
