package cl.duoc.bancoxyz.bff.atm.api.dto;

import java.util.List;

/**
 * Respuesta del endpoint A4, {@code GET /api/atm/v1/denominaciones}, congelada en la seccion 5.13
 * del contrato.
 *
 * <p><b>Es uno de los dos endpoints exclusivos del cajero.</b> La misma ruta contra el puerto 8443
 * o el 8444 devuelve 404, y ese contraste es la prueba mas directa de que los tres BFF no son
 * intercambiables: no es que web y movil "todavia no lo tengan", es que un navegador y un telefono
 * no entregan billetes y no tienen nada que preguntar sobre ellos.
 *
 * <h2>Por que el core no participa en esta respuesta</h2>
 *
 * <p>El core es el dueno del dinero, no de los billetes. Sabe que la cuenta 116 tiene 12.000, y no
 * tiene por que saber con que papeles se entregan: eso depende de la maquina y de la plaza. Meter
 * las denominaciones en el core contaminaria un backend de dominio con un concepto de presentacion
 * de un solo canal. Por eso este endpoint se sirve <b>sin una sola llamada de red</b>, leyendo la
 * configuracion del propio canal, y es a la vez el ejemplo mas barato de "valor que agrega un BFF".
 *
 * @param moneda         literal {@code CLP}
 * @param denominaciones billetes que la maquina entrega, en orden ascendente, leidos de
 *                       {@code atm.denominaciones}
 */
public record DenominacionesAtmResponse(
        String moneda,
        List<Integer> denominaciones) {
}
