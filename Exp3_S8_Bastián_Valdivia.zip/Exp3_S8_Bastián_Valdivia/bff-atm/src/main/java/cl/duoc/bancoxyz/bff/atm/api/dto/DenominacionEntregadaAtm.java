package cl.duoc.bancoxyz.bff.atm.api.dto;

/**
 * Un tipo de billete y cuantos de ellos entrega la maquina.
 *
 * <p>Los dos nombres estan congelados en la seccion 5.12 del contrato: {@code denominacion} y
 * {@code cantidad}. Son numeros enteros porque son un valor facial y un recuento de objetos
 * fisicos: no existe medio billete, y por eso este es el unico sitio del canal donde una cifra de
 * dinero no es {@code BigDecimal}.
 *
 * @param denominacion valor facial del billete
 * @param cantidad     cuantos billetes de ese valor se entregan
 */
public record DenominacionEntregadaAtm(long denominacion, long cantidad) {
}
