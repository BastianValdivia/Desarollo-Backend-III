package cl.duoc.bancoxyz.bff.atm.aplicacion;

import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.comun.token.LectorClaimsToken;

/**
 * La comprobacion mas importante de este canal: que la cuenta de la ruta sea la cuenta del token.
 *
 * <h2>Por que esto no lo puede hacer la cadena de filtros</h2>
 *
 * <p>Spring Security sabe responder "este token tiene la autoridad {@code PERM_retiro:ejecutar}?".
 * No sabe responder "este token es de la cuenta 116?", porque eso no depende del token solo: es una
 * comparacion entre un claim y un trozo de la URL. La autorizacion por <b>dato</b> (nivel 3 de la
 * seccion 6.4 del contrato) siempre necesita los dos lados, y por eso vive en la capa de aplicacion
 * y no en la configuracion.
 *
 * <p>Sin esta clase, el canal tendria autenticacion y autorizacion impecables y aun asi
 * <b>cualquier portador de un token valido podria consultar y vaciar cuentas ajenas</b>: bastaria
 * con hacer login con la tarjeta propia y cambiar un numero en la URL. Es el fallo mas facil de
 * cometer y el mas caro de todos los que este proyecto puede tener.
 *
 * <h2>Por que se llama antes de hablar con el core, y no despues</h2>
 *
 * <p>Dos consecuencias exigibles, ambas en la seccion 7.4 del contrato:
 *
 * <ol>
 *   <li>Pedir una cuenta <b>ajena e inexistente</b> devuelve 403 {@code cuenta_ajena} y no 404. Si
 *       se consultara primero la existencia, las cuentas que existen darian 403 y las que no
 *       existen darian 404, y comparar las dos respuestas convertiria el canal en un detector de
 *       cuentas para cualquiera con un token valido.</li>
 *   <li>La peticion rechazada por titularidad <b>no genera ni una llamada al core</b>. Muere en el
 *       canal, que ademas es lo correcto en costo.</li>
 * </ol>
 *
 * <h2>Nota para quien pregunto que es un puerto: que es un "claim"</h2>
 *
 * <p>Un token JWT es un texto firmado que contiene un conjunto de afirmaciones sobre quien lo
 * porta. Cada afirmacion es un <i>claim</i>. Aqui se lee el claim propio {@code cuentaId}, que el
 * login copio desde la tarjeta. Se puede confiar en el porque la firma ya fue verificada antes de
 * llegar a este metodo: si alguien editara el numero, la firma dejaria de validar y la peticion
 * nunca habria llegado hasta aqui.
 */
@Component
public class GuardiaTitularidad {

    /**
     * Deja pasar si el token acredita la cuenta pedida, y lanza 403 {@code cuenta_ajena} si no.
     *
     * @param token          token ya validado por el resource server
     * @param cuentaDeLaRuta valor de {@code {cuentaId}} en la URL
     * @throws ReglaAtmException siempre que no coincidan, incluido el caso de un token sin el claim
     */
    public void exigirTitularidad(Jwt token, int cuentaDeLaRuta) {
        Integer cuentaDelToken = token == null ? null : LectorClaimsToken.cuentaId(token);

        /*
         * El token sin claim cuentaId se trata como cuenta ajena y no como error del servidor. Es la
         * eleccion conservadora: un token asi no acredita titularidad sobre NINGUNA cuenta, que es
         * exactamente lo que significa cuenta_ajena. Devolver 500 seria ademas decirle a quien
         * sondea que encontro un camino que el servicio no esperaba.
         */
        if (cuentaDelToken == null || cuentaDelToken != cuentaDeLaRuta) {
            throw ReglaAtmException.cuentaAjena(cuentaDelToken, cuentaDeLaRuta);
        }
    }
}
