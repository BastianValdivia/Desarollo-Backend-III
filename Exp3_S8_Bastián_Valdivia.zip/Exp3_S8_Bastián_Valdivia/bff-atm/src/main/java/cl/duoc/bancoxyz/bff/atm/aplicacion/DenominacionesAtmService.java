package cl.duoc.bancoxyz.bff.atm.aplicacion;

import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.bff.atm.api.dto.DenominacionesAtmResponse;
import cl.duoc.bancoxyz.bff.atm.config.AtmProperties;

/**
 * Capa de aplicacion del endpoint A4: publica los billetes que esta maquina entrega.
 *
 * <h2>Por que existe un servicio para algo tan corto</h2>
 *
 * <p>La pregunta es legitima: el metodo copia dos valores de configuracion a un record. Tres razones
 * para que no viva dentro del controlador:
 *
 * <ol>
 *   <li><b>Simetria con el otro endpoint.</b> Los dos recursos del canal se sirven de la misma
 *       manera: el controlador recibe y responde, la capa de aplicacion decide que se devuelve. Un
 *       canal en el que cada endpoint se organiza distinto obliga a leer el codigo completo antes de
 *       poder cambiar nada.</li>
 *   <li><b>El controlador no debe conocer la configuracion.</b> Hoy la respuesta sale del YAML;
 *       manana podria salir del inventario real de la maquina. Ese cambio debe tocar esta clase y
 *       ninguna otra.</li>
 *   <li><b>Aqui es donde ira la cache.</b> Las denominaciones si se cachean, a diferencia del saldo:
 *       son un dato de configuracion que no cambia entre peticiones. Y una anotacion de cache solo
 *       funciona cuando la llamada cruza la frontera de un bean, porque Spring la intercepta con un
 *       proxy. Tener ya el bean separado deja esa puerta abierta por diseno y no por suerte.</li>
 * </ol>
 */
@Service
public class DenominacionesAtmService {

    private final AtmProperties propiedades;

    public DenominacionesAtmService(AtmProperties propiedades) {
        this.propiedades = propiedades;
    }

    /**
     * Devuelve la moneda y la lista de billetes configurada para esta maquina.
     *
     * <p>No hay ninguna llamada de red: el core es dueno del dinero, no de los billetes. Este es el
     * caso extremo y util de lo que aporta un BFF, porque responde un recurso que aguas arriba
     * sencillamente no existe.
     */
    public DenominacionesAtmResponse consultarDenominaciones() {
        return new DenominacionesAtmResponse(propiedades.moneda(), propiedades.denominaciones());
    }
}
