package cl.duoc.bancoxyz.bff.atm.api;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.bancoxyz.bff.atm.aplicacion.DenominacionesAtmService;
import cl.duoc.bancoxyz.bff.atm.api.dto.DenominacionesAtmResponse;

/**
 * Controlador de A4, {@code GET /v1/denominaciones}: los billetes que entrega esta maquina.
 *
 * <h2>Por que este endpoint es importante para el proyecto completo</h2>
 *
 * <p>Es uno de los cuatro <b>endpoints exclusivos</b> del sistema, y la prueba mas directa de que
 * los tres BFF no son intercambiables. La misma ruta contra {@code bff-web} (8443) o
 * {@code bff-mobile} (8444) devuelve 404, y no por falta de tiempo: un navegador y un telefono no
 * entregan billetes, de modo que el recurso no tiene ningun sentido en esos canales. Un BFF no es
 * un proxy con un nombre distinto; expone el conjunto de recursos que su cliente necesita, que es
 * distinto en cada canal.
 *
 * <p>La evidencia que hay que producir de esto es doble: el 404 en los otros dos puertos <b>y</b> el
 * 200 aqui. Solo el 404 probaria que la ruta no existe en ningun lado.
 *
 * <h2>Por que es una clase aparte de {@link CuentaAtmController}</h2>
 *
 * <p>Porque es otro recurso. {@code /v1/cuentas/{id}/...} habla de una cuenta concreta y necesita al
 * core; {@code /v1/denominaciones} habla de la maquina y no sale a la red. Separar por recurso, y no
 * por canal, es lo que permite mirar el arbol de archivos y saber que expone el canal sin abrir
 * ninguno.
 */
@RestController
public class DenominacionesAtmController {

    private final DenominacionesAtmService denominaciones;

    public DenominacionesAtmController(DenominacionesAtmService denominaciones) {
        this.denominaciones = denominaciones;
    }

    /**
     * Devuelve {@code {moneda, denominaciones}} segun la seccion 5.13 del contrato.
     *
     * <p>Los valores salen de {@code atm.denominaciones} en {@code config-repo/bff-atm.yml}, nunca de una
     * constante en el codigo: cargar otros billetes en la maquina debe ser editar una linea de
     * configuracion, no recompilar el canal.
     */
    @GetMapping(path = "/v1/denominaciones", produces = MediaType.APPLICATION_JSON_VALUE)
    public DenominacionesAtmResponse consultarDenominaciones() {
        return denominaciones.consultarDenominaciones();
    }
}
