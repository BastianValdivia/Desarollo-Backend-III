package cl.duoc.bancoxyz.bff.atm.api.dto;

import java.math.BigDecimal;

/**
 * Cuerpo de la peticion de retiro: un unico campo.
 *
 * <h2>Por que la clave de idempotencia NO esta aqui dentro</h2>
 *
 * <p>Porque identifica al <b>intento</b>, no a la operacion. Dos peticiones con la misma cuenta y
 * el mismo monto son dos operaciones distintas si el usuario quiso sacar dinero dos veces, y una
 * sola si lo que hubo fue un reintento tras un timeout. Solo el cliente sabe en cual de los dos
 * casos esta, y por eso el dato viaja en la cabecera {@code Idempotency-Key}, que es donde la
 * industria lo pone y donde el contrato lo congela.
 *
 * <h2>Por que BigDecimal y no double</h2>
 *
 * <p>{@code double} representa los numeros en base dos, y muchas cifras decimales corrientes no
 * tienen representacion exacta en base dos, igual que un tercio no la tiene en base diez. El
 * resultado clasico es que una suma de importes termina en 0,999999999 o en 10000,000000001. En un
 * sistema que mueve dinero eso no es un detalle de precision: es un descuadre. {@code BigDecimal}
 * guarda los digitos y la escala tal cual, y por eso la seccion 5.1 del contrato lo congela para
 * todos los importes del proyecto.
 *
 * @param monto cantidad que el usuario pidio, en la moneda del canal
 */
public record SolicitudRetiroAtm(BigDecimal monto) {
}
