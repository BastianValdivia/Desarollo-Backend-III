package cl.duoc.bancoxyz.bff.atm.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Los terminales de cajero que este canal reconoce, leidos bajo el prefijo {@code atm.acceso}.
 *
 * <h2>Que cambio con F5</h2>
 *
 * <p>Hasta F4 esta clase guardaba tambien el padron de tarjetas (con el hash de cada PIN) y el canal comprobaba
 * el PIN, llevaba la cuenta de intentos y emitia el token. Desde F5 todo eso es del {@code auth-server}: las
 * tarjetas, los PIN y la politica de bloqueo viven alli (decision D2), y el cajero se autentica con el grant de
 * extension {@code tarjeta-pin} en su cliente {@code atm-scl-001}. Aqui queda lo unico que sigue siendo de este
 * canal: <b>la regla del cajero</b>.
 *
 * <h2>La regla del cajero: el token debe venir de un terminal registrado</h2>
 *
 * <p>El auth-server escribe en el token el claim {@code terminal} (por ejemplo {@code ATM-SCL-001}) y solo emite
 * tokens de cajero a un terminal registrado, con su secreto. Este canal agrega su propia comprobacion, de defensa
 * en profundidad: un token cuyo {@code terminal} no figure en esta lista (o que no lo traiga) se rechaza con 401
 * {@code terminal_no_registrado}, aunque la firma, el emisor, la audiencia y la vigencia sean validas. Si algun
 * dia se registra un cajero nuevo en el auth-server y se olvida darlo de alta aqui, no opera: falla cerrado.
 *
 * <p>La comparacion es exacta, sin normalizar mayusculas ni espacios: {@code atm-scl-001} y {@code ATM-SCL-001} son
 * dos valores distintos, y un token con el primero no se acepta.
 *
 * @param terminalesAutorizados identificadores de terminal aceptados en el claim {@code terminal} del token
 */
@ConfigurationProperties(prefix = "atm.acceso")
public record AccesoAtmProperties(List<String> terminalesAutorizados) {

    /**
     * Comprueba al arrancar que haya al menos un terminal. Una lista vacia no significa "todos permitidos":
     * significa que ningun cajero podria operar, y es preferible decirlo al arrancar que descubrirlo con el
     * primer 401.
     */
    public AccesoAtmProperties {
        if (terminalesAutorizados == null || terminalesAutorizados.isEmpty()) {
            throw new IllegalStateException(
                    "Falta atm.acceso.terminales-autorizados. Una lista vacia no significa 'todos permitidos': "
                            + "significa que ningun cajero podria operar, y es preferible decirlo al arrancar.");
        }
        terminalesAutorizados = List.copyOf(terminalesAutorizados);
    }

    /** {@code true} si ese identificador figura exactamente en la lista. */
    public boolean terminalAutorizado(String terminalId) {
        return terminalId != null && terminalesAutorizados.contains(terminalId);
    }
}
