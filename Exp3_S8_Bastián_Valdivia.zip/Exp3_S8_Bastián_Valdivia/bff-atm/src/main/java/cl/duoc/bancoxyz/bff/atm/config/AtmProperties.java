package cl.duoc.bancoxyz.bff.atm.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Parametros de negocio del canal cajero, leidos de {@code config-repo/bff-atm.yml} bajo el prefijo
 * {@code atm}.
 *
 * <h2>Que es esto, para quien recien pregunto que es un puerto</h2>
 *
 * <p>Una clase {@code @ConfigurationProperties} es el puente tipado entre el archivo de
 * configuracion y el codigo Java. Spring lee las claves {@code atm.*} del YAML, las convierte a los
 * tipos declarados aqui y entrega este objeto ya armado a quien lo pida. No hay que leer el archivo
 * a mano en ninguna parte.
 *
 * <h2>Por que las denominaciones viven en configuracion y no como constante en el codigo</h2>
 *
 * <p>Porque son una decision de operacion, no una regla del lenguaje. Un cajero de otra sucursal
 * puede cargar otros billetes, y el dia que el banco retire el billete de 2.000 de circulacion, la
 * respuesta correcta es editar una linea del YAML y reiniciar, no recompilar y volver a desplegar.
 * La seccion 7.3 del contrato lo exige de forma explicita para <b>todos</b> los parametros del
 * cajero: {@code atm.denominaciones}, y mas adelante las reglas del retiro.
 *
 * <h2>Por que valida en el constructor y por que eso es fallar temprano</h2>
 *
 * <p>Un record de Java admite un "constructor compacto" que se ejecuta antes de asignar los campos.
 * Si la configuracion esta mal, lanzar aqui hace que la aplicacion <b>no arranque</b>, con un
 * mensaje que nombra la propiedad culpable. La alternativa (aceptar cualquier cosa y descubrirlo
 * despues) significa un cajero levantado en la via publica que responde una lista de billetes vacia
 * a la primera consulta real. Entre un fallo ruidoso al arrancar y uno silencioso en produccion, la
 * eleccion no es discutible.
 *
 * <h2>Por que no hay aqui ningun parametro del retiro</h2>
 *
 * <p>Porque el retiro (A3 del contrato) no existe todavia en este canal: necesita la autorizacion
 * por canal, que es de la fase siguiente. Declarar ya {@code atm.retiro.multiplo} y sus hermanos
 * dejaria en el codigo propiedades que nadie lee, que es la forma mas comun de que la configuracion
 * y el comportamiento real se separen sin que nadie lo note.
 *
 * @param moneda         literal congelado {@code CLP} (seccion 5.1 del contrato). Se lee de
 *                       configuracion y no se escribe a mano en cada DTO para que exista un unico
 *                       lugar donde cambiarlo si algun dia el canal opera en otra plaza
 * @param denominaciones billetes que la maquina entrega, en orden ascendente
 */
@ConfigurationProperties(prefix = "atm")
public record AtmProperties(
        String moneda,
        List<Integer> denominaciones) {

    /**
     * Comprueba que la configuracion tenga sentido antes de que el canal acepte una sola peticion.
     *
     * <p>Las tres reglas que exige y el motivo de cada una:
     * <ol>
     *   <li><b>Que existan.</b> Si falta el bloque {@code atm} en el YAML, Spring inyectaria
     *       {@code null} y el primer sintoma seria un {@code NullPointerException} en una peticion
     *       de usuario, muy lejos de la causa.</li>
     *   <li><b>Que sean positivas.</b> Un billete de cero o negativo no significa nada y, cuando
     *       llegue el desglose del retiro, un cero produciria una division por cero o un bucle
     *       infinito segun como se escriba el algoritmo.</li>
     *   <li><b>Que esten en orden ascendente estricto.</b> Esto no es cosmetica. El desglose de un
     *       retiro se calcula recorriendo los billetes de mayor a menor; si la lista llega
     *       desordenada o con repetidos, el algoritmo entrega mas billetes de los necesarios sin
     *       fallar nunca. Exigir el orden aqui convierte un error de datos silencioso en un error
     *       de arranque visible.</li>
     * </ol>
     */
    public AtmProperties {
        if (moneda == null || moneda.isBlank()) {
            throw new IllegalStateException(
                    "Falta la propiedad atm.moneda (literal CLP segun la seccion 5.1 del contrato).");
        }
        if (denominaciones == null || denominaciones.isEmpty()) {
            throw new IllegalStateException(
                    "Falta la propiedad atm.denominaciones: un cajero sin billetes configurados no "
                            + "puede declarar que entrega. Valor esperado: [1000, 2000, 5000, 10000].");
        }
        for (int i = 0; i < denominaciones.size(); i++) {
            Integer valor = denominaciones.get(i);
            if (valor == null || valor <= 0) {
                throw new IllegalStateException(
                        "atm.denominaciones contiene un valor no positivo en la posicion " + i
                                + ": un billete debe valer mas que cero.");
            }
            if (i > 0 && valor <= denominaciones.get(i - 1)) {
                throw new IllegalStateException(
                        "atm.denominaciones debe venir en orden ascendente estricto y sin repetidos. "
                                + "Valor " + valor + " en la posicion " + i + " rompe el orden.");
            }
        }

        // Copia inmutable. Sin ella, cualquier bean que reciba estas propiedades podria ordenar o
        // vaciar la lista original y el cambio se veria en todos los demas, porque todos comparten
        // el mismo objeto. Es una fuga de estado compartido que no deja rastro en el log.
        denominaciones = List.copyOf(denominaciones);
    }
}
