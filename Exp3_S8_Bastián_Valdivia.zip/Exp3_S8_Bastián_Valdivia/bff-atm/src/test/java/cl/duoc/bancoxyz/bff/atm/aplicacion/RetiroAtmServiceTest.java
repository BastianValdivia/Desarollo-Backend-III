package cl.duoc.bancoxyz.bff.atm.aplicacion;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.bff.atm.api.dto.RetiroAtmResponse;
import cl.duoc.bancoxyz.bff.atm.config.AtmProperties;
import cl.duoc.bancoxyz.bff.atm.config.ReglasRetiroProperties;
import cl.duoc.bancoxyz.bff.atm.soporte.TokensDePrueba;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.ConsultaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaTransaccionesCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto;

/**
 * Pruebas de la operacion critica, sin Spring y sin red.
 *
 * <h2>Que se verifica aqui y que no</h2>
 *
 * <p>Aqui se verifican las reglas que son del <b>canal</b>: el orden de validacion del monto, que la
 * titularidad se compruebe antes de tocar el core, que la clave de idempotencia se reenvie tal cual
 * y que el desglose acompane a la respuesta. No se verifica que el retiro sea atomico ni que no se
 * duplique: eso es del core, ya esta probado alli y duplicarlo aqui daria una falsa sensacion de
 * cobertura sobre codigo que este modulo no contiene.
 */
class RetiroAtmServiceTest {

    private static final ReglasRetiroProperties REGLAS = new ReglasRetiroProperties(
            new BigDecimal("1000"), new BigDecimal("1000"), new BigDecimal("10000"));

    private static final AtmProperties ATM = new AtmProperties("CLP", List.of(1000, 2000, 5000, 10000));

    @Test
    @DisplayName("Camino feliz: delega en el core y agrega el desglose")
    void caminoFeliz() {
        CoreClientEspia core = new CoreClientEspia();
        RetiroAtmResponse respuesta = servicio(core).retirar(
                116, new BigDecimal("3000"), "clave-42", TokensDePrueba.jwtDe(116));

        assertEquals("RET-DEMO-1", respuesta.folio());
        assertEquals(new BigDecimal("9000.00"), respuesta.saldoPosterior());

        // Los cuatro primeros campos vienen del core; el quinto lo agrega este canal, porque el core
        // no sabe que al otro lado hay una gaveta con billetes.
        assertEquals(2, respuesta.desglose().size());
        assertEquals(2000, respuesta.desglose().get(0).denominacion());
    }

    @Test
    @DisplayName("La clave de idempotencia se reenvia TAL CUAL, sin guardarla ni modificarla")
    void reenviaLaClaveDeIdempotencia() {
        CoreClientEspia core = new CoreClientEspia();
        servicio(core).retirar(116, new BigDecimal("3000"), "clave-del-terminal",
                TokensDePrueba.jwtDe(116));

        // Si el canal la transformara, un reintento del terminal con la misma clave llegaria al core
        // como una clave distinta y el retiro se ejecutaria dos veces.
        assertEquals("clave-del-terminal", core.clavesRecibidas.get(0));
    }

    @Test
    @DisplayName("Una clave de 200 caracteres pasa intacta; una de 201 se reemplaza por su resumen, igual en cada reintento")
    void laClaveLargaSeResumeSinPerderIdempotencia() {
        CoreClientEspia core = new CoreClientEspia();
        RetiroAtmService servicio = servicio(core);
        String justa = "k".repeat(200);
        String larga = "k".repeat(201);
        String otraLarga = "k".repeat(200) + "x";

        servicio.retirar(116, new BigDecimal("1000"), justa, TokensDePrueba.jwtDe(116));
        servicio.retirar(116, new BigDecimal("1000"), larga, TokensDePrueba.jwtDe(116));
        servicio.retirar(116, new BigDecimal("1000"), larga, TokensDePrueba.jwtDe(116));
        servicio.retirar(116, new BigDecimal("1000"), otraLarga, TokensDePrueba.jwtDe(116));

        assertEquals(justa, core.clavesRecibidas.get(0), "hasta el largo maximo, tal cual");
        assertTrue(core.clavesRecibidas.get(1).startsWith("sha256-"));
        assertEquals(7 + 64, core.clavesRecibidas.get(1).length(), "sha256- mas 64 caracteres hexadecimales");
        assertEquals(core.clavesRecibidas.get(1), core.clavesRecibidas.get(2),
                "el mismo reintento produce la misma clave: sigue siendo idempotente");
        assertTrue(!core.clavesRecibidas.get(1).equals(core.clavesRecibidas.get(3)),
                "dos claves largas distintas no colisionan (un recorte las confundiria)");
    }

    @Test
    @DisplayName("Sin cabecera de idempotencia se manda una clave nueva, nunca una derivada del monto")
    void sinClaveInventaUnaIrrepetible() {
        CoreClientEspia core = new CoreClientEspia();
        RetiroAtmService servicio = servicio(core);

        servicio.retirar(116, new BigDecimal("2000"), null, TokensDePrueba.jwtDe(116));
        servicio.retirar(116, new BigDecimal("2000"), "   ", TokensDePrueba.jwtDe(116));

        /*
         * Dos retiros identicos y seguidos tienen que llegar al core como DOS intentos distintos. Una
         * clave derivada de la cuenta y el monto los fusionaria en uno, y el cliente se iria con la
         * mitad de su dinero creyendo que saco el doble.
         */
        assertNotNull(core.clavesRecibidas.get(0));
        assertTrue(core.clavesRecibidas.get(0).startsWith("sin-clave-"));
        assertEquals(2, core.clavesRecibidas.stream().distinct().count(),
                "dos intentos sin clave no pueden compartir la misma");
    }

    @Test
    @DisplayName("La titularidad se comprueba ANTES de llamar al core")
    void laTitularidadCortaAntesDelCore() {
        CoreClientEspia core = new CoreClientEspia();

        ReglaAtmException fallo = assertThrows(ReglaAtmException.class,
                () -> servicio(core).retirar(105, new BigDecimal("3000"), "clave-42",
                        TokensDePrueba.jwtDe(116)));

        assertEquals("cuenta_ajena", fallo.motivo());
        assertEquals(403, fallo.estado().value());
        assertTrue(core.clavesRecibidas.isEmpty(), "la peticion tenia que morir en el canal");
    }

    @Test
    @DisplayName("El orden de validacion del monto esta congelado: multiplo, luego minimo y tope")
    void ordenDeValidacionCongelado() {
        CoreClientEspia core = new CoreClientEspia();
        RetiroAtmService servicio = servicio(core);

        // 1.500 falla SOLO por multiplo.
        assertEquals("monto_no_multiplo", motivoDe(servicio, core, new BigDecimal("1500")));

        /*
         * 500 viola DOS reglas: no es multiplo de 1.000 y esta bajo el minimo de 1.000. El contrato
         * congela que se responda por la PRIMERA. Si esta linea dijera monto_bajo_minimo, la
         * evidencia del canal dejaria de probar lo que dice probar, y el operador del cajero
         * recibiria el consejo equivocado: le diriamos que teclee mas, cuando lo que tiene que hacer
         * es teclear una cifra redonda.
         */
        assertEquals("monto_no_multiplo", motivoDe(servicio, core, new BigDecimal("500")));

        // Cero es multiplo de mil, asi que pasa la primera y cae en la segunda.
        assertEquals("monto_bajo_minimo", motivoDe(servicio, core, BigDecimal.ZERO));
        assertEquals("supera_tope_transaccion", motivoDe(servicio, core, new BigDecimal("11000")));

        // Un monto negativo es multiplo de 1.000 y cae, correctamente, en el minimo.
        assertEquals("monto_bajo_minimo", motivoDe(servicio, core, new BigDecimal("-2000")));

        assertTrue(core.clavesRecibidas.isEmpty(),
                "las reglas del canal se resuelven en el canal, sin molestar al core");
    }

    @Test
    @DisplayName("Un cuerpo sin monto no es un 400: es monto_bajo_minimo")
    void montoAusente() {
        CoreClientEspia core = new CoreClientEspia();

        // Este canal no emite 400 peticion_invalida (seccion 7.1 del contrato) y su tabla de
        // pantallas no tiene fila para ese motivo.
        assertEquals("monto_bajo_minimo", motivoDe(servicio(core), core, null));
    }

    @Test
    @DisplayName("El tope es POR TRANSACCION: el monto justo en el limite si pasa")
    void elTopeEsInclusivo() {
        CoreClientEspia core = new CoreClientEspia();

        // 10.000 es el tope, no el primer valor prohibido. Un "mayor o igual" en esa comparacion
        // dejaria inalcanzable el maximo publicado, que es de los errores mas dificiles de ver
        // leyendo el codigo.
        RetiroAtmResponse respuesta = servicio(core).retirar(
                116, new BigDecimal("10000"), "clave-42", TokensDePrueba.jwtDe(116));

        assertNotNull(respuesta.folio());
    }

    private String motivoDe(RetiroAtmService servicio, CoreClientEspia core, BigDecimal monto) {
        return assertThrows(ReglaAtmException.class,
                () -> servicio.retirar(116, monto, "clave-42", TokensDePrueba.jwtDe(116))).motivo();
    }

    private RetiroAtmService servicio(CoreClient core) {
        return new RetiroAtmService(core, new GuardiaTitularidad(), REGLAS, ATM);
    }

    /**
     * Doble del core que anota las claves de idempotencia que recibe.
     *
     * <p>Se escribe a mano en lugar de usar un simulador automatico por la misma razon que en el
     * resto del modulo: los metodos que este canal NO debe llamar lanzan una excepcion con un
     * mensaje que explica por que, y asi una llamada indebida falla con un motivo legible en vez de
     * devolver un nulo silencioso.
     */
    private static final class CoreClientEspia implements CoreClient {

        private final List<String> clavesRecibidas = new ArrayList<>();

        @Override
        public RetiroCoreDto ejecutarRetiro(int cuentaId, SolicitudRetiroCoreDto solicitud,
                                            String claveIdempotencia) {
            clavesRecibidas.add(claveIdempotencia);
            return new RetiroCoreDto("RET-DEMO-1", new BigDecimal("12000.00"),
                    solicitud.monto().setScale(2), new BigDecimal("9000.00"));
        }

        @Override
        public SaldoCoreDto obtenerSaldo(int cuentaId) {
            throw new UnsupportedOperationException("El retiro no consulta el saldo: lo decide el core");
        }

        @Override
        public CuentaCoreDto obtenerCuenta(int cuentaId) {
            throw new UnsupportedOperationException("El cajero no pide la cuenta completa");
        }

        @Override
        public PaginaMovimientosCoreDto obtenerMovimientos(int cuentaId, ConsultaMovimientosCoreDto consulta) {
            throw new UnsupportedOperationException("El cajero no muestra movimientos");
        }

        @Override
        public ReporteCalidadCoreDto obtenerCalidadDatos() {
            throw new UnsupportedOperationException("La auditoria es del canal web");
        }

        @Override
        public PaginaTransaccionesCoreDto obtenerTransaccionesNoConciliadas(int pagina, int tamano) {
            throw new UnsupportedOperationException("La auditoria es del canal web");
        }
    }
}
