package cl.duoc.bancoxyz.bff.atm.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Pruebas de las tres clases de configuracion que aparecen con la seguridad.
 *
 * <h2>Por que una prueba sobre configuracion, si "solo" lee un archivo</h2>
 *
 * <p>Porque estas clases no se limitan a leer: <b>deciden que el canal no arranque</b> cuando la
 * configuracion no tiene sentido. Y ese es el unico momento barato de descubrirlo. Un cajero que
 * arranca con un minimo imposible de alcanzar responde 422 a todo retiro con un cuerpo impecable, y
 * quien diagnostique ira a mirar el codigo de la validacion, que esta perfecto, en lugar de una
 * linea del YAML.
 *
 * <p>La regla general que ilustran: <b>fallar al arrancar es infinitamente mejor que degradarse en
 * silencio</b>, y en un canal de via publica la diferencia se mide en dinero.
 */
class ConfiguracionSeguridadAtmTest {

    @Test
    @DisplayName("Acepta las reglas de retiro congeladas del contrato")
    void aceptaLasReglasDelContrato() {
        ReglasRetiroProperties reglas = new ReglasRetiroProperties(
                new BigDecimal("1000"), new BigDecimal("1000"), new BigDecimal("10000"));

        assertEquals(new BigDecimal("10000"), reglas.topeTransaccion());
    }

    @Test
    @DisplayName("Rechaza una configuracion de retiro que ningun monto podria satisfacer")
    void rechazaReglasImposibles() {
        // Minimo que no es multiplo del multiplo: no existe monto que pase las dos primeras reglas.
        assertThrows(IllegalStateException.class, () -> new ReglasRetiroProperties(
                new BigDecimal("1000"), new BigDecimal("1500"), new BigDecimal("10000")));

        // Tope por debajo del minimo: la ventana de montos validos es vacia.
        assertThrows(IllegalStateException.class, () -> new ReglasRetiroProperties(
                new BigDecimal("1000"), new BigDecimal("10000"), new BigDecimal("5000")));

        assertThrows(IllegalStateException.class, () -> new ReglasRetiroProperties(
                null, new BigDecimal("1000"), new BigDecimal("10000")));
    }

    @Test
    @DisplayName("Rechaza una lista blanca de terminales vacia o ausente")
    void rechazaListaBlancaVacia() {
        assertThrows(IllegalStateException.class, () -> new AccesoAtmProperties(List.of()));
        assertThrows(IllegalStateException.class, () -> new AccesoAtmProperties(null));
    }

    @Test
    @DisplayName("El terminal se compara exacto, sin normalizar mayusculas ni espacios")
    void elTerminalSeComparaExacto() {
        AccesoAtmProperties acceso = new AccesoAtmProperties(List.of("ATM-SCL-001"));
        assertTrue(acceso.terminalAutorizado("ATM-SCL-001"));
        assertFalse(acceso.terminalAutorizado("atm-scl-001"));
        assertFalse(acceso.terminalAutorizado(" ATM-SCL-001"));
        assertFalse(acceso.terminalAutorizado(null));
    }
}
