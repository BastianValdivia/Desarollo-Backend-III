package cl.duoc.bancoxyz.bff.atm.resiliencia;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.CoreClientProperties;
import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.core.RestCoreClient;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.CoreClientResiliente;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.RetryRegistry;

/**
 * La resiliencia del cajero de punta a punta: decorador real, configuracion real de {@code config-repo/}, y
 * solo el adaptador HTTP simulado. La regla de este canal es una sola: <b>falla cerrado</b>. Con el core
 * caido, lento o con el circuito abierto responde 503 con su pantalla E-090, y jamas entrega un saldo
 * inventado ni un retiro simulado.
 */
@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("Resiliencia del cajero: falla cerrado")
class ResilienciaAtmTest {

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private CoreClient core;
    @Autowired
    private CoreClientProperties propiedadesDelCliente;
    @Autowired
    private CircuitBreakerRegistry circuitos;
    @Autowired
    private RetryRegistry reintentos;
    @Autowired
    private BulkheadRegistry mamparos;
    @Autowired
    private ApplicationContext contexto;

    @MockBean
    private RestCoreClient http;

    private final EmisorDePrueba emisor = EmisorDePrueba.compartido();

    @BeforeEach
    void limpiar() {
        circuito().reset();
        reset(http);
    }

    private CircuitBreaker circuito() {
        return circuitos.circuitBreaker("core");
    }

    private static CoreNoDisponibleException caida() {
        return new CoreNoDisponibleException("el core no respondio", "/internal/v1/cuentas/116/saldo", null, null, null);
    }

    private String bearer() {
        return "Bearer " + emisor.tarjeta116().emitir();
    }

    private org.springframework.test.web.servlet.ResultActions retirar(String clave) throws Exception {
        var peticion = post("/v1/cuentas/116/retiros")
                .header(HttpHeaders.AUTHORIZATION, bearer())
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"monto\":5000}");
        if (clave != null) {
            peticion = peticion.header("Idempotency-Key", clave);
        }
        return mvc.perform(peticion);
    }

    @Test
    @DisplayName("El cajero usa el decorador, su mamparo es de 5 y NO tiene respaldo de ultimo dato conocido")
    void laConfiguracionDelCajero() {
        assertThat(core).isInstanceOf(CoreClientResiliente.class);
        // Los limites de tiempo son los del cliente HTTP (el TimeLimiter no aplica a llamadas bloqueantes).
        assertThat(propiedadesDelCliente.timeoutConexion().toMillis()).isEqualTo(500);
        assertThat(propiedadesDelCliente.timeoutLectura().toSeconds()).isEqualTo(2);
        assertThat(mamparos.bulkhead("core").getBulkheadConfig().getMaxConcurrentCalls()).isEqualTo(5);
        assertThat(mamparos.bulkhead("core").getBulkheadConfig().getMaxWaitDuration().toMillis()).isZero();
        assertThat(circuito().getCircuitBreakerConfig().getFailureRateThreshold()).isEqualTo(70f);
        assertThat(reintentos.retry("core").getRetryConfig().getMaxAttempts()).isEqualTo(3);
        assertThat(reintentos.retry("auth-server").getRetryConfig().getMaxAttempts()).isEqualTo(2);

        // El respaldo existe como clase en la libreria comun, pero en el cajero el bean no se crea.
        assertThat(contexto.getBeansOfType(RespaldoDeLecturas.class)).isEmpty();
    }

    @Test
    @DisplayName("Saldo con el core caido: 503 E-090 y NINGUN saldo, aunque antes se haya consultado")
    void elSaldoFallaCerrado() throws Exception {
        when(http.obtenerSaldo(116)).thenReturn(new SaldoCoreDto(116, new BigDecimal("12000.00"), "CLP"));
        mvc.perform(get("/v1/cuentas/116/saldo-disponible").header(HttpHeaders.AUTHORIZATION, bearer()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.saldoDisponible").value(12000.00));

        when(http.obtenerSaldo(116)).thenThrow(caida());

        mvc.perform(get("/v1/cuentas/116/saldo-disponible").header(HttpHeaders.AUTHORIZATION, bearer()))
                .andExpect(status().isServiceUnavailable())
                .andExpect(header().doesNotExist("X-Datos-Desactualizados"))
                .andExpect(jsonPath("$.motivo").value("core_no_disponible"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-090"))
                .andExpect(jsonPath("$.canal").value("ATM"))
                .andExpect(jsonPath("$.saldoDisponible").doesNotExist());
    }

    @Test
    @DisplayName("Retiro con el core caido: 503 E-090, sin folio ni saldo, y el mismo Idempotency-Key en cada reintento")
    void elRetiroFallaCerradoYSeReintentaConLaMismaClave() throws Exception {
        when(http.ejecutarRetiro(anyInt(), any(), anyString())).thenThrow(caida());

        retirar("clave-del-terminal-1")
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.motivo").value("core_no_disponible"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-090"))
                .andExpect(jsonPath("$.folio").doesNotExist())
                .andExpect(jsonPath("$.saldoPosterior").doesNotExist())
                .andExpect(jsonPath("$.denominaciones").doesNotExist());

        // El retiro es reintentable SOLO porque viaja con su clave: 3 intentos, todos con la misma.
        verify(http, times(3)).ejecutarRetiro(anyInt(), any(), org.mockito.ArgumentMatchers.eq("clave-del-terminal-1"));
    }

    @Test
    @DisplayName("Un reintento que llega a un core recuperado devuelve el comprobante: el retiro se hizo una sola vez")
    void unReintentoTrasUnaCaidaPasajeraEntregaElComprobante() throws Exception {
        when(http.ejecutarRetiro(anyInt(), any(), anyString()))
                .thenThrow(caida())
                .thenReturn(new RetiroCoreDto("FOLIO-7", new BigDecimal("12000.00"),
                        new BigDecimal("5000.00"), new BigDecimal("7000.00")));

        retirar("clave-2")
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.folio").value("FOLIO-7"))
                .andExpect(jsonPath("$.saldoPosterior").value(7000.00));

        verify(http, times(2)).ejecutarRetiro(anyInt(), any(), org.mockito.ArgumentMatchers.eq("clave-2"));
    }

    @Test
    @DisplayName("Un retiro SIN Idempotency-Key del cliente: el canal le fabrica una clave unica y la usa en todos los intentos")
    void sinClaveDelClienteElCanalFabricaUnaYReintentaConLaMisma() throws Exception {
        when(http.ejecutarRetiro(anyInt(), any(), anyString())).thenThrow(caida());

        retirar(null).andExpect(status().isServiceUnavailable());

        // El servicio le fabrica una clave nueva por peticion, pero la capa de resiliencia
        // reintenta con ESA misma clave: 3 intentos, una clave. Se comprueba que la clave es una sola.
        var claves = org.mockito.ArgumentCaptor.forClass(String.class);
        verify(http, times(3)).ejecutarRetiro(anyInt(), any(), claves.capture());
        assertThat(claves.getAllValues()).hasSize(3).containsOnly(claves.getAllValues().get(0));
    }

    @Test
    @DisplayName("Con el circuito abierto el cajero no llama al core: ni saldo ni retiro, 503 E-090 al instante")
    void conElCircuitoAbiertoNoHayNada() throws Exception {
        when(http.obtenerSaldo(116)).thenThrow(caida());
        for (int i = 0; i < 3 && circuito().getState() != CircuitBreaker.State.OPEN; i++) {
            mvc.perform(get("/v1/cuentas/116/saldo-disponible").header(HttpHeaders.AUTHORIZATION, bearer()))
                    .andExpect(status().isServiceUnavailable());
        }
        assertThat(circuito().getState()).isEqualTo(CircuitBreaker.State.OPEN);

        clearInvocations(http);
        mvc.perform(get("/v1/cuentas/116/saldo-disponible").header(HttpHeaders.AUTHORIZATION, bearer()))
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.codigoPantalla").value("E-090"));
        retirar("clave-3")
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.codigoPantalla").value("E-090"))
                .andExpect(jsonPath("$.folio").doesNotExist());

        verifyNoInteractions(http);
    }

    @Test
    @DisplayName("Treinta 404 seguidos (cuenta inexistente) no abren el circuito del cajero")
    void los404NoAbrenElCircuito() throws Exception {
        when(http.obtenerSaldo(116)).thenThrow(new CoreRecursoNoEncontradoException("404", "/x", "{}"));

        for (int i = 0; i < 30; i++) {
            mvc.perform(get("/v1/cuentas/116/saldo-disponible").header(HttpHeaders.AUTHORIZATION, bearer()))
                    .andExpect(status().isNotFound());
        }

        assertThat(circuito().getState()).isEqualTo(CircuitBreaker.State.CLOSED);
        assertThat(circuito().getMetrics().getNumberOfFailedCalls()).isZero();
        verify(http, never()).ejecutarRetiro(anyInt(), any(), any());
    }
}
