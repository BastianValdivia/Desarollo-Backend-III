package cl.duoc.bancoxyz.bff.atm.soporte;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

import cl.duoc.bancoxyz.bff.atm.aplicacion.ConsultaSaldoAtmService;
import cl.duoc.bancoxyz.bff.atm.aplicacion.DenominacionesAtmService;
import cl.duoc.bancoxyz.bff.atm.aplicacion.GuardiaTitularidad;
import cl.duoc.bancoxyz.bff.atm.aplicacion.RetiroAtmService;
import cl.duoc.bancoxyz.bff.atm.api.ManejadorErroresAtm;
import cl.duoc.bancoxyz.bff.atm.config.AccesoAtmProperties;
import cl.duoc.bancoxyz.bff.atm.config.AtmProperties;
import cl.duoc.bancoxyz.bff.atm.config.ReglasRetiroProperties;
import cl.duoc.bancoxyz.bff.atm.seguridad.ManejadorAccesoDenegadoAtm;
import cl.duoc.bancoxyz.bff.atm.seguridad.PuntoEntradaAtm;
import cl.duoc.bancoxyz.bff.atm.seguridad.SeguridadAtmConfig;
import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;

/**
 * Arma el canal completo para las pruebas de rodaja web: cadena de filtros, servicios y politica.
 *
 * <h2>Que se prueba con esto y por que es la rodaja correcta</h2>
 *
 * <p>Una prueba de unidad puede comprobar que {@code RetiroAtmService} rechaza 1.500 pesos. Lo que
 * <b>no</b> puede comprobar es que la regla de la cadena de filtros exija de verdad
 * {@code PERM_retiro:ejecutar}, ni que un 401 salga con su {@code codigoPantalla}, porque todo eso
 * ocurre en filtros que solo existen dentro de un contexto web. Y son justamente las reglas que
 * fallan en silencio: un {@code requestMatchers} mal escrito no rompe ninguna compilacion y deja una
 * ruta abierta.
 *
 * <p>Por eso las pruebas de seguridad de este modulo importan esta clase: cargan la
 * {@link SeguridadAtmConfig} real, con sus reglas reales y su validador del cajero real, y solo sustituyen
 * el cliente del core (que se simula, porque el core no esta levantado). El decodificador de tokens NO se
 * sustituye: es el de Spring Boot, construido con {@code jwk-set-uri}, {@code issuer-uri} y
 * {@code audiences}, y cada prueba que valida tokens apunta su {@code jwk-set-uri} al JWKS de prueba
 * ({@code EmisorDePrueba.registrar}, desde un {@code @DynamicPropertySource}).
 *
 * <h2>Los valores de configuracion son los congelados del contrato</h2>
 *
 * <p>Los beans de propiedades repiten exactamente lo que dice {@code config-repo/bff-atm.yml}: multiplo
 * 1.000, minimo 1.000, tope 10.000 y el terminal {@code ATM-SCL-001}. Si manana alguien cambiara el
 * tope en el YAML sin cambiarlo aqui, estas pruebas seguirian pasando: comprueban el
 * <b>comportamiento</b> ante una configuracion dada, no que el archivo diga lo que debe decir. Eso
 * ultimo lo comprueba la evidencia con {@code curl}.
 */
@TestConfiguration
@Import({SeguridadAtmConfig.class,
        PuntoEntradaAtm.class,
        ManejadorAccesoDenegadoAtm.class,
        ManejadorErroresAtm.class,
        EscritorErrorHttp.class,
        GuardiaTitularidad.class,
        ConsultaSaldoAtmService.class,
        DenominacionesAtmService.class,
        RetiroAtmService.class})
public class ContextoAtmDePrueba {

    public static final String TERMINAL_AUTORIZADO = "ATM-SCL-001";

    @Bean
    AccesoAtmProperties accesoAtmProperties() {
        return new AccesoAtmProperties(List.of(TERMINAL_AUTORIZADO));
    }

    @Bean
    AtmProperties atmProperties() {
        return new AtmProperties("CLP", List.of(1000, 2000, 5000, 10000));
    }

    @Bean
    ReglasRetiroProperties reglasRetiroProperties() {
        return new ReglasRetiroProperties(
                new BigDecimal("1000"), new BigDecimal("1000"), new BigDecimal("10000"));
    }
}
