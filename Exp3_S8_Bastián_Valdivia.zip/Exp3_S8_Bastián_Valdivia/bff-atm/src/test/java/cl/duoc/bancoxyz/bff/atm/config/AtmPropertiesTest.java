package cl.duoc.bancoxyz.bff.atm.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Pruebas de la validacion de configuracion del canal.
 *
 * <p>Lo que se prueba aqui no es el codigo feliz, sino que la aplicacion se niegue a arrancar con
 * una configuracion sin sentido. Un cajero que parte con una lista de billetes vacia o desordenada
 * es peor que un cajero que no parte: el primero falla en la calle, el segundo falla en el
 * despliegue, delante de quien puede arreglarlo.
 */
class AtmPropertiesTest {

    @Test
    @DisplayName("Acepta la configuracion congelada del contrato")
    void aceptaLaConfiguracionDelContrato() {
        AtmProperties propiedades = new AtmProperties("CLP", List.of(1000, 2000, 5000, 10000));

        assertEquals("CLP", propiedades.moneda());
        assertEquals(List.of(1000, 2000, 5000, 10000), propiedades.denominaciones());
    }

    @Test
    @DisplayName("Rechaza una lista de billetes vacia o ausente")
    void rechazaListaVacia() {
        assertThrows(IllegalStateException.class, () -> new AtmProperties("CLP", List.of()));
        assertThrows(IllegalStateException.class, () -> new AtmProperties("CLP", null));
    }

    @Test
    @DisplayName("Rechaza billetes desordenados, repetidos o no positivos")
    void rechazaOrdenYValoresInvalidos() {
        // Desordenada: el desglose de un retiro recorre la lista de mayor a menor y una lista
        // desordenada entrega mas billetes de los necesarios sin fallar nunca.
        assertThrows(IllegalStateException.class,
                () -> new AtmProperties("CLP", List.of(1000, 10000, 5000)));
        assertThrows(IllegalStateException.class,
                () -> new AtmProperties("CLP", List.of(1000, 1000)));
        assertThrows(IllegalStateException.class,
                () -> new AtmProperties("CLP", List.of(0, 1000)));
    }

    @Test
    @DisplayName("Rechaza la moneda ausente")
    void rechazaMonedaAusente() {
        assertThrows(IllegalStateException.class, () -> new AtmProperties("  ", List.of(1000)));
    }
}
