package cl.duoc.bancoxyz.bff.atm.aplicacion;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.bff.atm.api.dto.DenominacionEntregadaAtm;

/**
 * Pruebas del reparto en billetes, que es el valor que este canal agrega sobre la respuesta del core.
 */
class DesgloseDenominacionesTest {

    private static final List<Integer> BILLETES = List.of(1000, 2000, 5000, 10000);

    @Test
    @DisplayName("Entrega la menor cantidad de billetes, de mayor a menor")
    void repartoCodicioso() {
        List<DenominacionEntregadaAtm> desglose =
                DesgloseDenominaciones.repartir(new BigDecimal("9000.00"), BILLETES);

        // 9.000 son un billete de 5.000, dos de 2.000 y ninguno de 1.000: la entrada de 1.000 no
        // aparece, porque un desglose con "cantidad: 0" seria ruido en la pantalla.
        assertEquals(List.of(
                new DenominacionEntregadaAtm(5000, 1),
                new DenominacionEntregadaAtm(2000, 2)), desglose);
    }

    @Test
    @DisplayName("El desglose siempre suma exactamente el monto retirado")
    void elDesgloseCuadra() {
        // Recorre todos los montos que este canal puede llegar a entregar: de 1.000 a 10.000 de mil
        // en mil. Es barato y cubre el invariante entero en lugar de un caso suelto.
        for (int monto = 1000; monto <= 10000; monto += 1000) {
            List<DenominacionEntregadaAtm> desglose =
                    DesgloseDenominaciones.repartir(BigDecimal.valueOf(monto), BILLETES);

            long suma = desglose.stream()
                    .mapToLong(entrada -> entrada.denominacion() * entrada.cantidad())
                    .sum();

            assertEquals(monto, suma, "el desglose de " + monto + " no cuadra");
            assertTrue(desglose.stream().allMatch(entrada -> entrada.cantidad() > 0),
                    "ninguna entrada puede tener cantidad cero");
        }
    }

    @Test
    @DisplayName("Un monto exacto de un solo billete entrega una sola entrada")
    void montoDeUnSoloBillete() {
        assertEquals(List.of(new DenominacionEntregadaAtm(10000, 1)),
                DesgloseDenominaciones.repartir(new BigDecimal("10000"), BILLETES));
    }

    @Test
    @DisplayName("Con la denominacion mayor retirada de circulacion, el reparto sigue cuadrando")
    void billetesConfigurablesDeVerdad() {
        // Las denominaciones son configuracion, no una constante: el dia que el banco retire el
        // billete de 10.000 basta con editar el YAML. Esta prueba es la que hace que esa frase sea
        // cierta y no una intencion.
        List<DenominacionEntregadaAtm> desglose =
                DesgloseDenominaciones.repartir(new BigDecimal("10000"), List.of(1000, 2000, 5000));

        assertEquals(List.of(new DenominacionEntregadaAtm(5000, 2)), desglose);
    }
}
