package cl.duoc.bancoxyz.bff.atm.soporte;

import java.util.List;

import org.springframework.security.oauth2.jwt.Jwt;

import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;

/**
 * Los tokens del cajero para las pruebas del canal.
 *
 * <p>Desde F5 el canal no emite tokens: el cajero se autentica en el {@code auth-server} con el grant
 * {@code tarjeta-pin}. Las pruebas reproducen lo que ese servidor emite con {@link EmisorDePrueba} (clave de
 * PRUEBA, JWKS por HTTP y los mismos claims: audiencia {@code bff-atm}, {@code canal}, {@code cuentaId},
 * {@code authorities}, {@code terminal} y 3 minutos de vigencia), y el canal los valida con su decodificador
 * REAL, el que construye Spring Boot con {@code jwk-set-uri}, {@code issuer-uri} y {@code audiences}.
 *
 * <p>Esta clase solo ofrece atajos para los dos usos habituales: un token valido con la cuenta y las
 * autoridades que la prueba pida, y un {@link Jwt} ya decodificado para las pruebas de servicios que no pasan
 * por la cadena de filtros.
 */
public final class TokensDePrueba {

    private TokensDePrueba() {
    }

    /**
     * Un token valido del cajero: audiencia {@code bff-atm}, terminal {@code ATM-SCL-001} y 3 minutos.
     *
     * @param cuentaId    cuenta que acredita, o {@code null} para un token SIN claim {@code cuentaId}
     * @param autoridades autoridades del token
     */
    public static String tokenValido(Integer cuentaId, List<String> autoridades) {
        EmisorDePrueba.Token token = EmisorDePrueba.compartido().tarjeta116().claim("authorities", autoridades);
        if (cuentaId == null) {
            token.sin("cuentaId");
        } else {
            token.claim("cuentaId", cuentaId);
        }
        return token.emitir();
    }

    /** Un {@link Jwt} con solo la cuenta, para probar la titularidad en los servicios sin cadena de filtros. */
    public static Jwt jwtDe(Integer cuentaId) {
        return Jwt.withTokenValue("token-de-prueba")
                .header("alg", "RS256")
                .claim("cuentaId", cuentaId)
                .claim("canal", "ATM")
                .build();
    }
}
