package cl.duoc.bancoxyz.bff.atm.api;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import cl.duoc.bancoxyz.bff.atm.soporte.TokensDePrueba;
import cl.duoc.bancoxyz.bff.atm.soporte.ContextoAtmDePrueba;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;
import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;

/**
 * Prueba de rodaja web del endpoint A2: levanta el controlador, el manejador de errores y la
 * serializacion JSON, con el {@link CoreClient} simulado y sin red.
 *
 * <p><b>Que asegura esta prueba y por que importa mas que un test de camino feliz.</b> El valor de
 * este canal esta en la forma exacta de su respuesta: dos campos, ni uno mas, y un cuerpo de error
 * sin {@code detail}. Esas dos afirmaciones son las que el proyecto entero repite, y son
 * exactamente las que se rompen sin que nadie lo note al agregar un campo "temporal" a un DTO. Aqui
 * quedan comprobadas en cada compilacion.
 *
 * <p>Las rutas van sin el prefijo {@code /api/atm}: el {@code context-path} lo aplica el servidor
 * real, y esta prueba no levanta uno.
 */
@WebMvcTest(controllers = CuentaAtmController.class)
@Import(ContextoAtmDePrueba.class)
class CuentaAtmControllerTest {

    /**
     * Autoridades de la tarjeta principal, tal como el login las copia al claim.
     *
     * <p>Desde la fase de seguridad, estas pruebas de forma de respuesta tienen que autenticarse
     * como cualquier otro cliente: la ruta exige {@code PERM_saldo:leer} y la titularidad se
     * comprueba contra el claim {@code cuentaId}. Que una prueba de A2 no pueda escribirse sin token
     * es, en si mismo, la evidencia de que la ruta quedo protegida.
     */
    private static final List<String> AUTORIDADES =
            List.of("ROLE_CLIENTE_ATM", "PERM_saldo:leer", "PERM_retiro:ejecutar");

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CoreClient core;

    @Test
    @DisplayName("A2 responde exactamente dos campos: saldoDisponible y moneda")
    void respondeDosCamposYNadaMas() throws Exception {
        given(core.obtenerSaldo(116)).willReturn(new SaldoCoreDto(116, new BigDecimal("12000.00"), "CLP"));

        mockMvc.perform(get("/v1/cuentas/116/saldo-disponible")
                        .header(HttpHeaders.AUTHORIZATION, bearer(116)))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.saldoDisponible").value(12000.00))
                .andExpect(jsonPath("$.moneda").value("CLP"))
                // Lo que NO viaja es la mitad del contrato de este canal, y por eso se prueba
                // campo por campo: quien mira la pantalla de un cajero esta en la calle.
                .andExpect(jsonPath("$.cuentaId").doesNotExist())
                .andExpect(jsonPath("$.titular").doesNotExist())
                .andExpect(jsonPath("$.tipoCuenta").doesNotExist())
                .andExpect(jsonPath("$.edadTitular").doesNotExist())
                .andExpect(jsonPath("$.movimientos").doesNotExist())
                .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    @DisplayName("Una cuenta inexistente responde 404 recurso_no_encontrado y sin detail")
    void cuentaInexistenteDevuelve404SinDetalle() throws Exception {
        given(core.obtenerSaldo(999)).willThrow(new CoreRecursoNoEncontradoException(
                "no existe", "/internal/v1/cuentas/999/saldo", null));

        mockMvc.perform(get("/v1/cuentas/999/saldo-disponible")
                        .header(HttpHeaders.AUTHORIZATION, bearer(999)))
                .andExpect(status().isNotFound())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("recurso_no_encontrado"))
                .andExpect(jsonPath("$.canal").value("ATM"))
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.type").value("https://bancoxyz.duoc.cl/errores/recurso-no-encontrado"))
                // El cajero nunca envia detail: el campo ni siquiera existe en su record de error.
                .andExpect(jsonPath("$.detail").doesNotExist())
                // Fila E-040 de la seccion 7.2, congelada en la version 1.1.0 del contrato. El
                // texto evita decir "no existe": distinguirlo de "existe y no es tuya" en la
                // pantalla convertiria al cajero en un detector de cuentas para quien pase por ahi.
                .andExpect(jsonPath("$.codigoPantalla").value("E-040"))
                .andExpect(jsonPath("$.mensajePantalla").value("Cuenta no disponible"));
    }

    @Test
    @DisplayName("El core caido se traduce en 503 con el codigo de pantalla E-090")
    void coreCaidoDevuelve503ConCodigoDePantalla() throws Exception {
        given(core.obtenerSaldo(116)).willThrow(new CoreNoDisponibleException(
                "el core no respondio", "/internal/v1/cuentas/116/saldo", null, null, null));

        mockMvc.perform(get("/v1/cuentas/116/saldo-disponible")
                        .header(HttpHeaders.AUTHORIZATION, bearer(116)))
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.motivo").value("core_no_disponible"))
                // Los dos campos que solo existen en este canal, con los literales congelados de
                // la seccion 7.2 del contrato.
                .andExpect(jsonPath("$.codigoPantalla").value("E-090"))
                .andExpect(jsonPath("$.mensajePantalla").value("Servicio no disponible"));
    }

    @Test
    @DisplayName("A2 prohibe guardar copia del saldo: no-store, Pragma y Expires")
    void elSaldoViajaConProhibicionDeGuardarlo() throws Exception {
        given(core.obtenerSaldo(116)).willReturn(new SaldoCoreDto(116, new BigDecimal("12000.00"), "CLP"));

        mockMvc.perform(get("/v1/cuentas/116/saldo-disponible")
                        .header(HttpHeaders.AUTHORIZATION, bearer(116)))
                .andExpect(status().isOk())

                // ESTA ES LA CUARTA CAPA de la regla "el saldo del cajero no sale de una cache".
                // Las otras tres (el pom sin la libreria, el cliente compartido sin anotacion y el
                // servicio sin capa intermedia) impiden que el SERVIDOR guarde una copia. Esta
                // impide que la guarde el TERMINAL, que es el otro extremo del problema y el que
                // menos controlamos, porque es firmware.
                .andExpect(header().string(HttpHeaders.CACHE_CONTROL, "no-store"))

                // Pragma y Expires son los equivalentes de HTTP/1.0 y hay que escribirlos a mano:
                // Spring Security los anade junto a Cache-Control, pero solo si la respuesta no
                // trae ya un Cache-Control propio. Al fijarlo en el controlador se perdian los
                // otros dos en silencio. Se conservan porque el cliente de este canal es el
                // software mas viejo y menos actualizable del sistema.
                .andExpect(header().string("Pragma", "no-cache"))
                .andExpect(header().string("Expires", "0"))

                // Y NO lleva ETag, a diferencia del canal movil. Un ETag habilita el 304, que
                // significa "reutiliza la copia que tienes", que es exactamente lo prohibido aqui.
                .andExpect(header().doesNotExist(HttpHeaders.ETAG));
    }

    /**
     * Token valido de este canal para la cuenta indicada.
     *
     * <p>La cuenta 999 no existe, y aun asi hace falta un token que la acredite: la titularidad se
     * comprueba antes que la existencia, asi que un token de otra cuenta daria 403 y la prueba nunca
     * llegaria a ejercer el 404 que quiere verificar.
     */
    private String bearer(int cuentaId) {
        return "Bearer " + TokensDePrueba.tokenValido(cuentaId, AUTORIDADES);
    }
}
