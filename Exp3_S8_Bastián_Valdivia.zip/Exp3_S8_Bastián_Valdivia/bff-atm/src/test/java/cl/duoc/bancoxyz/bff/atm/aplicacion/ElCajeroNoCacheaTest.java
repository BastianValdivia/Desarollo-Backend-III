package cl.duoc.bancoxyz.bff.atm.aplicacion;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.TypeFilter;
import org.springframework.security.oauth2.jwt.Jwt;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * La regla mas importante del canal del cajero, convertida en prueba automatizada:
 * <strong>el saldo NUNCA sale de una cache</strong>.
 *
 * <h2>Por que una ausencia necesita una prueba</h2>
 *
 * <p>Lo normal es probar lo que el codigo hace. Aqui se prueba lo que el codigo <em>no</em> hace, y
 * la razon es que esta ausencia es la decision de diseno mas cara de revertir por accidente de todo
 * el proyecto.
 *
 * <p>El escenario concreto que hay que impedir: alguien mira el panel de metricas, ve que el canal
 * del cajero es el que mas peticiones le hace al core (porque es el unico sin cache), y "arregla"
 * ese numero agregando una cache de 60 segundos. El panel mejora, ninguna prueba se pone roja, y a
 * partir de ese dia dos retiros hechos dentro del mismo minuto pueden entregar dos veces el saldo
 * total, porque el segundo se autoriza contra un numero que ya no es cierto. El dinero ya salio de
 * la maquina cuando el sistema se entera.
 *
 * <p>Notese que es una decision de <strong>correctitud</strong>, no de rendimiento. El cajero no
 * renuncia a la cache porque la cache sea lenta, sino porque el dato que cachearia caduca en el
 * instante en que otra terminal toca la misma cuenta.
 *
 * <h2>Las cuatro capas que sostienen la regla, y cual comprueba cada prueba de aqui</h2>
 *
 * <ol>
 *   <li><strong>El pom.xml</strong> de este modulo no declara {@code spring-boot-starter-cache}
 *       ni {@code caffeine}, asi que no hay ninguna implementacion de cache con TTL disponible.
 *       Lo comprueba {@link #noHayImplementacionDeCacheEnElClasspath()}.</li>
 *   <li><strong>Ninguna clase del canal lleva una anotacion de cache</strong>, y eso se vigila
 *       explorando el paquete en {@link #ningunaClaseDelCanalLlevaAnotacionDeCache()}.</li>
 *   <li><strong>{@code RestCoreClient}</strong>, en {@code plataforma-comun}, no lleva ninguna
 *       anotacion de cache, para que este canal no herede una que nadie decidio para el.</li>
 *   <li><strong>El comportamiento</strong>: cada consulta viaja al core, y lo comprueba
 *       {@link #cadaConsultaDeSaldoViajaAlCore()}.</li>
 *   <li><strong>La cabecera {@code no-store}</strong> de la respuesta, que prohibe al terminal
 *       guardar copia. Se comprueba en {@code CuentaAtmControllerTest}.</li>
 * </ol>
 */
@DisplayName("El cajero no cachea el saldo, y eso esta garantizado por construccion")
class ElCajeroNoCacheaTest {

    @Test
    @DisplayName("cinco consultas de saldo producen CINCO llamadas al core, no una")
    void cadaConsultaDeSaldoViajaAlCore() {
        CoreClient core = Mockito.mock(CoreClient.class);
        given(core.obtenerSaldo(anyInt()))
                .willReturn(new SaldoCoreDto(116, new BigDecimal("12000.00"), "CLP"));

        ConsultaSaldoAtmService servicio =
                new ConsultaSaldoAtmService(core, new GuardiaTitularidad());

        for (int i = 0; i < 5; i++) {
            servicio.consultarSaldoDisponible(116, tokenDeTarjeta(116L));
        }

        // En los otros dos canales, el numero correcto de esta linea seria 1 y significaria que la
        // cache funciona. AQUI el numero correcto es 5. Si algun dia esta prueba falla diciendo
        // "esperaba 5, fueron 1", NO es una optimizacion que aparecio: es la regla de seguridad
        // del canal que se rompio.
        verify(core, times(5)).obtenerSaldo(116);
    }

    @Test
    @DisplayName("no hay ninguna implementacion de cache con TTL en el classpath")
    void noHayImplementacionDeCacheEnElClasspath() {
        // ESTA PRUEBA NACIO DE UNA CREENCIA FALSA, y la historia vale mas que la prueba.
        //
        // La primera version afirmaba algo mas fuerte: que sin spring-boot-starter-cache en el
        // pom, la anotacion @Cacheable "no se puede ni importar" y el intento no compila. Sonaba
        // redondo. Se escribio la prueba, y FALLO: la anotacion ya estaba disponible.
        //
        // El motivo es que org.springframework.cache.annotation.Cacheable no vive en el starter
        // de cache, sino en spring-context, que lo arrastra spring-boot-starter-web y por tanto
        // lo tiene TODA aplicacion web de Spring. Lo que el starter aporta es la
        // autoconfiguracion; lo que aporta caffeine es la implementacion con expiracion y tope
        // de memoria. La anotacion es gratis y esta siempre.
        //
        // CONSECUENCIA HONESTA: en este modulo SI se puede escribir @Cacheable y SI compila. Lo
        // que no puede es funcionar como uno esperaria, porque sin @EnableCaching la anotacion es
        // inerte y sin caffeine no habria ni TTL ni tope. Pero "inerte" es una proteccion
        // silenciosa, y una proteccion silenciosa no sirve para una regla de la que depende que
        // no se entregue dinero de mas.
        //
        // Por eso la garantia de verdad no es esta prueba sino la siguiente, que explora el
        // paquete y falla si aparece la anotacion. Esta se conserva porque sigue siendo util:
        // vigila que nadie agregue la dependencia al pom "de paso".
        assertThatThrownBy(() -> Class.forName("com.github.benmanes.caffeine.cache.Caffeine"))
                .describedAs("bff-atm NO debe tener caffeine. Si esta prueba falla, alguien "
                        + "agrego la dependencia (tipicamente copiando el pom del canal web): "
                        + "leer el comentario de bff-atm/pom.xml antes de seguir, porque de eso "
                        + "depende que el cajero no entregue billetes contra un saldo viejo")
                .isInstanceOf(ClassNotFoundException.class);
    }

    @Test
    @DisplayName("ninguna clase del canal lleva @Cacheable, @CachePut, @CacheConfig ni @EnableCaching")
    void ningunaClaseDelCanalLlevaAnotacionDeCache() {
        // La garantia REAL, tras descubrir que el pom no la daba.
        //
        // ESTA PRUEBA TAMBIEN SE EQUIVOCO EN SU PRIMERA VERSION, y merece la pena contarlo.
        // Usaba AnnotationTypeFilter, que parecia lo obvio. Se comprobo metiendo a proposito una
        // clase con @Cacheable en este modulo para ver la prueba ponerse roja... y siguio en
        // VERDE. El motivo: AnnotationTypeFilter solo mira las anotaciones puestas sobre la
        // CLASE, y @Cacheable se pone sobre un METODO. La prueba no vigilaba nada.
        //
        // Una prueba que afirma "aqui no hay nada" no vale nada hasta que se la ha visto fallar
        // con algo puesto. Es la unica manera de distinguir "no hay violaciones" de "no estoy
        // mirando donde debo", y las dos se ven identicas en el informe.
        //
        // La version correcta lee los metadatos de cada clase con hasAnnotatedMethods, que si
        // inspecciona los metodos. Se verifico igual que la anterior: con una clase infractora
        // presente, falla; al retirarla, pasa.
        var explorador = new ClassPathScanningCandidateComponentProvider(false);
        explorador.addIncludeFilter(filtroDeCache(Cacheable.class));
        explorador.addIncludeFilter(filtroDeCache(CachePut.class));
        explorador.addIncludeFilter(filtroDeCache(CacheConfig.class));
        explorador.addIncludeFilter(filtroDeCache(EnableCaching.class));

        assertThat(explorador.findCandidateComponents("cl.duoc.bancoxyz.bff.atm"))
                .describedAs("El canal del cajero NO puede cachear. Si esta prueba falla, la clase "
                        + "que aparece aqui introdujo una cache en el unico canal que entrega "
                        + "dinero fisico: un saldo con 60 segundos de antiguedad permite retirar "
                        + "dos veces el saldo total dentro de esa ventana. Ver bff-atm/pom.xml")
                .isEmpty();
    }

    /**
     * Filtro que marca una clase si lleva la anotacion indicada <strong>sobre la clase o sobre
     * cualquiera de sus metodos</strong>.
     *
     * <p>Las dos comprobaciones son necesarias y cubren casos distintos: {@code @EnableCaching} y
     * {@code @CacheConfig} van sobre la clase, mientras que {@code @Cacheable} y {@code @CachePut}
     * van sobre metodos. Un filtro que solo mirara uno de los dos sitios dejaria pasar la mitad de
     * las formas de introducir una cache en este canal.
     *
     * <p>Se leen los metadatos del {@code .class} sin cargarlo en la JVM, que es lo que permite
     * revisar el modulo entero sin instanciar nada.
     */
    private static TypeFilter filtroDeCache(Class<? extends java.lang.annotation.Annotation> anotacion) {
        String nombre = anotacion.getName();
        return (lector, fabrica) ->
                lector.getAnnotationMetadata().hasAnnotation(nombre)
                        || lector.getAnnotationMetadata().hasAnnotatedMethods(nombre);
    }

    @Test
    @DisplayName("el servicio de saldo depende del CoreClient directo, sin nada en medio")
    void noHayNingunaCapaDeCacheEntreElServicioYElCore() {
        // Comprobacion estructural: el unico constructor del servicio recibe el puerto hacia el
        // core y el guardia, y nada mas. Si alguien interpusiera una clase intermedia (que es
        // exactamente como se introduciria una cache en este canal, imitando a CacheCuentaWeb del
        // canal web), la firma cambiaria y esto fallaria.
        //
        // Complementa a la prueba de anotaciones: aquella detecta la forma declarativa de cachear
        // (@Cacheable), esta detecta la forma artesanal (un mapa dentro de una clase intermedia),
        // que no lleva ninguna anotacion y por tanto ningun explorador de anotaciones encontraria.
        assertThat(ConsultaSaldoAtmService.class.getDeclaredConstructors())
                .hasSize(1);
        assertThat(ConsultaSaldoAtmService.class.getDeclaredConstructors()[0].getParameterTypes())
                .containsExactly(CoreClient.class, GuardiaTitularidad.class);
    }

    /** Token ya validado de una tarjeta, como el que el resource server entrega al controlador. */
    private static Jwt tokenDeTarjeta(Long cuentaId) {
        return Jwt.withTokenValue("token-de-prueba")
                .header("alg", "RS256")
                .issuedAt(Instant.now())
                .expiresAt(Instant.now().plusSeconds(180))
                .subject("4000000000000116")
                .claim("canal", "ATM")
                .claim("cuentaId", cuentaId)
                .claim("authorities", List.of("ROLE_CLIENTE_ATM", "PERM_saldo:leer"))
                .build();
    }
}
