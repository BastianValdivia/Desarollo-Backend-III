package cl.duoc.bancoxyz.bff.atm.seguridad;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import cl.duoc.bancoxyz.bff.atm.api.CuentaAtmController;
import cl.duoc.bancoxyz.bff.atm.soporte.ContextoAtmDePrueba;
import cl.duoc.bancoxyz.bff.atm.soporte.TokensDePrueba;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;

/**
 * Con el {@code auth-server} caido y sin sus claves en cache, el token no se puede ni verificar: 503
 * {@code autenticacion_no_disponible} (el cajero no hizo nada mal; devolverle un 401 lo mandaria a pasar la
 * tarjeta de nuevo para nada), no un 401 ni un 500. Sin token sigue siendo 401. Ver
 * {@code FiltroAutenticacionNoDisponible}.
 */
@WebMvcTest(controllers = CuentaAtmController.class)
@Import(ContextoAtmDePrueba.class)
class AuthServerCaidoAtmTest {

    @DynamicPropertySource
    static void servidorDeClavesCaido(DynamicPropertyRegistry registro) {
        registro.add("spring.security.oauth2.resourceserver.jwt.jwk-set-uri", () -> "http://127.0.0.1:1/oauth2/jwks");
        registro.add("spring.security.oauth2.resourceserver.jwt.issuer-uri", () -> EmisorDePrueba.EMISOR);
    }

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private CoreClient core;

    @Test
    @DisplayName("Con un token y el auth-server caido: 503 autenticacion_no_disponible, no 401")
    void sinClavesEs503() throws Exception {
        String token = TokensDePrueba.tokenValido(116, java.util.List.of("ROLE_CLIENTE_ATM", "PERM_saldo:leer"));
        mockMvc.perform(get("/v1/cuentas/116/saldo-disponible").header(HttpHeaders.AUTHORIZATION, "Bearer " + token))
                .andExpect(status().isServiceUnavailable())
                .andExpect(header().doesNotExist(HttpHeaders.WWW_AUTHENTICATE))
                .andExpect(jsonPath("$.motivo").value("autenticacion_no_disponible"))
                .andExpect(jsonPath("$.canal").value("ATM"));
    }

    @Test
    @DisplayName("Sin token sigue siendo 401 token_ausente: no hace falta ninguna clave para decirlo")
    void sinTokenSigueSiendo401() throws Exception {
        mockMvc.perform(get("/v1/cuentas/116/saldo-disponible"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_ausente"));
    }
}
