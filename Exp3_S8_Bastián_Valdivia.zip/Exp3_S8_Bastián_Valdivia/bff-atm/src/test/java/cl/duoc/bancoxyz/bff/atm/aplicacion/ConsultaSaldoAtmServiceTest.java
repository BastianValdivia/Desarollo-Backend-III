package cl.duoc.bancoxyz.bff.atm.aplicacion;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.bff.atm.api.dto.SaldoDisponibleAtmResponse;
import cl.duoc.bancoxyz.bff.atm.soporte.TokensDePrueba;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.core.dto.ConsultaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaTransaccionesCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto;

/**
 * Pruebas de la traduccion del DTO del core al DTO del canal.
 *
 * <p><b>Por que estas pruebas no levantan Spring ni la red.</b> La traduccion vive en la capa de
 * aplicacion justamente para poder probarla asi: se construye el servicio con un {@link CoreClient}
 * de mentira y se comprueba el resultado. Una prueba que necesitara el core levantado seria lenta,
 * dependeria de que otro proceso este arriba y dejaria de probar la traduccion para probar el
 * sistema entero.
 */
class ConsultaSaldoAtmServiceTest {

    @Test
    @DisplayName("Traduce saldo del core a saldoDisponible y descarta cuentaId")
    void traduceElContratoDelCoreAlDelCajero() {
        // El core entrega tres campos; el cajero publica dos. La cuenta 116 y su saldo de 12.000
        // son los valores congelados de la seccion 9 del contrato.
        CoreClient core = new CoreClientFalso(new SaldoCoreDto(116, new BigDecimal("12000.00"), "CLP"));

        SaldoDisponibleAtmResponse respuesta = servicioCon(core)
                .consultarSaldoDisponible(116, TokensDePrueba.jwtDe(116));

        assertEquals(new BigDecimal("12000.00"), respuesta.saldoDisponible());
        assertEquals("CLP", respuesta.moneda());

        // La prueba de que el recorte existe no es lo que el record trae, sino lo que NO puede
        // traer: el record declara dos componentes y ninguno es cuentaId. Si alguien agregara el
        // campo para "que sea mas comodo", esta linea seguiria pasando, pero la de mas abajo no.
        assertEquals(2, SaldoDisponibleAtmResponse.class.getRecordComponents().length,
                "La respuesta del cajero debe tener exactamente dos campos: saldoDisponible y moneda");
    }

    @Test
    @DisplayName("Deja pasar la excepcion del core sin atraparla")
    void noAtrapaLosFallosDelCore() {
        CoreClient core = new CoreClientFalso(null);

        // El servicio no lleva try/catch a proposito: la excepcion con nombre sube hasta el
        // manejador de errores del canal, que es el unico que sabe traducirla a RFC 7807.
        assertThrows(CoreRecursoNoEncontradoException.class,
                () -> servicioCon(core).consultarSaldoDisponible(999, TokensDePrueba.jwtDe(999)));
    }

    @Test
    @DisplayName("Una cuenta que no es la del token muere aqui, sin tocar el core")
    void rechazaLaCuentaAjenaAntesDeLlamarAlCore() {
        // El CoreClientFalso lanza UnsupportedOperationException en todo metodo que no sea el saldo,
        // y obtenerSaldo devolveria un valor: si la comprobacion de titularidad no existiera o
        // estuviera despues de la llamada, esta prueba recibiria un saldo en lugar de la excepcion.
        CoreClient core = new CoreClientFalso(new SaldoCoreDto(105, new BigDecimal("10000.00"), "CLP"));

        ReglaAtmException fallo = assertThrows(ReglaAtmException.class,
                () -> servicioCon(core).consultarSaldoDisponible(105, TokensDePrueba.jwtDe(116)));

        assertEquals("cuenta_ajena", fallo.motivo());
        assertEquals(403, fallo.estado().value());
    }

    private ConsultaSaldoAtmService servicioCon(CoreClient core) {
        return new ConsultaSaldoAtmService(core, new GuardiaTitularidad());
    }

    /**
     * Doble de prueba escrito a mano en lugar de un simulador tipo Mockito.
     *
     * <p>Se prefiere asi por dos razones: la prueba se lee como Java normal, sin una API intermedia
     * que aprender; y los cinco metodos que este canal no usa lanzan
     * {@code UnsupportedOperationException}, de modo que si alguien empieza a llamarlos desde el
     * cajero, la prueba lo dice en voz alta en vez de devolver un {@code null} silencioso.
     */
    private record CoreClientFalso(SaldoCoreDto saldo) implements CoreClient {

        @Override
        public SaldoCoreDto obtenerSaldo(int cuentaId) {
            if (saldo == null) {
                throw new CoreRecursoNoEncontradoException(
                        "cuenta inexistente", "/internal/v1/cuentas/" + cuentaId + "/saldo", null);
            }
            return saldo;
        }

        @Override
        public CuentaCoreDto obtenerCuenta(int cuentaId) {
            // Si esta linea se ejecuta alguna vez, el canal dejo de estar optimizado: estaria
            // trayendo la cuenta completa con sus movimientos para publicar dos campos.
            throw new UnsupportedOperationException("El cajero no pide la cuenta completa");
        }

        @Override
        public PaginaMovimientosCoreDto obtenerMovimientos(int cuentaId, ConsultaMovimientosCoreDto consulta) {
            throw new UnsupportedOperationException("El cajero no muestra movimientos");
        }

        @Override
        public RetiroCoreDto ejecutarRetiro(int cuentaId, SolicitudRetiroCoreDto solicitud, String claveIdempotencia) {
            throw new UnsupportedOperationException("El retiro llega con la fase de seguridad");
        }

        @Override
        public ReporteCalidadCoreDto obtenerCalidadDatos() {
            throw new UnsupportedOperationException("La auditoria es del canal web");
        }

        @Override
        public PaginaTransaccionesCoreDto obtenerTransaccionesNoConciliadas(int pagina, int tamano) {
            throw new UnsupportedOperationException("La auditoria es del canal web");
        }
    }
}
