package cl.duoc.bancoxyz.bff.atm.seguridad;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import cl.duoc.bancoxyz.bff.atm.api.CuentaAtmController;
import cl.duoc.bancoxyz.bff.atm.api.DenominacionesAtmController;
import cl.duoc.bancoxyz.bff.atm.soporte.TokensDePrueba;
import cl.duoc.bancoxyz.bff.atm.soporte.ContextoAtmDePrueba;
import cl.duoc.bancoxyz.comun.core.CoreClaveIdempotenciaReutilizadaException;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.CoreSaldoInsuficienteException;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;

/**
 * Las reglas de autorizacion del canal, probadas contra la cadena de filtros real.
 *
 * <h2>Los tres niveles del contrato, cada uno con su prueba</h2>
 *
 * <ol>
 *   <li><b>Autenticacion.</b> Sin token no se entra: 401 con el motivo exacto segun por que fallo el
 *       token.</li>
 *   <li><b>Operacion.</b> La tarjeta de solo consulta llega con un token impecable y no puede
 *       retirar: 403 {@code permiso_insuficiente}.</li>
 *   <li><b>Dato.</b> El token de la cuenta 116 no puede mirar la 105: 403 {@code cuenta_ajena}, y
 *       sin que la peticion llegue a rozar al core.</li>
 * </ol>
 *
 * <p>Los tres son 4xx distintos que un canal mal configurado colapsa en uno solo, o peor, en un 200.
 */
@WebMvcTest(controllers = {CuentaAtmController.class, DenominacionesAtmController.class})
@Import(ContextoAtmDePrueba.class)
class AutorizacionAtmTest {

    private static final List<String> AUTORIDADES_COMPLETAS =
            List.of("ROLE_CLIENTE_ATM", "PERM_saldo:leer", "PERM_retiro:ejecutar");

    private static final List<String> AUTORIDADES_SOLO_CONSULTA =
            List.of("ROLE_CLIENTE_ATM", "PERM_saldo:leer");

    private final EmisorDePrueba emisor = EmisorDePrueba.compartido();

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CoreClient core;

    // ------------------------------------------------------------------------------------------
    // Nivel 1: autenticacion. Los cuatro motivos de 401 del contrato.
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Sin cabecera Authorization: 401 token_ausente, con pantalla E-021")
    void sinTokenNoSeEntra() throws Exception {
        mockMvc.perform(get("/v1/cuentas/116/saldo-disponible"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_ausente"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-021"))
                .andExpect(jsonPath("$.mensajePantalla").value("Sesion no iniciada"))
                .andExpect(jsonPath("$.canal").value("ATM"))
                .andExpect(jsonPath("$.detail").doesNotExist())
                .andExpect(jsonPath("$.instance").value("/v1/cuentas/116/saldo-disponible"))
                .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"));

        // La peticion muere en la cadena de filtros: el core ni se entera.
        verify(core, never()).obtenerSaldo(anyInt());
    }

    @Test
    @DisplayName("Token firmado con una clave que el auth-server no publica: 401 firma_invalida")
    void firmaAjenaNoVale() throws Exception {
        String tokenAjeno = emisor.tarjeta116().firmadoPorOtraClave().emitir();
        consultarSaldo(116, tokenAjeno)
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("firma_invalida"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-022"));
    }

    @Test
    @DisplayName("Matriz 3x3, fila del cajero: el token web, el movil y el de servicio del core, con firma valida, son 401 audiencia_invalida (E-023)")
    void lasCeldasCruzadasSon401PorAudiencia() throws Exception {
        for (String ajeno : List.of(
                emisor.clienteWeb116().emitir(),
                emisor.clienteMovil116("dispositivo-demo-01").emitir(),
                emisor.tarjeta116().audiencia("core-service").emitir())) {
            consultarSaldo(116, ajeno)
                    .andExpect(status().isUnauthorized())
                    .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
                    .andExpect(jsonPath("$.motivo").value("audiencia_invalida"))
                    .andExpect(jsonPath("$.codigoPantalla").value("E-023"));
        }
        verify(core, never()).obtenerSaldo(anyInt());
    }

    @Test
    @DisplayName("La diagonal: el token del cajero con audiencia bff-atm entra")
    void laDiagonalEntra() throws Exception {
        given(core.obtenerSaldo(116)).willReturn(new SaldoCoreDto(116, new BigDecimal("12000.00"), "CLP"));
        consultarSaldo(116, TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Un token de otro emisor (el emisor propio del S5) es 401 firma_invalida aunque este bien firmado")
    void otroEmisorSeRechaza() throws Exception {
        consultarSaldo(116, emisor.tarjeta116().conEmisor("https://bancoxyz.duoc.cl/bff-atm").emitir())
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("firma_invalida"));
    }

    @Test
    @DisplayName("Un token sin firma (alg none) es 401")
    void tokenSinFirma() throws Exception {
        consultarSaldo(116, emisor.tarjeta116().emitirSinFirma())
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Token vencido: 401 token_expirado, con pantalla E-020")
    void tokenExpiradoNoVale() throws Exception {
        consultarSaldo(116, emisor.tarjeta116().vencido().emitir())
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_expirado"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-020"))
                .andExpect(jsonPath("$.mensajePantalla").value("Sesion expirada"));
    }

    @Test
    @DisplayName("La tolerancia de reloj es de 5 s y no de 60: un token vencido hace 30 s ya es 401 token_expirado")
    void laToleranciaDeRelojEsDeCincoSegundos() throws Exception {
        // Con los 60 s por defecto de Spring este token (exp = ahora - 30 s) todavia se aceptaria.
        consultarSaldo(116, emisor.tarjeta116().venceEn(-30).emitir())
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_expirado"));
    }

    @Test
    @DisplayName("La regla del cajero: un token SIN terminal es 401 terminal_no_registrado (E-012), aunque todo lo demas sea valido")
    void sinTerminalNoSeEntra() throws Exception {
        consultarSaldo(116, emisor.tarjeta116().sin("terminal").emitir())
                .andExpect(status().isUnauthorized())
                .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
                .andExpect(jsonPath("$.motivo").value("terminal_no_registrado"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-012"));
        verify(core, never()).obtenerSaldo(anyInt());
    }

    @Test
    @DisplayName("La regla del cajero: un terminal que no figura en la lista, o con otra grafia (atm-scl-001), es 401 terminal_no_registrado")
    void terminalDesconocidoNoSeEntra() throws Exception {
        for (String terminal : List.of("ATM-SCL-999", "atm-scl-001", " ATM-SCL-001", "")) {
            consultarSaldo(116, emisor.tarjeta116().claim("terminal", terminal).emitir())
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("terminal_no_registrado"));
        }
        verify(core, never()).obtenerSaldo(anyInt());
    }

    @Test
    @DisplayName("Un token valido del cajero sin claim authorities no abre nada: 403 permiso_insuficiente")
    void sinAutoridades() throws Exception {
        consultarSaldo(116, emisor.tarjeta116().sin("authorities").emitir())
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"));
    }

    @Test
    @DisplayName("El canal ya no emite tokens ni tiene login: POST /auth/login es 401 sin token y 404 con uno")
    void yaNoHayLogin() throws Exception {
        mockMvc.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"numeroTarjeta\":\"4000000000000116\",\"pin\":\"1234\"}"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_ausente"));
        mockMvc.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS))
                        .content("{\"numeroTarjeta\":\"4000000000000116\",\"pin\":\"1234\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("La tarjeta de solo consulta no puede retirar: 403 permiso_insuficiente")
    void sinPermisoDeRetiroNoSeRetira() throws Exception {
        /*
         * El token es valido, la cuenta es la suya y el monto es correcto: lo unico que falta es la
         * autoridad PERM_retiro:ejecutar. Esta tarjeta es el UNICO origen posible de un 403 por
         * permiso en este canal, porque un token de web o de movil falla antes por firma y devuelve
         * 401. Sin ella, la autorizacion por operacion no tendria prueba.
         */
        String token = TokensDePrueba.tokenValido(105, AUTORIDADES_SOLO_CONSULTA);

        mockMvc.perform(post("/v1/cuentas/105/retiros")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                        .header("Idempotency-Key", "clave-de-prueba-1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"monto\":1000}"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-030"))
                .andExpect(jsonPath("$.mensajePantalla").value("Operacion no permitida"))
                // Ninguna respuesta 403 lleva WWW-Authenticate: quien ya esta identificado no gana
                // nada repitiendo el login.
                .andExpect(header().doesNotExist(HttpHeaders.WWW_AUTHENTICATE));

        verify(core, never()).ejecutarRetiro(anyInt(), any(), anyString());
    }

    @Test
    @DisplayName("La misma tarjeta si puede consultar su saldo: el permiso es por operacion")
    void laMismaTarjetaSiConsulta() throws Exception {
        given(core.obtenerSaldo(105)).willReturn(new SaldoCoreDto(105, new BigDecimal("10000.00"), "CLP"));

        consultarSaldo(105, TokensDePrueba.tokenValido(105, AUTORIDADES_SOLO_CONSULTA))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.saldoDisponible").value(10000.00))
                .andExpect(jsonPath("$.moneda").value("CLP"))
                .andExpect(jsonPath("$.length()").value(2));
    }

    // ------------------------------------------------------------------------------------------
    // Nivel 3: autorizacion por dato. La regla que mas importa de todo el canal.
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Consultar una cuenta ajena es 403 cuenta_ajena y no llega al core")
    void noSeConsultaCuentaAjena() throws Exception {
        consultarSaldo(105, TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.motivo").value("cuenta_ajena"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-031"))
                .andExpect(jsonPath("$.mensajePantalla").value("Cuenta no asociada a la tarjeta"));

        verify(core, never()).obtenerSaldo(anyInt());
    }

    @Test
    @DisplayName("Retirar de una cuenta ajena es 403 cuenta_ajena y no mueve un peso")
    void noSeRetiraDeCuentaAjena() throws Exception {
        retirar(105, TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS), "3000")
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.motivo").value("cuenta_ajena"));

        verify(core, never()).ejecutarRetiro(anyInt(), any(), anyString());
    }

    @Test
    @DisplayName("Una cuenta ajena e INEXISTENTE tambien es 403 y nunca 404")
    void cuentaAjenaEInexistenteEs403() throws Exception {
        /*
         * La prueba que impide que el canal funcione como detector de cuentas. Si la titularidad se
         * comprobara despues de preguntar por la existencia, las cuentas que existen darian 403 y las
         * que no existen darian 404: comparando las dos respuestas, cualquiera con un token valido
         * sabria que numeros de cuenta hay en el banco.
         */
        consultarSaldo(999, TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.motivo").value("cuenta_ajena"));

        verify(core, never()).obtenerSaldo(anyInt());
    }

    @Test
    @DisplayName("Un token sin claim cuentaId no acredita titularidad sobre ninguna cuenta")
    void tokenSinCuentaIdNoAcreditaNada() throws Exception {
        consultarSaldo(116, TokensDePrueba.tokenValido(null, AUTORIDADES_COMPLETAS))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.motivo").value("cuenta_ajena"));
    }

    @Test
    @DisplayName("Retiro correcto: delega en el core, reenvia la clave y agrega el desglose")
    void retiroCorrecto() throws Exception {
        given(core.ejecutarRetiro(eq(116), any(), eq("clave-del-terminal-42")))
                .willReturn(new RetiroCoreDto("RET-20260911-000123", new BigDecimal("12000.00"),
                        new BigDecimal("3000.00"), new BigDecimal("9000.00")));

        retirar(116, TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS), "3000")
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.folio").value("RET-20260911-000123"))
                .andExpect(jsonPath("$.saldoAnterior").value(12000.00))
                .andExpect(jsonPath("$.montoRetirado").value(3000.00))
                .andExpect(jsonPath("$.saldoPosterior").value(9000.00))
                // 3.000 con billetes de 1.000, 2.000, 5.000 y 10.000: uno de 2.000 y uno de 1.000.
                .andExpect(jsonPath("$.desglose.length()").value(2))
                .andExpect(jsonPath("$.desglose[0].denominacion").value(2000))
                .andExpect(jsonPath("$.desglose[0].cantidad").value(1))
                .andExpect(jsonPath("$.desglose[1].denominacion").value(1000))
                .andExpect(jsonPath("$.desglose[1].cantidad").value(1));
    }

    @Test
    @DisplayName("Saldo insuficiente: 409 y no 503, aunque la excepcion venga del core")
    void saldoInsuficienteEs409() throws Exception {
        /*
         * CoreSaldoInsuficienteException hereda de CoreException, que este canal traduce a 503. Si
         * faltara el manejador especifico, el cajero diria "servicio no disponible" cuando lo que
         * pasa es que no hay fondos: una respuesta impecable y completamente equivocada.
         */
        given(core.ejecutarRetiro(anyInt(), any(), anyString()))
                .willThrow(new CoreSaldoInsuficienteException("sin fondos",
                        "/internal/v1/cuentas/106/retiros", null));

        retirar(116, TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS), "8000")
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.motivo").value("saldo_insuficiente"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-042"))
                .andExpect(jsonPath("$.mensajePantalla").value("Fondos insuficientes"));
    }

    @Test
    @DisplayName("Idempotency-Key reutilizada con otro importe: 422 propio y no 503, aunque la excepcion venga del core")
    void claveReutilizadaEs422() throws Exception {
        given(core.ejecutarRetiro(anyInt(), any(), anyString()))
                .willThrow(new CoreClaveIdempotenciaReutilizadaException("clave reutilizada",
                        "/internal/v1/cuentas/116/retiros", null));

        retirar(116, TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS), "3000")
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.motivo").value("clave_idempotencia_reutilizada"))
                .andExpect(jsonPath("$.codigoPantalla").doesNotExist());
    }

    @Test
    @DisplayName("Las tres reglas de monto dan tres motivos distintos, en el orden congelado")
    void lasTresReglasDeMontoSeDistinguen() throws Exception {
        String token = TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS);

        /*
         * 1.500 viola SOLO la regla del multiplo. 500 viola DOS a la vez (no es multiplo y esta bajo
         * el minimo) y debe responder por la primera: es el caso que hace que el orden importe y no
         * sea un detalle de implementacion.
         */
        retirar(116, token, "1500")
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.motivo").value("monto_no_multiplo"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-050"));

        retirar(116, token, "500")
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.motivo").value("monto_no_multiplo"));

        // Cero es multiplo de 1.000, asi que pasa la primera regla y cae en la segunda.
        retirar(116, token, "0")
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.motivo").value("monto_bajo_minimo"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-051"));

        retirar(116, token, "11000")
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.motivo").value("supera_tope_transaccion"))
                .andExpect(jsonPath("$.codigoPantalla").value("E-052"));

        // Ninguno de los cuatro llego al core: las reglas del canal se resuelven en el canal.
        verify(core, never()).ejecutarRetiro(anyInt(), any(), anyString());
    }

    @Test
    @DisplayName("A4, las denominaciones, exige token y la autoridad de consulta")
    void denominacionesExigeToken() throws Exception {
        mockMvc.perform(get("/v1/denominaciones"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_ausente"));

        mockMvc.perform(get("/v1/denominaciones")
                        .header(HttpHeaders.AUTHORIZATION,
                                "Bearer " + TokensDePrueba.tokenValido(116, AUTORIDADES_COMPLETAS)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.moneda").value("CLP"))
                .andExpect(jsonPath("$.denominaciones.length()").value(4));
    }

    private ResultActions consultarSaldo(int cuentaId, String token) throws Exception {
        return mockMvc.perform(get("/v1/cuentas/{id}/saldo-disponible", cuentaId)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token));
    }

    private ResultActions retirar(int cuentaId, String token, String monto) throws Exception {
        return mockMvc.perform(post("/v1/cuentas/{id}/retiros", cuentaId)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                .header("Idempotency-Key", "clave-del-terminal-42")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"monto\":" + monto + "}"));
    }
}
