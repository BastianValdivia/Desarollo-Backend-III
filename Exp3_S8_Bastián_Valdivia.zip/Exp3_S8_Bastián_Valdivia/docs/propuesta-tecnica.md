# Propuesta técnica: Banco XYZ en la nube con Spring Cloud

Documento de la entrega de la sumativa Exp3 S8 (Desarrollo Backend III, PBY2203). Explica qué problema
se resuelve, qué se propone, cómo queda la arquitectura, qué alternativas se descartaron y por qué,
qué riesgos se vieron y hasta dónde llega el alcance. Las instrucciones para ejecutar el proyecto
están en el [`README.md`](../README.md) y la evidencia, en [`evidencias/INDICE.md`](../evidencias/INDICE.md).

## 1. Problema

La entrega de la semana 5 dejó al Banco XYZ con tres backends por canal (patrón Backend for Frontend:
web, móvil y cajero) y un backend de dominio, el `core-service`. Funciona y está probado, pero tiene
límites que impiden operarlo en la nube:

| Límite del punto de partida | Consecuencia |
|---|---|
| Cada BFF emite sus propios tokens, con su propia clave; el core se protege con una cabecera fija | Hay tres emisores que auditar y rotar, y un secreto compartido que, si se filtra, abre el core entero |
| Direcciones y configuración fijas dentro de cada servicio | Mover o duplicar un servicio obliga a recompilar y redesplegar |
| El dominio guarda su estado en la memoria de un proceso | No se puede tener dos réplicas ni sobrevivir a un reinicio |
| Una caída o lentitud del core se propaga a los tres canales | Un fallo parcial se vuelve una caída total |
| Un retiro no puede avisar a otros sistemas sin acoplarlos | Notificar o auditar exigiría tocar el código del retiro |
| Solo corre con una receta manual en la máquina del autor | Nadie más puede reproducirlo ni desplegarlo |

La actividad pide tres tareas (OAuth 2.0, imágenes Docker y un `docker-compose.yaml`) y, en su
descripción, Spring Cloud Security, Resilience4j y mensajería con Kafka o JMS. La pauta evalúa seis
criterios: OAuth 2.0 (20 puntos), imágenes Docker (20), docker-compose (20), Resilience4j (20),
Kafka o JMS (15) y entrega (5).

Un supuesto de la actividad no se cumple en este repositorio: pide partir de "los microservicios de
la semana 6" con Config Server, Eureka y Resilience4j, y no existen. Por eso se construyen aquí.

## 2. Propuesta

Evolucionar el proyecto del S5 a una arquitectura de microservicios que se levanta con un solo
comando, sin tocar el comportamiento visible para el usuario. Seis líneas de trabajo, una por cada
límite de la sección anterior:

1. **Plataforma Spring Cloud.** `config-server` (configuración centralizada en `config-repo/`) y
   `eureka-server` (registro y descubrimiento). Los servicios se llaman por nombre lógico.
2. **Persistencia en PostgreSQL.** El core guarda su estado en una base propia con Flyway, y corre en
   dos réplicas. Cada servicio con datos tiene su base y su usuario.
3. **Un servidor de autorización OAuth 2.0.** El `auth-server` (Spring Authorization Server) es el
   único emisor. Entre servicios se usa `client_credentials` con scopes mínimos; los usuarios web y
   móvil entran con `authorization_code` y PKCE; el cajero, con un grant de extensión de tarjeta y
   PIN. Los demás servicios solo validan.
4. **Resiliencia.** Resilience4j alrededor de cada llamada a una dependencia remota, con un
   respaldo distinto por canal y escenarios de caos que lo demuestran con números.
5. **Mensajería con Kafka.** Un retiro escribe un evento en una tabla `outbox` dentro de su misma
   transacción; un relay lo publica; dos consumidores independientes (notificaciones y auditoría)
   lo procesan de forma idempotente.
6. **Contenedores.** Una imagen por microservicio y un compose que orquesta todo, con secretos
   generados al primer arranque y ninguno en git ni en las imágenes.

El resultado son nueve microservicios propios y la infraestructura que los sostiene (PostgreSQL,
Kafka, Kafka UI y dos tareas únicas), 16 contenedores en total.

## 3. Arquitectura

El diagrama general, la tabla de componentes y un diagrama de secuencia de un retiro están en el
README (sección Arquitectura). En una frase: tres canales entran por tres BFF protegidos con HTTPS y
tokens del `auth-server`; los BFF llaman al core (dos réplicas) con un token de servicio y con
Resilience4j; el core escribe en PostgreSQL y, por el outbox, publica en Kafka; notificaciones y
auditoría consumen; y el panel del ejecutivo del BFF web lee la auditoría.

Dos redes: `borde` (lo que el usuario alcanza) e `interna`, declarada `internal: true`, sin salida a
Internet ni al host, donde viven el core, la base, Kafka y los consumidores sin ningún puerto
publicado.

El contrato de los eventos, sus garantías y el diagrama de la arquitectura de eventos están en
[`eventos.md`](eventos.md).

## 4. Decisiones y alternativas

Cada decisión lleva lo que se descartó y por qué. Las doce decisiones numeradas (D1 a D12) están en
el plan maestro y resumidas en el README; aquí están las de mayor peso.

| Tema | Decisión | Alternativa descartada | Por qué |
|---|---|---|---|
| Versiones | Spring Boot 3.3.13, Spring Cloud 2023.0.6, Resilience4j 2.2.0 | Subir a Spring Boot 4 | La base ya funciona en 3.3 y la pauta no evalúa versiones; migrar arriesga regresiones (Jackson 3, Spring Security 7) sin dar puntos. El fin de soporte OSS de Boot 3.3 se declara como limitación |
| Emisión de tokens | Un solo emisor, y los BFF solo validan | Mantener un emisor por BFF y agregar OAuth2 solo entre servicios | Dejaría la autenticación de usuarios "a medias": tres claves, tres lugares donde rotar. La guía dice que los servicios deben delegar su seguridad |
| Aislamiento entre canales | La audiencia (`aud`) de cada token | Una clave de firma por canal (como en el S5) | Con un solo emisor hay una sola clave; la audiencia es la barrera semántica que define el RFC 7519 y la matriz 3x3 la comprueba |
| Login del cajero | Grant de extensión tarjeta + PIN con secreto de terminal | Grant `password` | La RFC 9700 lo prohíbe y Spring Authorization Server no lo implementa; el grant propio además autentica al terminal y lleva la política de PIN al servidor de autorización |
| Spring Cloud Security | Spring Security OAuth2 (Resource Server y Client) y Spring Authorization Server | El artefacto `spring-cloud-starter-security` | Su última versión (2.2.5) es de 2021 y no está en los trenes actuales; es lo que la propia guía recomienda |
| Confianza TLS | CA interna propia, emisor fijo `https://localhost:9000`, JWKS por la dirección interna | Certificados autofirmados por servicio, o `-k` en las pruebas | La CA permite verificar con `--cacert` sin desactivar la verificación; el emisor fijo evita que el token diga un emisor y el servicio espere otro dentro de Docker |
| Persistencia | PostgreSQL 16, Flyway, carga inicial como migración Java que reutiliza la ingesta del S5 | Job dedicado de Spring Batch | Un componente más que puede fallar y la pauta no lo evalúa. Queda como extensión posible |
| Mensajería | Kafka oficial en modo KRaft | El compose de la guía (`wurstmeister/kafka` con ZooKeeper); JMS | Esas imágenes se actualizaron por última vez en 2022 y 2019, Kafka 4.0 eliminó ZooKeeper y `version:` es obsoleta en Compose v2. Kafka, y no JMS, porque lo escalable se demuestra con particiones y grupos de consumidores |
| Doble escritura | Patrón outbox con relay de líder único (lock consultivo de PostgreSQL) | Publicar en Kafka dentro de la transacción del retiro; relay en cada réplica | Guardar el retiro y publicar son dos sistemas sin transacción común. Dos relays perderían el orden por cuenta |
| Entrega de eventos | Al menos una vez y consumidores idempotentes por `eventId` | Intentar "exactamente una vez" de extremo a extremo | Exigiría transacciones entre Kafka y dos bases; la idempotencia es más simple y se prueba |
| Reintentos de consumidores | No bloqueantes (`@RetryableTopic`) y DLT por grupo | Reintento bloqueante | Un mensaje enfermo detendría toda su partición |
| Resiliencia | Retry, CircuitBreaker y Bulkhead de Resilience4j, con respaldo por canal | Solo timeouts; o un respaldo igual para los tres canales | Cada dependencia falla distinto. El cajero entrega dinero físico y falla cerrado: nunca un saldo inventado ni un retiro simulado |
| Entrada al sistema | Sin API Gateway | Un gateway delante de los BFF | Cada BFF ya es la puerta de su canal; un gateway volvería a centralizar lo que el patrón separó |
| Secretos | Generados al primer arranque por una tarea única, un volumen por servicio | Variables de entorno o archivos en el repositorio | Nada secreto en git ni en las imágenes; cada servicio monta solo lo suyo |
| Configuración | Config Server nativo sobre una carpeta montada | Repositorio git de configuración | El evaluador cambia un valor y lo aplica con `POST /actuator/refresh` sin credenciales de un repositorio ni reconstruir imágenes |
| Actuator | Puerto de gestión separado, HTTP y no publicado | Un solo puerto con rutas protegidas | Los healthchecks no dependen de TLS ni de tokens, y nada de gestión llega al host |

## 5. Riesgos

| Riesgo | Efecto | Cómo se trató | Estado |
|---|---|---|---|
| Emisor del token distinto dentro y fuera de Docker | Todos los tokens rechazados | Emisor fijo y JWKS por la dirección interna | Cubierto: 85 comprobaciones del core con tokens reales |
| Secretos que un usuario no root no puede leer | Servicios que no arrancan | UID fijo 10001 y `chown` en la tarea de secretos | Cubierto; la tarea es la única que corre como root, acotada |
| Un servicio arranca antes que su dependencia | Fallos al inicio | `depends_on` con condiciones de salud más reintento de configuración y de Eureka | Cubierto: arranque en frío repetido |
| Orden de eventos roto con dos réplicas | Eventos de una cuenta desordenados | Relay con líder único y clave de partición por cuenta | Cubierto, con un límite conocido ante fallos parciales de un lote |
| Reintentos que duplican efectos | Un retiro descontado dos veces | Solo se reintenta lo idempotente: GET y el retiro con su `Idempotency-Key`; el reintento del balanceador se desactivó | Cubierto: se midió el duplicado y se corrigió |
| El umbral de fallos abre el circuito con una sola réplica muerta | Falso positivo de caída | Umbral subido a 70 % y conexión a 500 ms, ambos medidos | Cubierto: 100 de 100 peticiones con una réplica muerta |
| La carga en PostgreSQL no reproduce los números del S5 | Regresión silenciosa | Comprobación de las cifras del S5 (50 cuentas, 686 movimientos y los descartes) | Cubierto |
| Límites de descarga de las imágenes y de Maven Central | Construcción lenta o fallida | Caché de BuildKit y versión exacta de las bases; la verificación reintenta | Cubierto; depende de la red del evaluador |
| Ejecución en Windows o macOS | Diferencias de fin de línea o de `bash` | `.gitattributes` fuerza LF en los `.sh`; scripts probados con `bash` 3.2.57 y un clon con `core.autocrlf=true` | Parcial: no se ejecutó con Docker Desktop |
| Falta de alta disponibilidad | Una caída de PostgreSQL o Kafka detiene el sistema | Se declara como límite; el core sigue aceptando retiros con Kafka detenido gracias al outbox | Aceptado |

## 6. Alcance

**Incluye**
- Los nueve microservicios con su imagen, y la infraestructura: PostgreSQL, Kafka, Kafka UI y dos tareas únicas.
- OAuth 2.0 completo: emisor único, tres flujos de usuario, scopes y audiencias, política de intentos.
- Resilience4j en todas las llamadas a dependencias remotas, con seis escenarios de caos medidos.
- Dos tópicos de eventos, dos grupos de consumidores idempotentes, reintentos no bloqueantes, DLT y
  un escalado medido con 1, 3 y 4 consumidores.
- Un comando que levanta todo y otro que lo verifica y deja la evidencia en `evidencias/`.
- No regresión del S5: sus doce comportamientos siguen pasando.

**No incluye (límites declarados)**
- Alta disponibilidad: PostgreSQL y Kafka son de un solo nodo, y el respaldo es un guion manual.
- TLS mutuo entre servicios internos: la red `interna` no es alcanzable desde el host.
- Ejecución verificada en Windows o macOS con Docker Desktop.
- Un API Gateway, trazas distribuidas y migración con Spring Batch (extensiones posibles).
- Un escenario de caos con PostgreSQL detenido.
- Integración continua: no se pidió, así que la verificación es local, con `scripts/verificar.sh`.

## 7. Cómo se comprueba

`scripts/verificar.sh` levanta el sistema, ejecuta cada comprobación y los escenarios de caos, y
escribe la salida literal en `evidencias/salidas/`. `./mvnw -B verify` ejecuta las 610 pruebas.
Cada criterio de la pauta se mapea a sus archivos en [`evidencias/INDICE.md`](../evidencias/INDICE.md).
