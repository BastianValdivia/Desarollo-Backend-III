# Guía de estudio: 

Preguntas y respuestas (`planificacion/bitacora/F0.md` a `F10.md`),Las cifras salen de
`evidencias/salidas/`; el README dice de qué archivo.


**Índice**

1. [El proyecto y su punto de partida](#1-el-proyecto-y-su-punto-de-partida)
2. [Spring Cloud: Config Server y Eureka](#2-spring-cloud-config-server-y-eureka)
3. [Docker y Compose](#3-docker-y-compose)
4. [PostgreSQL y el dominio](#4-postgresql-y-el-dominio)
5. [OAuth 2.0](#5-oauth-20)
6. [Resilience4j](#6-resilience4j)
7. [Kafka](#7-kafka)
8. [Verificación, evidencia y entrega](#8-verificación-evidencia-y-entrega)
9. [Preguntas incómodas](#9-preguntas-incómodas)

---

## 1. El proyecto y su punto de partida

**¿Qué hace el sistema, en una frase?**
Tres canales (web, móvil y cajero) entran por tres BFF que validan tokens de un único servidor de autorización y llaman a un
core de dominio con PostgreSQL; el core publica un evento por cada retiro en Kafka, que consumen notificaciones y auditoría;
todo corre en contenedores con un solo comando.

**¿Por qué se parte del S5 y no de cero?**
La actividad dice "continuar" el proyecto, y el S5 ya resuelve el dominio, los tres BFF, HTTPS, la titularidad y las reglas por
canal. Reescribirlo no suma puntos y sí riesgo de regresiones. Con el historial unido el repositorio muestra la evolución, y el
S5 se consulta con `git show dd2e301:<ruta>`.

**¿Qué es un BOM y por qué Spring Cloud se alinea con una versión de Boot?**
Un BOM (Bill Of Materials) es un POM que solo trae `dependencyManagement`: versiones probadas juntas. Al importarlo, las
dependencias se declaran sin versión. Cada tren de Spring Cloud (2023.0.x) se compila contra una rama de Boot (3.3.x); mezclar
rompe el arranque, por eso se suben juntos: Boot 3.3.13 con Cloud 2023.0.6.

**¿Por qué Spring Boot 3.3 si ya salió Boot 4?**
Porque la base del S5 funciona en 3.3 y la pauta no evalúa versiones; migrar a Boot 4 (Jackson 3, Spring Security 7) arriesga
regresiones sin dar puntos. Es cierto que el soporte OSS de Boot 3.3 terminó el 30-06-2025, y por eso está declarado como
limitación en el README.

**¿Qué es "no regresión" y cómo se demuestra?**
Que lo que funcionaba en el S5 siga funcionando. Son doce comportamientos (sin token 401, vigencias, matriz 3x3, titularidad,
permisos por rol, token móvil atado al dispositivo, terminales del cajero, HTTPS, optimización por canal, retiro atómico e
idempotente, carga del dataset y casos borde). Se ejecutan en `scripts/verificar-no-regresion.sh` (`40-no-regresion-s5.txt`, 60
comprobaciones).

**¿Por qué los `.sh` con LF forzado?**
Se montan dentro de contenedores Linux. Git en Windows convierte a CRLF por defecto, y el intérprete lee `bash\r` y falla con
"bad interpreter". `.gitattributes` lo impide en cada clon sin pedirle nada al evaluador. Se comprobó con un clon con
`core.autocrlf=true`.

---

## 2. Spring Cloud: Config Server y Eureka

**¿Qué problema resuelve el Config Server?**
Que la configuración deje de vivir dentro de cada jar. Hay una carpeta `config-repo/` servida por HTTP: un cambio se aplica con
`POST /actuator/refresh`, sin recompilar ni reconstruir imágenes. Es lo que permite inyectar latencia en los escenarios de caos.

**¿Por qué backend `native` y no Git?**
La carpeta viaja con el código, se monta como volumen y se relee en cada petición. Git exigiría otro repositorio, credenciales y
un commit por cada cambio.

**¿Y Eureka?**
Que nadie conozca la dirección de nadie. Cada servicio se registra con un nombre y manda un latido; los demás descargan la lista.
El BFF pide `http://core-service` y el balanceador lo cambia por la IP y el puerto de una instancia viva. Si el core se mueve,
se duplica o muere, los BFF no se tocan.

**¿En qué se diferencia del DNS de Docker?**
El DNS de Docker resuelve un nombre a una IP, pero no sabe si el proceso está sano, no distingue puertos ni protocolos, no
existe fuera de Docker y no expulsa una instancia que falla. Eureka suma salud, metadatos y balanceo del lado del cliente. Se
usan los dos: el DNS para llegar a Eureka y al config-server, y Eureka entre microservicios.

**¿Qué pasa si cae Eureka? ¿y el Config Server?**
Si cae Eureka, los clientes siguen con la última lista descargada y las llamadas siguen funcionando; se pierde enterarse de altas
y bajas. Si cae el Config Server, los servicios ya arrancados siguen; uno que arranca de nuevo reintenta y no arranca con valores
por defecto (arrancar sin configuración sería peor que no arrancar).

**¿Qué es `@LoadBalanced` y por qué `http://core-service` funciona?**
Es un calificador que marca un `RestClient.Builder` para que Spring Cloud le agregue un interceptor. Antes de enviar, el
interceptor pregunta al registro por las instancias de `core-service`, elige una (round robin) y reemplaza el nombre por
`IP:puerto`. Sin la anotación, `core-service` sería un host inexistente.

**¿Por qué los arriendos cortos de Eureka están solo en el perfil `demo`?**
Con los valores por defecto una instancia muerta tarda minutos en salir y no se puede demostrar en vivo. Con arriendos de 5 s de
latido y 15 s de vencimiento sale en unos 30 s, a cambio de más tráfico y menos tolerancia a pausas largas. En producción se usan
los valores por defecto.

**¿Por qué el refresh no cambia el puerto ni lo de Eureka?**
El refresh vuelve a leer el `Environment` y reconstruye los beans `@RefreshScope`, pero el servidor web, los pools y los
`@ConfigurationProperties` se crean una vez. Además se desactivó `eureka.client.refresh.enable` porque cada refresh destruía el
cliente de Eureka y el BFF respondía 503 durante unos 5 s. Una propiedad `eureka.*` exige reiniciar el servicio.

**¿Por qué el puerto de gestión es aparte, HTTP y no publicado?**
Lo operativo (salud, refresh, métricas) no debe viajar por el puerto de los clientes del banco ni exigirles un token. Su
protección es no publicarse. HTTP porque un healthcheck no necesita cifrado y TLS lo volvería frágil. Nunca se exponen `env`,
`configprops` ni `heapdump` porque entregan la configuración resuelta o la memoria del proceso (`20-compose-config-eureka-f1.txt`).

---

## 3. Docker y Compose

**¿Qué es una imagen y qué es un contenedor?**
La imagen es la plantilla inmutable (capas de solo lectura con el JRE, el código y el arranque); el contenedor es una instancia
en ejecución, con su capa de escritura, procesos, red y volúmenes. De una imagen salen tantos contenedores como se quiera (el
core corre dos). Lo que no está en la imagen (secretos, `config-repo`) entra por volúmenes.

**¿Por qué se construye en dos etapas y para qué sirven las capas?**
Compilar necesita JDK y Maven (la imagen de Maven pesa 814 MB); ejecutar solo necesita el JRE (287 MB). Con una etapa, el
compilador, el código fuente y la caché de dependencias viajarían en la imagen y ampliarían la superficie de ataque. Las capas
parten el jar: las dependencias (decenas de MB) casi no cambian y el código propio (KB) cambia en cada commit, así que un cambio
invalida una capa pequeña.

**¿Healthcheck o `depends_on`?**
El healthcheck es la pregunta "¿estás sano?" que Docker hace a un contenedor (aquí, un `wget` al puerto de gestión).
`depends_on` es una regla de orden: con `service_healthy` no arranca un servicio hasta que su dependencia responda sana, y con
`service_completed_successfully` espera a que una tarea única (`secretos-init`, `kafka-init`) termine con código 0. No se
sustituyen: `depends_on` solo actúa al arrancar, y el reintento del config-server cubre lo que se reinicie después.
`start_period` evita marcar como fallido a un servicio que aún arranca.

**¿Por qué no root y por qué dos redes?**
Un proceso comprometido como root tiene todos los privilegios del contenedor; como 10001 solo puede lo que ese usuario puede.
UID numérico y fijo porque los volúmenes se escriben con ese dueño. Dos redes porque `interna` (`internal: true`) no tiene salida
ni se puede publicar desde ella: lo que solo vive allí es inalcanzable desde afuera aunque alguien publique un puerto por error.

**¿Por qué `secretos-init` corre como root si todo lo demás es 10001?**
Tiene que dejar cada volumen de secretos con el dueño de su servicio (10001, y 70 para PostgreSQL), y solo root puede cambiar
dueños. Se acotó: `cap_drop: ALL` salvo `CHOWN`, `DAC_OVERRIDE` y `FOWNER`, sin red, solo lectura, 512 MiB y unos segundos de
vida. Es la única excepción, está declarada y `verificar-f8.sh` la comprueba.

**¿Por qué una CA propia y no certificados autofirmados por canal?**
Con tres autofirmados había que pasarle a `curl` tres archivos o usar `-k`, que desactiva la verificación. Con una CA se firma
todo y el evaluador confía en **un** archivo, `certs/ca.crt`, que es público (solo identifica a la autoridad). La clave privada
de la CA no sale del volumen que solo monta `secretos-init`.

**¿Qué es `configtree` y por qué para los secretos?**
Una forma de Spring Boot de leer propiedades desde una carpeta, un archivo por propiedad, que es como Kubernetes y Docker
entregan secretos. Así ni la contraseña del keystore ni la del cliente pasan por una variable de entorno (visible con
`docker inspect`), por `config-repo` ni por el jar.

**¿Qué pasa si se ejecuta `secretos-init` dos veces?**
Nada: cada pieza existente se conserva. Regenerar la CA o la clave de firma invalidaría de golpe certificados y tokens, con un
síntoma (fallos TLS o 401 por todas partes) lejos de la causa.

**¿Cómo sé que no hay secretos en las imágenes?**
Cuatro revisiones: el historial de capas (una capa posterior no borra lo que una anterior dejó), las variables de entorno de la
imagen, el sistema de archivos y el interior de cada `.jar`, más git. Y la inversa: se leen los valores secretos reales de los
volúmenes y se comprueba que ninguno aparece en las evidencias (`11-imagenes-f8.txt`, `79-entrega.txt`).

**¿Por qué las imágenes base llevan versión exacta?**
Para que construir hoy y dentro de seis meses dé lo mismo, y para reproducir un fallo. Cada etiqueta nueva apunta al mismo
digest que la flotante anterior. Costo: los parches de seguridad no llegan solos.

**¿Qué hace cada límite del compose y qué pasa si un servicio se pasa?**
`mem_limit` es un techo: si el proceso lo supera, el núcleo lo mata (OOM) y `restart: unless-stopped` lo levanta, sin llevarse al
resto. `cpus` evita que uno ocupe los núcleos; `pids_limit` contiene una fuga de hilos. La JVM lee el límite del contenedor
(`-XX:MaxRAMPercentage=75`): con 768 MiB su heap máximo es de 576 MiB, no de 11,8 GiB como sin límite en la máquina de pruebas
(Actuator suma 556 MiB porque cuenta solo las regiones del heap; la cifra configurada es 576).

**¿Por qué los límites aceleraron el arranque?**
Sin límite cada JVM se dimensiona para toda la máquina (recolector G1, 4 hilos de GC, heap inicial de 256 MiB) y 14 JVM
arrancando juntas compiten por 4 núcleos; con límite elige el recolector serial y un heap inicial pequeño. Medido en la máquina de
pruebas (no se afirma que valga en otra): 108 s sin límites contra 84 s con ellos, y 4393 contra 3057 MiB.

**¿Qué activa `restart: unless-stopped`?**
Que el proceso del contenedor termine **por sí mismo**. `docker kill` y `docker stop` los toma Docker como una orden de una
persona y no reinician; `docker exec <c> kill 1` (SIGTERM al PID 1 desde dentro) hace que la JVM se apague y Docker la levante;
en Eureka se ve `UP`, ausente, `UP` (`22-compose-reinicio-automatico.txt`).

**¿Qué es multiarquitectura y por qué importa?**
Una etiqueta puede apuntar a una lista de manifiestos, uno por plataforma (`amd64`, `arm64`). Docker baja el que corresponde al
equipo; por eso el mismo `docker compose up` corre en un Mac con Apple Silicon. Se comprueba en el registro, no ejecutando en ARM.

**¿Qué es CDS y por qué se descartó?**
Class Data Sharing guarda en un archivo las clases ya leídas y verificadas. Se midió un 25 % menos de arranque de la aplicación
(7,6 a 5,7 s). Se descartó porque el archivo no se puede generar al construir la imagen sin una corrida de entrenamiento que
necesita las dependencias de cada servicio, y la variante que se crea al apagarse no mejora el primer arranque, que es el que ve el
evaluador.

**¿Por qué no se copió el compose de la guía?**
Usa `wurstmeister/kafka` con ZooKeeper (imágenes sin actualizar desde 2022 y 2019), Kafka 4.0 eliminó ZooKeeper y `version:` es
obsoleta en Compose v2. Se usa la imagen oficial `apache/kafka` en modo KRaft con versión fija.

**¿Por qué los BFF registran su IP de la red interna en Eureka?**
Porque están en dos redes y tienen dos IP. Si Eureka registrara la de `borde`, el core intentaría llamarlos por una dirección
a la que no llega. La subred `interna` está fija y los clientes prefieren esa por su prefijo.

**¿Hay copias de seguridad?**
Hay un guion manual, `scripts/respaldar-postgres.sh`, que respalda y restaura las tres bases con `pg_dump` y `pg_restore`. No es
un respaldo programado; programarlo (cron, tareas del equipo) invocaría el mismo guion. Está declarado como limitación.

---

## 4. PostgreSQL y el dominio

**¿Por qué el estado en memoria no sirve con contenedores?**
Un contenedor es desechable y puede haber varios. En memoria cada réplica tendría su propio saldo, un reinicio borraría los
retiros y la idempotencia no valdría entre réplicas. El estado tiene que vivir en un solo lugar compartido y duradero.

**¿Por qué el `UPDATE` condicional basta, sin locks a mano?**
`UPDATE cuenta SET saldo = saldo - :monto WHERE id = :id AND saldo >= :monto` es una sola sentencia: la condición se evalúa sobre
la fila que PostgreSQL ya bloqueó para escribirla. El segundo retiro espera, reevalúa con el saldo nuevo y, si ya no alcanza,
no actualiza ninguna fila (0 filas = saldo insuficiente). No hay un instante entre leer y escribir donde otro se cuele. Además
`CHECK (saldo >= 0)` impide el negativo. Prueba: diez retiros simultáneos sobre 5000 dan 5 éxitos y saldo 0.

**¿Cómo la restricción única vuelve idempotente el retiro?**
La clave de idempotencia es única **por cuenta** (clave primaria `(cuenta_id, clave)`, migración `V3`). Se reserva con
`INSERT ... ON CONFLICT DO NOTHING` antes de descontar, en la misma transacción. Si dos peticiones con la misma clave llegan a la
vez, la base deja pasar a una y hace esperar a la otra; la segunda ve 0 filas y devuelve el comprobante guardado (mismo folio, sin
descontar). La misma clave en otra cuenta es una operación nueva; la misma clave y cuenta con otro importe da 422
`clave_idempotencia_reutilizada`. Si el retiro falla, la reserva se deshace con la transacción.

**¿Por qué dos réplicas no cargan el dataset a la vez?**
Flyway toma un bloqueo en la base antes de migrar. La réplica que lo obtiene aplica las versiones; la otra espera y ve la carga ya
hecha. La carga es una migración Java versionada, no un `@PostConstruct` en cada arranque. Una migración aplicada no se edita.

**¿Es la migración `V2` una foto independiente del código?**
Solo mientras no cambien las clases que reutiliza (`IngestaDataset`, `ReglaConsolidacion`, `ParserFechas`). Una base nueva cargaría
distinto de una ya migrada si esas clases cambian; lo cubre `IngestaDatasetTest`. Es un límite declarado.

**¿Por qué una secuencia para el folio y no un contador?**
Una secuencia la comparten todas las réplicas y sobrevive a los reinicios. Un contador en el proceso repetiría folios y volvería a 1
al reiniciar. A cambio los folios son únicos y crecientes pero no consecutivos.

**¿Qué aísla una base de otra?**
Un usuario por base sin privilegios globales; `REVOKE ALL ... FROM PUBLIC` sobre cada base (por omisión PostgreSQL deja conectarse
a cualquiera); y contraseñas distintas, generadas y guardadas en un volumen de solo lectura que monta solo quien las necesita. Se
comprueba con `psql` desde cada usuario hacia cada base (`21-compose-postgres-replicas-f3.txt`).

**¿Por qué reiniciar el core ya no devuelve los saldos iniciales?**
Porque ese es el objetivo: el estado vive en PostgreSQL. Para repetir una demostración, `scripts/restablecer-demo.sh`; para un
arranque en frío, `docker compose down -v`.

**¿Por qué Testcontainers 1.21.4?**
La 1.19.8 que gestiona Boot 3.3 habla con la API 1.32 de Docker y Docker Engine 29 la rechaza. La propiedad
`testcontainers.version` del POM raíz lo corrige.

---

## 5. OAuth 2.0

**Los cuatro roles, aplicados aquí.**
*Propietario del recurso* (el dueño de los datos), *cliente* (quien los pide), *servidor de autorización* (quien emite tokens) y
*servidor de recursos* (quien los guarda y los entrega a quien traiga un token válido). En `client_credentials` no interviene
ninguna persona: el cliente es un BFF, el servidor de autorización es el `auth-server` y el servidor de recursos es el core.

**El flujo `client_credentials`, paso a paso.**
1) El BFF necesita llamar al core y no tiene token. 2) Hace `POST /oauth2/token` con `grant_type=client_credentials` y sus
credenciales en `Authorization: Basic`. 3) El auth-server verifica el secreto contra su hash BCrypt, comprueba que los scopes pedidos
estén entre los registrados (si no, `invalid_scope`) y firma un JWT con su clave RSA privada. 4) El BFF guarda el token y lo manda
al core en `Authorization: Bearer`. 5) El core lo valida sin hablar con el auth-server (con la clave pública del JWKS) y atiende.
6) Unos 4 minutos y medio después, el BFF pide otro antes de que venza.

**¿Qué valida el core en un JWT, y en qué orden?**
Que haya token; su **firma** (si falla, nada de lo que dice importa); el **emisor** (`iss`); la **vigencia** (`exp`, `nbf`); y la
**audiencia** (`aud` debe incluir `core-service`). Cualquier fallo es 401. Si todo pasa, se evalúa la autorización: el scope que
exige el endpoint; si falta, 403.

**401 contra 403.**
401: "no sé quién eres" (sin token, o uno que no sirve). 403: "sé quién eres y no te lo permito" (token válido sin el scope). El
403 se arregla dando el permiso al cliente; el 401, corrigiendo el token.

**Scope, autoridad y audiencia.**
El *scope* es lo que el auth-server concede a un cliente y va en el token; una *autoridad* es cómo Spring Security representa un
permiso (cada scope pasa a `SCOPE_<scope>`); la *audiencia* dice **para qué servicio** se emitió. Un token firmado, vigente y con los
scopes correctos, pero emitido para otro servicio, se rechaza.

**Mínimo privilegio, en una frase.**
Si alguien compromete el BFF web, su token puede leer cuentas pero no retirar dinero (403): el scope `retiros:ejecutar` solo existe
para `bff-atm`.

**¿Por qué el emisor es `https://localhost:9000` y las claves se leen por `https://auth-server:9000`?**
El claim `iss` tiene que ser el mismo se pida el token donde se pida, y lo que ven los clientes de fuera es `localhost`. Pero un
contenedor no puede llamar a `localhost:9000` (sería él mismo), así que las claves se descargan por el nombre del servicio. Se fijan
por separado `issuer-uri` y `jwk-set-uri`; juntos, Spring Boot no hace descubrimiento OIDC.

**¿Por qué no se pide un token por petición?**
Serían dos peticiones por cada una de negocio, el auth-server estaría en el camino caliente de todo y una caída suya tumbaría todo
al instante. Con la caché, una caída breve no se nota mientras haya un token vigente. BCrypt (lenta a propósito) se paga una vez
por token; en el core solo se verifica una firma RSA, que es barata.

**¿Por qué `denyAll()` y no una lista de rutas protegidas?**
Con una lista, todo lo que no figura queda abierto, y se puede eludir con una variante de la URL que el filtro lea distinto que el
enrutador (así se eludía el filtro del S5). Con default-deny, lo que nadie declaró se rechaza.

**¿Cómo funciona `authorization_code` con PKCE y qué ataque evita PKCE?**
La app inventa un `code_verifier` aleatorio y manda su huella SHA-256 (`code_challenge`) al pedir autorización. El servidor la guarda,
pide login al usuario y devuelve un código de un solo uso por la redirect URI. La app canjea el código mandando el `code_verifier`
original y el servidor comprueba que su huella coincida. PKCE evita el robo del código de autorización: otra aplicación puede ver
la redirección con el código, pero sin el `code_verifier` no puede canjearlo.

**¿Por qué web y móvil son clientes "públicos" sin secreto?**
Porque su código corre en el equipo del usuario y cualquiera leería un secreto incrustado. La barrera es PKCE. Tampoco hay
pantalla de consentimiento: las dos aplicaciones son del propio banco, no hay delegación a un tercero.

**¿Por qué la redirect URI debe coincidir exactamente?**
Porque es adónde viaja el código. Si el servidor aceptara cualquier dirección, un atacante pediría autorización con la suya y
recibiría el código de la víctima. En loopback solo el puerto es libre (RFC 8252).

**¿Qué es el token CSRF del formulario de login?**
Un valor aleatorio ligado a la sesión que el formulario devuelve en cada envío. Sin él, otra página podría hacer que el navegador
del usuario inicie sesión con las credenciales del atacante. El servidor responde 403.

**¿Cómo llega el `device_id` al token móvil?**
La app lo agrega a la solicitud de autorización; Spring Authorization Server guarda esa solicitud con sus parámetros y el
personalizador del token la lee al canjear el código. Queda atado a quien inició el login. Límite honesto: no prueba posesión (quien
conoce la clave puede pedir un token con otro `device_id`), y la baja de dispositivo vive en memoria del BFF.

**¿Por qué el cajero usa un grant de extensión y no `password`?**
`password` entrega usuario y clave del titular al cliente: la RFC 9700 lo prohíbe y Spring Authorization Server no lo implementa.
Un grant de extensión (RFC 6749, 4.5) define una credencial propia (tarjeta y PIN), y como el cliente debe ser además un terminal
con secreto, solo una máquina registrada del banco puede usarlo. Se implementa con un `AuthenticationConverter` y un
`AuthenticationProvider` registrados en el endpoint de tokens.

**¿Cómo funciona el límite de intentos?**
Tres fallos seguidos bloquean 15 minutos la clave de un usuario o el PIN de una tarjeta. El bloqueo se decide **antes** de comparar,
bajo un candado por usuario o tarjeta: sin él, peticiones simultáneas pasarían todas la comprobación antes de que alguna registre su
fallo y el atacante probaría más de tres claves. Se verificó por mutación. Responde igual que una clave incorrecta.

**¿Se puede saber qué tarjetas existen?**
Casi no: "tarjeta inexistente" y "PIN incorrecto" responden igual, y un señuelo de BCrypt iguala el tiempo (~70 ms). Pero con
tres intentos se distingue una que existe (al tercer fallo responde `pin_bloqueado`) de una inexistente (siempre
`credenciales_invalidas`). Es heredado del S5 y está en las limitaciones del README.

**Si hay una sola clave de firma, ¿qué impide usar un token web en el cajero?**
La audiencia. El token web trae `aud = bff-web` y el cajero exige `bff-atm`: responde 401 `audiencia_invalida`. Es el mecanismo
correcto según la RFC 7519. La matriz 3x3 lo comprueba: la diagonal 200 y las seis celdas cruzadas 401.

**¿Por qué el BFF ya no firma nada y qué valida entonces?**
Emitir tokens es responsabilidad de un solo servicio; tenerla en cuatro lugares multiplica claves y políticas que pueden divergir.
El BFF descarga el JWKS y valida firma, algoritmo, vigencia, emisor y audiencia. No guarda ninguna clave privada.

**¿Qué reglas siguen siendo del BFF aunque el token sea válido?**
Titularidad (el `cuentaId` del token contra la cuenta pedida), permisos por canal y rol, `X-Device-Id` contra `device_id` más la baja
de dispositivo en el móvil, y el claim `terminal` registrado en el cajero. Son políticas del canal; el `auth-server` solo certifica
quién es el usuario.

**¿Por qué 503 y no 401 si el `auth-server` no responde?**
Porque 401 le dice al cliente que su token es inválido y volverá a iniciar sesión sin arreglar nada. 503 dice que el problema es del
servidor y que reintente más tarde.

**¿Por qué `expires_in` dice 1799 y el JWT dura 1800?**
El servidor calcula `expires_in` como la vigencia restante con su reloj en ese instante, que ya avanzó un segundo desde `iat`. Lo que
cuenta es `exp - iat` dentro del JWT: 1800, 3600 y 180.

**¿Qué pasa con "Spring Cloud Security"?**
El artefacto `spring-cloud-starter-security` quedó en la versión 2.2.5 de 2021 y no está en los trenes actuales. Hoy esa función
la cumplen Spring Security OAuth2 (Resource Server y Client) y Spring Authorization Server, que es lo que recomienda la guía.

**El secreto de cada cliente, ¿está guardado con hash?**
El auth-server conserva el hash BCrypt **en memoria**; el archivo de entrada en el volumen (0400, dueño 10001) tiene el valor en
claro, y la clave privada de firma vive en el mismo volumen, así que un hash en disco no sumaría protección real. Está dicho así en el
README.

**El descubrimiento OIDC anuncia grants que no usas, ¿es un problema?**
Es el catálogo por defecto de Spring Authorization Server. Cada cliente de servicio solo tiene `client_credentials`: lo demás da
`unauthorized_client` o `invalid_grant`.

---

## 6. Resilience4j

**¿Cuáles son los estados del circuit breaker y sus umbrales?**
**CLOSED**: las llamadas pasan y el circuito mira las últimas 10; cuando, con al menos 5 hechas, fallan 70 % o más, o 50 % o más son
lentas (más de 1 s), se **abre**. **OPEN**: rechaza todo sin llamar al core durante 10 s (los canales usan su respaldo o responden
503); pasado ese tiempo pasa solo a **HALF_OPEN**. **HALF_OPEN**: deja pasar 3 llamadas de prueba; si salen bien se cierra, y si
fallan vuelve a abrirse. Falla = timeout, conexión rechazada, 5xx o sin instancias; un 404 o un saldo insuficiente no lo es
(`50-resiliencia-core-caido.txt`).

**¿Por qué el Retry envuelve al CircuitBreaker?**
Cada intento tiene que pasar por el circuito y contar en él; con el circuito abierto el Retry ve el rechazo de inmediato y no
insiste. Si fuera al revés, tres intentos fallidos contarían como una sola falla y el circuito tardaría tres veces más en abrir.
Costo medido: cuando una réplica muere, la mitad de los intentos fallan aunque cada petición salga bien, y el umbral hay que ponerlo
por encima de eso (70 %).

**¿Bulkhead o rate limiter?**
El **bulkhead** limita cuántas llamadas hay **al mismo tiempo** hacia una dependencia (aislamiento de recursos: una dependencia lenta no
ocupa todos los hilos del canal). El **rate limiter** limita cuántas por unidad de tiempo, sin importar cuánto tarden. Aquí el
problema es un core lento que acumularía llamadas en vuelo: bulkhead (20, 20 y 5). Rechazar por mamparo lleno no cuenta como falla.

**¿Por qué el cajero falla cerrado?**
Entrega dinero físico: un saldo de hace un minuto es dinero que ya no existe, y un retiro "simulado" con el core caído es una entrega
sin registro. No tiene respaldo (el bean ni se crea), responde 503 con la pantalla E-090, y cada retiro viaja con su
`Idempotency-Key`.

**¿Por qué no se usa el `TimeLimiter`?**
Cancela un `Future`, así que solo sirve para llamadas asíncronas. Una llamada bloqueante se limita con el timeout del cliente HTTP
(500 ms de conexión y 2 s de lectura por intento), que corta la lectura de verdad y libera el hilo.

**¿Por qué solo se reintenta lo idempotente?**
Reintentar una operación que cambia el estado duplica su efecto. El GET no cambia nada; el retiro sí, pero viaja con una clave y el
core devuelve el mismo folio si ya lo ejecutó. El decorador `CoreClientResiliente` no reintenta un retiro sin clave; en el cajero,
si el terminal no manda clave, el canal fabrica una y reintenta con la misma, así que sigue siendo seguro.

**¿Por qué dos capas de reintento son un problema?**
Se multiplican y no se ven: el balanceador reintentaba cada GET además del Retry, y una petición tardó 12,6 s en vez de 6,5 s y
llegó al core el doble de veces. Hay un solo reintento, el de Resilience4j, y se mide (`spring.cloud.loadbalancer.retry.enabled:
false`).

**¿Por qué 500 ms de conexión y 3 intentos?**
Conectar a una réplica muerta no se rechaza: espera hasta el límite. Con 1 s, cada petición que caía en la muerta tardaba ~1,2 s y
contaba como lenta. Con 2 intentos una petición agotó sus reintentos cuando Eureka reordenó la lista; con 3 no. Resultado:
100 de 100 peticiones correctas mientras muere una réplica (`53-resiliencia-replica-muere.txt`).

**¿Qué se sirve cuando el core está caído?**
Web y móvil, el último dato conocido (menos de 10 minutos) marcado con `X-Datos-Desactualizados`, `X-Datos-Antiguedad-Segundos`,
`Warning: 110` y `Cache-Control: no-store`; si no hay dato, 503. El cajero, 503 sin saldo. Un 4xx de negocio no abre el circuito.

**¿Qué pasa si el auth-server cae?**
Los BFF siguen sirviendo mientras su token de servicio (5 minutos) esté vigente; en los últimos 30 s intentan renovar, fallan, avisan
y siguen con el vigente; vencido, 503 controlado (en web, el último dato). Siguen validando los tokens ya emitidos porque conservan
las claves públicas. Lo que no se puede es iniciar sesión de nuevo (`54-resiliencia-auth-server-caido.txt`).

**¿Qué demostró la ráfaga contra el mamparo?**
Que el exceso se rechaza al instante y se cuenta (`CALL_REJECTED`), que el circuito sigue CLOSED (rechazar no es fallar), y que
ninguna petición se pierde: cajero 5 atendidas y 15 rechazadas de 20; web 20 atendidas y 40 con respaldo de 60.

**Consecuencia del mamparo del cajero sobre los "10 retiros simultáneos".**
Antes: 5 éxitos y 5 rechazos por saldo (409). Ahora los 5 rechazos son una mezcla de 409 y 503 (estos no llegaron al core). El
invariante se mantiene: 5 éxitos y saldo final 0.

**¿Dónde hay Resilience4j además de los BFF?**
En el relay del core hacia Kafka, en la cola de eventos de seguridad del auth-server, en la pasarela de notificaciones y en el
panel del ejecutivo hacia la auditoría. El core no llama a otros servicios por red, y no hay un escenario con PostgreSQL detenido
(limitación declarada).

---

## 7. Kafka

**Tópico, partición, offset y grupo.**
Un **tópico** es un registro ordenado con nombre (`bancoxyz.retiros.v1`), partido en **particiones**; dentro de una partición el orden
está garantizado, entre particiones no. Cada mensaje tiene un **offset**. Un **grupo de consumidores** se reparte las particiones:
cada partición la lee uno solo del grupo, y cada grupo avanza por su cuenta. Por eso `notificaciones` (2 réplicas) y `auditoria`
reciben **cada uno todos** los eventos, y dentro de `notificaciones` cada evento lo procesa una sola réplica. El **lag** es
`LOG-END-OFFSET` menos `CURRENT-OFFSET`.

**¿Por qué la clave es la cuenta?**
La partición se elige con un hash de la clave. Si todos los eventos de la cuenta 116 llevan la clave `116`, caen en la misma partición
y se leen en orden: un retiro nunca se ve antes que el anterior. Entre cuentas no hace falta orden, y repartirlas entre particiones
es lo que permite escalar.

**Outbox y doble escritura.**
Guardar el retiro (PostgreSQL) y avisarlo (Kafka) son dos escrituras en dos sistemas, y ninguna transacción abarca a ambos. El
outbox escribe el evento en una tabla **en la misma transacción** del retiro (o quedan los dos o ninguno) y un relay lo publica y lo
marca. Si Kafka no está, el evento espera en la tabla: con Kafka detenido, 5 retiros respondieron 200 y sus 5 eventos se entregaron
al volver, sin duplicados (`60-kafka-eventos-f7.txt`). El costo: la entrega es "al menos una vez".

**¿Por qué un solo relay activo?**
Con dos réplicas publicando a la vez se perdería el orden por cuenta. Un lock consultivo de sesión de PostgreSQL elige una (si
muere, el motor libera el lock y la otra toma el relevo); además el relay lee con `FOR UPDATE`, así que aun si dos creyeran ser
líder no duplicarían.

**Idempotencia de los consumidores.**
Como un evento puede llegar dos veces, cada consumidor lo reconoce por su `eventId` con una clave primaria en su base: el segundo
`INSERT ... ON CONFLICT DO NOTHING` no inserta nada. Funciona entre réplicas. En notificaciones, la anotación y el envío van en la misma
transacción: si la pasarela falla, la anotación se deshace y el reintento no se confunde con un repetido.

**Reintentos bloqueantes versus no bloqueantes.**
Un reintento **bloqueante** detiene la partición hasta resolver el mensaje enfermo. Uno **no bloqueante** (`@RetryableTopic`)
republica el mensaje en un tópico de reintento con su espera y la partición sigue con el siguiente. Agotados los intentos, va a la
**DLT** (dead letter topic). Un mensaje **inválido** va directo a la DLT sin reintentos, porque daría el mismo error.

**Kafka versus JMS.**
Con JMS un mensaje se entrega a un consumidor y se borra: es una cola. Kafka conserva el registro y cada grupo lleva su propia
posición: varios servicios leen lo mismo sin interferir, un servicio nuevo puede leer el historial, y se escala con particiones y
grupos. Lo "escalable" se demuestra con la tabla de escalado.

**¿Por qué 3 particiones y por qué el cuarto consumidor no ayuda?**
Una partición la lee un solo consumidor de un grupo. Con 3 por tópico el grupo escala hasta 3; el cuarto queda con 0 particiones y no
aporta velocidad. En la evidencia: 1 consumidor 20764 ms, 3 consumidores 6924 ms (aceleración 3,00), 4 consumidores 6603 ms con uno ocioso
(`61-kafka-escalado.txt`). La diferencia entre 3 y 4 es ruido de medición (2 repeticiones; otras corridas dieron entre 2,87 y 3,14
con 3 y 4 consumidores); el costo por evento es simulado (20 ms).

**¿Por qué con 2 réplicas el reparto es 4 y 2?**
El asignador por defecto (Range) entrega 2 de cada tópico a la primera réplica y 1 de cada uno a la segunda. Con 3 queda 2, 2 y 2. No
afecta la corrección (cada partición tiene un solo consumidor).

**¿Qué pasa si cae Kafka? ¿y la auditoría?**
Si cae Kafka: los retiros siguen (el core no depende de él), los eventos esperan en el outbox y salen al volver; el login no espera (los
eventos de seguridad esperan en una cola en memoria). Si cae la auditoría: los eventos se acumulan en Kafka y los lee al volver desde
donde quedó su grupo; mientras, el panel del ejecutivo sale **sin la sección de actividad y lo avisa**.

**¿Por qué el `auth-server` no tiene outbox?**
No tiene base de datos. Su respaldo es una cola en memoria acotada: se pierde lo que haya si el proceso muere. Son eventos de
observabilidad de seguridad, no de dinero; darle una base al único servicio que no la necesita no compensa. Es un límite declarado.

**¿Qué valida el contrato de eventos?**
El **sobre** (seis campos, tipo y versión existentes). Los campos de `datos` los exige cada consumidor: notificaciones rechaza un
retiro al que le falta un dato; auditoría guarda lo que llega. No hay esquema por tipo en el contrato: limitación conocida.

**¿Cómo evoluciona el contrato?**
Un cambio compatible (campo opcional nuevo) no cambia la versión; uno incompatible se publica con `version: 2` y, si afecta a todo el
tópico, en un tópico `.v2` mientras conviven productores y consumidores de las dos versiones.

---

## 8. Verificación, evidencia y entrega

**¿Qué hace `scripts/verificar.sh` y qué NO demuestra?**
Levanta el sistema, ejecuta cada guion de verificación y los escenarios de caos, guarda la salida literal en `evidencias/salidas/` y
resume PASS o FAIL por criterio. No demuestra la ejecución en Windows o macOS con Docker Desktop, y las cifras de tiempo y memoria
son de una máquina concreta. Con `--rapido` termina en `PASS PARCIAL`: no verifica el criterio 4.

**¿Cómo se lee `evidencias/INDICE.md`?**
Cada fila es un archivo de `evidencias/`, qué demuestra y a qué criterio y puntaje responde. `verificar-entrega.sh` exige que sea
exacto en las dos direcciones (todo lo citado existe y todo lo que hay está citado) y comprueba que las cifras del README coincidan
con la evidencia.

**¿Qué cambia entre una ejecución y otra de la verificación?**
Fechas, identificadores, folios, tiempos y memoria. No cambian los PASS, los códigos HTTP ni los conteos de comprobaciones (salvo uno
o dos en `21-...`, que dependen de cuántos retiros simultáneos llegan al core antes de que el mamparo del cajero rechace el resto).

**¿Por qué las capturas esperan a que Eureka salga de `EMERGENCY`?**
Eureka entra en autopreservación el primer minuto porque aún no sabe cuántas renovaciones esperar y muestra un aviso rojo que
parecería un error.

**¿Cómo se arma la entrega?**
`scripts/empaquetar-entrega.sh Nombres_Apellidos` crea `Exp3_S8_Nombres_Apellidos.zip` con una sola carpeta raíz que lleva el código, el
README, `docs/` y `evidencias/`. Excluye secretos, certificados, `target/`, `run/`, respaldos y `docs/enunciado/` (los documentos
oficiales llevan aviso de derechos reservados de Duoc UC), y al terminar vuelve a abrir el zip para comprobarlo.

**¿Por qué no hay CI/CD?**
No se pidió, y mientras el repositorio fue privado cada corrida gastaba minutos de la cuota del usuario. La verificación es local, con
`scripts/verificar.sh`. El flujo que existió brevemente se retiró y no se usa.

---

## 9. Preguntas incómodas

**¿Qué NO está verificado?**
La ejecución en Windows y macOS con Docker Desktop (el entorno de desarrollo es Linux con Docker Engine); sí se probaron los scripts con
el `bash` 3.2 de macOS y un clon con `core.autocrlf=true`. Tampoco hay un escenario con PostgreSQL detenido ni alta disponibilidad de
PostgreSQL y Kafka.

**¿Qué es lo más débil de la seguridad?**
Los tramos internos van por HTTP dentro de una red que no sale del host (en producción serían TLS mutuo); el estado de los bloqueos y
de las bajas de dispositivo vive en memoria; la baja de dispositivo no prueba posesión; y `secretos-init` corre como root unos segundos.
Todo está en las limitaciones del README.

**¿Por qué el core no tiene Resilience4j?**
Porque no llama a otros servicios por red: recibe llamadas. Quienes llaman a dependencias remotas (los BFF, el relay hacia Kafka, la
cola de seguridad, la pasarela) son quienes llevan el circuito. La base de datos se gestiona con el pool de conexiones.

**¿Por qué no hay API Gateway?**
Cada BFF ya es la puerta de su canal; un gateway delante volvería a centralizar lo que el patrón separó, y la pauta no lo pide.

**¿Qué haría distinto con más tiempo?**
TLS mutuo interno, un respaldo programado, un escenario de PostgreSQL detenido, esquemas por tipo de evento, y Kafka y PostgreSQL en
varios nodos.
