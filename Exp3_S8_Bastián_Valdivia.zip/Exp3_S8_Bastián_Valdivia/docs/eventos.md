# Eventos de dominio: contrato y arquitectura de mensajería

Documento de referencia de la mensajería asíncrona del Banco XYZ (fase F7 del plan). Dice qué viaja por
Kafka, con qué forma, quién lo publica, quién lo consume y qué garantías da cada pieza. Lo que aquí se
afirma lo comprueban las pruebas (`./mvnw -B verify`) y las demostraciones de
`planificacion/bitacora/F7.md`.

## 1. Tópicos

| Tópico | Productor | Clave del registro | Particiones | Tipos de evento |
|---|---|---|---|---|
| `bancoxyz.retiros.v1` | `core-service` (relay del outbox) | número de cuenta (`116`) | 3 | `RETIRO_EJECUTADO` |
| `bancoxyz.seguridad.v1` | `auth-server` | usuario (`cliente116`) o tarjeta enmascarada (`400000******0116`) | 3 | `LOGIN_FALLIDO`, `USUARIO_BLOQUEADO`, `PIN_INCORRECTO`, `TARJETA_BLOQUEADA` |

Se crean de forma declarativa con `docker/kafka/crear-topicos.sh` (servicio `kafka-init` del compose):
el broker tiene `auto.create.topics.enable=false`, de modo que un nombre mal escrito no crea un tópico
fantasma con una sola partición.

**Por qué la clave es la cuenta.** Kafka garantiza el orden **dentro de una partición**, y la partición
se decide con un hash de la clave. Si todos los eventos de la cuenta 116 llevan la clave `116`, caen en la
misma partición y se leen en el orden en que ocurrieron. Entre cuentas distintas no hay orden (ni hace
falta). El mismo criterio vale para el usuario o la tarjeta en el tópico de seguridad.

**Por qué 3 particiones.** Es el techo de consumidores útiles por grupo: un grupo con 4 consumidores deja
uno ocioso. Con 3 se demuestra el reparto entre 2 réplicas, el escalado a 3 y el consumidor ocioso al
llegar a 4 (medido en `planificacion/bitacora/F7.md`).

El sufijo `.v1` es la versión del contrato del tópico (sección 5).

## 2. El sobre

Todo evento viaja dentro del mismo sobre JSON. Son seis campos y los seis son obligatorios. El código que
lo escribe y lo valida es el módulo `eventos-contrato` (`SobreEvento`, `CodecEventos`), compartido por los
productores y los consumidores para que nunca se desvíen.

```json
{
  "eventId": "08051238-dd05-4b55-980b-0f88021b883a",
  "tipo": "RETIRO_EJECUTADO",
  "version": 1,
  "ocurridoEn": "2026-10-03T03:37:02.389691479Z",
  "origen": "core-service",
  "datos": {
    "cuentaId": 116,
    "folio": "RET-20261003-000057",
    "monto": 1000.00,
    "saldoAnterior": 11000.00,
    "saldoPosterior": 10000.00,
    "movimientoId": 743,
    "moneda": "CLP"
  }
}
```

| Campo | Tipo | Significado |
|---|---|---|
| `eventId` | UUID en texto | Identificador único del evento. Es la **clave de idempotencia** de los consumidores. |
| `tipo` | texto | Qué ocurrió (`RETIRO_EJECUTADO`, ...). |
| `version` | entero desde 1 | Versión del formato de `datos` para ese tipo. |
| `ocurridoEn` | instante ISO-8601 en UTC | Cuándo ocurrió el hecho (no cuándo se publicó ni cuándo se procesó). |
| `origen` | texto | Servicio que lo emitió (`core-service`, `auth-server`). |
| `datos` | objeto JSON | Contenido propio del tipo (sección 3). |

La clave del registro de Kafka no va dentro del sobre: es metadato del transporte. Además cada registro
lleva la cabecera `eventId` con el mismo valor del sobre, para que `kafka-ui` y los consumidores lo
identifiquen sin leer el cuerpo.

**Un mensaje que incumple el contrato del sobre** (no es JSON, falta uno de los seis campos, el `eventId` no es un UUID, la
`version` no es un entero, el tipo o la versión no están definidos) se rechaza con
`EventoInvalidoException`, que los consumidores tratan como error permanente: va directo a la DLT sin
reintentos y sin detener el consumo de la partición.

**Qué valida el contrato y qué valida cada consumidor.** `CodecEventos` valida el **sobre** (los seis campos, su
tipo y que el tipo y la versión existan), no el contenido de `datos`. Los campos de `datos` los exige cada consumidor
según lo que necesita: `notificaciones-service` rechaza un `RETIRO_EJECUTADO` al que le falta un dato para componer el
mensaje (`EventoInvalidoException`, va a la DLT), mientras que `auditoria-service` guarda el evento tal como llega, con
los campos ausentes en cero. Es una limitación conocida: no hay un esquema por tipo que se aplique en el contrato.

## 3. Eventos

### 3.1 `RETIRO_EJECUTADO` v1 (tópico `bancoxyz.retiros.v1`)

Lo emite el core cuando un retiro queda **confirmado** en su base. Un reintento con la misma
`Idempotency-Key` no emite un segundo evento (solo hay evento si hubo descuento).

| Campo de `datos` | Tipo | Significado |
|---|---|---|
| `cuentaId` | entero | Cuenta de la que se retiró. |
| `folio` | texto | Folio del comprobante (`RET-yyyyMMdd-NNNNNN`). |
| `monto` | número decimal | Importe retirado. |
| `saldoAnterior` | número decimal | Saldo antes del retiro. |
| `saldoPosterior` | número decimal | Saldo después. |
| `movimientoId` | entero largo | Id del movimiento que el retiro dejó en el historial del core. |
| `moneda` | texto | Código de moneda (`CLP`). |

### 3.2 Eventos de seguridad v1 (tópico `bancoxyz.seguridad.v1`)

Los emite el `auth-server`. **Nunca llevan una clave, un PIN ni un número de tarjeta completo**: la tarjeta
va enmascarada (primeros 6 y últimos 4 dígitos). Los campos que no aplican a un tipo se omiten del JSON.

| Tipo | Cuándo se emite | `motivo` | Otros campos de `datos` |
|---|---|---|---|
| `LOGIN_FALLIDO` | Una clave de usuario web o móvil fue rechazada | `clave_incorrecta`; `usuario_bloqueado` (intento con el usuario ya bloqueado, aunque la clave sea la correcta); `usuario_desconocido` (el nombre no existe) | `sujeto` (usuario), `intentosFallidos` y `intentosRestantes` (en `clave_incorrecta`), `bloqueadoHasta` (en `usuario_bloqueado`) |
| `USUARIO_BLOQUEADO` | La tercera clave errada seguida bloqueó al usuario | `intentos_agotados` | `sujeto`, `intentosFallidos`, `bloqueadoHasta` |
| `PIN_INCORRECTO` | El PIN de una tarjeta fue rechazado en un cajero | `pin_incorrecto`; `tarjeta_desconocida` (la tarjeta no existe; si lo recibido no puede ser un número de tarjeta, el `sujeto` es `****`) | `sujeto` (tarjeta enmascarada), `terminal`, `intentosFallidos` y `intentosRestantes` (en `pin_incorrecto`) |
| `TARJETA_BLOQUEADA` | El tercer PIN errado seguido bloqueó la tarjeta, o se intentó usar una tarjeta ya bloqueada | `intentos_agotados`; `intento_con_tarjeta_bloqueada` (aunque el PIN sea el correcto) | `sujeto`, `terminal`, `intentosFallidos`, `bloqueadoHasta` |

El tercer fallo seguido publica dos eventos: el de fallo (`LOGIN_FALLIDO` o `PIN_INCORRECTO`, con `intentosRestantes`
en 0) y el de bloqueo. El nombre de un usuario inexistente lo escribe quien ataca: se recorta a 64 caracteres y se
limpian los caracteres de control antes de publicarlo. Un inicio de sesión correcto no publica nada.

## 4. Entrega y orden: las garantías y su costo

### 4.1 Del core a Kafka: el patrón outbox

Guardar el retiro y publicar el evento son dos escrituras en dos sistemas, y ninguna transacción abarca
a ambos (la **doble escritura**). Si se descuenta y falla la publicación, el retiro existe y nadie se
entera; si se publica y falla el descuento, se avisa de algo que no ocurrió.

La solución es el **outbox**: el evento se escribe en la tabla `outbox` del core **en la misma
transacción** que el descuento (`RetiroService`, migración `V4__outbox.sql`). O quedan los dos o no queda
ninguno. Un proceso aparte, el **relay** (`RelayOutbox`), lee lo pendiente y lo publica en Kafka. Si Kafka
no está, el evento espera en la tabla y se entrega cuando vuelve: **el retiro nunca depende de Kafka**.

```text
retiro  ──(misma transacción)──►  cuenta (UPDATE) + movimiento + outbox (INSERT)
                                              │
              relay del líder (lock consultivo) ── lee lo pendiente (FOR UPDATE) ──► Kafka (acks=all)
                                              │
                                  marca "publicado" lo que Kafka confirmó
```

* **Un solo relay activo.** Con dos réplicas publicando a la vez se perdería el orden por cuenta. Las
  réplicas compiten por un **lock consultivo de PostgreSQL** (`pg_try_advisory_lock`) que el líder
  conserva en una conexión dedicada: la otra réplica espera y toma el relevo si el líder cae (PostgreSQL
  libera el lock al cerrarse su conexión). Además el relay lee con `FOR UPDATE`, así que aun si dos relays
  coincidieran no duplicarían ni desordenarían.
* **Orden por cuenta.** El `INSERT` del outbox se hace después del `UPDATE` de la cuenta, y ese `UPDATE`
  bloquea la fila hasta el commit: dos retiros de la misma cuenta se serializan, y sus eventos quedan en el
  outbox en el orden de confirmación. El relay publica por `id` ascendente; el productor es idempotente
  (los reintentos del cliente no reordenan); y la clave lleva la cuenta a una sola partición.
* **Productor** (`config-repo/application.yml`): `acks=all`, `enable.idempotence=true`, compresión `lz4`,
  lotes (`linger.ms=20`, `batch.size=32768`) y plazos acotados (`delivery.timeout.ms=5000`,
  `max.block.ms=2000`) para que un Kafka caído no cuelgue al relay.
* **Resilience4j** (`PublicadorKafka`): `CircuitBreaker` y `Retry` alrededor del envío. Con Kafka caído el
  circuito se abre y el relay deja de insistir (rechazo instantáneo) hasta que una llamada de prueba
  confirme que volvió. El respaldo es el propio outbox: nada se pierde.

**Garantía resultante: al menos una vez.** Si el relay publica y cae antes de marcar la fila, o si un lote
que el productor dio por vencido igual llegó al broker, el evento se publica de nuevo. Por eso **todo
consumidor es idempotente por `eventId`**. Lo que no puede ocurrir es perder un evento.

**Límite conocido del orden.** El orden por cuenta se conserva salvo en un caso: un fallo *parcial* dentro
de un lote (un evento no se confirma y uno posterior de la misma cuenta sí). El relay marca solo el prefijo
confirmado, así que el evento posterior se reenvía junto con el anterior y puede quedar por delante de él
en el log. Cerrarlo exigiría enviar de a un evento y esperar cada confirmación, y con ello renunciar a los
lotes. Se acepta porque la primera aparición de cada evento sigue respetando el orden de la cuenta (lo
comprueba `RelayConKafkaCaidoTest`) y los consumidores aplican cada `eventId` una sola vez.

## 5. Compatibilidad y versiones

* **Cambio compatible** (agregar un campo opcional a `datos`): no cambia la versión. La lectura es
  tolerante con los campos que no conoce, así que un productor más nuevo no rompe a un consumidor viejo
  (lo comprueba `CodecEventosTest`).
* **Cambio incompatible** (quitar o renombrar un campo, cambiar su significado): se publica con
  `version: 2` y, si el cambio afecta a todo el tópico, en un tópico nuevo `.v2`. Productores y
  consumidores de las dos versiones conviven mientras migran.
* Un consumidor que recibe un tipo o una versión que no conoce no adivina: rechaza el mensaje a la DLT.
  El catálogo de lo que el sistema entiende hoy es `TiposEvento`.

## 6. Productores y consumidores

| Servicio | Papel | Tópicos | Grupo | Réplicas |
|---|---|---|---|---|
| `core-service` | Productor (outbox y relay) | `bancoxyz.retiros.v1` | no aplica | 2 (publica una sola a la vez: el líder) |
| `auth-server` | Productor (cola en memoria) | `bancoxyz.seguridad.v1` | no aplica | 1 |
| `notificaciones-service` | Consumidor: avisa por una pasarela simulada | ambos | `notificaciones` | 2 (hasta 3 útiles) |
| `auditoria-service` | Consumidor: guarda cada evento y lo ofrece por una API | ambos | `auditoria` | 1 |

**Cada grupo recibe todos los eventos.** Dentro de un grupo, Kafka reparte las particiones entre sus
consumidores (cada evento lo procesa uno solo); entre grupos no se reparte nada: `notificaciones` y `auditoria`
reciben, cada uno por su cuenta, todos los eventos de los dos tópicos y avanzan a su ritmo. Si uno se atrasa
o cae, el otro no se entera.

### 6.1 Idempotencia por `eventId`

Como la entrega es al menos una vez, un consumidor tiene que tolerar el repetido. Ambos lo hacen con la clave
primaria `event_id` de su propia base:

* **notificaciones** (`evento_procesado` y `notificacion`): en una sola transacción anota el `eventId`,
  compone el mensaje, lo envía por la pasarela y guarda la notificación. Si el `eventId` ya estaba, descarta
  el evento sin avisar de nuevo. Si la pasarela falla, la transacción se deshace *incluida la anotación del
  `eventId`*: el reintento no se confunde con un repetido y el aviso no se pierde.
* **auditoría** (`evento_auditado`): un solo `INSERT ... ON CONFLICT DO NOTHING`. El propio registro auditado
  es la marca de que el evento ya se vio.

Funciona también entre réplicas: si dos reciben el mismo evento a la vez, la clave primaria hace esperar a la
segunda hasta que la primera confirme, y la segunda ve el conflicto (lo comprueban las pruebas con seis hilos
sobre el mismo evento).

### 6.2 Reintentos no bloqueantes y DLT

Un reintento **bloqueante** detiene la partición: nada avanza hasta que el mensaje enfermo se resuelve. Un
reintento **no bloqueante** (`@RetryableTopic` de Spring Kafka) republica el mensaje fallido en un tópico de
reintento con su espera y deja que la partición siga con el siguiente. Tras agotar los intentos, el mensaje
va a la DLT (dead letter topic: el tópico donde termina lo que no se pudo procesar).

| Causa del fallo | Tipo | Qué ocurre |
|---|---|---|
| La pasarela falla, el circuito está abierto o el mamparo lleno (notificaciones); la base falla (auditoría) | transitorio | Pasa por los tópicos de reintento (5 intentos, espera exponencial de 2 s a 16 s) y, si no se resuelve, a la DLT |
| El mensaje incumple el contrato (no es JSON, falta un campo, tipo o versión desconocidos) | permanente (`EventoInvalidoException`) | Va **directo** a la DLT, sin reintentos: reintentarlo daría el mismo error |

Los tópicos de reintento y la DLT llevan el nombre del grupo: `<tópico>-notificaciones-retry-<espera>` y
`<tópico>-notificaciones-dlt` (y `-auditoria-` para la auditoría). Sin el grupo en el nombre, los dos grupos
compartirían el tópico de reintento y cada reintento de uno lo vería también el otro. Se crean al arrancar cada
consumidor, con las mismas 3 particiones. Cada mensaje que llega a la DLT queda además anotado, con su causa,
en la tabla `carta_muerta` de la base del servicio.

### 6.3 La pasarela de envío (notificaciones)

`PasarelaSimulada` espera `notificaciones.pasarela.latencia-ms` y falla con la probabilidad
`notificaciones.pasarela.tasa-fallo`; una latencia mayor que `timeout-ms` se corta con un timeout. Está
protegida por Resilience4j (`PasarelaProtegida`): `Retry` (3 intentos de 100 ms), `CircuitBreaker` (50 % de
fallos o de llamadas lentas en las últimas 10, abierto 10 s) y `Bulkhead` (10 simultáneas). Cuando todo eso se
agota, la excepción sube al consumidor y los reintentos no bloqueantes toman el relevo. Los valores se cambian
en caliente con `POST /actuator/refresh`.

### 6.4 Eventos de seguridad: el login nunca espera a Kafka

El `auth-server` publica desde pleno inicio de sesión, así que enviar a Kafka desde ese hilo haría esperar al
usuario cada vez que Kafka falla. `PublicadorEventosSeguridad` deja el evento en una cola acotada en memoria
(`offer`, que nunca espera) y un hilo de fondo lo entrega con `CircuitBreaker` y `Retry` de Resilience4j. Con
Kafka caído, los eventos esperan en la cola y se entregan en orden al volver; lo que excede la capacidad se
descarta y se cuenta (`eventos.seguridad.descartados`).

Un evento que Kafka rechaza **para siempre** (demasiado grande, no serializable) no es una caída de Kafka: `EnvioKafka`
lo distingue (`EventoRechazadoException`), no cuenta para el circuito ni se reintenta, y el publicador lo descarta con
su log y la métrica `eventos.seguridad.rechazados` en lugar de devolverlo al frente de la cola, donde detendría a los
eventos legítimos que le siguen. Además, el sujeto que viene de la petición (el número de tarjeta que escribe quien
llama) tiene cota: solo lo que puede ser un número de tarjeta (11 a 19 dígitos) se enmascara y se refleja, y un sobre
de más de 64 KiB ni entra en la cola.

**Límite honesto:** a diferencia del core, el `auth-server` no tiene base de datos donde guardar un outbox. Su
respaldo es memoria: se pierde lo que haya en la cola si el proceso muere, y se descarta lo que exceda su
capacidad durante una caída larga. Son eventos de observabilidad de seguridad, no de dinero, y darle una base
al único servicio que no la necesita no compensa.

### 6.5 La API de auditoría y el panel del ejecutivo

`auditoria-service` expone `GET /internal/v1/auditoria/eventos` (filtros `tipo`, `cuenta`, `sujeto`; paginado,
del más reciente al más antiguo) y `GET /internal/v1/auditoria/resumen`. Es un servidor de recursos OAuth2:
valida la firma con el JWKS del auth-server, el emisor, la vigencia y la audiencia `auditoria-service`, y exige
el scope `auditoria:leer` (todo lo demás, denegado). Sin token responde 401; con un token válido sin ese scope,
403.

Su cliente es `bff-web`, que llama con su token de servicio (el auth-server se lo emite con las audiencias
`core-service` y `auditoria-service`) a través de `AuditoriaClientResiliente` (`Retry`, `CircuitBreaker` y
`Bulkhead` de 10). La consume el panel del ejecutivo, `GET /api/web/v1/admin/panel`: si el auditoría no
responde, el panel sale **sin esa sección y lo avisa** (`actividad.disponible=false` con un aviso), con la
calidad de datos intacta, en vez de fallar entero.

## 7. Diagrama de la arquitectura de eventos

Líneas continuas: el camino normal. Líneas punteadas: el camino de fallo (reintentos no bloqueantes y DLT). Cada
tópico de negocio tiene sus tópicos de reintento y su DLT por grupo, todos de 3 particiones.

```mermaid
flowchart LR
  subgraph Productores
    CORE["core-service x2<br/>retiro + outbox (misma transaccion)"]
    RELAY["relay del lider<br/>lock consultivo de PostgreSQL"]
    AUTH["auth-server<br/>cola en memoria + Resilience4j"]
  end
  PG[("PostgreSQL<br/>base core: tabla outbox")]
  subgraph Kafka["Kafka (KRaft, 3 particiones por topico)"]
    TR["bancoxyz.retiros.v1<br/>clave: cuenta"]
    TS["bancoxyz.seguridad.v1<br/>clave: usuario o tarjeta"]
    RN["...-notificaciones-retry-2000 a 16000"]
    DN["...-notificaciones-dlt"]
    RA["...-auditoria-retry-2000 a 16000"]
    DA["...-auditoria-dlt"]
  end
  subgraph GN["grupo notificaciones (2 replicas, hasta 3 utiles)"]
    N1["notificaciones-service #1"]
    N2["notificaciones-service #2"]
  end
  subgraph GA["grupo auditoria"]
    A1["auditoria-service"]
  end
  PASARELA["pasarela simulada<br/>CircuitBreaker, Retry, Bulkhead"]
  DBN[("base notificaciones<br/>evento_procesado, notificacion, carta_muerta")]
  DBA[("base auditoria<br/>evento_auditado, carta_muerta")]
  WEB["bff-web<br/>panel del ejecutivo<br/>Resilience4j + token de servicio"]
  UI["kafka-ui 127.0.0.1:8090"]

  CORE --> PG
  PG --> RELAY
  RELAY -->|acks=all, idempotente| TR
  AUTH -->|eventos de seguridad| TS
  TR --> N1
  TR --> N2
  TS --> N1
  TS --> N2
  TR --> A1
  TS --> A1
  N1 --> PASARELA
  N2 --> PASARELA
  N1 --> DBN
  N2 --> DBN
  A1 --> DBA
  N1 -. fallo transitorio .-> RN
  RN -. reintento con espera .-> N1
  RN -. intentos agotados o mensaje invalido .-> DN
  A1 -. fallo transitorio .-> RA
  RA -. intentos agotados o mensaje invalido .-> DA
  WEB -->|GET /internal/v1/auditoria, scope auditoria:leer| A1
  UI -.-> Kafka
```

## 8. Escalado medido

`scripts/medir-escalado.sh` procesa el **mismo lote** de 900 eventos con 1, 3 y 4 consumidores del grupo
`notificaciones` (2 repeticiones por fila en la verificación integral; cada evento cuesta 20 ms de pasarela más una
escritura en la base; un hilo por réplica; lote repartido por igual entre las 3 particiones de cada tópico). Medido en
un equipo de 4 CPU, con el resto del compose en marcha y `auditoria-service` detenido durante la prueba. La tabla
siguiente es la de `evidencias/salidas/61-kafka-escalado.txt`.

| Consumidores | Procesamiento del lote (ms) | Promedio (ms) | Eventos/s | Aceleración | Consumidores ociosos |
|---|---|---|---|---|---|
| 1 | 21021 / 20508 | 20764 | 43,3 | 1,00 | 0 |
| 3 | 6917 / 6932 | 6924 | 130,0 | 3,00 | 0 |
| 4 | 6856 / 6350 | 6603 | 136,3 | 3,14 | **1** |

Con 3 consumidores cada uno toma 2 particiones (una de cada tópico) y el tiempo baja a un tercio. El cuarto consumidor
**queda ocioso**: el grupo lo tiene registrado con 0 particiones (`kafka-consumer-groups --describe --members`), porque
una partición la atiende un solo consumidor del grupo, y por eso el tiempo con 4 (6603 ms) no mejora de forma significativa
al de 3 (6924 ms). El techo de escalado de un grupo lo fija el número de particiones del tópico, y por eso los tópicos
tienen 3.

**Cómo leer la tabla con honestidad.** Con solo 2 repeticiones por fila, las cifras de tiempo varían del orden del 8 %
entre corridas: otras corridas del mismo guion dieron una aceleración con 3 consumidores de 2,87, 2,88, 2,93, 3,00 y 3,02, y con
4 consumidores de hasta 3,14, es decir, por encima del ideal de 3,00, lo que es ruido de medición y no un beneficio de los
consumidores. Lo que no cambia entre corridas es lo estructural: el tiempo con 3 es cerca de un tercio del de 1 y el cuarto
consumidor queda con 0 particiones. Además el costo por evento es simulado (un `sleep` de 20 ms), no trabajo real.

**Reparto con 2 réplicas.** El asignador por defecto (Range) reparte las 6 particiones (3 por tópico) entre 2
réplicas como 4 y 2: la primera recibe 2 de cada tópico y la segunda 1 de cada uno (se ve en
`evidencias/salidas/77-ms-notificaciones-service.txt`). Con 3 réplicas queda 2, 2 y 2. Un asignador
`RoundRobin` daría 3 y 3 con dos réplicas; no se cambió porque el reparto 4 y 2 no afecta la corrección (cada
partición tiene un solo consumidor) y se dejó el comportamiento por defecto de Kafka.
