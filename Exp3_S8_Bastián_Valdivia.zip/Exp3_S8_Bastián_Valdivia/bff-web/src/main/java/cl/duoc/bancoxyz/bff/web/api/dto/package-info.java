/**
 * Los DTO de <strong>respuesta</strong> del canal web, y de ningun otro canal.
 *
 * <p><strong>Por que este paquete existe y por que estas clases no estan en
 * {@code plataforma-comun}.</strong> Es la invariante que define el proyecto completo. Un
 * Backend for Frontend existe para entregar a cada cliente la forma exacta que ese cliente
 * necesita. Si los tres canales compartieran las clases de respuesta, las tres respuestas
 * tendrian por fuerza los mismos campos, y entonces los tres BFF serian el mismo servicio
 * desplegado tres veces en tres puertos distintos. El patron no aportaria nada.
 *
 * <p>La consecuencia incomoda, y que hay que sostener a proposito: aqui hay clases que se
 * parecen mucho a clases de {@code bff-mobile} y de {@code bff-atm}. Por ejemplo, el objeto de
 * paginacion del canal web tiene los mismos cuatro campos que el del core. <strong>Esa
 * duplicacion es intencional</strong>, no un descuido. Es lo que permite que manana el canal web
 * agregue un campo {@code totalPaginasVisibles} a su paginacion sin tocar una sola linea de los
 * otros dos canales ni obligarlos a redesplegar.
 *
 * <p><strong>Que SI se comparte con los otros canales.</strong> El mecanismo, nunca la forma de
 * salida:
 * <ul>
 *   <li>{@code CoreClient} y los DTO de {@code cl.duoc.bancoxyz.comun.core.dto}, que son el
 *       contrato <em>aguas arriba</em>. Hay un solo {@code core-service}, luego hay un solo
 *       contrato con el. Esos DTO describen lo que el core dice, no lo que este canal responde.</li>
 *   <li>{@code RespuestaError}, el envoltorio RFC 7807. El envoltorio uniforme es calidad; el
 *       contenido que cada canal mete dentro es adaptacion.</li>
 * </ul>
 *
 * <p><strong>Como se leen los nombres de campo.</strong> Todos estan congelados en la seccion 5
 * del contrato. Un record de Java serializa sus componentes en el orden en que estan declarados,
 * asi que el orden de declaracion de cada record de este paquete replica a proposito el orden de
 * la tabla del contrato: cambiar el orden no rompe a ningun cliente, pero hace mas dificil
 * comparar la respuesta real contra el documento a simple vista.
 */
package cl.duoc.bancoxyz.bff.web.api.dto;
