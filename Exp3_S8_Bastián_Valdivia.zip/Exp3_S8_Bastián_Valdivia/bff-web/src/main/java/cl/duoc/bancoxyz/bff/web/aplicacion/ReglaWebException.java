package cl.duoc.bancoxyz.bff.web.aplicacion;

import cl.duoc.bancoxyz.comun.error.MotivosError;

/**
 * Las reglas propias del canal web que rechazan una peticion: hoy, la cuenta ajena en la consulta
 * (titularidad). La credencial invalida ya no es de este canal: el login vive en el {@code auth-server}.
 *
 * <h2>Rol en la arquitectura</h2>
 *
 * <p>Es el vehiculo con el que la capa de aplicacion le dice al manejador de errores "esto se
 * rechaza, con este codigo y con este motivo", sin tocar una sola clase de HTTP. El servicio decide
 * <strong>que regla se rompio</strong>; el {@code ManejadorErroresWeb} decide <strong>como se ve
 * eso por el cable</strong>. Si el servicio devolviera un {@code ResponseEntity}, la capa de
 * aplicacion habria pasado a conocer el transporte y ya no podria probarse sin el.
 *
 * <p>El {@code estado} viaja dentro de la excepcion, y no es una contradiccion con lo anterior: es
 * el canal quien decide que su cuenta ajena vale 403, y este es codigo del canal. Lo que no hace esta clase es escribir cabeceras, elegir tipo de medio ni serializar
 * nada.
 *
 * <h2>Por que NO extiende IllegalArgumentException</h2>
 *
 * <p>Detalle que parece menor y romperia el canal entero. {@code ManejadorErroresWeb} ya declara un
 * manejador para {@code IllegalArgumentException} que devuelve <strong>400
 * {@code peticion_invalida}</strong>, porque es como se rechaza un {@code ?tipo=TRANSFERENCIA}.
 * Spring elige siempre el manejador mas especifico segun la jerarquia de la excepcion, asi que si
 * esta clase heredara de aquella y alguien olvidara declarar su propio manejador, un intento de
 * leer una cuenta ajena saldria como 400 "revise el formato de las fechas". Heredando de
 * {@code RuntimeException} ese parentesco no existe.
 *
 * <h2>Por que hay una fabrica y no un constructor publico</h2>
 *
 * <p>Para que los motivos que este canal puede emitir por su cuenta esten enumerados en un solo
 * archivo y no se puedan inventar desde fuera. Un {@code new ReglaWebException(403, "cuenta-ajena")}
 * escrito a mano en cualquier servicio produciria una respuesta que a simple vista se ve perfecta y
 * que hace fallar la evidencia, porque el guion lee {@code motivo} y ahi el guion medio no es el
 * guion bajo.
 */
public class ReglaWebException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final int estado;
    private final String motivo;
    private final String titulo;
    private final String detalle;

    private ReglaWebException(int estado, String motivo, String titulo, String detalle,
                              String mensajeParaElLog) {
        super(mensajeParaElLog);
        this.estado = estado;
        this.motivo = motivo;
        this.titulo = titulo;
        this.detalle = detalle;
    }

    /**
     * 403: el token es valido y no acredita titularidad sobre la cuenta pedida.
     *
     * <p><strong>Es 403 y no 404 aunque la cuenta no exista</strong>, y el orden de comprobacion que
     * lo consigue esta congelado en la seccion 7.4 del contrato: la titularidad se comprueba antes
     * de preguntarle al core si la cuenta existe. Si fuera al reves, las cuentas existentes darian
     * 403 y las inexistentes 404, y comparar las dos respuestas convertiria el canal en un
     * <strong>detector de cuentas</strong> para cualquiera con un token valido.
     *
     * <p>El detalle si nombra la cuenta pedida, y no es una fuga: ese numero lo escribio el propio
     * cliente en la URL, asi que la respuesta no le esta contando nada que no supiera. Lo que jamas
     * viaja es la cuenta que el token SI acredita, que es un dato de otra persona.
     */
    public static ReglaWebException cuentaAjena(Integer cuentaDelToken, int cuentaDeLaRuta) {
        return new ReglaWebException(403, MotivosError.CUENTA_AJENA,
                "Acceso denegado",
                "El token no acredita titularidad sobre la cuenta " + cuentaDeLaRuta,
                "Titularidad rechazada: el token acredita la cuenta " + cuentaDelToken
                        + " y la ruta pidio la " + cuentaDeLaRuta + ".");
    }

    /** Codigo HTTP que el canal decidio para esta regla. */
    public int estado() {
        return estado;
    }

    /** Literal congelado de {@link MotivosError}. Es el campo que leen los guiones de evidencia. */
    public String motivo() {
        return motivo;
    }

    /** Titulo corto y estable del cuerpo RFC 7807. */
    public String titulo() {
        return titulo;
    }

    /** Texto explicativo que si viaja al cliente. Nunca el mensaje de la excepcion. */
    public String detalle() {
        return detalle;
    }
}
