package cl.duoc.bancoxyz.bff.web.api.dto;

import java.math.BigDecimal;
import java.util.List;

/**
 * La respuesta de {@code GET /api/web/v1/cuentas/{id}}: el objeto <strong>W2</strong> del
 * contrato, y la pieza que justifica que este canal exista.
 *
 * <p><strong>Principio del canal: una peticion llena la pantalla completa.</strong> El navegador
 * esta en una red buena y frente a una pantalla grande, asi que el costo dominante no son los
 * bytes sino los <em>viajes</em>. Una pantalla de detalle de cuenta necesita tres cosas: la ficha
 * del titular, los totales de la cabecera y la tabla de movimientos con sus controles de
 * paginacion. Sin BFF, eso son tres peticiones desde el navegador, cada una con su latencia de
 * ida y vuelta por internet y su propio manejo de errores en el codigo de la interfaz.
 *
 * <p>Este objeto entrega las tres en una. Y hay una simetria que conviene ver: aguas arriba, el
 * BFF tambien resuelve todo con <strong>una sola llamada</strong> al {@code core-service}
 * ({@code GET /internal/v1/cuentas/{id}}, que ya trae la cuenta con todos sus movimientos). Una
 * peticion entra, una peticion sale, y en el medio el BFF calcula el resumen y recorta los
 * movimientos.
 *
 * <p><strong>Comparacion con los otros dos canales, sobre la misma cuenta 116.</strong> El core
 * entrega la ficha completa mas 42 movimientos de 5 campos. Este canal entrega la ficha, un
 * resumen que el core no tiene, 20 movimientos de 4 campos y la paginacion. El movil entrega el
 * saldo y 5 movimientos de 3 campos con el titular abreviado. El cajero entrega dos campos.
 * Cuatro respuestas claramente distintas del mismo recurso, y esa diferencia es la evidencia de
 * que los canales estan optimizados de verdad.
 *
 * <p>Los nombres y el orden de los campos estan congelados en la seccion 5.8 del contrato.
 *
 * @param cuentaId    identificador de la cuenta, 101 a 150
 * @param titular     nombre <strong>completo</strong>. El canal web lo entrega entero; el movil
 *                    lo abrevia a {@code D. Prince}, porque en un telefono el nombre compite por
 *                    el ancho con el saldo
 * @param tipoCuenta  {@code AHORRO}, {@code HIPOTECA} o {@code PRESTAMO}
 * @param saldo       saldo actual, {@code BigDecimal} serializado como numero JSON
 * @param moneda      literal {@code CLP}. Se propaga tal como lo entrega el core en vez de
 *                    escribirlo aqui: el dia que el banco opere en dos monedas, el canal ya
 *                    esta dando la respuesta correcta sin cambios
 * @param edadTitular edad del titular. Se llama asi y no {@code edad}
 * @param resumen     los agregados que <strong>calcula este BFF</strong>. Ver
 *                    {@link ResumenWebResponse}
 * @param movimientos <strong>primera pagina</strong> de movimientos, 20 como maximo, de cuatro
 *                    campos cada uno. Lista vacia, nunca {@code null}, para la cuenta 130
 * @param paginacion  cuantas paginas mas hay. Permite a la tabla dibujar sus controles sin una
 *                    segunda peticion solo para contar
 */
public record CuentaWebResponse(
        int cuentaId,
        String titular,
        String tipoCuenta,
        BigDecimal saldo,
        String moneda,
        int edadTitular,
        ResumenWebResponse resumen,
        List<MovimientoWebResponse> movimientos,
        PaginacionWebResponse paginacion) {

    /**
     * Blindaje del caso borde que este proyecto usa como prueba: la cuenta 130 no tiene ni un
     * movimiento.
     *
     * <p>El contrato exige, en la seccion 5.4 y en la 9, que una coleccion vacia viaje como
     * {@code []} y <strong>jamas</strong> como {@code null}. El motivo es practico: en el
     * navegador, {@code respuesta.movimientos.length} sobre una lista vacia da cero y sobre
     * {@code null} lanza {@code TypeError}, es decir la pantalla se cae entera por una cuenta sin
     * movimientos. Esta linea del constructor compacto hace que ese error sea imposible aunque
     * mas adelante alguien construya el record a mano desde otro sitio.
     *
     * <p>{@code List.copyOf} ademas devuelve una lista inmutable: nadie puede agregarle elementos
     * despues de construida la respuesta.
     */
    public CuentaWebResponse {
        movimientos = movimientos == null ? List.of() : List.copyOf(movimientos);
    }
}
