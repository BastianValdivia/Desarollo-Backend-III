package cl.duoc.bancoxyz.bff.web.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Un movimiento tal como lo ve <strong>el navegador</strong>: cuatro campos.
 *
 * <p><strong>El recorte, que es el valor que aporta un BFF.</strong> El {@code core-service}
 * entrega cinco campos por movimiento: {@code fecha}, {@code tipo}, {@code monto},
 * {@code descripcion} y {@code origen}. Este canal entrega cuatro. El que desaparece es
 * {@code origen}, cuyos valores congelados son {@code CSV_SEMILLA} y {@code RETIRO_ATM}.
 *
 * <p><strong>Por que se quita {@code origen} y no otro.</strong> Ese campo dice de que sistema
 * <em>interno</em> del banco provino el dato: si se sembro desde el archivo legado o si lo
 * genero un cajero durante la operacion. Es informacion util para un auditor y es ruido para un
 * cliente mirando su cartola: no cambia nada de lo que el cliente puede hacer con la pantalla, y
 * de paso revela detalles de la ingesta interna a cualquiera que abra las herramientas de
 * desarrollo del navegador. Recortar hacia afuera es a la vez menos bytes y menos superficie de
 * informacion expuesta.
 *
 * <p><strong>Por que {@code descripcion} SI se conserva aqui, aunque el canal movil la quite.</strong>
 * El navegador dibuja una tabla con una columna de glosa, y una cartola sin glosa es inservible
 * para reconocer un cargo. En una pantalla de telefono esa columna no cabe. Es exactamente la
 * clase de decision que un BFF permite tomar canal por canal en vez de imponer una sola forma a
 * todos.
 *
 * <p><strong>Sobre el signo del monto.</strong> El monto es siempre positivo y la direccion del
 * dinero vive en {@code tipo} (contrato, seccion 5.4). El navegador pinta en rojo o en verde
 * mirando el tipo, nunca el signo. Quien construya una interfaz sobre este canal no tiene que
 * recordar ninguna regla de signo.
 *
 * @param fecha       dia del movimiento, serializado como {@code yyyy-MM-dd}
 * @param tipo        {@code DEPOSITO}, {@code RETIRO}, {@code COMPRA} o {@code PAGO}
 * @param monto       importe, siempre positivo, serializado como numero JSON
 * @param descripcion glosa del archivo de origen. Puede venir {@code null}, y se conserva como
 *                    {@code null} en vez de omitirse: para el codigo del navegador es mas simple
 *                    encontrar siempre la clave y preguntar por su valor que averiguar si existe
 */
public record MovimientoWebResponse(
        LocalDate fecha,
        String tipo,
        BigDecimal monto,
        String descripcion) {
}
