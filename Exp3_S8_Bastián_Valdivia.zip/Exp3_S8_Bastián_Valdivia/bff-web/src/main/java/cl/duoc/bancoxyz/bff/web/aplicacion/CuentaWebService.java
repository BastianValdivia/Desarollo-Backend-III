package cl.duoc.bancoxyz.bff.web.aplicacion;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.bff.web.api.dto.CuentaWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.MovimientoWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.PaginaMovimientosWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.PaginacionWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.ResumenMensualWebResponse;
import cl.duoc.bancoxyz.bff.web.config.CanalWebProperties;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.ConsultaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;

/**
 * El cerebro del canal web: <strong>orquesta</strong> las llamadas al {@code core-service} y
 * <strong>traduce</strong> lo que recibe a la forma que responde este canal.
 *
 * <p><strong>Que es un "puerto" y donde esta aqui.</strong> {@code CoreClient} es una interfaz
 * que declara <em>que</em> se le puede pedir al core (obtener una cuenta, obtener una pagina de
 * movimientos) sin decir <em>como</em> se le pide. Esa interfaz es el puerto. La implementacion
 * que de verdad abre un socket y habla HTTP, {@code RestCoreClient}, es el adaptador, y vive en
 * {@code plataforma-comun}. Este servicio depende solo del puerto: no sabe que existe HTTP, ni
 * cabeceras, ni timeouts. La consecuencia practica es que se puede probar dandole un
 * {@code CoreClient} falso que devuelva la cuenta 130, sin levantar el core ni la red.
 *
 * <p><strong>Las tres operaciones y la llamada aguas arriba que elige cada una.</strong> Esto es
 * lo que hay que saber defender de este archivo:
 *
 * <table border="1">
 *   <caption>Endpoints del canal y su costo aguas arriba</caption>
 *   <tr><th>Operacion del canal</th><th>Llamada al core</th><th>Por que esa y no otra</th></tr>
 *   <tr>
 *     <td>Ficha de cuenta (W2)</td>
 *     <td><strong>una</strong>: {@code GET /internal/v1/cuentas/{id}}</td>
 *     <td>Necesita todos los movimientos para sumar el resumen, y esa llamada ya los trae todos.
 *         Pedir ademas la pagina al endpoint paginado seria un segundo viaje para obtener datos
 *         que ya estan en memoria</td>
 *   </tr>
 *   <tr>
 *     <td>Pagina de movimientos (W3)</td>
 *     <td><strong>una</strong>: {@code GET /internal/v1/cuentas/{id}/movimientos}</td>
 *     <td>No calcula agregados, asi que no necesita la cuenta completa. Traerla seria mover 42
 *         movimientos para publicar 20</td>
 *   </tr>
 *   <tr>
 *     <td>Resumen mensual (W4)</td>
 *     <td><strong>una</strong>: {@code GET /internal/v1/cuentas/{id}}</td>
 *     <td>Agrupa por mes <em>todos</em> los movimientos. Recorrer el endpoint paginado seria una
 *         llamada por pagina para terminar con el mismo conjunto</td>
 *   </tr>
 * </table>
 *
 * <p>Ninguna operacion de este canal hace mas de una llamada al core. Esa es la mitad del
 * argumento de "reduccion del consumo de recursos" que el canal tiene que sostener: el navegador
 * hace una peticion y el sistema hace una llamada interna, no tres de cada una.
 *
 * <p><strong>Donde entra la seguridad en este archivo.</strong> Las tres operaciones empiezan
 * exigiendo titularidad y solo despues hablan con el core. El orden esta congelado en la seccion
 * 7.4 del contrato y tiene dos consecuencias exigibles: pedir una cuenta ajena <em>e
 * inexistente</em> devuelve 403 {@code cuenta_ajena} y nunca 404 (si no, la API seria un detector
 * de cuentas existentes), y una peticion rechazada por titularidad no genera ni una llamada
 * aguas arriba. La regla completa, con la excepcion del perfil de ejecutivo, esta en
 * {@link GuardiaTitularidadWeb}.
 *
 * <p><strong>Sobre los errores.</strong> Este servicio no captura ninguna excepcion del
 * {@code CoreClient}. Las deja subir tal cual hasta el manejador del canal, que es el unico sitio
 * que sabe traducir un fallo a un codigo HTTP y a un {@code motivo} del contrato. Capturarlas
 * aqui para devolver, por ejemplo, una cuenta vacia, convertiria una caida del core en una
 * respuesta 200 con datos falsos, que es la peor forma posible de fallar en un sistema bancario.
 */
@Service
public class CuentaWebService {

    private static final Logger log = LoggerFactory.getLogger(CuentaWebService.class);

    private final CoreClient core;
    private final CacheCuentaWeb cacheCuenta;
    private final CanalWebProperties propiedades;
    private final GuardiaTitularidadWeb guardia;
    private final RespaldoDeLecturas respaldo;

    /** Identifica una pagina de movimientos en el respaldo: la cuenta y todo lo que la define. */
    private record ClaveMovimientos(int cuentaId, ConsultaMovimientosCoreDto consulta) {
    }

    /**
     * Inyeccion por constructor, no por campo con {@code @Autowired}.
     *
     * <p><strong>Por que hay DOS colaboradores hacia el core y no uno.</strong> Las lecturas de
     * la cuenta completa pasan por {@link CacheCuentaWeb}, que puede resolverlas de memoria; la
     * pagina de movimientos usa el {@link CoreClient} directo, sin cache. No es una
     * inconsistencia: es la decision de que se cachea y que no, hecha visible en el cableado.
     * Una pagina de movimientos depende de {@code page}, {@code size}, {@code desde},
     * {@code hasta} y {@code tipo}; cachearla significaria una entrada distinta por cada
     * combinacion de filtros que a un usuario se le ocurra escribir, es decir una cache que casi
     * nunca acierta y que en cambio si crece. Se cachea lo que se pide muchas veces igual, no
     * todo lo que pasa por aqui.
     *
     * <p>Dos ventajas concretas: los colaboradores son {@code final}, asi que nadie puede
     * cambiarlos despues de construido el objeto; y la clase se puede instanciar a mano en una
     * prueba pasandole un doble de {@code CoreClient}, sin contenedor de Spring de por medio. Con
     * inyeccion por campo, esa misma prueba necesitaria reflexion o levantar el contexto.
     */
    public CuentaWebService(CoreClient core,
                            CacheCuentaWeb cacheCuenta,
                            CanalWebProperties propiedades,
                            GuardiaTitularidadWeb guardia,
                            RespaldoDeLecturas respaldo) {
        this.core = core;
        this.cacheCuenta = cacheCuenta;
        this.propiedades = propiedades;
        this.guardia = guardia;
        this.respaldo = respaldo;
    }

    /**
     * Endpoint W2: la ficha completa de la cuenta, con el resumen agregado y la primera pagina de
     * movimientos.
     *
     * <p>Los cinco pasos, en orden:
     * <ol>
     *   <li>se exige titularidad <strong>antes</strong> de tocar la red;</li>
     *   <li>una sola llamada al core, que devuelve la cuenta con <strong>todos</strong> sus
     *       movimientos;</li>
     *   <li>se calcula el resumen sobre esa lista completa, que es el dato que el core no tiene;</li>
     *   <li>se recorta la primera pagina y se proyecta cada movimiento de cinco campos a cuatro;</li>
     *   <li>se fabrica el bloque de paginacion, porque la llamada al core no fue paginada.</li>
     * </ol>
     *
     * <p>Para la cuenta 130 los pasos funcionan sin ninguna rama especial: la lista vacia
     * produce un resumen en cero, una primera pagina vacia y una paginacion de cero paginas.
     */
    public CuentaWebResponse obtenerFicha(int cuentaId, Jwt token) {
        // ORDEN DELIBERADO, y el comentario esta aqui porque invertirlo no rompe ninguna
        // prueba y en cambio abre un agujero. La titularidad se comprueba SIEMPRE, antes
        // de tocar la cache. La llamada de abajo puede resolverse de memoria sin ejecutar
        // su cuerpo; si el control viviera dentro de ella, dejaria de aplicarse justo en
        // los aciertos, que es cuando la optimizacion funciona.
        guardia.exigirTitularidad(token, cuentaId);

        CuentaCoreDto cuenta = cuentaConRespaldo(cuentaId);

        List<MovimientoCoreDto> todos = cuenta.movimientos();
        int tamanoPagina = propiedades.paginacion().tamanoPorDefecto();

        // subList sobre la lista del core, sin copiar: primerosDe devuelve una vista y la
        // traduccion posterior construye la lista nueva una sola vez.
        List<MovimientoWebResponse> primeraPagina = TraductorWeb.movimientos(
                primerosDe(todos, tamanoPagina));

        PaginacionWebResponse paginacion =
                TraductorWeb.paginacionCalculada(0, tamanoPagina, todos.size());

        log.debug("Ficha web de la cuenta {}: {} movimientos en total, {} publicados en la primera pagina",
                cuentaId, todos.size(), primeraPagina.size());

        return new CuentaWebResponse(
                cuenta.cuentaId(),
                cuenta.titular(),
                cuenta.tipoCuenta(),
                cuenta.saldo(),
                cuenta.moneda(),
                cuenta.edadTitular(),
                AgregadorResumenWeb.resumirTodo(todos),
                primeraPagina,
                paginacion);
    }

    /**
     * Endpoint W3: una pagina de movimientos, con sus filtros opcionales.
     *
     * <p>Aqui la paginacion la hace el <strong>core</strong>, no el BFF. Es importante entender
     * por que, porque es la diferencia con W2: en W2 el BFF ya tenia la lista completa en memoria
     * por otro motivo (el resumen), asi que recortarla el mismo no costaba ninguna llamada extra.
     * En W3 no hay ningun agregado que calcular, luego traerse la cuenta completa para publicar
     * 20 movimientos seria mover datos por la red sin motivo. El endpoint paginado del core
     * existe exactamente para esto.
     *
     * @param consulta parametros ya normalizados y validados. Ver {@link ConsultaMovimientosWeb}
     */
    public PaginaMovimientosWebResponse listarMovimientos(int cuentaId,
                                                          ConsultaMovimientosWeb consulta,
                                                          Jwt token) {
        guardia.exigirTitularidad(token, cuentaId);

        ConsultaMovimientosCoreDto consultaDelCore = consulta.aConsultaDelCore();
        // F6: si el core no esta disponible se sirve la ultima pagina igual que se pidio (misma cuenta,
        // pagina, tamano y filtros), marcada como desactualizada; si nunca se pidio, 503.
        PaginaMovimientosCoreDto pagina = respaldo.leerYRespaldar("movimientos",
                new ClaveMovimientos(cuentaId, consultaDelCore),
                () -> core.obtenerMovimientos(cuentaId, consultaDelCore));

        return new PaginaMovimientosWebResponse(
                pagina.cuentaId(),
                TraductorWeb.movimientos(pagina.movimientos()),
                TraductorWeb.paginacion(pagina.paginacion()));
    }

    /**
     * Endpoint W4: el resumen mensual, exclusivo del canal web.
     *
     * <p>Una sola llamada al core y toda la agregacion dentro del BFF. El core no ofrece nada
     * parecido y no deberia: agrupar por mes es una necesidad de <em>esta</em> pantalla, no una
     * verdad del dominio bancario.
     *
     * <p>La moneda se propaga desde la respuesta del core en vez de escribirse aqui como el
     * literal {@code CLP}. Cuesta lo mismo y deja de ser una mentira el dia que el banco opere en
     * mas de una moneda.
     */
    public ResumenMensualWebResponse obtenerResumenMensual(int cuentaId, Jwt token) {
        guardia.exigirTitularidad(token, cuentaId);

        // La MISMA cache que la ficha, y a proposito: las dos operaciones necesitan
        // exactamente el mismo recurso del core. Un usuario que abre su panel (W2) y pincha
        // luego "resumen mensual" (W4) provoca UN viaje al core en vez de dos. Ese es el
        // ahorro de recursos aguas arriba, y se comprueba contando las peticiones que recibe
        // el core, nunca cronometrando la respuesta: el cronometro tambien baja por el
        // calentamiento del JIT y por la reutilizacion de la conexion TLS, asi que no prueba
        // nada sobre el consumo del core.
        CuentaCoreDto cuenta = cuentaConRespaldo(cuentaId);

        return new ResumenMensualWebResponse(
                cuenta.cuentaId(),
                cuenta.moneda(),
                AgregadorResumenWeb.resumirPorMes(cuenta.movimientos()));
    }

    /**
     * La cuenta, de la cache del canal si esta fresca, del core si no, y del ultimo dato conocido si el
     * core no esta disponible (F6). La titularidad ya se comprobo antes de llegar aqui.
     */
    private CuentaCoreDto cuentaConRespaldo(int cuentaId) {
        return respaldo.leerConRespaldo(CacheCuentaWeb.ESPACIO_RESPALDO, cuentaId,
                () -> cacheCuenta.obtenerCuenta(cuentaId));
    }

    /**
     * Devuelve los primeros {@code cantidad} elementos, o la lista entera si tiene menos.
     *
     * <p>Existe como metodo aparte porque {@code subList(0, 20)} sobre una lista de 3 elementos
     * lanza {@code IndexOutOfBoundsException}. Es exactamente el error que aparece con la cuenta
     * 130 si uno confia en que siempre hay al menos una pagina completa. El {@code Math.min} lo
     * hace imposible.
     */
    private static <T> List<T> primerosDe(List<T> lista, int cantidad) {
        return lista.subList(0, Math.min(cantidad, lista.size()));
    }
}
