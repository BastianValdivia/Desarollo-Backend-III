package cl.duoc.bancoxyz.bff.web.aplicacion;

import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

import cl.duoc.bancoxyz.bff.web.config.CanalWebProperties;
import cl.duoc.bancoxyz.comun.core.dto.ConsultaMovimientosCoreDto;

/**
 * Los parametros de busqueda de movimientos, <strong>ya normalizados y ya validados</strong>.
 *
 * <p><strong>Que problema resuelve esta clase.</strong> Entre la peticion HTTP y la llamada al
 * core hay un salto: lo que llega son cadenas y numeros que escribio un desconocido en la barra
 * de direcciones ({@code ?page=-5&size=99999&tipo=cualquier-cosa}), y lo que sale tiene que ser
 * un conjunto de valores sanos. Ese salto ocurre en un solo lugar, aqui, y su resultado es un
 * objeto inmutable. A partir de el, ningun metodo tiene que volver a preguntarse si los valores
 * que recibe son de fiar.
 *
 * <p>Es el patron de "objeto de parametros": en vez de pasar cinco argumentos sueltos por varias
 * capas (donde intercambiar {@code desde} y {@code hasta} compila sin problema y produce un
 * resultado vacio muy dificil de diagnosticar), se pasa un objeto con nombres.
 *
 * <p>Vive en la capa de aplicacion y no en {@code api/dto} porque no es parte del contrato
 * publico del canal: no se serializa a JSON y nadie fuera del BFF lo ve. Es vocabulario interno.
 *
 * @param pagina indice de pagina ya normalizado, siempre mayor o igual que cero
 * @param tamano tamano de pagina ya normalizado, siempre entre 1 y el maximo del canal
 * @param desde  fecha inicial inclusiva, o {@code null} si el cliente no filtro por fecha
 * @param hasta  fecha final inclusiva, o {@code null}
 * @param tipo   tipo de movimiento en mayusculas y ya comprobado contra el enumerado congelado,
 *               o {@code null} si el cliente no filtro por tipo
 */
public record ConsultaMovimientosWeb(
        int pagina,
        int tamano,
        LocalDate desde,
        LocalDate hasta,
        String tipo) {

    /**
     * Los cuatro valores que el contrato congela para {@code tipo} (seccion 5.1).
     *
     * <p>Se comprueban <strong>aqui</strong>, en el BFF, y no se delega la comprobacion al core.
     * Motivo concreto: si se le pasara un tipo desconocido, el core responderia 400, y el
     * {@code CoreClient} traduce cualquier codigo que no sepa interpretar a una excepcion de
     * "respuesta inesperada", que el canal publica como <strong>503</strong>. El navegador
     * recibiria "el servicio no esta disponible" cuando en realidad el error estaba en su propia
     * peticion, y alguien perderia una tarde buscando una caida del core que nunca ocurrio.
     * Validar en la frontera evita ese diagnostico falso.
     */
    private static final List<String> TIPOS_VALIDOS = List.of("DEPOSITO", "RETIRO", "COMPRA", "PAGO");

    /**
     * Construye una consulta sana a partir de los parametros crudos de la URL.
     *
     * <p><strong>Dos politicas distintas, y la diferencia importa.</strong>
     * <ul>
     *   <li>{@code page} y {@code size} se <em>normalizan</em> en silencio: un tamano de 99999 se
     *       recorta a 100 y una pagina negativa pasa a cero. El contrato describe el maximo como
     *       un limite del servidor, no como un error, y la respuesta dice en su bloque de
     *       paginacion exactamente que tamano se aplico, asi que nunca miente.</li>
     *   <li>{@code tipo} se <em>rechaza</em> si no es uno de los cuatro valores congelados. La
     *       diferencia es que aqui no hay ninguna normalizacion honesta posible: si alguien pide
     *       los movimientos de tipo "TRANSFERENCIA", ni devolver todos ni devolver ninguno
     *       responde a lo que pregunto. Lo unico correcto es decirle que ese filtro no existe.</li>
     * </ul>
     *
     * @param paginaPedida valor crudo de {@code page}, o {@code null}
     * @param tamanoPedido valor crudo de {@code size}, o {@code null}
     * @param desde        valor de {@code desde}, ya convertido a fecha por Spring, o {@code null}
     * @param hasta        valor de {@code hasta}, o {@code null}
     * @param tipoPedido   valor crudo de {@code tipo}, o {@code null}
     * @param limites      la politica de paginacion del canal
     * @throws IllegalArgumentException si {@code tipo} no es un valor congelado, o si el rango de
     *                                  fechas esta invertido. El manejador de errores del canal
     *                                  las traduce a 400
     */
    public static ConsultaMovimientosWeb de(Integer paginaPedida,
                                            Integer tamanoPedido,
                                            LocalDate desde,
                                            LocalDate hasta,
                                            String tipoPedido,
                                            CanalWebProperties.Paginacion limites) {

        if (desde != null && hasta != null && desde.isAfter(hasta)) {
            // Se detecta aqui y no se deja pasar al core porque el core devolveria alegremente
            // una lista vacia: ningun movimiento puede ser a la vez posterior a "desde" y
            // anterior a "hasta" cuando el rango esta invertido. Una lista vacia es una respuesta
            // valida y por eso es una trampa: el cliente concluiria que la cuenta no tuvo
            // movimientos en ese periodo, en vez de descubrir que escribio el rango al reves.
            throw new IllegalArgumentException(
                    "El rango de fechas esta invertido: desde=" + desde + " es posterior a hasta=" + hasta);
        }

        return new ConsultaMovimientosWeb(
                limites.normalizarPagina(paginaPedida),
                limites.normalizarTamano(tamanoPedido),
                desde,
                hasta,
                normalizarTipo(tipoPedido));
    }

    /**
     * Traduce esta consulta al objeto que entiende el {@code CoreClient}.
     *
     * <p>La traduccion es directa porque los dos objetos ya hablan del mismo concepto. La
     * diferencia es de garantias: este objeto <em>garantiza</em> que sus valores son sanos, y
     * {@code ConsultaMovimientosCoreDto} solo se defiende de los peores (lanza si la pagina es
     * negativa o el tamano no es positivo). Como la normalizacion ya ocurrio, esa defensa del
     * DTO del core nunca se dispara: es una red de seguridad, no el control principal.
     */
    public ConsultaMovimientosCoreDto aConsultaDelCore() {
        return new ConsultaMovimientosCoreDto(pagina, tamano, desde, hasta, tipo);
    }

    private static String normalizarTipo(String tipoPedido) {
        if (tipoPedido == null || tipoPedido.isBlank()) {
            return null;
        }
        // Locale.ROOT y no el locale por omision de la maquina: con el locale turco,
        // "tipo".toUpperCase() convierte la i en I con punto, y la comparacion contra el
        // enumerado falla. Es un fallo real, famoso, que solo aparece en algunos servidores.
        String normalizado = tipoPedido.trim().toUpperCase(Locale.ROOT);

        if (!TIPOS_VALIDOS.contains(normalizado)) {
            throw new IllegalArgumentException(
                    "Tipo de movimiento desconocido: '" + tipoPedido + "'. Valores validos: " + TIPOS_VALIDOS);
        }
        return normalizado;
    }
}
