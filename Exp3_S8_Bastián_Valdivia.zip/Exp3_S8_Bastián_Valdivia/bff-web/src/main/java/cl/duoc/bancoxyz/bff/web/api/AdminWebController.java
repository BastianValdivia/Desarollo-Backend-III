package cl.duoc.bancoxyz.bff.web.api;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.bancoxyz.bff.web.aplicacion.AuditoriaWebService;
import cl.duoc.bancoxyz.bff.web.aplicacion.PanelEjecutivoService;
import cl.duoc.bancoxyz.bff.web.api.dto.PaginaTransaccionesWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.PanelEjecutivoWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.ReporteCalidadWebResponse;

/**
 * Las dos rutas de <strong>administracion</strong> del canal web, reservadas al perfil de ejecutivo:
 * W5 (transacciones no conciliadas) y W6 (reporte de calidad de datos).
 *
 * <h2>Por que estas dos rutas prueban algo que ninguna otra del proyecto puede probar</h2>
 *
 * <p>Los tres canales demuestran que un token de uno no sirve en otro. Eso es autorizacion
 * <em>por canal</em>. Estas dos rutas demuestran lo siguiente, que es mas fino: dos usuarios
 * <strong>del mismo canal</strong>, con tokens igual de validos (misma clave de firma, misma
 * audiencia, ninguno expirado), obtienen respuestas distintas. El ejecutivo recibe 200; el cliente
 * recibe <strong>403 {@code permiso_insuficiente}</strong>. La autorizacion de este sistema es por
 * permiso, no solo por canal, y esta es la prueba.
 *
 * <h2>403 y no 404, que es el punto entero de que estas rutas existan</h2>
 *
 * <p>Antes de esta etapa las dos respondian 404, simplemente porque no estaban escritas. Ahora
 * existen, y un cliente sin el rol tiene que recibir <strong>403</strong>. La diferencia no es
 * cosmetica:
 *
 * <ul>
 *   <li>Un <strong>404</strong> significa "este canal no ofrece esto". Es la respuesta correcta
 *       para {@code /v1/dispositivos/baja}, que vive solo en el movil, o para el retiro del cajero.
 *       Decir 404 aqui seria mentir sobre el catalogo del canal.</li>
 *   <li>Un <strong>403</strong> significa "esto existe y no es para ti". Es la verdad, y es ademas
 *       lo que le permite a la interfaz distinguir "pide otro perfil" de "esta funcion no esta en
 *       esta aplicacion".</li>
 * </ul>
 *
 * <p>Quien decide ese 403 no es este controlador: es la regla
 * {@code requestMatchers("/v1/admin/**").hasAuthority("ROLE_EJECUTIVO")} de la cadena de filtros.
 * Un cliente sin el rol <strong>nunca entra a estos metodos</strong>, y por eso aqui no hay ni una
 * linea de comprobacion de permisos. Que la regla viva en la cadena y no en una anotacion sobre el
 * metodo es una decision congelada del contrato: un {@code @PreAuthorize} sin
 * {@code @EnableMethodSecurity} se ignora en absoluto silencio, y el sintoma seria un 200 donde se
 * esperaba un 403, sin ninguna pista.
 *
 * <h2>Por que no hay comprobacion de titularidad en ninguna de las dos</h2>
 *
 * <p>Porque ninguna habla de una cuenta. El reporte de calidad describe la ingesta entera, y el lote
 * no conciliado no tiene columna de cuenta y no puede tenerla. La titularidad es el nivel 3 de la
 * autorizacion y solo aplica donde hay un dato con dueno; forzarla aqui obligaria a inventar un
 * dueno para datos que no lo tienen.
 *
 * <h2>Rutas reales</h2>
 *
 * <p>Con el {@code context-path} del canal: {@code https://localhost:8443/api/web/v1/admin/calidad-datos}
 * y {@code https://localhost:8443/api/web/v1/admin/transacciones-no-conciliadas}. Las mismas rutas
 * en los puertos 8444 y 8445 devuelven 404, que es la evidencia de que estos endpoints son
 * exclusivos de web.
 */
@RestController
@RequestMapping(value = "/v1/admin", produces = MediaType.APPLICATION_JSON_VALUE)
public class AdminWebController {

    private final AuditoriaWebService auditoria;
    private final PanelEjecutivoService panel;

    public AdminWebController(AuditoriaWebService auditoria, PanelEjecutivoService panel) {
        this.auditoria = auditoria;
        this.panel = panel;
    }

    /**
     * <strong>W6</strong>. {@code GET /api/web/v1/admin/calidad-datos}
     *
     * <p>El reporte de la ingesta: cuantas filas trajo cada archivo, cuantas se descartaron y por
     * que motivo, y los tres totales que el contrato congela (50 cuentas, 686 movimientos, 1000
     * transacciones sin conciliar).
     *
     * <p>No recibe parametros. El reporte es un objeto de tamano fijo, con una fila por archivo
     * leido, y paginarlo o filtrarlo agregaria controles al cliente sin ahorrar nada medible.
     */
    @GetMapping("/calidad-datos")
    public ReporteCalidadWebResponse obtenerCalidadDatos() {
        return auditoria.obtenerCalidadDatos();
    }

    /**
     * <strong>W5</strong>. {@code GET /api/web/v1/admin/transacciones-no-conciliadas}
     *
     * <p>El lote de {@code transacciones.csv} tal como quedo: 1000 filas que no se pudieron
     * vincular a ninguna cuenta, publicadas sin maquillar, con sus fechas ilegibles como
     * {@code null} y sus tipos crudos incluidos {@code invalid}.
     *
     * <p><strong>Por que los dos parametros se declaran {@code Integer} y no {@code int}.</strong>
     * Misma razon que en W3: con {@code int}, un parametro ausente obligaria a escribir un valor por
     * defecto en la anotacion, y el canal tendria su politica de paginacion en dos sitios. Con
     * {@code Integer}, "el cliente no lo envio" se representa como {@code null} y la unica decision
     * sobre que hacer con esa ausencia vive en {@code CanalWebProperties}, que es la clase que
     * conoce los limites del canal.
     *
     * @param page pagina pedida, base cero. Ausente o negativa se normaliza a 0
     * @param size tamano pedido. Ausente o absurdo se normaliza a 20, y en cualquier caso se
     *             recorta al maximo del canal (100)
     */
    @GetMapping("/transacciones-no-conciliadas")
    public PaginaTransaccionesWebResponse listarTransaccionesNoConciliadas(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {

        return auditoria.listarTransaccionesNoConciliadas(page, size);
    }

    /**
     * <strong>Panel del ejecutivo</strong> (F7). {@code GET /api/web/v1/admin/panel}
     *
     * <p>Junta en una respuesta la calidad de los datos (del core) y la actividad reciente del banco (del
     * auditoria-service, alimentado por los eventos de Kafka: retiros y hechos de seguridad). Cada seccion dice si
     * esta disponible: si uno de los dos servicios no responde, esa seccion sale marcada y con un aviso, y la otra
     * se entrega igual (la respuesta sigue siendo 200). Como el resto de {@code /v1/admin/**}, es solo para el
     * perfil de ejecutivo: un cliente recibe 403.
     *
     * @param cuenta si se indica, la actividad se limita a los retiros de esa cuenta
     */
    @GetMapping("/panel")
    public PanelEjecutivoWebResponse panel(@RequestParam(required = false) Integer cuenta) {
        return panel.armar(cuenta);
    }
}
