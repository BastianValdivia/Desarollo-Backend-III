package cl.duoc.bancoxyz.bff.web.auditoria;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** Una pagina de eventos auditados, del mas reciente al mas antiguo. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record PaginaEventosAuditoriaDto(List<EventoAuditoriaDto> eventos, int pagina, int tamano, long total) {
}
