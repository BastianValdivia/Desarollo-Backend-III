package cl.duoc.bancoxyz.bff.web.auditoria;

import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import io.github.resilience4j.bulkhead.Bulkhead;
import io.github.resilience4j.bulkhead.BulkheadFullException;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;

/**
 * El {@link AuditoriaClient} que usa el canal web: el adaptador HTTP envuelto en Resilience4j, decision D6
 * ("{@code bff-web} a auditoria: igual, solo GET, 10 simultaneas, el panel sale sin esa seccion avisandolo").
 *
 * <p>Capas, de afuera hacia adentro: {@code Retry( CircuitBreaker( Bulkhead( llamada ) ) )}, el mismo orden y por
 * la misma razon que en {@code CoreClientResiliente}: cada intento tiene que pasar por el circuito y contar en
 * el, y con el circuito abierto el Retry ve el rechazo de inmediato y no insiste.
 *
 * <ul>
 *   <li><strong>Retry</strong> (3 intentos, espera exponencial): todas las llamadas son GET, asi que repetir es
 *       seguro.</li>
 *   <li><strong>CircuitBreaker</strong>: con el servicio caido, tras unos fallos se abre y el panel deja de
 *       esperar el timeout en cada consulta.</li>
 *   <li><strong>Bulkhead</strong> (10 simultaneas): un servicio lento no puede ocupar todos los hilos del
 *       canal; la llamada 11 se rechaza al instante.</li>
 * </ul>
 *
 * <p>Los tres rechazos que no son del servicio (circuito abierto, mamparo lleno) se traducen tambien a
 * {@link AuditoriaNoDisponibleException}: para el panel todos significan lo mismo, "esta seccion no esta".
 */
@Component
@Primary
public class AuditoriaClientResiliente implements AuditoriaClient {

    private static final Logger log = LoggerFactory.getLogger(AuditoriaClientResiliente.class);

    /** Nombre de la instancia en {@code resilience4j.*} (config-repo/bff-web.yml). */
    public static final String INSTANCIA = "auditoria";

    private final RestAuditoriaClient http;
    private final CircuitBreaker circuito;
    private final Retry reintento;
    private final Bulkhead mamparo;

    public AuditoriaClientResiliente(RestAuditoriaClient http, CircuitBreakerRegistry circuitos,
                                     RetryRegistry reintentos, BulkheadRegistry mamparos) {
        this.http = http;
        this.circuito = circuitos.circuitBreaker(INSTANCIA);
        this.reintento = reintentos.retry(INSTANCIA);
        this.mamparo = mamparos.bulkhead(INSTANCIA);
        // Todo cambio de estado del circuito queda en el log (ademas de /actuator/circuitbreakerevents/auditoria).
        this.circuito.getEventPublisher().onStateTransition(
                evento -> log.warn("Circuito '{}' hacia auditoria: {}", INSTANCIA, evento.getStateTransition()));
    }

    @Override
    public ResumenAuditoriaDto resumen() {
        return proteger("resumen", http::resumen);
    }

    @Override
    public PaginaEventosAuditoriaDto recientes(Integer cuenta, int tamano) {
        return proteger("recientes", () -> http.recientes(cuenta, tamano));
    }

    private <T> T proteger(String operacion, Supplier<T> llamada) {
        Supplier<T> protegida = Bulkhead.decorateSupplier(mamparo, llamada);
        protegida = CircuitBreaker.decorateSupplier(circuito, protegida);
        protegida = Retry.decorateSupplier(reintento, protegida);
        try {
            return protegida.get();
        } catch (CallNotPermittedException abierto) {
            throw new AuditoriaNoDisponibleException("El circuito de auditoria esta " + circuito.getState()
                    + ": " + operacion + " no se intento.", abierto);
        } catch (BulkheadFullException lleno) {
            throw new AuditoriaNoDisponibleException("El mamparo de auditoria esta lleno: " + operacion
                    + " no se intento.", lleno);
        }
    }
}
