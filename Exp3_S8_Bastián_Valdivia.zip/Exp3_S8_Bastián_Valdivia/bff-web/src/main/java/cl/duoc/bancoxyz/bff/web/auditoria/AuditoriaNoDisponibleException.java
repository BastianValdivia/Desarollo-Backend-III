package cl.duoc.bancoxyz.bff.web.auditoria;

/**
 * El auditoria-service no pudo atender la consulta: conexion rechazada, timeout, respuesta de error o ninguna
 * instancia en Eureka.
 *
 * <p>Es la unica excepcion que Resilience4j cuenta como fallo del circuito {@code auditoria} y que reintenta
 * (las consultas son GET, asi que repetirlas es seguro). Para el panel del ejecutivo no es un error del
 * usuario ni un 503: la seccion de actividad sale marcada como no disponible y el resto del panel se entrega.
 */
public class AuditoriaNoDisponibleException extends RuntimeException {

    public AuditoriaNoDisponibleException(String mensaje) {
        super(mensaje);
    }

    public AuditoriaNoDisponibleException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
