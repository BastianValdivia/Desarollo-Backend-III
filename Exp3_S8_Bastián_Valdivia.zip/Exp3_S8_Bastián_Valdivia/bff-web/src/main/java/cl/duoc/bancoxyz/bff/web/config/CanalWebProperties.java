package cl.duoc.bancoxyz.bff.web.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Politica de paginacion <strong>del canal web</strong>, leida de {@code config-repo/bff-web.yml} bajo el
 * prefijo {@code web}.
 *
 * <p><strong>Que hace esta clase en la arquitectura.</strong> Es el unico lugar donde viven los
 * dos numeros que gobiernan cuantos movimientos entrega este canal en una respuesta. El contrato
 * (seccion 4.2, fila W3) congela que {@code size} vale 20 por defecto y 100 como maximo, y exige
 * que el maximo se valide <em>en el servidor</em>: si el limite viviera solo en el navegador,
 * bastaria escribir {@code ?size=100000} en la barra de direcciones para que el BFF construyera
 * una respuesta gigantesca.
 *
 * <p><strong>Por que es una clase de propiedades y no dos constantes en el codigo.</strong> El
 * plan (seccion 6.5, ultimo parrafo) impone que ningun parametro de negocio quede escrito como
 * literal en Java. Cambiar el tamano de pagina del canal web debe ser editar una linea de
 * configuracion, no recompilar y volver a desplegar. Ademas, y esto es lo importante para el
 * patron BFF, estos numeros son <strong>politica de canal</strong>: el canal movil no expone
 * paginacion en absoluto y el cajero no entrega movimientos. Por eso esta clase vive en
 * {@code bff-web} y no en {@code plataforma-comun}: la libreria compartida aporta mecanismo, el
 * canal decide politica.
 *
 * <p><strong>Por que es un {@code record} y no una clase con setters.</strong> Spring Boot enlaza
 * propiedades a un record por constructor. El resultado es inmutable: una vez arrancada la
 * aplicacion nadie puede cambiar el tamano maximo en caliente desde otro bean, que es
 * exactamente lo que uno quiere de un limite de seguridad.
 *
 * <p>Para que esta clase exista como bean hace falta {@code @ConfigurationPropertiesScan} en la
 * clase principal, que ya cubre el paquete {@code cl.duoc.bancoxyz.bff.web}. Sin esa anotacion
 * la clase no se registra y el arranque falla al inyectarla, con un mensaje que no apunta a la
 * causa.
 */
@ConfigurationProperties(prefix = "web")
public record CanalWebProperties(@DefaultValue Paginacion paginacion) {

    /**
     * Los dos limites de pagina del canal, mas las dos operaciones que los aplican.
     *
     * <p>Las operaciones de normalizacion viven <em>aqui</em>, junto a los numeros, y no
     * repartidas por el servicio o el controlador. Asi es imposible que un endpoint nuevo se
     * olvide de aplicar el tope: el unico camino para convertir un parametro del cliente en un
     * numero utilizable pasa por estos dos metodos.
     */
    public record Paginacion(
            @DefaultValue("20") int tamanoPorDefecto,
            @DefaultValue("100") int tamanoMaximo) {

        /**
         * Comprobacion de coherencia en el momento del arranque.
         *
         * <p>Se valida aqui, y no la primera vez que llega una peticion, porque una configuracion
         * absurda (un maximo de cero, o un valor por defecto mayor que el maximo) debe impedir
         * que el servicio arranque. Un servicio que arranca con una configuracion invalida y
         * falla mas tarde, en produccion y solo para algunas peticiones, es mucho peor que uno
         * que se niega a partir y dice por que.
         */
        public Paginacion {
            if (tamanoMaximo <= 0) {
                throw new IllegalArgumentException(
                        "web.paginacion.tamano-maximo debe ser mayor que cero: " + tamanoMaximo);
            }
            if (tamanoPorDefecto <= 0 || tamanoPorDefecto > tamanoMaximo) {
                throw new IllegalArgumentException(
                        "web.paginacion.tamano-por-defecto debe estar entre 1 y "
                                + tamanoMaximo + ": " + tamanoPorDefecto);
            }
        }

        /**
         * Convierte el {@code size} que pidio el navegador en un tamano de pagina utilizable.
         *
         * <p>Reglas, en este orden: si no viene, vale el valor por defecto; si viene con un valor
         * absurdo (cero o negativo), tambien vale el valor por defecto; y en cualquier caso se
         * recorta al maximo del canal.
         *
         * <p><strong>Por que se recorta en silencio en vez de rechazar la peticion con un error.</strong>
         * El catalogo de la seccion 7.1 del contrato congela los valores del campo {@code motivo}
         * y no contiene ninguno para "parametro fuera de rango". Inventar uno aqui romperia la
         * regla de que el contrato se cambia primero en el documento. Y recortar es, ademas, lo
         * que el contrato describe: dice que el maximo esta "validado en servidor", no que pedir
         * de mas sea un error. El cliente recibe una pagina valida, con el campo {@code tamano}
         * de la paginacion diciendo exactamente cuantos elementos se le entregaron, asi que la
         * respuesta nunca miente sobre lo que hizo el servidor.
         *
         * @param tamanoPedido el valor crudo del parametro {@code size}, o {@code null} si el
         *                     cliente no lo envio
         */
        public int normalizarTamano(Integer tamanoPedido) {
            if (tamanoPedido == null || tamanoPedido <= 0) {
                return tamanoPorDefecto;
            }
            return Math.min(tamanoPedido, tamanoMaximo);
        }

        /**
         * Convierte el {@code page} que pidio el navegador en un numero de pagina utilizable.
         *
         * <p>La paginacion de este proyecto empieza en cero (contrato, seccion 5.6), asi que una
         * pagina negativa no significa nada y se lleva a cero. Pedir una pagina mas alla del
         * final no es un error: devuelve una lista vacia con la paginacion correcta, que es lo
         * que espera cualquier tabla con controles de "siguiente".
         */
        public int normalizarPagina(Integer paginaPedida) {
            if (paginaPedida == null || paginaPedida < 0) {
                return 0;
            }
            return paginaPedida;
        }
    }
}
