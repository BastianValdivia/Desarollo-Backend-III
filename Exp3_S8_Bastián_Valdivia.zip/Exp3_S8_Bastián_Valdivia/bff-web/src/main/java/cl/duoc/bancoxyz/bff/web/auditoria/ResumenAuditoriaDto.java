package cl.duoc.bancoxyz.bff.web.auditoria;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** Cuantos eventos hay auditados, en total y por tipo. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ResumenAuditoriaDto(long total, Map<String, Long> porTipo) {
}
