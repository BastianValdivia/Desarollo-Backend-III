package cl.duoc.bancoxyz.bff.web.seguridad;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.error.MotivosError;
import cl.duoc.bancoxyz.comun.error.RespuestaError;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Responde los <strong>401</strong> del canal web: las peticiones que llegan sin token o con un
 * token que no vale.
 *
 * <h2>Que es un "punto de entrada de autenticacion"</h2>
 *
 * <p>El nombre viene de la epoca de los formularios de login: era el sitio al que se mandaba al
 * visitante para que se identificara. En una API sin sesion no hay a donde mandarlo, asi que este
 * punto de entrada hace lo unico que tiene sentido: responder 401 y decir en un campo por que.
 *
 * <h2>La nota que ahorra una tarde: esto NO pasa por el manejador de errores</h2>
 *
 * <p>{@code ManejadorErroresWeb} es un {@code @RestControllerAdvice}, y un advice solo ve lo que
 * ocurre <strong>dentro</strong> del DispatcherServlet, es decir despues de que la peticion haya
 * sido despachada a un controlador. Un 401 se decide <strong>antes</strong>, en la cadena de
 * filtros, cuando todavia no hay controlador al que despachar. Por eso el JSON se escribe aqui a
 * mano sobre el {@link HttpServletResponse} (estado, {@code Content-Type} y cuerpo, en ese orden) en
 * lugar de devolver un objeto y confiar en que alguien lo serialice.
 *
 * <p>Si no se hiciera asi, los dos escenarios que la evaluacion de seguridad mira de cerca (el 401
 * y el 403) devolverian la pagina de error generica de Spring, que no se parece en nada al resto de
 * la API: sin {@code motivo}, sin {@code canal} y con otro tipo de medio.
 *
 * <h2>Por que lleva WWW-Authenticate y el 403 no</h2>
 *
 * <p>Esa cabecera significa "identificate, y hazlo asi". Tiene sentido exacto en un 401, donde el
 * servidor no sabe quien llama. En un 403 seria un consejo equivocado: a quien ya esta identificado
 * y no tiene permiso se lo estaria mandando a repetir un login que no va a cambiar nada.
 *
 * <h2>Que dice y que no dice el cuerpo</h2>
 *
 * <p>Este canal <strong>si</strong> envia el campo {@code detail}, a diferencia del cajero, porque
 * su cliente es una interfaz compleja en un entorno supervisado que puede reaccionar a el: una
 * aplicacion de navegador que lee {@code token_expirado} puede rehacer el login sola, y si lee
 * {@code token_ausente} sabe que su almacenamiento quedo vacio. Lo que no viaja nunca es el texto
 * original de la excepcion: ese va al log, donde lo lee un operador.
 */
@Component
public class PuntoEntradaWeb implements AuthenticationEntryPoint {

    private static final Logger log = LoggerFactory.getLogger(PuntoEntradaWeb.class);

    /** Valor congelado del campo {@code canal} para este BFF (contrato, seccion 5.16). */
    private static final String CANAL = "WEB";

    private final EscritorErrorHttp escritor;

    public PuntoEntradaWeb(EscritorErrorHttp escritor) {
        this.escritor = escritor;
    }

    @Override
    public void commence(HttpServletRequest peticion,
                         HttpServletResponse respuesta,
                         AuthenticationException fallo) throws IOException {

        String motivo = MotivoDelFalloDeToken.clasificar(fallo);

        log.info("401 {} en {} {}: {}", motivo, peticion.getMethod(), peticion.getRequestURI(),
                fallo.getMessage());

        respuesta.setHeader(HttpHeaders.WWW_AUTHENTICATE, "Bearer");
        escritor.escribir(respuesta, HttpStatus.UNAUTHORIZED.value(),
                RespuestaError.de(HttpStatus.UNAUTHORIZED.value(), motivo, "No autenticado",
                        detalleDe(motivo), peticion.getRequestURI(), CANAL));
    }

    /**
     * Texto explicativo por motivo, con una frase accionable y sin ningun detalle tecnico.
     *
     * <p>La regla que gobierna estas cuatro cadenas: dicen <strong>que hacer</strong>, no
     * <strong>que se detecto</strong>. "Vuelva a iniciar sesion" es util para el cliente y no le
     * dice nada a quien esta sondeando el servicio; "la firma no verifica contra la clave publica
     * del canal" seria lo contrario en los dos sentidos.
     */
    private static String detalleDe(String motivo) {
        return switch (motivo) {
            case MotivosError.TOKEN_AUSENTE ->
                    "Esta ruta exige la cabecera Authorization con un token Bearer de este canal";
            case MotivosError.TOKEN_EXPIRADO ->
                    "La sesion expiro. Vuelva a iniciar sesion para obtener un token nuevo";
            case MotivosError.AUDIENCIA_INVALIDA ->
                    "El token no fue emitido para este canal";
            default ->
                    "El token presentado no es valido en este canal";
        };
    }
}
