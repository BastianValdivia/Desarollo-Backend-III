package cl.duoc.bancoxyz.bff.web.api;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.bancoxyz.bff.web.aplicacion.ConsultaMovimientosWeb;
import cl.duoc.bancoxyz.bff.web.aplicacion.CuentaWebService;
import cl.duoc.bancoxyz.bff.web.api.dto.CuentaWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.PaginaMovimientosWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.ResumenMensualWebResponse;
import cl.duoc.bancoxyz.bff.web.config.CanalWebProperties;

/**
 * La <strong>puerta HTTP</strong> del canal web: las tres rutas de cuentas que el navegador
 * consume.
 *
 * <p><strong>Que hace y, sobre todo, que NO hace.</strong> Un controlador de este proyecto tiene
 * una sola responsabilidad: convertir una peticion HTTP en una llamada a la capa de aplicacion y
 * devolver lo que esa capa produjo. No traduce DTO, no calcula agregados, no decide codigos de
 * error y no habla con el core. Si alguna de esas cosas apareciera aqui, el archivo que gobierna
 * las rutas se convertiria en el archivo que lo gobierna todo, y cualquier cambio de forma de la
 * respuesta obligaria a tocarlo.
 *
 * <p>Lo unico que si hace ademas de enrutar es <em>recoger</em> los parametros crudos de la URL y
 * entregarlos a {@link ConsultaMovimientosWeb} para que los normalice. Recoger no es validar: la
 * politica de que tamano de pagina se acepta pertenece al canal, no al transporte.
 *
 * <p><strong>Como se forman las URL reales.</strong> El {@code context-path} del canal es
 * {@code /api/web} y esta clase declara {@code /v1/cuentas}, asi que la ficha de la cuenta 116 se
 * sirve en {@code http://localhost:8443/api/web/v1/cuentas/116}. Conviene tener presente la
 * asimetria que produce mas 404 inexplicables en este proyecto: el contexto existe solo en el
 * puerto del canal. Actuator ya no depende de el: desde la fase F1 vive en un puerto de gestion
 * aparte y sin prefijo ({@code http://127.0.0.1:8082/actuator/health} en local, igual que en el
 * {@code core-service}), y pedir {@code /api/web/actuator/health} en el puerto de servicio
 * responde 404.
 *
 * <p><strong>Las tres rutas estan protegidas, y en dos sitios distintos.</strong> Antes de que
 * cualquiera de estos metodos se ejecute, la cadena de filtros ya comprobo que el token es valido
 * en este canal y que lleva la autoridad exacta que la ruta exige ({@code PERM_cuenta:leer},
 * {@code PERM_movimientos:leer} o {@code PERM_resumen:leer}). Lo que la cadena <em>no</em> puede
 * comprobar es si la cuenta pedida es la del token, porque eso exige comparar un claim con un trozo
 * de la URL; de eso se encarga {@code GuardiaTitularidadWeb} dentro del servicio, y es lo que
 * produce el 403 {@code cuenta_ajena}.
 *
 * <p>De ahi el parametro {@code token} de los tres metodos: la autoridad dice que este usuario
 * puede leer fichas de cuenta, no que pueda leer <strong>esta</strong>. Son los niveles 2 y 3 de la
 * seccion 6.4 del contrato, y ninguno suple al otro.
 *
 * <p>{@code produces} se declara una sola vez, a nivel de clase: las tres rutas responden
 * {@code application/json}. Los errores salen con {@code application/problem+json}, y eso lo fija
 * {@link ManejadorErroresWeb}, que es quien los construye.
 */
@RestController
@RequestMapping(value = "/v1/cuentas", produces = MediaType.APPLICATION_JSON_VALUE)
public class CuentaWebController {

    private final CuentaWebService cuentaWebService;
    private final CanalWebProperties propiedades;

    public CuentaWebController(CuentaWebService cuentaWebService, CanalWebProperties propiedades) {
        this.cuentaWebService = cuentaWebService;
        this.propiedades = propiedades;
    }

    /**
     * <strong>W2</strong>. {@code GET /api/web/v1/cuentas/{cuentaId}}
     *
     * <p>Devuelve en una sola respuesta todo lo que la pantalla de detalle necesita para
     * dibujarse: ficha, resumen calculado por el BFF, primera pagina de movimientos y paginacion.
     * Es el endpoint que justifica el canal: sin el, el navegador haria tres viajes por internet
     * para armar una sola vista.
     *
     * <p>{@code cuentaId} se declara {@code int} y no {@code String}: si alguien pide
     * {@code /v1/cuentas/abc}, Spring no consigue convertirlo y lanza antes de entrar al metodo.
     * Esa excepcion la recoge el manejador de errores del canal, de modo que la respuesta sigue
     * siendo un cuerpo RFC 7807 igual que todos los demas errores, y no la pagina generica de
     * Spring.
     *
     * <p>{@code @AuthenticationPrincipal Jwt} entrega el token <strong>ya validado</strong>: firma,
     * algoritmo, vigencia y audiencia se comprobaron en la cadena de filtros, asi que dentro de este
     * metodo sus claims son confiables. Si el token fuera invalido, la peticion no habria llegado
     * hasta aqui.
     */
    @GetMapping("/{cuentaId}")
    public CuentaWebResponse obtenerCuenta(@PathVariable int cuentaId,
                                           @AuthenticationPrincipal Jwt token) {
        return cuentaWebService.obtenerFicha(cuentaId, token);
    }

    /**
     * <strong>W3</strong>. {@code GET /api/web/v1/cuentas/{cuentaId}/movimientos}
     *
     * <p>La paginacion de la tabla, para cuando el usuario ya tiene la pantalla cargada y solo
     * quiere avanzar o filtrar. No repite la ficha ni el resumen: el navegador ya los tiene.
     *
     * <p><strong>Por que los cinco parametros se declaran {@code required = false} y se reciben
     * como envoltorios ({@code Integer}, no {@code int}).</strong> Con {@code int}, un parametro
     * ausente obligaria a inventar un valor por defecto en la propia anotacion, y entonces el
     * canal tendria su politica de paginacion escrita en dos sitios: aqui y en
     * {@code CanalWebProperties}. Con {@code Integer}, "el cliente no lo envio" se representa
     * como {@code null} y la unica decision sobre que hacer con esa ausencia vive en la clase de
     * propiedades, que es la que conoce los limites del canal.
     *
     * @param page  pagina pedida, base cero. Ausente o negativa se normaliza a 0
     * @param size  tamano pedido. Ausente o absurdo se normaliza al valor por defecto (20) y en
     *              cualquier caso se recorta al maximo del canal (100)
     * @param desde fecha inicial inclusiva, formato {@code yyyy-MM-dd}
     * @param hasta fecha final inclusiva, mismo formato
     * @param tipo  uno de {@code DEPOSITO}, {@code RETIRO}, {@code COMPRA}, {@code PAGO}
     */
    @GetMapping("/{cuentaId}/movimientos")
    public PaginaMovimientosWebResponse listarMovimientos(
            @PathVariable int cuentaId,
            @AuthenticationPrincipal Jwt token,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta,
            @RequestParam(required = false) String tipo) {

        ConsultaMovimientosWeb consulta = ConsultaMovimientosWeb.de(
                page, size, desde, hasta, tipo, propiedades.paginacion());

        return cuentaWebService.listarMovimientos(cuentaId, consulta, token);
    }

    /**
     * <strong>W4</strong>. {@code GET /api/web/v1/cuentas/{cuentaId}/resumen-mensual}
     *
     * <p>Agregacion por mes, <strong>exclusiva del canal web</strong>: esta misma ruta en los
     * puertos 8444 y 8445 devuelve 404, y esa es la prueba de que los tres BFF no son el mismo
     * servicio repetido.
     *
     * <p>No recibe parametros de paginacion a proposito. Un banco con 50 cuentas y datos de un
     * par de anios produce a lo sumo unas decenas de filas de mes, y paginar decenas de filas
     * agrega complejidad al cliente sin ahorrar nada medible. Si manana el dataset abarcara
     * veinte anios, esta es la primera decision que habria que revisar, y se revisaria aqui sin
     * tocar ningun otro canal.
     */
    @GetMapping("/{cuentaId}/resumen-mensual")
    public ResumenMensualWebResponse obtenerResumenMensual(@PathVariable int cuentaId,
                                                           @AuthenticationPrincipal Jwt token) {
        return cuentaWebService.obtenerResumenMensual(cuentaId, token);
    }
}
