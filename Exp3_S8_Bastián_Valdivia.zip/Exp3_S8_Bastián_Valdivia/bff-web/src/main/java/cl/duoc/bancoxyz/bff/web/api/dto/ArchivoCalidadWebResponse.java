package cl.duoc.bancoxyz.bff.web.api.dto;

/**
 * Una fila del reporte de calidad (W6): que se leyo de cada archivo de la ingesta y cuanto se
 * descarto por duplicado.
 *
 * <p>Los cuatro nombres estan congelados en la seccion 5.14 del contrato.
 *
 * <p><strong>Por que el canal republica estos numeros tal cual, sin maquillarlos.</strong> Es un
 * reporte de calidad: su valor esta en decir exactamente cuantas filas venian y cuantas
 * sobrevivieron. Un canal que redondeara, agrupara o escondiera las filas descartadas estaria
 * fabricando la apariencia de un dataset limpio, que es justo lo contrario de para lo que existe
 * esta pantalla.
 *
 * @param archivo               nombre del archivo leido, por ejemplo {@code intereses.csv}
 * @param filasLeidas           filas que traia el archivo
 * @param filasUnicas           filas que quedaron tras descartar duplicados exactos
 * @param duplicadasDescartadas diferencia entre las dos anteriores
 */
public record ArchivoCalidadWebResponse(
        String archivo,
        int filasLeidas,
        int filasUnicas,
        int duplicadasDescartadas) {
}
