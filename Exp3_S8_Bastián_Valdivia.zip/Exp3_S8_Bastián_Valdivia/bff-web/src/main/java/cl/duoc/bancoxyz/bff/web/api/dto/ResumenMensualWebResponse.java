package cl.duoc.bancoxyz.bff.web.api.dto;

import java.util.List;

/**
 * La respuesta de {@code GET /api/web/v1/cuentas/{id}/resumen-mensual}: el objeto
 * <strong>W4</strong>, y uno de los tres endpoints <strong>exclusivos del canal web</strong>.
 *
 * <p><strong>Que significa "exclusivo" y por que importa.</strong> Esta ruta no existe en
 * {@code bff-mobile} ni en {@code bff-atm}: pedirla en los puertos 8444 u 8445 devuelve 404. Eso
 * no es una funcionalidad faltante en esos canales, es la prueba de que los tres BFF no son
 * intercambiables. Si los tres expusieran el mismo catalogo de rutas, la afirmacion "cada canal
 * esta adaptado a su cliente" no tendria ninguna evidencia que la sostenga.
 *
 * <p><strong>Por que es el canal web y no otro el que lo tiene.</strong> Un grafico de barras de
 * abonos contra cargos por mes necesita ancho de pantalla. En un telefono no se lee, y un cajero
 * automatico ni siquiera intenta mostrarlo. La decision de que endpoint vive en que canal la
 * toma la pantalla del cliente, no el backend.
 *
 * <p><strong>Es agregacion pura: el core no tiene nada parecido.</strong> El
 * {@code core-service} entrega movimientos sueltos con su fecha. Agruparlos por mes, sumar por
 * tipo y ordenar el resultado ocurre entero dentro de este BFF. La alternativa (que el navegador
 * se traiga los 42 movimientos y los agrupe en JavaScript) mueve datos que solo sirven para ser
 * agregados, y deja la definicion de "abono" escrita en el cliente.
 *
 * @param cuentaId la cuenta consultada
 * @param moneda   literal {@code CLP}, propagado desde el core
 * @param meses    un elemento por mes <strong>que tenga movimientos</strong>, ordenado de forma
 *                 ascendente. Los meses sin actividad no aparecen como filas en cero: rellenar
 *                 huecos seria inventar filas que el dominio no tiene, y la decision de dibujar
 *                 o no un hueco en un grafico le corresponde a la interfaz. Para la cuenta 130,
 *                 que no tiene ni un movimiento, la lista viaja como {@code []} y nunca como
 *                 {@code null}
 */
public record ResumenMensualWebResponse(
        int cuentaId,
        String moneda,
        List<MesWebResponse> meses) {

    /** Misma proteccion que en los demas objetos con colecciones: {@code []}, nunca {@code null}. */
    public ResumenMensualWebResponse {
        meses = meses == null ? List.of() : List.copyOf(meses);
    }
}
