package cl.duoc.bancoxyz.bff.web.seguridad;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.error.MotivosError;
import cl.duoc.bancoxyz.comun.error.RespuestaError;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Responde los <strong>403 {@code permiso_insuficiente}</strong> del canal web: el token es valido
 * y le falta la autoridad que la ruta exige.
 *
 * <h2>Quien llega hasta aqui, exactamente</h2>
 *
 * <p>Este es el manejador que produce la evidencia central del canal: un
 * <strong>cliente</strong> perfectamente autenticado que pide {@code /v1/admin/calidad-datos}. Su
 * token esta firmado por este mismo canal, tiene la audiencia correcta y no ha expirado; lo unico
 * que le falta es {@code ROLE_EJECUTIVO}. Dos usuarios del mismo canal, dos respuestas distintas:
 * eso es autorizacion por permiso y no solo por canal.
 *
 * <p>El mismo cliente contra {@code /v1/cuentas/116/movimientos} sin
 * {@code PERM_movimientos:leer} tambien acaba aqui. Son los <strong>niveles 1 y 2</strong> de la
 * seccion 6.4 del contrato (rol y operacion), los dos decididos en la cadena de filtros.
 *
 * <h2>El 403 que NO pasa por aqui, y por que</h2>
 *
 * <p>El <strong>nivel 3</strong>, la titularidad, produce {@code 403 cuenta_ajena} y lo emite el
 * manejador de errores del canal, no esta clase. La razon es estructural y no un capricho: la
 * cadena de filtros puede comparar el token contra la regla de la ruta, pero no puede comparar un
 * claim contra un trozo de la URL, que es lo que exige decidir si una cuenta es tuya. Dos preguntas
 * distintas, dos sitios distintos, dos motivos distintos en el mismo codigo HTTP.
 *
 * <h2>Por que el cuerpo no dice que autoridad falto</h2>
 *
 * <p>Seria comodo para quien integra y es informacion gratis para quien sondea: le diria el nombre
 * exacto de la llave que tiene que conseguir. La autoridad que falto va al log, donde la lee un
 * operador; hacia afuera viaja el motivo congelado y nada mas.
 */
@Component
public class ManejadorAccesoDenegadoWeb implements AccessDeniedHandler {

    private static final Logger log = LoggerFactory.getLogger(ManejadorAccesoDenegadoWeb.class);

    /** Valor congelado del campo {@code canal} para este BFF (contrato, seccion 5.16). */
    private static final String CANAL = "WEB";

    private final EscritorErrorHttp escritor;

    public ManejadorAccesoDenegadoWeb(EscritorErrorHttp escritor) {
        this.escritor = escritor;
    }

    @Override
    public void handle(HttpServletRequest peticion,
                       HttpServletResponse respuesta,
                       AccessDeniedException fallo) throws IOException {

        log.info("403 permiso_insuficiente en {} {}: {}",
                peticion.getMethod(), peticion.getRequestURI(), fallo.getMessage());

        // Sin cabecera WWW-Authenticate, a diferencia del 401: quien llama ya esta identificado y
        // repetir el login no le va a dar el permiso que le falta.
        escritor.escribir(respuesta, HttpStatus.FORBIDDEN.value(),
                RespuestaError.de(HttpStatus.FORBIDDEN.value(), MotivosError.PERMISO_INSUFICIENTE,
                        "Acceso denegado",
                        "Su perfil no tiene permiso para esta operacion",
                        peticion.getRequestURI(), CANAL));
    }
}
