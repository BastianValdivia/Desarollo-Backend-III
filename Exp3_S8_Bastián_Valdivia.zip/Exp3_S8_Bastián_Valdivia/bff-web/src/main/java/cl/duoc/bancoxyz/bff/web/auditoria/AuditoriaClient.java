package cl.duoc.bancoxyz.bff.web.auditoria;

/**
 * Puerto hacia el auditoria-service, igual que {@code CoreClient} lo es hacia el core: dice QUE se le puede
 * pedir sin decir COMO. El panel del ejecutivo solo conoce esta interfaz, de modo que se prueba con un doble
 * sin levantar la red.
 */
public interface AuditoriaClient {

    /** Cuantos eventos hay, en total y por tipo. */
    ResumenAuditoriaDto resumen();

    /**
     * Los eventos mas recientes.
     *
     * @param cuenta  si no es {@code null}, solo los de retiro de esa cuenta
     * @param tamano  cuantos traer como maximo
     * @throws AuditoriaNoDisponibleException si el servicio no responde o rechaza la llamada
     */
    PaginaEventosAuditoriaDto recientes(Integer cuenta, int tamano);
}
