package cl.duoc.bancoxyz.bff.web.auditoria;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Como habla el canal web con el auditoria-service, bajo el prefijo {@code servicios.auditoria}.
 *
 * <p>Los dos timeouts son explicitos por la misma razon que los del core: sin ellos, un servicio colgado
 * (que acepta la conexion y no responde) ocuparia un hilo del canal por peticion, hasta agotarlos. El
 * {@code TimeLimiter} de Resilience4j no aplica a llamadas bloqueantes; el limite lo pone el cliente HTTP.
 *
 * @param baseUrl         direccion logica ({@code http://auditoria-service}); Eureka la convierte en una instancia
 * @param timeoutConexion cuanto esperar para conectar
 * @param timeoutLectura  cuanto esperar la respuesta
 * @param eventosRecientes cuantos eventos muestra el panel
 */
@ConfigurationProperties(prefix = "servicios.auditoria")
public record AuditoriaClientProperties(
        String baseUrl,
        @DefaultValue("500ms") Duration timeoutConexion,
        @DefaultValue("2s") Duration timeoutLectura,
        @DefaultValue("10") int eventosRecientes) {

    public AuditoriaClientProperties {
        if (baseUrl == null || baseUrl.isBlank()) {
            throw new IllegalArgumentException("Falta servicios.auditoria.base-url: sin ella el panel no sabe a "
                    + "donde llamar para su seccion de actividad.");
        }
        if (timeoutConexion.isZero() || timeoutConexion.isNegative()
                || timeoutLectura.isZero() || timeoutLectura.isNegative()) {
            throw new IllegalArgumentException("Los timeouts hacia auditoria deben ser positivos: un cero "
                    + "significa esperar para siempre, que es lo que estos valores existen para impedir.");
        }
        if (eventosRecientes < 1 || eventosRecientes > 100) {
            throw new IllegalArgumentException("servicios.auditoria.eventos-recientes debe estar entre 1 y 100.");
        }
    }
}
