package cl.duoc.bancoxyz.bff.web.aplicacion;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.bff.web.api.dto.ArchivoCalidadWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.PaginaTransaccionesWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.ReporteCalidadWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.TransaccionNoConciliadaWebResponse;
import cl.duoc.bancoxyz.bff.web.config.CanalWebProperties;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.PaginaTransaccionesCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;

/**
 * Las dos operaciones de <strong>auditoria</strong> del canal web: el reporte de calidad de la
 * ingesta (W6) y el lote de transacciones no conciliadas (W5).
 *
 * <h2>Rol en la arquitectura</h2>
 *
 * <p>Es el gemelo de {@link CuentaWebService} para el otro perfil del canal. Uno atiende al cliente
 * y el otro al ejecutivo, y estan separados por una razon concreta: son dos publicos con dos
 * preguntas distintas, y tenerlos en clases distintas hace que la linea que divide los dos perfiles
 * sea visible en el arbol de archivos y no solo en una regla de configuracion.
 *
 * <p>Habla con el core por el mismo <strong>puerto</strong> que el resto del canal,
 * {@code CoreClient}: una interfaz que declara <em>que</em> se le puede pedir al core sin decir
 * <em>como</em>. La implementacion que de verdad abre un socket vive en {@code plataforma-comun} y
 * esta clase no sabe que existe HTTP. La consecuencia practica es que se prueba con un
 * {@code CoreClient} falso, sin levantar el core ni la red.
 *
 * <h2>Una llamada al core por peticion, igual que en el resto del canal</h2>
 *
 * <p>Las dos operaciones hacen exactamente una llamada aguas arriba. En W5 la paginacion la resuelve
 * el <strong>core</strong>, no este servicio: pedir las 1000 filas para publicar 20 seria mover
 * datos por la red sin motivo, y el endpoint paginado del core existe justamente para esto.
 *
 * <h2>Sobre los errores</h2>
 *
 * <p>Este servicio no captura ninguna excepcion del {@code CoreClient}: las deja subir al manejador
 * del canal, que es el unico sitio que sabe traducir un fallo a un codigo HTTP y a un motivo del
 * contrato. Capturarlas aqui para devolver, por ejemplo, un reporte en ceros, convertiria una caida
 * del core en un 200 con datos falsos. En un reporte de calidad eso seria especialmente grave: la
 * pantalla que existe para detectar problemas de datos estaria inventandolos.
 */
@Service
public class AuditoriaWebService {

    private static final Logger log = LoggerFactory.getLogger(AuditoriaWebService.class);

    private final CoreClient core;
    private final CanalWebProperties propiedades;
    private final RespaldoDeLecturas respaldo;

    /** Identifica una pagina del lote no conciliado en el respaldo. */
    private record ClavePagina(int pagina, int tamano) {
    }

    public AuditoriaWebService(CoreClient core, CanalWebProperties propiedades, RespaldoDeLecturas respaldo) {
        this.core = core;
        this.propiedades = propiedades;
        this.respaldo = respaldo;
    }

    /**
     * W6: el reporte de calidad de la ingesta, tal como lo calculo el core.
     *
     * <p>No hay nada que agregar ni que recortar: el reporte ya responde exactamente la pregunta
     * del ejecutivo. Lo que si hace este metodo es traducirlo a las clases del canal, para que el
     * contrato de salida de web pueda evolucionar sin arrastrar al core.
     */
    public ReporteCalidadWebResponse obtenerCalidadDatos() {
        // F6: ante un core no disponible, el ultimo reporte conocido marcado como desactualizado.
        ReporteCalidadCoreDto reporte = respaldo.leerYRespaldar("calidad-datos", "reporte",
                core::obtenerCalidadDatos);

        List<ArchivoCalidadWebResponse> archivos = reporte.archivos().stream()
                .map(origen -> new ArchivoCalidadWebResponse(
                        origen.archivo(),
                        origen.filasLeidas(),
                        origen.filasUnicas(),
                        origen.duplicadasDescartadas()))
                .toList();

        log.debug("Reporte de calidad servido al canal web: {} cuentas, {} movimientos, {} archivos.",
                reporte.cuentasConsolidadas(), reporte.movimientosCargados(), archivos.size());

        return new ReporteCalidadWebResponse(
                reporte.generadoEn(),
                archivos,
                reporte.descartesPorMotivo(),
                reporte.cuentasConsolidadas(),
                reporte.movimientosCargados(),
                reporte.transaccionesNoConciliadas());
    }

    /**
     * W5: una pagina del lote no conciliado.
     *
     * <p><strong>Los parametros se normalizan con la misma politica que el resto del canal.</strong>
     * No es un detalle de estilo: el tope de 100 elementos por pagina existe para que nadie pueda
     * escribir {@code ?size=100000} y obligar al BFF a construir una respuesta con las mil filas del
     * lote. Un limite que solo viviera en el navegador no seria un limite, seria una sugerencia. Y
     * reutilizar {@code CanalWebProperties} en vez de escribir aqui otros numeros evita que el canal
     * acabe con dos politicas de paginacion que divergen en silencio.
     *
     * @param pagina valor crudo del parametro {@code page}, o {@code null} si no vino
     * @param tamano valor crudo del parametro {@code size}, o {@code null} si no vino
     */
    public PaginaTransaccionesWebResponse listarTransaccionesNoConciliadas(Integer pagina, Integer tamano) {
        CanalWebProperties.Paginacion politica = propiedades.paginacion();
        int paginaPedida = politica.normalizarPagina(pagina);
        int tamanoPedido = politica.normalizarTamano(tamano);

        PaginaTransaccionesCoreDto lote = respaldo.leerYRespaldar("no-conciliadas",
                new ClavePagina(paginaPedida, tamanoPedido),
                () -> core.obtenerTransaccionesNoConciliadas(paginaPedida, tamanoPedido));

        List<TransaccionNoConciliadaWebResponse> transacciones = lote.transacciones().stream()
                .map(origen -> new TransaccionNoConciliadaWebResponse(
                        origen.id(),
                        origen.fecha(),
                        origen.monto(),
                        origen.tipo()))
                .toList();

        return new PaginaTransaccionesWebResponse(
                transacciones,
                TraductorWeb.paginacion(lote.paginacion()));
    }
}
