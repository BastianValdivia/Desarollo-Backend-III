package cl.duoc.bancoxyz.bff.web.auditoria;

import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;

/**
 * Un evento tal como lo entrega el auditoria-service (y como lo muestra el panel). Lectura tolerante: un
 * campo nuevo del servicio no rompe al BFF.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record EventoAuditoriaDto(String eventId, String tipo, int version, Instant ocurridoEn, String origen,
                                 String topico, String clave, JsonNode datos) {
}
