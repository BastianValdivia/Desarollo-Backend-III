package cl.duoc.bancoxyz.bff.web.api.dto;

import java.util.List;

/**
 * <strong>W5</strong>: una pagina del lote de transacciones no conciliadas, exclusiva del canal web
 * y reservada al perfil de ejecutivo.
 *
 * <p>Los dos nombres de campo estan congelados en la seccion 5.15 del contrato.
 *
 * <h2>Por que este endpoint se pagina y W6 no</h2>
 *
 * <p>Son 1000 filas. Devolverlas de una sola vez obligaria al canal a construir una respuesta
 * grande para una pantalla que muestra veinte lineas, y seria ademas la unica respuesta del canal
 * cuyo tamano no depende de nada que el cliente pueda controlar. El reporte de calidad, en cambio,
 * es un objeto de tamano fijo con una fila por archivo: paginarlo agregaria complejidad al cliente
 * sin ahorrar un solo byte.
 *
 * <p>La paginacion reutiliza {@link PaginacionWebResponse}, el mismo objeto que acompana a los
 * movimientos, y eso es deliberado: dos listas paginadas del mismo canal que describieran su
 * paginacion con nombres distintos obligarian al cliente a escribir dos veces el mismo control de
 * "pagina siguiente".
 *
 * @param transacciones filas del lote, tal como vinieron del archivo
 * @param paginacion    metadatos para recorrer el lote completo
 */
public record PaginaTransaccionesWebResponse(
        List<TransaccionNoConciliadaWebResponse> transacciones,
        PaginacionWebResponse paginacion) {

    /** Lista nula a lista vacia, igual que en el resto del canal. */
    public PaginaTransaccionesWebResponse {
        transacciones = transacciones == null ? List.of() : List.copyOf(transacciones);
    }
}
