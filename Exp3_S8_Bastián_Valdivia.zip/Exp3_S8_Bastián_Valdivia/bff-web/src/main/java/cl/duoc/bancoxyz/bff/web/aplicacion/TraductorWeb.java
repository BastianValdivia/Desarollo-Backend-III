package cl.duoc.bancoxyz.bff.web.aplicacion;

import java.util.List;

import cl.duoc.bancoxyz.bff.web.api.dto.MovimientoWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.PaginacionWebResponse;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginacionCoreDto;

/**
 * <strong>La frontera</strong> entre el contrato aguas arriba (lo que dice el
 * {@code core-service}) y el contrato aguas abajo (lo que responde el canal web).
 *
 * <p>Esta clase es literalmente el recorte del que habla el patron BFF. Cada metodo toma un
 * objeto del core y devuelve un objeto de <em>este</em> canal, con la forma exacta que el
 * navegador necesita y ni un campo mas.
 *
 * <p><strong>Por que la traduccion vive en la capa de aplicacion y no en el controlador.</strong>
 * El controlador tiene una sola responsabilidad: recibir una peticion HTTP y devolver una
 * respuesta HTTP. Si ademas tradujera, cualquier cambio en la forma de la respuesta obligaria a
 * tocar la clase que gobierna las rutas, y el codigo que decide <em>que</em> se responde quedaria
 * mezclado con el que decide <em>como</em> se transporta.
 *
 * <p><strong>Por que tampoco vive en los propios DTO como {@code MovimientoWebResponse.de(...)}.</strong>
 * Es la opcion mas comoda y tiene un costo escondido: obligaria a los DTO de respuesta de este
 * canal a importar los DTO del core, es decir a conocer la forma del backend de dominio. Con la
 * traduccion aqui, las clases de {@code api/dto} no importan absolutamente nada del core y
 * describen unicamente el contrato publico del canal. La direccion de las dependencias queda en
 * un solo sentido y se ve a simple vista.
 *
 * <p>Todos los metodos son estaticos y la clase no tiene estado: no traduce nada que dependa de
 * configuracion ni de la peticion en curso, asi que no necesita ser un bean de Spring.
 */
public final class TraductorWeb {

    private TraductorWeb() {
    }

    /**
     * Proyecta un movimiento del core al movimiento del canal web: <strong>de cinco campos a
     * cuatro</strong>.
     *
     * <p>El campo que se queda fuera es {@code origen} ({@code CSV_SEMILLA} o
     * {@code RETIRO_ATM}). Dice de que sistema interno vino el dato, lo cual no cambia nada de lo
     * que el cliente puede hacer con su cartola y de paso expone detalles de la ingesta a
     * cualquiera que abra las herramientas del navegador.
     *
     * <p>Este metodo, repetido 20 veces por respuesta, es la mitad de la diferencia de tamano
     * entre la respuesta del core y la de este canal. La otra mitad es que el core envia los 42
     * movimientos de la cuenta y este canal envia 20.
     */
    public static MovimientoWebResponse movimiento(MovimientoCoreDto origen) {
        return new MovimientoWebResponse(
                origen.fecha(),
                origen.tipo(),
                origen.monto(),
                origen.descripcion());
    }

    /**
     * Proyecta una lista completa de movimientos.
     *
     * <p>Devuelve una lista inmutable ({@code toList()} sobre un stream la produce asi), de modo
     * que la respuesta no pueda modificarse despues de construida.
     *
     * @param origen lista del core. Se tolera {@code null} y se devuelve {@code []}, para que el
     *               contrato de "coleccion vacia, nunca nula" se cumpla ya en la traduccion y no
     *               dependa solo del blindaje de los records
     */
    public static List<MovimientoWebResponse> movimientos(List<MovimientoCoreDto> origen) {
        if (origen == null) {
            return List.of();
        }
        return origen.stream().map(TraductorWeb::movimiento).toList();
    }

    /**
     * Copia el bloque de paginacion del core al del canal.
     *
     * <p>Hoy los cuatro campos coinciden uno a uno y este metodo parece burocracia pura. Es el
     * precio, consciente y barato, de que los dos contratos sean independientes: el dia que el
     * core agregue un campo, este canal decide si lo expone; el dia que el navegador necesite un
     * campo calculado, se agrega aqui sin tocar el core ni a los otros dos canales.
     *
     * <p>Se tolera {@code null} porque un core que respondiera sin bloque de paginacion no debe
     * traducirse en un {@code NullPointerException} del canal: se devuelve una paginacion vacia
     * coherente, que es informacion honesta y no una caida.
     */
    public static PaginacionWebResponse paginacion(PaginacionCoreDto origen) {
        if (origen == null) {
            return new PaginacionWebResponse(0, 0, 0, 0);
        }
        return new PaginacionWebResponse(
                origen.pagina(),
                origen.tamano(),
                origen.totalElementos(),
                origen.totalPaginas());
    }

    /**
     * Construye el bloque de paginacion cuando <strong>no</strong> lo entrega el core, sino que
     * lo calcula este canal.
     *
     * <p>Hace falta en el objeto W2: alli el BFF pide al core la cuenta completa (porque necesita
     * todos los movimientos para calcular el resumen) y despues recorta el mismo la primera
     * pagina. Como esa peticion al core no fue paginada, no llega ningun bloque de paginacion y
     * hay que fabricarlo con los numeros que el canal acaba de decidir.
     *
     * <p><strong>El calculo de {@code totalPaginas} y su caso borde.</strong> Se usa la division
     * entera hacia arriba, {@code (total + tamano - 1) / tamano}, en vez de
     * {@code Math.ceil((double) total / tamano)}: no convierte a coma flotante, asi que no hay
     * ninguna sorpresa de redondeo. Con {@code totalElementos} en cero (la cuenta 130) el
     * resultado es cero paginas, que es lo correcto: no existe "la pagina 1 vacia". Y como
     * {@code tamano} nunca puede ser cero (lo garantiza {@code CanalWebProperties}), esta division
     * <strong>no puede</strong> dividir por cero; aun asi se comprueba, porque el costo de la
     * comprobacion es una linea y el costo de equivocarse es una caida del canal.
     *
     * @param pagina         indice de la pagina entregada, base cero
     * @param tamano         tamano de pagina que el canal decidio
     * @param totalElementos cuantos elementos hay en total
     */
    public static PaginacionWebResponse paginacionCalculada(int pagina, int tamano, int totalElementos) {
        int totalPaginas = tamano <= 0 ? 0 : (totalElementos + tamano - 1) / tamano;
        return new PaginacionWebResponse(pagina, tamano, totalElementos, totalPaginas);
    }
}
