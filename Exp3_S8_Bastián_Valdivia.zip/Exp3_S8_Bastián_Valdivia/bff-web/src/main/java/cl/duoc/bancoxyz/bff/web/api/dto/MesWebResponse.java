package cl.duoc.bancoxyz.bff.web.api.dto;

import java.math.BigDecimal;

/**
 * Una fila del resumen mensual: los agregados de <strong>un</strong> mes.
 *
 * <p>Tiene los mismos tres agregados que {@link ResumenWebResponse}, calculados sobre el
 * subconjunto de movimientos de un mes en vez de sobre la cuenta completa, mas la etiqueta del
 * mes. Se declara como un record propio y no se reutiliza {@code ResumenWebResponse} con un campo
 * extra porque son dos conceptos distintos que hoy coinciden: el resumen de la ficha responde
 * "como va esta cuenta", y esta fila responde "como fue marzo". Fundirlos ataria la evolucion de
 * los dos objetos.
 *
 * @param mes                 etiqueta del mes en formato congelado {@code yyyy-MM}, por ejemplo
 *                            {@code 2024-03}. Se envia como texto y no como fecha a proposito: un
 *                            mes no es un dia, y elegir {@code 2024-03-01} para representarlo
 *                            invitaria a la interfaz a mostrar un "1 de marzo" que no significa
 *                            nada. El formato ademas ordena alfabeticamente igual que
 *                            cronologicamente, lo que hace trivial ordenar la tabla en el
 *                            navegador
 * @param totalAbonos         suma de los {@code DEPOSITO} de ese mes
 * @param totalCargos         suma de los {@code RETIRO}, {@code COMPRA} y {@code PAGO} de ese mes
 * @param cantidadMovimientos cuantos movimientos hubo ese mes
 */
public record MesWebResponse(
        String mes,
        BigDecimal totalAbonos,
        BigDecimal totalCargos,
        int cantidadMovimientos) {
}
