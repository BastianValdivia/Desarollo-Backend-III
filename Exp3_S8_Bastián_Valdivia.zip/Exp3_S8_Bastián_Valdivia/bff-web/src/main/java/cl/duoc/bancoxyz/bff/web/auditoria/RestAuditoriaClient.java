package cl.duoc.bancoxyz.bff.web.auditoria;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

/**
 * El adaptador HTTP hacia el auditoria-service: la unica clase del canal web que conoce las rutas de su API.
 *
 * <p>Llama a {@code http://auditoria-service/internal/v1/auditoria/...}: el nombre logico lo resuelve el
 * balanceador del lado del cliente con la lista de Eureka (ningun servicio conoce la direccion de otro), y el
 * interceptor del token de servicio adjunta el JWT del BFF web, que el auth-server emitio con el scope
 * {@code auditoria:leer} y la audiencia {@code auditoria-service}. El token es el mismo que usa el cliente del
 * core (un solo token en cache, un solo hilo renovandolo).
 *
 * <p>Traduce TODO fallo (conexion rechazada, timeout, ninguna instancia, un 401, 403 o 5xx) a
 * {@link AuditoriaNoDisponibleException}: para el panel, que el servicio este caido o que rechace el token es lo
 * mismo (la seccion no esta disponible), y la causa queda en la excepcion y en el log. Un 401 o 403 aqui indica
 * una configuracion rota (al token le falta el scope o la audiencia) y no se arregla reintentando, pero tampoco
 * debe tumbar el panel.
 *
 * <p>No lleva proteccion de Resilience4j: la agrega {@link AuditoriaClientResiliente}, que decora a esta clase.
 */
@Component
public class RestAuditoriaClient implements AuditoriaClient {

    private static final String RAIZ = "/internal/v1/auditoria";

    private final RestClient http;

    public RestAuditoriaClient(@LoadBalanced RestClient.Builder plantilla, AuditoriaClientProperties propiedades,
                               @Qualifier("tokenServicioInterceptor") ClientHttpRequestInterceptor tokenServicio) {
        SimpleClientHttpRequestFactory fabrica = new SimpleClientHttpRequestFactory();
        fabrica.setConnectTimeout(propiedades.timeoutConexion());
        fabrica.setReadTimeout(propiedades.timeoutLectura());

        this.http = plantilla.clone()
                .requestInterceptors(interceptores -> {
                    // El mas externo: convierte "no hay instancia que elegir" en un fallo de E/S que este
                    // adaptador sabe traducir (sin esto saldria una IllegalStateException del balanceador).
                    interceptores.add(0, traducirFallosDeDespacho());
                    // Antes del balanceador: el token viaja con la peticion a la instancia que se elija.
                    interceptores.add(1, tokenServicio);
                })
                .baseUrl(propiedades.baseUrl())
                .requestFactory(fabrica)
                .defaultStatusHandler(HttpStatusCode::isError, (peticion, respuesta) -> {
                    throw new AuditoriaNoDisponibleException("El auditoria-service respondio "
                            + respuesta.getStatusCode().value() + " a " + peticion.getURI().getPath());
                })
                .build();
    }

    @Override
    public ResumenAuditoriaDto resumen() {
        return ejecutar("/resumen", () -> http.get().uri(RAIZ + "/resumen").retrieve()
                .body(ResumenAuditoriaDto.class));
    }

    @Override
    public PaginaEventosAuditoriaDto recientes(Integer cuenta, int tamano) {
        return ejecutar("/eventos", () -> http.get().uri(constructor -> {
                    constructor.path(RAIZ + "/eventos").queryParam("tamano", tamano);
                    if (cuenta != null) {
                        constructor.queryParam("cuenta", cuenta);
                    }
                    return constructor.build();
                }).retrieve().body(PaginaEventosAuditoriaDto.class));
    }

    private <T> T ejecutar(String ruta, java.util.function.Supplier<T> llamada) {
        try {
            T cuerpo = llamada.get();
            if (cuerpo == null) {
                throw new AuditoriaNoDisponibleException("El auditoria-service respondio sin cuerpo a " + ruta);
            }
            return cuerpo;
        } catch (AuditoriaNoDisponibleException yaTraducida) {
            throw yaTraducida;
        } catch (ResourceAccessException sinRespuesta) {
            throw new AuditoriaNoDisponibleException("El auditoria-service no respondio a " + ruta
                    + ": puede estar detenido o haber superado el timeout.", sinRespuesta);
        } catch (RestClientException otro) {
            throw new AuditoriaNoDisponibleException("Respuesta ilegible del auditoria-service en " + ruta, otro);
        }
    }

    private static ClientHttpRequestInterceptor traducirFallosDeDespacho() {
        return (peticion, cuerpo, ejecucion) -> {
            try {
                return ejecucion.execute(peticion, cuerpo);
            } catch (IllegalStateException | IllegalArgumentException sinInstancia) {
                throw new IOException("No se pudo elegir una instancia de " + peticion.getURI().getHost()
                        + ": " + sinInstancia.getMessage(), sinInstancia);
            }
        };
    }
}
