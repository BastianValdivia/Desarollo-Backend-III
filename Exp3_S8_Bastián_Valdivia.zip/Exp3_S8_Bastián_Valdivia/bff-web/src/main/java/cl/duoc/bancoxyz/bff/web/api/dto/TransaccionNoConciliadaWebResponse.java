package cl.duoc.bancoxyz.bff.web.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Una fila del lote no conciliado (W5), publicada <strong>tal como vino del archivo</strong>.
 *
 * <p>Los cuatro nombres estan congelados en la seccion 5.15 del contrato, y aqui lo importante no
 * es la forma sino la honestidad de los valores:
 *
 * <ul>
 *   <li><strong>{@code id} no es un {@code cuentaId}.</strong> Es el identificador propio del
 *       archivo, de 1 a 1000. Confundirlos llevaria a un ejecutivo a buscar la cuenta 837, que
 *       existe en esta tabla y no existe en el banco.</li>
 *   <li><strong>{@code fecha} y {@code monto} pueden ser {@code null}</strong>, y se publican
 *       nulos: la fecha cuando el archivo traia un formato ilegible, el monto cuando venia vacio.
 *       Rellenarlos con la fecha de hoy o con un cero seria inventar un dato financiero.</li>
 *   <li><strong>{@code tipo} es el valor crudo del CSV</strong>, sin normalizar, incluidos
 *       {@code invalid} y {@code desconocido}. Es el unico sitio del sistema donde un enumerado no
 *       va en mayusculas, y es a proposito: normalizarlo aqui esconderia que el archivo esta
 *       sucio.</li>
 * </ul>
 *
 * <p><strong>La regla que gobierna esta clase entera:</strong> el lote no esta conciliado y no se
 * debe maquillar. El contrato prohibe expresamente inventar una asignacion de cuenta para estas
 * filas (por modulo, por turno o al azar): {@code transacciones.csv} no tiene columna de cuenta y
 * no puede tenerla. Declarar honestamente que el archivo no se pudo conciliar es mejor que fabricar
 * un vinculo que nadie podria auditar.
 *
 * @param id     identificador propio del archivo, de 1 a 1000
 * @param fecha  fecha del movimiento, o {@code null} si venia ilegible
 * @param monto  importe, o {@code null} si venia vacio
 * @param tipo   valor crudo del CSV, sin normalizar
 */
public record TransaccionNoConciliadaWebResponse(
        int id,
        LocalDate fecha,
        BigDecimal monto,
        String tipo) {
}
