package cl.duoc.bancoxyz.bff.web.aplicacion;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;

/**
 * Cache de la ficha de cuenta del <strong>canal web</strong>, y de ningun otro canal.
 *
 * <p><strong>Que problema resuelve.</strong> Las tres operaciones del canal web que necesitan la
 * cuenta completa (la ficha W2 y el resumen mensual W4) hacen cada una un viaje al
 * {@code core-service}. Un usuario que abre su panel y luego pincha "resumen mensual" provoca
 * dos viajes por los mismos 4669 bytes. Con esta cache, el segundo viaje no ocurre. Lo que se
 * ahorra no son milisegundos en la pantalla del usuario: es <strong>carga en el core</strong>, que
 * es un recurso compartido por los tres canales. Esa distincion es la mitad del criterio que a
 * menudo se deja sin poblar, porque es la unica de las dos que no se ve en el cronometro.
 *
 * <h2>Por que esta clase existe, en vez de poner la anotacion en CuentaWebService</h2>
 *
 * <p>Hay dos razones, y ninguna es estetica.
 *
 * <p><strong>Razon 1: la trampa de la autoinvocacion.</strong> {@code @Cacheable} no es magia del
 * compilador: Spring la implementa envolviendo el bean en un <em>proxy</em>, un objeto intermedio
 * que se pone delante y que, antes de dejar pasar la llamada, mira si la respuesta ya esta
 * guardada. Ese proxy solo puede interceptar llamadas que <em>entran desde fuera</em> del objeto.
 * Si un metodo de {@code CuentaWebService} llamara a otro metodo anotado de
 * {@code CuentaWebService}, la llamada viajaria por {@code this}, por dentro, sin pasar por el
 * proxy, y <strong>la cache no se activaria jamas, sin producir ningun error</strong>. El sintoma
 * seria el peor posible: todo funciona, la configuracion existe, y el ahorro simplemente no
 * aparece. Al vivir la anotacion en un bean <em>distinto</em>, la llamada cruza el proxy
 * siempre. La trampa queda eliminada por diseno, no por disciplina.
 *
 * <p><strong>Razon 2, la importante: la cache no debe ver el token.</strong> Los metodos de
 * {@code CuentaWebService} reciben el {@code Jwt} y comprueban la titularidad antes de responder.
 * Si la anotacion estuviera sobre uno de esos metodos, ocurriria una de dos cosas, las dos malas:
 *
 * <ul>
 *   <li>Si la clave de cache incluyera el token, cada usuario tendria su propia entrada y
 *       ademas una entrada nueva por cada login: la cache no acertaria casi nunca y solo
 *       gastaria memoria.</li>
 *   <li>Si la clave fuera solo el {@code cuentaId}, un acierto de cache <strong>se saltaria la
 *       comprobacion de titularidad</strong>, porque en un acierto el cuerpo del metodo no se
 *       ejecuta. El usuario A pediria la cuenta de B y la recibiria. Eso no es un problema de
 *       rendimiento: es una fuga de datos de otro cliente, introducida por una optimizacion.</li>
 * </ul>
 *
 * <p>La regla general que hay que llevarse: <strong>cachear un metodo equivale a no ejecutar su
 * cuerpo</strong>. Todo lo que ese cuerpo hacia (validar, autorizar, auditar) deja de ocurrir en
 * los aciertos. Por eso lo que se cachea aqui es exclusivamente el <em>dato</em> traido del core,
 * y la autorizacion se queda fuera, en {@link CuentaWebService}, donde se ejecuta siempre.
 *
 * <h2>Por que el TTL es de 60 segundos</h2>
 *
 * <p>El TTL no se elige por cuanto se quiere ahorrar, sino respondiendo a una sola pregunta:
 * <strong>que hace el usuario con este numero</strong>. El usuario del canal web esta mirando un
 * panel en un navegador: revisa su historial, compara meses, recarga la pagina. No hay dinero
 * moviendose contra ese saldo. Un valor con hasta un minuto de antiguedad no lo induce a ningun
 * error, y en cambio absorbe entera la rafaga tipica del canal, que es un usuario recargando o
 * navegando entre las tres vistas de su cuenta.
 *
 * <p>La comparacion entre canales es lo que demuestra que la decision fue deliberada:
 *
 * <table border="1">
 *   <caption>TTL por canal y el motivo, que es siempre el uso y nunca el dispositivo</caption>
 *   <tr><th>Canal</th><th>TTL</th><th>Que hace el usuario con el numero</th></tr>
 *   <tr><td>Cajero</td><td><strong>sin cache</strong></td>
 *       <td>La maquina entrega billetes contra el. Un dato viejo entrega dinero que no existe</td></tr>
 *   <tr><td>Movil</td><td>30 s</td>
 *       <td>Consulta el saldo, a menudo justo despues de retirar en un cajero</td></tr>
 *   <tr><td>Web</td><td><strong>60 s</strong></td>
 *       <td>Revisa historial y agregados en una pantalla grande. Es analisis, no caja</td></tr>
 * </table>
 *
 * <p>El TTL efectivo lo fija {@code spring.cache.caffeine.spec} en el {@code config-repo/bff-web.yml} de
 * este modulo, junto con el {@code maximumSize} que acota la memoria. Ambos valores viven alli, y
 * no aqui, porque son <strong>politica operable</strong>: se ajustan sin recompilar.
 */
@Component
public class CacheCuentaWeb {

    /**
     * Nombre de la cache. Es una constante y no un literal suelto porque el mismo nombre aparece
     * en el {@code config-repo/bff-web.yml}, en las pruebas y en la evidencia: un nombre escrito cuatro
     * veces a mano es un desacuerdo esperando ocurrir, y una cache con el nombre mal escrito no
     * falla, simplemente nunca acierta.
     */
    public static final String NOMBRE_CACHE = "cuenta-web";

    private static final Logger log = LoggerFactory.getLogger(CacheCuentaWeb.class);

    /** Espacio del respaldo (ultimo dato conocido) donde se guarda la cuenta; lo lee {@link CuentaWebService}. */
    static final String ESPACIO_RESPALDO = "cuenta";

    private final CoreClient core;
    private final RespaldoDeLecturas respaldo;

    public CacheCuentaWeb(CoreClient core, RespaldoDeLecturas respaldo) {
        this.core = core;
        this.respaldo = respaldo;
    }

    /**
     * Devuelve la cuenta completa del core, sirviendola de memoria si ya se pidio hace poco.
     *
     * <p>La clave de cache es el {@code cuentaId} y nada mas. Se escribe explicitamente con
     * {@code key = "#cuentaId"} en vez de dejar la clave por defecto: la clave por defecto se
     * construye con <em>todos</em> los parametros del metodo, asi que hoy daria el mismo
     * resultado, pero el dia que alguien agregue un segundo parametro la clave cambiaria sola y
     * en silencio. Escribirla deja la intencion fijada.
     *
     * <p><strong>Este metodo no comprueba titularidad a proposito.</strong> No recibe el token
     * porque no debe verlo: en un acierto de cache su cuerpo no se ejecuta, de modo que cualquier
     * control que viviera aqui dejaria de aplicarse justo cuando la cache funciona. Quien llama
     * ({@link CuentaWebService}) ya autorizo.
     *
     * <p>El {@code log.debug} solo se imprime en los <strong>fallos</strong> de cache, porque en
     * un acierto el cuerpo no corre. Eso lo convierte en el instrumento exacto para comprobar
     * que la cache funciona: dos peticiones seguidas deben dejar <em>una</em> linea, no dos.
     */
    @Cacheable(cacheNames = NOMBRE_CACHE, key = "#cuentaId")
    public CuentaCoreDto obtenerCuenta(int cuentaId) {
        log.debug("FALLO DE CACHE para la cuenta {}: se viaja al core", cuentaId);
        CuentaCoreDto cuenta = core.obtenerCuenta(cuentaId);
        // F6: el dato recien traido del core queda tambien como "ultimo dato conocido". Se guarda AQUI,
        // en el unico punto que viaja al core, y no en cada acierto de cache: asi la antiguedad que se
        // informa si el core cae es la real y no la del ultimo acierto.
        respaldo.respaldar(ESPACIO_RESPALDO, cuentaId, cuenta);
        return cuenta;
    }

    /**
     * Expulsa de la cache la ficha de una cuenta.
     *
     * <p>No lo usa ningun flujo del canal web, porque el canal web no mueve dinero: sus tres
     * endpoints son de lectura. Existe para que la prueba automatizada pueda dejar la cache
     * limpia entre casos, y para que el dia que este canal reciba una operacion de escritura
     * exista ya el gancho correcto en vez de improvisarlo.
     *
     * <p>Conviene ver la limitacion de frente: quien mueve el saldo de verdad es el
     * <em>cajero</em>, que es otro proceso y otra JVM. Esta cache no se entera de ese retiro y
     * seguira sirviendo el saldo viejo hasta que expire su TTL. Esa es precisamente la razon de
     * que el TTL sea corto y de que el cajero no cachee nada: en un sistema de varios procesos,
     * el TTL <strong>es</strong> el mecanismo de invalidacion, y la unica pregunta honesta es
     * cuanta antiguedad tolera cada canal.
     */
    @CacheEvict(cacheNames = NOMBRE_CACHE, key = "#cuentaId")
    public void olvidarCuenta(int cuentaId) {
        log.debug("Cache de la cuenta {} invalidada explicitamente", cuentaId);
    }
}
