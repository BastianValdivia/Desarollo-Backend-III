package cl.duoc.bancoxyz.bff.web.api.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import cl.duoc.bancoxyz.bff.web.auditoria.EventoAuditoriaDto;
import cl.duoc.bancoxyz.bff.web.auditoria.ResumenAuditoriaDto;

/**
 * El panel del ejecutivo: dos secciones independientes en una sola respuesta.
 *
 * <p>Cada seccion dice si esta disponible. Si el servicio que la alimenta no responde (el core para la calidad
 * de los datos, el auditoria-service para la actividad), esa seccion sale marcada como no disponible, con un
 * aviso, y la otra se entrega igual: el panel degrada por secciones en vez de fallar entero.
 *
 * @param calidadDatos reporte de calidad de la ingesta, que calcula el core
 * @param actividad    actividad reciente del banco, que guarda el auditoria-service a partir de los eventos de Kafka
 */
public record PanelEjecutivoWebResponse(SeccionCalidad calidadDatos, SeccionActividad actividad) {

    /**
     * @param disponible si la seccion se pudo armar
     * @param aviso      por que no esta (solo cuando no esta disponible)
     * @param reporte    el reporte de calidad (solo cuando esta disponible)
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record SeccionCalidad(boolean disponible, String aviso, ReporteCalidadWebResponse reporte) {

        public static SeccionCalidad con(ReporteCalidadWebResponse reporte) {
            return new SeccionCalidad(true, null, reporte);
        }

        public static SeccionCalidad noDisponible(String aviso) {
            return new SeccionCalidad(false, aviso, null);
        }
    }

    /**
     * @param disponible si la seccion se pudo armar
     * @param aviso      por que no esta (solo cuando no esta disponible)
     * @param resumen    cuantos eventos hay, en total y por tipo (solo cuando esta disponible)
     * @param recientes  los eventos mas recientes, del mas nuevo al mas antiguo (solo cuando esta disponible)
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record SeccionActividad(boolean disponible, String aviso, ResumenAuditoriaDto resumen,
                                   List<EventoAuditoriaDto> recientes) {

        public static SeccionActividad con(ResumenAuditoriaDto resumen, List<EventoAuditoriaDto> recientes) {
            return new SeccionActividad(true, null, resumen, recientes);
        }

        public static SeccionActividad noDisponible(String aviso) {
            return new SeccionActividad(false, aviso, null, null);
        }
    }
}
