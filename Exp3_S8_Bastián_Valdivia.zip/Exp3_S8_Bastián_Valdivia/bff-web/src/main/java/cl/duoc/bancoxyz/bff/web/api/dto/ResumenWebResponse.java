package cl.duoc.bancoxyz.bff.web.api.dto;

import java.math.BigDecimal;

/**
 * El bloque {@code resumen} de la ficha de cuenta: <strong>el unico dato de toda esta API que no
 * existe en ninguna parte del {@code core-service}</strong>.
 *
 * <p><strong>Aqui esta la mitad del argumento del canal web.</strong> El otro canal, el movil,
 * aporta valor <em>recortando</em>: entrega menos de lo que el core sabe. Este canal aporta valor
 * <em>agregando</em>: entrega algo que el core no sabe calcular, y lo entrega en la misma
 * respuesta que la ficha y los movimientos.
 *
 * <p>Sin este bloque, un navegador que quisiera mostrar "abonos del periodo" y "cargos del
 * periodo" en la cabecera de la pantalla tendria que traerse los 42 movimientos de la cuenta 116
 * (o los 686 del banco entero, si la cuenta fuera mas grande), sumarlos en JavaScript y volver a
 * hacerlo cada vez que el usuario recargue. Tres consecuencias, todas malas: viajan datos que
 * solo sirven para ser sumados y despues descartados; la regla de que un {@code DEPOSITO} es
 * abono y todo lo demas es cargo queda escrita en el navegador, donde cualquiera puede leerla y
 * donde dos pantallas distintas terminan implementandola distinto; y el calculo se repite en cada
 * cliente en vez de hacerse una vez en el servidor.
 *
 * <p><strong>Por que el calculo no vive en el {@code core-service}.</strong> Porque no es una
 * verdad del dominio bancario, es una necesidad de <em>esta</em> pantalla. El cajero no la
 * necesita y el movil tampoco. Meterla en el core obligaria a los tres canales a cargar con
 * ella y convertiria al core en el sitio donde se acumulan las peticiones particulares de cada
 * pantalla, que es justamente el problema que el patron BFF viene a resolver.
 *
 * @param totalAbonos         suma de los montos de los movimientos de tipo {@code DEPOSITO}.
 *                            Vale {@code 0.00}, nunca {@code null}, si no hay ninguno
 * @param totalCargos         suma de los montos de todos los demas tipos ({@code RETIRO},
 *                            {@code COMPRA}, {@code PAGO}). Positiva: es una magnitud, no un saldo
 * @param cantidadMovimientos cuantos movimientos se consideraron para las dos sumas. Es
 *                            <strong>el total de la cuenta</strong>, no los 20 de la primera
 *                            pagina: un resumen que solo resumiera la pagina visible no seria un
 *                            resumen de nada
 */
public record ResumenWebResponse(
        BigDecimal totalAbonos,
        BigDecimal totalCargos,
        int cantidadMovimientos) {
}
