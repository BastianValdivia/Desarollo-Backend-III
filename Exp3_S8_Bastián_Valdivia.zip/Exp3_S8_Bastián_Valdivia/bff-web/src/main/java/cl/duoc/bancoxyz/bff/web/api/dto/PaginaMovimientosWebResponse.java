package cl.duoc.bancoxyz.bff.web.api.dto;

import java.util.List;

/**
 * La respuesta de {@code GET /api/web/v1/cuentas/{id}/movimientos}: el endpoint
 * <strong>W3</strong> del contrato.
 *
 * <p><strong>Por que este endpoint existe si W2 ya devuelve movimientos.</strong> Porque son dos
 * momentos distintos de la misma pantalla. W2 es la carga inicial: el navegador llega sin nada y
 * necesita todo de una vez. W3 es lo que ocurre despues, cuando el usuario pulsa "siguiente" o
 * filtra por fechas: ahi la ficha del titular, el saldo y el resumen <strong>no han
 * cambiado</strong>, y volver a enviarlos seria pagar de nuevo por datos que el navegador ya
 * tiene en memoria.
 *
 * <p>Por eso este objeto trae solo tres cosas y, a diferencia de W2, <strong>no trae el bloque
 * {@code resumen}</strong>. Esa ausencia es deliberada y conviene saber defenderla: el resumen
 * se calcula sobre <em>todos</em> los movimientos de la cuenta, asi que repetirlo en cada pagina
 * seria repetir siempre el mismo valor, y hacerlo obligaria al BFF a traerse la cuenta completa
 * desde el core en cada paso de paginacion. Dicho de otro modo: si este endpoint devolviera el
 * resumen, seria mas caro aguas arriba que W2 para entregar menos informacion.
 *
 * <p>La consecuencia en llamadas al core es visible: W2 llama a {@code /cuentas/{id}} (cuenta
 * completa, porque necesita sumar todo), y W3 llama a {@code /cuentas/{id}/movimientos}, que es
 * el endpoint paginado del core y por lo tanto mueve solo la pagina pedida. El canal elige, para
 * cada uno de sus endpoints, la llamada aguas arriba mas barata que basta.
 *
 * @param cuentaId    la cuenta consultada. Se repite en el cuerpo aunque ya venga en la URL para
 *                    que la respuesta sea autodescriptiva al leerla en un archivo de evidencia
 * @param movimientos la pagina pedida, con movimientos de cuatro campos. Lista vacia, nunca
 *                    {@code null}
 * @param paginacion  el bloque congelado en la seccion 5.6 del contrato
 */
public record PaginaMovimientosWebResponse(
        int cuentaId,
        List<MovimientoWebResponse> movimientos,
        PaginacionWebResponse paginacion) {

    /** Misma proteccion que en {@code CuentaWebResponse}: lista vacia, nunca {@code null}. */
    public PaginaMovimientosWebResponse {
        movimientos = movimientos == null ? List.of() : List.copyOf(movimientos);
    }
}
