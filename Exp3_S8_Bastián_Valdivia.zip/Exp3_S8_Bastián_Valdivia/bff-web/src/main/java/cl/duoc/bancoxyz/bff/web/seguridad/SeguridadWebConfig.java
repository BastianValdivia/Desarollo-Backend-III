package cl.duoc.bancoxyz.bff.web.seguridad;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;

import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.oauth2.FiltroAutenticacionNoDisponible;

/**
 * La cadena de filtros del canal web: quien entra, y a que.
 *
 * <h2>Que es una "cadena de filtros", para quien recien pregunto que es un puerto</h2>
 *
 * <p>Antes de llegar a un controlador, una peticion atraviesa una fila de filtros, cada uno con una
 * tarea. Aqui importan tres: uno lee la cabecera {@code Authorization} y valida el token, otro
 * compara el resultado con las reglas de abajo, y un tercero convierte un rechazo en una respuesta
 * HTTP. Un controlador de este modulo solo se ejecuta si la peticion atraveso la fila entera. Esa
 * es la propiedad que hace que la seguridad no dependa de que alguien se acuerde de comprobarla
 * dentro de cada metodo.
 *
 * <h2>Mecanismo compartido, politica propia</h2>
 *
 * <p>Los tres BFF usan el <strong>mismo mecanismo</strong>: HTTPS con certificado propio, JWT
 * firmado en RS256 por el servidor de autorizacion, validacion delegada en el resource server (firma
 * por JWKS, emisor y audiencia), sesion sin estado y las mismas cabeceras de seguridad. Ningun BFF
 * emite ni firma tokens: el login vive en el {@code auth-server} (fase F5). Lo que <strong>no</strong>
 * comparten es la politica, y esta clase es donde se escribe la de este canal: el token de este canal
 * es el que se pide a {@code web-app} (audiencia {@code bff-web}, 30 minutos), y cada ruta exige la
 * autoridad que le corresponde.
 *
 * <h2>Lo que este canal demuestra y los otros dos no pueden</h2>
 *
 * <p>Es el unico con <strong>dos perfiles</strong>: cliente y ejecutivo. Los dos inician sesion en el
 * mismo formulario del auth-server, reciben tokens igual de validos, firmados con la misma clave y con la
 * misma audiencia, y aun asi obtienen respuestas distintas. Eso es lo que prueba que la autorizacion de
 * este sistema es <strong>por permiso y no solo por canal</strong>:
 *
 * <table border="1">
 *   <caption>Dos identidades del mismo canal frente a las mismas rutas</caption>
 *   <tr><th>Ruta</th><th>{@code cliente116}</th><th>{@code ejecutivo1}</th></tr>
 *   <tr><td>W2 {@code /v1/cuentas/116}</td><td>200</td><td>403 {@code permiso_insuficiente}</td></tr>
 *   <tr><td>W5 {@code /v1/admin/transacciones-no-conciliadas}</td><td>403 {@code permiso_insuficiente}</td><td>200</td></tr>
 *   <tr><td>W6 {@code /v1/admin/calidad-datos}</td><td>403 {@code permiso_insuficiente}</td><td>200</td></tr>
 * </table>
 *
 * <p>El detalle que convierte esa tabla en una prueba de diseno y no en una casualidad: las rutas
 * de administracion <strong>existen</strong> en este canal. Un cliente sin el rol recibe
 * <strong>403</strong>, no 404. Un 404 diria "aqui no hay nada" y seria mentira; el 403 dice la
 * verdad, que es "esto existe y no es para ti". El 404 queda reservado para lo que de verdad no
 * vive en este canal, como el retiro del cajero.
 *
 * <h2>Las reglas, y por que el orden es parte de la regla</h2>
 *
 * <p>Se evaluan de arriba abajo y gana la primera que coincide, asi que lo especifico va antes que
 * lo general y {@code anyRequest()} va siempre al final. Con {@code anyRequest().authenticated()}
 * arriba, las lineas siguientes no se leerian jamas y una ruta que deberia exigir un permiso
 * concreto se contentaria con cualquier token valido, sin que nada fallara ni avisara.
 *
 * <p>La unica ruta abierta es la salud, porque el guion de arranque necesita esperar a que el servicio
 * responda antes de tener credencial alguna (el login ya no esta aqui: el token se pide al
 * {@code auth-server}, ver {@code scripts/login-web.sh}). Esta regla de la salud solo se ejerce cuando Actuator
 * comparte el puerto del canal (el perfil de prueba); desde F1, en el despliegue, Actuator vive en
 * un puerto de gestion aparte cuya cadena {@code SeguridadPuertoGestionConfig} deja pasar sin
 * token. {@code /actuator/metrics} sigue cubierto por {@code anyRequest().authenticated()}: en el
 * puerto del canal responde 401 sin token (y 404 con token, porque ahi no esta publicado), y las
 * metricas se leen en el puerto de gestion.
 *
 * <h2>Por que aqui no hay ni un {@code @PreAuthorize}</h2>
 *
 * <p>Decision congelada del contrato (seccion 6.4) y vale para los tres canales.
 * {@code @PreAuthorize} <strong>sin</strong> {@code @EnableMethodSecurity} se ignora en absoluto
 * silencio: el codigo compila, arranca y parece correcto, pero ninguna regla se aplica. Se prueba
 * la cuenta ajena, sale 200 donde se esperaba 403, y no hay ninguna pista de por que. Con las
 * reglas aqui y la titularidad como comprobacion explicita en el servicio, esa clase de fallo no
 * existe.
 */
@Configuration
public class SeguridadWebConfig {

    /**
     * Literales de autoridad de este canal, copiados a la letra de la seccion 6.1 del contrato.
     *
     * <p>Se declaran como constantes por una razon muy concreta: la misma cadena aparece en el
     * {@code config-repo/bff-web.yml} (dentro de las autoridades de cada usuario) y en las reglas de abajo.
     * Si las dos copias divergieran en un caracter, el resultado seria un 403 sobre una ruta cuyo
     * token, leido a ojo, parece llevar el permiso correcto. Con constantes, al menos una de las
     * dos mitades deja de compilar, y una prueba automatica comprueba que las del YAML coinciden.
     *
     * <p><strong>Nunca se usa {@code hasRole(...)} en este proyecto, siempre
     * {@code hasAuthority(...)} con el literal completo</strong>, prefijo incluido. Spring antepone
     * {@code ROLE_} por su cuenta dentro de {@code hasRole}, y esa asimetria produce reglas que no
     * coinciden nunca. Con esta convencion, el texto de la regla y el contenido del token son
     * literalmente la misma cadena y se pueden comparar a simple vista entre la evidencia del token
     * decodificado y este archivo.
     */
    public static final String ROLE_EJECUTIVO = "ROLE_EJECUTIVO";

    /** Habilita W2, la ficha de cuenta. */
    public static final String PERM_CUENTA_LEER = "PERM_cuenta:leer";

    /** Habilita W3, la pagina de movimientos. */
    public static final String PERM_MOVIMIENTOS_LEER = "PERM_movimientos:leer";

    /** Habilita W4, el resumen mensual exclusivo de este canal. */
    public static final String PERM_RESUMEN_LEER = "PERM_resumen:leer";

    /**
     * Permiso de auditoria que acompana al rol de ejecutivo en su token.
     *
     * <p>No aparece en ningun {@code requestMatchers} de abajo, y eso es deliberado: el contrato
     * congela en su seccion 6.4 que la regla de las rutas de administracion se escribe sobre
     * {@code ROLE_EJECUTIVO}. La constante existe igualmente porque el literal viaja en el token del
     * ejecutivo (seccion 8 del contrato) y una prueba de este modulo comprueba que el YAML lo
     * escribe exactamente asi. Dicho de otro modo: el rol es hoy la llave, y el permiso es la
     * declaracion de para que sirve esa llave.
     */
    public static final String PERM_AUDITORIA_LEER = "PERM_auditoria:leer";

    @Bean
    SecurityFilterChain cadenaDeFiltros(HttpSecurity http,
                                        PuntoEntradaWeb puntoEntrada,
                                        ManejadorAccesoDenegadoWeb accesoDenegado,
                                        EscritorErrorHttp escritor) throws Exception {
        http
                /*
                 * CSRF DESACTIVADO, Y AQUI ESTA LA JUSTIFICACION, QUE ES LO QUE LO SEPARA DE UN
                 * DESCUIDO.
                 *
                 * El ataque que CSRF previene consiste en que una pagina cualquiera provoque una
                 * peticion al banco desde el navegador de la victima, aprovechando que el navegador
                 * adjunta AUTOMATICAMENTE las cookies del banco: la credencial viaja sola, sin que
                 * el atacante necesite leerla ni conocerla.
                 *
                 * Aqui no hay cookie ni sesion. La credencial de este canal viaja en la cabecera
                 * Authorization, y esa cabecera no la pone nadie por su cuenta: hay que escribirla
                 * en cada peticion, y para escribirla hay que haber leido antes el token. Sin
                 * adjuntado automatico, el vector no existe.
                 *
                 * Es la unica de las tres desactivaciones del proyecto que hay que justificar por
                 * escrito, precisamente porque este canal SI habla con un navegador y a primera
                 * vista parece el que mas la necesitaria. Lo que la hace innecesaria no es el
                 * cliente, es donde viaja la credencial.
                 */
                .csrf(AbstractHttpConfigurer::disable)

                /*
                 * SESION SIN ESTADO. El servidor no guarda nada entre peticiones: cada una trae su
                 * propia prueba de identidad o no es nadie. Tres consecuencias:
                 *
                 * 1. No hay JSESSIONID que robar ni sesion que fijar, y por eso mismo tampoco hay
                 *    nada que el navegador adjunte solo (ver la nota de CSRF de arriba).
                 * 2. La matriz de cruce de tokens es limpia: una peticion que debia fallar no puede
                 *    pasar por una sesion residual que quedo de la peticion anterior.
                 * 3. El canal escala sin estado compartido, que es la razon por la que este estilo
                 *    se impuso en las APIs.
                 */
                .sessionManagement(sesion -> sesion.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                .authorizeHttpRequests(reglas -> reglas
                        // W7: la salud se consulta sin credencial (el guion de arranque espera
                        // al servicio antes de tener token). Esta regla solo se ejerce si Actuator comparte
                        // el puerto del canal (pruebas); en el despliegue la salud esta en el
                        // puerto de gestion (F1) y esta ruta, en el del canal, responde 404. Se
                        // escribe sin /api/web porque las reglas usan la ruta relativa al contexto.
                        .requestMatchers(HttpMethod.GET, "/actuator/health").permitAll()

                        /*
                         * W5 y W6, LAS RUTAS DE ADMINISTRACION. Nivel 1 de autorizacion del
                         * contrato: el ROL.
                         *
                         * Es la regla que hace visible la diferencia entre dos usuarios del MISMO
                         * canal. Un cliente llega hasta aqui con un token perfectamente valido,
                         * firmado por este canal y con la audiencia correcta, y se va con 403
                         * permiso_insuficiente. No con 404: la ruta existe, lo que falta es el
                         * derecho, y responder 404 seria mentir sobre el catalogo del canal.
                         *
                         * Se escribe con /v1/admin/** y no con las dos rutas por separado a
                         * proposito: cualquier endpoint de administracion que se agregue manana
                         * nace protegido. El caso por defecto de un prefijo entero es la unica
                         * forma de que "se me olvido proteger el nuevo" no sea posible.
                         */
                        .requestMatchers("/v1/admin/**").hasAuthority(ROLE_EJECUTIVO)

                        /*
                         * W2, W3 y W4. Nivel 2: el permiso de OPERACION, uno distinto por
                         * operacion. Tres permisos y no uno solo porque "leer la ficha", "paginar
                         * movimientos" y "ver el resumen mensual" son capacidades separables: se
                         * podria emitir manana un perfil que vea la ficha y no el historial sin
                         * tocar una linea de codigo, solo cambiando las autoridades del YAML.
                         *
                         * El orden importa y no es cosmetico. El asterisco de requestMatchers
                         * cubre UN solo segmento, asi que /v1/cuentas/* no coincide con
                         * /v1/cuentas/116/movimientos; aun asi, lo especifico se escribe primero,
                         * que es la convencion que hace que anadir manana una ruta mas larga no
                         * dependa de ese detalle para seguir siendo correcta.
                         *
                         * Ninguna de las tres comprueba que la cuenta sea TUYA: eso no se puede
                         * decidir aqui, porque depende de comparar un claim con un trozo de la URL.
                         * Lo hace GuardiaTitularidadWeb, que es el nivel 3.
                         */
                        .requestMatchers(HttpMethod.GET, "/v1/cuentas/*/movimientos")
                        .hasAuthority(PERM_MOVIMIENTOS_LEER)
                        .requestMatchers(HttpMethod.GET, "/v1/cuentas/*/resumen-mensual")
                        .hasAuthority(PERM_RESUMEN_LEER)
                        .requestMatchers(HttpMethod.GET, "/v1/cuentas/*")
                        .hasAuthority(PERM_CUENTA_LEER)

                        /*
                         * Red de seguridad: todo lo demas exige al menos un token valido. Va al
                         * final y cubre W8 (/actuator/metrics) y cualquier ruta futura. Que el caso
                         * por defecto sea "cerrado" es la diferencia entre olvidarse de proteger
                         * algo nuevo y olvidarse de abrirlo: el segundo olvido se nota en la
                         * primera prueba, el primero no se nota nunca.
                         */
                        .anyRequest().authenticated())

                /*
                 * VALIDACION DEL TOKEN. Esta linea activa el filtro que lee "Authorization: Bearer
                 * ..." y verifica firma, algoritmo, exp, nbf y audiencia. El COMO esta enteramente
                 * en config-repo/bff-web.yml: public-key-location, audiences, authorities-claim-name y
                 * authority-prefix. Cero Java de validacion, que es la decision correcta y no un
                 * atajo (ver el comentario de las dependencias en el pom).
                 *
                 * Los dos manejadores se declaran DOS VECES a proposito, aqui y en
                 * exceptionHandling. No es redundancia: el resource server instala sus propios
                 * manejadores dentro de su configurador, y si solo se pusieran en
                 * exceptionHandling, un token invalido (no ausente) se responderia con el formato
                 * por defecto de Spring en lugar del RFC 7807 del contrato. Se descubre tarde,
                 * porque el caso "sin token" si saldria bien.
                 */
                .oauth2ResourceServer(recurso -> recurso
                        .authenticationEntryPoint(puntoEntrada)
                        .accessDeniedHandler(accesoDenegado)
                        .jwt(Customizer.withDefaults()))

                .exceptionHandling(manejo -> manejo
                        .authenticationEntryPoint(puntoEntrada)
                        .accessDeniedHandler(accesoDenegado))

                /*
                 * Si el auth-server no entrega sus claves, el token no se puede ni verificar: eso es un 503 en
                 * el formato del canal, no un 401 ni un 500 (ver FiltroAutenticacionNoDisponible). Va antes del
                 * filtro de tokens, que es donde nace la excepcion que atrapa.
                 */
                .addFilterBefore(new FiltroAutenticacionNoDisponible(escritor, "WEB"),
                        BearerTokenAuthenticationFilter.class);

        /*
         * No se tocan las cabeceras de seguridad: Spring Security ya emite por defecto
         * X-Content-Type-Options: nosniff, X-Frame-Options: DENY, Cache-Control: no-store y, sobre
         * una conexion segura, HSTS. Escribirlas a mano solo abriria la posibilidad de escribirlas
         * peor.
         *
         * Tampoco se configura CORS todavia. CORS es el permiso que un navegador pide para que una
         * pagina servida desde otro origen hable con esta API, y este es el unico de los tres
         * canales donde tendra sentido. El contrato lo deja explicitamente pendiente en su seccion
         * 10 ("origen permitido de CORS en el canal web"), y mientras no haya un origen congelado,
         * escribir una lista aqui seria inventar politica en el sitio equivocado: el contrato se
         * cambia primero en el documento.
         */
        return http.build();
    }
}
