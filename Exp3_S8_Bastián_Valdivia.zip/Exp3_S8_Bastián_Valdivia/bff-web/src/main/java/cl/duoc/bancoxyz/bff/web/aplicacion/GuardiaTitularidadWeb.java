package cl.duoc.bancoxyz.bff.web.aplicacion;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.bff.web.seguridad.SeguridadWebConfig;
import cl.duoc.bancoxyz.comun.token.LectorClaimsToken;

/**
 * La comprobacion por <strong>dato</strong> del canal web: que la cuenta de la ruta sea la cuenta
 * del token, salvo que quien pregunte sea un ejecutivo.
 *
 * <h2>Por que esto no lo puede hacer la cadena de filtros</h2>
 *
 * <p>Spring Security sabe responder "este token tiene la autoridad {@code PERM_cuenta:leer}?". No
 * sabe responder "este token es de la cuenta 116?", porque eso no depende del token solo: es una
 * comparacion entre un claim y un trozo de la URL. La autorizacion por dato (nivel 3 de la seccion
 * 6.4 del contrato) siempre necesita los dos lados, y por eso vive en la capa de aplicacion y no en
 * la configuracion.
 *
 * <p>Sin esta clase, el canal tendria autenticacion y autorizacion impecables y aun asi
 * <strong>cualquier portador de un token valido podria leer cuentas ajenas</strong>: bastaria con
 * hacer login con el usuario propio y cambiar un numero en la URL. Es el fallo mas facil de cometer
 * de todo el proyecto.
 *
 * <h2>La excepcion del ejecutivo, que es una regla de negocio y no un agujero</h2>
 *
 * <p>El ejecutivo no tiene cuenta propia: su token no lleva claim {@code cuentaId} porque audita, no
 * consulta su saldo. Aplicarle la comparacion literal lo dejaria fuera de <strong>toda</strong>
 * cuenta del banco, que es exactamente lo contrario de su funcion. Por eso el guardia exime a quien
 * porta {@code ROLE_EJECUTIVO}: la titularidad responde "es tuya?", y para un perfil cuya funcion es
 * mirar cuentas de otros esa no es la pregunta correcta.
 *
 * <p><strong>Lo que la exencion NO hace, y conviene tenerlo claro.</strong> No le abre ninguna ruta.
 * El ejecutivo sigue pasando primero por la cadena de filtros, y con las autoridades que el contrato
 * congela para el ({@code ROLE_EJECUTIVO} y {@code PERM_auditoria:leer}, sin
 * {@code PERM_cuenta:leer}) recibe hoy <strong>403 {@code permiso_insuficiente}</strong> en W2, W3 y
 * W4: se queda en el nivel 2 sin llegar al 3. Cada nivel responde su propia pregunta y ninguno
 * suple al otro. El dia que el banco decida que sus ejecutivos consultan fichas, la unica linea que
 * habra que cambiar es la lista de autoridades de ese perfil en el YAML, y esta regla ya estara
 * escrita y probada para recibirlo.
 *
 * <h2>Por que se llama antes de hablar con el core, y no despues</h2>
 *
 * <p>Dos consecuencias exigibles, las dos en la seccion 7.4 del contrato:
 *
 * <ol>
 *   <li>Pedir una cuenta <strong>ajena e inexistente</strong> devuelve 403 {@code cuenta_ajena} y
 *       nunca 404. Si se consultara primero la existencia, las cuentas que existen darian 403 y las
 *       que no darian 404, y comparar las dos respuestas convertiria el endpoint en un detector de
 *       cuentas para cualquiera con un token valido.</li>
 *   <li>La peticion rechazada por titularidad <strong>no genera ni una llamada al core</strong>.
 *       Muere en el canal, que ademas es lo correcto en costo.</li>
 * </ol>
 *
 * <h2>Nota para quien recien pregunto que es un puerto: que es un "claim"</h2>
 *
 * <p>Un token JWT es un texto firmado que contiene afirmaciones sobre quien lo porta. Cada
 * afirmacion es un <i>claim</i>. Aqui se leen dos: el claim propio {@code cuentaId}, que el login
 * copio desde el padron de usuarios, y {@code authorities}, que es de donde el resource server saca
 * los permisos. Se puede confiar en los dos porque la firma ya fue verificada antes de llegar a
 * este metodo: si alguien editara un numero o agregara un rol, la firma dejaria de validar y la
 * peticion nunca habria llegado hasta aqui.
 *
 * <p>Y una trampa concreta que esta clase evita al leer {@code cuentaId} con
 * {@link LectorClaimsToken}: el claim viaja como {@code Long} aunque se escriba como
 * {@code Integer}, asi que un {@code jwt.getClaim("cuentaId").equals(cuentaDeLaRuta)} compila, no
 * lanza nada y devuelve <strong>siempre</strong> falso. El sintoma seria un 403 {@code cuenta_ajena}
 * sobre la propia cuenta del usuario, y el mensaje mandaria a revisar justo donde no esta el
 * problema.
 */
@Component
public class GuardiaTitularidadWeb {

    private static final Logger log = LoggerFactory.getLogger(GuardiaTitularidadWeb.class);

    /**
     * Deja pasar si el token acredita la cuenta pedida o si es un ejecutivo, y lanza 403
     * {@code cuenta_ajena} en cualquier otro caso.
     *
     * <p><strong>Por que recibe el {@link Jwt} y no el {@code Authentication} de Spring
     * Security.</strong> Las autoridades del {@code Authentication} y el claim {@code authorities}
     * del token son la misma informacion: el resource server construye las primeras leyendo el
     * segundo, segun la configuracion {@code authorities-claim-name} y {@code authority-prefix} del
     * YAML. Tomarla del token deja a esta capa sin ninguna dependencia de la maquinaria de
     * autenticacion, y por eso la regla se puede probar con un {@code Jwt} construido a mano, sin
     * contexto de Spring y sin cadena de filtros. Una regla de seguridad que es barata de probar es
     * una regla que de verdad se prueba.
     *
     * @param token          token ya validado por el resource server
     * @param cuentaDeLaRuta valor de {@code {cuentaId}} en la URL
     * @throws ReglaWebException si el token no acredita esa cuenta y no es un ejecutivo
     */
    public void exigirTitularidad(Jwt token, int cuentaDeLaRuta) {
        if (token != null && LectorClaimsToken.autoridades(token)
                .contains(SeguridadWebConfig.ROLE_EJECUTIVO)) {
            log.debug("Titularidad omitida sobre la cuenta {}: el token porta {}.",
                    cuentaDeLaRuta, SeguridadWebConfig.ROLE_EJECUTIVO);
            return;
        }

        Integer cuentaDelToken = token == null ? null : LectorClaimsToken.cuentaId(token);

        /*
         * El token sin claim cuentaId y sin rol de ejecutivo se trata como cuenta ajena, no como
         * error del servidor. Es la eleccion conservadora: un token asi no acredita titularidad
         * sobre NINGUNA cuenta, que es exactamente lo que significa cuenta_ajena. Devolver 500 seria
         * ademas decirle a quien sondea que encontro un camino que el servicio no esperaba.
         */
        if (cuentaDelToken == null || cuentaDelToken != cuentaDeLaRuta) {
            throw ReglaWebException.cuentaAjena(cuentaDelToken, cuentaDeLaRuta);
        }
    }
}
