package cl.duoc.bancoxyz.bff.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.cache.annotation.EnableCaching;

/**
 * Punto de entrada del <strong>bff-web</strong>, el Backend for Frontend del canal navegador.
 *
 * <p>Escucha en el puerto 8443 bajo el context-path {@code /api/web}. Su unico cliente es un
 * navegador en un entorno supervisado, con pantalla grande y teclado completo, y por eso este
 * es el canal que entrega la vista mas rica: ficha de cuenta, agregados, movimientos paginados,
 * resumen mensual y, con perfil de ejecutivo, los recursos de auditoria.
 *
 * <p>Su papel en la arquitectura es traducir: toma el modelo generico que expone el
 * {@code core-service} y lo proyecta en la forma exacta que necesita <em>este</em> cliente y
 * ningun otro. Nunca lee los CSV, nunca habla con otro BFF y nunca comparte sus DTO de
 * respuesta: esa duplicacion entre canales es intencional en el patron BFF, porque es
 * precisamente lo que permite que cada canal evolucione sin romper a los demas.
 *
 * <p>Esta clase no contiene logica. En Spring Boot la clase principal es solo el disparador del
 * contenedor; todo lo demas vive en beans que el contenedor descubre.
 */
@SpringBootApplication(
        /*
         * Por que se enumeran los paquetes a escanear en lugar de dejar el valor por defecto:
         *
         * Por defecto, @SpringBootApplication escanea solo el paquete de esta clase hacia abajo,
         * es decir cl.duoc.bancoxyz.bff.web. Los beans que viven en la libreria compartida
         * (cl.duoc.bancoxyz.comun) quedarian fuera y no existirian.
         *
         * La alternativa "profesional" seria declarar plataforma-comun como auto-configuracion,
         * con un archivo META-INF/spring/...AutoConfiguration.imports. Se descarto a proposito:
         * si a ese archivo le falta una letra o el paquete no calza, Spring NO da ningun error;
         * simplemente los beans no existen y aparece mas tarde un NoSuchBeanDefinitionException
         * cuyo mensaje no apunta a la causa. Esta linea, en cambio, es visible, se lee en dos
         * segundos y falla de forma ruidosa y comprensible.
         *
         * Y no sacrifica extensibilidad: agregar un @Service nuevo dentro de plataforma-comun
         * no obliga a tocar ni una linea de este modulo.
         */
        scanBasePackages = {"cl.duoc.bancoxyz.bff.web", "cl.duoc.bancoxyz.comun"}
)
/*
 * @SpringBootApplication incluye el escaneo de componentes pero NO el de propiedades. Sin esta
 * anotacion, una clase anotada solo con @ConfigurationProperties no se registra como bean y el
 * arranque falla con "required a bean of type ...Properties that could not be found". Se declara
 * desde el primer dia, y sobre los mismos dos paquetes, para que nadie tenga que acordarse de
 * agregarla el dia que aparezca la primera clase de propiedades.
 */
// Se escanea SOLO cl.duoc.bancoxyz.comun.core, no el paquete comun completo: es el unico paquete de la
// libreria compartida que declara propiedades (la direccion y los tiempos del cliente del core). Escanear
// mas obligaria a cada BFF a declarar un bloque de configuracion que quiza no necesita, y un bloque ausente
// fallaria al arrancar con un mensaje que no apunta a la causa. Desde F5 ningun BFF emite tokens, asi que
// la libreria ya no trae politica de token que declarar: solo valida (ver ConfianzaEnElAuthServerConfig).
@ConfigurationPropertiesScan({"cl.duoc.bancoxyz.bff.web", "cl.duoc.bancoxyz.comun.core"})
/*
 * @EnableCaching (Etapa 7) enciende el MECANISMO de cache de Spring: a partir de aqui, el
 * contenedor envuelve en un proxy a todo bean que tenga un metodo con @Cacheable y consulta la
 * cache antes de dejar pasar la llamada.
 *
 * Lo que hay que entender de esta anotacion es que sin ella NO HAY ERROR. Un @Cacheable en un
 * proyecto sin @EnableCaching compila, arranca y funciona: simplemente no cachea nunca. No hay
 * excepcion, ni aviso en el log, ni nada en la pantalla. El unico sintoma es que el ahorro que
 * se esperaba no aparece, y ese sintoma es facil de atribuir a cualquier otra cosa. Por eso la
 * prueba automatizada de este canal no comprueba que la anotacion este escrita, sino que el
 * core recibe UNA llamada cuando se le piden dos cosas: comprueba el efecto, no la intencion.
 *
 * Esta anotacion NO existe en BffAtmApplication, y no es un olvido: es la pieza que mantiene
 * inerte cualquier @Cacheable que alguien escribiera por error en aquel canal. El motivo esta en
 * bff-atm/pom.xml y se resume en que un saldo cacheado, en una maquina que entrega billetes, es
 * dinero entregado dos veces. Alli la regla no se confia a esta ausencia, que seria silenciosa,
 * sino a una prueba de arquitectura que falla si aparece cualquier anotacion de cache.
 */
@EnableCaching
public class BffWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(BffWebApplication.class, args);
    }
}
