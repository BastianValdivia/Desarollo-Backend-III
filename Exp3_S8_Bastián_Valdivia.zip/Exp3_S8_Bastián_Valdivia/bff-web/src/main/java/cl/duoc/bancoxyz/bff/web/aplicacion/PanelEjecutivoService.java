package cl.duoc.bancoxyz.bff.web.aplicacion;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.bff.web.api.dto.PanelEjecutivoWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.PanelEjecutivoWebResponse.SeccionActividad;
import cl.duoc.bancoxyz.bff.web.api.dto.PanelEjecutivoWebResponse.SeccionCalidad;
import cl.duoc.bancoxyz.bff.web.auditoria.AuditoriaClient;
import cl.duoc.bancoxyz.bff.web.auditoria.AuditoriaClientProperties;
import cl.duoc.bancoxyz.bff.web.auditoria.AuditoriaNoDisponibleException;
import cl.duoc.bancoxyz.bff.web.auditoria.PaginaEventosAuditoriaDto;
import cl.duoc.bancoxyz.bff.web.auditoria.ResumenAuditoriaDto;
import cl.duoc.bancoxyz.comun.core.CoreException;

/**
 * Arma el panel del ejecutivo: la calidad de los datos (del core) y la actividad reciente (del
 * auditoria-service, que la alimenta Kafka).
 *
 * <h2>Degradacion por secciones</h2>
 *
 * <p>Cada seccion se pide por separado y su fallo se captura aqui: si el auditoria-service no responde (caido,
 * lento, con el circuito abierto, con el mamparo lleno o rechazando el token) la seccion de actividad sale con
 * {@code disponible=false} y un aviso, y la de calidad se entrega igual. Lo mismo al reves con el core.
 * Es la decision D6 para esta llamada ("el panel sale sin esa seccion, avisandolo"): un panel que falla entero
 * porque no llego la actividad esconderia datos sanos que el ejecutivo si puede usar.
 *
 * <p>Lo que NO se hace es inventar: una seccion no disponible no lleva datos viejos ni vacios que parezcan
 * reales. Solo el aviso. (La seccion de calidad conserva ademas el respaldo de "ultimo dato conocido" que ya le
 * da {@code AuditoriaWebService}: si el core cayo hace poco, su ultimo reporte sale marcado como tal.)
 */
@Service
public class PanelEjecutivoService {

    private static final Logger log = LoggerFactory.getLogger(PanelEjecutivoService.class);

    private final AuditoriaWebService calidad;
    private final AuditoriaClient auditoria;
    private final AuditoriaClientProperties propiedades;

    public PanelEjecutivoService(AuditoriaWebService calidad, AuditoriaClient auditoria,
                                 AuditoriaClientProperties propiedades) {
        this.calidad = calidad;
        this.auditoria = auditoria;
        this.propiedades = propiedades;
    }

    /**
     * @param cuenta si no es {@code null}, la actividad se limita a los retiros de esa cuenta
     */
    public PanelEjecutivoWebResponse armar(Integer cuenta) {
        return new PanelEjecutivoWebResponse(seccionCalidad(), seccionActividad(cuenta));
    }

    private SeccionCalidad seccionCalidad() {
        try {
            return SeccionCalidad.con(calidad.obtenerCalidadDatos());
        } catch (CoreException e) {
            log.warn("Panel del ejecutivo: la calidad de los datos no esta disponible: {}", e.getMessage());
            return SeccionCalidad.noDisponible("El reporte de calidad de datos no esta disponible en este "
                    + "momento (el core no responde).");
        }
    }

    private SeccionActividad seccionActividad(Integer cuenta) {
        try {
            ResumenAuditoriaDto resumen = auditoria.resumen();
            PaginaEventosAuditoriaDto pagina = auditoria.recientes(cuenta, propiedades.eventosRecientes());
            return SeccionActividad.con(resumen, pagina.eventos());
        } catch (AuditoriaNoDisponibleException e) {
            log.warn("Panel del ejecutivo: la actividad reciente no esta disponible: {}", e.getMessage());
            return SeccionActividad.noDisponible("La actividad reciente no esta disponible en este momento "
                    + "(el servicio de auditoria no responde).");
        }
    }
}
