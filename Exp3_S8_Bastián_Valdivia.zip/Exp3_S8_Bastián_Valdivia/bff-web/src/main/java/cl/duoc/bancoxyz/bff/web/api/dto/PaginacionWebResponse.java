package cl.duoc.bancoxyz.bff.web.api.dto;

/**
 * El bloque de paginacion del canal web: los cuatro numeros que una tabla necesita para dibujar
 * sus controles de "anterior" y "siguiente".
 *
 * <p><strong>Por que existe esta clase si el core ya tiene una identica.</strong> Es la pregunta
 * correcta y la respuesta es el corazon del patron. {@code PaginacionCoreDto} describe lo que el
 * {@code core-service} <em>dice</em>; esta clase describe lo que el canal web <em>responde</em>.
 * Hoy coinciden campo por campo, y por eso la traduccion entre ambas es una copia aburrida. Pero
 * son dos contratos con dos duenos distintos: si manana el core agrega un campo de ordenamiento,
 * el canal web decide si lo expone o no; si el navegador necesita un campo calculado, este
 * record lo agrega sin que el core se entere. Reutilizar aqui la clase del core ahorraria ocho
 * lineas hoy y ataria para siempre la respuesta del canal a la forma del backend de dominio.
 *
 * <p><strong>Los nombres estan congelados</strong> en la seccion 5.6 del contrato, con dos
 * detalles que se equivocan con facilidad: {@code tamano} se escribe sin enie y sin tilde, y
 * {@code pagina} empieza en <strong>0</strong>, no en 1.
 *
 * @param pagina         indice de la pagina entregada, base cero
 * @param tamano         cuantos elementos trae esta pagina como maximo. Es el valor que el
 *                       servidor decidio, ya recortado al tope del canal, no el que pidio el
 *                       cliente
 * @param totalElementos cuantos movimientos hay en total tras aplicar los filtros
 * @param totalPaginas   cuantas paginas componen ese total. Vale <strong>0</strong> cuando no hay
 *                       ningun elemento, que es el caso de la cuenta 130
 */
public record PaginacionWebResponse(
        int pagina,
        int tamano,
        long totalElementos,
        int totalPaginas) {
}
