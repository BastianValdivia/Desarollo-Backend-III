package cl.duoc.bancoxyz.bff.web.api.dto;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * <strong>W6</strong>: el reporte de calidad de la ingesta, exclusivo del canal web y reservado al
 * perfil de ejecutivo.
 *
 * <p>Los seis nombres de campo estan congelados en la seccion 5.14 del contrato, y tres de sus
 * valores tambien: {@code cuentasConsolidadas} debe ser 50, {@code movimientosCargados} 686 y
 * {@code transaccionesNoConciliadas} 1000. Si alguno no cuadra, el problema no esta en este canal
 * sino en la ingesta del core, y esta pantalla es justamente el sitio donde eso se ve.
 *
 * <h2>Por que este endpoint pertenece al canal web y a ningun otro</h2>
 *
 * <p>Porque su lector es una persona sentada frente a una pantalla grande, en una oficina, cuyo
 * trabajo es mirar como quedo la carga de datos. Ese lector no existe en un telefono y mucho menos
 * en un cajero de la calle. Publicarlo en los tres canales seria confundir "el sistema tiene este
 * dato" con "este cliente lo necesita", que es el error que el patron BFF evita.
 *
 * <h2>Por que la forma es casi identica a la del core, y eso no es pereza</h2>
 *
 * <p>En W2 el canal <em>agrega</em> valor: calcula un resumen que el core no tiene y recorta la
 * primera pagina. Aqui no hay nada que agregar: el reporte ya es exactamente la respuesta a la
 * pregunta del ejecutivo, y "adaptar por canal" no significa cambiar la forma por cambiarla. Lo que
 * si hace el canal es <strong>republicarlo con sus propias clases</strong>, y esa duplicacion es la
 * que permite que manana este canal agregue un campo calculado, o esconda uno, sin que el core se
 * entere.
 *
 * @param generadoEn                 instante ISO-8601 en UTC en que el core hizo la ingesta
 * @param archivos                   una fila por archivo leido
 * @param descartesPorMotivo         conteo por motivo de descarte. Las cinco claves congeladas
 *                                   aparecen siempre, aunque valgan cero
 * @param cuentasConsolidadas        debe ser 50
 * @param movimientosCargados        debe ser 686
 * @param transaccionesNoConciliadas debe ser 1000, y es el lote que publica W5
 */
public record ReporteCalidadWebResponse(
        Instant generadoEn,
        List<ArchivoCalidadWebResponse> archivos,
        Map<String, Integer> descartesPorMotivo,
        int cuentasConsolidadas,
        int movimientosCargados,
        int transaccionesNoConciliadas) {

    /**
     * Colecciones nulas a colecciones vacias.
     *
     * <p>Misma regla que en el resto del proyecto y por el mismo motivo: una coleccion vacia se
     * recorre sin ramas especiales y un {@code null} explota en el cliente. Un reporte que dice
     * {@code "archivos": []} esta diciendo "no se leyo ningun archivo", que es informacion; uno que
     * dice {@code null} no dice nada y ademas rompe a quien lo lea.
     */
    public ReporteCalidadWebResponse {
        archivos = archivos == null ? List.of() : List.copyOf(archivos);
        descartesPorMotivo = descartesPorMotivo == null ? Map.of() : Map.copyOf(descartesPorMotivo);
    }
}
