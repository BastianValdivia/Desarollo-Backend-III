package cl.duoc.bancoxyz.bff.web.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import cl.duoc.bancoxyz.bff.web.aplicacion.ReglaWebException;
import cl.duoc.bancoxyz.comun.core.CoreCredencialRechazadaException;
import cl.duoc.bancoxyz.comun.core.CoreException;
import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.core.CoreSaldoInsuficienteException;
import cl.duoc.bancoxyz.comun.error.MotivosError;
import cl.duoc.bancoxyz.comun.error.RespuestaError;

import jakarta.servlet.http.HttpServletRequest;

/**
 * El <strong>traductor de fallos</strong> del canal web: convierte cualquier excepcion que suba
 * desde el controlador o desde el {@code CoreClient} en un cuerpo RFC 7807 con el codigo HTTP que
 * manda el contrato.
 *
 * <p><strong>Por que existe un unico sitio para esto.</strong> Si cada metodo del controlador
 * capturara sus propios errores, habria tres implementaciones del mismo cuerpo de error y tarde o
 * temprano una de ellas escribiria {@code razon} donde las otras escriben {@code motivo}. Los
 * scripts de evidencia leen ese campo, asi que una sola letra distinta hace que una evidencia
 * "pase" leyendo un valor vacio. Con un {@code @RestControllerAdvice}, el cuerpo de error se
 * construye en un solo metodo privado y es imposible que dos rutas disientan.
 *
 * <p><strong>El envoltorio es igual en los tres canales; el contenido, no.</strong> Los siete
 * campos ({@code type}, {@code title}, {@code status}, {@code detail}, {@code instance},
 * {@code canal}, {@code motivo}) vienen del record compartido {@code RespuestaError}, y eso es
 * calidad: quien integre contra dos canales distintos encuentra la misma forma. Lo que cambia es
 * lo que cada canal mete dentro. Este canal <strong>si</strong> envia {@code detail} con un texto
 * explicativo, porque su cliente es una interfaz compleja en un entorno supervisado que puede
 * reaccionar a el. El canal del cajero, en cambio, <strong>omite</strong> {@code detail} y agrega
 * {@code codigoPantalla} y {@code mensajePantalla}: lo que se muestra en la via publica no debe
 * filtrar detalles tecnicos. Que el mismo error se vea distinto en dos canales es adaptacion, no
 * inconsistencia.
 *
 * <p><strong>La traduccion mas importante de esta clase, y la mas facil de hacer mal.</strong>
 * El {@code core-service} rechaza al BFF (401 o 403) cuando su token de servicio no sirve
 * (otro emisor, otra audiencia o un scope que le falta). La tentacion es propagar ese 401 al navegador. Seria un error grave: para el navegador,
 * un 401 significa "tu sesion no sirve", y el usuario intentaria volver a entrar una y otra vez
 * con credenciales que estan perfectamente bien. La credencial que fallo no es la suya, es la del
 * BFF hablando con el core, o sea un problema de configuracion <em>nuestro</em>. Hacia afuera eso
 * es <strong>503 {@code core_no_disponible}</strong>, y hacia adentro es una linea de
 * {@code log.error} que le dice al operador exactamente donde mirar.
 *
 * <p><strong>Lo que esta clase NO cubre, y donde vive eso.</strong> Un
 * {@code @RestControllerAdvice} solo ve lo que ocurre dentro del DispatcherServlet, es decir
 * despues de que la peticion fue despachada a un controlador. Los rechazos que decide la
 * <em>cadena de filtros</em> ocurren antes, cuando todavia no hay controlador al que envolver, asi
 * que no pasan por aqui y hay que escribirlos a mano sobre el {@code HttpServletResponse}: el 401
 * por token ausente o invalido lo escribe {@code PuntoEntradaWeb}, y el 403 por autoridad faltante
 * lo escribe {@code ManejadorAccesoDenegadoWeb}. Los tres sitios construyen el mismo
 * {@code RespuestaError}, que es lo que mantiene identico el formato de error del canal.
 *
 * <p>Si eso no se hiciera asi, justo los dos escenarios que mas se miran al evaluar seguridad
 * devolverian la pagina de error generica de Spring, que no se parece en nada al resto de la API.
 */
@RestControllerAdvice
public class ManejadorErroresWeb {

    private static final Logger log = LoggerFactory.getLogger(ManejadorErroresWeb.class);

    /**
     * Valor congelado del campo {@code canal} para este BFF (contrato, seccion 5.16).
     *
     * <p>Es una constante y no una propiedad configurable: la identidad del canal no es algo que
     * un despliegue deba poder cambiar. Si estuviera en {@code config-repo/bff-web.yml}, un error de
     * copiar y pegar entre canales produciria respuestas del puerto 8443 diciendo
     * {@code "canal":"ATM"}, y la evidencia comparativa entre canales quedaria invalidada sin que
     * nada fallara.
     */
    private static final String CANAL = "WEB";

    // ------------------------------------------------------------------
    // Reglas propias del canal
    // ------------------------------------------------------------------

    /**
     * Una regla de este canal rechazo la peticion: cuenta ajena en la consulta (403).
     *
     * <p><strong>Por que este caso entra por aqui y no por los beans de Spring
     * Security.</strong> Aquellos dos, el punto de entrada y el manejador de acceso denegado,
     * atienden lo que la <em>cadena de filtros</em> rechaza: token ausente, token invalido, falta de
     * autoridad. El caso de este manejador lo decide el <em>codigo del canal</em>, ya dentro
     * del controlador, y por eso llegan como excepciones normales de Java y se formatean aqui, junto
     * al resto de los errores.
     *
     * <p>Merece la pena ver los tres 403 del sistema uno al lado del otro, porque el codigo HTTP es
     * el mismo y las causas no:
     * <ul>
     *   <li>{@code permiso_insuficiente}: te falta la autoridad que la ruta exige. Lo decide la
     *       cadena de filtros, lo escribe {@code ManejadorAccesoDenegadoWeb}.</li>
     *   <li>{@code cuenta_ajena}: tienes la autoridad y ese dato no es tuyo. Lo decide
     *       {@code GuardiaTitularidadWeb}, lo escribe este metodo.</li>
     *   <li>{@code operacion_no_disponible_en_canal}: existe en el sistema y este canal no la
     *       ofrece a esta identidad. Hoy este canal no lo emite.</li>
     * </ul>
     *
     * <p>El {@code detail} sale de la excepcion y es texto redactado para el cliente. El mensaje de
     * la excepcion, que si nombra la cuenta que el token acreditaba, va al log y no cruza nunca la
     * frontera del canal: es dato de otra persona.
     */
    @ExceptionHandler(ReglaWebException.class)
    public ResponseEntity<RespuestaError> manejarReglaDelCanal(ReglaWebException excepcion,
                                                               HttpServletRequest peticion) {
        log.info("{} {} en {}: {}", excepcion.estado(), excepcion.motivo(),
                peticion.getRequestURI(), excepcion.getMessage());

        HttpStatus estado = HttpStatus.valueOf(excepcion.estado());

        ResponseEntity.BodyBuilder respuesta = ResponseEntity.status(estado)
                .contentType(MediaType.APPLICATION_PROBLEM_JSON);

        /*
         * Todo 401 lleva WWW-Authenticate: Bearer, y ningun 403 la lleva. Esa cabecera significa
         * "identificate, y hazlo asi": es exacta cuando el servidor no sabe quien llama, y es un
         * consejo equivocado para quien ya esta identificado y solo le falta un permiso, porque lo
         * mandaria a repetir un login que no va a cambiar nada.
         */
        if (estado == HttpStatus.UNAUTHORIZED) {
            respuesta.header(HttpHeaders.WWW_AUTHENTICATE, "Bearer");
        }

        return respuesta.body(RespuestaError.de(
                excepcion.estado(), excepcion.motivo(), excepcion.titulo(), excepcion.detalle(),
                peticion.getRequestURI(), CANAL));
    }

    // ------------------------------------------------------------------
    // Fallos que vienen del core-service
    // ------------------------------------------------------------------

    /**
     * La cuenta pedida no existe en el core. Es el caso de {@code /v1/cuentas/999}.
     *
     * <p>Se traduce tal cual: 404 con {@code recurso_no_encontrado}. Conviene no confundirlo con
     * el otro 404 de este archivo (ruta inexistente): alli no existe el <em>endpoint</em>, aqui
     * no existe el <em>recurso</em>. Y cuando llegue la fase de seguridad habra un tercer caso que
     * se parece y no lo es: pedir una cuenta que <strong>si</strong> existe y no es tuya devuelve
     * <strong>403 {@code cuenta_ajena}</strong>, no 404, porque el recurso existe y lo que falta
     * es el derecho.
     */
    @ExceptionHandler(CoreRecursoNoEncontradoException.class)
    public ResponseEntity<RespuestaError> manejarNoEncontrado(CoreRecursoNoEncontradoException excepcion,
                                                              HttpServletRequest peticion) {
        log.info("El core no encontro el recurso pedido desde {}: {}",
                peticion.getRequestURI(), excepcion.rutaSolicitada());

        return construir(HttpStatus.NOT_FOUND,
                MotivosError.RECURSO_NO_ENCONTRADO,
                "Recurso no encontrado",
                "No existe la cuenta solicitada",
                peticion);
    }

    /**
     * El core rechazo la credencial de servicio del BFF.
     *
     * <p>Ver la explicacion extendida en el Javadoc de la clase: hacia afuera esto es 503, nunca
     * 401. Se registra con {@code log.error} y no con {@code log.info} porque siempre indica una
     * configuracion rota (los dos servicios no comparten el mismo secreto, o uno de los dos no se
     * reinicio despues de regenerarlo) y no hay ninguna accion que el cliente pueda tomar.
     */
    @ExceptionHandler(CoreCredencialRechazadaException.class)
    public ResponseEntity<RespuestaError> manejarCredencialRechazada(CoreCredencialRechazadaException excepcion,
                                                                     HttpServletRequest peticion) {
        log.error("El core rechazo el token de servicio de bff-web (estado {}). Con 401, revise que el core y el "
                + "auth-server coincidan en emisor y audiencia; con 403, que el cliente OAuth2 bff-web conserve "
                + "el scope del endpoint. Ruta interna: {}",
                excepcion.estadoDelCore(), excepcion.rutaSolicitada(), excepcion);

        return construir(HttpStatus.SERVICE_UNAVAILABLE,
                MotivosError.CORE_NO_DISPONIBLE,
                "Servicio no disponible",
                "El canal no pudo consultar el sistema central",
                peticion);
    }

    /**
     * El core rechazo una operacion por saldo insuficiente.
     *
     * <p>Hoy el canal web no mueve dinero, asi que este manejador no se puede alcanzar desde
     * ninguna de sus tres rutas. Se declara igualmente por una razon concreta: sin el, esta
     * excepcion caeria en el manejador generico de {@code CoreException} y saldria como 503, es
     * decir el canal diria "el sistema central esta caido" cuando el sistema central respondio
     * perfectamente y lo que dijo fue "no". Dejarlo escrito cuesta seis lineas y evita un
     * diagnostico falso el dia que este canal crezca.
     */
    @ExceptionHandler(CoreSaldoInsuficienteException.class)
    public ResponseEntity<RespuestaError> manejarSaldoInsuficiente(CoreSaldoInsuficienteException excepcion,
                                                                   HttpServletRequest peticion) {
        log.info("El core rechazo la operacion por saldo insuficiente en {}", excepcion.rutaSolicitada());

        return construir(HttpStatus.CONFLICT,
                MotivosError.SALDO_INSUFICIENTE,
                "Operacion rechazada",
                "La cuenta no tiene saldo suficiente para la operacion",
                peticion);
    }

    /**
     * Cualquier otro fallo hablando con el core: no respondio, supero el timeout, devolvio 5xx o
     * devolvio algo que el cliente no sabe interpretar.
     *
     * <p>Este manejador es la <strong>red de contencion</strong> que hace que una caida del core
     * no se convierta en una caida del canal. El BFF sigue en pie, responde en los cinco segundos
     * del timeout configurado y dice con precision que fallo. Un canal que responde
     * "el sistema central no esta disponible" en cinco segundos es infinitamente mejor que uno
     * que deja al navegador esperando para siempre.
     *
     * <p>Cubre {@code CoreNoDisponibleException} y {@code CoreRespuestaInesperadaException}
     * porque las dos comparten la misma respuesta hacia afuera; lo que las distingue es el
     * diagnostico, y eso va al log, no al cliente. El detalle tecnico (la ruta interna, el codigo
     * que devolvio el core) <strong>no</strong> viaja en el cuerpo: son datos de la topologia
     * interna del banco y no le sirven de nada a un navegador.
     */
    @ExceptionHandler(CoreException.class)
    public ResponseEntity<RespuestaError> manejarCoreCaido(CoreException excepcion,
                                                           HttpServletRequest peticion) {
        if (excepcion instanceof CoreNoDisponibleException) {
            log.error("El core-service no respondio al atender {}. Estado observado: {}",
                    peticion.getRequestURI(), excepcion.estadoDelCore(), excepcion);
        } else {
            log.error("Respuesta del core que este canal no sabe interpretar al atender {}. "
                            + "Si el core respondio 200, revise que los nombres de campo coincidan "
                            + "con el contrato congelado.",
                    peticion.getRequestURI(), excepcion);
        }

        return construir(HttpStatus.SERVICE_UNAVAILABLE,
                MotivosError.CORE_NO_DISPONIBLE,
                "Servicio no disponible",
                "El canal no pudo consultar el sistema central",
                peticion);
    }

    // ------------------------------------------------------------------
    // Fallos de la peticion del cliente
    // ------------------------------------------------------------------

    /**
     * Spring no consiguio convertir un valor de la peticion al tipo que el metodo declara. Este
     * manejador decide entre <strong>404 y 400</strong> segun <em>donde</em> venia ese valor.
     *
     * <h3>Por que una misma excepcion produce dos codigos distintos</h3>
     *
     * <p>{@code MethodArgumentTypeMismatchException} tapa dos situaciones que para el cliente no
     * se parecen en nada:
     *
     * <ul>
     *   <li><strong>La ruta no se puede ni leer.</strong> {@code /v1/cuentas/abc} no nombra
     *       ninguna cuenta: no existe, ni existira, un recurso con ese identificador. Eso es
     *       {@code 404 recurso_no_encontrado}, igual que {@code /v1/cuentas/999}, porque desde
     *       fuera son el mismo hecho: la direccion pedida no apunta a nada.</li>
     *   <li><strong>La ruta es valida y el filtro no.</strong> {@code ?desde=08-03-2024} pide un
     *       recurso que si existe, con un parametro que el canal no sabe interpretar. El recurso
     *       esta ahi; lo que esta mal es la pregunta. Eso es {@code 400}.</li>
     * </ul>
     *
     * <p><strong>Y por que esto importa mas alla de este canal.</strong> Los tres BFF se
     * construyeron en paralelo, y el cajero y el movil resuelven {@code /v1/cuentas/abc/...} como
     * 404. Si el canal web respondiera 400 al mismo tipo de peticion, la evidencia comparativa
     * mostraria a los tres canales discrepando en un caso que no tiene nada de especifico de
     * ningun canal, y un lector razonable concluiria que uno de los tres esta mal. La adaptacion
     * por canal legitima cambia <em>que</em> se devuelve y <em>cuanto</em>, no el significado de
     * un codigo HTTP. Alinearse aqui no le quita nada al canal web: conserva su 400 propio para
     * los parametros de consulta, que son suyos y de nadie mas, porque ni el movil ni el cajero
     * exponen un solo parametro de consulta.
     *
     * <p><strong>Como se distingue una cosa de la otra.</strong> No comparando el nombre del
     * parametro contra la cadena {@code "cuentaId"}, que se rompe en silencio el dia que alguien
     * lo renombre, sino preguntandole al propio parametro si lleva la anotacion
     * {@link PathVariable}. La pregunta se le hace al codigo, no a una convencion de nombres.
     *
     * <p><strong>Sobre el valor de {@code motivo} del 400.</strong> Desde la version 1.1.0 del
     * contrato, {@code peticion_invalida} es un literal congelado de la seccion 7.1 y se escribe
     * desde {@link MotivosError#PETICION_INVALIDA}. Antes era un literal suelto que este canal
     * habia tomado prestado del {@code core-service} para no inventar un segundo vocabulario;
     * ahora es vocabulario compartido de verdad, y una grafia equivocada deja de compilar en vez
     * de aparecer en una evidencia que falla sin decir por que.
     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<RespuestaError> manejarValorNoConvertible(
            MethodArgumentTypeMismatchException excepcion, HttpServletRequest peticion) {

        boolean veniaEnLaRuta = excepcion.getParameter().hasParameterAnnotation(PathVariable.class);

        if (veniaEnLaRuta) {
            log.info("Identificador ilegible en la ruta {}: {}",
                    peticion.getRequestURI(), excepcion.getName());

            return construir(HttpStatus.NOT_FOUND,
                    MotivosError.RECURSO_NO_ENCONTRADO,
                    "Recurso no encontrado",
                    "Este canal no expone el recurso solicitado",
                    peticion);
        }

        return peticionInvalida(excepcion, peticion);
    }

    /**
     * El valor llego bien formado pero no es uno de los que el canal acepta.
     *
     * <p>Caso real: {@code ?tipo=TRANSFERENCIA}. Es una cadena perfectamente convertible, asi que
     * Spring no se queja; quien la rechaza es {@code ConsultaMovimientosWeb} al contrastarla con
     * el enumerado congelado, y lo hace lanzando {@code IllegalArgumentException}. La ruta existe
     * y el recurso existe: el error esta en el filtro, y por eso es 400 y no 404.
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<RespuestaError> manejarValorNoAceptado(IllegalArgumentException excepcion,
                                                                 HttpServletRequest peticion) {
        return peticionInvalida(excepcion, peticion);
    }

    /**
     * Cuerpo comun del 400, para que los dos caminos que lo producen no puedan divergir.
     *
     * <p>El {@code detail} describe el problema sin repetir el texto que envio el cliente. Copiar
     * la entrada de vuelta en el cuerpo de la respuesta es como se construyen los reflejos que
     * terminan en un XSS cuando alguien pinta ese texto en una pagina.
     */
    private ResponseEntity<RespuestaError> peticionInvalida(Exception excepcion,
                                                            HttpServletRequest peticion) {
        log.info("Peticion invalida en {}: {}", peticion.getRequestURI(), excepcion.getMessage());

        return construir(HttpStatus.BAD_REQUEST,
                MotivosError.PETICION_INVALIDA,
                "Peticion invalida",
                "Revise el formato de las fechas (yyyy-MM-dd), el tamano de pagina "
                        + "y el tipo de movimiento",
                peticion);
    }

    /**
     * La ruta pedida no existe en <strong>este</strong> canal.
     *
     * <p>Es el manejador que sostiene la evidencia de endpoints exclusivos: pedir
     * {@code /v1/dispositivos/baja} (que solo tiene el canal movil) en el puerto 8443 tiene que
     * devolver un 404 con la misma forma que cualquier otro error del canal, no la pagina blanca
     * de Spring. Un 404 bien formado dice "aqui no", y esa negativa es informacion de contrato
     * tanto como un 200.
     *
     * <p>Se declaran las dos excepciones porque Spring Boot 3 usa {@code NoResourceFoundException}
     * para rutas sin manejador y {@code NoHandlerFoundException} sigue existiendo segun como este
     * configurado el despachador. Declarar las dos cuesta una linea y evita descubrir la
     * diferencia mirando una respuesta que no se parece a ninguna otra.
     */
    @ExceptionHandler({NoResourceFoundException.class, NoHandlerFoundException.class})
    public ResponseEntity<RespuestaError> manejarRutaInexistente(HttpServletRequest peticion) {
        return construir(HttpStatus.NOT_FOUND,
                MotivosError.RECURSO_NO_ENCONTRADO,
                "Recurso no encontrado",
                "Este canal no expone el recurso solicitado",
                peticion);
    }

    /**
     * La ruta existe pero no acepta ese verbo, por ejemplo un {@code POST} contra la ficha de
     * cuenta.
     *
     * <p>Se distingue del 404 a proposito: un 405 le dice a quien integra que la ruta es correcta
     * y el verbo no, que es una pista mucho mas util que "no existe". El valor de {@code motivo},
     * igual que el del 400, quedo congelado en la seccion 7.1 del contrato en su version 1.1.0, y
     * se escribe desde {@link MotivosError}.
     *
     * <p>El canal del cajero hace lo contrario y responde 404 a este mismo caso, a proposito: un
     * 405 lleva la cabecera {@code Allow} y le confirma a quien sondea la maquina que la ruta
     * existe y con que verbo usarla. Aqui esa pista se da porque el interlocutor es quien integra
     * la aplicacion; en via publica no.
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<RespuestaError> manejarVerboNoSoportado(HttpRequestMethodNotSupportedException excepcion,
                                                                  HttpServletRequest peticion) {
        return construir(HttpStatus.METHOD_NOT_ALLOWED,
                MotivosError.METODO_NO_PERMITIDO,
                "Metodo no permitido",
                "El recurso existe pero no acepta el verbo " + excepcion.getMethod(),
                peticion);
    }

    /**
     * El cuerpo llego con un {@code Content-Type} que la ruta no consume, por ejemplo un
     * {@code curl -d} sin {@code -H 'Content-Type: application/json'}, que curl manda como
     * formulario.
     *
     * <p>Es un error del cliente y se responde 415, no 500: el 500 le diria a quien integra que
     * el canal esta roto cuando lo unico que falta es la cabecera. Sin este manejador, la red de
     * seguridad de mas abajo se lo tragaba. El {@code motivo} reutiliza {@code peticion_invalida},
     * del vocabulario congelado: la peticion viene mal y reintentarla igual siempre fallara, que
     * es justo lo que ese motivo dice. No se inventa un motivo nuevo, porque la seccion 7.1 del
     * contrato no lo contempla.
     */
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<RespuestaError> manejarTipoContenidoNoSoportado(
            HttpMediaTypeNotSupportedException excepcion, HttpServletRequest peticion) {
        log.info("Tipo de contenido no soportado en {} {}: {}",
                peticion.getMethod(), peticion.getRequestURI(), excepcion.getContentType());

        return construir(HttpStatus.UNSUPPORTED_MEDIA_TYPE,
                MotivosError.PETICION_INVALIDA,
                "Tipo de contenido no soportado",
                "El cuerpo debe enviarse como application/json",
                peticion);
    }

    /**
     * El cuerpo falta o no es un JSON legible. Misma familia que el 415: falla del cliente, no del
     * canal, y por eso 400 y no 500. El detalle no copia el texto de la excepcion de Jackson, que
     * cita fragmentos del cuerpo recibido y nombres de clases.
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<RespuestaError> manejarCuerpoIlegible(
            HttpMessageNotReadableException excepcion, HttpServletRequest peticion) {
        log.info("Cuerpo ilegible en {} {}", peticion.getMethod(), peticion.getRequestURI());

        return construir(HttpStatus.BAD_REQUEST,
                MotivosError.PETICION_INVALIDA,
                "Peticion invalida",
                "El cuerpo de la peticion no es un JSON valido",
                peticion);
    }

    /**
     * La red de seguridad final: cualquier excepcion que nadie mas reclamo.
     *
     * <p>Existe para que un fallo no previsto salga con la misma forma que todos los demas y no
     * como la pagina generica del contenedor. La traza completa va al log, donde la lee un
     * operador; el cuerpo de la respuesta dice lo minimo, porque el texto de una excepcion de
     * Java puede contener nombres de clases, rutas de archivos y fragmentos de consulta, y nada
     * de eso debe cruzar la frontera del canal.
     *
     * <p>Este manejador se declara <strong>al final</strong> por claridad de lectura. Spring
     * elige siempre el manejador mas especifico segun la jerarquia de la excepcion, asi que el
     * orden del archivo no cambia el comportamiento; cambiarlo de sitio no romperia nada, pero un
     * archivo que se lee de lo particular a lo general se entiende mejor.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<RespuestaError> manejarInesperado(Exception excepcion,
                                                            HttpServletRequest peticion) {
        log.error("Fallo no controlado en {} {}",
                peticion.getMethod(), peticion.getRequestURI(), excepcion);

        return construir(HttpStatus.INTERNAL_SERVER_ERROR,
                MotivosError.ERROR_INTERNO,
                "Error interno",
                "El canal no pudo completar la operacion",
                peticion);
    }

    // ------------------------------------------------------------------
    // Construccion del cuerpo, en un solo lugar
    // ------------------------------------------------------------------

    /**
     * Arma el cuerpo RFC 7807 del canal. Todos los manejadores de arriba pasan por aqui.
     *
     * <p>Dos detalles que parecen menores y no lo son:
     * <ul>
     *   <li>El {@code Content-Type} es {@code application/problem+json} y no
     *       {@code application/json}. Es lo que define RFC 7807 y es lo que permite que un
     *       cliente distinga un cuerpo de error de un cuerpo normal sin mirar el codigo HTTP.</li>
     *   <li>{@code instance} se toma de {@code getRequestURI()}, que <strong>incluye el
     *       context-path</strong>. Por eso el valor es {@code /api/web/v1/cuentas/999} y no
     *       {@code /v1/cuentas/999}: el contrato pide la ruta tal como la pidio el cliente, y de
     *       paso ese prefijo hace autoevidente en un archivo de evidencia a que canal pertenece
     *       cada error.</li>
     * </ul>
     *
     * <p>El campo {@code type} lo deriva {@code RespuestaError} a partir del motivo, cambiando los
     * guiones bajos por guiones: {@code recurso_no_encontrado} produce
     * {@code https://bancoxyz.duoc.cl/errores/recurso-no-encontrado}. Asi es imposible que el
     * {@code motivo} y la URI del catalogo se contradigan.
     */
    private ResponseEntity<RespuestaError> construir(HttpStatus estado,
                                                     String motivo,
                                                     String titulo,
                                                     String detalle,
                                                     HttpServletRequest peticion) {
        RespuestaError cuerpo = RespuestaError.de(
                estado.value(), motivo, titulo, detalle, peticion.getRequestURI(), CANAL);

        return ResponseEntity.status(estado)
                .contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .body(cuerpo);
    }
}
