package cl.duoc.bancoxyz.bff.web.aplicacion;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import cl.duoc.bancoxyz.bff.web.api.dto.MesWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.ResumenWebResponse;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;

/**
 * Donde vive <strong>la agregacion</strong>, que es el valor que el canal web aporta por encima
 * del {@code core-service}.
 *
 * <p><strong>Por que esto es una clase con nombre propio y no tres lineas sueltas dentro del
 * servicio.</strong> Porque es el argumento del canal, y un argumento merece ser visible en el
 * arbol de archivos. Un lector que abra {@code bff-web} debe poder senalar el archivo donde
 * ocurre lo que el core no hace. Ademas, al ser una clase sin dependencias (no conoce Spring, ni
 * HTTP, ni el {@code CoreClient}), se puede probar con una lista construida a mano y sin levantar
 * nada.
 *
 * <p><strong>La regla de negocio que esta clase implementa, una sola vez y en un solo sitio.</strong>
 * Un movimiento de tipo {@code DEPOSITO} es un <em>abono</em>; {@code RETIRO}, {@code COMPRA} y
 * {@code PAGO} son <em>cargos</em>. El monto siempre es positivo, asi que no hay ninguna regla de
 * signo que recordar: la direccion del dinero vive en el tipo (contrato, seccion 5.4). Si esta
 * regla se implementara en el navegador, dos pantallas distintas podrian terminar clasificando
 * distinto el mismo movimiento; aqui hay un unico lugar donde puede estar bien o mal.
 *
 * <p><strong>Por que los totales son {@code BigDecimal} y no {@code double}.</strong> Porque son
 * dinero. Un {@code double} no puede representar exactamente 0,1 y acumula error al sumar: sumar
 * cuarenta y dos importes puede terminar en un total que no cuadra con la suma que haga a mano
 * quien mire la pantalla. Ese descuadre no lanza ninguna excepcion y se descubre cuando lo
 * reclama un cliente.
 */
public final class AgregadorResumenWeb {

    /**
     * Escala con la que se publican los totales.
     *
     * <p><strong>Por que se fija explicitamente.</strong> {@code BigDecimal.ZERO} se serializa
     * como {@code 0} mientras que la suma de importes con dos decimales se serializa como
     * {@code 45000.00}. Sin fijar la escala, la respuesta de la cuenta 116 y la de la cuenta 130
     * (sin movimientos) tendrian <em>forma</em> distinta, y el caso borde se leeria como si fuera
     * otro tipo de dato. Fijando la escala, los dos casos publican {@code 0.00} y
     * {@code 45000.00}: el mismo tipo, siempre.
     */
    private static final int DECIMALES_DE_MONEDA = 2;

    /** Valor congelado del enumerado de tipos que representa una entrada de dinero. */
    private static final String TIPO_ABONO = "DEPOSITO";

    /** Clase de utilidades sin estado: no tiene sentido instanciarla. */
    private AgregadorResumenWeb() {
    }

    /**
     * Calcula el bloque {@code resumen} de la ficha de cuenta (objeto W2) sobre
     * <strong>todos</strong> los movimientos de la cuenta.
     *
     * <p>Es importante que reciba la lista completa y no la pagina visible: un total de abonos
     * que solo sumara los 20 movimientos de la primera pagina seria un numero sin significado, y
     * peor aun, cambiaria al pasar de pagina.
     *
     * <p><strong>Caso borde de la cuenta 130.</strong> Con una lista vacia, las dos sumas valen
     * {@code 0.00} y la cantidad vale {@code 0}. No hay ninguna division involucrada, asi que no
     * existe la posibilidad de dividir por cero: los promedios no forman parte del contrato
     * precisamente porque obligarian a decidir que significa "promedio de cero movimientos".
     *
     * @param movimientos todos los movimientos de la cuenta, tal como los entrega el core. Se
     *                    tolera {@code null} y se trata como lista vacia
     */
    public static ResumenWebResponse resumirTodo(List<MovimientoCoreDto> movimientos) {
        List<MovimientoCoreDto> seguros = movimientos == null ? List.of() : movimientos;

        BigDecimal abonos = BigDecimal.ZERO;
        BigDecimal cargos = BigDecimal.ZERO;

        // Un solo recorrido para las dos sumas. Con dos "stream().filter().reduce()" el codigo se
        // leeria mas declarativo, pero recorreria la lista dos veces y, sobre todo, repetiria la
        // condicion "es abono" en dos sitios, que es donde se cuelan las divergencias.
        for (MovimientoCoreDto movimiento : seguros) {
            BigDecimal monto = movimiento.monto() == null ? BigDecimal.ZERO : movimiento.monto();
            if (esAbono(movimiento)) {
                abonos = abonos.add(monto);
            } else {
                cargos = cargos.add(monto);
            }
        }

        return new ResumenWebResponse(
                normalizarEscala(abonos), normalizarEscala(cargos), seguros.size());
    }

    /**
     * Calcula el arreglo {@code meses} del resumen mensual (objeto W4): un elemento por mes con
     * actividad, ordenado de forma ascendente.
     *
     * <p><strong>Por que un {@code LinkedHashMap} con clave {@code YearMonth} y no un
     * {@code groupingBy} de streams.</strong> {@code YearMonth} es el tipo que representa
     * exactamente "marzo de 2024", asi que agrupar por el evita el error clasico de agrupar por
     * el texto de la fecha y terminar con un grupo por dia. La version con streams necesitaria
     * agrupar, luego mapear cada grupo a su suma y luego ordenar, y el paso intermedio tambien
     * recorre cada grupo: este bucle acumula sobre la marcha y despues ordena una sola vez.
     *
     * <p><strong>Los meses sin movimientos no aparecen.</strong> Rellenar los huecos con filas en
     * cero seria inventar filas que el dominio no tiene. Si la interfaz quiere un eje temporal
     * continuo, ella sabe que rango esta dibujando; el BFF no.
     *
     * @param movimientos todos los movimientos de la cuenta. Lista vacia devuelve lista vacia
     */
    public static List<MesWebResponse> resumirPorMes(List<MovimientoCoreDto> movimientos) {
        List<MovimientoCoreDto> seguros = movimientos == null ? List.of() : movimientos;

        Map<YearMonth, Acumulador> porMes = new LinkedHashMap<>();

        for (MovimientoCoreDto movimiento : seguros) {
            // Defensa barata: un movimiento sin fecha no se puede asignar a ningun mes. El core
            // no deberia entregar ninguno (descarta las filas con fecha ilegible durante la
            // ingesta), pero un NullPointerException aqui se veria como un 500 del canal web y
            // apuntaria al sitio equivocado al diagnosticar.
            if (movimiento.fecha() == null) {
                continue;
            }
            porMes.computeIfAbsent(YearMonth.from(movimiento.fecha()), mes -> new Acumulador())
                    .sumar(movimiento);
        }

        List<MesWebResponse> meses = new ArrayList<>(porMes.size());
        porMes.entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.naturalOrder()))
                .forEach(entrada -> meses.add(entrada.getValue().aRespuesta(entrada.getKey())));

        return List.copyOf(meses);
    }

    /**
     * La unica definicion de "abono" del canal web.
     *
     * <p>Manda el campo {@code tipo}, nunca la {@code descripcion}. El contrato advierte que el
     * archivo legado trae glosas que contradicen al tipo (una fila marcada {@code RETIRO} con la
     * descripcion "Deposito mensual"). Clasificar mirando el texto produciria totales que no
     * cuadran con los movimientos que el usuario ve en la tabla.
     */
    private static boolean esAbono(MovimientoCoreDto movimiento) {
        return TIPO_ABONO.equals(movimiento.tipo());
    }

    /** Lleva un total a la escala de publicacion. Ver {@link #DECIMALES_DE_MONEDA}. */
    private static BigDecimal normalizarEscala(BigDecimal total) {
        // HALF_UP y no UNNECESSARY: si algun importe llegara con mas de dos decimales, el modo
        // UNNECESSARY lanzaria ArithmeticException y tumbaria la respuesta completa por un
        // detalle de presentacion. Redondear al centavo mas cercano es la convencion de dinero.
        return total.setScale(DECIMALES_DE_MONEDA, RoundingMode.HALF_UP);
    }

    /**
     * Acumulador mutable de un mes mientras dura el recorrido.
     *
     * <p>Es mutable a proposito y su vida entera transcurre dentro de
     * {@link #resumirPorMes(List)}: nunca escapa de ese metodo. Los objetos que si salen de esta
     * clase ({@code MesWebResponse}, {@code ResumenWebResponse}) son records inmutables.
     */
    private static final class Acumulador {

        private BigDecimal abonos = BigDecimal.ZERO;
        private BigDecimal cargos = BigDecimal.ZERO;
        private int cantidad;

        private void sumar(MovimientoCoreDto movimiento) {
            BigDecimal monto = movimiento.monto() == null ? BigDecimal.ZERO : movimiento.monto();
            if (esAbono(movimiento)) {
                abonos = abonos.add(monto);
            } else {
                cargos = cargos.add(monto);
            }
            cantidad++;
        }

        private MesWebResponse aRespuesta(YearMonth mes) {
            // YearMonth.toString() produce exactamente "2024-03", que es el formato congelado en
            // la seccion 5.9 del contrato. No hace falta un DateTimeFormatter propio.
            return new MesWebResponse(
                    mes.toString(), normalizarEscala(abonos), normalizarEscala(cargos), cantidad);
        }
    }
}
