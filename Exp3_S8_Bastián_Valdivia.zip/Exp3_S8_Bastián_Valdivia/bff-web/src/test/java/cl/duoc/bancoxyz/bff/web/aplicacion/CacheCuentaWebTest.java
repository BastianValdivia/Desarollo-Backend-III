package cl.duoc.bancoxyz.bff.web.aplicacion;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * La cache del canal web, comprobada por su <strong>efecto</strong> sobre el core.
 *
 * <h2>Por que esta prueba levanta el contexto de Spring, que es lento</h2>
 *
 * <p>Porque es la unica forma de que exista lo que se quiere probar. {@code @Cacheable} no lo
 * implementa el compilador: lo implementa un <em>proxy</em> que el contenedor de Spring pone
 * delante del bean al crearlo. Un objeto construido con {@code new} no lleva proxy, y por tanto no
 * cachea. Una prueba de cache escrita con {@code new} pasaria en verde con la anotacion
 * <strong>borrada</strong>, que es la definicion exacta de una prueba inutil.
 *
 * <p>Es el precio justo a pagar: las pruebas de la logica del canal son rapidas y no levantan
 * nada; esta, que prueba una decision de infraestructura, levanta la infraestructura.
 *
 * <h2>Y por que se cuenta el core en vez de cronometrar</h2>
 *
 * <p>Lo que la cache promete no es velocidad, es <strong>menos carga aguas arriba</strong>. Medir
 * eso con un cronometro seria un error: el tiempo de una segunda llamada tambien baja por el
 * calentamiento del JIT y por la reutilizacion de la conexion, asi que un numero mas bajo no
 * probaria nada. Lo que se comprueba aqui es cuantas veces se toco el {@link CoreClient}, que es
 * exactamente la afirmacion que se esta haciendo.
 */
@SpringBootTest
@DisplayName("Cache del canal web: menos llamadas al core, y la autorizacion intacta")
class CacheCuentaWebTest {

    @Autowired
    private CacheCuentaWeb cache;

    @Autowired
    private CacheManager gestorDeCaches;

    @MockBean
    private CoreClient core;

    /**
     * Vaciar la cache antes de CADA prueba, y no es opcional.
     *
     * <p>Una cache es estado compartido que sobrevive de un metodo de prueba al siguiente: sin este
     * borrado, la segunda prueba encontraria la cuenta que dejo la primera, contaria cero llamadas
     * al core y pasaria o fallaria segun el <strong>orden</strong> en que JUnit decidiera
     * ejecutarlas. Ese tipo de prueba falla un dia de cada veinte y se acaba marcando como
     * inestable en vez de arreglarse.
     */
    @BeforeEach
    void vaciarCache() {
        gestorDeCaches.getCacheNames()
                .forEach(nombre -> gestorDeCaches.getCache(nombre).clear());
    }

    @Test
    @DisplayName("dos peticiones de la misma cuenta producen UNA sola llamada al core")
    void segundaLlamadaNoViajaAlCore() {
        given(core.obtenerCuenta(anyInt())).willReturn(cuentaDemo(116));

        cache.obtenerCuenta(116);
        cache.obtenerCuenta(116);
        cache.obtenerCuenta(116);

        // El numero exacto es lo que importa: no "menos de tres", sino UNA.
        verify(core, times(1)).obtenerCuenta(116);
    }

    @Test
    @DisplayName("cuentas distintas NO se pisan entre si: la clave es el cuentaId")
    void cadaCuentaTieneSuEntrada() {
        given(core.obtenerCuenta(anyInt())).willReturn(cuentaDemo(116));

        cache.obtenerCuenta(116);
        cache.obtenerCuenta(105);

        // Esta prueba protege contra un fallo muy caro y muy silencioso: una clave de cache mal
        // elegida (por ejemplo, una constante) haria que la cuenta 105 recibiera los datos de la
        // 116. No seria un problema de rendimiento, seria entregarle a un cliente el saldo de otro.
        verify(core, times(1)).obtenerCuenta(116);
        verify(core, times(1)).obtenerCuenta(105);
    }

    @Test
    @DisplayName("la cache declarada en config-repo/bff-web.yml se llama 'cuenta-web'")
    void laCacheSeLlamaComoDiceElContrato() {
        cache.obtenerCuenta(116);

        // Un nombre mal escrito en el @Cacheable NO da error: Spring crearia una cache nueva en
        // silencio y la dconfig-repo/bff-web.yml, con su TTL y su tope de memoria, no se usaria nunca.
        // El sintoma seria una cache que funciona pero que no expira jamas.
        assertThat(gestorDeCaches.getCacheNames()).contains(CacheCuentaWeb.NOMBRE_CACHE);
        assertThat(gestorDeCaches.getCache(CacheCuentaWeb.NOMBRE_CACHE).get(116)).isNotNull();
    }

    @Test
    @DisplayName("olvidarCuenta expulsa la entrada y la siguiente peticion vuelve a viajar")
    void laInvalidacionFunciona() {
        given(core.obtenerCuenta(anyInt())).willReturn(cuentaDemo(116));

        cache.obtenerCuenta(116);
        cache.olvidarCuenta(116);
        cache.obtenerCuenta(116);

        verify(core, times(2)).obtenerCuenta(116);
    }

    private static CuentaCoreDto cuentaDemo(int cuentaId) {
        return new CuentaCoreDto(cuentaId, "Diana Prince", "HIPOTECA",
                new BigDecimal("12000.00"), 30, "CLP",
                List.of(new MovimientoCoreDto(
                        LocalDate.of(2024, 3, 8), "DEPOSITO", new BigDecimal("3000.00"),
                        "Deposito de prueba", "CSV_SEMILLA")));
    }
}
