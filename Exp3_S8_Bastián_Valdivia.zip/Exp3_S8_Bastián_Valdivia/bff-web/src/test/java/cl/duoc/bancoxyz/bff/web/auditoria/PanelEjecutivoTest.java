package cl.duoc.bancoxyz.bff.web.auditoria;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.comun.core.RestCoreClient;
import cl.duoc.bancoxyz.comun.core.dto.ArchivoCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;

/**
 * El panel del ejecutivo de {@code bff-web} y su consumo del auditoria-service, con la cadena de seguridad real
 * (tokens firmados con {@link EmisorDePrueba}) y el adaptador HTTP del auditoria simulado.
 *
 * <p>Lo que se prueba, que es el criterio "el panel del ejecutivo en bff-web consume la auditoria con su token de
 * servicio y Resilience4j":
 * <ul>
 *   <li>el panel es solo del ejecutivo (401 sin token, 403 a un cliente);</li>
 *   <li>con el servicio sano entrega las dos secciones;</li>
 *   <li>con el servicio caido la seccion de actividad sale marcada como no disponible, con un aviso, y la de
 *       calidad se entrega igual (el panel sigue en 200);</li>
 *   <li>el Retry reintenta las consultas, el CircuitBreaker se abre con el servicio caido y deja de llamarlo, y
 *       el Bulkhead existe con el tamano de D6.</li>
 * </ul>
 * La conversacion HTTP real (rutas, token adjunto, traduccion de errores) la prueba {@link RestAuditoriaClientTest}.
 */
@SpringBootTest
@AutoConfigureMockMvc
class PanelEjecutivoTest {

    private static final String PANEL = "/v1/admin/panel";

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private AuditoriaClient auditoria;
    @Autowired
    private CircuitBreakerRegistry circuitos;
    @Autowired
    private BulkheadRegistry mamparos;
    @Autowired
    private CacheManager caches;
    @Autowired
    private RespaldoDeLecturas respaldo;

    @MockBean
    private RestAuditoriaClient http;
    @MockBean
    private RestCoreClient core;

    private final EmisorDePrueba emisor = EmisorDePrueba.compartido();

    @BeforeEach
    void limpiar() {
        circuitos.circuitBreaker("auditoria").reset();
        circuitos.circuitBreaker("core").reset();
        caches.getCacheNames().forEach(nombre -> caches.getCache(nombre).clear());
        respaldo.vaciar();
        reset(http, core);
        when(core.obtenerCalidadDatos()).thenReturn(reporte());
    }

    private static ReporteCalidadCoreDto reporte() {
        return new ReporteCalidadCoreDto(Instant.parse("2026-10-03T12:00:00Z"), List.of(
                new ArchivoCalidadCoreDto("cuentas_anuales.csv", 1000, 900, 100)),
                Map.of("duplicada", 100), 50, 686, 1000);
    }

    private static EventoAuditoriaDto evento(String tipo, String clave) {
        return new EventoAuditoriaDto("6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11", tipo, 1,
                Instant.parse("2026-10-03T12:00:00Z"), "core-service", "bancoxyz.retiros.v1", clave,
                new ObjectMapper().createObjectNode().put("cuentaId", 116).put("monto", new BigDecimal("1000.00")));
    }

    private void auditoriaSana() {
        when(http.resumen()).thenReturn(new ResumenAuditoriaDto(3, Map.of("RETIRO_EJECUTADO", 2L,
                "PIN_INCORRECTO", 1L)));
        when(http.recientes(any(), anyInt())).thenReturn(new PaginaEventosAuditoriaDto(
                List.of(evento("RETIRO_EJECUTADO", "116")), 0, 10, 1));
    }

    private static AuditoriaNoDisponibleException caida() {
        return new AuditoriaNoDisponibleException("el auditoria-service no respondio");
    }

    private String bearerEjecutivo() {
        return "Bearer " + emisor.ejecutivoWeb().emitir();
    }

    // ------------------------------------------------------------------------------------------
    // Quien puede verlo
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Sin token: 401. Con el token de un CLIENTE (valido, del mismo canal): 403. El panel es solo del ejecutivo")
    void soloElEjecutivo() throws Exception {
        mvc.perform(get(PANEL)).andExpect(status().isUnauthorized());
        mvc.perform(get(PANEL).header(HttpHeaders.AUTHORIZATION, "Bearer " + emisor.clienteWeb116().emitir()))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"));
        verify(http, never()).resumen();
        verify(core, never()).obtenerCalidadDatos();
    }

    // ------------------------------------------------------------------------------------------
    // El panel completo
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Con el auditoria-service sano, el panel trae la calidad de datos y la actividad reciente")
    void panelCompleto() throws Exception {
        auditoriaSana();

        mvc.perform(get(PANEL).header(HttpHeaders.AUTHORIZATION, bearerEjecutivo()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.calidadDatos.disponible").value(true))
                .andExpect(jsonPath("$.calidadDatos.reporte.cuentasConsolidadas").value(50))
                .andExpect(jsonPath("$.actividad.disponible").value(true))
                .andExpect(jsonPath("$.actividad.resumen.total").value(3))
                .andExpect(jsonPath("$.actividad.resumen.porTipo.RETIRO_EJECUTADO").value(2))
                .andExpect(jsonPath("$.actividad.recientes[0].tipo").value("RETIRO_EJECUTADO"))
                .andExpect(jsonPath("$.actividad.recientes[0].datos.cuentaId").value(116))
                .andExpect(jsonPath("$.actividad.aviso").doesNotExist());
    }

    @Test
    @DisplayName("El filtro por cuenta llega al auditoria-service")
    void filtroPorCuenta() throws Exception {
        auditoriaSana();

        mvc.perform(get(PANEL).param("cuenta", "116").header(HttpHeaders.AUTHORIZATION, bearerEjecutivo()))
                .andExpect(status().isOk());

        verify(http).recientes(eq(116), eq(10));
    }

    // ------------------------------------------------------------------------------------------
    // Cuando el auditoria-service no esta
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Con el auditoria-service caido, el panel sale SIN esa seccion y lo avisa (200), con la calidad de datos intacta")
    void sinAuditoriaElPanelSaleSinEsaSeccion() throws Exception {
        when(http.resumen()).thenThrow(caida());

        mvc.perform(get(PANEL).header(HttpHeaders.AUTHORIZATION, bearerEjecutivo()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.actividad.disponible").value(false))
                .andExpect(jsonPath("$.actividad.aviso").value(org.hamcrest.Matchers.containsString("auditoria")))
                .andExpect(jsonPath("$.actividad.resumen").doesNotExist())
                .andExpect(jsonPath("$.actividad.recientes").doesNotExist())
                .andExpect(jsonPath("$.calidadDatos.disponible").value(true))
                .andExpect(jsonPath("$.calidadDatos.reporte.movimientosCargados").value(686));
    }

    @Test
    @DisplayName("Con el core caido, el panel sale sin la calidad de datos y lo avisa; la actividad se entrega igual")
    void sinCoreElPanelSaleSinCalidad() throws Exception {
        auditoriaSana();
        when(core.obtenerCalidadDatos()).thenThrow(new CoreNoDisponibleException("el core no respondio",
                "/internal/v1/admin/calidad-datos", null, null, null));

        mvc.perform(get(PANEL).header(HttpHeaders.AUTHORIZATION, bearerEjecutivo()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.calidadDatos.disponible").value(false))
                .andExpect(jsonPath("$.calidadDatos.reporte").doesNotExist())
                .andExpect(jsonPath("$.actividad.disponible").value(true))
                .andExpect(jsonPath("$.actividad.resumen.total").value(3));
    }

    // ------------------------------------------------------------------------------------------
    // Resilience4j
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Retry: un fallo pasajero se reintenta y el panel sale completo sin que el ejecutivo lo note")
    void unFalloPasajeroSeReintenta() throws Exception {
        when(http.resumen()).thenThrow(caida()).thenReturn(new ResumenAuditoriaDto(1, Map.of("RETIRO_EJECUTADO", 1L)));
        when(http.recientes(any(), anyInt())).thenReturn(new PaginaEventosAuditoriaDto(List.of(), 0, 10, 0));

        mvc.perform(get(PANEL).header(HttpHeaders.AUTHORIZATION, bearerEjecutivo()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.actividad.disponible").value(true));

        verify(http, times(2)).resumen();
    }

    @Test
    @DisplayName("Retry: con el servicio caido se hacen 3 intentos antes de rendirse")
    void tresIntentosAntesDeRendirse() throws Exception {
        when(http.resumen()).thenThrow(caida());

        mvc.perform(get(PANEL).header(HttpHeaders.AUTHORIZATION, bearerEjecutivo())).andExpect(status().isOk());

        verify(http, times(3)).resumen();
    }

    @Test
    @DisplayName("CircuitBreaker: con el servicio caido el circuito se abre y el panel deja de llamarlo (sale sin la seccion al instante)")
    void elCircuitoSeAbreYDejaDeLlamar() throws Exception {
        when(http.resumen()).thenThrow(caida());
        CircuitBreaker circuito = circuitos.circuitBreaker("auditoria");

        // 3 intentos por consulta; con 3 llamadas minimas el circuito abre en la primera consulta.
        mvc.perform(get(PANEL).header(HttpHeaders.AUTHORIZATION, bearerEjecutivo())).andExpect(status().isOk());
        assertThat(circuito.getState()).isEqualTo(CircuitBreaker.State.OPEN);
        verify(http, times(3)).resumen();

        // Abierto: la siguiente consulta no llega al servicio.
        long inicio = System.nanoTime();
        mvc.perform(get(PANEL).header(HttpHeaders.AUTHORIZATION, bearerEjecutivo()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.actividad.disponible").value(false));
        assertThat((System.nanoTime() - inicio) / 1_000_000).as("rechazo inmediato").isLessThan(1500);
        verify(http, times(3)).resumen();   // sigue en 3: no se llamo
    }

    @Test
    @DisplayName("La configuracion de config-repo llega a los mecanismos: circuito, reintentos y mamparo de 10 (D6)")
    void laConfiguracionLlegaALosMecanismos() {
        assertThat(auditoria).isInstanceOf(AuditoriaClientResiliente.class);
        var circuito = circuitos.circuitBreaker("auditoria").getCircuitBreakerConfig();
        assertThat(circuito.getSlidingWindowSize()).isEqualTo(6);
        assertThat(circuito.getMinimumNumberOfCalls()).isEqualTo(3);
        assertThat(circuito.getFailureRateThreshold()).isEqualTo(50f);
        assertThat(circuito.getPermittedNumberOfCallsInHalfOpenState()).isEqualTo(2);
        assertThat(mamparos.bulkhead("auditoria").getBulkheadConfig().getMaxConcurrentCalls()).isEqualTo(10);
    }
}
