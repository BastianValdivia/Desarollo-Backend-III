package cl.duoc.bancoxyz.bff.web.auditoria;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;

import com.sun.net.httpserver.HttpServer;

/**
 * El adaptador HTTP hacia el auditoria-service contra un servidor HTTP de verdad (el del JDK) que hace de
 * auditoria-service: la ruta, los parametros, el token que se adjunta y la traduccion de cada fallo.
 */
class RestAuditoriaClientTest {

    private static final String CUERPO_EVENTOS = """
            {"eventos":[{"eventId":"6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11","tipo":"RETIRO_EJECUTADO","version":1,
              "ocurridoEn":"2026-10-03T12:00:00Z","origen":"core-service","topico":"bancoxyz.retiros.v1","clave":"116",
              "datos":{"cuentaId":116,"monto":1000.00},"campoNuevo":"se ignora"}],
             "pagina":0,"tamano":10,"total":1}""";

    private HttpServer servidor;
    private final List<String> peticiones = new CopyOnWriteArrayList<>();
    private final List<String> autorizaciones = new CopyOnWriteArrayList<>();
    private volatile int estado = 200;
    private volatile String cuerpo = CUERPO_EVENTOS;
    private volatile long demoraMs = 0;
    private final AtomicInteger llamadas = new AtomicInteger();

    @BeforeEach
    void iniciar() throws IOException {
        servidor = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
        servidor.createContext("/", intercambio -> {
            llamadas.incrementAndGet();
            peticiones.add(intercambio.getRequestURI().toString());
            autorizaciones.add(intercambio.getRequestHeaders().getFirst("Authorization"));
            try {
                Thread.sleep(demoraMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            byte[] bytes = cuerpo.getBytes(StandardCharsets.UTF_8);
            intercambio.getResponseHeaders().add("Content-Type", "application/json");
            intercambio.sendResponseHeaders(estado, bytes.length);
            intercambio.getResponseBody().write(bytes);
            intercambio.close();
        });
        servidor.start();
    }

    @AfterEach
    void detener() {
        servidor.stop(0);
    }

    private RestAuditoriaClient cliente(Duration lectura) {
        var propiedades = new AuditoriaClientProperties("http://127.0.0.1:" + servidor.getAddress().getPort(),
                Duration.ofMillis(500), lectura, 10);
        // Sin balanceador (la direccion es literal) y con un "token de servicio" fijo en lugar del real.
        return new RestAuditoriaClient(RestClient.builder(), propiedades, (peticion, bytes, ejecucion) -> {
            peticion.getHeaders().setBearerAuth("token-de-servicio-de-prueba");
            return ejecucion.execute(peticion, bytes);
        });
    }

    @Test
    @DisplayName("Pide los eventos a /internal/v1/auditoria/eventos con el tamano y la cuenta, adjunta el token de servicio y lee la respuesta (ignorando campos nuevos)")
    void pideLosEventosConElToken() {
        PaginaEventosAuditoriaDto pagina = cliente(Duration.ofSeconds(2)).recientes(116, 10);

        assertThat(peticiones).containsExactly("/internal/v1/auditoria/eventos?tamano=10&cuenta=116");
        assertThat(autorizaciones).containsExactly("Bearer token-de-servicio-de-prueba");
        assertThat(pagina.total()).isEqualTo(1);
        assertThat(pagina.eventos()).hasSize(1);
        assertThat(pagina.eventos().get(0).tipo()).isEqualTo("RETIRO_EJECUTADO");
        assertThat(pagina.eventos().get(0).datos().get("cuentaId").asInt()).isEqualTo(116);
    }

    @Test
    @DisplayName("Sin filtro de cuenta, no la envia")
    void sinCuentaNoLaEnvia() {
        cliente(Duration.ofSeconds(2)).recientes(null, 5);

        assertThat(peticiones).containsExactly("/internal/v1/auditoria/eventos?tamano=5");
    }

    @Test
    @DisplayName("Pide el resumen a /internal/v1/auditoria/resumen")
    void pideElResumen() {
        cuerpo = "{\"total\":3,\"porTipo\":{\"RETIRO_EJECUTADO\":2,\"PIN_INCORRECTO\":1}}";

        ResumenAuditoriaDto resumen = cliente(Duration.ofSeconds(2)).resumen();

        assertThat(peticiones).containsExactly("/internal/v1/auditoria/resumen");
        assertThat(resumen.total()).isEqualTo(3);
        assertThat(resumen.porTipo()).containsEntry("RETIRO_EJECUTADO", 2L);
    }

    @Test
    @DisplayName("Un 401, un 403 o un 5xx se traducen a AuditoriaNoDisponibleException (el panel solo sabe que la seccion no esta)")
    void erroresDelServicioSeTraducen() {
        RestAuditoriaClient cliente = cliente(Duration.ofSeconds(2));
        cuerpo = "{\"motivo\":\"error\"}";
        for (int codigo : new int[] {401, 403, 500, 503}) {
            estado = codigo;
            assertThatThrownBy(cliente::resumen)
                    .as("estado %d", codigo)
                    .isInstanceOf(AuditoriaNoDisponibleException.class)
                    .hasMessageContaining(String.valueOf(codigo));
        }
    }

    @Test
    @DisplayName("Un servicio que se cuelga se corta con el timeout de lectura (no ocupa el hilo para siempre)")
    void timeoutDeLectura() {
        demoraMs = 1500;
        RestAuditoriaClient cliente = cliente(Duration.ofMillis(300));

        long inicio = System.nanoTime();
        assertThatThrownBy(cliente::resumen).isInstanceOf(AuditoriaNoDisponibleException.class);

        assertThat(Duration.ofNanos(System.nanoTime() - inicio)).isLessThan(Duration.ofMillis(1200));
    }

    @Test
    @DisplayName("Un servicio inalcanzable (nadie escucha en el puerto) es AuditoriaNoDisponibleException")
    void conexionRechazada() {
        RestAuditoriaClient cliente = cliente(Duration.ofSeconds(2));
        servidor.stop(0);

        assertThatThrownBy(cliente::resumen).isInstanceOf(AuditoriaNoDisponibleException.class);
    }

    @Test
    @DisplayName("Una respuesta que no es JSON es AuditoriaNoDisponibleException y no un error tecnico")
    void respuestaIlegible() {
        cuerpo = "esto no es json";

        assertThatThrownBy(() -> cliente(Duration.ofSeconds(2)).resumen())
                .isInstanceOf(AuditoriaNoDisponibleException.class);
    }
}
