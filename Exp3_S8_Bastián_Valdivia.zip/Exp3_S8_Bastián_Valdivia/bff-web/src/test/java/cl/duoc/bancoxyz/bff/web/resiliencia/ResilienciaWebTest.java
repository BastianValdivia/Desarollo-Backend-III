package cl.duoc.bancoxyz.bff.web.resiliencia;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.CoreClientProperties;
import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.core.RestCoreClient;
import cl.duoc.bancoxyz.comun.core.dto.ArchivoCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginacionCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.resiliencia.CoreClientResiliente;
import cl.duoc.bancoxyz.comun.resiliencia.RespaldoDeLecturas;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.RetryRegistry;

/**
 * La resiliencia del canal web de punta a punta, con el contexto completo, la configuracion REAL de
 * {@code config-repo/} y el decorador {@link CoreClientResiliente} verdadero. Lo unico que se simula es el
 * adaptador HTTP ({@link RestCoreClient}): el "core" que se cae, se pone lento o responde 404.
 *
 * <p>Comprueba el respaldo del canal (ultimo dato conocido marcado como desactualizado, o 503 con el
 * contrato de error), que la titularidad no se salta por el respaldo y que los 4xx de negocio no abren el
 * circuito.
 */
@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("Resiliencia del canal web")
class ResilienciaWebTest {

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private CoreClient core;
    @Autowired
    private CoreClientProperties propiedadesDelCliente;
    @Autowired
    private CircuitBreakerRegistry circuitos;
    @Autowired
    private RetryRegistry reintentos;
    @Autowired
    private BulkheadRegistry mamparos;
    @Autowired
    private CacheManager caches;
    @Autowired
    private RespaldoDeLecturas respaldo;

    /** El adaptador HTTP: el decorador real queda delante de este doble. */
    @MockBean
    private RestCoreClient http;

    private final EmisorDePrueba emisor = EmisorDePrueba.compartido();

    @BeforeEach
    void limpiar() {
        circuito().reset();
        caches.getCacheNames().forEach(nombre -> caches.getCache(nombre).clear());
        reset(http);
        // El respaldo es estado compartido del contexto: sin vaciarlo, un caso hereda el dato del anterior.
        respaldo.vaciar();
    }

    private CircuitBreaker circuito() {
        return circuitos.circuitBreaker("core");
    }

    private void olvidarLaCacheDelCanal() {
        caches.getCacheNames().forEach(nombre -> caches.getCache(nombre).clear());
    }

    private static CoreNoDisponibleException caida() {
        return new CoreNoDisponibleException("el core no respondio", "/internal/v1/cuentas/116", null, null, null);
    }

    private static CuentaCoreDto cuenta(int id) {
        return new CuentaCoreDto(id, "Diana Prince", "HIPOTECA", new BigDecimal("12000.00"), 30, "CLP",
                List.of(new MovimientoCoreDto(LocalDate.of(2024, 3, 8), "DEPOSITO", new BigDecimal("3000.00"),
                        "Deposito de prueba", "CSV_SEMILLA")));
    }

    private String bearer116() {
        return "Bearer " + emisor.clienteWeb116().emitir();
    }

    @Test
    @DisplayName("El canal usa el decorador y recibe de config-repo los valores de Resilience4j")
    void laConfiguracionDeConfigRepoLlegaALosMecanismos() {
        assertThat(core).isInstanceOf(CoreClientResiliente.class);
        // Los limites de tiempo son los del cliente HTTP (el TimeLimiter no aplica a llamadas bloqueantes).
        assertThat(propiedadesDelCliente.timeoutConexion().toMillis()).isEqualTo(500);
        assertThat(propiedadesDelCliente.timeoutLectura().toSeconds()).isEqualTo(2);

        var cb = circuito().getCircuitBreakerConfig();
        assertThat(cb.getSlidingWindowSize()).isEqualTo(10);
        assertThat(cb.getMinimumNumberOfCalls()).isEqualTo(5);
        assertThat(cb.getFailureRateThreshold()).isEqualTo(70f);
        assertThat(cb.getSlowCallDurationThreshold().toMillis()).isEqualTo(1000);
        assertThat(cb.getSlowCallRateThreshold()).isEqualTo(50f);
        assertThat(cb.getWaitIntervalFunctionInOpenState().apply(1)).isEqualTo(10_000L);
        assertThat(cb.getPermittedNumberOfCallsInHalfOpenState()).isEqualTo(3);
        assertThat(cb.isAutomaticTransitionFromOpenToHalfOpenEnabled()).isTrue();
        assertThat(cb.getRecordExceptionPredicate().test(caida())).isTrue();
        assertThat(cb.getRecordExceptionPredicate().test(
                new CoreRecursoNoEncontradoException("404", "/x", "{}"))).isFalse();

        var reintento = reintentos.retry("core").getRetryConfig();
        assertThat(reintento.getMaxAttempts()).isEqualTo(3);
        assertThat(reintento.getExceptionPredicate().test(caida())).isTrue();
        assertThat(reintento.getExceptionPredicate().test(
                new CoreRecursoNoEncontradoException("404", "/x", "{}"))).isFalse();

        var mamparo = mamparos.bulkhead("core").getBulkheadConfig();
        assertThat(mamparo.getMaxConcurrentCalls()).isEqualTo(20);
        assertThat(mamparo.getMaxWaitDuration().toMillis()).isZero();

        // La obtencion del token tiene sus propios mecanismos (D6: 2 intentos y circuito, sin mamparo).
        assertThat(reintentos.retry("auth-server").getRetryConfig().getMaxAttempts()).isEqualTo(2);
        assertThat(circuitos.circuitBreaker("auth-server").getCircuitBreakerConfig().getMinimumNumberOfCalls())
                .isEqualTo(2);
    }

    @Test
    @DisplayName("Con el core caido y sin cache fresca, la ficha sale del ultimo dato conocido, marcada como desactualizada")
    void elCoreCaidoSirveElUltimoDato() throws Exception {
        when(http.obtenerCuenta(116)).thenReturn(cuenta(116));
        String fresco = mvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("X-Datos-Desactualizados"))
                .andReturn().getResponse().getContentAsString();

        // Pasan los 60 s de la cache del canal y el core cae.
        olvidarLaCacheDelCanal();
        when(http.obtenerCuenta(116)).thenThrow(caida());

        String respaldo = mvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isOk())
                .andExpect(header().string("X-Datos-Desactualizados", "true"))
                .andExpect(header().exists("X-Datos-Antiguedad-Segundos"))
                .andExpect(header().string("Warning", "110 - \"Response is Stale\""))
                .andExpect(header().string("Cache-Control", "no-store"))
                .andReturn().getResponse().getContentAsString();

        // El cuerpo es el mismo dato real, no uno fabricado, y el contrato del canal no cambia.
        assertThat(respaldo).isEqualTo(fresco);
    }

    @Test
    @DisplayName("Con el core caido y SIN dato previo: 503 core_no_disponible con el contrato de error del canal")
    void sinDatoPrevioEs503() throws Exception {
        when(http.obtenerCuenta(116)).thenThrow(caida());

        mvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isServiceUnavailable())
                .andExpect(header().doesNotExist("X-Datos-Desactualizados"))
                .andExpect(jsonPath("$.motivo").value("core_no_disponible"))
                .andExpect(jsonPath("$.canal").value("WEB"))
                .andExpect(jsonPath("$.status").value(503));
    }

    @Test
    @DisplayName("La pagina de movimientos tambien tiene respaldo, y solo para la MISMA consulta")
    void losMovimientosTienenRespaldoPorConsulta() throws Exception {
        PaginaMovimientosCoreDto pagina = new PaginaMovimientosCoreDto(116,
                cuenta(116).movimientos(), new PaginacionCoreDto(0, 20, 1, 1));
        when(http.obtenerMovimientos(anyInt(), any())).thenReturn(pagina);
        mvc.perform(get("/v1/cuentas/116/movimientos?page=0&size=20")
                        .header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isOk());

        when(http.obtenerMovimientos(anyInt(), any())).thenThrow(caida());

        mvc.perform(get("/v1/cuentas/116/movimientos?page=0&size=20")
                        .header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isOk())
                .andExpect(header().string("X-Datos-Desactualizados", "true"));

        // Otra consulta (otro filtro) nunca se hizo: no hay dato que servir, y no se inventa uno.
        mvc.perform(get("/v1/cuentas/116/movimientos?page=0&size=20&tipo=RETIRO")
                        .header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.motivo").value("core_no_disponible"));
    }

    @Test
    @DisplayName("El respaldo NO salta la titularidad: un token de la cuenta 105 no ve la 116 aunque haya dato guardado")
    void elRespaldoNoSaltaLaTitularidad() throws Exception {
        when(http.obtenerCuenta(116)).thenReturn(cuenta(116));
        mvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isOk());
        olvidarLaCacheDelCanal();
        when(http.obtenerCuenta(116)).thenThrow(caida());

        mvc.perform(get("/v1/cuentas/116")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + emisor.clienteWeb105().emitir()))
                .andExpect(status().isForbidden())
                .andExpect(header().doesNotExist("X-Datos-Desactualizados"));
    }

    @Test
    @DisplayName("Treinta 404 seguidos (cuenta inexistente) no abren el circuito y el core sano sigue sirviendo")
    void los404NoAbrenElCircuito() throws Exception {
        when(http.obtenerCuenta(116)).thenThrow(new CoreRecursoNoEncontradoException("404", "/x", "{}"));

        for (int i = 0; i < 30; i++) {
            mvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer116()))
                    .andExpect(status().isNotFound());
        }

        assertThat(circuito().getState()).isEqualTo(CircuitBreaker.State.CLOSED);
        assertThat(circuito().getMetrics().getNumberOfFailedCalls()).isZero();

        // doReturn y no when(...): llamar al doble dentro de when() relanzaria el 404 que tiene programado.
        doReturn(cuenta(116)).when(http).obtenerCuenta(116);
        mvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Con el circuito abierto el canal responde con el respaldo SIN llamar al core")
    void conElCircuitoAbiertoNoSeLlamaAlCore() throws Exception {
        when(http.obtenerCuenta(116)).thenReturn(cuenta(116));
        mvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isOk());
        olvidarLaCacheDelCanal();

        when(http.obtenerCuenta(116)).thenThrow(caida());
        // Las fallas de infraestructura (3 intentos por peticion) abren el circuito.
        for (int i = 0; i < 3 && circuito().getState() != CircuitBreaker.State.OPEN; i++) {
            mvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer116()))
                    .andExpect(status().isOk())
                    .andExpect(header().string("X-Datos-Desactualizados", "true"));
            olvidarLaCacheDelCanal();
        }
        assertThat(circuito().getState()).isEqualTo(CircuitBreaker.State.OPEN);

        clearInvocations(http);
        mvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isOk())
                .andExpect(header().string("X-Datos-Desactualizados", "true"));
        verifyNoInteractions(http);
    }

    @Test
    @DisplayName("El panel del ejecutivo (calidad de datos) tambien se sirve desde el respaldo si el core cae")
    void elPanelDelEjecutivoTieneRespaldo() throws Exception {
        String ejecutivo = "Bearer " + emisor.ejecutivoWeb().emitir();
        ReporteCalidadCoreDto reporte = new ReporteCalidadCoreDto(java.time.Instant.parse("2026-01-01T00:00:00Z"),
                List.of(new ArchivoCalidadCoreDto("cuentas.csv", 50, 50, 0)), java.util.Map.of(), 50, 686, 1000);
        when(http.obtenerCalidadDatos()).thenReturn(reporte);
        mvc.perform(get("/v1/admin/calidad-datos").header(HttpHeaders.AUTHORIZATION, ejecutivo))
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("X-Datos-Desactualizados"));

        when(http.obtenerCalidadDatos()).thenThrow(caida());
        mvc.perform(get("/v1/admin/calidad-datos").header(HttpHeaders.AUTHORIZATION, ejecutivo))
                .andExpect(status().isOk())
                .andExpect(header().string("X-Datos-Desactualizados", "true"));
    }

    @Test
    @DisplayName("Un cliente (no ejecutivo) sigue sin ver el panel aunque haya respaldo: 403")
    void elRespaldoNoAbreElPanelAUnCliente() throws Exception {
        mvc.perform(get("/v1/admin/calidad-datos").header(HttpHeaders.AUTHORIZATION, bearer116()))
                .andExpect(status().isForbidden());
    }
}
