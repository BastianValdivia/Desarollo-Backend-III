package cl.duoc.bancoxyz.bff.web.aplicacion;

import java.time.Instant;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.jwt.Jwt;

import cl.duoc.bancoxyz.comun.error.MotivosError;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Pruebas de la autorizacion por <strong>dato</strong> del canal web.
 *
 * <p><strong>Por que esta regla se prueba sola, sin contexto de Spring y sin cadena de
 * filtros.</strong> Porque es la regla de seguridad mas facil de romper en silencio de todo el
 * proyecto: si dejara de aplicarse, nada fallaria, nada se registraria y todas las peticiones
 * seguirian respondiendo 200. Simplemente cualquier usuario podria leer las cuentas de los demas
 * cambiando un numero en la URL. Las reglas que fallan sin dar senal son exactamente las que hay
 * que amarrar con pruebas rapidas, porque una prueba lenta es una prueba que se termina
 * desactivando.
 *
 * <p>Los tokens se construyen a mano con el constructor de {@link Jwt}: aqui no se prueba la
 * validacion del token (de eso se encarga el resource server y no es codigo de este proyecto), sino
 * la decision que se toma <em>despues</em> de que el token ya fue validado.
 */
class GuardiaTitularidadWebTest {

    private final GuardiaTitularidadWeb guardia = new GuardiaTitularidadWeb();

    /**
     * Construye un token ya validado, como el que el resource server entrega al controlador.
     *
     * <p>El claim {@code cuentaId} se escribe como {@code Long} <strong>a proposito</strong>, y no
     * como {@code Integer}. Es lo que ocurre en la realidad: JSON no distingue entre entero y entero
     * largo, asi que el claim que se firmo como {@code Integer} vuelve como {@code Long} al
     * deserializar. Una comprobacion escrita con {@code equals} entre envoltorios de distinto tipo
     * devuelve <strong>siempre</strong> falso, y el titular de la 116 recibiria 403 sobre su propia
     * cuenta. Escribirlo asi en la prueba es lo que garantiza que este guardia no pueda caer en esa
     * trampa sin que la prueba se ponga roja.
     */
    private static Jwt tokenDe(Long cuentaId, List<String> autoridades) {
        Jwt.Builder constructor = Jwt.withTokenValue("token-de-prueba")
                .header("alg", "RS256")
                .issuedAt(Instant.now())
                .expiresAt(Instant.now().plusSeconds(1800))
                .subject("usuario-de-prueba")
                .claim("canal", "WEB")
                .claim("authorities", autoridades);

        if (cuentaId != null) {
            constructor.claim("cuentaId", cuentaId);
        }
        return constructor.build();
    }

    private static final List<String> AUTORIDADES_CLIENTE =
            List.of("ROLE_CLIENTE_WEB", "PERM_cuenta:leer", "PERM_movimientos:leer", "PERM_resumen:leer");

    private static final List<String> AUTORIDADES_EJECUTIVO =
            List.of("ROLE_EJECUTIVO", "PERM_auditoria:leer");

    @Test
    @DisplayName("El cliente accede a su propia cuenta")
    void clienteAccedeASuCuenta() {
        Jwt token = tokenDe(116L, AUTORIDADES_CLIENTE);

        assertThatCode(() -> guardia.exigirTitularidad(token, 116)).doesNotThrowAnyException();
    }

    @Test
    @DisplayName("El cliente que pide una cuenta ajena recibe 403 cuenta_ajena, nunca 404")
    void clienteNoAccedeACuentaAjena() {
        Jwt token = tokenDe(116L, AUTORIDADES_CLIENTE);

        assertThatThrownBy(() -> guardia.exigirTitularidad(token, 105))
                .isInstanceOf(ReglaWebException.class)
                .satisfies(fallo -> {
                    ReglaWebException regla = (ReglaWebException) fallo;
                    assertThat(regla.estado()).isEqualTo(403);
                    assertThat(regla.motivo()).isEqualTo(MotivosError.CUENTA_AJENA);
                });
    }

    /**
     * La consecuencia del orden congelado "titularidad antes que existencia": una cuenta que no
     * existe se rechaza igual, y con el mismo motivo, que una que si existe y es de otro. Si no
     * fuera asi, comparar las dos respuestas convertiria el canal en un detector de cuentas
     * existentes para cualquiera con un token valido.
     */
    @Test
    @DisplayName("Una cuenta ajena e inexistente tambien es 403 cuenta_ajena, no 404")
    void cuentaAjenaEInexistenteEsIgualDeAjena() {
        Jwt token = tokenDe(116L, AUTORIDADES_CLIENTE);

        assertThatThrownBy(() -> guardia.exigirTitularidad(token, 999))
                .isInstanceOf(ReglaWebException.class)
                .extracting(fallo -> ((ReglaWebException) fallo).motivo())
                .isEqualTo(MotivosError.CUENTA_AJENA);
    }

    /**
     * La regla de negocio del segundo perfil del canal: el ejecutivo no tiene cuenta propia, asi
     * que la pregunta "es tuya?" no aplica y la titularidad no lo detiene sobre ninguna cuenta.
     *
     * <p>Esto no le abre ninguna ruta: la cadena de filtros sigue exigiendo la autoridad de cada
     * endpoint, y con las autoridades que el contrato congela para este perfil recibe hoy 403
     * {@code permiso_insuficiente} en la ficha de cuenta, sin llegar nunca a este guardia. Son dos
     * niveles distintos y ninguno suple al otro.
     */
    @Test
    @DisplayName("El ejecutivo, sin cuenta propia, no queda detenido por la titularidad")
    void ejecutivoNoQuedaDetenidoPorTitularidad() {
        Jwt token = tokenDe(null, AUTORIDADES_EJECUTIVO);

        assertThatCode(() -> guardia.exigirTitularidad(token, 105)).doesNotThrowAnyException();
        assertThatCode(() -> guardia.exigirTitularidad(token, 130)).doesNotThrowAnyException();
    }

    /**
     * Un token sin claim {@code cuentaId} y sin rol de ejecutivo no acredita titularidad sobre
     * NINGUNA cuenta. Se trata como cuenta ajena y no como error del servidor: 500 seria ademas
     * decirle a quien sondea que encontro un camino que el servicio no esperaba.
     */
    @Test
    @DisplayName("Un token sin cuentaId y sin rol de ejecutivo no acredita ninguna cuenta")
    void tokenSinCuentaNiRolNoAcreditaNada() {
        Jwt token = tokenDe(null, List.of("PERM_cuenta:leer"));

        assertThatThrownBy(() -> guardia.exigirTitularidad(token, 116))
                .isInstanceOf(ReglaWebException.class)
                .extracting(fallo -> ((ReglaWebException) fallo).motivo())
                .isEqualTo(MotivosError.CUENTA_AJENA);
    }

    /**
     * Cierra la trampa descrita en {@code LectorClaimsToken}: el claim vuelve como {@code Long} y
     * hay que leerlo como {@link Number}. Esta prueba falla si alguien reescribe el guardia con un
     * {@code equals} entre envoltorios, que compila, no lanza nada y devuelve siempre falso.
     */
    @Test
    @DisplayName("El claim cuentaId se compara por valor numerico aunque viaje como Long")
    void elClaimSeComparaPorValorNumerico() {
        Jwt token = tokenDe(116L, AUTORIDADES_CLIENTE);

        assertThat(token.getClaims()).containsEntry("cuentaId", 116L);
        assertThatCode(() -> guardia.exigirTitularidad(token, 116)).doesNotThrowAnyException();
    }

    /**
     * Caso defensivo: un token nulo solo puede llegar aqui si alguien abriera la ruta con
     * {@code permitAll} sin querer. La regla conservadora es rechazar, no dejar pasar.
     */
    @Test
    @DisplayName("Sin token no hay titularidad que acreditar")
    void sinTokenNoHayTitularidad() {
        assertThatThrownBy(() -> guardia.exigirTitularidad(null, 116))
                .isInstanceOf(ReglaWebException.class);
    }
}
