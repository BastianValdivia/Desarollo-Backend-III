package cl.duoc.bancoxyz.bff.web.aplicacion;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.security.oauth2.jwt.Jwt;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.error.MotivosError;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;

/**
 * La prueba mas importante de la etapa de optimizacion: <strong>un acierto de cache no puede
 * saltarse la comprobacion de titularidad</strong>.
 *
 * <h2>El fallo que esta prueba existe para impedir</h2>
 *
 * <p>La forma natural de escribir una cache es poner {@code @Cacheable} sobre el metodo del
 * servicio que ya existe, que en este canal seria
 * {@code CuentaWebService.obtenerFicha(cuentaId, token)}. Si se hiciera eso con la clave puesta en
 * {@code #cuentaId} (que es lo unico razonable, porque una clave que incluyera el token no
 * acertaria casi nunca), el resultado seria este:
 *
 * <ol>
 *   <li>El titular de la cuenta 116 pide su ficha. La comprobacion pasa, se llama al core y la
 *       respuesta se guarda bajo la clave 116.</li>
 *   <li>Otro usuario, titular de la 105, pide la cuenta 116. <strong>Hay acierto de cache</strong>,
 *       asi que el cuerpo del metodo <em>no se ejecuta</em>. Y la comprobacion de titularidad vivia
 *       dentro de ese cuerpo.</li>
 *   <li>Recibe 200 y los datos de otro cliente.</li>
 * </ol>
 *
 * <p>No habria excepcion, ni aviso, ni nada en el log. Y lo peor: <strong>solo ocurriria cuando la
 * cache acierta</strong>, es decir en la segunda peticion y dentro de la ventana del TTL. Una
 * prueba manual hecha con calma, o una prueba automatizada que pidiera cada cuenta una sola vez,
 * lo dejaria pasar sin enterarse.
 *
 * <p>La regla que hay que llevarse, y que vale para cualquier {@code @Cacheable} que se escriba en
 * la vida: <strong>cachear un metodo es no ejecutar su cuerpo</strong>. Todo lo que ese cuerpo
 * hacia (validar, autorizar, auditar, registrar) deja de ocurrir en los aciertos. Por eso en este
 * proyecto lo cacheado es el <em>dato</em> ({@link CacheCuentaWeb}) y la autorizacion vive fuera,
 * en {@link CuentaWebService}, donde se ejecuta siempre.
 *
 * <p>Esta prueba recorre exactamente la secuencia de arriba y exige que el paso 2 termine en un
 * rechazo.
 */
@SpringBootTest
@DisplayName("La cache NO puede convertirse en un atajo para saltarse la autorizacion")
class CacheNoSaltaAutorizacionWebTest {

    @Autowired
    private CuentaWebService servicio;

    @Autowired
    private CacheManager gestorDeCaches;

    @MockBean
    private CoreClient core;

    @BeforeEach
    void vaciarCache() {
        gestorDeCaches.getCacheNames()
                .forEach(nombre -> gestorDeCaches.getCache(nombre).clear());
        given(core.obtenerCuenta(anyInt())).willReturn(cuentaDemo(116));
    }

    @Test
    @DisplayName("con la cuenta YA cacheada, un token ajeno sigue recibiendo cuenta_ajena")
    void elAciertoDeCacheNoAbreLaPuerta() {
        // PASO 1: el titular legitimo calienta la cache. A partir de aqui la cuenta 116 esta en
        // memoria y una segunda peticion NO viajara al core.
        assertThatCode(() -> servicio.obtenerFicha(116, tokenDeCliente(116L)))
                .doesNotThrowAnyException();

        assertThat(gestorDeCaches.getCache(CacheCuentaWeb.NOMBRE_CACHE).get(116))
                .describedAs("la cuenta debe estar cacheada, si no esta prueba no estaria "
                        + "comprobando el caso peligroso")
                .isNotNull();

        // PASO 2: el momento de la verdad. Otro usuario pide la misma cuenta, que esta cacheada.
        // Si la autorizacion viviera dentro del metodo cacheado, esto devolveria los datos.
        assertThatThrownBy(() -> servicio.obtenerFicha(116, tokenDeCliente(105L)))
                .isInstanceOfSatisfying(ReglaWebException.class, fallo -> {
                    assertThat(fallo.motivo()).isEqualTo(MotivosError.CUENTA_AJENA);
                    assertThat(fallo.estado()).isEqualTo(403);
                });
    }

    @Test
    @DisplayName("el resumen mensual, que comparte la misma cache, tampoco se salta el control")
    void elResumenMensualTampoco() {
        // W4 reutiliza deliberadamente la cache de W2, asi que hereda el mismo riesgo y necesita
        // la misma comprobacion. Se prueba aparte porque es un metodo distinto: en el original, la
        // llamada a exigirTitularidad estaba escrita dos veces, y una linea repetida es una linea
        // que alguien puede borrar en uno de los dos sitios.
        servicio.obtenerFicha(116, tokenDeCliente(116L));

        assertThatThrownBy(() -> servicio.obtenerResumenMensual(116, tokenDeCliente(105L)))
                .isInstanceOfSatisfying(ReglaWebException.class, fallo ->
                        assertThat(fallo.motivo()).isEqualTo(MotivosError.CUENTA_AJENA));
    }

    /**
     * Token ya validado de un cliente, como el que el resource server entrega al controlador.
     *
     * <p>El claim {@code cuentaId} se escribe como {@code Long} a proposito: es lo que ocurre al
     * deserializar un JWT real, porque JSON no distingue entero de entero largo.
     */
    private static Jwt tokenDeCliente(Long cuentaId) {
        return Jwt.withTokenValue("token-de-prueba")
                .header("alg", "RS256")
                .issuedAt(Instant.now())
                .expiresAt(Instant.now().plusSeconds(1800))
                .subject("cliente" + cuentaId)
                .claim("canal", "WEB")
                .claim("cuentaId", cuentaId)
                .claim("authorities", List.of(
                        "ROLE_CLIENTE_WEB", "PERM_cuenta:leer",
                        "PERM_movimientos:leer", "PERM_resumen:leer"))
                .build();
    }

    private static CuentaCoreDto cuentaDemo(int cuentaId) {
        return new CuentaCoreDto(cuentaId, "Diana Prince", "HIPOTECA",
                new BigDecimal("12000.00"), 30, "CLP",
                List.of(new MovimientoCoreDto(
                        LocalDate.of(2024, 3, 8), "DEPOSITO", new BigDecimal("3000.00"),
                        "Deposito de prueba", "CSV_SEMILLA")));
    }
}
