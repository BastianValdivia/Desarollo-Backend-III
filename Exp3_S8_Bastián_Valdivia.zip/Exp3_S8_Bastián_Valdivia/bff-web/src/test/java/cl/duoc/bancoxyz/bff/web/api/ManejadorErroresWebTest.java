package cl.duoc.bancoxyz.bff.web.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;

/**
 * Las peticiones mal formadas de un cliente AUTENTICADO se rechazan en el formato del canal (RFC 7807 con
 * {@code motivo} y {@code canal}) y nunca como un 500 ni como la pagina de error de Spring.
 *
 * <p>Estas pruebas vivian en el endpoint de login (Content-Type de formulario: 415, JSON ilegible: 400), que
 * desde F5 ya no esta en este canal: el login es del auth-server. El invariante que protegian, "un cuerpo o un
 * tipo de contenido que el canal no admite es un error del CLIENTE y se informa como tal", sigue valiendo para
 * cualquier ruta del canal, y por eso se prueba ahora sobre las que existen: metodo no permitido, ruta
 * inexistente y valor no convertible, todas con token valido.
 */
@SpringBootTest
@AutoConfigureMockMvc
class ManejadorErroresWebTest {

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;
    @MockBean
    private CoreClient core;

    private static String token() {
        return "Bearer " + EmisorDePrueba.compartido().clienteWeb116().emitir();
    }

    @Test
    @DisplayName("Un POST sobre una ruta de solo lectura es 405 en problem+json, no 500")
    void metodoNoPermitidoEs405() throws Exception {
        mvc.perform(post("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, token())
                        .contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isMethodNotAllowed())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("metodo_no_permitido"))
                .andExpect(jsonPath("$.canal").value("WEB"));
    }

    @Test
    @DisplayName("Una ruta que no existe es 404 en problem+json, no la pagina de error de Spring")
    void rutaInexistenteEs404() throws Exception {
        mvc.perform(get("/v1/no-existe").header(HttpHeaders.AUTHORIZATION, token()))
                .andExpect(status().isNotFound())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("recurso_no_encontrado"));
    }

    @Test
    @DisplayName("Un parametro de consulta que no se puede convertir es 400 peticion_invalida, no 500")
    void parametroNoConvertibleEs400() throws Exception {
        mvc.perform(get("/v1/cuentas/116/movimientos?size=muchos").header(HttpHeaders.AUTHORIZATION, token()))
                .andExpect(status().isBadRequest())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("peticion_invalida"));
    }

    @Test
    @DisplayName("Un identificador de cuenta que no es un numero es 404 (el canal no expone ese recurso), no 500")
    void cuentaNoNumericaEs404() throws Exception {
        mvc.perform(get("/v1/cuentas/abc").header(HttpHeaders.AUTHORIZATION, token()))
                .andExpect(status().isNotFound())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("recurso_no_encontrado"));
    }
}
