package cl.duoc.bancoxyz.bff.web.aplicacion;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.bff.web.api.dto.MesWebResponse;
import cl.duoc.bancoxyz.bff.web.api.dto.ResumenWebResponse;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;

/**
 * Pruebas de la agregacion del canal web.
 *
 * <p><strong>Por que esta clase se puede probar sin levantar nada.</strong>
 * {@code AgregadorResumenWeb} no conoce Spring, ni HTTP, ni el {@code CoreClient}: recibe una
 * lista y devuelve un objeto. Esa es la recompensa de haber sacado la agregacion del controlador.
 * Si el calculo viviera dentro del metodo del controlador, probar estos mismos cuatro casos
 * exigiria arrancar el contexto de Spring y simular el core, y cada prueba costaria segundos en
 * vez de milisegundos.
 *
 * <p>Los casos elegidos no son arbitrarios: cubren la regla de negocio (que es abono y que es
 * cargo), el caso borde congelado del proyecto (la cuenta 130, sin movimientos) y las dos
 * trampas del dataset legado (una glosa que contradice al tipo, y el agrupamiento por mes y no
 * por dia).
 */
class AgregadorResumenWebTest {

    private static MovimientoCoreDto movimiento(String fecha, String tipo, String monto, String descripcion) {
        return new MovimientoCoreDto(
                LocalDate.parse(fecha), tipo, new BigDecimal(monto), descripcion, "CSV_SEMILLA");
    }

    @Test
    @DisplayName("El deposito es abono y los otros tres tipos son cargo")
    void clasificaAbonosYCargosSegunElTipo() {
        List<MovimientoCoreDto> movimientos = List.of(
                movimiento("2024-03-08", "DEPOSITO", "3000.00", "Abono"),
                movimiento("2024-03-10", "RETIRO", "1000.00", null),
                movimiento("2024-03-11", "COMPRA", "500.00", null),
                movimiento("2024-03-12", "PAGO", "250.00", null));

        ResumenWebResponse resumen = AgregadorResumenWeb.resumirTodo(movimientos);

        assertEquals(new BigDecimal("3000.00"), resumen.totalAbonos());
        assertEquals(new BigDecimal("1750.00"), resumen.totalCargos());
        assertEquals(4, resumen.cantidadMovimientos());
    }

    @Test
    @DisplayName("Manda el tipo, nunca la descripcion: una glosa que miente no cambia el total")
    void ignoraLaDescripcionAlClasificar() {
        // El dataset legado trae filas marcadas RETIRO con glosas del estilo "Deposito mensual".
        // Clasificar mirando el texto produciria totales que no cuadran con la tabla que el
        // usuario tiene delante.
        List<MovimientoCoreDto> movimientos = List.of(
                movimiento("2024-03-08", "RETIRO", "2000.00", "Deposito mensual"));

        ResumenWebResponse resumen = AgregadorResumenWeb.resumirTodo(movimientos);

        assertEquals(new BigDecimal("0.00"), resumen.totalAbonos());
        assertEquals(new BigDecimal("2000.00"), resumen.totalCargos());
    }

    @Test
    @DisplayName("Caso borde de la cuenta 130: cero movimientos da totales en cero y lista vacia")
    void cuentaSinMovimientosNoProduceNiNulosNiDivisionPorCero() {
        ResumenWebResponse resumen = AgregadorResumenWeb.resumirTodo(List.of());

        assertEquals(new BigDecimal("0.00"), resumen.totalAbonos());
        assertEquals(new BigDecimal("0.00"), resumen.totalCargos());
        assertEquals(0, resumen.cantidadMovimientos());

        List<MesWebResponse> meses = AgregadorResumenWeb.resumirPorMes(List.of());
        assertTrue(meses.isEmpty(), "los meses de una cuenta sin movimientos deben ser [] y nunca null");
    }

    @Test
    @DisplayName("El resumen mensual agrupa por mes, no por dia, y sale ordenado ascendente")
    void agrupaPorMesEnOrdenAscendente() {
        // Deliberadamente desordenados en la entrada: el orden de salida lo decide el agregador,
        // no el azar con que el core haya cargado el archivo.
        List<MovimientoCoreDto> movimientos = List.of(
                movimiento("2024-05-02", "DEPOSITO", "1000.00", null),
                movimiento("2024-03-08", "DEPOSITO", "3000.00", null),
                movimiento("2024-03-25", "RETIRO", "500.00", null));

        List<MesWebResponse> meses = AgregadorResumenWeb.resumirPorMes(movimientos);

        assertEquals(2, meses.size(), "dos dias distintos de marzo son un solo mes");

        assertEquals("2024-03", meses.get(0).mes());
        assertEquals(new BigDecimal("3000.00"), meses.get(0).totalAbonos());
        assertEquals(new BigDecimal("500.00"), meses.get(0).totalCargos());
        assertEquals(2, meses.get(0).cantidadMovimientos());

        assertEquals("2024-05", meses.get(1).mes());
    }
}
