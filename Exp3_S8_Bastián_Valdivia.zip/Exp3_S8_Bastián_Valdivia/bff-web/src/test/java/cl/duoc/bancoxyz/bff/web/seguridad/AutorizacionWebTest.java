package cl.duoc.bancoxyz.bff.web.seguridad;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.soporte.EmisorDePrueba;
import cl.duoc.bancoxyz.comun.core.dto.ArchivoCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.MovimientoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaTransaccionesCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginacionCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.TransaccionNoConciliadaCoreDto;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Las reglas de autenticacion y autorizacion del canal web, ejercidas <strong>a traves de la cadena
 * de filtros real</strong>.
 *
 * <h2>Por que estas pruebas existen y por que no bastan las unitarias</h2>
 *
 * <p>Las reglas de seguridad que fallan en silencio son las que salen mas caras. Tres ejemplos
 * concretos de este canal, todos silenciosos:
 *
 * <ul>
 *   <li>{@code authority-prefix} sin comillas en el YAML: Spring conserva su prefijo por defecto
 *       {@code SCOPE_}, ninguna regla coincide y <em>todo</em> devuelve 403 despues de un login
 *       perfectamente exitoso, sin una sola advertencia en el log.</li>
 *   <li>Una regla escrita con {@code hasRole("EJECUTIVO")} en vez de
 *       {@code hasAuthority("ROLE_EJECUTIVO")}: compila, arranca y nunca coincide.</li>
 *   <li>Un {@code anyRequest().authenticated()} colocado antes de las reglas especificas: las de
 *       abajo dejan de leerse y cualquier token valido entra a las rutas de administracion.</li>
 * </ul>
 *
 * <p>Ninguno de los tres se detecta mirando el codigo ni probando clases sueltas: los tres exigen
 * levantar el contexto, presentar un token de verdad y pedir una ruta de verdad. Por eso estas pruebas
 * no fabrican autenticaciones simuladas: firman tokens con una clave de PRUEBA, con los mismos claims que
 * emite el auth-server ({@code EmisorDePrueba}), y los presentan al decodificador REAL del canal (el que
 * Spring Boot construye con {@code jwk-set-uri}, {@code issuer-uri} y {@code audiences}, contra un JWKS de
 * prueba por HTTP). Desde F5 el canal no emite tokens: el login vive en el auth-server y se prueba alli.
 *
 * <p>El unico doble es el {@code CoreClient}: no se prueba aqui que el core responda, sino quien
 * consigue llegar hasta el. Ese doble ademas permite la comprobacion mas fina de todo el archivo,
 * que es <strong>verificar que el core NO se llamo</strong> cuando la titularidad rechaza la
 * peticion.
 */
@SpringBootTest
@AutoConfigureMockMvc
class AutorizacionWebTest {

    @Autowired
    private MockMvc mockMvc;

    /**
     * El core no participa en estas pruebas: lo que se ejercita es quien llega hasta el.
     *
     * <p>Sin este doble, cada prueba de camino feliz necesitaria el {@code core-service} levantado,
     * y una prueba de seguridad que depende de otro proceso es una prueba que se termina
     * desactivando.
     */
    @MockBean
    private CoreClient core;

    // Credenciales de demostracion, identicas a la seccion 8 del contrato.
    private final EmisorDePrueba emisor = EmisorDePrueba.compartido();

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    private static String bearer(String token) {
        return "Bearer " + token;
    }

    @Nested
    @DisplayName("Sin token: 401 con el motivo del contrato")
    class SinToken {

        @Test
        @DisplayName("La ficha de cuenta exige token")
        void fichaExigeToken() throws Exception {
            mockMvc.perform(get("/v1/cuentas/116"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
                    .andExpect(content().contentTypeCompatibleWith("application/problem+json"))
                    .andExpect(jsonPath("$.motivo").value("token_ausente"))
                    .andExpect(jsonPath("$.canal").value("WEB"))
                    .andExpect(jsonPath("$.status").value(401));
        }

        @Test
        @DisplayName("Las dos rutas de administracion exigen token")
        void administracionExigeToken() throws Exception {
            mockMvc.perform(get("/v1/admin/calidad-datos"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_ausente"));

            mockMvc.perform(get("/v1/admin/transacciones-no-conciliadas"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_ausente"));
        }

        /**
         * Un token manipulado o emitido por otro canal muere en la primera barrera, la firma. Es la
         * razon por la que las seis celdas fuera de la diagonal de la matriz 3x3 son
         * {@code firma_invalida} y no {@code audiencia_invalida}.
         */
        @Test
        @DisplayName("Un token que no verifica la firma es 401 firma_invalida")
        void tokenManipuladoEsFirmaInvalida() throws Exception {
            String token = emisor.clienteWeb116().emitir();
            String manipulado = token.substring(0, token.lastIndexOf('.') + 1) + "ZmlybWEtaW52ZW50YWRh";

            mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer(manipulado)))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("firma_invalida"));
        }

        /**
         * {@code /actuator/health} esta abierto porque el guion de arranque tiene que esperar al
         * servicio antes de tener credencial; {@code /actuator/metrics} no lo esta. Si esta prueba
         * se pusiera roja porque metrics responde 200, significaria que la red de seguridad
         * {@code anyRequest().authenticated()} dejo de cubrir lo que no esta enumerado.
         *
         * <p>Esta diferencia solo se ejerce porque en las pruebas el servicio y Actuator comparten
         * puerto. En el despliegue (desde F1) Actuator vive en un puerto de gestion aparte, sin
         * token, y estas dos rutas, pedidas en el puerto del canal, responden 404 y 401.
         */
        @Test
        @DisplayName("La salud es publica y las metricas no")
        void saludPublicaYMetricasNo() throws Exception {
            mockMvc.perform(get("/actuator/health")).andExpect(status().isOk());

            mockMvc.perform(get("/actuator/metrics/jvm.memory.used"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_ausente"));
        }
    }

    @Nested
    @DisplayName("Tokens del auth-server: emisor, audiencia, firma y vigencia")
    class TokensDelAuthServer {

        private String peticion(String token) throws Exception {
            return mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer(token)))
                    .andReturn().getResponse().getContentAsString();
        }

        @Test
        @DisplayName("Matriz 3x3, fila del canal web: el token de movil, el del cajero y el de servicio del core se rechazan por AUDIENCIA, con firma valida")
        void lasCeldasCruzadasSon401PorAudiencia() throws Exception {
            for (String ajeno : List.of(
                    emisor.clienteMovil116("dispositivo-demo-01").emitir(),
                    emisor.tarjeta116().emitir(),
                    emisor.clienteWeb116().audiencia("core-service").emitir())) {
                mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, bearer(ajeno)))
                        .andExpect(status().isUnauthorized())
                        .andExpect(header().string(HttpHeaders.WWW_AUTHENTICATE, "Bearer"))
                        .andExpect(jsonPath("$.motivo").value("audiencia_invalida"))
                        .andExpect(jsonPath("$.canal").value("WEB"));
            }
            verify(core, never()).obtenerCuenta(anyInt());
        }

        @Test
        @DisplayName("La diagonal: el token con audiencia bff-web entra, y tambien uno cuya audiencia es una lista que la incluye")
        void laDiagonalEntra() throws Exception {
            given(core.obtenerCuenta(116)).willReturn(cuentaDemo(116));
            mockMvc.perform(get("/v1/cuentas/116")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.clienteWeb116().emitir())))
                    .andExpect(status().isOk());
            mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION,
                            bearer(emisor.clienteWeb116().audiencia("bff-web", "auditoria-service").emitir())))
                    .andExpect(status().isOk());
        }

        @Test
        @DisplayName("Un token de otro emisor (el emisor propio del S5, por ejemplo) es 401 firma_invalida aunque este bien firmado")
        void otroEmisorSeRechaza() throws Exception {
            mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION,
                            bearer(emisor.clienteWeb116().conEmisor("https://bancoxyz.duoc.cl/bff-web").emitir())))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("firma_invalida"));
        }

        @Test
        @DisplayName("Un token firmado con una clave que el auth-server no publica (mismo kid) es 401 firma_invalida")
        void firmadoPorOtraClave() throws Exception {
            mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION,
                            bearer(emisor.clienteWeb116().firmadoPorOtraClave().emitir())))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("firma_invalida"));
        }

        @Test
        @DisplayName("Un token sin firma (alg none) es 401")
        void tokenSinFirma() throws Exception {
            mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION,
                            bearer(emisor.clienteWeb116().emitirSinFirma())))
                    .andExpect(status().isUnauthorized());
        }

        @Test
        @DisplayName("Un token vencido es 401 token_expirado")
        void tokenVencido() throws Exception {
            mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION,
                            bearer(emisor.clienteWeb116().vencido().emitir())))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_expirado"));
        }

        @Test
        @DisplayName("El secreto del cuerpo no se filtra: la respuesta 401 no contiene el token ni descripciones de Spring")
        void elCuerpoDelErrorNoFiltra() throws Exception {
            String token = emisor.clienteWeb116().audiencia("bff-mobile").emitir();
            String cuerpo = peticion(token);
            assertThat(cuerpo).doesNotContain(token).doesNotContain("claim").doesNotContain("Jwt");
        }

        @Test
        @DisplayName("Un token valido sin claim authorities no abre nada: 403 permiso_insuficiente")
        void sinAutoridades() throws Exception {
            mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION,
                            bearer(emisor.clienteWeb116().sin("authorities").emitir())))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"));
        }

        @Test
        @DisplayName("El canal ya no emite tokens ni tiene login: POST /auth/login es 401 sin token y 404 con uno")
        void yaNoHayLogin() throws Exception {
            mockMvc.perform(post("/auth/login").contentType("application/json")
                            .content("{\"usuario\":\"cliente116\",\"clave\":\"Cliente.2026\"}"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.motivo").value("token_ausente"));
            mockMvc.perform(post("/auth/login").contentType("application/json")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.clienteWeb116().emitir()))
                            .content("{\"usuario\":\"cliente116\",\"clave\":\"Cliente.2026\"}"))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.motivo").value("recurso_no_encontrado"));
        }

        @Test
        @DisplayName("Un token de la cuenta 105 pidiendo la 116 es 403 cuenta_ajena y el segundo cliente comparte permisos con el primero")
        void titularidadConElTokenDelAuthServer() throws Exception {
            mockMvc.perform(get("/v1/cuentas/116")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.clienteWeb105().emitir())))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("cuenta_ajena"));
            verify(core, never()).obtenerCuenta(anyInt());
        }
    }

    @Nested
    @DisplayName("Perfil CLIENTE")
    class PerfilCliente {

        @Test
        @DisplayName("Accede a su propia cuenta")
        void accedeASuCuenta() throws Exception {
            given(core.obtenerCuenta(116)).willReturn(cuentaDemo(116));

            mockMvc.perform(get("/v1/cuentas/116")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.clienteWeb116().emitir())))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.cuentaId").value(116))
                    .andExpect(jsonPath("$.resumen.cantidadMovimientos").value(1));
        }

        /**
         * El 403 por <strong>dato</strong>, y su consecuencia mas exigible: la peticion muere en el
         * canal y el core no recibe ni una llamada. Ese {@code verify(never())} es lo que distingue
         * "se comprueba la titularidad" de "se comprueba la titularidad <em>antes</em> de preguntar
         * si la cuenta existe", que es lo que impide que el canal funcione como detector de cuentas.
         */
        @Test
        @DisplayName("Pedir una cuenta ajena es 403 cuenta_ajena y no llega al core")
        void cuentaAjenaEs403() throws Exception {
            mockMvc.perform(get("/v1/cuentas/105")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.clienteWeb116().emitir())))
                    .andExpect(status().isForbidden())
                    .andExpect(content().contentTypeCompatibleWith("application/problem+json"))
                    .andExpect(jsonPath("$.motivo").value("cuenta_ajena"))
                    .andExpect(jsonPath("$.status").value(403))
                    .andExpect(jsonPath("$.instance").value("/v1/cuentas/105"))
                    // Ningun 403 lleva WWW-Authenticate: quien ya esta identificado no gana nada
                    // repitiendo el login.
                    .andExpect(header().doesNotExist(HttpHeaders.WWW_AUTHENTICATE));

            verify(core, never()).obtenerCuenta(anyInt());
        }

        @Test
        @DisplayName("Una cuenta ajena que ni siquiera existe tambien es 403 cuenta_ajena")
        void cuentaAjenaEInexistenteEs403() throws Exception {
            mockMvc.perform(get("/v1/cuentas/999")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.clienteWeb116().emitir())))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("cuenta_ajena"));

            verify(core, never()).obtenerCuenta(anyInt());
        }

        /**
         * LA PRUEBA QUE DEFINE ESTE CANAL. Un token igual de valido que el del ejecutivo, del mismo
         * canal y firmado con la misma clave, recibe 403 en las dos rutas de administracion. Y
         * <strong>403, no 404</strong>: la ruta existe, lo que falta es el derecho.
         */
        @Test
        @DisplayName("Las rutas de administracion le responden 403 permiso_insuficiente, no 404")
        void administracionLeResponde403() throws Exception {
            String token = bearer(emisor.clienteWeb116().emitir());

            mockMvc.perform(get("/v1/admin/calidad-datos").header(HttpHeaders.AUTHORIZATION, token))
                    .andExpect(status().isForbidden())
                    .andExpect(content().contentTypeCompatibleWith("application/problem+json"))
                    .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"))
                    .andExpect(jsonPath("$.canal").value("WEB"));

            mockMvc.perform(get("/v1/admin/transacciones-no-conciliadas")
                            .header(HttpHeaders.AUTHORIZATION, token))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"));

            verify(core, never()).obtenerCalidadDatos();
        }

        @Test
        @DisplayName("El segundo cliente ve su cuenta y no la del primero")
        void elSegundoClienteVeLaSuya() throws Exception {
            given(core.obtenerCuenta(105)).willReturn(cuentaDemo(105));
            String token = bearer(emisor.clienteWeb105().emitir());

            mockMvc.perform(get("/v1/cuentas/105").header(HttpHeaders.AUTHORIZATION, token))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.cuentaId").value(105));

            mockMvc.perform(get("/v1/cuentas/116").header(HttpHeaders.AUTHORIZATION, token))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("cuenta_ajena"));
        }
    }

    @Nested
    @DisplayName("Perfil EJECUTIVO")
    class PerfilEjecutivo {

        @Test
        @DisplayName("Lee el reporte de calidad de datos")
        void leeElReporteDeCalidad() throws Exception {
            given(core.obtenerCalidadDatos()).willReturn(reporteDemo());

            mockMvc.perform(get("/v1/admin/calidad-datos")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.ejecutivoWeb().emitir())))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.cuentasConsolidadas").value(50))
                    .andExpect(jsonPath("$.movimientosCargados").value(686))
                    .andExpect(jsonPath("$.transaccionesNoConciliadas").value(1000))
                    .andExpect(jsonPath("$.archivos[0].archivo").value("intereses.csv"))
                    .andExpect(jsonPath("$.descartesPorMotivo.SALDO_INVALIDO").value(0));
        }

        @Test
        @DisplayName("Lee el lote no conciliado, con sus campos crudos y sus nulos")
        void leeElLoteNoConciliado() throws Exception {
            given(core.obtenerTransaccionesNoConciliadas(0, 20)).willReturn(loteDemo());

            mockMvc.perform(get("/v1/admin/transacciones-no-conciliadas")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.ejecutivoWeb().emitir())))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.transacciones[0].id").value(1))
                    .andExpect(jsonPath("$.transacciones[0].tipo").value("invalid"))
                    // La fecha ilegible se publica como null y no se rellena: maquillarla seria
                    // inventar un dato financiero en el unico reporte que existe para detectarlo.
                    .andExpect(jsonPath("$.transacciones[1].fecha").doesNotExist())
                    .andExpect(jsonPath("$.paginacion.tamano").value(20))
                    .andExpect(jsonPath("$.paginacion.totalElementos").value(1000));
        }

        /**
         * El tope de pagina se aplica EN EL SERVIDOR. Pedir 100000 no produce un error: produce una
         * pagina recortada al maximo del canal, y el campo {@code tamano} de la respuesta dice
         * exactamente cuantos elementos se entregaron, de modo que la respuesta nunca miente sobre
         * lo que hizo el servidor.
         */
        @Test
        @DisplayName("Un tamano de pagina absurdo se recorta al maximo del canal")
        void elTamanoSeRecorta() throws Exception {
            given(core.obtenerTransaccionesNoConciliadas(0, 100)).willReturn(loteDemo());

            mockMvc.perform(get("/v1/admin/transacciones-no-conciliadas?size=100000")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.ejecutivoWeb().emitir())))
                    .andExpect(status().isOk());

            verify(core).obtenerTransaccionesNoConciliadas(0, 100);
        }

        /**
         * La otra mitad de la prueba del doble perfil: el ejecutivo <strong>no</strong> puede leer
         * fichas de cuenta, porque sus autoridades congeladas no incluyen {@code PERM_cuenta:leer}.
         * Se detiene en el nivel 2 (permiso) y no llega al nivel 3 (titularidad), donde su rol si lo
         * eximiria. Cada nivel responde su propia pregunta y ninguno suple al otro.
         */
        @Test
        @DisplayName("No lee fichas de cuenta: le falta el permiso, no el rol")
        void noLeeFichasDeCuenta() throws Exception {
            mockMvc.perform(get("/v1/cuentas/116")
                            .header(HttpHeaders.AUTHORIZATION, bearer(emisor.ejecutivoWeb().emitir())))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"));

            verify(core, never()).obtenerCuenta(anyInt());
        }
    }

    // ------------------------------------------------------------------
    // Ayudas de lectura del token y datos de demostracion
    // ------------------------------------------------------------------

    /**
     * Decodifica la carga util del JWT.
     *
     * <p>Usa el decodificador <strong>sin relleno</strong> de Base64 URL. Es la misma trampa que la
     * evidencia con {@code curl} encuentra por el otro lado: {@code base64 -d} a secas falla sobre
     * un JWT porque la carga util viaja en Base64 URL sin los {@code =} finales, y por eso los
     * guiones del proyecto la decodifican con {@code python3}.
     */
    private static CuentaCoreDto cuentaDemo(int cuentaId) {
        return new CuentaCoreDto(cuentaId, "Diana Prince", "HIPOTECA", new BigDecimal("12000.00"), 30, "CLP",
                List.of(new MovimientoCoreDto(
                        LocalDate.of(2024, 3, 8), "DEPOSITO", new BigDecimal("3000.00"),
                        "Deposito de prueba", "CSV_SEMILLA")));
    }

    private static ReporteCalidadCoreDto reporteDemo() {
        return new ReporteCalidadCoreDto(
                Instant.parse("2026-09-11T03:18:43Z"),
                List.of(new ArchivoCalidadCoreDto(
                        "intereses.csv", 1000, 991, 9)),
                Map.of("SALDO_INVALIDO", 0, "TIPO_INVALIDO", 0, "EDAD_FUERA_DE_RANGO", 0,
                        "MONTO_NO_POSITIVO", 0, "FECHA_ILEGIBLE", 0),
                50, 686, 1000);
    }

    private static PaginaTransaccionesCoreDto loteDemo() {
        return new PaginaTransaccionesCoreDto(
                List.of(
                        new TransaccionNoConciliadaCoreDto(
                                1, LocalDate.of(2024, 3, 8), new BigDecimal("1500.00"), "invalid"),
                        new TransaccionNoConciliadaCoreDto(
                                2, null, null, "desconocido")),
                new PaginacionCoreDto(0, 20, 1000, 50));
    }
}
