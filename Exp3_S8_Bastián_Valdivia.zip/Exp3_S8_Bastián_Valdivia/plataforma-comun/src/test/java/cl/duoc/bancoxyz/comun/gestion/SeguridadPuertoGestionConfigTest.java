package cl.duoc.bancoxyz.comun.gestion;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Reproduce la situacion de un canal BFF: una cadena de seguridad que exige autenticacion en todo
 * ({@code anyRequest().authenticated()}, como la de cada canal) y Actuator en un puerto de gestion
 * distinto del de servicio.
 *
 * <p>Lo que se comprueba es la frontera de confianza de {@link SeguridadPuertoGestionConfig}:
 * <ul>
 *   <li>por el puerto de GESTION, health e info responden sin credencial (lo que necesitan el
 *       healthcheck y la demostracion de refresh) y lo que no esta expuesto (env) no existe;</li>
 *   <li>por el puerto de SERVICIO, nada de Actuator queda abierto y las rutas del canal siguen
 *       exigiendo credencial: abrir el puerto de gestion no debilita el publico.</li>
 * </ul>
 */
@SpringBootTest(
        classes = SeguridadPuertoGestionConfigTest.CanalDePrueba.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {
                "management.endpoints.web.exposure.include=health,info",
                "management.info.env.enabled=true",
                "info.demo=hola"
        })
class SeguridadPuertoGestionConfigTest {

    private static int puertoDeGestion;

    @DynamicPropertySource
    static void puertoDeGestionLibre(DynamicPropertyRegistry registro) throws IOException {
        try (ServerSocket libre = new ServerSocket(0)) {
            puertoDeGestion = libre.getLocalPort();
        }
        registro.add("management.server.port", () -> puertoDeGestion);
    }

    @Value("${local.server.port}")
    private int puertoDeServicio;

    private int get(int puerto, String ruta) throws Exception {
        HttpResponse<String> respuesta = HttpClient.newHttpClient().send(
                HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + puerto + ruta)).GET().build(),
                HttpResponse.BodyHandlers.ofString());
        return respuesta.statusCode();
    }

    @Test
    @DisplayName("Por el puerto de gestion, health e info responden sin credencial")
    void gestionAbiertaParaLosEndpointsExpuestos() throws Exception {
        assertThat(get(puertoDeGestion, "/actuator/health")).isEqualTo(200);
        assertThat(get(puertoDeGestion, "/actuator/info")).isEqualTo(200);
    }

    @Test
    @DisplayName("Por el puerto de gestion, un endpoint no expuesto (env) no existe")
    void unEndpointNoExpuestoNoExiste() throws Exception {
        assertThat(get(puertoDeGestion, "/actuator/env")).isEqualTo(404);
        assertThat(get(puertoDeGestion, "/actuator/configprops")).isEqualTo(404);
        assertThat(get(puertoDeGestion, "/actuator/heapdump")).isEqualTo(404);
    }

    @Test
    @DisplayName("Por el puerto de servicio, las rutas del canal siguen exigiendo credencial y Actuator no queda abierto")
    void elPuertoPublicoSigueCerrado() throws Exception {
        assertThat(get(puertoDeServicio, "/ping")).isEqualTo(401);
        assertThat(get(puertoDeServicio, "/actuator/info")).isEqualTo(401);
    }

    /** Un canal minimo: autenticacion obligatoria en todo, igual que los tres BFF reales. */
    @Configuration(proxyBeanMethods = false)
    @EnableAutoConfiguration
    @EnableWebSecurity
    @Import(SeguridadPuertoGestionConfig.class)
    static class CanalDePrueba {

        @Bean
        SecurityFilterChain cadenaDelCanal(HttpSecurity http) throws Exception {
            http.authorizeHttpRequests(reglas -> reglas.anyRequest().authenticated())
                    // 401 y no 403 para quien no se identifica, como el punto de entrada de cada canal.
                    .exceptionHandling(e -> e.authenticationEntryPoint(
                            new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))
                    .csrf(csrf -> csrf.disable());
            return http.build();
        }

        @RestController
        static class Ping {
            @GetMapping("/ping")
            String ping() {
                return "pong";
            }
        }
    }
}
