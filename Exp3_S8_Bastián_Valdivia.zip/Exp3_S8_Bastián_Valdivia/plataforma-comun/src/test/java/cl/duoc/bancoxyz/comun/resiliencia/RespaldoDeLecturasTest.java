package cl.duoc.bancoxyz.comun.resiliencia;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

@DisplayName("RespaldoDeLecturas: el ultimo dato conocido, solo cuando el core no esta disponible")
class RespaldoDeLecturasTest {

    /** Reloj que avanza solo cuando la prueba lo dice. */
    private static final class RelojManual extends Clock {
        private final AtomicReference<Instant> ahora = new AtomicReference<>(Instant.parse("2026-01-01T10:00:00Z"));

        void avanzar(Duration duracion) {
            ahora.updateAndGet(i -> i.plus(duracion));
        }

        @Override
        public ZoneId getZone() {
            return ZoneOffset.UTC;
        }

        @Override
        public Clock withZone(ZoneId zona) {
            return this;
        }

        @Override
        public Instant instant() {
            return ahora.get();
        }
    }

    private RelojManual reloj;
    private SimpleMeterRegistry metricas;
    private RespaldoDeLecturas respaldo;
    private MockHttpServletRequest peticion;

    @BeforeEach
    void armar() {
        reloj = new RelojManual();
        metricas = new SimpleMeterRegistry();
        respaldo = new RespaldoDeLecturas(new RespaldoProperties(Duration.ofMinutes(10), 3), reloj, metricas);
        peticion = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(peticion));
    }

    @AfterEach
    void limpiar() {
        RequestContextHolder.resetRequestAttributes();
    }

    private static CoreNoDisponibleException caida() {
        return new CoreNoDisponibleException("el core no respondio", "/x", null, null, null);
    }

    private Object marca() {
        return peticion.getAttribute(DatosDesactualizados.ATRIBUTO);
    }

    @Test
    @DisplayName("Con el core sano devuelve el dato y NO marca la peticion")
    void conElCoreSanoNoMarca() {
        String dato = respaldo.leerYRespaldar("cuenta", 116, () -> "saldo 1500");

        assertThat(dato).isEqualTo("saldo 1500");
        assertThat(marca()).isNull();
    }

    @Test
    @DisplayName("Con el core caido sirve el ultimo dato, marca la antiguedad real y cuenta el respaldo")
    void conElCoreCaidoSirveElUltimoDato() {
        respaldo.leerYRespaldar("cuenta", 116, () -> "saldo 1500");
        reloj.avanzar(Duration.ofSeconds(95));

        String dato = respaldo.leerYRespaldar("cuenta", 116, () -> {
            throw caida();
        });

        assertThat(dato).isEqualTo("saldo 1500");
        assertThat(marca()).isEqualTo(95L);
        assertThat(metricas.get(RespaldoDeLecturas.METRICA_SERVIDOS).tag("espacio", "cuenta").counter().count())
                .isEqualTo(1.0);
    }

    @Test
    @DisplayName("Sin ningun dato previo para esa clave, relanza: el canal responde 503")
    void sinDatoPrevioRelanza() {
        respaldo.leerYRespaldar("cuenta", 116, () -> "saldo 1500");

        assertThatThrownBy(() -> respaldo.leerYRespaldar("cuenta", 105, () -> {
            throw caida();
        })).isInstanceOf(CoreNoDisponibleException.class);
        assertThat(marca()).isNull();
    }

    @Test
    @DisplayName("Un dato mas viejo que la antiguedad maxima (10 min) no se sirve")
    void unDatoDemasiadoViejoNoSeSirve() {
        respaldo.leerYRespaldar("cuenta", 116, () -> "saldo 1500");
        reloj.avanzar(Duration.ofMinutes(10).plusSeconds(1));

        assertThatThrownBy(() -> respaldo.leerYRespaldar("cuenta", 116, () -> {
            throw caida();
        })).isInstanceOf(CoreNoDisponibleException.class);
        assertThat(marca()).isNull();
    }

    @Test
    @DisplayName("Solo se respalda ante CoreNoDisponibleException: un 404 del core NO se sirve desde el respaldo")
    void unaRespuestaDeNegocioNoSeRespalda() {
        respaldo.leerYRespaldar("cuenta", 116, () -> "saldo 1500");

        assertThatThrownBy(() -> respaldo.leerYRespaldar("cuenta", 116, () -> {
            throw new CoreRecursoNoEncontradoException("ya no existe", "/x", "{}");
        })).isInstanceOf(CoreRecursoNoEncontradoException.class);
        assertThat(marca()).isNull();
    }

    @Test
    @DisplayName("Las claves de distintas operaciones y cuentas no se pisan")
    void lasClavesNoSePisan() {
        respaldo.leerYRespaldar("cuenta", 116, () -> "cuenta 116");
        respaldo.leerYRespaldar("movimientos", 116, () -> "movimientos 116");
        respaldo.leerYRespaldar("cuenta", 105, () -> "cuenta 105");

        assertThat((String) respaldo.leerConRespaldo("cuenta", 116, () -> {
            throw caida();
        })).isEqualTo("cuenta 116");
        assertThat((String) respaldo.leerConRespaldo("movimientos", 116, () -> {
            throw caida();
        })).isEqualTo("movimientos 116");
        assertThat((String) respaldo.leerConRespaldo("cuenta", 105, () -> {
            throw caida();
        })).isEqualTo("cuenta 105");
    }

    @Test
    @DisplayName("leerConRespaldo NO guarda: la antiguedad que se informa es la del dato traido del core, no la del ultimo acierto de cache")
    void leerConRespaldoNoGuarda() {
        respaldo.respaldar("cuenta", 116, "saldo viejo");
        reloj.avanzar(Duration.ofSeconds(50));

        // Un acierto de cache entrega el mismo dato sin viajar al core: no debe "rejuvenecerlo".
        assertThat((String) respaldo.leerConRespaldo("cuenta", 116, () -> "saldo viejo")).isEqualTo("saldo viejo");
        reloj.avanzar(Duration.ofSeconds(10));

        respaldo.leerConRespaldo("cuenta", 116, () -> {
            throw caida();
        });
        assertThat(marca()).isEqualTo(60L);
    }

    @Test
    @DisplayName("El respaldo tiene tope de entradas: descarta las menos usadas")
    void tieneTopeDeMemoria() {
        respaldo.respaldar("cuenta", 1, "a");
        respaldo.respaldar("cuenta", 2, "b");
        respaldo.respaldar("cuenta", 3, "c");
        respaldo.respaldar("cuenta", 4, "d"); // tope 3: sale la 1

        assertThatThrownBy(() -> respaldo.leerConRespaldo("cuenta", 1, () -> {
            throw caida();
        })).isInstanceOf(CoreNoDisponibleException.class);
        assertThat((String) respaldo.leerConRespaldo("cuenta", 4, () -> {
            throw caida();
        })).isEqualTo("d");
    }

    @Test
    @DisplayName("Si la peticion ya tenia una marca, queda la antiguedad MAYOR")
    void quedaLaMayorAntiguedad() {
        DatosDesactualizados.marcar(Duration.ofSeconds(30));
        DatosDesactualizados.marcar(Duration.ofSeconds(5));
        assertThat(marca()).isEqualTo(30L);
        DatosDesactualizados.marcar(Duration.ofSeconds(90));
        assertThat(marca()).isEqualTo(90L);
    }

    @Test
    @DisplayName("Fuera de una peticion web, marcar no hace nada ni falla")
    void sinPeticionNoHaceNada() {
        RequestContextHolder.resetRequestAttributes();
        DatosDesactualizados.marcar(Duration.ofSeconds(5));
        assertThat(RequestContextHolder.getRequestAttributes()).isNull();
        assertThat(RequestAttributes.SCOPE_REQUEST).isEqualTo(0);
    }

    @Test
    @DisplayName("La politica rechaza valores sin sentido")
    void laPoliticaSeValida() {
        assertThatThrownBy(() -> new RespaldoProperties(Duration.ZERO, 10)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new RespaldoProperties(Duration.ofMinutes(1), 0)).isInstanceOf(IllegalArgumentException.class);
    }
}
