package cl.duoc.bancoxyz.comun.resiliencia;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.ObjectProvider;

import cl.duoc.bancoxyz.comun.core.CoreCircuitoAbiertoException;
import cl.duoc.bancoxyz.comun.core.CoreCredencialRechazadaException;
import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import cl.duoc.bancoxyz.comun.core.CoreRecursoNoEncontradoException;
import cl.duoc.bancoxyz.comun.core.CoreSaldoInsuficienteException;
import cl.duoc.bancoxyz.comun.core.CoreSaturadoException;
import cl.duoc.bancoxyz.comun.core.RestCoreClient;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto;
import io.github.resilience4j.bulkhead.BulkheadConfig;
import io.github.resilience4j.bulkhead.BulkheadFullException;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

/**
 * El decorador {@link CoreClientResiliente} sin contenedor de Spring: el orden de los mecanismos, que
 * errores cuentan, que se reintenta y como se traducen los rechazos. Los valores de las configuraciones
 * son los de {@code config-repo/application.yml} con ventanas mas chicas (para no necesitar decenas de
 * llamadas); que el YAML real produzca esos valores lo comprueba cada BFF con su prueba de contexto.
 */
@DisplayName("CoreClientResiliente: Retry( CircuitBreaker( Bulkhead( llamada ) ) )")
class CoreClientResilienteTest {

    private RestCoreClient http;
    private SimpleMeterRegistry metricas;
    private CircuitBreakerRegistry circuitos;
    private CoreClientResiliente cliente;

    @BeforeEach
    void armar() {
        armar(20);
    }

    private void armar(int llamadasSimultaneas) {
        http = mock(RestCoreClient.class);
        metricas = new SimpleMeterRegistry();
        circuitos = CircuitBreakerRegistry.of(CircuitBreakerConfig.custom()
                .slidingWindowSize(10).minimumNumberOfCalls(5).failureRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(30))
                .permittedNumberOfCallsInHalfOpenState(2)
                .recordExceptions(CoreNoDisponibleException.class)
                .ignoreExceptions(BulkheadFullException.class)
                .build());
        RetryRegistry reintentos = RetryRegistry.of(RetryConfig.custom()
                .maxAttempts(3).waitDuration(Duration.ofMillis(1))
                .retryExceptions(CoreNoDisponibleException.class).build());
        BulkheadRegistry mamparos = BulkheadRegistry.of(BulkheadConfig.custom()
                .maxConcurrentCalls(llamadasSimultaneas).maxWaitDuration(Duration.ZERO).build());
        @SuppressWarnings("unchecked")
        ObjectProvider<io.micrometer.core.instrument.MeterRegistry> proveedor = mock(ObjectProvider.class);
        when(proveedor.getIfAvailable()).thenReturn(metricas);
        cliente = new CoreClientResiliente(http, circuitos, reintentos, mamparos, proveedor);
    }

    private CircuitBreaker circuito() {
        return circuitos.circuitBreaker(CoreClientResiliente.INSTANCIA);
    }

    private static CoreNoDisponibleException caida() {
        return new CoreNoDisponibleException("el core no respondio", "/x", null, null, null);
    }

    private static SaldoCoreDto saldo() {
        return new SaldoCoreDto(116, new BigDecimal("1500.50"), "CLP");
    }

    @Test
    @DisplayName("Una lectura que falla dos veces por causas pasajeras sale bien al tercer intento")
    void unaLecturaSeReintentaHastaTresVeces() {
        when(http.obtenerSaldo(116)).thenThrow(caida(), caida()).thenReturn(saldo());

        assertThat(cliente.obtenerSaldo(116)).isEqualTo(saldo());

        verify(http, times(3)).obtenerSaldo(116);
    }

    @Test
    @DisplayName("Si los tres intentos fallan, sale la CoreNoDisponibleException original (el canal responde 503 o respaldo)")
    void agotadosLosIntentosSaleElFallo() {
        when(http.obtenerSaldo(116)).thenThrow(caida());

        assertThatThrownBy(() -> cliente.obtenerSaldo(116)).isInstanceOf(CoreNoDisponibleException.class)
                .isNotInstanceOf(CoreCircuitoAbiertoException.class);
        verify(http, times(3)).obtenerSaldo(116);
    }

    @Test
    @DisplayName("Un 404, un 409 o un 401/403 no se reintentan: son respuestas del core, no fallas")
    void lasRespuestasDeNegocioNoSeReintentan() {
        when(http.obtenerSaldo(999)).thenThrow(
                new CoreRecursoNoEncontradoException("no existe", "/x", "{}"));
        assertThatThrownBy(() -> cliente.obtenerSaldo(999)).isInstanceOf(CoreRecursoNoEncontradoException.class);
        verify(http, times(1)).obtenerSaldo(999);

        when(http.obtenerSaldo(105)).thenThrow(
                new CoreCredencialRechazadaException("403", "/x", 403, "{}"));
        assertThatThrownBy(() -> cliente.obtenerSaldo(105)).isInstanceOf(CoreCredencialRechazadaException.class);
        verify(http, times(1)).obtenerSaldo(105);
    }

    @Test
    @DisplayName("Cien respuestas 404 y 409 seguidas NO abren el circuito: los 4xx de negocio cuentan como llamadas buenas")
    void los4xxNoAbrenElCircuito() {
        when(http.obtenerSaldo(999)).thenThrow(new CoreRecursoNoEncontradoException("no existe", "/x", "{}"));
        when(http.ejecutarRetiro(anyInt(), any(), any())).thenThrow(
                new CoreSaldoInsuficienteException("sin saldo", "/x", "{}"));

        for (int i = 0; i < 50; i++) {
            assertThatThrownBy(() -> cliente.obtenerSaldo(999)).isInstanceOf(CoreRecursoNoEncontradoException.class);
            assertThatThrownBy(() -> cliente.ejecutarRetiro(116, new SolicitudRetiroCoreDto(new BigDecimal("1000")), "k"))
                    .isInstanceOf(CoreSaldoInsuficienteException.class);
        }

        assertThat(circuito().getState()).isEqualTo(CircuitBreaker.State.CLOSED);
        assertThat(circuito().getMetrics().getNumberOfFailedCalls()).isZero();
        assertThat(circuito().getMetrics().getNumberOfSuccessfulCalls()).isPositive();
    }

    @Test
    @DisplayName("Las fallas de infraestructura abren el circuito; abierto, rechaza SIN llamar al core")
    void lasFallasAbrenElCircuitoYAbiertoNoLlama() {
        when(http.obtenerSaldo(116)).thenThrow(caida());

        // Cada peticion gasta 3 intentos, y cada intento cuenta: con minimumNumberOfCalls=5 abre en la segunda.
        assertThatThrownBy(() -> cliente.obtenerSaldo(116)).isInstanceOf(CoreNoDisponibleException.class);
        assertThatThrownBy(() -> cliente.obtenerSaldo(116)).isInstanceOf(CoreNoDisponibleException.class);
        assertThat(circuito().getState()).isEqualTo(CircuitBreaker.State.OPEN);
        int llamadasAlAbrir = org.mockito.Mockito.mockingDetails(http).getInvocations().size();

        assertThatThrownBy(() -> cliente.obtenerSaldo(116))
                .isInstanceOf(CoreCircuitoAbiertoException.class)
                .isInstanceOf(CoreNoDisponibleException.class);

        assertThat(org.mockito.Mockito.mockingDetails(http).getInvocations()).hasSize(llamadasAlAbrir);
        // La segunda peticion ya choco con el circuito al abrirse a mitad de sus reintentos (1 rechazo) y la
        // tercera lo encontro abierto desde el principio (otro): dos llamadas rechazadas sin intentarlas.
        assertThat(metricas.get(CoreClientResiliente.METRICA_RECHAZOS).tag("motivo", "circuito_abierto")
                .counter().count()).isEqualTo(2.0);
    }

    @Test
    @DisplayName("Con el circuito abierto el retiro tampoco llega al core (el cajero falla cerrado)")
    void conElCircuitoAbiertoNoHayRetiro() {
        circuito().transitionToOpenState();

        assertThatThrownBy(() -> cliente.ejecutarRetiro(116, new SolicitudRetiroCoreDto(new BigDecimal("5000")), "clave-1"))
                .isInstanceOf(CoreCircuitoAbiertoException.class);

        verifyNoInteractions(http);
    }

    @Test
    @DisplayName("El circuito recorre CLOSED, OPEN, HALF_OPEN y CLOSED")
    void recorreLosCuatroEstados() {
        CircuitBreaker circuito = circuito();
        assertThat(circuito.getState()).isEqualTo(CircuitBreaker.State.CLOSED);

        when(http.obtenerSaldo(116)).thenThrow(caida());
        assertThatThrownBy(() -> cliente.obtenerSaldo(116)).isInstanceOf(CoreNoDisponibleException.class);
        assertThatThrownBy(() -> cliente.obtenerSaldo(116)).isInstanceOf(CoreNoDisponibleException.class);
        assertThat(circuito.getState()).isEqualTo(CircuitBreaker.State.OPEN);

        circuito.transitionToHalfOpenState(); // lo que hace solo, pasado waitDurationInOpenState
        assertThat(circuito.getState()).isEqualTo(CircuitBreaker.State.HALF_OPEN);

        org.mockito.Mockito.reset(http);
        when(http.obtenerSaldo(116)).thenReturn(saldo());
        cliente.obtenerSaldo(116);
        cliente.obtenerSaldo(116);
        assertThat(circuito.getState()).isEqualTo(CircuitBreaker.State.CLOSED);
    }

    @Test
    @DisplayName("El retiro con Idempotency-Key se reintenta con LA MISMA clave")
    void elRetiroConClaveSeReintentaConLaMismaClave() {
        SolicitudRetiroCoreDto solicitud = new SolicitudRetiroCoreDto(new BigDecimal("5000"));
        RetiroCoreDto retiro = new RetiroCoreDto("FOLIO-1", new BigDecimal("12000"),
                new BigDecimal("5000"), new BigDecimal("7000"));
        when(http.ejecutarRetiro(116, solicitud, "clave-1")).thenThrow(caida()).thenReturn(retiro);

        assertThat(cliente.ejecutarRetiro(116, solicitud, "clave-1")).isEqualTo(retiro);

        verify(http, times(2)).ejecutarRetiro(116, solicitud, "clave-1");
    }

    @Test
    @DisplayName("Un retiro SIN clave de idempotencia no se reintenta: repetirlo podria descontar dos veces")
    void elRetiroSinClaveNoSeReintenta() {
        SolicitudRetiroCoreDto solicitud = new SolicitudRetiroCoreDto(new BigDecimal("5000"));
        when(http.ejecutarRetiro(eq(116), eq(solicitud), any())).thenThrow(caida());

        assertThatThrownBy(() -> cliente.ejecutarRetiro(116, solicitud, null))
                .isInstanceOf(CoreNoDisponibleException.class);
        assertThatThrownBy(() -> cliente.ejecutarRetiro(116, solicitud, "  "))
                .isInstanceOf(CoreNoDisponibleException.class);

        verify(http, times(2)).ejecutarRetiro(eq(116), eq(solicitud), any());
    }

    @Test
    @DisplayName("El mamparo lleno rechaza al instante, no se reintenta y no cuenta como falla del core")
    void elMamparoLlenoRechazaSinContarComoFalla() throws Exception {
        armar(1);
        CountDownLatch dentro = new CountDownLatch(1);
        CountDownLatch soltar = new CountDownLatch(1);
        when(http.obtenerSaldo(116)).thenAnswer(invocacion -> {
            dentro.countDown();
            soltar.await(5, TimeUnit.SECONDS);
            return saldo();
        });
        ExecutorService pool = Executors.newSingleThreadExecutor();
        try {
            Future<SaldoCoreDto> lenta = pool.submit(() -> cliente.obtenerSaldo(116));
            assertThat(dentro.await(5, TimeUnit.SECONDS)).isTrue();

            // El unico lugar esta ocupado: la segunda llamada simultanea se rechaza sin esperar.
            assertThatThrownBy(() -> cliente.obtenerSaldo(116))
                    .isInstanceOf(CoreSaturadoException.class)
                    .isInstanceOf(CoreNoDisponibleException.class);

            soltar.countDown();
            assertThat(lenta.get(5, TimeUnit.SECONDS)).isEqualTo(saldo());
        } finally {
            soltar.countDown();
            pool.shutdownNow();
        }

        verify(http, times(1)).obtenerSaldo(116);
        assertThat(circuito().getMetrics().getNumberOfFailedCalls()).isZero();
        assertThat(circuito().getState()).isEqualTo(CircuitBreaker.State.CLOSED);
        assertThat(metricas.get(CoreClientResiliente.METRICA_RECHAZOS).tag("motivo", "mamparo_lleno")
                .counter().count()).isEqualTo(1.0);
    }

    @Test
    @DisplayName("Tras liberarse el lugar, el mamparo vuelve a aceptar llamadas")
    void elMamparoSeLibera() {
        armar(1);
        when(http.obtenerSaldo(116)).thenReturn(saldo());

        for (int i = 0; i < 10; i++) {
            assertThat(cliente.obtenerSaldo(116)).isEqualTo(saldo());
        }
        verify(http, never()).ejecutarRetiro(anyInt(), any(), any());
    }
}
