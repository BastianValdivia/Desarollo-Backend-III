package cl.duoc.bancoxyz.comun.core;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import com.sun.net.httpserver.HttpServer;

import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.oauth2.ClienteOAuth2ServicioConfig;
import cl.duoc.bancoxyz.comun.soporte.AuthServerSimulado;

/**
 * Comprueba que {@link RestCoreClient} llama al core por su NOMBRE LOGICO y no por una
 * direccion: {@code core.base-url} vale {@code http://core-service}, un host que no existe en
 * ninguna red, y aun asi la llamada llega a un servidor real.
 *
 * <p>El registro de instancias es el {@code SimpleDiscoveryClient} de Spring Cloud Commons, cuyas
 * instancias se declaran por propiedad. Es el mismo mecanismo de resolucion que usa Eureka en
 * ejecucion (el interceptor del balanceador pregunta al {@code DiscoveryClient}), pero sin
 * levantar ningun servidor: la prueba no depende de Eureka.
 *
 * <p>El "core" es un servidor HTTP minimo del propio JDK. Registra la cabecera {@code Authorization}
 * que recibe, para comprobar de paso que el balanceo conserva el token del servicio, que un auth-server
 * simulado entrega una sola vez.
 */
@SpringBootTest(
        classes = RestCoreClientBalanceadoTest.ConfiguracionDePrueba.class,
        webEnvironment = SpringBootTest.WebEnvironment.MOCK,
        properties = {
                "core.base-url=http://core-service",
                "core.timeout-conexion=1s",
                "core.timeout-lectura=2s",
                "spring.cloud.loadbalancer.cache.enabled=false"
        })
class RestCoreClientBalanceadoTest {

    private static final AtomicReference<String> CABECERA_RECIBIDA = new AtomicReference<>();
    private static HttpServer coreSimulado;
    private static AuthServerSimulado authServer;

    /** El simulador se levanta antes de que Spring lea las propiedades dinamicas. */
    @DynamicPropertySource
    static void registrarElCoreEnElRegistro(DynamicPropertyRegistry registro) throws IOException {
        authServer = AuthServerSimulado.iniciar(300);
        authServer.registrarCliente(registro, AuthServerSimulado.SECRETO);
        coreSimulado = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
        coreSimulado.createContext("/internal/v1/cuentas/116/saldo", intercambio -> {
            CABECERA_RECIBIDA.set(intercambio.getRequestHeaders().getFirst("Authorization"));
            byte[] cuerpo = "{\"cuentaId\":116,\"saldo\":1500.50,\"moneda\":\"CLP\"}"
                    .getBytes(StandardCharsets.UTF_8);
            intercambio.getResponseHeaders().add("Content-Type", "application/json");
            intercambio.sendResponseHeaders(200, cuerpo.length);
            intercambio.getResponseBody().write(cuerpo);
            intercambio.close();
        });
        coreSimulado.start();

        // "core-service" apunta al simulador.
        registro.add("spring.cloud.discovery.client.simple.instances.core-service[0].uri",
                () -> "http://127.0.0.1:" + coreSimulado.getAddress().getPort());
    }

    @AfterAll
    static void detenerElSimulador() {
        if (coreSimulado != null) {
            coreSimulado.stop(0);
        }
        if (authServer != null) {
            authServer.detener();
        }
    }

    @Autowired
    private RestCoreClient cliente;

    @Test
    @DisplayName("Resuelve el nombre logico core-service, adjunta el Bearer del servicio y lo reutiliza en las llamadas siguientes")
    void resuelveElNombreLogicoAdjuntaElTokenYLoReutiliza() {
        SaldoCoreDto saldo = cliente.obtenerSaldo(116);

        assertThat(saldo.cuentaId()).isEqualTo(116);
        assertThat(saldo.saldo()).isEqualByComparingTo("1500.50");
        assertThat(CABECERA_RECIBIDA.get()).isEqualTo("Bearer token-de-servicio-1");

        // Diez llamadas mas: el auth-server entrego un solo token en total (no uno por peticion).
        for (int i = 0; i < 10; i++) {
            cliente.obtenerSaldo(116);
        }
        assertThat(CABECERA_RECIBIDA.get()).isEqualTo("Bearer token-de-servicio-1");
        assertThat(authServer.tokensEntregados()).isEqualTo(1);
    }

    /**
     * Contexto minimo: autoconfiguracion de Boot (Jackson, RestClient, balanceador, registro
     * simple) mas las dos clases bajo prueba. No hay clase {@code @SpringBootApplication} en la
     * libreria, a proposito, asi que se arma aqui.
     */
    @Configuration(proxyBeanMethods = false)
    @EnableAutoConfiguration
    @EnableConfigurationProperties(CoreClientProperties.class)
    @Import({ClienteCoreBalanceadoConfig.class, ClienteOAuth2ServicioConfig.class, RestCoreClient.class})
    static class ConfiguracionDePrueba {
    }
}
