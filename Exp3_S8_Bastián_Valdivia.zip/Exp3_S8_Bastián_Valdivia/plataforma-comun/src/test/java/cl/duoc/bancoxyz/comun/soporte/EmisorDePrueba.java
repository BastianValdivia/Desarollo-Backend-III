package cl.duoc.bancoxyz.comun.soporte;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.security.oauth2.jose.jws.SignatureAlgorithm;
import org.springframework.security.oauth2.jwt.JwsHeader;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.security.oauth2.jwt.NimbusJwtEncoder;
import org.springframework.test.context.DynamicPropertyRegistry;

import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.sun.net.httpserver.HttpServer;

import cl.duoc.bancoxyz.comun.token.ClaimsToken;

/**
 * El {@code auth-server} de las pruebas de los BFF: una clave RSA de PRUEBA que firma tokens y un servidor HTTP
 * de loopback que publica su JWKS, para que el decodificador REAL de cada BFF (el que Spring Boot construye con
 * {@code jwk-set-uri}, {@code issuer-uri} y {@code audiences}) valide los tokens por el mismo camino que en
 * operacion. Lo unico que cambia respecto a produccion es la direccion del JWKS y la clave.
 *
 * <p><strong>Este es el unico lugar fuera del {@code auth-server} que firma tokens</strong>, y solo en pruebas:
 * ningun BFF emite nada (regla de F5, comprobada con {@code git grep JwtEncoder}).
 *
 * <p>Las plantillas ({@link #clienteWeb116()}, {@link #ejecutivoWeb()}, {@link #clienteMovil116}, {@link #tarjeta116()}...)
 * reproducen LOS CLAIMS que emite el auth-server para cada usuario de demostracion (mismos nombres, mismas
 * autoridades por canal, misma audiencia y misma vigencia), que fijan {@code LoginWebYMovilTest} y
 * {@code LoginCajeroTest} del auth-server contra la configuracion real. Cada plantilla se puede deformar con los
 * metodos del {@link Token}: otra audiencia, otro emisor, otra clave, vencido, sin un claim.
 *
 * <p>El servidor arranca una vez por JVM de pruebas ({@link #compartido()}) y las pruebas de un modulo
 * comparten la misma clave.
 */
public final class EmisorDePrueba {

    /** El emisor fijo del auth-server (decision D3). */
    public static final String EMISOR = "https://localhost:9000";

    private static EmisorDePrueba instancia;

    private final RSAKey claveDeFirma;
    private final HttpServer servidor;

    private EmisorDePrueba() {
        this.claveDeFirma = nuevaClave("clave-de-prueba");
        try {
            byte[] cuerpo = new JWKSet(claveDeFirma.toPublicJWK()).toString().getBytes(StandardCharsets.UTF_8);
            servidor = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
            servidor.createContext("/oauth2/jwks", intercambio -> {
                intercambio.getResponseHeaders().add("Content-Type", "application/json");
                intercambio.sendResponseHeaders(200, cuerpo.length);
                intercambio.getResponseBody().write(cuerpo);
                intercambio.close();
            });
            servidor.start();
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo iniciar el servidor de claves de prueba", e);
        }
    }

    public static synchronized EmisorDePrueba compartido() {
        if (instancia == null) {
            instancia = new EmisorDePrueba();
        }
        return instancia;
    }

    /**
     * Apunta el decodificador del BFF a este servidor. Se llama desde un {@code @DynamicPropertySource}; el emisor
     * y la audiencia vienen de {@code config-repo} (las pruebas leen los mismos archivos que sirve el config-server).
     */
    public static void registrar(DynamicPropertyRegistry registro) {
        EmisorDePrueba emisor = compartido();
        registro.add("spring.security.oauth2.resourceserver.jwt.jwk-set-uri", emisor::urlDeClaves);
        registro.add("spring.security.oauth2.resourceserver.jwt.issuer-uri", () -> EMISOR);
    }

    public String urlDeClaves() {
        return "http://127.0.0.1:" + servidor.getAddress().getPort() + "/oauth2/jwks";
    }

    /** Para pruebas que quieren dejar de publicar las claves (auth-server caido). */
    public void detener() {
        servidor.stop(0);
    }

    // ------------------------------------------------------------------ plantillas: lo que emite el auth-server

    private static final List<String> AUTORIDADES_CLIENTE_WEB =
            List.of("ROLE_CLIENTE_WEB", "PERM_cuenta:leer", "PERM_movimientos:leer", "PERM_resumen:leer");

    /** Usuario web con una cuenta y las autoridades de {@code cliente116} y {@code cliente105}. */
    public Token clienteWeb(String usuario, int cuenta) {
        return new Token(usuario).audiencia("bff-web").canal(ClaimsToken.CANAL_WEB).cuenta(cuenta)
                .autoridades(AUTORIDADES_CLIENTE_WEB).vigencia(Duration.ofMinutes(30)).clienteOAuth("web-app");
    }

    public Token clienteWeb116() {
        return clienteWeb("cliente116", 116);
    }

    public Token clienteWeb105() {
        return clienteWeb("cliente105", 105);
    }

    /** El ejecutivo: rol y permiso de auditoria, y NINGUN claim de cuenta. */
    public Token ejecutivoWeb() {
        return new Token("ejecutivo1").audiencia("bff-web").canal(ClaimsToken.CANAL_WEB)
                .autoridades(List.of("ROLE_EJECUTIVO", "PERM_auditoria:leer"))
                .vigencia(Duration.ofMinutes(30)).clienteOAuth("web-app");
    }

    /** {@code cliente116} en el canal movil, atado a un dispositivo (claim {@code device_id}). */
    public Token clienteMovil116(String dispositivo) {
        return clienteMovil("cliente116", 116, dispositivo);
    }

    /** Un cliente movil de la cuenta indicada (por ejemplo para probar que la 105 no ve la 116). */
    public Token clienteMovil(String usuario, int cuenta, String dispositivo) {
        return new Token(usuario).audiencia("bff-mobile").canal(ClaimsToken.CANAL_MOVIL).cuenta(cuenta)
                .autoridades(List.of("ROLE_CLIENTE_MOVIL", "PERM_saldo:leer", "PERM_dispositivo:gestionar"))
                .dispositivo(dispositivo).vigencia(Duration.ofMinutes(60)).clienteOAuth("mobile-app");
    }

    /** Una tarjeta del cajero autenticada por el terminal {@code ATM-SCL-001}. */
    public Token tarjeta(String numeroEnmascarado, int cuenta, boolean puedeRetirar) {
        List<String> autoridades = puedeRetirar
                ? List.of("ROLE_CLIENTE_ATM", "PERM_saldo:leer", "PERM_retiro:ejecutar")
                : List.of("ROLE_CLIENTE_ATM", "PERM_saldo:leer");
        return new Token(numeroEnmascarado).audiencia("bff-atm").canal(ClaimsToken.CANAL_ATM).cuenta(cuenta)
                .autoridades(autoridades).terminal("ATM-SCL-001").vigencia(Duration.ofMinutes(3)).clienteOAuth("atm-scl-001");
    }

    /** Tarjeta 116 (cuenta 116, con permiso de retiro). */
    public Token tarjeta116() {
        return tarjeta("400000******0116", 116, true);
    }

    /** Tarjeta 105 (cuenta 105, SIN permiso de retiro). */
    public Token tarjeta105() {
        return tarjeta("400000******0105", 105, false);
    }

    private static RSAKey nuevaClave(String id) {
        try {
            KeyPairGenerator generador = KeyPairGenerator.getInstance("RSA");
            generador.initialize(2048);
            KeyPair par = generador.generateKeyPair();
            return new RSAKey.Builder((RSAPublicKey) par.getPublic())
                    .privateKey((RSAPrivateKey) par.getPrivate())
                    .keyID(id)
                    .build();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Un token en construccion. Cada metodo devuelve el mismo objeto para encadenar. */
    public final class Token {
        private final String sujeto;
        private List<String> audiencia = List.of();
        private String emisor = EMISOR;
        private Instant emision = Instant.now().minusSeconds(5);
        private Duration vigencia = Duration.ofMinutes(5);
        private RSAKey clave = claveDeFirma;
        private final Map<String, Object> claims = new LinkedHashMap<>();

        private Token(String sujeto) {
            this.sujeto = sujeto;
        }

        public Token audiencia(String... audiencias) {
            this.audiencia = List.of(audiencias);
            return this;
        }

        private Token canal(String canal) {
            claims.put(ClaimsToken.CANAL, canal);
            return this;
        }

        private Token cuenta(int cuenta) {
            claims.put(ClaimsToken.CUENTA_ID, cuenta);
            return this;
        }

        private Token autoridades(List<String> autoridades) {
            claims.put(ClaimsToken.AUTORIDADES, autoridades);
            return this;
        }

        private Token dispositivo(String dispositivo) {
            claims.put(ClaimsToken.DEVICE_ID, dispositivo);
            return this;
        }

        private Token terminal(String terminal) {
            claims.put(ClaimsToken.TERMINAL, terminal);
            return this;
        }

        private Token clienteOAuth(String cliente) {
            claims.put("client_id", cliente);
            return this;
        }

        private Token vigencia(Duration vigencia) {
            this.vigencia = vigencia;
            return this;
        }

        /** Reemplaza o agrega un claim cualquiera. */
        public Token claim(String nombre, Object valor) {
            claims.put(nombre, valor);
            return this;
        }

        /** Quita un claim (por ejemplo {@code terminal} o {@code device_id}). */
        public Token sin(String nombre) {
            claims.remove(nombre);
            return this;
        }

        public Token conEmisor(String emisor) {
            this.emisor = emisor;
            return this;
        }

        /** Ya vencido hace 10 minutos (con holgura de sobra sobre cualquier tolerancia de reloj). */
        public Token vencido() {
            this.emision = Instant.now().minusSeconds(900);
            this.vigencia = Duration.ofSeconds(300);
            return this;
        }

        /** Vence en {@code segundos} segundos a partir de AHORA (para probar la tolerancia de reloj). */
        public Token venceEn(long segundos) {
            this.emision = Instant.now().minusSeconds(60);
            this.vigencia = Duration.ofSeconds(60 + segundos);
            return this;
        }

        /** Firmado con una clave que el servidor de claves NO publica (mismo {@code kid}). */
        public Token firmadoPorOtraClave() {
            this.clave = nuevaClave(claveDeFirma.getKeyID());
            return this;
        }

        public String emitir() {
            NimbusJwtEncoder codificador = new NimbusJwtEncoder(new ImmutableJWKSet<>(new JWKSet(clave)));
            JwtClaimsSet.Builder constructor = JwtClaimsSet.builder()
                    .issuer(emisor)
                    .subject(sujeto)
                    .audience(audiencia)
                    .issuedAt(emision)
                    .expiresAt(emision.plus(vigencia))
                    .id(UUID.randomUUID().toString());
            claims.forEach(constructor::claim);
            JwsHeader cabecera = JwsHeader.with(SignatureAlgorithm.RS256).keyId(clave.getKeyID()).build();
            return codificador.encode(JwtEncoderParameters.from(cabecera, constructor.build())).getTokenValue();
        }

        /** El mismo contenido con algoritmo {@code none}: sin firma. Un decodificador correcto lo rechaza. */
        public String emitirSinFirma() {
            String[] partes = emitir().split("\\.");
            String cabecera = Base64.getUrlEncoder().withoutPadding()
                    .encodeToString("{\"alg\":\"none\"}".getBytes(StandardCharsets.UTF_8));
            return cabecera + "." + partes[1] + ".";
        }
    }
}
