package cl.duoc.bancoxyz.comun.resiliencia;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Duration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@DisplayName("AvisoDatosDesactualizados: las cabeceras de la respuesta de respaldo")
class AvisoDatosDesactualizadosTest {

    @RestController
    static class ControladorDePrueba {
        @GetMapping("/fresco")
        java.util.Map<String, Object> fresco() {
            return java.util.Map.of("saldo", 1500);
        }

        @GetMapping("/viejo")
        java.util.Map<String, Object> viejo() {
            DatosDesactualizados.marcar(Duration.ofSeconds(42));
            return java.util.Map.of("saldo", 1500);
        }

        /** Como el controlador movil: pone su propio Cache-Control con ResponseEntity. */
        @GetMapping("/viejo-con-cache-control")
        ResponseEntity<java.util.Map<String, Object>> viejoConCacheControl() {
            DatosDesactualizados.marcar(Duration.ofSeconds(7));
            return ResponseEntity.ok().cacheControl(CacheControl.noCache().cachePrivate())
                    .body(java.util.Map.of("saldo", 1500));
        }
    }

    private MockMvc mvc;

    @BeforeEach
    void armar() {
        mvc = MockMvcBuilders.standaloneSetup(new ControladorDePrueba())
                .setControllerAdvice(new AvisoDatosDesactualizados()).build();
    }

    @Test
    @DisplayName("Una respuesta con datos frescos no lleva ninguna cabecera de advertencia")
    void elDatoFrescoNoLlevaAdvertencia() throws Exception {
        mvc.perform(get("/fresco"))
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist(AvisoDatosDesactualizados.CABECERA_DESACTUALIZADO))
                .andExpect(header().doesNotExist("Warning"));
    }

    @Test
    @DisplayName("Una respuesta de respaldo lleva las cuatro cabeceras y el cuerpo intacto")
    void elRespaldoLlevaCabeceras() throws Exception {
        mvc.perform(get("/viejo"))
                .andExpect(status().isOk())
                .andExpect(header().string(AvisoDatosDesactualizados.CABECERA_DESACTUALIZADO, "true"))
                .andExpect(header().string(AvisoDatosDesactualizados.CABECERA_ANTIGUEDAD, "42"))
                .andExpect(header().string("Warning", "110 - \"Response is Stale\""))
                .andExpect(header().string("Cache-Control", "no-store"))
                .andExpect(jsonPath("$.saldo").value(1500));
    }

    @Test
    @DisplayName("Reemplaza el Cache-Control del controlador: el telefono no debe guardar ni revalidar el saldo viejo")
    void reemplazaElCacheControlDelControlador() throws Exception {
        mvc.perform(get("/viejo-con-cache-control"))
                .andExpect(header().stringValues("Cache-Control", "no-store"))
                .andExpect(header().string(AvisoDatosDesactualizados.CABECERA_ANTIGUEDAD, "7"));
    }
}
