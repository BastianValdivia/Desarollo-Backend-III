package cl.duoc.bancoxyz.comun.oauth2;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;
import java.net.URI;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.mock.http.client.MockClientHttpRequest;
import org.springframework.mock.http.client.MockClientHttpResponse;
import org.springframework.security.oauth2.client.AuthorizedClientServiceOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.ClientAuthorizationException;
import org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.endpoint.OAuth2AccessTokenResponse;

/**
 * El comportamiento del {@link TokenServicioInterceptor} que importa para el sistema: el token se pide
 * una vez y se reutiliza, se renueva antes de vencer (con un solo hilo hablando con el auth-server) y
 * un fallo del auth-server sale como {@link IOException} sin filtrar el secreto.
 *
 * <p>Usa el gestor real de Spring Security con un cliente de tokens falso que cuenta las peticiones, y
 * un reloj controlado, de modo que "vencer" no cuesta minutos de espera.
 */
class TokenServicioInterceptorTest {

    private static final String REGISTRO = "servicios-internos";
    private static final Duration VIGENCIA = Duration.ofMinutes(5);
    private static final Duration RENOVAR_ANTES = Duration.ofSeconds(30);

    /**
     * Un reloj que avanza cuando la prueba lo dice: la hora real mas un desfase. Se hace asi, y no con
     * un instante fijo, porque Spring Security fija el instante de emision del token con el reloj del
     * sistema y el vencimiento que se compara contra este reloj sale de ahi.
     */
    private static final class RelojControlado extends Clock {
        private final AtomicReference<Duration> desfase = new AtomicReference<>(Duration.ZERO);

        void avanzar(Duration duracion) {
            desfase.updateAndGet(d -> d.plus(duracion));
        }

        /** Lo que ya "paso" de mas respecto al reloj real: un token pedido ahora debe vencer a su vigencia desde ESTE reloj. */
        Duration desfase() {
            return desfase.get();
        }

        @Override
        public ZoneId getZone() {
            return ZoneOffset.UTC;
        }

        @Override
        public Clock withZone(ZoneId zona) {
            return this;
        }

        @Override
        public Instant instant() {
            return Instant.now().plus(desfase.get());
        }
    }

    /** El montaje completo: gestor real, auth-server falso y reloj controlado. */
    private static final class Montaje {
        final RelojControlado reloj = new RelojControlado();
        final AtomicInteger tokensPedidos = new AtomicInteger();
        /** Cuantas veces se llego al "auth-server", con exito o sin el. Con el circuito abierto no crece. */
        final AtomicInteger intentos = new AtomicInteger();
        final AtomicReference<RuntimeException> falla = new AtomicReference<>();
        /** Una falla que ocurre UNA sola vez (la primera llamada) y luego desaparece: una caida pasajera. */
        final AtomicReference<RuntimeException> fallaUnica = new AtomicReference<>();
        final InMemoryOAuth2AuthorizedClientService almacen;
        final TokenServicioInterceptor interceptor;

        Montaje() {
            this(null, null);
        }

        Montaje(CircuitBreaker circuito, Retry reintento) {
            ClientRegistration registro = ClientRegistration.withRegistrationId(REGISTRO)
                    .clientId("bff-de-prueba").clientSecret("secreto-que-no-debe-salir-en-ningun-mensaje")
                    .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                    .tokenUri("http://auth-server.invalido/oauth2/token")
                    .scope("cuentas:leer").build();
            InMemoryClientRegistrationRepository registros = new InMemoryClientRegistrationRepository(registro);
            almacen = new InMemoryOAuth2AuthorizedClientService(registros);
            var gestor = new AuthorizedClientServiceOAuth2AuthorizedClientManager(registros, almacen);
            gestor.setAuthorizedClientProvider(OAuth2AuthorizedClientProviderBuilder.builder()
                    .clientCredentials(grant -> {
                        grant.accessTokenResponseClient(peticion -> {
                            intentos.incrementAndGet();
                            RuntimeException pasajera = fallaUnica.getAndSet(null);
                            if (pasajera != null) {
                                throw pasajera;
                            }
                            if (falla.get() != null) {
                                throw falla.get();
                            }
                            int numero = tokensPedidos.incrementAndGet();
                            return OAuth2AccessTokenResponse.withToken("token-" + numero)
                                    .tokenType(OAuth2AccessToken.TokenType.BEARER)
                                    .expiresIn(VIGENCIA.plus(reloj.desfase()).toSeconds())
                                    .scopes(java.util.Set.of("cuentas:leer")).build();
                        });
                        grant.clockSkew(RENOVAR_ANTES);
                        grant.clock(reloj);
                    }).build());
            interceptor = new TokenServicioInterceptor(gestor, almacen, REGISTRO, RENOVAR_ANTES, reloj,
                    circuito, reintento);
        }

        /** Hace una llamada y devuelve el valor de la cabecera Authorization que habria viajado. */
        String llamar() throws IOException {
            return llamar(HttpStatus.OK);
        }

        String llamar(HttpStatus respuestaDelDestino) throws IOException {
            MockClientHttpRequest peticion = new MockClientHttpRequest(HttpMethod.GET, URI.create("http://core-service/x"));
            ClientHttpRequestExecution ejecucion = (p, cuerpo) -> new MockClientHttpResponse(new byte[0], respuestaDelDestino);
            interceptor.intercept(peticion, new byte[0], ejecucion);
            return peticion.getHeaders().getFirst("Authorization");
        }
    }

    @Test
    @DisplayName("Cincuenta llamadas seguidas piden un solo token y todas llevan el mismo Bearer")
    void elTokenSeReutiliza() throws Exception {
        Montaje m = new Montaje();

        for (int i = 0; i < 50; i++) {
            assertThat(m.llamar()).isEqualTo("Bearer token-1");
        }

        assertThat(m.tokensPedidos.get()).isEqualTo(1);
        assertThat(m.interceptor.obtenciones()).isEqualTo(1);
    }

    @Test
    @DisplayName("Mientras falta mas que el margen para vencer no se renueva; dentro del margen, si")
    void seRenuevaAntesDeVencer() throws Exception {
        Montaje m = new Montaje();
        assertThat(m.llamar()).isEqualTo("Bearer token-1");

        // A 4 min 20 s de 5 min quedan 40 s: fuera del margen de 30 s.
        m.reloj.avanzar(Duration.ofSeconds(260));
        assertThat(m.llamar()).isEqualTo("Bearer token-1");
        assertThat(m.tokensPedidos.get()).isEqualTo(1);

        // A 4 min 40 s quedan 20 s: dentro del margen. El token viejo todavia no vencio, y aun asi se cambia.
        m.reloj.avanzar(Duration.ofSeconds(20));
        assertThat(m.llamar()).isEqualTo("Bearer token-2");
        assertThat(m.llamar()).isEqualTo("Bearer token-2");
        assertThat(m.tokensPedidos.get()).isEqualTo(2);
    }

    @Test
    @DisplayName("Con 32 hilos llegando a la vez justo en el margen de renovacion, solo uno habla con el auth-server")
    void unSoloHiloRenueva() throws Exception {
        Montaje m = new Montaje();
        m.llamar();
        m.reloj.avanzar(Duration.ofSeconds(280));

        int hilos = 32;
        ExecutorService pool = Executors.newFixedThreadPool(hilos);
        CountDownLatch salida = new CountDownLatch(1);
        List<Future<String>> resultados = new ArrayList<>();
        for (int i = 0; i < hilos; i++) {
            resultados.add(pool.submit(() -> {
                salida.await();
                return m.llamar();
            }));
        }
        salida.countDown();
        for (Future<String> r : resultados) {
            assertThat(r.get()).isEqualTo("Bearer token-2");
        }
        pool.shutdown();

        assertThat(m.tokensPedidos.get()).as("el primero y una sola renovacion").isEqualTo(2);
    }

    @Test
    @DisplayName("Si el auth-server rechaza al cliente, la llamada falla con IOException y el mensaje no trae el secreto")
    void unFalloDelAuthServerSaleComoIOException() {
        Montaje m = new Montaje();
        m.falla.set(new ClientAuthorizationException(new OAuth2Error("invalid_client"), REGISTRO));

        assertThatThrownBy(m::llamar)
                .isInstanceOf(IOException.class)
                .hasMessageContaining("invalid_client")
                .hasMessageNotContaining("secreto-que-no-debe-salir");
        assertThat(m.interceptor.obtenciones()).isZero();
    }

    @Test
    @DisplayName("Tras un fallo del auth-server, la siguiente llamada vuelve a intentarlo y funciona")
    void seRecuperaCuandoElAuthServerVuelve() throws Exception {
        Montaje m = new Montaje();
        m.falla.set(new ClientAuthorizationException(new OAuth2Error("server_error"), REGISTRO));
        assertThatThrownBy(m::llamar).isInstanceOf(IOException.class);

        m.falla.set(null);

        assertThat(m.llamar()).isEqualTo("Bearer token-1");
    }

    @Test
    @DisplayName("Con el token vigente en memoria, una caida del auth-server no se nota")
    void unTokenVigenteSobreviveALaCaidaDelAuthServer() throws Exception {
        Montaje m = new Montaje();
        m.llamar();
        m.falla.set(new ClientAuthorizationException(new OAuth2Error("server_error"), REGISTRO));

        assertThat(m.llamar()).isEqualTo("Bearer token-1");
    }

    @Test
    @DisplayName("Si el destino responde 401, se descarta el token y la siguiente llamada pide uno nuevo")
    void unRechazo401DescartaElToken() throws Exception {
        Montaje m = new Montaje();
        assertThat(m.llamar(HttpStatus.UNAUTHORIZED)).isEqualTo("Bearer token-1");

        assertThat(m.llamar()).isEqualTo("Bearer token-2");
        assertThat(m.tokensPedidos.get()).isEqualTo(2);
    }

    /** Circuito y reintento con los criterios de config-repo (solo cuenta TokenServicioNoDisponibleException), ventana chica. */
    private static CircuitBreaker circuito() {
        return circuito(2);
    }

    private static CircuitBreaker circuito(int llamadasMinimas) {
        return CircuitBreaker.of("auth-server-prueba", CircuitBreakerConfig.custom()
                .slidingWindowSize(Math.max(4, llamadasMinimas)).minimumNumberOfCalls(llamadasMinimas)
                .failureRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(30))
                .recordExceptions(TokenServicioNoDisponibleException.class).build());
    }

    private static Retry reintento() {
        return Retry.of("auth-server-prueba", RetryConfig.custom().maxAttempts(2)
                .waitDuration(Duration.ofMillis(1)).retryExceptions(TokenServicioNoDisponibleException.class).build());
    }

    @Test
    @DisplayName("Dentro del margen de renovacion y con el auth-server caido se sigue usando el token vigente")
    void enElMargenDeRenovacionElTokenVigenteSigueSirviendo() throws Exception {
        Montaje m = new Montaje(circuito(), reintento());
        assertThat(m.llamar()).isEqualTo("Bearer token-1");

        // A 4 min 40 s quedan 20 s: el interceptor quiere renovar, pero el auth-server cayo. El token
        // sigue siendo valido para el core, asi que NO se corta el servicio.
        m.reloj.avanzar(Duration.ofSeconds(280));
        m.falla.set(new ClientAuthorizationException(new OAuth2Error("server_error"), REGISTRO));

        assertThat(m.llamar()).isEqualTo("Bearer token-1");
        assertThat(m.llamar()).isEqualTo("Bearer token-1");
        assertThat(m.interceptor.obtenciones()).isEqualTo(1);
    }

    @Test
    @DisplayName("Con el token ya vencido y el auth-server caido: IOException controlada (el canal responde 503)")
    void conElTokenVencidoSinAuthServerFalla() throws Exception {
        // Circuito que tarda en abrir (10 llamadas minimas): aqui se prueba el 503 por falta de token, no el circuito.
        Montaje m = new Montaje(circuito(10), reintento());
        m.llamar();
        m.reloj.avanzar(Duration.ofSeconds(301));
        m.falla.set(new ClientAuthorizationException(new OAuth2Error("server_error"), REGISTRO));

        assertThatThrownBy(m::llamar)
                .isInstanceOf(IOException.class)
                .hasMessageContaining("server_error")
                .hasMessageNotContaining("secreto-que-no-debe-salir");

        // Cuando el auth-server vuelve, todo se recupera solo (con el circuito cerrado todavia).
        m.falla.set(null);
        assertThat(m.llamar()).isEqualTo("Bearer token-2");
    }

    @Test
    @DisplayName("La obtencion del token se reintenta: una falla pasajera del auth-server no se nota")
    void unaFallaPasajeraSeReintenta() throws Exception {
        Montaje m = new Montaje(circuito(), reintento());
        m.fallaUnica.set(new ClientAuthorizationException(new OAuth2Error("server_error"), REGISTRO));

        assertThat(m.llamar()).isEqualTo("Bearer token-1");
        assertThat(m.intentos.get()).isEqualTo(2);
    }

    @Test
    @DisplayName("Con el auth-server caido el circuito se abre y deja de llamarlo; un rechazo de credenciales no lo abre")
    void elCircuitoDelAuthServerSeAbreSoloPorFallasDeInfraestructura() throws Exception {
        CircuitBreaker circuito = circuito();
        Montaje m = new Montaje(circuito, reintento());
        m.falla.set(new ClientAuthorizationException(new OAuth2Error("server_error"), REGISTRO));

        // Cada llamada sin token gasta 2 intentos; con minimumNumberOfCalls=2 el circuito abre en la primera.
        assertThatThrownBy(m::llamar).isInstanceOf(IOException.class);
        assertThat(circuito.getState()).isEqualTo(CircuitBreaker.State.OPEN);
        int intentosAlAbrir = m.intentos.get();

        assertThatThrownBy(m::llamar).isInstanceOf(IOException.class).hasMessageContaining("circuito");
        assertThat(m.intentos.get()).as("con el circuito abierto no se llama al auth-server").isEqualTo(intentosAlAbrir);

        // Un secreto mal puesto (invalid_client) NO es una falla de infraestructura: no abre el circuito.
        CircuitBreaker otro = circuito();
        Montaje credencialMala = new Montaje(otro, reintento());
        credencialMala.falla.set(new ClientAuthorizationException(new OAuth2Error("invalid_client"), REGISTRO));
        for (int i = 0; i < 10; i++) {
            assertThatThrownBy(credencialMala::llamar).isInstanceOf(IOException.class)
                    .hasMessageContaining("invalid_client");
        }
        assertThat(otro.getState()).isEqualTo(CircuitBreaker.State.CLOSED);
        assertThat(credencialMala.intentos.get()).as("sin reintentos para un rechazo de credenciales").isEqualTo(10);
    }
}
