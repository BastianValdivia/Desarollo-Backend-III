package cl.duoc.bancoxyz.comun.core;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto;
import cl.duoc.bancoxyz.comun.oauth2.ClienteOAuth2ServicioConfig;
import cl.duoc.bancoxyz.comun.soporte.AuthServerSimulado;

/**
 * La traduccion de los 422 del core a excepciones con nombre: la clave de idempotencia reutilizada se
 * distingue de cualquier otro 422, que sigue siendo "respuesta inesperada".
 *
 * <p>Usa el mismo armado que {@link RestCoreClientBalanceadoTest} (un core simulado con el servidor
 * HTTP del JDK registrado en el descubrimiento simple), porque lo que se prueba es la traduccion que
 * ocurre al leer una respuesta real.
 */
@SpringBootTest(
        classes = RestCoreClientErroresTest.ConfiguracionDePrueba.class,
        webEnvironment = SpringBootTest.WebEnvironment.MOCK,
        properties = {
                "core.base-url=http://core-service",
                "core.timeout-conexion=1s",
                "core.timeout-lectura=2s",
                "spring.cloud.loadbalancer.cache.enabled=false"
        })
class RestCoreClientErroresTest {

    private static HttpServer coreSimulado;
    private static AuthServerSimulado authServer;

    @DynamicPropertySource
    static void registrarElCoreEnElRegistro(DynamicPropertyRegistry registro) throws IOException {
        authServer = AuthServerSimulado.iniciar(300);
        authServer.registrarCliente(registro, AuthServerSimulado.SECRETO);
        coreSimulado = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
        // Cuenta 116: el core dice que la clave se reutilizo con otro importe.
        coreSimulado.createContext("/internal/v1/cuentas/116/retiros", intercambio -> responder(intercambio,
                "{\"status\":422,\"motivo\":\"clave_idempotencia_reutilizada\"}"));
        // Cuenta 117: un 422 de otra naturaleza, que este cliente no conoce.
        coreSimulado.createContext("/internal/v1/cuentas/117/retiros", intercambio -> responder(intercambio,
                "{\"status\":422,\"motivo\":\"otra_regla_del_core\"}"));
        coreSimulado.start();
        registro.add("spring.cloud.discovery.client.simple.instances.core-service[0].uri",
                () -> "http://127.0.0.1:" + coreSimulado.getAddress().getPort());
    }

    private static void responder(HttpExchange intercambio, String json) throws IOException {
        byte[] cuerpo = json.getBytes(StandardCharsets.UTF_8);
        intercambio.getResponseHeaders().add("Content-Type", "application/problem+json");
        intercambio.sendResponseHeaders(422, cuerpo.length);
        intercambio.getResponseBody().write(cuerpo);
        intercambio.close();
    }

    @AfterAll
    static void detenerElSimulador() {
        if (coreSimulado != null) {
            coreSimulado.stop(0);
        }
        if (authServer != null) {
            authServer.detener();
        }
    }

    @Autowired
    private RestCoreClient cliente;

    @Test
    @DisplayName("422 clave_idempotencia_reutilizada se traduce a su excepcion propia, no a un fallo del core")
    void claveReutilizada() {
        assertThatThrownBy(() -> cliente.ejecutarRetiro(116, new SolicitudRetiroCoreDto(new BigDecimal("3000")), "clave-x"))
                .isInstanceOf(CoreClaveIdempotenciaReutilizadaException.class)
                .satisfies(e -> org.assertj.core.api.Assertions.assertThat(((CoreException) e).estadoDelCore())
                        .isEqualTo(422));
    }

    @Test
    @DisplayName("Un 422 con otro motivo sigue siendo respuesta inesperada: no se adivina")
    void otro422NoSeAdivina() {
        assertThatThrownBy(() -> cliente.ejecutarRetiro(117, new SolicitudRetiroCoreDto(new BigDecimal("3000")), "clave-y"))
                .isInstanceOf(CoreRespuestaInesperadaException.class);
    }

    @Configuration(proxyBeanMethods = false)
    @EnableAutoConfiguration
    @EnableConfigurationProperties(CoreClientProperties.class)
    @Import({ClienteCoreBalanceadoConfig.class, ClienteOAuth2ServicioConfig.class, RestCoreClient.class})
    static class ConfiguracionDePrueba {
    }
}
