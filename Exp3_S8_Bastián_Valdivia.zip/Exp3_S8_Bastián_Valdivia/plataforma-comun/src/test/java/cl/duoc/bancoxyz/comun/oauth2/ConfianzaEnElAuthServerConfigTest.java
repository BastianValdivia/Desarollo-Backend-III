package cl.duoc.bancoxyz.comun.oauth2;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.security.oauth2.resource.servlet.JwkSetUriJwtDecoderBuilderCustomizer;
import org.springframework.boot.ssl.DefaultSslBundleRegistry;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.test.util.ReflectionTestUtils;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.sun.net.httpserver.HttpServer;

/**
 * Las claves publicas del auth-server se descargan UNA vez y se conservan: una caida del auth-server no hace
 * esperar a cada peticion el timeout de la descarga ni impide validar tokens de claves ya conocidas.
 *
 * <p>Nacio de una medicion (scripts/caos/auth-server-caido.sh): con el auth-server detenido, al cumplirse 5
 * minutos del JWKS descargado Spring Security volvia a descargarlo antes de validar cada token, y cada peticion al
 * core esperaba 2 s.
 */
@DisplayName("Claves del auth-server: descarga unica, sin vencimiento")
class ConfianzaEnElAuthServerConfigTest {

    private static JwkSetUriJwtDecoderBuilderCustomizer personalizador() {
        return new ConfianzaEnElAuthServerConfig().descargaDeClavesConLaCaInterna(
                new DefaultSslBundleRegistry(), Duration.ofSeconds(1), Duration.ofSeconds(1));
    }

    @Test
    @DisplayName("El constructor del decodificador recibe una cache de Spring sin vencimiento")
    void laCacheDeClavesNoVence() {
        NimbusJwtDecoder.JwkSetUriJwtDecoderBuilder constructor = NimbusJwtDecoder.withJwkSetUri("http://127.0.0.1:1/jwks");

        personalizador().customize(constructor);

        assertThat(ReflectionTestUtils.getField(constructor, "cache")).isInstanceOf(ConcurrentMapCache.class);
    }

    @Test
    @DisplayName("Tras descargar las claves una vez, con el servidor de claves caido se siguen validando tokens (y no se vuelve a descargar)")
    void conElServidorCaidoSigueValidando() throws Exception {
        RSAKey clave = new RSAKeyGenerator(2048).keyID("clave-1").generate();
        AtomicInteger descargas = new AtomicInteger();
        HttpServer servidor = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
        servidor.createContext("/oauth2/jwks", intercambio -> {
            descargas.incrementAndGet();
            byte[] cuerpo = new JWKSet(clave.toPublicJWK()).toString().getBytes(StandardCharsets.UTF_8);
            intercambio.getResponseHeaders().add("Content-Type", "application/json");
            intercambio.sendResponseHeaders(200, cuerpo.length);
            intercambio.getResponseBody().write(cuerpo);
            intercambio.close();
        });
        servidor.start();
        int puerto = servidor.getAddress().getPort();

        NimbusJwtDecoder.JwkSetUriJwtDecoderBuilder constructor =
                NimbusJwtDecoder.withJwkSetUri("http://127.0.0.1:" + puerto + "/oauth2/jwks");
        personalizador().customize(constructor);
        NimbusJwtDecoder decodificador = constructor.build();

        Jwt primero = decodificador.decode(tokenFirmadoCon(clave));
        assertThat(primero.getSubject()).isEqualTo("cliente116");
        assertThat(descargas.get()).isEqualTo(1);

        servidor.stop(0); // el auth-server cae
        Jwt segundo = decodificador.decode(tokenFirmadoCon(clave));
        assertThat(segundo.getSubject()).isEqualTo("cliente116");
        assertThat(descargas.get()).as("no se vuelve a descargar mientras el kid sea conocido").isEqualTo(1);
    }

    private static String tokenFirmadoCon(RSAKey clave) throws Exception {
        SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.RS256).keyID(clave.getKeyID()).build(),
                new JWTClaimsSet.Builder().subject("cliente116")
                        .expirationTime(new Date(System.currentTimeMillis() + 60_000)).build());
        jwt.sign(new RSASSASigner(clave));
        return jwt.serialize();
    }
}
