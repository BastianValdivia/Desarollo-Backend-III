package cl.duoc.bancoxyz.comun.soporte;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.test.context.DynamicPropertyRegistry;

import com.sun.net.httpserver.HttpServer;

/**
 * Un auth-server minimo para las pruebas de la libreria: solo el endpoint de tokens de
 * {@code client_credentials}, con el servidor HTTP del propio JDK.
 *
 * <p>Comprueba lo que un servidor real comprueba (cliente y secreto por {@code client_secret_basic} y el
 * grant pedido) y entrega un token distinto en cada respuesta ({@code token-de-servicio-1},
 * {@code token-de-servicio-2}...), de modo que una prueba ve cuantas veces se le pidio uno y cual llego a
 * su destino. No firma nada: el core simulado de estas pruebas no valida la firma.
 */
public final class AuthServerSimulado {

    public static final String CLIENTE = "bff-de-prueba";
    public static final String SECRETO = "secreto-solo-para-pruebas";

    private final HttpServer servidor;
    private final AtomicInteger peticiones = new AtomicInteger();

    private AuthServerSimulado(HttpServer servidor) {
        this.servidor = servidor;
    }

    /** Arranca el simulador en un puerto libre del bucle local. */
    public static AuthServerSimulado iniciar(int vigenciaSegundos) throws IOException {
        HttpServer http = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
        AuthServerSimulado simulado = new AuthServerSimulado(http);
        String esperado = "Basic " + Base64.getEncoder()
                .encodeToString((CLIENTE + ":" + SECRETO).getBytes(StandardCharsets.UTF_8));
        http.createContext("/oauth2/token", intercambio -> {
            String autorizacion = intercambio.getRequestHeaders().getFirst("Authorization");
            String cuerpoPedido = new String(intercambio.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            byte[] respuesta;
            int estado;
            if (!esperado.equals(autorizacion)) {
                estado = 401;
                respuesta = "{\"error\":\"invalid_client\"}".getBytes(StandardCharsets.UTF_8);
            } else if (!cuerpoPedido.contains("grant_type=client_credentials")) {
                estado = 400;
                respuesta = "{\"error\":\"unsupported_grant_type\"}".getBytes(StandardCharsets.UTF_8);
            } else {
                int numero = simulado.peticiones.incrementAndGet();
                estado = 200;
                respuesta = ("{\"access_token\":\"token-de-servicio-" + numero + "\",\"token_type\":\"Bearer\","
                        + "\"expires_in\":" + vigenciaSegundos + ",\"scope\":\"cuentas:leer\"}")
                        .getBytes(StandardCharsets.UTF_8);
            }
            intercambio.getResponseHeaders().add("Content-Type", "application/json");
            intercambio.sendResponseHeaders(estado, respuesta.length);
            intercambio.getResponseBody().write(respuesta);
            intercambio.close();
        });
        http.start();
        return simulado;
    }

    /** Cuantos tokens entrego (solo cuenta las peticiones validas). */
    public int tokensEntregados() {
        return peticiones.get();
    }

    public String urlDeTokens() {
        return "http://127.0.0.1:" + servidor.getAddress().getPort() + "/oauth2/token";
    }

    /** Declara el registro {@code servicios-internos} apuntando a este simulador. */
    public void registrarCliente(DynamicPropertyRegistry registro, String secreto) {
        String r = "spring.security.oauth2.client.registration.servicios-internos.";
        registro.add(r + "client-id", () -> CLIENTE);
        registro.add(r + "client-secret", () -> secreto);
        registro.add(r + "authorization-grant-type", () -> "client_credentials");
        registro.add(r + "client-authentication-method", () -> "client_secret_basic");
        registro.add(r + "scope", () -> "cuentas:leer");
        registro.add("spring.security.oauth2.client.provider.servicios-internos.token-uri", this::urlDeTokens);
    }

    public void detener() {
        servidor.stop(0);
    }
}
