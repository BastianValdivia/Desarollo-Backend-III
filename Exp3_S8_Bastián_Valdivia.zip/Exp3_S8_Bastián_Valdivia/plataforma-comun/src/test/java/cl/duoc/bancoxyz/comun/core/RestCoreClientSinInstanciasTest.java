package cl.duoc.bancoxyz.comun.core;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.comun.oauth2.ClienteOAuth2ServicioConfig;
import cl.duoc.bancoxyz.comun.soporte.AuthServerSimulado;

/**
 * Comprueba el caso en que Eureka no tiene ninguna instancia de {@code core-service} (el core no
 * arranco, murio y su arriendo vencio, o aun no se registro).
 *
 * <p>Sin balanceador, un core caido producia un error de conexion que {@link RestCoreClient}
 * traducia a {@link CoreNoDisponibleException}, que cada BFF convierte en 503
 * {@code core_no_disponible}. Con balanceador el fallo cambia de forma (no hay a quien conectarse),
 * y esta prueba garantiza que el contrato hacia los canales NO cambia: sigue siendo 503 y no un
 * 500 generico por una excepcion que nadie esperaba.
 */
@SpringBootTest(
        classes = RestCoreClientSinInstanciasTest.ConfiguracionDePrueba.class,
        webEnvironment = SpringBootTest.WebEnvironment.MOCK,
        properties = {
                "core.base-url=http://core-service",
                "spring.cloud.loadbalancer.cache.enabled=false"
        })
class RestCoreClientSinInstanciasTest {

    private static AuthServerSimulado authServer;

    /** El token se pide ANTES de elegir instancia: el simulador evita que esta prueba pase por otro motivo. */
    @DynamicPropertySource
    static void registrarElAuthServer(DynamicPropertyRegistry registro) throws IOException {
        authServer = AuthServerSimulado.iniciar(300);
        authServer.registrarCliente(registro, AuthServerSimulado.SECRETO);
    }

    @AfterAll
    static void detener() {
        authServer.detener();
    }

    @Autowired
    private RestCoreClient cliente;

    @Test
    @DisplayName("Sin instancias registradas de core-service, la llamada falla con CoreNoDisponibleException")
    void sinInstanciasEsCoreNoDisponible() {
        assertThatThrownBy(() -> cliente.obtenerSaldo(116))
                .isInstanceOf(CoreNoDisponibleException.class);
    }

    @Configuration(proxyBeanMethods = false)
    @EnableAutoConfiguration
    @EnableConfigurationProperties(CoreClientProperties.class)
    @Import({ClienteCoreBalanceadoConfig.class, ClienteOAuth2ServicioConfig.class, RestCoreClient.class})
    static class ConfiguracionDePrueba {
    }
}
