package cl.duoc.bancoxyz.comun.token;

/**
 * Nombres de los claims propios que el {@code auth-server} escribe en los tokens de usuario y que leen
 * los tres BFF.
 *
 * <p><b>Por que viven en la libreria compartida.</b> El token lo escribe un servicio (el servidor de
 * autorizacion) y lo leen otros tres. Si cada uno tuviera su propia cadena literal, un desajuste de una
 * letra ({@code cuentaId} contra {@code cuenta_id}) no fallaria al compilar ni al arrancar: el titular de
 * una cuenta recibiria 403 sobre su propia cuenta, y el sintoma apuntaria a la comprobacion de
 * titularidad y no al nombre del claim. Con una sola fuente, el desajuste ni siquiera se puede escribir.
 *
 * <p>Los nombres son los mismos que los BFF leian cuando emitian sus propios tokens (fase S5), salvo
 * {@link #DEVICE_ID} (antes {@code dispositivoId}) y {@link #TERMINAL}, que es nuevo: la delegacion del
 * login al servidor de autorizacion no cambia lo que el BFF necesita saber del portador.
 */
public final class ClaimsToken {

    /** Cuenta de la que el portador es titular (entero). Ausente en el ejecutivo, que no tiene cuenta. */
    public static final String CUENTA_ID = "cuentaId";

    /** Canal del token: {@link #CANAL_WEB}, {@link #CANAL_MOVIL} o {@link #CANAL_ATM}. Solo informativo. */
    public static final String CANAL = "canal";

    /**
     * Autoridades del portador en ESE canal, con el prefijo incluido ({@code ROLE_...},
     * {@code PERM_...}). Los BFF las convierten tal cual en autoridades de Spring Security
     * ({@code authorities-claim-name} y {@code authority-prefix: ""}).
     */
    public static final String AUTORIDADES = "authorities";

    /** Dispositivo al que queda atado un token del canal movil (el que declaro la app al pedir el codigo). */
    public static final String DEVICE_ID = "device_id";

    /** Terminal registrado que autentico la tarjeta en el cajero (por ejemplo {@code ATM-SCL-001}). */
    public static final String TERMINAL = "terminal";

    public static final String CANAL_WEB = "WEB";
    public static final String CANAL_MOVIL = "MOVIL";
    public static final String CANAL_ATM = "ATM";

    private ClaimsToken() {
    }
}
