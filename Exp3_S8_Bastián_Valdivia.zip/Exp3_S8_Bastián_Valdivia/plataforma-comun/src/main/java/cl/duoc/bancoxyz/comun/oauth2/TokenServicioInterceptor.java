package cl.duoc.bancoxyz.comun.oauth2;

import java.io.IOException;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.oauth2.client.OAuth2AuthorizeRequest;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.core.OAuth2AuthorizationException;
import org.springframework.security.oauth2.core.OAuth2AccessToken;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.retry.Retry;

/**
 * Adjunta a cada llamada saliente el <strong>token de acceso del propio servicio</strong>
 * ({@code Authorization: Bearer ...}), pedido al auth-server con el flujo {@code client_credentials}.
 *
 * <h2>Por que existe, si Spring Security ya trae un cliente OAuth2</h2>
 *
 * <p>Spring Security 6.3 (la version que gestiona Spring Boot 3.3) no incluye un interceptor para
 * {@code RestClient}: el {@code OAuth2ClientHttpRequestInterceptor} llega en la 6.4. Lo que si trae es
 * el {@link OAuth2AuthorizedClientManager}, que es quien sabe obtener un token, guardarlo y decidir si
 * sigue vigente. Esta clase es el pegamento entre los dos: unas pocas lineas que piden el cliente
 * autorizado al gestor y ponen su token en la cabecera.
 *
 * <h2>El token se reutiliza: no se pide uno por peticion</h2>
 *
 * <p>Pedir un token en cada llamada al core duplicaria el trafico (dos peticiones por cada una de
 * negocio), cargaria al auth-server con la carga entera del sistema y haria que una caida suya
 * tumbara el servicio al instante. Aqui el gestor guarda el token en memoria y lo entrega mientras no
 * venza. Con tokens de 5 minutos, un BFF habla con el auth-server una vez cada unos 4 minutos y medio,
 * por muchas peticiones que atienda.
 *
 * <p>Se renueva <strong>antes</strong> de que venza: el margen {@code renovarAntes} evita el caso
 * clasico en que el token caduca entre que el BFF lo lee y el core lo valida, y el usuario recibe un
 * 401 por un reloj que iba medio segundo atrasado.
 *
 * <h3>Un solo hilo renueva, los demas esperan</h3>
 *
 * <p>Cuando el token entra en su margen de renovacion, decenas de peticiones concurrentes lo notan a la
 * vez. Sin coordinacion, cada una pediria su propio token ("estampida"). El camino habitual (token
 * vigente) no toma ningun candado: solo lee la memoria. El camino de renovacion si lo toma y vuelve a
 * mirar dentro de el, de modo que solo el primer hilo habla con el auth-server y los demas encuentran
 * el token ya renovado.
 *
 * <h2>Si el auth-server no responde (F6)</h2>
 *
 * <p>La obtencion del token esta protegida con un {@link Retry} (2 intentos) y un {@link CircuitBreaker}
 * propios, ambos de la instancia {@code auth-server} de Resilience4j, y el limite de tiempo de 2 s del
 * cliente HTTP (ver {@code ClienteOAuth2ServicioConfig}). Cuando la renovacion falla:
 * <ul>
 *   <li><b>Si el token guardado sigue vigente</b> (la renovacion se intenta {@code renovarAntes} antes de
 *       que venza, 30 s por defecto), <b>se sigue usando</b> hasta su vencimiento real. Una caida del
 *       auth-server no se nota mientras quede un token valido: el BFF no tumba al core por un fallo
 *       ajeno. Se avisa con un WARN en cada intento fallido.</li>
 *   <li><b>Si no hay token o ya vencio</b>, la falla se convierte en {@link IOException}, que
 *       {@code RestCoreClient} traduce a "el core no esta disponible" (503 controlado): sin token no
 *       se puede hablar con el core.</li>
 * </ul>
 * Con el circuito abierto el intento de renovar ni siquiera sale hacia la red, asi que los hilos no
 * esperan timeouts mientras el auth-server esta caido. Se registra con el codigo OAuth2 del error (por
 * ejemplo {@code invalid_client} si el secreto esta mal) y nunca con el secreto.
 *
 * <h2>Si el core rechaza el token con 401</h2>
 *
 * <p>Se descarta el token guardado, para que la siguiente llamada pida uno nuevo en vez de repetir el
 * mismo hasta que venza. Cubre, por ejemplo, un auth-server reinstalado con otra clave de firma. La
 * llamada que recibio el 401 no se repite aqui: un 401 es una respuesta del core (no una falla de
 * infraestructura), asi que no entra en la politica de reintentos de {@code CoreClientResiliente}, y el
 * canal responde 503 a esa peticion; la siguiente ya lleva un token nuevo.
 */
public final class TokenServicioInterceptor implements ClientHttpRequestInterceptor {

    private static final Logger log = LoggerFactory.getLogger(TokenServicioInterceptor.class);

    private final OAuth2AuthorizedClientManager gestor;
    private final OAuth2AuthorizedClientService almacen;
    private final String registro;
    private final Duration renovarAntes;
    private final Clock reloj;
    private final CircuitBreaker circuito;
    private final Retry reintento;

    /** Candado de la renovacion. Un objeto propio y no {@code this}: nadie de fuera puede tomarlo. */
    private final Object candadoDeRenovacion = new Object();

    /** Cuantas veces se obtuvo un token nuevo del auth-server. Es lo que miden las pruebas. */
    private final AtomicLong obtenciones = new AtomicLong();

    /**
     * Version sin Resilience4j: la usan las pruebas que no necesitan el circuito. En el sistema real se
     * usa el constructor completo.
     *
     * @param gestor       el que obtiene y renueva el token (client_credentials)
     * @param almacen      donde el gestor guarda el cliente autorizado; se consulta sin candado
     * @param registro     identificador del registro de cliente ({@code servicios-internos})
     * @param renovarAntes margen de renovacion respecto al vencimiento
     * @param reloj        fuente de tiempo, inyectable para probar la renovacion sin esperar minutos
     */
    public TokenServicioInterceptor(OAuth2AuthorizedClientManager gestor,
                                    OAuth2AuthorizedClientService almacen,
                                    String registro,
                                    Duration renovarAntes,
                                    Clock reloj) {
        this(gestor, almacen, registro, renovarAntes, reloj, null, null);
    }

    /**
     * @param circuito  cortacircuitos de la obtencion del token, o {@code null} para no usar ninguno
     * @param reintento reintentos de la obtencion del token, o {@code null} para no usar ninguno
     * @see #TokenServicioInterceptor(OAuth2AuthorizedClientManager, OAuth2AuthorizedClientService, String, Duration, Clock)
     */
    public TokenServicioInterceptor(OAuth2AuthorizedClientManager gestor,
                                    OAuth2AuthorizedClientService almacen,
                                    String registro,
                                    Duration renovarAntes,
                                    Clock reloj,
                                    CircuitBreaker circuito,
                                    Retry reintento) {
        this.gestor = gestor;
        this.almacen = almacen;
        this.registro = registro;
        this.renovarAntes = renovarAntes;
        this.reloj = reloj;
        this.circuito = circuito;
        this.reintento = reintento;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest peticion, byte[] cuerpo,
                                        ClientHttpRequestExecution ejecucion) throws IOException {
        String token = tokenVigente();
        peticion.getHeaders().setBearerAuth(token);

        ClientHttpResponse respuesta = ejecucion.execute(peticion, cuerpo);

        if (respuesta.getStatusCode() == HttpStatus.UNAUTHORIZED) {
            log.warn("El destino {} rechazo el token de servicio con 401 ({}). Se descarta el token "
                            + "guardado para pedir uno nuevo en la siguiente llamada.",
                    peticion.getURI().getHost(), respuesta.getHeaders().getFirst(HttpHeaders.WWW_AUTHENTICATE));
            almacen.removeAuthorizedClient(registro, registro);
        }
        return respuesta;
    }

    /**
     * Cuantos tokens se han pedido al auth-server desde que arranco el servicio.
     *
     * @return cuenta acumulada; con trafico constante crece una vez por vigencia del token, no por
     *         peticion
     */
    public long obtenciones() {
        return obtenciones.get();
    }

    private String tokenVigente() throws IOException {
        OAuth2AuthorizedClient cliente = almacen.loadAuthorizedClient(registro, registro);
        if (cliente == null || vencePronto(cliente.getAccessToken())) {
            synchronized (candadoDeRenovacion) {
                // Se vuelve a mirar dentro del candado: otro hilo pudo renovarlo mientras este esperaba.
                cliente = almacen.loadAuthorizedClient(registro, registro);
                if (cliente == null || vencePronto(cliente.getAccessToken())) {
                    cliente = renovarOConservar(cliente);
                }
            }
        }
        return cliente.getAccessToken().getTokenValue();
    }

    /**
     * Intenta renovar y, si el auth-server no responde, conserva el token vigente mientras exista.
     *
     * <p>"Vigente" aqui es el vencimiento REAL del token, no el margen de renovacion: el margen existe
     * para renovar con holgura, pero un token a 20 s de vencer sigue siendo valido para el core. Solo
     * cuando ya no lo es, la falla del auth-server se convierte en un 503.
     */
    private OAuth2AuthorizedClient renovarOConservar(OAuth2AuthorizedClient actual) throws IOException {
        try {
            return pedirTokenNuevo();
        } catch (IOException falla) {
            if (actual != null && sigueVigente(actual.getAccessToken())) {
                log.warn("No se pudo renovar el token de servicio ({}). Se sigue usando el token vigente, "
                        + "que vence el {}.", falla.getMessage(), actual.getAccessToken().getExpiresAt());
                return actual;
            }
            throw falla;
        }
    }

    private boolean sigueVigente(OAuth2AccessToken token) {
        Instant vencimiento = token.getExpiresAt();
        // Un segundo de holgura: el token que se entrega ahora viaja y se valida en el core despues.
        return vencimiento == null || reloj.instant().isBefore(vencimiento.minusSeconds(1));
    }

    private boolean vencePronto(OAuth2AccessToken token) {
        Instant vencimiento = token.getExpiresAt();
        // Misma regla que aplica el proveedor de client_credentials del gestor (ahora > vencimiento menos el
        // margen): si discreparan, el interceptor creeria vencido un token que el gestor da por bueno.
        return vencimiento != null && reloj.instant().isAfter(vencimiento.minus(renovarAntes));
    }

    /** Codigos OAuth2 con los que Spring Security informa un fallo del servidor y no un rechazo de credenciales. */
    private static final Set<String> CODIGOS_DE_INFRAESTRUCTURA =
            Set.of("invalid_token_response", "server_error", "temporarily_unavailable");

    private OAuth2AuthorizedClient pedirTokenNuevo() throws IOException {
        // El nombre del "principal" es solo la llave bajo la que el gestor guarda el token: este
        // servicio tiene una unica identidad, la del registro.
        OAuth2AuthorizeRequest solicitud = OAuth2AuthorizeRequest
                .withClientRegistrationId(registro)
                .principal(registro)
                .build();

        // Retry( CircuitBreaker( llamada ) ), igual que con el core y por la misma razon (ver
        // CoreClientResiliente): cada intento cuenta en el circuito, y con el circuito abierto no se insiste.
        Supplier<OAuth2AuthorizedClient> llamada = () -> autorizar(solicitud);
        if (circuito != null) {
            llamada = CircuitBreaker.decorateSupplier(circuito, llamada);
        }
        if (reintento != null) {
            llamada = Retry.decorateSupplier(reintento, llamada);
        }
        try {
            OAuth2AuthorizedClient cliente = llamada.get();
            if (cliente == null) {
                throw new IOException("El gestor OAuth2 no entrego un token de servicio para el registro "
                        + registro);
            }
            OAuth2AccessToken token = cliente.getAccessToken();
            log.info("Token de servicio obtenido del auth-server (obtencion {}), vigente hasta {}, scopes {}",
                    obtenciones.incrementAndGet(), token.getExpiresAt(), token.getScopes());
            return cliente;
        } catch (CallNotPermittedException abierto) {
            throw new IOException("El circuito del auth-server esta abierto: no se intento obtener el "
                    + "token de servicio", abierto);
        } catch (TokenServicioNoDisponibleException caido) {
            log.error("El auth-server no entrego el token de servicio: {}", caido.getMessage());
            throw new IOException("No se pudo obtener el token de servicio del auth-server: "
                    + caido.getMessage(), caido);
        } catch (OAuth2AuthorizationException falla) {
            // Solo el codigo y la descripcion del error OAuth2: nunca la peticion, que lleva el secreto.
            log.error("No se pudo obtener el token de servicio ({}): {}",
                    falla.getError().getErrorCode(), falla.getMessage());
            throw new IOException("No se pudo obtener el token de servicio del auth-server: "
                    + falla.getError().getErrorCode(), falla);
        }
    }

    /**
     * Una sola llamada al auth-server. Distingue la falla de infraestructura (reintentable y que
     * cuenta para el circuito) del rechazo de credenciales (que no).
     */
    private OAuth2AuthorizedClient autorizar(OAuth2AuthorizeRequest solicitud) {
        try {
            return gestor.authorize(solicitud);
        } catch (OAuth2AuthorizationException falla) {
            if (CODIGOS_DE_INFRAESTRUCTURA.contains(falla.getError().getErrorCode())) {
                throw new TokenServicioNoDisponibleException(falla.getError().getErrorCode(), falla);
            }
            throw falla;
        }
    }
}
