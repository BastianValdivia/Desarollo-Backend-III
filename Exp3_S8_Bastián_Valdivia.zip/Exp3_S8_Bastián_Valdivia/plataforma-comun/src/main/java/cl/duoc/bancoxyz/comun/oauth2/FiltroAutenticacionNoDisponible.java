package cl.duoc.bancoxyz.comun.oauth2;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.web.filter.OncePerRequestFilter;

import cl.duoc.bancoxyz.comun.error.EscritorErrorHttp;
import cl.duoc.bancoxyz.comun.error.MotivosError;
import cl.duoc.bancoxyz.comun.error.RespuestaError;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Convierte en un 503 la imposibilidad de VERIFICAR un token porque el {@code auth-server} no entrego sus claves.
 *
 * <p><strong>Que problema resuelve.</strong> Desde F5 los BFF validan la firma con las claves publicas que publica el
 * servidor de autorizacion. Si ese servidor esta caido y el BFF no las tiene en cache, el decodificador lanza una
 * excepcion de INFRAESTRUCTURA ({@link AuthenticationServiceException}), no de token invalido. Spring Security la
 * RELANZA a proposito (el filtro de tokens no la convierte en 401, para no decirle al cliente que su token es
 * malo cuando el problema es del servidor), y sin este filtro llegaria al contenedor como un 500 con la pagina de
 * error de Spring, fuera del formato RFC 7807 del canal.
 *
 * <p><strong>Que responde.</strong> 503 {@code autenticacion_no_disponible}, en el formato del canal, sin
 * {@code WWW-Authenticate} (ese encabezado dice "identificate", y el cliente no hizo nada mal: repetir el login no
 * lo arregla). Mientras las claves sigan en cache, una caida breve del auth-server no se nota. Sin token no hace
 * falta ninguna clave y el filtro no interviene: sigue siendo 401 {@code token_ausente}.
 *
 * <p>Se registra ANTES del filtro de tokens de portador, que es donde nace la excepcion que debe atrapar. Lo hace
 * cada BFF en su cadena de seguridad, con su propio nombre de canal.
 */
public class FiltroAutenticacionNoDisponible extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(FiltroAutenticacionNoDisponible.class);

    private final EscritorErrorHttp escritor;
    private final String canal;

    public FiltroAutenticacionNoDisponible(EscritorErrorHttp escritor, String canal) {
        this.escritor = escritor;
        this.canal = canal;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest peticion, HttpServletResponse respuesta, FilterChain cadena)
            throws ServletException, IOException {
        try {
            cadena.doFilter(peticion, respuesta);
        } catch (AuthenticationServiceException fallo) {
            log.error("503 en {} {}: no se pudo verificar el token (el auth-server no entrego sus claves): {}",
                    peticion.getMethod(), peticion.getRequestURI(), fallo.getMessage());
            respuesta.setHeader("Cache-Control", "no-store");
            escritor.escribir(respuesta, HttpStatus.SERVICE_UNAVAILABLE.value(),
                    RespuestaError.de(HttpStatus.SERVICE_UNAVAILABLE.value(), MotivosError.AUTENTICACION_NO_DISPONIBLE,
                            "Servicio no disponible",
                            "No se pudo verificar la sesion en este momento. Intente de nuevo",
                            peticion.getRequestURI(), canal));
        }
    }
}
