package cl.duoc.bancoxyz.comun.core.dto;

/**
 * Recuento de la ingesta de UN archivo del dataset legado, elemento del arreglo
 * {@code archivos} del reporte de calidad (seccion 5.14 del contrato).
 *
 * <p>Las tres cifras cuentan la misma historia en tres pasos: cuantas filas
 * traia el archivo, cuantas quedaron tras quitar duplicados exactos, y la
 * diferencia entre ambas. Sobre {@code intereses.csv} el resultado medido es
 * 1000, 991 y 9.
 *
 * <p><b>Por que {@code duplicadasDescartadas} viaja aunque sea la resta de las
 * otras dos.</b> Porque este reporte se lee en pantalla, y obligar a quien lo
 * mira a restar dos numeros para enterarse del dato que le interesa es
 * trasladarle trabajo. Un reporte de calidad de datos existe para que los
 * problemas salten a la vista, no para que se deduzcan.
 *
 * @param archivo               nombre del archivo, por ejemplo {@code intereses.csv}
 * @param filasLeidas           filas de datos del archivo, sin contar la cabecera
 * @param filasUnicas           filas que quedaron tras descartar duplicados exactos
 * @param duplicadasDescartadas diferencia entre las dos anteriores
 */
public record ArchivoCalidadCoreDto(
        String archivo,
        int filasLeidas,
        int filasUnicas,
        int duplicadasDescartadas) {
}
