package cl.duoc.bancoxyz.comun.core;

/**
 * El core devolvio 422 {@code clave_idempotencia_reutilizada}: la {@code Idempotency-Key} ya se uso
 * en esa cuenta para retirar otro importe.
 *
 * <p>Es una excepcion propia y no un caso de {@link CoreRespuestaInesperadaException} porque el canal
 * tiene que distinguirla: sin ella saldria como un 503 "core no disponible", y el cajero creeria que
 * el banco esta caido cuando en realidad su peticion es la defectuosa (reintentarla igual siempre
 * fallara, hace falta una clave nueva). El core es quien lo decide, porque la idempotencia protege una
 * mutacion de estado y el estado tiene un unico dueno.
 */
public class CoreClaveIdempotenciaReutilizadaException extends CoreException {

    public CoreClaveIdempotenciaReutilizadaException(String mensaje,
                                                     String rutaSolicitada,
                                                     String cuerpoCrudo) {
        super(mensaje, rutaSolicitada, 422, cuerpoCrudo, null);
    }
}
