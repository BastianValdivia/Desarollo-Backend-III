package cl.duoc.bancoxyz.comun.core.dto;

import java.math.BigDecimal;

/**
 * Respuesta del endpoint C5 del core, el retiro (seccion 5.12 del contrato).
 *
 * <p><b>Por que vienen los tres importes y no solo el saldo final.</b> Porque
 * un retiro es la unica operacion del sistema que cambia el estado del banco,
 * y una respuesta que solo dijera "ahora tienes 9.000" no permite verificar
 * nada: el cliente no sabe si el cargo fue el que pidio. Con saldo anterior,
 * monto y saldo posterior, la propia respuesta es su comprobante, y la
 * evidencia del retiro se lee de un vistazo (12.000 menos 3.000 igual a 9.000).
 *
 * <p><b>El {@code folio} y la idempotencia.</b> Ante un {@code Idempotency-Key}
 * repetido, el core devuelve EL MISMO folio y no descuenta otra vez. Ese es el
 * punto entero del mecanismo: si un cajero pierde la respuesta por un timeout
 * de red y reintenta, el cliente no puede quedar con dos retiros. Notese donde
 * vive: en el core, dueño unico del estado, no en el BFF. Un registro de
 * idempotencia en el BFF protegeria solo a los reintentos que pasaran por esa
 * instancia del BFF, que es no protegerlos.
 *
 * <p>Este record tiene cuatro campos. La respuesta del cajero (A3) tiene estos
 * cuatro MAS {@code desglose}, el reparto en billetes, porque el core no sabe
 * de billetes: las denominaciones son configuracion del canal. Ese quinto
 * campo se agrega en {@code bff-atm} y no aqui.
 *
 * @param folio          identificador unico y estable por clave de idempotencia
 * @param saldoAnterior  saldo antes de la operacion
 * @param montoRetirado  importe efectivamente descontado
 * @param saldoPosterior saldo despues de la operacion
 */
public record RetiroCoreDto(
        String folio,
        BigDecimal saldoAnterior,
        BigDecimal montoRetirado,
        BigDecimal saldoPosterior) {
}
