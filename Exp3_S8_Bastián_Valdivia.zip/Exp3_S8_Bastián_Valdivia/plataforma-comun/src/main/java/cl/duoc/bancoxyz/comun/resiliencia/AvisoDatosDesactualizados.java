package cl.duoc.bancoxyz.comun.resiliencia;

import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * Escribe las cabeceras que avisan al cliente de que la respuesta trae datos desactualizados, cuando
 * un servicio los marco con {@link DatosDesactualizados#marcar}.
 *
 * <h2>Las cabeceras</h2>
 * <ul>
 *   <li>{@code X-Datos-Desactualizados: true}: la senal que un cliente programatico mira.</li>
 *   <li>{@code X-Datos-Antiguedad-Segundos: N}: hace cuantos segundos el BFF obtuvo ese dato del core.</li>
 *   <li>{@code Warning: 110 - "Response is Stale"}: la advertencia estandar de HTTP para una respuesta
 *       vencida, que entienden caches y herramientas aunque no conozcan este sistema.</li>
 *   <li>{@code Cache-Control: no-store}: la respuesta de respaldo NO debe guardarse ni revalidarse en el
 *       cliente ni en intermediarios. Si el telefono la guardara con un ETag, seguiria mostrando el
 *       saldo viejo despues de que el core vuelva.</li>
 * </ul>
 *
 * <p>Por que un {@code ResponseBodyAdvice} y no un filtro: corre justo antes de escribir el cuerpo,
 * cuando la respuesta aun no se ha enviado (un filtro que actuara despues del controlador podria
 * encontrar ya la respuesta comprometida, porque las fichas grandes superan el buffer) y ve las
 * cabeceras que el controlador puso, de modo que puede reemplazar su {@code Cache-Control}.
 *
 * <p>Se recoge por el escaneo de {@code cl.duoc.bancoxyz.comun}. En el cajero nunca se activa: su
 * canal no usa respaldo.
 */
@ControllerAdvice
public class AvisoDatosDesactualizados implements ResponseBodyAdvice<Object> {

    public static final String CABECERA_DESACTUALIZADO = "X-Datos-Desactualizados";
    public static final String CABECERA_ANTIGUEDAD = "X-Datos-Antiguedad-Segundos";

    @Override
    public boolean supports(MethodParameter tipoDeRetorno, Class<? extends HttpMessageConverter<?>> conversor) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object cuerpo, MethodParameter tipoDeRetorno, MediaType tipoDeContenido,
                                  Class<? extends HttpMessageConverter<?>> conversor,
                                  ServerHttpRequest peticion, ServerHttpResponse respuesta) {
        if (peticion instanceof ServletServerHttpRequest servlet) {
            Object antiguedad = servlet.getServletRequest().getAttribute(DatosDesactualizados.ATRIBUTO);
            if (antiguedad instanceof Long segundos) {
                HttpHeaders cabeceras = respuesta.getHeaders();
                cabeceras.set(CABECERA_DESACTUALIZADO, "true");
                cabeceras.set(CABECERA_ANTIGUEDAD, Long.toString(segundos));
                cabeceras.set(HttpHeaders.WARNING, "110 - \"Response is Stale\"");
                cabeceras.set(HttpHeaders.CACHE_CONTROL, "no-store");
            }
        }
        return cuerpo;
    }
}
