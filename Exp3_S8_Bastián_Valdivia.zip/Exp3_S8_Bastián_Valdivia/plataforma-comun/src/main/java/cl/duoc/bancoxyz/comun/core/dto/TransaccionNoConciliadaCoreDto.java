package cl.duoc.bancoxyz.comun.core.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Una fila de {@code transacciones.csv}, el lote que NO se pudo vincular a
 * ninguna cuenta (seccion 5.15 del contrato).
 *
 * <p><b>Rol en la arquitectura, y por que este DTO se ve "mal hecho" a
 * proposito.</b> Ese archivo no tiene columna {@code cuenta_id} y sus ids van
 * de 1 a 1000 sin ninguna columna vinculable, asi que es inservible para una
 * API por cuenta. La decision tomada fue exponerlo tal cual, marcado como no
 * conciliado, en lugar de inventarle una asignacion de cuenta por modulo, por
 * turno o al azar. Fabricar ese vinculo seria inventar datos financieros, que
 * es peor que declarar que el archivo no se pudo conciliar.
 *
 * <p>De ahi las tres rarezas de este record, que son fidelidad y no descuido:
 * <ul>
 *   <li>{@code fecha} es nula cuando la fecha del archivo era ilegible.</li>
 *   <li>{@code monto} es nulo cuando la celda venia vacia.</li>
 *   <li>{@code tipo} es el valor CRUDO del CSV, sin normalizar, incluidos
 *       {@code invalid} y {@code desconocido}. Es el unico lugar de todo el
 *       sistema donde un enumerado sale sin normalizar, y es deliberado:
 *       normalizarlo daria la impresion de que el dato esta limpio.</li>
 * </ul>
 *
 * <p>Compareselo con {@link MovimientoCoreDto}, donde nada es nulo y todo esta
 * normalizado. La diferencia entre los dos records es, en si misma, la
 * distincion entre un dato conciliado y uno que no lo esta.
 *
 * @param id    identificador propio del archivo, de 1 a 1000. <b>No es un {@code cuentaId}</b>
 * @param fecha fecha del archivo, o {@code null} si era ilegible
 * @param monto importe del archivo, o {@code null} si venia vacio
 * @param tipo  valor crudo del CSV, sin normalizar
 */
public record TransaccionNoConciliadaCoreDto(
        int id,
        LocalDate fecha,
        BigDecimal monto,
        String tipo) {
}
