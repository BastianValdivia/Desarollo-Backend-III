package cl.duoc.bancoxyz.comun.core;

import org.springframework.boot.autoconfigure.web.client.RestClientBuilderConfigurer;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.web.client.RestClient;

/**
 * Declara el {@code RestClient.Builder} <b>balanceado</b> con el que {@link RestCoreClient} llama
 * al core por su NOMBRE LOGICO.
 *
 * <p><b>Que resuelve.</b> {@code core.base-url} vale {@code http://core-service}. Ese host no existe
 * en ninguna red: es el nombre con el que el core se registra en Eureka. La anotacion
 * {@link LoadBalanced} hace que Spring Cloud agregue al builder un interceptor que, justo antes de
 * enviar cada peticion, pregunta al registro por las instancias vivas de {@code core-service},
 * elige una (round robin) y reemplaza el nombre por su direccion real. Asi ningun BFF conoce la
 * direccion del core: si cambia de maquina, de puerto o se duplica, los BFF no se tocan.
 *
 * <p><b>Por que se parte del configurador de Spring Boot y no de {@code RestClient.builder()}.</b>
 * El builder que Boot publica por defecto viene cargado con los conversores de mensaje del
 * contexto (el mismo {@code ObjectMapper} que el resto del BFF, con el modulo de fechas de Java 8,
 * del que depende deserializar {@code "2024-03-08"} a {@code LocalDate}). Al declarar aqui un
 * builder propio el de Boot se retira ({@code @ConditionalOnMissingBean}), asi que se reproduce
 * su receta con el mismo {@link RestClientBuilderConfigurer}: se gana el balanceo y no se pierde
 * ese comportamiento.
 *
 * <p><b>Prototipo y no singleton</b>, igual que el de Boot: cada inyeccion recibe un builder nuevo
 * y {@link RestCoreClient} lo clona ademas antes de configurarlo, de modo que la URL base y las
 * cabeceras de un cliente no se filtran a otro.
 *
 * <p>Esta clase vive en la libreria compartida porque la necesitan los tres BFF por igual y la
 * recogen con el escaneo de {@code cl.duoc.bancoxyz.comun}. El core no depende de
 * plataforma-comun y no la carga.
 */
@Configuration(proxyBeanMethods = false)
public class ClienteCoreBalanceadoConfig {

    /**
     * Builder con balanceo del lado del cliente. Cualquier {@code RestClient} que se construya a
     * partir de el resuelve los nombres logicos contra Eureka.
     *
     * @param configurador el de Spring Boot, que aplica los conversores de mensaje del contexto
     * @return un builder nuevo en cada inyeccion
     */
    @Bean
    @LoadBalanced
    @Scope("prototype")
    public RestClient.Builder restClientBuilderBalanceado(RestClientBuilderConfigurer configurador) {
        return configurador.configure(RestClient.builder());
    }
}
