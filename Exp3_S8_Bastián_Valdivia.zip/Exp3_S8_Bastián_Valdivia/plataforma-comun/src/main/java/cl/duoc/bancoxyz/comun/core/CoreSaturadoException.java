package cl.duoc.bancoxyz.comun.core;

/**
 * El mamparo (bulkhead) del core esta lleno: ya hay el maximo de llamadas simultaneas permitidas y
 * esta se rechazo sin intentarla.
 *
 * <p>Es una {@link CoreNoDisponibleException} para que el canal responda con el mismo 503 o el
 * mismo respaldo, pero se distingue por su nombre porque la causa es otra: el core puede estar
 * perfectamente sano y ser el BFF quien limita cuanto le manda a la vez. Rechazar de inmediato lo que
 * excede el limite es lo que impide que una rafaga (o un core lento) ocupe todos los hilos del
 * canal y deje sin servicio hasta a las peticiones que no necesitaban el core.
 *
 * <p>Nunca la lanza {@link RestCoreClient}: la produce {@code CoreClientResiliente} al traducir la
 * {@code BulkheadFullException} de Resilience4j. No es un fallo del circuito (el core no fallo) ni
 * se reintenta (reintentar una sobrecarga la empeora).
 */
public class CoreSaturadoException extends CoreNoDisponibleException {

    public CoreSaturadoException(String mensaje, String rutaSolicitada, Throwable causa) {
        super(mensaje, rutaSolicitada, null, null, causa);
    }
}
