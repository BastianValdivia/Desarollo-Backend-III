package cl.duoc.bancoxyz.comun.core.dto;

import java.math.BigDecimal;
import java.util.List;

/**
 * La cuenta canonica completa que devuelve el endpoint C2 del core,
 * {@code GET /internal/v1/cuentas/{id}} (seccion 5.4 del contrato).
 *
 * <p><b>Rol en la arquitectura: esta es la respuesta mas grande del sistema, y
 * eso es intencional.</b> Trae la ficha de la cuenta mas TODOS sus
 * movimientos, que en la cuenta 116 son 42 y en la 106 son 43. Es la linea
 * base contra la que se mide cuanto recorta cada canal: el cajero devuelve dos
 * campos, movil devuelve cinco movimientos de tres campos, y web devuelve una
 * primera pagina con agregados. Sin una linea base gorda, la frase
 * "optimizado por canal" no se puede medir, solo afirmar.
 *
 * <p>Por eso mismo hay endpoints mas estrechos aguas arriba (C3 para el saldo,
 * C4 para una pagina de movimientos): un canal que solo necesita el saldo no
 * debe pedir esta respuesta y descartar el 95 por ciento. Traer de mas y botar
 * es exactamente el desperdicio que el patron BFF existe para evitar, y no se
 * arregla proyectando al final: el trafico ya viajo.
 *
 * @param cuentaId    entero entre 101 y 150
 * @param titular     nombre completo consolidado, con tildes correctas
 * @param tipoCuenta  {@code AHORRO}, {@code HIPOTECA} o {@code PRESTAMO}
 * @param saldo       saldo consolidado. Siempre en el conjunto {5000, 7000, 8000, 10000, 12000}
 * @param edadTitular edad del titular. Ojo: NO se llama {@code edad}, que es como viene en el CSV
 * @param moneda      literal {@code CLP}
 * @param movimientos todos los movimientos validos. Ver la nota sobre la lista vacia
 */
public record CuentaCoreDto(
        int cuentaId,
        String titular,
        String tipoCuenta,
        BigDecimal saldo,
        int edadTitular,
        String moneda,
        List<MovimientoCoreDto> movimientos) {

    /**
     * Constructor compacto que convierte una lista nula en lista vacia.
     *
     * <p><b>Por que esta defensa y no confiar en el core.</b> El contrato
     * obliga al core a devolver {@code []} y nunca {@code null}, y la cuenta
     * 130 (cero movimientos) existe precisamente para demostrarlo. Pero este
     * objeto se construye a partir de JSON que llega por la red: si por
     * cualquier motivo el campo faltara, Jackson dejaria {@code null} y el
     * primer {@code movimientos().size()} de cualquier canal lanzaria un
     * {@code NullPointerException}. Convertir aqui, en el borde de entrada,
     * significa que ninguno de los tres BFF necesita escribir esa comprobacion,
     * y que el caso borde de la cuenta 130 se comporta igual que cualquier otra.
     *
     * <p>La copia inmutable ademas impide que un canal ordene o filtre la lista
     * en el sitio y, sin saberlo, modifique lo que otro componente esta a punto
     * de leer.
     */
    public CuentaCoreDto {
        movimientos = movimientos == null ? List.of() : List.copyOf(movimientos);
    }
}
