package cl.duoc.bancoxyz.comun.resiliencia;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Politica del "ultimo dato conocido" que web y movil sirven cuando el core no esta disponible.
 *
 * <p>Los valores viven en el {@code config-repo/} de cada canal (la politica es del canal, el
 * mecanismo es comun). Prefijo {@code resiliencia.respaldo}.
 *
 * @param antiguedadMaxima cuanto tiempo despues de obtenido un dato se acepta servirlo como respaldo.
 *                         Pasado ese tiempo es mejor un 503 honesto que un saldo de hace una hora
 * @param maximoEntradas   tope de datos guardados; al superarlo se descartan los menos usados. Sin tope
 *                         el respaldo seria una fuga de memoria lenta
 */
@ConfigurationProperties(prefix = "resiliencia.respaldo")
public record RespaldoProperties(
        @DefaultValue("10m") Duration antiguedadMaxima,
        @DefaultValue("500") int maximoEntradas) {

    public RespaldoProperties {
        if (antiguedadMaxima.isNegative() || antiguedadMaxima.isZero()) {
            throw new IllegalArgumentException(
                    "resiliencia.respaldo.antiguedad-maxima debe ser positiva. Para no servir nunca datos "
                            + "de respaldo no se usa el respaldo, no se pone un cero.");
        }
        if (maximoEntradas < 1) {
            throw new IllegalArgumentException("resiliencia.respaldo.maximo-entradas debe ser al menos 1.");
        }
    }
}
