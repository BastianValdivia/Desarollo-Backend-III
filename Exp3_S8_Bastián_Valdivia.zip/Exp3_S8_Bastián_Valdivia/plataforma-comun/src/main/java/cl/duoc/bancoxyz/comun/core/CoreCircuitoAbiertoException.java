package cl.duoc.bancoxyz.comun.core;

/**
 * El circuito del core esta ABIERTO: la llamada ni siquiera se intento.
 *
 * <p>Es una {@link CoreNoDisponibleException} (el canal la trata igual: 503 o respaldo), pero se
 * distingue por su nombre porque cuenta una historia distinta en el log del operador. Un
 * {@code CoreNoDisponibleException} "a secas" dice que el core no contesto; esta dice que el BFF
 * <b>decidio no preguntarle</b> porque las ultimas llamadas fallaron y darle un respiro es mejor que
 * seguir cargandolo (y que dejar hilos de Tomcat esperando timeouts que ya se sabe que vencen).
 *
 * <p>Nunca la lanza {@link RestCoreClient}: la produce {@code CoreClientResiliente} al traducir la
 * {@code CallNotPermittedException} de Resilience4j. Por eso no cuenta como fallo del circuito ni
 * se reintenta: se lanza fuera de ambos mecanismos.
 */
public class CoreCircuitoAbiertoException extends CoreNoDisponibleException {

    public CoreCircuitoAbiertoException(String mensaje, String rutaSolicitada, Throwable causa) {
        super(mensaje, rutaSolicitada, null, null, causa);
    }
}
