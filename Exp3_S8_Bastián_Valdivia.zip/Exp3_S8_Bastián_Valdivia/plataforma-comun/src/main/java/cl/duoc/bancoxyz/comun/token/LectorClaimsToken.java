package cl.duoc.bancoxyz.comun.token;

import java.util.List;

import org.springframework.security.oauth2.jwt.Jwt;

/**
 * Lee de vuelta los claims propios que escribe el servidor de autorizacion (ver {@link ClaimsToken}).
 *
 * <p><b>Rol en la arquitectura: es la mitad lectora del contrato de claims.</b>
 * El servidor de autorizacion escribe cada claim con el nombre de
 * {@link ClaimsToken}; este lector lo busca con ese mismo nombre y sabe de que
 * tipo vuelve. Usar las mismas constantes es lo que impide que un dia el
 * servidor escriba {@code cuentaId} y un canal busque {@code cuenta_id}: el
 * desajuste no compilaria.
 *
 * <p><b>Por que esto es mecanismo y no politica.</b> Porque aqui no se compara
 * nada ni se decide nada. Este lector responde "que cuenta dice el token", no
 * "puede este token ver esta cuenta": esa segunda pregunta, con su 403 y su
 * motivo {@code cuenta_ajena}, es la comprobacion explicita que cada canal
 * hace en su propio servicio.
 *
 * <h2>LA TRAMPA QUE ESTA CLASE EXISTE PARA NEUTRALIZAR</h2>
 *
 * <p>Es la mas peligrosa de todo el proyecto, porque su sintoma apunta al
 * lugar equivocado y porque parece que la seguridad esta funcionando.
 *
 * <p>El claim {@code cuentaId} se escribe como {@code Integer}, pero JSON no
 * distingue entre entero y entero largo: al deserializar el token,
 * <b>vuelve como {@code Long}</b>. Verificado en esta maquina. Eso hace que
 * las dos formas naturales de escribir la comprobacion de titularidad esten
 * mal:
 *
 * <pre>
 * // MAL: lanza ClassCastException, porque el claim es Long y no Integer
 * Integer cuenta = (Integer) jwt.getClaim("cuentaId");
 *
 * // PEOR: compila, no lanza nada, y SIEMPRE da false
 * if (!jwt.getClaim("cuentaId").equals(cuentaIdDeLaRuta)) {
 *     throw new CuentaAjenaException();
 * }
 * </pre>
 *
 * <p>El segundo caso es el que cuesta una tarde. {@code Long.valueOf(116)} y
 * {@code Integer.valueOf(116)} son numericamente iguales, pero
 * {@code equals} entre envoltorios de tipo distinto devuelve <b>siempre</b>
 * {@code false}. Consecuencia: el titular de la cuenta 116, con su token
 * recien emitido y perfectamente valido, recibe <b>403 {@code cuenta_ajena}</b>
 * al pedir su propia cuenta. Y como el mensaje dice "cuenta ajena", lo natural
 * es concluir que la comprobacion de titularidad funciona y que el problema
 * esta en el token o en el usuario de prueba, que es justo donde no esta.
 *
 * <p>La cura es leer el claim como {@code Number} y pedirle su valor entero,
 * que es lo que hace {@link #cuentaId(Jwt)}. Un canal que use este metodo no
 * puede caer en la trampa; uno que lea el claim a mano, si.
 */
public final class LectorClaimsToken {

    /**
     * Devuelve el claim {@code cuentaId} como entero, o {@code null} si el
     * token no lo trae.
     *
     * <p>El {@code null} no es un descuido: el ejecutivo de web se autentica
     * sin cuenta asociada, porque audita y no consulta su saldo. Un canal que
     * llame a este metodo sobre un token de ejecutivo debe tratar ese
     * {@code null} como "esta identidad no acredita titularidad sobre ninguna
     * cuenta", que es distinto de "acredita sobre la cuenta 0".
     *
     * <p>Se lee como {@link Number} a proposito: asi da igual que el token
     * traiga el valor como {@code Long} (que es lo que ocurre en la practica),
     * como {@code Integer} o como cualquier otro numero entero. Ver la nota de
     * la clase.
     */
    public static Integer cuentaId(Jwt jwt) {
        Object valor = jwt.getClaim(ClaimsToken.CUENTA_ID);
        return valor instanceof Number numero ? numero.intValue() : null;
    }

    /**
     * Devuelve el claim {@code canal}: {@code WEB}, {@code MOVIL} o
     * {@code ATM}.
     *
     * <p>Sirve sobre todo para que una linea de log o de evidencia diga de que
     * canal venia una peticion. No debe usarse como control de seguridad: un
     * canal ya sabe cual es, y un token de otro canal no llega hasta aqui
     * porque lo detienen antes la firma y la audiencia. Un {@code if} sobre
     * este valor dentro de un BFF seria la señal de que se esta construyendo
     * un servicio generico con ramas por canal en lugar de tres BFF.
     */
    public static String canal(Jwt jwt) {
        return jwt.getClaimAsString(ClaimsToken.CANAL);
    }

    /**
     * Devuelve el claim {@code authorities} tal como viaja en el token.
     *
     * <p>Uso previsto: dejarlo visible en la evidencia, para poder comparar a
     * simple vista el contenido del token con el texto de las reglas de
     * autorizacion del canal. No hace falta para autorizar: de eso se encarga
     * el resource server, que convierte este mismo claim en las autoridades
     * del {@code Authentication} a partir de la configuracion
     * {@code authorities-claim-name} y {@code authority-prefix: ""}.
     */
    public static List<String> autoridades(Jwt jwt) {
        List<String> valores = jwt.getClaimAsStringList(ClaimsToken.AUTORIDADES);
        return valores == null ? List.of() : List.copyOf(valores);
    }

    /**
     * Devuelve un claim de texto propio de un canal, como el
     * {@code dispositivoId} de movil.
     *
     * <p>No existe un metodo {@code dispositivoId(Jwt)} a proposito: ese claim
     * pertenece a un solo canal, y darle un metodo con nombre propio en la
     * libreria compartida meteria aqui un concepto que web y cajero no tienen.
     * El canal movil declara su constante y llama a este metodo generico.
     */
    public static String claimDeTexto(Jwt jwt, String nombre) {
        return jwt.getClaimAsString(nombre);
    }

    private LectorClaimsToken() {
    }
}
