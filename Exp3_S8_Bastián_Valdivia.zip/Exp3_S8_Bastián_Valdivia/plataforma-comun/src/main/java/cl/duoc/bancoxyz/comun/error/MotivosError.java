package cl.duoc.bancoxyz.comun.error;

/**
 * Vocabulario congelado del campo {@code motivo} del cuerpo de error, tomado
 * literalmente de la seccion 7.1 del contrato.
 *
 * <p><b>Rol en la arquitectura.</b> Es una lista de constantes, no una regla.
 * Aqui vive UNA sola vez la grafia exacta de cada motivo; los tres canales la
 * importan en lugar de escribir la cadena a mano.
 *
 * <p><b>Por que esto NO viola el invariante "mecanismo, nunca politica".</b> La
 * pregunta legitima es si un catalogo de errores es politica de canal. No lo
 * es, y la distincion es fina pero importante:
 * <ul>
 *   <li>Que estas cadenas se escriban <i>igual</i> en los tres canales es
 *       mecanismo: es vocabulario compartido, como lo es el nombre de una
 *       cabecera HTTP.</li>
 *   <li>Que un canal devuelva {@code cuenta_ajena} en una situacion concreta,
 *       con que codigo HTTP y con que texto, es politica, y eso vive en el
 *       manejador de errores de cada BFF.</li>
 * </ul>
 * Dicho de otro modo: aqui esta el diccionario, no las frases.
 *
 * <p><b>Por que importa tanto como para merecer una clase propia.</b> El campo
 * {@code motivo} es el que leen los guiones de evidencia para decidir si una
 * prueba paso o fallo. Un canal que escriba {@code "cuenta-ajena"} con guion
 * en lugar de {@code "cuenta_ajena"} con guion bajo produce una respuesta que
 * a simple vista se ve perfecta: el codigo HTTP es 403, el JSON esta bien
 * formado, y aun asi la evidencia falla sin que nada apunte a la causa. Con
 * constantes, esa clase de error deja de compilar en vez de aparecer en
 * tiempo de ejecucion.
 *
 * <p><b>Por que constantes de texto y no un enum.</b> Un enum seria mas
 * elegante, pero invitaria a colgarle el codigo HTTP a cada valor, y ese
 * codigo es justamente la decision que cada canal debe tomar por su cuenta.
 * Dejandolo como texto plano, la clase no puede crecer hacia la politica.
 *
 * <p><b>Quien NO usa esta clase, y por que no es un descuido.</b> El
 * {@code core-service} escribe los mismos literales a mano. No puede importar
 * estas constantes porque el contrato le prohibe depender de
 * {@code plataforma-comun}: no emite tokens ni consume el core, asi que no
 * necesita nada de esta libreria, y agregar la dependencia por cuatro cadenas
 * haria ficticia la frontera entre el backend de dominio y los canales. Para el
 * core, la fuente compartida es el documento y no este archivo; el costo es que
 * un cambio de grafia aqui obliga a revisar {@code ManejadorErroresCore} a
 * mano, y esta acotado a los cuatro motivos que el core emite.
 *
 * <p>Lo que deliberadamente NO esta aqui: la tabla de {@code codigoPantalla} y
 * {@code mensajePantalla} de la seccion 7.2 del contrato. Esos dos campos
 * existen solo en el canal del cajero y su tabla vive en {@code bff-atm}.
 */
public final class MotivosError {

    // --- 401: fallo de AUTENTICACION. No se quien eres. -------------------

    /** No llego la cabecera {@code Authorization}. */
    public static final String TOKEN_AUSENTE = "token_ausente";
    /** El token es legitimo pero su {@code exp} ya paso. */
    public static final String TOKEN_EXPIRADO = "token_expirado";
    /** La firma no verifica contra la clave publica del canal: el token fue emitido por otro. */
    public static final String FIRMA_INVALIDA = "firma_invalida";
    /** El claim {@code aud} no nombra a este canal. Es la barrera semantica entre canales. */
    public static final String AUDIENCIA_INVALIDA = "audiencia_invalida";
    /** Usuario y clave, o tarjeta y PIN, no coinciden. */
    public static final String CREDENCIALES_INVALIDAS = "credenciales_invalidas";
    /** El {@code X-Device-Id} de la peticion no es el que quedo grabado en el token. Solo movil. */
    public static final String DISPOSITIVO_NO_COINCIDE = "dispositivo_no_coincide";
    /** El claim {@code terminal} del token no esta entre los terminales registrados. Solo cajero. */
    public static final String TERMINAL_NO_REGISTRADO = "terminal_no_registrado";

    // --- 403: fallo de AUTORIZACION. Se quien eres y no puedes. -----------

    /** El token es valido pero le falta la autoridad que el endpoint exige. */
    public static final String PERMISO_INSUFICIENTE = "permiso_insuficiente";
    /** La operacion existe en el sistema pero no en este canal. */
    public static final String OPERACION_NO_DISPONIBLE_EN_CANAL = "operacion_no_disponible_en_canal";
    /**
     * El claim {@code cuentaId} del token no coincide con la cuenta pedida.
     * Es 403 y no 404 a proposito: el recurso existe, lo que falta es el derecho.
     */
    public static final String CUENTA_AJENA = "cuenta_ajena";

    // --- 400 y 405: la peticion viene mal, no el permiso ------------------

    /**
     * 400: la peticion esta mal formada y reintentarla igual siempre fallara.
     *
     * <p>Lo emiten el {@code core-service} y {@code bff-web}. El canal web lo
     * reserva para sus <b>parametros de consulta</b> ({@code ?desde},
     * {@code ?tipo}, {@code ?size}); movil y cajero no emiten por parametros porque
     * no exponen ninguno. Un identificador de ruta que no es un numero no cae
     * aqui: es 404 en los tres canales, porque un identificador ilegible no
     * nombra ninguna cuenta, igual que uno que no existe.
     *
     * <p>Tambien cubre el <b>cuerpo</b> que no se puede leer: 400 si no es JSON
     * valido y 415 si el {@code Content-Type} no es {@code application/json}.
     * Lo emiten el core, web y movil (el cajero responde 401 en el login, ver su
     * manejador). Es la misma idea, reintentar igual siempre fallara, y asi no se
     * agrega un motivo fuera de la seccion 7.1.
     */
    public static final String PETICION_INVALIDA = "peticion_invalida";
    /**
     * 405: la ruta existe y no acepta ese verbo.
     *
     * <p>Lo emiten el core, web y movil, que hablan con quien integra y para
     * quien "la ruta es correcta, el verbo no" es una pista util. El
     * <b>cajero no lo emite nunca</b>: responde 404, porque un 405 lleva la
     * cabecera {@code Allow} y le confirma a quien sondea la maquina que la
     * ruta existe y con que verbo usarla, que es informacion gratis para el
     * que sondea en via publica. Seccion 7.1 del contrato.
     */
    public static final String METODO_NO_PERMITIDO = "metodo_no_permitido";

    // --- 404, 409, 422, 423, 500, 503 ------------------------------------

    /** El recurso no existe en este canal. */
    public static final String RECURSO_NO_ENCONTRADO = "recurso_no_encontrado";
    /** 409: el saldo no alcanza para el retiro pedido. */
    public static final String SALDO_INSUFICIENTE = "saldo_insuficiente";
    /** 422: el monto no es multiplo del billete minimo. */
    public static final String MONTO_NO_MULTIPLO = "monto_no_multiplo";
    /** 422: el monto esta bajo el minimo por operacion. */
    public static final String MONTO_BAJO_MINIMO = "monto_bajo_minimo";
    /** 422: el monto supera el tope por transaccion. */
    public static final String SUPERA_TOPE_TRANSACCION = "supera_tope_transaccion";
    /**
     * 422: la misma {@code Idempotency-Key} ya se uso en esa cuenta para retirar otro importe.
     *
     * <p>Lo decide el core (la idempotencia vive donde esta el estado) y el cajero lo reenvia. No tiene
     * fila en la tabla de pantallas de la seccion 7.2 del contrato: el cajero lo emite sin
     * {@code codigoPantalla}, y es un defecto del firmware que genera la clave, no algo que el cliente
     * final pueda corregir tecleando otra cosa.
     */
    public static final String CLAVE_IDEMPOTENCIA_REUTILIZADA = "clave_idempotencia_reutilizada";
    /** 423: la tarjeta quedo bloqueada por PIN fallido. */
    public static final String PIN_BLOQUEADO = "pin_bloqueado";
    /**
     * 500: defecto del propio servicio, no culpa del cliente.
     *
     * <p>Es el motivo de la red de seguridad de cada canal, ese
     * {@code @ExceptionHandler(Exception.class)} que existe para que ninguna
     * respuesta se salga del formato RFC 7807 ni siquiera cuando el error es un
     * fallo del codigo. <b>No se confunde con {@link #CORE_NO_DISPONIBLE}</b>,
     * que es 503: aquel dice "mi dependencia se cayo, revisa el core"; este
     * dice "fallé yo, revisa el canal". Un solo valor para los dos casos manda
     * a quien diagnostica al servicio equivocado la mitad de las veces.
     */
    public static final String ERROR_INTERNO = "error_interno";
    /** 503: el {@code core-service} no respondio. Es el motivo de la degradacion controlada. */
    public static final String CORE_NO_DISPONIBLE = "core_no_disponible";
    /**
     * 503: el canal no pudo VERIFICAR el token porque el {@code auth-server} no entrego sus claves publicas
     * (caido o inalcanzable y sin claves en cache). No es un 401: el token del cliente puede ser perfectamente
     * valido y repetir el login no lo arreglaria. Desde F5 los canales validan con el JWKS del servidor de
     * autorizacion, asi que esta dependencia existe y su caida tiene que verse como lo que es.
     */
    public static final String AUTENTICACION_NO_DISPONIBLE = "autenticacion_no_disponible";

    /**
     * Constructor privado: esta clase es un contenedor de constantes y no tiene
     * sentido instanciarla. Sin esta linea, Java generaria un constructor
     * publico por defecto y alguien podria escribir {@code new MotivosError()},
     * que no significa nada.
     */
    private MotivosError() {
    }
}
