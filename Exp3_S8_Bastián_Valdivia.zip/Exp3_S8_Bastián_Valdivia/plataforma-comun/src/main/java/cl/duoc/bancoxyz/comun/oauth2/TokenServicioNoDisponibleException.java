package cl.duoc.bancoxyz.comun.oauth2;

import org.springframework.security.oauth2.core.OAuth2AuthorizationException;

/**
 * El auth-server no entrego el token de servicio por una falla de INFRAESTRUCTURA: no respondio, vencio
 * el timeout o contesto con un error suyo (5xx).
 *
 * <p>Es la unica excepcion que el CircuitBreaker y el Retry de la instancia {@code auth-server} tratan
 * como fallo y como reintentable. Un rechazo de credenciales ({@code invalid_client}: el secreto del
 * cliente esta mal) NO lo es: es un error de configuracion que repetir no arregla, y contarlo abriria el
 * circuito por un problema que el circuito no puede resolver. Se queda como
 * {@link OAuth2AuthorizationException} y sale tal cual.
 *
 * <p>Es publica y de primer nivel (no anidada) para poder nombrarla en
 * {@code resilience4j.*.instances.auth-server.record-exceptions} de {@code config-repo/}.
 */
public class TokenServicioNoDisponibleException extends RuntimeException {

    public TokenServicioNoDisponibleException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
