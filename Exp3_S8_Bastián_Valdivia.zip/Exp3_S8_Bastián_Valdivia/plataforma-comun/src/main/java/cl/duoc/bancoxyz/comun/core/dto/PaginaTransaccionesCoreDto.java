package cl.duoc.bancoxyz.comun.core.dto;

import java.util.List;

/**
 * Pagina del lote no conciliado, endpoint C7 del core (seccion 5.15 del
 * contrato).
 *
 * <p><b>Por que este endpoint esta paginado y no devuelve las 1000 filas de
 * una vez.</b> Por la misma razon que los movimientos: una respuesta cuyo
 * tamano depende del tamano del archivo es una respuesta sin tope. Hoy son
 * 1000 filas y cabrian; el dia que el archivo tenga 100.000, el endpoint deja
 * de responder y nadie cambio una linea de codigo.
 *
 * <p>Notese que, a diferencia de {@link PaginaMovimientosCoreDto}, aqui no hay
 * {@code cuentaId}: estas filas no pertenecen a ninguna cuenta. Esa ausencia
 * es el contrato diciendo la verdad sobre los datos.
 *
 * @param transacciones filas de esta pagina, tal como vienen del archivo
 * @param paginacion    metadatos para recorrer el lote completo
 */
public record PaginaTransaccionesCoreDto(
        List<TransaccionNoConciliadaCoreDto> transacciones,
        PaginacionCoreDto paginacion) {

    /** Lista nula a lista vacia, igual que en el resto del paquete. */
    public PaginaTransaccionesCoreDto {
        transacciones = transacciones == null ? List.of() : List.copyOf(transacciones);
    }
}
