package cl.duoc.bancoxyz.comun.core;

/**
 * El {@code core-service} no respondio, o respondio con un error suyo (5xx).
 *
 * <p>Cubre tres situaciones que desde el BFF se ven igual y se tratan igual:
 * <ul>
 *   <li>el core no esta levantado, y la conexion se rechaza de inmediato;</li>
 *   <li>el core esta levantado pero no contesta a tiempo, y salta el timeout
 *       de lectura configurado por el canal;</li>
 *   <li>el core contesta con un 500 o un 503 propio.</li>
 * </ul>
 *
 * <p><b>Por que las tres juntas.</b> Porque la decision del canal es la misma
 * en las tres: responder {@code core_no_disponible} y no un error 500 con
 * rastro de pila. Separarlas obligaria a cada BFF a escribir tres
 * {@code catch} que hacen lo mismo. La diferencia entre ellas queda en
 * {@link CoreException#estadoDelCore()} y en la causa, que es donde sirve: en
 * el log del operador, no en la logica del canal.
 *
 * <p><b>Rol en la evidencia.</b> Esta excepcion es la que sostiene la prueba
 * de degradacion controlada: se detiene el core, se repite una consulta, y el
 * BFF debe responder un 503 con {@code motivo} igual a
 * {@code core_no_disponible}, con su cuerpo RFC 7807 bien formado. Que el
 * sistema falle de forma prevista y descriptible cuando su dependencia se cae
 * es tan parte de la calidad como que funcione cuando todo esta bien.
 */
public class CoreNoDisponibleException extends CoreException {

    public CoreNoDisponibleException(String mensaje,
                                     String rutaSolicitada,
                                     Integer estadoDelCore,
                                     String cuerpoCrudo,
                                     Throwable causa) {
        super(mensaje, rutaSolicitada, estadoDelCore, cuerpoCrudo, causa);
    }
}
