package cl.duoc.bancoxyz.comun.resiliencia;

import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.comun.core.CoreCircuitoAbiertoException;
import cl.duoc.bancoxyz.comun.core.CoreClient;
import cl.duoc.bancoxyz.comun.core.CoreSaturadoException;
import cl.duoc.bancoxyz.comun.core.RestCoreClient;
import cl.duoc.bancoxyz.comun.core.dto.ConsultaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaTransaccionesCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto;
import io.github.resilience4j.bulkhead.Bulkhead;
import io.github.resilience4j.bulkhead.BulkheadFullException;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * El {@link CoreClient} que usan los canales: protege cada llamada al core con un
 * <b>mamparo</b> (Bulkhead), un <b>cortacircuitos</b> (CircuitBreaker) y <b>reintentos</b> (Retry), y
 * delega el trabajo real en {@link RestCoreClient}.
 *
 * <h2>Por que es un decorador y no codigo en cada servicio de canal</h2>
 *
 * <p>Los tres BFF dependen del puerto {@link CoreClient}, no de su adaptador HTTP. Interponer la
 * proteccion en ESE punto da dos cosas que ningun otro sitio da: (1) <b>todas</b> las llamadas al core
 * quedan protegidas, incluidas las que alguien agregue manana, sin que nadie tenga que recordarlo;
 * (2) los servicios de canal no cambian ni una linea. Esta clase es {@link Primary}: donde el codigo
 * pide un {@code CoreClient}, recibe este. {@link RestCoreClient} sigue existiendo como bean para
 * que este decorador lo use, y nadie mas lo inyecta.
 *
 * <h2>El orden importa: Retry( CircuitBreaker( Bulkhead( llamada ) ) )</h2>
 *
 * <pre>
 *   Retry            reintenta lo que falla por causas pasajeras (con espera creciente)
 *    CircuitBreaker  corta cuando las fallas dejan de ser pasajeras
 *     Bulkhead       limita cuantas llamadas simultaneas puede haber
 *      llamada       RestCoreClient: HTTP con timeouts de conexion y de lectura
 * </pre>
 *
 * <ul>
 *   <li><b>El Retry envuelve al CircuitBreaker</b> (es el orden por defecto de Resilience4j y el
 *       correcto): cada intento pasa por el circuito y cuenta en el, de modo que tres fallos seguidos
 *       de una misma peticion cuentan como tres fallos y no como uno. Y cuando el circuito esta
 *       abierto, el Retry ve de inmediato la {@code CallNotPermittedException}, que no esta en su
 *       lista de excepciones reintentables, y no insiste: reintentar contra un circuito abierto
 *       seria gastar la espera del backoff para recibir el mismo rechazo. Si fuera al reves (el
 *       circuito envolviendo al retry), una peticion con tres intentos fallidos contaria como UN solo
 *       fallo y el circuito tardaria tres veces mas en abrir.</li>
 *   <li><b>El Bulkhead es lo mas interno</b>: cada intento adquiere y suelta su propio permiso, de
 *       modo que mientras el Retry espera su backoff no ocupa un lugar del mamparo.</li>
 * </ul>
 *
 * <h2>Que cuenta como fallo y que no</h2>
 *
 * <p>El circuito registra como fallo solo {@code CoreNoDisponibleException}: conexion rechazada,
 * timeout de conexion o de lectura, balanceador sin instancias y respuestas 5xx. Un 404, un 409
 * (saldo insuficiente), un 422 o un 401/403 del token de servicio son respuestas <b>validas</b> del core: es
 * una decision de negocio, no una falla de infraestructura, y por tanto cuentan como llamadas exitosas
 * para el circuito. Un usuario que pide cien veces una cuenta inexistente NO debe abrir el circuito de
 * todos los demas (lo prueban {@code CoreClientResilienteTest} y las pruebas de cada canal). El Retry,
 * por la misma razon, solo reintenta {@code CoreNoDisponibleException}.
 *
 * <h2>Que se reintenta y que no</h2>
 *
 * <p>Se reintenta toda lectura (GET) porque repetirla no cambia nada. El unico POST, el retiro, se
 * reintenta <b>solo porque viaja con su {@code Idempotency-Key}</b>: si el primer intento llego al
 * core y la respuesta se perdio, el segundo devuelve el mismo folio sin descontar dos veces. Un retiro
 * sin clave NO se reintenta (reintentarlo duplicaria el descuento).
 *
 * <h2>Por que no hay TimeLimiter</h2>
 *
 * <p>El {@code TimeLimiter} de Resilience4j cancela un {@code Future}: solo sirve para llamadas
 * asincronas. Esta llamada es bloqueante, asi que el limite de tiempo es el del cliente HTTP
 * ({@code core.timeout-conexion} y {@code core.timeout-lectura}), que corta la lectura de verdad y
 * libera el hilo. El CircuitBreaker ademas mide la lentitud ({@code slowCallDurationThreshold}).
 *
 * <h2>Lo que reciben los canales</h2>
 *
 * <p>Los rechazos de Resilience4j se traducen a {@link CoreCircuitoAbiertoException} y
 * {@link CoreSaturadoException}, ambas {@code CoreNoDisponibleException}: ningun canal conoce los tipos
 * de la libreria. Cada canal decide su respaldo (web y movil: el ultimo dato conocido marcado como
 * desactualizado, o 503; cajero: 503 siempre, jamas un dato inventado).
 */
@Component
@Primary
public class CoreClientResiliente implements CoreClient {

    private static final Logger log = LoggerFactory.getLogger(CoreClientResiliente.class);

    /** Nombre de la instancia en {@code resilience4j.circuitbreaker|retry|bulkhead.instances.*}. */
    public static final String INSTANCIA = "core";

    /** Nombre del contador de llamadas que ni siquiera se intentaron. */
    public static final String METRICA_RECHAZOS = "bancoxyz.core.rechazos";

    private final RestCoreClient http;
    private final CircuitBreaker circuito;
    private final Retry reintento;
    private final Bulkhead mamparo;
    private final Counter rechazosPorCircuito;
    private final Counter rechazosPorMamparo;

    public CoreClientResiliente(RestCoreClient http,
                                CircuitBreakerRegistry circuitos,
                                RetryRegistry reintentos,
                                BulkheadRegistry mamparos,
                                ObjectProvider<MeterRegistry> metricas) {
        this.http = http;
        this.circuito = circuitos.circuitBreaker(INSTANCIA);
        this.reintento = reintentos.retry(INSTANCIA);
        this.mamparo = mamparos.bulkhead(INSTANCIA);

        MeterRegistry registro = metricas.getIfAvailable();
        this.rechazosPorCircuito = contador(registro, "circuito_abierto");
        this.rechazosPorMamparo = contador(registro, "mamparo_lleno");

        // Todo cambio de estado del circuito queda en el log: es la evidencia mas directa de que el
        // mecanismo actuo (ademas de /actuator/circuitbreakerevents).
        this.circuito.getEventPublisher()
                .onStateTransition(evento -> log.warn("Circuito '{}' del core: {}",
                        INSTANCIA, evento.getStateTransition()));
        this.reintento.getEventPublisher()
                .onRetry(evento -> log.warn("Reintento {} de {} hacia el core tras: {}",
                        evento.getNumberOfRetryAttempts(), reintento.getRetryConfig().getMaxAttempts() - 1,
                        evento.getLastThrowable() == null ? "?" : evento.getLastThrowable().getMessage()));
    }

    @Override
    public CuentaCoreDto obtenerCuenta(int cuentaId) {
        return proteger("obtenerCuenta", true, () -> http.obtenerCuenta(cuentaId));
    }

    @Override
    public SaldoCoreDto obtenerSaldo(int cuentaId) {
        return proteger("obtenerSaldo", true, () -> http.obtenerSaldo(cuentaId));
    }

    @Override
    public PaginaMovimientosCoreDto obtenerMovimientos(int cuentaId, ConsultaMovimientosCoreDto consulta) {
        return proteger("obtenerMovimientos", true, () -> http.obtenerMovimientos(cuentaId, consulta));
    }

    @Override
    public RetiroCoreDto ejecutarRetiro(int cuentaId, SolicitudRetiroCoreDto solicitud, String claveIdempotencia) {
        // Sin clave no hay garantia de que repetir sea seguro: se protege con el circuito y el mamparo,
        // pero un fallo se informa tal cual y no se reintenta.
        boolean reintentable = claveIdempotencia != null && !claveIdempotencia.isBlank();
        return proteger("ejecutarRetiro", reintentable,
                () -> http.ejecutarRetiro(cuentaId, solicitud, claveIdempotencia));
    }

    @Override
    public ReporteCalidadCoreDto obtenerCalidadDatos() {
        return proteger("obtenerCalidadDatos", true, http::obtenerCalidadDatos);
    }

    @Override
    public PaginaTransaccionesCoreDto obtenerTransaccionesNoConciliadas(int pagina, int tamano) {
        return proteger("obtenerTransaccionesNoConciliadas", true,
                () -> http.obtenerTransaccionesNoConciliadas(pagina, tamano));
    }

    /**
     * Aplica Retry( CircuitBreaker( Bulkhead( llamada ) ) ) y traduce los rechazos de la libreria.
     *
     * @param operacion   nombre de la operacion, solo para el mensaje y el log
     * @param reintentable {@code true} si repetir la llamada es seguro (lecturas y retiro con clave)
     */
    private <T> T proteger(String operacion, boolean reintentable, Supplier<T> llamada) {
        Supplier<T> protegida = Bulkhead.decorateSupplier(mamparo, llamada);
        protegida = CircuitBreaker.decorateSupplier(circuito, protegida);
        if (reintentable) {
            protegida = Retry.decorateSupplier(reintento, protegida);
        }
        try {
            return protegida.get();
        } catch (CallNotPermittedException abierto) {
            rechazosPorCircuito.increment();
            log.warn("Llamada {} al core rechazada sin intentarla: el circuito esta {}",
                    operacion, circuito.getState());
            throw new CoreCircuitoAbiertoException(
                    "El circuito del core esta " + circuito.getState() + ": " + operacion
                            + " no se intento.", operacion, abierto);
        } catch (BulkheadFullException lleno) {
            rechazosPorMamparo.increment();
            log.warn("Llamada {} al core rechazada sin intentarla: el mamparo esta lleno ({} simultaneas como maximo)",
                    operacion, mamparo.getBulkheadConfig().getMaxConcurrentCalls());
            throw new CoreSaturadoException(
                    "El mamparo del core esta lleno: " + operacion + " no se intento.", operacion, lleno);
        }
    }

    private static Counter contador(MeterRegistry registro, String motivo) {
        if (registro == null) {
            return Counter.builder(METRICA_RECHAZOS).tag("motivo", motivo).register(
                    new io.micrometer.core.instrument.simple.SimpleMeterRegistry());
        }
        return Counter.builder(METRICA_RECHAZOS)
                .description("Llamadas al core rechazadas sin intentarlas (circuito abierto o mamparo lleno)")
                .tag("motivo", motivo)
                .register(registro);
    }
}
