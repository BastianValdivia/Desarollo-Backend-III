package cl.duoc.bancoxyz.comun.core;

/**
 * El core devolvio 404: la cuenta pedida no existe en el dominio.
 *
 * <p><b>La distincion que hay que tener clara para no implementarlo mal.</b>
 * Esta excepcion significa "no existe", y es distinta de "existe y no es
 * tuya". Pedir la cuenta 999, que no esta en el dataset, llega hasta aqui.
 * Pedir la cuenta 105 con un token de la 116 NO llega hasta aqui: ese caso lo
 * corta el canal antes de salir a la red, comparando el claim
 * {@code cuentaId} del token con la variable de ruta, y responde 403
 * {@code cuenta_ajena}.
 *
 * <p>Confundir los dos casos tiene consecuencias reales en las dos
 * direcciones. Responder 404 a una cuenta ajena convierte la API en un
 * detector de cuentas existentes por diferencia de respuestas. Responder 403 a
 * una cuenta inexistente le dice al cliente que la cuenta 999 existe, que es
 * falso. El contrato es explicito: el recurso existe, lo que falta es el
 * derecho, y por eso la cuenta ajena es 403.
 */
public class CoreRecursoNoEncontradoException extends CoreException {

    public CoreRecursoNoEncontradoException(String mensaje,
                                            String rutaSolicitada,
                                            String cuerpoCrudo) {
        super(mensaje, rutaSolicitada, 404, cuerpoCrudo, null);
    }
}
