package cl.duoc.bancoxyz.comun.core.dto;

import java.util.List;

/**
 * Una pagina de movimientos devuelta por el endpoint C4 del core,
 * {@code GET /internal/v1/cuentas/{id}/movimientos} (seccion 5.7 del contrato).
 *
 * <p><b>Rol en la arquitectura.</b> Es el otro endpoint estrecho aguas arriba:
 * permite que web pida los veinte movimientos de la primera pagina en vez de
 * los 42 de la cuenta completa. La paginacion no es solo comodidad de
 * interfaz; es el mecanismo que acota cuanto puede crecer una respuesta
 * independientemente de cuantos movimientos tenga la cuenta.
 *
 * @param cuentaId    cuenta a la que pertenecen los movimientos
 * @param movimientos elementos de esta pagina. Vacio, nunca nulo
 * @param paginacion  metadatos para saber si hay mas paginas
 */
public record PaginaMovimientosCoreDto(
        int cuentaId,
        List<MovimientoCoreDto> movimientos,
        PaginacionCoreDto paginacion) {

    /** Misma defensa de lista nula que {@link CuentaCoreDto}, y por el mismo motivo. */
    public PaginaMovimientosCoreDto {
        movimientos = movimientos == null ? List.of() : List.copyOf(movimientos);
    }
}
