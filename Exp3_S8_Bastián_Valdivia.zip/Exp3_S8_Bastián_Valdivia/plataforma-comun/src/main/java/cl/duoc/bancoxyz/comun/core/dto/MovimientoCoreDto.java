package cl.duoc.bancoxyz.comun.core.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Un movimiento tal como lo devuelve el {@code core-service} (seccion 5.4 del
 * contrato). Lleva CINCO campos; las proyecciones de cada canal llevan menos.
 *
 * <p><b>Por que {@code LocalDate} y no {@code String}.</b> El CSV de origen
 * trae cuatro formatos de fecha conviviendo ({@code dd-MM-yyyy},
 * {@code yyyy-MM-dd}, {@code yyyy/MM/dd} y {@code dd/MM/yyyy}), y el core los
 * normaliza a ISO-8601 antes de publicarlos. Recibir aqui un tipo de fecha de
 * verdad, y no una cadena, cierra la puerta a que ese desorden se cuele en los
 * BFF: una cadena se puede comparar o cortar por posicion sin darse cuenta,
 * una {@code LocalDate} obliga a tratarla como fecha. Ademas el canal web
 * necesita agrupar por mes para su resumen mensual, y eso con una cadena es
 * aritmetica de substrings.
 *
 * @param fecha       dia del movimiento, ya normalizado por el core
 * @param tipo        {@code DEPOSITO}, {@code RETIRO}, {@code COMPRA} o {@code PAGO}
 * @param monto       importe. Ver la nota de signo mas abajo
 * @param descripcion texto decorativo del CSV. Puede ser {@code null} y puede contradecir al tipo
 * @param origen      {@code CSV_SEMILLA} si vino del archivo, {@code RETIRO_ATM} si lo genero un retiro
 */
public record MovimientoCoreDto(
        LocalDate fecha,
        String tipo,
        BigDecimal monto,
        String descripcion,
        String origen) {

    // Nota sobre el signo, congelada en el contrato: el monto es SIEMPRE
    // positivo y la direccion del dinero vive en el campo "tipo". El CSV de
    // origen trae 254 montos negativos y la tentacion es conservar el signo,
    // pero entonces cada canal tendria que decidir por su cuenta si un retiro
    // de -3000 y uno de 3000 son lo mismo, y tarde o temprano dos canales
    // deciden distinto. Con el signo en el tipo, sumar abonos es filtrar por
    // tipo y sumar, sin ninguna regla de signo que recordar.

    // Nota sobre "descripcion": el contrato advierte que puede contradecir al
    // tipo (una fila marcada RETIRO con descripcion "Deposito mensual"). Manda
    // el tipo. La descripcion es texto de adorno del archivo legado y no se
    // debe usar para clasificar nada.
}
