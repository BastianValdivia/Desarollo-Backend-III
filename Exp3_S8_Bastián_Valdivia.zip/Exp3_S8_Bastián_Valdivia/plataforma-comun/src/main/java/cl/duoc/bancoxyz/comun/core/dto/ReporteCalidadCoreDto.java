package cl.duoc.bancoxyz.comun.core.dto;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Reporte de calidad de la ingesta, endpoint C6 del core (seccion 5.14 del
 * contrato). Solo el canal web lo expone, y solo al perfil de ejecutivo.
 *
 * <p><b>Rol en la arquitectura: este objeto es una declaracion de honestidad
 * sobre los datos.</b> El dataset legado esta sucio de verdad: 211 saldos
 * vacios, 279 tipos con valor {@code -1}, 52 con {@code unknown}, montos
 * negativos, montos en cero y cuatro formatos de fecha conviviendo. Un sistema
 * puede hacer dos cosas con eso: esconderlo, o contarlo. Contarlo es lo que
 * permite a alguien decidir si confia en una cifra, y por eso el reporte es un
 * endpoint de la API y no una linea en el log de arranque que nadie vuelve a
 * mirar.
 *
 * <p><b>Por que {@code descartesPorMotivo} es un {@code Map} y no un record de
 * cinco campos.</b> Es la unica concesion de este paquete, y tiene motivo: el
 * contrato congela cinco claves ({@code SALDO_INVALIDO}, {@code TIPO_INVALIDO},
 * {@code EDAD_FUERA_DE_RANGO}, {@code MONTO_NO_POSITIVO},
 * {@code FECHA_ILEGIBLE}) y exige que las cinco aparezcan aunque valgan cero,
 * pero la lista de motivos es lo que mas probablemente crezca cuando aparezca
 * una trampa nueva en los datos. Con un {@code Map}, un motivo nuevo llega a
 * los tres BFF sin recompilar nada; con un record, agregar un motivo obliga a
 * tocar la libreria compartida y los tres canales. Aqui la tolerancia vale mas
 * que el tipado, porque ningun canal razona sobre estas claves: las muestra.
 *
 * @param generadoEn                instante UTC en que se ejecuto la ingesta
 * @param archivos                  un elemento por archivo leido
 * @param descartesPorMotivo        cuantas filas se descartaron por cada motivo
 * @param cuentasConsolidadas       debe ser 50
 * @param movimientosCargados       debe ser 686
 * @param transaccionesNoConciliadas debe ser 1000
 */
public record ReporteCalidadCoreDto(
        Instant generadoEn,
        List<ArchivoCalidadCoreDto> archivos,
        Map<String, Integer> descartesPorMotivo,
        int cuentasConsolidadas,
        int movimientosCargados,
        int transaccionesNoConciliadas) {

    /** Colecciones nulas a colecciones vacias, por el mismo motivo que en {@link CuentaCoreDto}. */
    public ReporteCalidadCoreDto {
        archivos = archivos == null ? List.of() : List.copyOf(archivos);
        descartesPorMotivo = descartesPorMotivo == null ? Map.of() : Map.copyOf(descartesPorMotivo);
    }
}
