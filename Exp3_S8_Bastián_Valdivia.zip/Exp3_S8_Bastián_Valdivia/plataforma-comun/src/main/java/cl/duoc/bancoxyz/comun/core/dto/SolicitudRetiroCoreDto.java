package cl.duoc.bancoxyz.comun.core.dto;

import java.math.BigDecimal;

/**
 * Cuerpo de la peticion del endpoint C5 del core,
 * {@code POST /internal/v1/cuentas/{id}/retiros} (seccion 5.12 del contrato).
 *
 * <p><b>Un solo campo, y es a proposito.</b> La cuenta viaja en la ruta y la
 * clave de idempotencia viaja en la cabecera {@code Idempotency-Key}, no en el
 * cuerpo. Repetir la cuenta dentro del JSON abriria la posibilidad de que la
 * ruta diga 116 y el cuerpo diga 106, y entonces el core tendria que decidir
 * cual manda: un conflicto que es mas facil no crear que resolver.
 *
 * <p><b>Que validaciones NO estan aqui.</b> Ninguna de las reglas del retiro:
 * ni el multiplo de 1.000, ni el minimo, ni el tope por transaccion. Esas tres
 * son reglas de negocio del canal del cajero, con valores en su
 * {@code config-repo/bff-atm.yml} y con un orden de evaluacion congelado que determina
 * cual de los tres errores 422 sale. Si vivieran en este record, el canal
 * perderia el control de ese orden y los tres BFF heredarian reglas de un
 * canal en el que dos de ellos ni siquiera pueden retirar dinero.
 *
 * @param monto importe a retirar. Positivo, en pesos chilenos
 */
public record SolicitudRetiroCoreDto(BigDecimal monto) {
}
