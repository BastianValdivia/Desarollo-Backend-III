package cl.duoc.bancoxyz.comun.error;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletResponse;

/**
 * Escribe un cuerpo de error directamente en la respuesta HTTP, sin pasar por
 * el mecanismo normal de serializacion de Spring MVC.
 *
 * <p><b>Rol en la arquitectura: esta clase existe por un motivo muy concreto y
 * vale la pena entenderlo antes de usarla.</b> En un BFF, casi todos los
 * errores los formatea un {@code @RestControllerAdvice}: el controlador lanza
 * una excepcion, el advice la captura y devuelve un objeto que Spring
 * serializa. Pero hay dos beans que corren FUERA de ese camino:
 * <ul>
 *   <li>el {@code AuthenticationEntryPoint}, que responde el 401 cuando falta
 *       el token o es invalido, y</li>
 *   <li>el {@code AccessDeniedHandler}, que responde el 403 cuando el token es
 *       valido pero no alcanza.</li>
 * </ul>
 * Los dos se ejecutan dentro de la cadena de filtros de Spring Security, antes
 * de que exista un controlador al que el advice pueda envolver. Si no se hace
 * nada, esos dos casos devuelven la pagina de error generica de Spring, que no
 * se parece en nada al resto de la API.
 *
 * <p>El detalle cruel es que esos dos casos son precisamente los que prueban
 * la autenticacion (401) y la autorizacion (403), es decir la evidencia mas
 * mirada de todo el proyecto. Un sistema con un formato de error impecable en
 * todas partes menos en 401 y 403 se ve peor que uno consistente.
 *
 * <p><b>Por que vive en la libreria compartida.</b> Escribir a mano el estado,
 * el {@code Content-Type} y el cuerpo es plomeria: los tres canales la
 * necesitan identica. QUE se escribe (el estado, el motivo, el detalle, y si
 * el canal agrega campos de pantalla) es politica y queda del lado del que
 * llama. De ahi la firma: esta clase recibe el estado ya decidido y el cuerpo
 * ya construido, y no mira su contenido.
 *
 * <p><b>Por que el parametro {@code cuerpo} es {@code Object} y no
 * {@link RespuestaError}.</b> Porque el canal del cajero envia su propio
 * record, con {@code codigoPantalla} y {@code mensajePantalla} ademas de los
 * siete campos base. Tipar el parametro como {@code RespuestaError} obligaria
 * a ese record a vivir aqui, que es justo lo que la seccion 4.3 del plan
 * prohibe. Se paga con perder un poco de comprobacion de tipos y se gana que
 * la libreria no sepa nada de ningun canal.
 */
@Component
public class EscritorErrorHttp {

    /**
     * Tipo de medio de RFC 7807. Se escribe como constante y no como literal
     * suelto porque un error de tipeo aqui ({@code problem-json} en vez de
     * {@code problem+json}) no rompe nada visible: la respuesta llega, el JSON
     * se ve bien, y solo un cliente que discrimine por tipo de medio se entera.
     */
    public static final String TIPO_PROBLEMA_JSON = "application/problem+json";

    private final ObjectMapper mapeador;

    /**
     * Recibe el {@code ObjectMapper} del contexto de Spring en lugar de crear
     * uno propio con {@code new}. No es un detalle menor: el mapeador del
     * contexto ya viene configurado por Spring Boot con las mismas reglas que
     * usa el resto de la API (fechas en ISO-8601 y no en milisegundos desde
     * 1970, entre otras). Uno fabricado a mano tendria las reglas por defecto
     * de Jackson, y los errores saldrian serializados distinto que las
     * respuestas exitosas del mismo servicio.
     */
    public EscritorErrorHttp(ObjectMapper mapeador) {
        this.mapeador = mapeador;
    }

    /**
     * Fija estado y tipo de medio, y escribe el cuerpo como JSON.
     *
     * <p>El orden de las operaciones importa y es la trampa clasica de este
     * metodo: una respuesta HTTP se "compromete" en cuanto se empieza a
     * escribir el cuerpo, y a partir de ese momento los cambios de estado y de
     * cabeceras se ignoran en silencio. Por eso el estado y el
     * {@code Content-Type} se fijan ANTES de tocar el flujo de salida. Si se
     * invirtiera, la respuesta saldria con un 200 y el JSON de un error 401.
     *
     * <p>Cualquier cabecera adicional (por ejemplo el {@code WWW-Authenticate:
     * Bearer} que el contrato exige acompanando a todo 401) debe fijarse sobre
     * la respuesta antes de llamar a este metodo, por la misma razon. No se
     * pone aqui porque no todos los estados la llevan, y decidir cual la lleva
     * es politica del canal.
     *
     * @param respuesta la respuesta del servlet, aun sin comprometer
     * @param estado    codigo HTTP ya decidido por quien llama
     * @param cuerpo    objeto a serializar: {@link RespuestaError} o el record propio de un canal
     * @throws IOException si el cliente corta la conexion mientras se escribe
     */
    public void escribir(HttpServletResponse respuesta, int estado, Object cuerpo) throws IOException {
        respuesta.setStatus(estado);
        respuesta.setContentType(TIPO_PROBLEMA_JSON);
        respuesta.setCharacterEncoding(StandardCharsets.UTF_8.name());
        mapeador.writeValue(respuesta.getOutputStream(), cuerpo);
    }
}
