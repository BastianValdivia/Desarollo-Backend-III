package cl.duoc.bancoxyz.comun.core.dto;

import java.time.LocalDate;

/**
 * Parametros de consulta del endpoint C4 del core,
 * {@code /internal/v1/cuentas/{id}/movimientos?page&size&desde&hasta&tipo}.
 *
 * <p><b>Por que un objeto y no cinco parametros sueltos en el metodo.</b>
 * Cuatro de los cinco son opcionales, y una firma del tipo
 * {@code obtenerMovimientos(int, int, int, LocalDate, LocalDate, String)} se
 * llama casi siempre con nulos intercalados. Peor: {@code pagina} y
 * {@code tamano} son dos enteros seguidos, asi que invertirlos compila
 * perfectamente y produce resultados absurdos en tiempo de ejecucion. Con un
 * record y metodos de fabrica con nombre, el error deja de ser posible.
 *
 * <p><b>Que NO decide esta clase.</b> No decide el tamano por defecto ni el
 * maximo permitido. El contrato fija 20 por defecto y 100 de tope para el
 * canal web, pero eso es politica de web: otro canal podria tener otro tope, y
 * el canal movil directamente no expone paginacion. Aqui solo viaja el valor
 * que el canal ya decidio.
 *
 * @param pagina indice de pagina empezando en 0
 * @param tamano elementos por pagina
 * @param desde  filtro inferior de fecha, inclusive. {@code null} para no filtrar
 * @param hasta  filtro superior de fecha, inclusive. {@code null} para no filtrar
 * @param tipo   filtro por tipo de movimiento. {@code null} para no filtrar
 */
public record ConsultaMovimientosCoreDto(
        int pagina,
        int tamano,
        LocalDate desde,
        LocalDate hasta,
        String tipo) {

    /**
     * Consulta sin filtros: solo pagina y tamano. Es el caso mas frecuente y
     * merece un nombre, para no escribir tres {@code null} seguidos en cada
     * llamada (que es como termina alguien pasandolos en el orden equivocado).
     */
    public static ConsultaMovimientosCoreDto de(int pagina, int tamano) {
        return new ConsultaMovimientosCoreDto(pagina, tamano, null, null, null);
    }

    /**
     * Rechaza valores imposibles en el momento de construir la consulta, no
     * cuando el core devuelve una respuesta rara.
     *
     * <p>Un {@code tamano} de cero devolveria una pagina vacia de una cuenta
     * que si tiene movimientos, y una {@code pagina} negativa suele terminar
     * en un error 500 del lado del core. Los dos son fallos cuyo sintoma
     * aparece lejos de la causa; fallar aqui deja el error a un paso del
     * codigo que lo provoco.
     */
    public ConsultaMovimientosCoreDto {
        if (pagina < 0) {
            throw new IllegalArgumentException("La pagina empieza en 0 y no puede ser negativa: " + pagina);
        }
        if (tamano <= 0) {
            throw new IllegalArgumentException("El tamano de pagina debe ser mayor que cero: " + tamano);
        }
    }
}
