package cl.duoc.bancoxyz.comun.oauth2;

import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.security.oauth2.resource.servlet.JwkSetUriJwtDecoderBuilderCustomizer;
import org.springframework.boot.ssl.NoSuchSslBundleException;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.boot.web.client.ClientHttpRequestFactories;
import org.springframework.boot.web.client.ClientHttpRequestFactorySettings;
import org.springframework.cache.Cache;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * Como los BFF descargan las claves publicas del {@code auth-server} para verificar los tokens de usuario.
 *
 * <p><strong>Que cambia con la delegacion completa (F5).</strong> Hasta F4 cada BFF firmaba y validaba sus propios
 * tokens con su propio par de claves, guardadas en su volumen. Ahora el unico emisor es el servidor de
 * autorizacion: los BFF solo VALIDAN, con la clave publica que este publica en {@code /oauth2/jwks}. Ningun BFF
 * tiene ya una clave privada de firma.
 *
 * <p>Spring Boot construye el decodificador a partir de {@code jwk-set-uri}, {@code issuer-uri} y
 * {@code audiences} (con las dos primeras juntas no hay descubrimiento OIDC: no llama al servidor para
 * averiguar nada). Lo unico a medida es QUE CA se acepta al descargar el JWKS por HTTPS: la CA interna del
 * proyecto y ninguna mas, con el bundle SSL {@code interna} que ya usa el cliente de tokens de servicio, y con
 * tiempos de espera de 2 s para que un auth-server caido no deje colgadas las peticiones. Sin ese bundle (en
 * local, donde el auth-server habla HTTP) la descarga usa la configuracion normal de la JVM.
 *
 * <p>El decodificador guarda las claves en una cache sin vencimiento y solo vuelve a descargarlas ante un
 * {@code kid} desconocido, asi que una caida del auth-server (de cualquier duracion) no tumba a los BFF mientras las
 * claves sigan siendo las mismas. Lo comprueba {@code ConfianzaEnElAuthServerConfigTest}.
 */
@Configuration(proxyBeanMethods = false)
public class ConfianzaEnElAuthServerConfig {

    private static final Logger log = LoggerFactory.getLogger(ConfianzaEnElAuthServerConfig.class);

    /** Nombre del bundle SSL (truststore con solo la CA interna) que define {@code config-repo/<bff>-docker.yml}. */
    static final String BUNDLE_DE_CONFIANZA = "interna";

    @Bean
    public JwkSetUriJwtDecoderBuilderCustomizer descargaDeClavesConLaCaInterna(
            SslBundles bundles,
            @Value("${seguridad.jwks.timeout-conexion:2s}") Duration timeoutConexion,
            @Value("${seguridad.jwks.timeout-lectura:2s}") Duration timeoutLectura) {
        ClientHttpRequestFactorySettings ajustes = ClientHttpRequestFactorySettings.DEFAULTS
                .withConnectTimeout(timeoutConexion)
                .withReadTimeout(timeoutLectura);
        try {
            ajustes = ajustes.withSslBundle(bundles.getBundle(BUNDLE_DE_CONFIANZA));
            log.info("La descarga de claves del auth-server confia solo en la CA del bundle '{}'", BUNDLE_DE_CONFIANZA);
        } catch (NoSuchSslBundleException sinBundle) {
            log.info("Sin bundle SSL '{}': la descarga de claves usa la configuracion normal de la JVM",
                    BUNDLE_DE_CONFIANZA);
        }
        RestTemplate http = new RestTemplate(ClientHttpRequestFactories.get(ajustes));

        // F6: las claves se guardan en una cache SIN vencimiento. Sin esto, Spring Security conserva el JWKS 5 minutos y
        // despues lo vuelve a descargar ANTES de validar el token: con el auth-server caido, cada peticion esperaba el
        // timeout de la descarga (2 s) y los BFF vencian su propio timeout de lectura (medido con
        // scripts/caos/auth-server-caido.sh: replicas del core con 2.011 ms por peticion). Con esta cache la descarga
        // ocurre una vez y solo se repite ante un kid desconocido (rotacion de claves), que es lo que la clase siempre
        // dijo que hacia. Una cache de Spring usada como objeto: no requiere @EnableCaching.
        Cache cacheDeClaves = new ConcurrentMapCache("jwks-auth-server");
        return constructor -> constructor.restOperations(http).cache(cacheDeClaves);
    }
}
