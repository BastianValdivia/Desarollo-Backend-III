package cl.duoc.bancoxyz.comun.core;

/**
 * El core rechazo el token de servicio del BFF (401 o 403).
 *
 * <p><b>Rol en la arquitectura: esto NUNCA es culpa del usuario final.</b> Es
 * la distincion mas importante de esta clase. Si el core rechaza el token de
 * servicio, lo que hay es un problema de despliegue o de permisos: el cliente
 * OAuth2 del BFF no tiene el scope que el endpoint exige (403), o el token no
 * lo acepta el core (401: firma de otro auth-server, audiencia equivocada o un
 * emisor distinto al configurado).
 *
 * <p>La consecuencia practica: un canal <b>no debe</b> traducir esta excepcion
 * en un 401 hacia su cliente. El cliente presento un token perfectamente
 * valido; devolverle un 401 le dice que vuelva a autenticarse, lo cual no va a
 * arreglar nada y ademas manda a quien diagnostique el problema a mirar el
 * login del canal, que es el unico lugar donde no esta el fallo. Lo correcto
 * es tratarlo como una dependencia inutilizable, igual que
 * {@link CoreNoDisponibleException}, y dejar el detalle real en el log del
 * servidor.
 *
 * <p>Se mantiene como clase aparte, y no fundida con la anterior, justamente
 * para que ese log pueda decir "el core rechazo mi credencial" en vez de "el
 * core no responde": son dos diagnosticos con remedios completamente
 * distintos, y confundirlos cuesta una tarde.
 */
public class CoreCredencialRechazadaException extends CoreException {

    public CoreCredencialRechazadaException(String mensaje,
                                            String rutaSolicitada,
                                            Integer estadoDelCore,
                                            String cuerpoCrudo) {
        super(mensaje, rutaSolicitada, estadoDelCore, cuerpoCrudo, null);
    }
}
