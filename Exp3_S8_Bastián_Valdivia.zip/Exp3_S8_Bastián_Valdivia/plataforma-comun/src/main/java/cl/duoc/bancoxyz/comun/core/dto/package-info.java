/**
 * DTO que reflejan el contrato del {@code core-service}, es decir el contrato
 * AGUAS ARRIBA.
 *
 * <p><b>La distincion que da sentido a todo el paquete.</b> Hay dos contratos
 * distintos en juego y confundirlos vacia de contenido al patron BFF:
 * <ul>
 *   <li><b>Aguas arriba</b> (este paquete): lo que el core devuelve. Hay UN
 *       core, luego hay UN contrato, luego estas clases se comparten. Que los
 *       tres canales lean la misma forma del core no los hace parecidos entre
 *       si, igual que dos traductores que leen el mismo libro no escriben la
 *       misma traduccion.</li>
 *   <li><b>Aguas abajo</b> (NO esta aqui, y no puede estarlo): lo que cada
 *       canal devuelve a su cliente. Web entrega la cuenta con agregados y
 *       veinte movimientos; movil entrega el titular abreviado y cinco
 *       movimientos de tres campos; el cajero entrega dos campos. Esas tres
 *       formas viven en el paquete {@code dto} de cada BFF. Si vivieran aqui,
 *       los tres canales devolverian lo mismo y el proyecto dejaria de ser un
 *       BFF para ser un backend con tres puertas.</li>
 * </ul>
 *
 * <p><b>Por que records.</b> Un DTO de transporte no tiene comportamiento: es
 * un puñado de valores que llegan de la red y se leen una vez. Un record da
 * inmutabilidad, {@code equals}, {@code hashCode} y {@code toString} correctos
 * en una linea, y sobre todo impide que alguien le agregue logica de negocio
 * mas adelante, que es como estas clases se degradan.
 *
 * <p><b>Por que los campos de enumerado son {@code String} y no enums.</b>
 * Tentacion natural: declarar {@code TipoMovimiento} como enum. El problema es
 * que Jackson, ante un valor que el enum no conoce, lanza una excepcion y la
 * peticion muere. Es decir: el dia que el core agregue un quinto tipo de
 * movimiento, los TRES BFF empiezan a fallar a la vez, aunque ninguno de ellos
 * necesitara el tipo nuevo para lo que estaba haciendo. Con {@code String}, un
 * valor desconocido simplemente viaja y cada canal decide si le importa. Es la
 * aplicacion directa de "se tolerante con lo que recibes". El caso extremo
 * esta en {@link cl.duoc.bancoxyz.comun.core.dto.TransaccionNoConciliadaCoreDto},
 * donde el contrato EXIGE devolver el valor crudo del CSV, incluidos los
 * invalidos.
 *
 * <p><b>Por que los importes son {@code BigDecimal} y nunca {@code double}.</b>
 * {@code double} no puede representar 0,1 de forma exacta, asi que sumar
 * importes en coma flotante acumula un error que aparece como un peso de
 * diferencia en un total y es imposible de justificar ante un cliente. Es la
 * regla de oro sobre dinero del plan, y se respeta desde el borde de entrada
 * de los datos: si el importe entra como {@code double}, ya se perdio
 * precision antes de llegar a la logica que se preocupa de conservarla.
 *
 * <p><b>Sobre el sufijo {@code Dto} en clases de peticion.</b>
 * {@link cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto} y
 * {@link cl.duoc.bancoxyz.comun.core.dto.ConsultaMovimientosCoreDto} viajan
 * hacia el core, no desde el core. Se les deja el mismo sufijo a proposito:
 * aqui "Dto ... Core" significa "forma del contrato con el core", en
 * cualquiera de los dos sentidos. Un nombre distinto para cada direccion se
 * lee como si fueran cosas de naturaleza distinta, y no lo son.
 */
package cl.duoc.bancoxyz.comun.core.dto;
