package cl.duoc.bancoxyz.comun.core;

/**
 * El core devolvio 409: el retiro no cabe en el saldo de la cuenta.
 *
 * <p><b>Por que la comprobacion de saldo es del core y no del cajero, si el
 * cajero ya validó multiplo, minimo y tope.</b> Porque las tres reglas del
 * cajero se pueden evaluar mirando solo el monto pedido, y la del saldo no:
 * necesita el estado de la cuenta, y ese estado tiene un unico dueño. Un BFF
 * que consultara el saldo, lo comparara y despues pidiera el retiro estaria
 * decidiendo sobre un dato que pudo cambiar en el intervalo entre las dos
 * llamadas. Es la condicion de carrera clasica de un sistema bancario: dos
 * cajeros consultan 5.000, los dos concluyen que alcanza para 3.000, y la
 * cuenta termina en -1.000. La comparacion tiene que ocurrir en el mismo lugar
 * y en el mismo momento que el descuento.
 *
 * <p>El caso congelado de la evidencia es la cuenta 106, con saldo 5.000,
 * pidiendo retirar 8.000: un monto elegido para que pase el multiplo, pase el
 * minimo, pase el tope y falle solo aqui, de modo que el 409 pruebe lo que
 * dice probar y no un 422 disfrazado.
 */
public class CoreSaldoInsuficienteException extends CoreException {

    public CoreSaldoInsuficienteException(String mensaje,
                                          String rutaSolicitada,
                                          String cuerpoCrudo) {
        super(mensaje, rutaSolicitada, 409, cuerpoCrudo, null);
    }
}
