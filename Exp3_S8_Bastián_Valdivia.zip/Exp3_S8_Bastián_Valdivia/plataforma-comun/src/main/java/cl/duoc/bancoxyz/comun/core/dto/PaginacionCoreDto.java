package cl.duoc.bancoxyz.comun.core.dto;

/**
 * Objeto anidado de paginacion, identico en el core y en el canal web
 * (seccion 5.6 del contrato).
 *
 * <p><b>Rol en la arquitectura.</b> Sirve para que el cliente sepa si hay mas
 * paginas sin tener que adivinarlo. Es el unico objeto de este paquete cuya
 * forma coincide con la que web devuelve hacia afuera; aun asi, web declara su
 * propio record, porque el dia que el canal quiera agregar un enlace
 * {@code siguiente} no puede hacerlo sobre una clase que comparte con el core.
 *
 * <p><b>Las dos trampas de nombre que este record congela.</b>
 * <ul>
 *   <li>{@code pagina} empieza en <b>0</b>, no en 1. Es la convencion de
 *       Spring Data y la que el contrato fija. Un canal que asuma que empieza
 *       en 1 devuelve siempre la pagina equivocada sin producir ningun error.</li>
 *   <li>El campo se llama {@code tamano}: sin tilde y sin enie. Escribirlo
 *       {@code tamaño} rompe la deserializacion en cualquier maquina cuya
 *       codificacion no sea UTF-8, y el sintoma (un campo en cero) no apunta
 *       en absoluto a la causa.</li>
 * </ul>
 *
 * @param tamano         elementos por pagina. Sin tilde y sin enie, a proposito
 * @param pagina         indice de pagina, empezando en 0
 * @param totalElementos total de elementos en todas las paginas
 * @param totalPaginas   cantidad de paginas
 */
public record PaginacionCoreDto(
        int pagina,
        int tamano,
        long totalElementos,
        int totalPaginas) {
}
