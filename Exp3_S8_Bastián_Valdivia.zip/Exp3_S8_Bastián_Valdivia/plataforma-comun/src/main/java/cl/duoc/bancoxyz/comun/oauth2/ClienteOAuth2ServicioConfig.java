package cl.duoc.bancoxyz.comun.oauth2;

import java.time.Clock;
import java.time.Duration;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ssl.SslBundle;
import org.springframework.boot.ssl.NoSuchSslBundleException;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.boot.web.client.ClientHttpRequestFactories;
import org.springframework.boot.web.client.ClientHttpRequestFactorySettings;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.security.oauth2.client.AuthorizedClientServiceOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.endpoint.DefaultClientCredentialsTokenResponseClient;
import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequest;
import org.springframework.security.oauth2.client.http.OAuth2ErrorResponseErrorHandler;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.core.http.converter.OAuth2AccessTokenResponseHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.RetryRegistry;

/**
 * Cablea el cliente OAuth2 de servicio de un BFF: de las propiedades {@code spring.security.oauth2.client.*}
 * al {@link TokenServicioInterceptor} que {@code RestCoreClient} instala en sus llamadas al core.
 *
 * <p>El registro {@value #REGISTRO} (cliente, grant {@code client_credentials}, scopes, direccion del
 * endpoint de tokens) lo declara cada BFF en su archivo de {@code config-repo/}, porque cada uno tiene su
 * propio {@code client-id} y su propia lista de scopes. El <strong>secreto</strong> no esta ahi: llega por
 * archivo desde el volumen de secretos ({@code configtree}), igual que la contrasena del keystore.
 *
 * <h2>Confianza en el certificado del auth-server</h2>
 *
 * <p>En contenedores el auth-server habla HTTPS con un certificado que firma la CA interna del proyecto,
 * que la JVM no conoce. Si existe el bundle SSL {@value #BUNDLE_DE_CONFIANZA}
 * ({@code spring.ssl.bundle.jks.interna.truststore.*}, que apunta a un truststore con <em>solo</em> esa
 * CA), la peticion de token lo usa: el BFF confia en el auth-server de este despliegue y en nada mas,
 * sin desactivar la verificacion del certificado ni tocar el almacen de la JVM. Sin ese bundle (JVM
 * locales, donde el auth-server habla HTTP) se usa la configuracion normal de la JVM.
 *
 * <p>El cliente HTTP lleva tiempos de espera propios (2 s, como fija el plan en D6 para esta llamada):
 * un auth-server colgado no debe dejar hilos del canal esperando para siempre. Sobre ese limite, la
 * obtencion del token se reintenta una vez y pasa por un cortacircuitos (F6), y si el auth-server cae
 * el BFF sigue con el token vigente hasta que venza (ver {@link TokenServicioInterceptor}).
 *
 * <p>Esta clase vive en la libreria compartida porque la necesitan los tres BFF por igual y la recogen
 * con el escaneo de {@code cl.duoc.bancoxyz.comun}. El core no la carga (no depende de la libreria) y el
 * auth-server tampoco (importa solo lo que usa).
 */
@Configuration(proxyBeanMethods = false)
public class ClienteOAuth2ServicioConfig {

    private static final Logger log = LoggerFactory.getLogger(ClienteOAuth2ServicioConfig.class);

    /** Identificador del registro de cliente OAuth2 de los tres BFF (mismo nombre en los tres). */
    public static final String REGISTRO = "servicios-internos";

    /** Nombre de la instancia de Resilience4j (circuitbreaker y retry) de la obtencion del token. */
    public static final String INSTANCIA_RESILIENCIA = "auth-server";

    /** Nombre del bundle SSL con la CA interna (spring.ssl.bundle.jks.interna.*). */
    public static final String BUNDLE_DE_CONFIANZA = "interna";

    @Bean
    public OAuth2AuthorizedClientService almacenDeClientesAutorizados(
            ClientRegistrationRepository registros) {
        return new InMemoryOAuth2AuthorizedClientService(registros);
    }

    /**
     * El gestor que obtiene el token con {@code client_credentials} y lo guarda en memoria.
     *
     * <p>Se usa la variante {@code AuthorizedClientService} y no la de repositorio porque no hay
     * peticion de usuario ni sesion de por medio: el token pertenece al servicio y no a quien llama.
     */
    @Bean
    public OAuth2AuthorizedClientManager gestorDeClientesAutorizados(
            ClientRegistrationRepository registros,
            OAuth2AuthorizedClientService almacen,
            SslBundles bundles,
            @Value("${seguridad.servicios.auth-server.timeout-conexion:2s}") Duration timeoutConexion,
            @Value("${seguridad.servicios.auth-server.timeout-lectura:2s}") Duration timeoutLectura,
            @Value("${seguridad.servicios.renovar-antes:30s}") Duration renovarAntes) {

        OAuth2AuthorizedClientProvider proveedor = OAuth2AuthorizedClientProviderBuilder.builder()
                .clientCredentials(grant -> {
                    grant.accessTokenResponseClient(
                            clienteDeTokens(bundles, timeoutConexion, timeoutLectura));
                    grant.clockSkew(renovarAntes);
                })
                .build();

        AuthorizedClientServiceOAuth2AuthorizedClientManager gestor =
                new AuthorizedClientServiceOAuth2AuthorizedClientManager(registros, almacen);
        gestor.setAuthorizedClientProvider(proveedor);
        return gestor;
    }

    /**
     * El interceptor, con la obtencion del token protegida por la instancia {@value #INSTANCIA_RESILIENCIA}
     * de Resilience4j (reintentos y cortacircuitos; sus valores estan en {@code config-repo/}). Si el
     * contexto no trae los registros de Resilience4j se usa sin proteccion.
     */
    @Bean
    public TokenServicioInterceptor tokenServicioInterceptor(
            OAuth2AuthorizedClientManager gestor,
            OAuth2AuthorizedClientService almacen,
            ObjectProvider<CircuitBreakerRegistry> circuitos,
            ObjectProvider<RetryRegistry> reintentos,
            @Value("${seguridad.servicios.renovar-antes:30s}") Duration renovarAntes) {
        CircuitBreakerRegistry registroDeCircuitos = circuitos.getIfAvailable();
        RetryRegistry registroDeReintentos = reintentos.getIfAvailable();
        return new TokenServicioInterceptor(gestor, almacen, REGISTRO, renovarAntes, Clock.systemUTC(),
                registroDeCircuitos == null ? null : registroDeCircuitos.circuitBreaker(INSTANCIA_RESILIENCIA),
                registroDeReintentos == null ? null : registroDeReintentos.retry(INSTANCIA_RESILIENCIA));
    }

    private static OAuth2AccessTokenResponseClient<OAuth2ClientCredentialsGrantRequest> clienteDeTokens(
            SslBundles bundles, Duration timeoutConexion, Duration timeoutLectura) {

        ClientHttpRequestFactorySettings ajustes = ClientHttpRequestFactorySettings.DEFAULTS
                .withConnectTimeout(timeoutConexion)
                .withReadTimeout(timeoutLectura);
        try {
            SslBundle bundle = bundles.getBundle(BUNDLE_DE_CONFIANZA);
            ajustes = ajustes.withSslBundle(bundle);
            log.info("Las peticiones de token al auth-server confian solo en la CA del bundle '{}'",
                    BUNDLE_DE_CONFIANZA);
        } catch (NoSuchSslBundleException sinBundle) {
            // Perfil local: el auth-server habla HTTP y no hay CA interna que declarar.
            log.info("Sin bundle SSL '{}': las peticiones de token usan la configuracion normal de la JVM",
                    BUNDLE_DE_CONFIANZA);
        }
        ClientHttpRequestFactory fabrica = ClientHttpRequestFactories.get(ajustes);

        // Los dos conversores y el manejador de errores son los que Spring Security usa por defecto
        // para este flujo: el cuerpo del token va como formulario y la respuesta es JSON de OAuth2.
        RestTemplate http = new RestTemplate(List.of(
                new FormHttpMessageConverter(), new OAuth2AccessTokenResponseHttpMessageConverter()));
        http.setRequestFactory(fabrica);
        http.setErrorHandler(new OAuth2ErrorResponseErrorHandler());

        DefaultClientCredentialsTokenResponseClient cliente = new DefaultClientCredentialsTokenResponseClient();
        cliente.setRestOperations(http);
        return cliente;
    }
}
