package cl.duoc.bancoxyz.comun.core;

import cl.duoc.bancoxyz.comun.core.dto.ConsultaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaTransaccionesCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto;

/**
 * PUERTO hacia el {@code core-service}: la unica via por la que un BFF puede
 * hablar con el backend de dominio.
 *
 * <p><b>Que es un puerto y por que esto es uno.</b> Un puerto es una interfaz
 * escrita desde el punto de vista de QUIEN LA USA, que describe lo que el
 * sistema necesita de afuera sin decir como se consigue. Fijese en lo que esta
 * declaracion no menciona: no aparece HTTP, ni una URL, ni un codigo de
 * estado, ni JSON, ni el token de servicio OAuth2. Solo aparece lo que
 * un canal quiere: una cuenta, un saldo, una pagina de movimientos, un retiro.
 * Todo lo demas es un detalle de COMO, y vive en
 * {@link RestCoreClient}, que es el ADAPTADOR.
 *
 * <p><b>Para que sirve en la practica esa separacion.</b> Tres cosas
 * concretas, no teoricas:
 * <ul>
 *   <li><b>Se puede probar un canal sin levantar el core.</b> Una prueba de
 *       {@code CuentaWebService} implementa esta interfaz devolviendo una
 *       cuenta fija. Sin puerto, esa prueba necesitaria un servidor HTTP.</li>
 *   <li><b>Se puede cambiar el transporte sin tocar los canales.</b> El dia
 *       que el core hable gRPC, se escribe un {@code GrpcCoreClient} y los
 *       tres BFF no cambian una linea. Esa es la afirmacion de extensibilidad
 *       del proyecto, y esta interfaz es lo que la hace verdad y no un
 *       adjetivo.</li>
 *   <li><b>Se ve de un vistazo todo lo que los BFF pueden pedirle al
 *       core.</b> Son seis metodos. Si un canal necesitara un septimo, se
 *       veria aqui, y habria que justificarlo.</li>
 * </ul>
 *
 * <p><b>Lo que esta interfaz NO hace, y es igual de importante.</b>
 * <ul>
 *   <li><b>No cachea nada, y ninguna implementacion suya debe cachear.</b>
 *       {@link #obtenerSaldo(int)} lo llaman movil y cajero. Si este metodo
 *       llevara una anotacion de cache, el cajero heredaria una cache de
 *       saldo, y cachear el saldo en un cajero significa entregar dinero que
 *       ya no existe. Si no la llevara, movil perderia la suya. Una clase
 *       compartida no puede tener dos comportamientos: la cache va en el
 *       servicio de cada canal, que decide su propio TTL y su propio tamano
 *       maximo. Esto tiene ademas un beneficio gratis: elimina por diseno la
 *       trampa de la autoinvocacion, en la que una anotacion de cache sobre un
 *       metodo llamado desde su propia clase no hace nada y no avisa.</li>
 *   <li><b>No comprueba titularidad.</b> Este puerto trae la cuenta 105 a
 *       quien la pida. Verificar que el claim {@code cuentaId} del token
 *       coincide con la cuenta pedida es responsabilidad del servicio del
 *       canal, ANTES de llamar aqui.</li>
 *   <li><b>No decide codigos HTTP de salida.</b> Lanza {@link CoreException} y
 *       sus subclases; el canal las traduce a su cuerpo de error.</li>
 * </ul>
 *
 * <p>Todos los metodos lanzan {@link CoreException} ante cualquier fallo, sin
 * excepcion: no hay forma de que una llamada a este puerto falle con algo que
 * el canal no sepa reconocer.
 */
public interface CoreClient {

    /**
     * C2. Trae la cuenta canonica completa, con TODOS sus movimientos.
     *
     * <p>Es la respuesta mas grande del sistema y la linea base de medicion.
     * Un canal que solo necesita el saldo debe usar {@link #obtenerSaldo(int)},
     * y uno que necesita una pagina, {@link #obtenerMovimientos}. Llamar a
     * este metodo y quedarse con un campo mueve por la red decenas de veces
     * mas datos de los necesarios, y el costo ya se pago cuando el canal
     * proyecta la respuesta.
     *
     * @param cuentaId identificador de la cuenta, entre 101 y 150
     * @return la cuenta con sus movimientos. Lista vacia, nunca nula, si no tiene
     * @throws CoreRecursoNoEncontradoException si la cuenta no existe
     * @throws CoreNoDisponibleException        si el core no responde
     */
    CuentaCoreDto obtenerCuenta(int cuentaId);

    /**
     * C3. Trae solo el saldo. Existe para que movil y cajero no tengan que
     * traer la cuenta completa.
     *
     * @param cuentaId identificador de la cuenta
     * @return cuenta, saldo y moneda, y nada mas
     * @throws CoreRecursoNoEncontradoException si la cuenta no existe
     * @throws CoreNoDisponibleException        si el core no responde
     */
    SaldoCoreDto obtenerSaldo(int cuentaId);

    /**
     * C4. Trae una pagina de movimientos, con filtros opcionales de fecha y
     * tipo.
     *
     * @param cuentaId identificador de la cuenta
     * @param consulta pagina, tamano y filtros ya decididos por el canal
     * @return la pagina pedida mas sus metadatos de paginacion
     * @throws CoreRecursoNoEncontradoException si la cuenta no existe
     * @throws CoreNoDisponibleException        si el core no responde
     */
    PaginaMovimientosCoreDto obtenerMovimientos(int cuentaId, ConsultaMovimientosCoreDto consulta);

    /**
     * C5. Ejecuta un retiro. Es la UNICA operacion de todo este puerto que
     * cambia el estado del banco, y por eso es la unica con clave de
     * idempotencia.
     *
     * <p><b>Sobre {@code claveIdempotencia}.</b> Viaja en la cabecera
     * {@code Idempotency-Key} y hace que un reintento con la misma clave
     * devuelva el mismo folio sin descontar dos veces. El escenario que
     * protege es real y frecuente: el cajero pide el retiro, el core lo
     * ejecuta, y la respuesta se pierde por un corte de red. El cajero no sabe
     * si el dinero salio o no. Sin idempotencia, reintentar arriesga un doble
     * cargo y no reintentar arriesga entregar billetes sin registrar el
     * movimiento; con idempotencia, reintentar es siempre seguro.
     *
     * <p>El registro de claves vive en el core, no en el BFF. Un registro en
     * el BFF solo protegeria a los reintentos que llegaran a esa misma
     * instancia, que es no proteger.
     *
     * @param cuentaId          cuenta de la que se retira
     * @param solicitud         monto a retirar
     * @param claveIdempotencia valor de {@code Idempotency-Key}, generado por el canal
     * @return folio y los tres importes que hacen de comprobante
     * @throws CoreSaldoInsuficienteException   si el saldo no alcanza
     * @throws CoreRecursoNoEncontradoException si la cuenta no existe
     * @throws CoreNoDisponibleException        si el core no responde
     */
    RetiroCoreDto ejecutarRetiro(int cuentaId, SolicitudRetiroCoreDto solicitud, String claveIdempotencia);

    /**
     * C6. Trae el reporte de calidad de la ingesta. Hoy solo lo consume el
     * canal web, y solo para el perfil de ejecutivo.
     *
     * <p>Que este metodo viva en el puerto compartido no significa que los
     * tres canales lo expongan: el puerto describe lo que el core OFRECE, y
     * cada canal decide que parte de esa oferta publica. Movil y cajero
     * simplemente no lo llaman, y no tienen ruta que lo alcance.
     *
     * @return recuentos de la ingesta y descartes por motivo
     * @throws CoreNoDisponibleException si el core no responde
     */
    ReporteCalidadCoreDto obtenerCalidadDatos();

    /**
     * C7. Trae una pagina del lote de {@code transacciones.csv}, que no se
     * pudo vincular a ninguna cuenta.
     *
     * @param pagina indice de pagina, empezando en 0
     * @param tamano elementos por pagina
     * @return las filas crudas del archivo mas sus metadatos de paginacion
     * @throws CoreNoDisponibleException si el core no responde
     */
    PaginaTransaccionesCoreDto obtenerTransaccionesNoConciliadas(int pagina, int tamano);
}
