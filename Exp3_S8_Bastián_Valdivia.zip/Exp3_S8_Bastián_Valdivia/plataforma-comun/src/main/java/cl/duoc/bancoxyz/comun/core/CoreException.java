package cl.duoc.bancoxyz.comun.core;

/**
 * Raiz de todos los fallos al hablar con el {@code core-service}.
 *
 * <p><b>Rol en la arquitectura: esta jerarquia es la traduccion entre dos
 * mundos.</b> El {@link CoreClient} recibe codigos HTTP del core (404, 409,
 * 401...) y sus llamadores son servicios de canal que no deben razonar sobre
 * codigos HTTP ajenos. Sin traduccion, un servicio de {@code bff-web}
 * escribiria algo como {@code if (e.getStatusCode() == 404)}, y entonces el
 * canal estaria acoplado al protocolo de su dependencia: el dia que el core
 * cambiara ese 404 por otra cosa, habria que buscar el numero por los tres
 * BFF. Con excepciones con nombre, el canal escribe
 * {@code catch (CoreRecursoNoEncontradoException e)} y el numero vive en un
 * solo lugar.
 *
 * <p><b>Por que son excepciones no comprobadas.</b> Extienden
 * {@code RuntimeException} y no {@code Exception} porque casi ningun llamador
 * puede hacer algo util con ellas en el acto: la respuesta correcta es dejar
 * que suban hasta el manejador de errores del canal, que las convierte en el
 * cuerpo RFC 7807 correspondiente. Obligar a declarar {@code throws} en cada
 * metodo intermedio solo agregaria ruido a un monton de codigo que no tiene
 * nada que decidir.
 *
 * <p><b>Lo que esta jerarquia deliberadamente NO tiene: un codigo HTTP de
 * salida.</b> Seria comodo ponerle a cada excepcion el estado con el que el
 * canal debe responder. Seria tambien mover politica al modulo compartido: por
 * ejemplo, que un core caido se traduzca en 503 {@code core_no_disponible} es
 * una decision de cada canal, y el cajero ademas le agrega su
 * {@code codigoPantalla E-090}, que web y movil no tienen. Estas clases dicen
 * QUE paso; el canal decide COMO se ve eso desde afuera.
 *
 * <p>Lo que si llevan es contexto de diagnostico: la ruta que se pidio, el
 * estado que devolvio el core y el cuerpo crudo de esa respuesta. Sin eso, un
 * fallo en produccion deja una linea de log que dice "error al llamar al core"
 * y no permite avanzar ni un paso.
 */
public abstract class CoreException extends RuntimeException {

    private final String rutaSolicitada;
    private final Integer estadoDelCore;
    private final String cuerpoCrudo;

    /**
     * @param mensaje        explicacion en espanol, pensada para el log
     * @param rutaSolicitada ruta del core que se estaba llamando
     * @param estadoDelCore  codigo HTTP que devolvio el core, o {@code null} si nunca respondio
     * @param cuerpoCrudo    cuerpo de la respuesta tal cual, o {@code null}
     * @param causa          excepcion original, o {@code null} si no hubo
     */
    protected CoreException(String mensaje,
                            String rutaSolicitada,
                            Integer estadoDelCore,
                            String cuerpoCrudo,
                            Throwable causa) {
        super(mensaje, causa);
        this.rutaSolicitada = rutaSolicitada;
        this.estadoDelCore = estadoDelCore;
        this.cuerpoCrudo = cuerpoCrudo;
    }

    /** Ruta del core que se estaba llamando cuando ocurrio el fallo. */
    public String rutaSolicitada() {
        return rutaSolicitada;
    }

    /**
     * Codigo HTTP devuelto por el core, o {@code null} cuando el core nunca
     * llego a responder (conexion rechazada o timeout). Esa distincion entre
     * "respondio mal" y "no respondio" es justamente la que un {@code null}
     * comunica y un cero no comunicaria.
     */
    public Integer estadoDelCore() {
        return estadoDelCore;
    }

    /**
     * Cuerpo de la respuesta del core sin interpretar.
     *
     * <p>Se conserva para el log y NO para que un canal lo reenvie a su
     * cliente. El cuerpo de error del core habla de rutas {@code /internal/v1}
     * y de detalles internos que ningun cliente externo tiene por que ver;
     * reenviarlo seria filtrar la arquitectura interna en una respuesta
     * publica.
     */
    public String cuerpoCrudo() {
        return cuerpoCrudo;
    }
}
