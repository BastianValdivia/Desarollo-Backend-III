package cl.duoc.bancoxyz.comun.core;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.function.Supplier;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.util.UriBuilder;

import cl.duoc.bancoxyz.comun.core.dto.ConsultaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.CuentaCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaMovimientosCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.PaginaTransaccionesCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.ReporteCalidadCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.RetiroCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SaldoCoreDto;
import cl.duoc.bancoxyz.comun.core.dto.SolicitudRetiroCoreDto;
import cl.duoc.bancoxyz.comun.oauth2.TokenServicioInterceptor;

/**
 * ADAPTADOR HTTP del puerto {@link CoreClient}: la unica clase de todo el
 * sistema que sabe que el {@code core-service} se alcanza por HTTP.
 *
 * <p><b>Rol en la arquitectura.</b> Si {@link CoreClient} dice QUE se le puede
 * pedir al core, esta clase dice COMO se le pide: con que URL, con que
 * cabecera, con cuanta paciencia y que hacer cuando la respuesta no es la
 * esperada. Todo eso esta encerrado aqui a proposito. Ningun servicio de
 * ningun canal deberia contener la cadena {@code "/internal/v1"}; si alguien
 * la escribe en otro archivo, el puerto dejo de servir para lo que existe.
 *
 * <p><b>Es {@code @Component} porque cada BFF la recoge con
 * {@code scanBasePackages}.</b> La clase principal de cada canal declara:
 * <pre>
 * &#64;SpringBootApplication(scanBasePackages = {"cl.duoc.bancoxyz.bff.web", "cl.duoc.bancoxyz.comun"})
 * </pre>
 * Se eligio ese mecanismo, y no la autoconfiguracion de Spring Boot, porque la
 * autoconfiguracion exige un archivo de metadatos en {@code META-INF} cuyo
 * contenido es el nombre completo de una clase escrito a mano: si ese nombre
 * tiene un caracter mal puesto, no hay ningun error, los beans simplemente no
 * existen, y el mensaje que aparece habla de un bean que falta sin decir por
 * que. Una linea visible en la clase principal falla de forma ruidosa.
 *
 * <p><b>Las tres responsabilidades que esta clase cumple para que ningun canal
 * tenga que cumplirlas.</b>
 * <ol>
 *   <li><b>Adjuntar el token de servicio OAuth2 en cada llamada.</b> Lo hace el
 *       {@link TokenServicioInterceptor}, instalado UNA vez en el cliente, no en
 *       cada metodo. La diferencia importa: si dependiera de recordarlo en cada
 *       llamada, bastaria que el septimo metodo que alguien agregue lo olvide
 *       para abrir un agujero silencioso.</li>
 *   <li><b>Poner timeouts explicitos.</b> Ver la nota completa en el
 *       constructor.</li>
 *   <li><b>Traducir cada error HTTP a una {@link CoreException} con
 *       significado.</b> Ver {@link #traducirError}.</li>
 * </ol>
 *
 * <p><b>Y la que NO cumple: cachear.</b> Esta clase no lleva, y no debe
 * llevar, ninguna anotacion de cache. El motivo esta explicado en el
 * {@link CoreClient}: el mismo metodo lo usan un canal que quiere cachear el
 * saldo y otro para el que cachearlo seria entregar dinero inexistente.
 */
@Component
public class RestCoreClient implements CoreClient {

    /**
     * Motivo con el que el core rechaza una {@code Idempotency-Key} reutilizada con otro importe. Se
     * repite aqui como literal (igual que {@code MotivosError}) porque el core no depende de esta
     * libreria.
     */
    private static final String MOTIVO_CLAVE_REUTILIZADA = "clave_idempotencia_reutilizada";

    /** Cabecera estandar de idempotencia. Solo viaja en el retiro. */
    public static final String CABECERA_IDEMPOTENCIA = "Idempotency-Key";

    /** Prefijo de todos los recursos del core. Deliberadamente NO es {@code /api}. */
    private static final String RAIZ_INTERNA = "/internal/v1";

    private final RestClient http;

    /**
     * Arma el cliente HTTP una sola vez, al construir el bean.
     *
     * <p><b>Por que recibe un {@code RestClient.Builder} en vez de fabricar
     * uno con {@code RestClient.create()}.</b> El builder inyectado trae dos
     * cosas que uno fabricado a mano no tendria:
     * <ol>
     *   <li>los conversores de mensaje del contexto, es decir el mismo
     *       {@code ObjectMapper} que usa el resto del BFF. Las fechas del core
     *       llegan como {@code "2024-03-08"} y se deserializan a
     *       {@code LocalDate} porque ese mapeador tiene registrado el modulo
     *       de fechas de Java 8; el sintoma de no tenerlo seria un error de
     *       deserializacion en la primera consulta que devuelva un
     *       movimiento;</li>
     *   <li>el <b>balanceo por nombre logico</b>. Es el builder marcado con
     *       {@link LoadBalanced} en {@link ClienteCoreBalanceadoConfig}: el
     *       calificador {@code @LoadBalanced} del parametro lo selecciona a el
     *       y no a cualquier otro. Gracias a eso {@code core.base-url} vale
     *       {@code http://core-service} y la direccion real la resuelve
     *       Eureka en cada llamada.</li>
     * </ol>
     *
     * <p>Se llama a {@code clone()} antes de configurarlo por una razon
     * practica: el builder inyectado se comparte, y modificarlo en el sitio
     * dejaria la URL base y el interceptor del token pegados a cualquier otro
     * cliente HTTP que el canal construya despues (y el token de servicio solo
     * debe viajar al core).
     *
     * <p><b>POR QUE LOS TIMEOTS SON EXPLICITOS, que es la decision mas
     * importante de esta clase.</b> Sin ellos, una peticion HTTP espera
     * indefinidamente. Traducido a lo que pasa de verdad: si el core se cuelga
     * (no se cae, se cuelga: acepta la conexion y no responde), cada peticion
     * de usuario ocupa un hilo de Tomcat que no se libera jamas. Con suficiente
     * trafico, los 50 hilos del cajero se agotan en segundos y el BFF deja de
     * responder <b>incluso a las peticiones que no necesitaban el core</b>,
     * como {@code /actuator/health}. Un monitor que mire esa ruta va a
     * concluir que el cajero se cayo. Es decir: un core colgado se lleva
     * puestos a los tres BFF, y el fallo se propaga hacia arriba en lugar de
     * quedar contenido. Con un timeout de lectura, la peticion que no llega a
     * tiempo se corta, el hilo vuelve al pool, el canal responde 503
     * {@code core_no_disponible} y todo lo que no dependia del core sigue
     * funcionando. Eso es degradacion controlada, y son dos lineas.
     *
     * <p>Se usa {@code SimpleClientHttpRequestFactory} y sus dos metodos
     * {@code setConnectTimeout} y {@code setReadTimeout} en lugar de
     * {@code ClientHttpRequestFactorySettings}: la API de esa segunda clase
     * cambio entre Spring Boot 3.3 y 3.4, y produce errores de compilacion
     * cuyo mensaje no ayuda a entender que el problema es de version.
     *
     * <p>El manejador de estado se registra aqui, con
     * {@code defaultStatusHandler}, y no en cada llamada, por el mismo motivo
     * que la cabecera: lo que se declara una vez no se puede olvidar despues.
     */
    public RestCoreClient(@LoadBalanced RestClient.Builder plantilla, CoreClientProperties propiedades,
                          TokenServicioInterceptor tokenServicio) {
        SimpleClientHttpRequestFactory fabrica = new SimpleClientHttpRequestFactory();
        fabrica.setConnectTimeout(propiedades.timeoutConexion());
        fabrica.setReadTimeout(propiedades.timeoutLectura());

        this.http = plantilla.clone()
                // En la posicion 0: debe ser el MAS EXTERNO, el que envuelve al interceptor del
                // balanceador que Spring Cloud agrego al builder.
                .requestInterceptors(interceptores -> {
                    interceptores.add(0, traducirFallosDeDespacho());
                    // Justo despues del traductor y antes del balanceador: el token se adjunta a la
                    // peticion con el nombre logico y viaja con ella a la instancia que se elija. Si no
                    // se puede obtener, la IOException sale como "core no disponible" (503).
                    interceptores.add(1, tokenServicio);
                })
                .baseUrl(propiedades.baseUrl())
                .requestFactory(fabrica)
                .defaultStatusHandler(HttpStatusCode::isError, this::traducirError)
                .build();
    }

    @Override
    public CuentaCoreDto obtenerCuenta(int cuentaId) {
        String ruta = RAIZ_INTERNA + "/cuentas/" + cuentaId;
        return ejecutar(ruta, () -> http.get()
                .uri(RAIZ_INTERNA + "/cuentas/{id}", cuentaId)
                .retrieve()
                .body(CuentaCoreDto.class));
    }

    @Override
    public SaldoCoreDto obtenerSaldo(int cuentaId) {
        String ruta = RAIZ_INTERNA + "/cuentas/" + cuentaId + "/saldo";
        return ejecutar(ruta, () -> http.get()
                .uri(RAIZ_INTERNA + "/cuentas/{id}/saldo", cuentaId)
                .retrieve()
                .body(SaldoCoreDto.class));
    }

    @Override
    public PaginaMovimientosCoreDto obtenerMovimientos(int cuentaId, ConsultaMovimientosCoreDto consulta) {
        String ruta = RAIZ_INTERNA + "/cuentas/" + cuentaId + "/movimientos";
        return ejecutar(ruta, () -> http.get()
                .uri(constructor -> construirUriDeMovimientos(constructor, cuentaId, consulta))
                .retrieve()
                .body(PaginaMovimientosCoreDto.class));
    }

    @Override
    public RetiroCoreDto ejecutarRetiro(int cuentaId, SolicitudRetiroCoreDto solicitud, String claveIdempotencia) {
        String ruta = RAIZ_INTERNA + "/cuentas/" + cuentaId + "/retiros";
        return ejecutar(ruta, () -> http.post()
                .uri(RAIZ_INTERNA + "/cuentas/{id}/retiros", cuentaId)
                // La clave de idempotencia va como cabecera y no como campo del
                // cuerpo porque identifica al INTENTO, no a la operacion: dos
                // intentos con el mismo monto y la misma cuenta son operaciones
                // distintas si el usuario quiso retirar dos veces, y el mismo
                // intento si lo que hubo fue un reintento por timeout. Solo el
                // cliente sabe cual de los dos casos es, y por eso es el cliente
                // quien genera la clave.
                .header(CABECERA_IDEMPOTENCIA, claveIdempotencia)
                .body(solicitud)
                .retrieve()
                .body(RetiroCoreDto.class));
    }

    @Override
    public ReporteCalidadCoreDto obtenerCalidadDatos() {
        String ruta = RAIZ_INTERNA + "/admin/calidad-datos";
        return ejecutar(ruta, () -> http.get()
                .uri(ruta)
                .retrieve()
                .body(ReporteCalidadCoreDto.class));
    }

    @Override
    public PaginaTransaccionesCoreDto obtenerTransaccionesNoConciliadas(int pagina, int tamano) {
        String ruta = RAIZ_INTERNA + "/admin/transacciones-no-conciliadas";
        return ejecutar(ruta, () -> http.get()
                .uri(constructor -> constructor.path(ruta)
                        .queryParam("page", pagina)
                        .queryParam("size", tamano)
                        .build())
                .retrieve()
                .body(PaginaTransaccionesCoreDto.class));
    }

    /**
     * Arma la URI de C4 agregando solo los filtros que el canal pidio.
     *
     * <p>Se construye con {@code UriBuilder} y no concatenando texto porque el
     * constructor codifica los valores: un filtro de tipo con un espacio o un
     * caracter reservado produciria, concatenando, una URL invalida o, peor,
     * una URL valida que significa otra cosa.
     *
     * <p>Los filtros nulos se OMITEN en lugar de viajar vacios. No es
     * cosmetica: un {@code ?tipo=} vacio obliga al core a decidir si eso
     * significa "sin filtro" o "los de tipo vacio", y dos implementaciones
     * razonables pueden decidir distinto. Un parametro ausente no tiene esa
     * ambiguedad.
     */
    private java.net.URI construirUriDeMovimientos(UriBuilder constructor,
                                                   int cuentaId,
                                                   ConsultaMovimientosCoreDto consulta) {
        constructor.path(RAIZ_INTERNA + "/cuentas/{id}/movimientos")
                .queryParam("page", consulta.pagina())
                .queryParam("size", consulta.tamano());
        if (consulta.desde() != null) {
            constructor.queryParam("desde", consulta.desde());
        }
        if (consulta.hasta() != null) {
            constructor.queryParam("hasta", consulta.hasta());
        }
        if (consulta.tipo() != null) {
            constructor.queryParam("tipo", consulta.tipo());
        }
        return constructor.build(cuentaId);
    }

    /**
     * Envuelve una llamada para garantizar que TODO fallo salga de esta clase
     * como una {@link CoreException}.
     *
     * <p>El manejador de estado registrado en el constructor ya cubre las
     * respuestas de error del core. Lo que queda fuera de su alcance son los
     * fallos en los que no hay respuesta alguna, y son justamente los mas
     * probables:
     * <ul>
     *   <li>{@code ResourceAccessException} envuelve los errores de entrada y
     *       salida: conexion rechazada porque el core no esta levantado, y
     *       tambien el vencimiento de los dos timeouts. Es la excepcion que
     *       aparece en la prueba de degradacion controlada cuando se detiene el
     *       core a proposito.</li>
     *   <li>Cuando el balanceador no encuentra ninguna instancia de
     *       {@code core-service} en Eureka (no arranco, murio y su arriendo
     *       vencio, o aun no se registro) lanza una excepcion de Spring Cloud
     *       que ni siquiera es de entrada y salida. Para el canal equivale a un
     *       core caido: {@link #traducirFallosDeDespacho} la convierte en un
     *       error de entrada y salida y llega aqui como
     *       {@code ResourceAccessException}.</li>
     *   <li>{@code RestClientException} cubre el resto, entre ellos el caso de
     *       una respuesta exitosa cuyo cuerpo no se pudo deserializar, que es
     *       como se manifiesta un desajuste de nombres de campo entre el core y
     *       el contrato congelado.</li>
     * </ul>
     *
     * <p>Sin esta red, esas excepciones subirian con su tipo original y el
     * manejador de errores del canal, que sabe tratar {@link CoreException}, no
     * las reconoceria: el usuario recibiria un 500 generico en lugar del 503
     * bien formado que el contrato exige.
     *
     * @param ruta   ruta que se estaba llamando, solo para el diagnostico
     * @param accion la llamada HTTP propiamente tal
     */
    private <T> T ejecutar(String ruta, Supplier<T> accion) {
        try {
            return accion.get();
        } catch (CoreException yaTraducida) {
            // Viene del manejador de estado: ya tiene significado, se deja pasar
            // tal cual. Sin este catch, el siguiente la volveria a envolver y el
            // canal perderia la distincion entre un 404 y un 409.
            throw yaTraducida;
        } catch (ResourceAccessException sinRespuesta) {
            throw new CoreNoDisponibleException(
                    "El core no respondio al llamar a " + ruta
                            + ". Puede estar detenido o haber superado el timeout configurado.",
                    ruta, null, null, sinRespuesta);
        } catch (RestClientException otro) {
            throw new CoreRespuestaInesperadaException(
                    "Fallo inesperado al llamar a " + ruta
                            + ". Si el core respondio 200, revise que los nombres de campo del core "
                            + "coincidan con el contrato congelado.",
                    ruta, null, null, otro);
        }
    }

    /**
     * Convierte en un error de entrada y salida cualquier fallo del balanceador al ELEGIR una
     * instancia (ninguna registrada en Eureka), para que {@link #ejecutar} lo trate como "el core
     * no esta disponible" y el canal responda 503 {@code core_no_disponible}.
     *
     * <p>Sin esto el resultado depende de un detalle interno de Spring Cloud: segun el camino,
     * el balanceador lanza una {@link IllegalStateException} ("No instances available for ...") o
     * una {@link IllegalArgumentException} ("Service Instance cannot be null ..."), y esta ultima la
     * recoge el manejador de errores de un canal como si el USUARIO hubiera enviado un parametro
     * invalido (400). Un core caido contestando 400 seria un diagnostico enganoso.
     *
     * <p>Se captura por TIPO y solo a este nivel del interceptor: la lectura y deserializacion del
     * cuerpo ocurren despues, fuera de el, asi que un error de formato del cuerpo no se disfraza de
     * core caido. Lo cubre {@code RestCoreClientSinInstanciasTest}.
     */
    private static ClientHttpRequestInterceptor traducirFallosDeDespacho() {
        return (peticion, cuerpo, ejecucion) -> {
            try {
                return ejecucion.execute(peticion, cuerpo);
            } catch (IllegalStateException | IllegalArgumentException sinInstancia) {
                throw new IOException("No se pudo elegir una instancia de "
                        + peticion.getURI().getHost() + " para " + peticion.getURI().getPath()
                        + ": " + sinInstancia.getMessage(), sinInstancia);
            }
        };
    }

    /**
     * Convierte una respuesta de error del core en la {@link CoreException} que
     * le corresponde.
     *
     * <p><b>Este metodo es la frontera entre "el protocolo del core" y "el
     * vocabulario del sistema".</b> A la izquierda entran numeros; a la derecha
     * salen conceptos. El mapeo y su razon:
     * <ul>
     *   <li><b>401 y 403</b>: el core rechazo el token de SERVICIO (401: no lo
     *       acepta; 403: le falta el scope del endpoint). Nunca es culpa del usuario
     *       final; ver {@link CoreCredencialRechazadaException}.</li>
     *   <li><b>404</b>: la cuenta no existe. Ojo: la cuenta ajena no llega
     *       hasta aqui, la corta el canal antes con un 403.</li>
     *   <li><b>409</b>: saldo insuficiente. Es el unico conflicto de estado que
     *       el contrato define.</li>
     *   <li><b>422 {@code clave_idempotencia_reutilizada}</b>: la clave de idempotencia ya se uso en
     *       esa cuenta con otro importe; ver {@link CoreClaveIdempotenciaReutilizadaException}.</li>
     *   <li><b>5xx</b>: el core fallo por dentro. Para el canal es
     *       indistinguible de que el core no este, y se trata igual.</li>
     *   <li><b>cualquier otro</b>: no se adivina. Se lanza
     *       {@link CoreRespuestaInesperadaException} con el cuerpo crudo, que
     *       es lo que permite diagnosticarlo.</li>
     * </ul>
     *
     * <p>El cuerpo de la respuesta se lee y se guarda en la excepcion, pero
     * <b>no</b> para reenviarlo al cliente: habla de rutas internas y seria
     * filtrar la arquitectura del sistema hacia afuera. Es material para el
     * log.
     *
     * <p>La firma con {@code throws IOException} viene impuesta por la interfaz
     * de Spring; este metodo no la lanza nunca, porque la lectura del cuerpo ya
     * esta protegida.
     */
    private void traducirError(HttpRequest peticion, ClientHttpResponse respuesta) throws IOException {
        int estado = respuesta.getStatusCode().value();
        String ruta = peticion.getURI().getPath();
        String cuerpo = leerCuerpoSinFallar(respuesta);

        if (estado == 401 || estado == 403) {
            throw new CoreCredencialRechazadaException(
                    "El core rechazo con " + estado + " el token de servicio al llamar a " + ruta
                            + ". Con 401, revise que el core valide el emisor y la audiencia del "
                            + "auth-server de este despliegue; con 403, que el cliente OAuth2 de este "
                            + "canal tenga el scope que el endpoint exige.",
                    ruta, estado, cuerpo);
        }
        if (estado == 404) {
            throw new CoreRecursoNoEncontradoException(
                    "El core no encontro el recurso " + ruta + ".", ruta, cuerpo);
        }
        if (estado == 409) {
            throw new CoreSaldoInsuficienteException(
                    "El core rechazo el retiro por saldo insuficiente en " + ruta + ".", ruta, cuerpo);
        }
        // El unico 422 que el core define hoy es la clave de idempotencia reutilizada con otro importe.
        // Se confirma por el motivo del cuerpo y no solo por el numero: un 422 con otro motivo seria un
        // caso que este cliente no conoce y debe seguir cayendo en "respuesta inesperada".
        if (estado == 422 && cuerpo != null && cuerpo.contains(MOTIVO_CLAVE_REUTILIZADA)) {
            throw new CoreClaveIdempotenciaReutilizadaException(
                    "El core rechazo el retiro en " + ruta + ": la Idempotency-Key ya se uso con otro importe.",
                    ruta, cuerpo);
        }
        if (respuesta.getStatusCode().is5xxServerError()) {
            throw new CoreNoDisponibleException(
                    "El core respondio " + estado + " al llamar a " + ruta + ".",
                    ruta, estado, cuerpo, null);
        }
        throw new CoreRespuestaInesperadaException(
                "El core respondio " + estado + " al llamar a " + ruta
                        + ", y este cliente no sabe interpretar ese codigo.",
                ruta, estado, cuerpo, null);
    }

    /**
     * Lee el cuerpo de una respuesta de error sin poder fallar.
     *
     * <p>Parece defensivo de mas y no lo es: aqui ya estamos atendiendo un
     * error, y si la lectura del cuerpo lanzara su propia excepcion, esa
     * segunda excepcion reemplazaria a la primera. El resultado seria un log
     * quejandose de un flujo de entrada, sin rastro del 409 que de verdad
     * ocurrio. Es la forma clasica de perder el error original: fallar
     * mientras se informa de un fallo.
     */
    private String leerCuerpoSinFallar(ClientHttpResponse respuesta) {
        try (InputStream flujo = respuesta.getBody()) {
            return StreamUtils.copyToString(flujo, StandardCharsets.UTF_8);
        } catch (IOException | RuntimeException ignorada) {
            return null;
        }
    }
}
