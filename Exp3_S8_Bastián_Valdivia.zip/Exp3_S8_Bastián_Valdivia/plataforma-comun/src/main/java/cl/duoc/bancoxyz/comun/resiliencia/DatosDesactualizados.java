package cl.duoc.bancoxyz.comun.resiliencia;

import java.time.Duration;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

/**
 * Marca la peticion en curso como atendida con datos DESACTUALIZADOS (el ultimo dato conocido del core,
 * servido porque el core no esta disponible).
 *
 * <p>Los servicios de canal devuelven DTO, no respuestas HTTP, y el contrato de cada canal esta
 * congelado: el cuerpo no cambia. La advertencia viaja en cabeceras, que las escribe
 * {@link AvisoDatosDesactualizados} al momento de responder. Este objeto es el puente entre ambos: el
 * servicio deja una marca en la peticion actual y la cabecera sale sola, sin que el controlador tenga
 * que enterarse. Fuera de una peticion web (una prueba de unidad, un hilo propio) no hace nada.
 */
public final class DatosDesactualizados {

    /** Atributo de la peticion con la antiguedad, en segundos, del dato mas viejo que se sirvio. */
    static final String ATRIBUTO = DatosDesactualizados.class.getName() + ".antiguedadSegundos";

    private DatosDesactualizados() {
    }

    /**
     * Anota en la peticion actual que se sirvio un dato con la antiguedad indicada. Si la peticion ya
     * tenia una marca (una peticion que lee dos recursos), se conserva la mayor antiguedad: la
     * advertencia debe describir lo peor que recibio el cliente.
     */
    public static void marcar(Duration antiguedad) {
        RequestAttributes atributos = RequestContextHolder.getRequestAttributes();
        if (atributos == null) {
            return;
        }
        long segundos = Math.max(0, antiguedad.toSeconds());
        Object previa = atributos.getAttribute(ATRIBUTO, RequestAttributes.SCOPE_REQUEST);
        if (previa instanceof Long anterior && anterior >= segundos) {
            return;
        }
        atributos.setAttribute(ATRIBUTO, segundos, RequestAttributes.SCOPE_REQUEST);
    }
}
