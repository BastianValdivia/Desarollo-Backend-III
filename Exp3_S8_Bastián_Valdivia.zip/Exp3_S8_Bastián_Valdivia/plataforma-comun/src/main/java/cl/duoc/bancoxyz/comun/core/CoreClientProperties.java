package cl.duoc.bancoxyz.comun.core;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Valores de configuracion del cliente hacia el core, leidos del
 * {@code config-repo/bff-*.yml} de CADA BFF bajo el prefijo {@code core}.
 *
 * <p><b>Rol en la arquitectura: esta clase es la frontera exacta entre
 * mecanismo y politica.</b> La CLASE vive en la libreria compartida, porque
 * todos los canales necesitan las mismas cuatro perillas. Los VALORES viven en
 * el YAML de cada canal, porque cada canal las gira distinto. Un solo ejemplo
 * lo deja claro: en el S5 el timeout de lectura era 5 segundos en web, 3 en movil y 2 en
 * el cajero (desde F6, medido, los tres usan 500 ms de conexion y 2 s de lectura por intento). Si el
 * numero estuviera aqui, los tres canales tendrian siempre el mismo y la adaptacion por canal seria
 * imposible; si la clase estuviera repetida en cada canal, agregar una perilla obligaria a tocar tres
 * archivos. Estos tiempos son los de CADA INTENTO: el reintento de Resilience4j
 * ({@code CoreClientResiliente}) los repite, y el TimeLimiter de la libreria no aplica a una llamada
 * bloqueante, asi que el limite de tiempo es siempre este.
 *
 * <p>Ejemplo de configuracion, tomado del canal del cajero:
 * <pre>
 * core:
 *   base-url: http://core-service
 *   timeout-conexion: 500ms
 *   timeout-lectura: 2s
 * </pre>
 *
 * <p><b>Nota de cableado que impide arrancar si se olvida.</b> La anotacion
 * {@code @SpringBootApplication} incluye el escaneo de componentes pero NO el
 * de propiedades de configuracion. Una clase anotada solo con
 * {@code @ConfigurationProperties} no se registra como bean, y el arranque
 * muere con un mensaje del tipo <i>"Parameter 1 of constructor in
 * RestCoreClient required a bean of type CoreClientProperties that could not be
 * found"</i>, que no dice en absoluto que falta una anotacion. La clase
 * principal de cada BFF debe llevar, en una linea aparte:
 * <pre>
 * &#64;ConfigurationPropertiesScan({"cl.duoc.bancoxyz.bff.atm", "cl.duoc.bancoxyz.comun"})
 * </pre>
 *
 * <p><b>Por que un record y no una clase con getters y setters.</b> Spring
 * Boot enlaza records por constructor, lo que tiene una consecuencia util: los
 * valores quedan fijados al arrancar y nadie puede cambiarlos en caliente. Una
 * configuracion que cambia mientras el programa corre es una fuente de fallos
 * que no se reproducen.
 *
 * @param baseUrl         raiz del core, sin barra final ni prefijo de recursos. Es el NOMBRE
 *                        LOGICO con el que el core se registra en Eureka
 *                        ({@code http://core-service}), nunca una direccion fija
 * @param timeoutConexion cuanto esperar a ESTABLECER la conexion
 * @param timeoutLectura  cuanto esperar la RESPUESTA una vez conectado
 */
@ConfigurationProperties(prefix = "core")
public record CoreClientProperties(

        String baseUrl,

        /*
         * Un segundo por defecto para conectar, y no mas.
         *
         * Conectar es solo el apreton de manos TCP, y el core vive en
         * 127.0.0.1: en loopback eso tarda microsegundos. Si tarda mas de un
         * segundo, lo que hay no es lentitud sino un core que no esta
         * escuchando, y en ese caso lo util es enterarse rapido. Por eso este
         * timeout es corto y, a diferencia del de lectura, es igual en los
         * tres canales: no mide trabajo del core, mide si existe.
         */
        @DefaultValue("1s") Duration timeoutConexion,

        /*
         * Cinco segundos por defecto, y cada canal lo baja en su YAML: 5 en
         * web, 3 en movil, 2 en el cajero.
         *
         * El valor por defecto es el mas permisivo a proposito. Si un canal
         * olvida declararlo, hereda un limite laxo pero existente, que es
         * mucho mejor que heredar "sin limite": ese es justamente el fallo que
         * estos timeouts existen para evitar.
         */
        @DefaultValue("5s") Duration timeoutLectura) {

    /**
     * Comprueba al arrancar lo que de otro modo se descubriria en la primera
     * peticion de un usuario.
     *
     * <p><b>Por que fallar al arrancar es lo correcto aqui.</b> Un BFF sin URL
     * del core no puede atender ni una sola peticion util. Dejarlo arrancar
     * produce un proceso que responde a {@code /actuator/health} con {@code UP}
     * y falla todas las consultas: un servicio que miente sobre su propio
     * estado. Es peor que uno que no arranca, porque un balanceador le manda
     * trafico.
     *
     * <p>La credencial hacia el core ya no es una propiedad de este record: es
     * el token OAuth2 del servicio, que el {@code TokenServicioInterceptor}
     * pide al auth-server con el registro {@code servicios-internos}. Si le falta
     * el secreto o el registro, el arranque falla en la autoconfiguracion de
     * Spring Security, que lo dice con el nombre de la propiedad.
     */
    public CoreClientProperties {
        if (baseUrl == null || baseUrl.isBlank()) {
            throw new IllegalArgumentException(
                    "Falta la propiedad core.base-url. Sin ella el BFF no sabe a donde llamar.");
        }
        if (timeoutConexion.isZero() || timeoutConexion.isNegative()
                || timeoutLectura.isZero() || timeoutLectura.isNegative()) {
            throw new IllegalArgumentException(
                    "Los timeouts hacia el core deben ser positivos. Un cero significa 'esperar para "
                            + "siempre', que es exactamente lo que estos valores existen para impedir.");
        }
    }
}
