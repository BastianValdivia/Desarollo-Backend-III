package cl.duoc.bancoxyz.comun.resiliencia;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.comun.core.CoreNoDisponibleException;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

/**
 * Guarda el ULTIMO DATO CONOCIDO de cada lectura al core y lo sirve, marcado como desactualizado,
 * cuando el core no esta disponible. Es el respaldo (fallback) de los canales web y movil.
 *
 * <h2>Por que existe, si ya hay una cache</h2>
 *
 * <p>La cache de cada canal (Caffeine) optimiza: guarda un dato 30 o 60 s para no viajar al core, y
 * lo olvida al vencer. Este respaldo hace otra cosa: conserva el dato <b>mas alla</b> de su frescura
 * ({@link RespaldoProperties#antiguedadMaxima()}, 10 minutos) para el dia en que el core falle. Son
 * politicas distintas: mezclarlas obligaria a elegir entre servir saldos viejos siempre o no tener
 * respaldo nunca. Aqui el dato viejo solo sale cuando la alternativa es un 503, y siempre con la
 * advertencia ({@link DatosDesactualizados}).
 *
 * <h2>Reglas que lo mantienen seguro</h2>
 * <ul>
 *   <li><b>La titularidad se comprueba ANTES</b> de llegar aqui (los servicios de canal llaman a su
 *       guardia primero), igual que con la cache. El respaldo nunca decide quien puede ver una cuenta.</li>
 *   <li><b>Solo se respalda ante {@link CoreNoDisponibleException}</b> (core caido, lento, circuito
 *       abierto, mamparo lleno). Un 404 de una cuenta inexistente o un 409 NO se sirve desde el
 *       respaldo: son respuestas validas del core.</li>
 *   <li><b>Tiene tope de edad y de tamano</b>: un dato mas viejo que la antiguedad maxima no se sirve.</li>
 *   <li><b>El cajero no lo usa.</b> Un saldo desactualizado en un cajero es dinero entregado que ya no
 *       existe; su canal falla cerrado (ver {@code bff-atm}). Esta clase vive en la libreria comun, pero
 *       {@code config-repo/bff-atm.yml} fija {@code resiliencia.respaldo.habilitado: false} y el bean
 *       ni siquiera se crea en ese proceso: una prueba lo vigila.</li>
 * </ul>
 *
 * <h2>Por que hay dos formas de leer</h2>
 *
 * <p>{@link #leerYRespaldar} guarda el resultado cada vez que la lectura tiene exito: para lecturas
 * que van directo al core. {@link #leerConRespaldo} no guarda: es para una lectura que pasa por la
 * cache del canal, donde el que guarda es el metodo que SI viaja al core ({@link #respaldar}). Si
 * se guardara en cada acierto de cache, un dato de hace 60 s parecería recien obtenido y la
 * antiguedad que se informa al cliente seria falsa.
 */
@Component
// Registra RespaldoProperties aqui: el @ConfigurationPropertiesScan de cada BFF solo recorre
// cl.duoc.bancoxyz.comun.core, y asi la politica llega junto con el bean que la usa (y solo si existe).
@EnableConfigurationProperties(RespaldoProperties.class)
@ConditionalOnProperty(prefix = "resiliencia.respaldo", name = "habilitado", havingValue = "true",
        matchIfMissing = true)
public class RespaldoDeLecturas {

    private static final Logger log = LoggerFactory.getLogger(RespaldoDeLecturas.class);

    /** Nombre del contador de respuestas servidas desde el respaldo. */
    public static final String METRICA_SERVIDOS = "bancoxyz.respaldo.servidos";

    private record Entrada(Object valor, Instant obtenidoEn) {
    }

    private record Clave(String espacio, Object clave) {
    }

    private final Map<Clave, Entrada> entradas;
    private final Duration antiguedadMaxima;
    private final Clock reloj;
    private final MeterRegistry metricas;

    @Autowired
    public RespaldoDeLecturas(RespaldoProperties propiedades, ObjectProvider<MeterRegistry> metricas) {
        this(propiedades, Clock.systemUTC(), metricas.getIfAvailable(SimpleMeterRegistry::new));
    }

    /** Para pruebas de unidad que arman un servicio a mano: reloj del sistema y metricas descartables. */
    public static RespaldoDeLecturas paraPruebas(RespaldoProperties propiedades) {
        return new RespaldoDeLecturas(propiedades, Clock.systemUTC(), new SimpleMeterRegistry());
    }

    RespaldoDeLecturas(RespaldoProperties propiedades, Clock reloj, MeterRegistry metricas) {
        this.antiguedadMaxima = propiedades.antiguedadMaxima();
        this.reloj = reloj;
        this.metricas = metricas;
        int tope = propiedades.maximoEntradas();
        // Orden de acceso + descarte del menos usado al superar el tope: un LRU acotado.
        this.entradas = new LinkedHashMap<>(16, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<Clave, Entrada> masAntigua) {
                return size() > tope;
            }
        };
    }

    /**
     * Ejecuta la lectura y guarda su resultado; si el core no esta disponible, sirve el ultimo dato
     * guardado para esa clave (marcado como desactualizado) o, si no hay uno aceptable, relanza.
     *
     * @param espacio nombre de la operacion ("cuenta", "movimientos"...): evita que dos operaciones
     *                con la misma clave se pisen
     * @param clave   identifica la lectura (cuenta, pagina, filtros): debe tener equals y hashCode
     */
    public <V> V leerYRespaldar(String espacio, Object clave, Supplier<V> lectura) {
        return leer(espacio, clave, lectura, true);
    }

    /** Como {@link #leerYRespaldar}, pero sin guardar el resultado (ver la nota de la clase). */
    public <V> V leerConRespaldo(String espacio, Object clave, Supplier<V> lectura) {
        return leer(espacio, clave, lectura, false);
    }

    /** Olvida todo lo guardado. Lo usan las pruebas para que un caso no herede el respaldo del anterior. */
    public void vaciar() {
        synchronized (entradas) {
            entradas.clear();
        }
    }

    /** Guarda un dato recien obtenido del core. */
    public void respaldar(String espacio, Object clave, Object valor) {
        if (valor == null) {
            return;
        }
        synchronized (entradas) {
            entradas.put(new Clave(espacio, clave), new Entrada(valor, reloj.instant()));
        }
    }

    private <V> V leer(String espacio, Object clave, Supplier<V> lectura, boolean guardar) {
        try {
            V valor = lectura.get();
            if (guardar) {
                respaldar(espacio, clave, valor);
            }
            return valor;
        } catch (CoreNoDisponibleException coreNoDisponible) {
            Entrada guardada;
            synchronized (entradas) {
                guardada = entradas.get(new Clave(espacio, clave));
            }
            if (guardada == null) {
                log.warn("Core no disponible y sin dato de respaldo para {} {}: se responde 503.",
                        espacio, clave);
                throw coreNoDisponible;
            }
            Duration antiguedad = Duration.between(guardada.obtenidoEn(), reloj.instant());
            if (antiguedad.compareTo(antiguedadMaxima) > 0) {
                log.warn("Core no disponible y el dato de respaldo de {} {} tiene {} s (maximo {} s): "
                                + "se responde 503.", espacio, clave, antiguedad.toSeconds(),
                        antiguedadMaxima.toSeconds());
                throw coreNoDisponible;
            }
            log.warn("Core no disponible ({}): se sirve el ultimo dato conocido de {} {}, de hace {} s.",
                    coreNoDisponible.getClass().getSimpleName(), espacio, clave, antiguedad.toSeconds());
            DatosDesactualizados.marcar(antiguedad);
            contador(espacio).increment();
            @SuppressWarnings("unchecked")
            V valor = (V) guardada.valor();
            return valor;
        }
    }

    private Counter contador(String espacio) {
        return Counter.builder(METRICA_SERVIDOS)
                .description("Respuestas servidas con el ultimo dato conocido porque el core no estaba disponible")
                .tag("espacio", espacio)
                .register(metricas);
    }
}
