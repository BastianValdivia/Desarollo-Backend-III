package cl.duoc.bancoxyz.comun.error;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Forma BASE del cuerpo de error de la API, segun RFC 7807
 * ({@code application/problem+json}). Es el envoltorio comun a los tres
 * canales, definido en la seccion 5.16 del contrato.
 *
 * <p><b>Rol en la arquitectura.</b> Que los tres canales devuelvan errores con
 * la misma forma es una caracteristica de calidad: un cliente que ya sabe leer
 * un error de web sabe leer uno de movil. Que el CONTENIDO de esos campos
 * cambie por canal es adaptacion. Este record captura exactamente la mitad
 * compartida, y ni un campo mas.
 *
 * <p><b>Por que aqui no se decide el codigo HTTP.</b> El campo {@code status}
 * viaja dentro del JSON porque el RFC lo exige, pero quien elige su valor y
 * quien lo pone en la linea de estado de la respuesta HTTP es el manejador de
 * errores de cada BFF. Esta clase solo transporta el numero que le entreguen.
 * Si tuviera un metodo del tipo {@code paraCuentaAjena()} que fijara 403, la
 * politica se habria mudado al modulo compartido.
 *
 * <p><b>Por que faltan {@code codigoPantalla} y {@code mensajePantalla}.</b>
 * Son dos campos que existen SOLO en el canal del cajero (seccion 7.2 del
 * contrato). Meterlos aqui obligaria a web y a movil a cargar con dos campos
 * nulos que no significan nada para ellos, y convertiria el envoltorio comun
 * en el envoltorio del cajero. Como los records de Java no se pueden heredar,
 * {@code bff-atm} declara su propio record con estos siete campos mas los dos
 * suyos. Duplicar siete nombres de campo una vez es mas barato que contaminar
 * la libreria compartida con un concepto de un solo canal, y es exactamente lo
 * que el patron BFF llama duplicacion intencional.
 *
 * <p><b>Por que {@code NON_NULL}.</b> El contrato dice que el cajero omite
 * {@code detail} para no filtrar informacion en via publica. Con esta
 * anotacion, "omitir" se logra pasando {@code null} y el campo desaparece del
 * JSON; sin ella apareceria como {@code "detail": null}, que no es lo mismo:
 * un campo nulo sigue diciendo que el campo existe.
 *
 * @param type     URI del catalogo de errores. Se deriva del motivo, ver {@link #uriDeMotivo}
 * @param title    titulo corto y estable, legible por una persona
 * @param status   codigo HTTP. Debe coincidir con el de la respuesta real, o el cliente se confunde
 * @param detail   texto explicativo. {@code null} en el canal del cajero
 * @param instance ruta que se pidio, incluido el {@code context-path}
 * @param canal    {@code WEB}, {@code MOVIL} o {@code ATM}
 * @param motivo   valor de {@link MotivosError}. Es el campo que leen los guiones de evidencia
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record RespuestaError(
        String type,
        String title,
        int status,
        String detail,
        String instance,
        String canal,
        String motivo) {

    /**
     * Prefijo del catalogo de errores publicado por el banco. El RFC 7807 pide
     * que {@code type} sea una URI que identifique el TIPO de problema, no la
     * ocurrencia concreta: por eso dos errores distintos de cuenta ajena
     * comparten esta URI y se diferencian por {@code instance}.
     */
    public static final String BASE_URI_ERRORES = "https://bancoxyz.duoc.cl/errores/";

    /**
     * Traduce un motivo a su URI de catalogo, que es la unica regla de formato
     * que el contrato congela sobre el campo {@code type}: los motivos se
     * escriben con guion bajo ({@code cuenta_ajena}) y las URI con guion medio
     * ({@code .../cuenta-ajena}).
     *
     * <p>Existe como metodo y no como texto escrito a mano en cada manejador
     * porque es justo el tipo de conversion que un canal hace bien, otro
     * escribe con guion bajo y el tercero olvida, dejando tres catalogos de
     * errores distintos para un solo sistema.
     */
    public static String uriDeMotivo(String motivo) {
        return BASE_URI_ERRORES + motivo.replace('_', '-');
    }

    /**
     * Construye el cuerpo derivando {@code type} del motivo, que es la unica
     * forma en que se debe construir: asi es imposible que {@code type} y
     * {@code motivo} se contradigan.
     *
     * <p>El orden de los parametros no es casual: primero lo que identifica el
     * problema ({@code estado}, {@code motivo}, {@code titulo}) y despues lo
     * que cambia en cada ocurrencia. Un canal que quiera omitir el detalle
     * pasa {@code null} en {@code detalle}.
     */
    public static RespuestaError de(int estado,
                                    String motivo,
                                    String titulo,
                                    String detalle,
                                    String instancia,
                                    String canal) {
        return new RespuestaError(uriDeMotivo(motivo), titulo, estado, detalle, instancia, canal, motivo);
    }
}
