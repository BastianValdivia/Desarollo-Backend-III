package cl.duoc.bancoxyz.comun.core.dto;

import java.math.BigDecimal;

/**
 * Respuesta del endpoint estrecho C3 del core,
 * {@code GET /internal/v1/cuentas/{id}/saldo} (seccion 5.5 del contrato).
 *
 * <p><b>Por que existe este endpoint teniendo ya C2.</b> Porque movil y cajero
 * solo necesitan el saldo, y pedirles que llamen a C2 y descarten los 42
 * movimientos moveria por la red, cada vez, un objeto decenas de veces mas
 * grande que el dato buscado. Recortar en el BFF despues de recibir todo no es
 * optimizar: el costo ya se pago en la red del core al BFF. La optimizacion
 * real es no pedirlo, y para eso el contrato aguas arriba tiene que ofrecer un
 * endpoint estrecho.
 *
 * <p><b>Ojo con la diferencia de nombres.</b> Este DTO tiene {@code saldo} y
 * {@code cuentaId}, porque es lo que devuelve el core. La respuesta del cajero
 * (A2) tiene {@code saldoDisponible} y NO tiene {@code cuentaId}: son dos
 * contratos distintos y el BFF del cajero traduce de uno al otro. Copiar este
 * record como respuesta del cajero para ahorrarse la traduccion romperia el
 * contrato congelado por dos campos a la vez.
 *
 * @param cuentaId entero entre 101 y 150
 * @param saldo    saldo consolidado
 * @param moneda   literal {@code CLP}
 */
public record SaldoCoreDto(
        int cuentaId,
        BigDecimal saldo,
        String moneda) {
}
