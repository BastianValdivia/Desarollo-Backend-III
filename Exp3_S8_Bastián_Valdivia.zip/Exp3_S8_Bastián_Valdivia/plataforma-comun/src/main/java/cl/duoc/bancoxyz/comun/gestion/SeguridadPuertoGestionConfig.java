package cl.duoc.bancoxyz.comun.gestion;

import org.springframework.boot.actuate.autoconfigure.web.server.ConditionalOnManagementPort;
import org.springframework.boot.actuate.autoconfigure.web.server.ManagementPortType;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.web.context.WebServerApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Cadena de seguridad del PUERTO DE GESTION de los canales BFF.
 *
 * <p><b>El problema que resuelve.</b> Cuando Actuator vive en un puerto propio
 * ({@code management.server.port}), Spring Boot crea un contexto hijo para ese puerto, pero la
 * cadena de filtros de Spring Security del canal le sigue aplicando: todo lo que no sea
 * {@code /actuator/health} (que la cadena del canal deja publico) devolveria 401 pidiendo un token
 * Bearer del canal. Con eso {@code info} y {@code refresh} quedarian inalcanzables para quien opera
 * el servicio, y el healthcheck de Docker y la demostracion de refresh se romperian.
 *
 * <p><b>Que hace.</b> Registra una cadena adicional, con la maxima prioridad, que se aplica a TODA
 * peticion que llegue por el puerto de gestion y la deja pasar sin credencial. Es una decision de
 * frontera de confianza, no un descuido:
 * <ul>
 *   <li>el puerto de gestion NO se publica fuera: en local escucha solo en 127.0.0.1 y en Docker no
 *       se mapea al host, asi que solo lo alcanzan el propio equipo y la red interna;</li>
 *   <li>solo estan expuestos {@code health, info, metrics y refresh} (ver
 *       {@code config-repo/application.yml}); {@code env}, {@code configprops} y {@code heapdump}
 *       ni existen y responden 404 (con la cadena del canal responderian 401, que oculta el 404 y
 *       confunde a quien verifica que no estan expuestos);</li>
 *   <li>{@code refresh} solo hace que el servicio vuelva a leer SU configuracion del config-server:
 *       no acepta datos del llamante.</li>
 * </ul>
 *
 * <p><b>Que NO hace, y es la mitad importante.</b> Solo se activa cuando el puerto de gestion es
 * DISTINTO del de servicio ({@link ConditionalOnManagementPort}). Si Actuator compartiera el puerto
 * del canal, esta cadena no existiria y {@code metrics} seguiria exigiendo token como en el S5
 * (lo comprueban las pruebas de autorizacion de cada canal). Y el emparejador distingue por el
 * contexto que atiende la peticion, no por la ruta: una peticion al puerto de servicio a
 * {@code /actuator/...} no coincide, cae en la cadena del canal y exige token.
 *
 * <p>Vive en la libreria compartida porque la regla es la misma en los tres canales (mecanismo) y
 * la recogen con el escaneo de {@code cl.duoc.bancoxyz.comun}. El core no la carga: no usa Spring
 * Security, su proteccion es un filtro propio limitado a {@code /internal/}.
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnClass({ConditionalOnManagementPort.class, HttpSecurity.class})
@ConditionalOnManagementPort(ManagementPortType.DIFFERENT)
public class SeguridadPuertoGestionConfig {

    /**
     * Coincide con las peticiones que atiende el servidor de gestion. Spring Boot le da a ese
     * servidor un contexto hijo con el espacio de nombres {@code "management"}; es la misma
     * distincion que usa {@code EndpointRequest} y no depende de numeros de puerto (que pueden ser
     * aleatorios en las pruebas) ni de rutas.
     */
    private static final RequestMatcher PETICION_AL_PUERTO_DE_GESTION = peticion -> {
        WebApplicationContext contexto =
                WebApplicationContextUtils.getWebApplicationContext(peticion.getServletContext());
        return contexto != null && WebServerApplicationContext.hasServerNamespace(contexto, "management");
    };

    /**
     * Cadena que solo atiende el puerto de gestion. {@code HIGHEST_PRECEDENCE} para que se evalue
     * antes que la del canal (que coincide con cualquier ruta).
     *
     * <p>CSRF se desactiva porque {@code refresh} es un POST sin sesion ni cookies: el servicio es
     * sin estado y no hay navegador con una sesion que un tercero pudiera aprovechar.
     */
    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    public SecurityFilterChain cadenaDelPuertoDeGestion(HttpSecurity http) throws Exception {
        http
                .securityMatcher(PETICION_AL_PUERTO_DE_GESTION)
                .authorizeHttpRequests(reglas -> reglas.anyRequest().permitAll())
                .csrf(csrf -> csrf.disable())
                .sessionManagement(sesion -> sesion.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
        return http.build();
    }
}
