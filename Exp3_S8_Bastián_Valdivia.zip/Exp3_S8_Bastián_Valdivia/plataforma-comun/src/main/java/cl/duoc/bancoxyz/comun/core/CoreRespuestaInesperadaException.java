package cl.duoc.bancoxyz.comun.core;

/**
 * El core respondio algo que este cliente no sabe interpretar.
 *
 * <p>Es la rama "todo lo demas" de la traduccion de errores: cualquier codigo
 * 4xx que no sea 401, 403, 404, 409 ni el 422 de clave reutilizada, y tambien el caso en que la respuesta
 * llego con estado exitoso pero el cuerpo no se pudo deserializar.
 *
 * <p><b>Por que existe una rama para lo desconocido, en vez de dejar escapar
 * la excepcion original.</b> Porque sin ella, un caso no previsto sube por la
 * pila como una excepcion de Spring (un {@code RestClientException}, por
 * ejemplo) y el manejador de errores del canal, que sabe tratar
 * {@link CoreException}, no la reconoce: el cliente recibe un 500 con la
 * pagina de error generica en lugar del cuerpo RFC 7807 del sistema. Con esta
 * clase, la garantia se vuelve total: <b>toda</b> llamada que salga de
 * {@link CoreClient} falla, si falla, como una {@link CoreException}, y ningun
 * canal necesita un {@code catch} de reserva para lo imprevisto.
 *
 * <p>Es tambien la excepcion que aparece cuando el contrato entre el core y
 * los BFF se desincroniza, que es el riesgo concreto de construir los dos
 * modulos en paralelo. Su mensaje y su {@link CoreException#cuerpoCrudo()} son
 * lo que permite ver de inmediato que el core esta devolviendo un nombre de
 * campo distinto al congelado.
 */
public class CoreRespuestaInesperadaException extends CoreException {

    public CoreRespuestaInesperadaException(String mensaje,
                                            String rutaSolicitada,
                                            Integer estadoDelCore,
                                            String cuerpoCrudo,
                                            Throwable causa) {
        super(mensaje, rutaSolicitada, estadoDelCore, cuerpoCrudo, causa);
    }
}
