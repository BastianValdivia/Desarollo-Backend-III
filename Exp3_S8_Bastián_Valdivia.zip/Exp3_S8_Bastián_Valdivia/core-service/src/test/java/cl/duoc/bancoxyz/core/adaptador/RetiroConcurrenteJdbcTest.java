package cl.duoc.bancoxyz.core.adaptador;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicLong;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.TipoMovimiento;
import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;
import cl.duoc.bancoxyz.core.soporte.Concurrencia;
import cl.duoc.bancoxyz.core.soporte.Concurrencia.Resultado;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * La prueba de concurrencia del S5, ahora contra PostgreSQL y <strong>repartida entre dos
 * "replicas"</strong>.
 *
 * <p>La version del S5 ({@code RetiroConcurrenteTest}) soltaba 20 hilos sobre un mapa en memoria:
 * demostraba que {@code ConcurrentHashMap.compute} serializa los retiros dentro de UN proceso. Con dos
 * replicas del core eso ya no alcanza, porque cada proceso tendria su propio mapa. Aqui los 20 retiros
 * se reparten entre dos pools de conexiones independientes sobre la misma base (cada pool es una
 * replica: no comparten memoria ni cerrojos de la JVM), de modo que la unica exclusion posible es la
 * que da PostgreSQL con el {@code UPDATE} condicional.
 *
 * <p>Resultado esperado, exacto: la cuenta tiene 12000 y cada retiro es de 1000, asi que pasan
 * <strong>12 y solo 12</strong>, los otros 8 reciben saldo insuficiente, el saldo final es cero (nunca
 * negativo) y hay exactamente 12 movimientos nuevos: por cada descuento, un apunte.
 */
class RetiroConcurrenteJdbcTest {

    private static final int CUENTA = 116;
    private static final int HILOS = 20;

    private static HikariDataSource poolReplicaA;
    private static HikariDataSource poolReplicaB;
    private static CuentaRepositoryJdbc replicaA;
    private static CuentaRepositoryJdbc replicaB;

    @BeforeAll
    static void prepararBase() {
        PostgresDePrueba.Base base = PostgresDePrueba.crearBaseMigrada();
        poolReplicaA = base.nuevoPool(10);
        poolReplicaB = base.nuevoPool(10);
        replicaA = new CuentaRepositoryJdbc(JdbcClient.create(poolReplicaA), new DataSourceTransactionManager(poolReplicaA));
        replicaB = new CuentaRepositoryJdbc(JdbcClient.create(poolReplicaB), new DataSourceTransactionManager(poolReplicaB));
    }

    @AfterAll
    static void cerrar() {
        poolReplicaA.close();
        poolReplicaB.close();
    }

    @Test
    @DisplayName("20 retiros simultaneos de 1000 sobre 12000, repartidos entre dos replicas: exactamente 12 pasan, saldo 0")
    void veinteRetirosEntreDosReplicas() {
        AtomicLong idMovimiento = new AtomicLong(100_000);
        List<Callable<Boolean>> tareas = new ArrayList<>();
        for (int i = 0; i < HILOS; i++) {
            CuentaRepositoryJdbc replica = (i % 2 == 0) ? replicaA : replicaB;
            tareas.add(() -> {
                replica.debitar(CUENTA, new BigDecimal("1000"), "RET-PRUEBA", LocalDate.now(),
                        idMovimiento.incrementAndGet());
                return true;
            });
        }

        List<Resultado<Boolean>> resultados = Concurrencia.enParalelo(tareas);

        long exitos = resultados.stream().filter(Resultado::fueExito).count();
        long rechazos = resultados.stream()
                .filter(r -> r.error() instanceof SaldoInsuficienteException).count();
        assertThat(exitos).as("exitos: 12000 / 1000 = 12, ni uno mas ni uno menos").isEqualTo(12);
        assertThat(rechazos).as("rechazos por saldo insuficiente").isEqualTo(HILOS - 12);
        assertThat(resultados).as("no hay otro tipo de fallo (interbloqueos, errores de la base)")
                .allMatch(r -> r.fueExito() || r.error() instanceof SaldoInsuficienteException);

        // Las dos replicas ven el mismo estado final.
        for (CuentaRepositoryJdbc replica : List.of(replicaA, replicaB)) {
            Cuenta cuenta = replica.buscarPorId(CUENTA).orElseThrow();
            assertThat(cuenta.saldo()).as("saldo final: cuadra y nunca es negativo")
                    .isEqualByComparingTo(BigDecimal.ZERO);
            // 42 movimientos de la carga + 12 retiros: por cada descuento, exactamente un apunte.
            assertThat(cuenta.movimientos()).hasSize(42 + 12);
            assertThat(cuenta.movimientos().stream()
                    .filter(m -> m.tipo() == TipoMovimiento.RETIRO && m.id() > 100_000)).hasSize(12);
        }
    }

    @Test
    @DisplayName("Diez retiros simultaneos de 1000 sobre 5000, repartidos entre dos replicas: cinco exitos y saldo cero")
    void diezRetirosSobreCincoMil() {
        AtomicLong idMovimiento = new AtomicLong(200_000);
        List<Callable<Boolean>> tareas = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            CuentaRepositoryJdbc replica = (i % 2 == 0) ? replicaA : replicaB;
            tareas.add(() -> {
                replica.debitar(106, new BigDecimal("1000"), "RET-PRUEBA", LocalDate.now(),
                        idMovimiento.incrementAndGet());
                return true;
            });
        }

        List<Resultado<Boolean>> resultados = Concurrencia.enParalelo(tareas);

        assertThat(resultados.stream().filter(Resultado::fueExito).count()).isEqualTo(5);
        assertThat(resultados.stream().filter(r -> r.error() instanceof SaldoInsuficienteException).count())
                .isEqualTo(5);
        assertThat(replicaA.buscarPorId(106).orElseThrow().saldo()).isEqualByComparingTo(BigDecimal.ZERO);
    }

    @Test
    @DisplayName("Retiros que no caben, con montos distintos y mezclados: la suma retirada nunca supera el saldo")
    void montosMezcladosNuncaSuperanElSaldo() {
        // Cuenta 105 con 10000. Retiros de 3000 y de 4000 mezclados: el saldo final debe ser
        // exactamente 10000 menos lo que efectivamente se entrego, y nunca negativo.
        AtomicLong idMovimiento = new AtomicLong(300_000);
        List<Callable<BigDecimal>> tareas = new ArrayList<>();
        for (int i = 0; i < 12; i++) {
            CuentaRepositoryJdbc replica = (i % 2 == 0) ? replicaA : replicaB;
            BigDecimal monto = new BigDecimal(i % 3 == 0 ? "4000" : "3000");
            tareas.add(() -> {
                replica.debitar(105, monto, "RET-PRUEBA", LocalDate.now(), idMovimiento.incrementAndGet());
                return monto;
            });
        }

        List<Resultado<BigDecimal>> resultados = Concurrencia.enParalelo(tareas);

        BigDecimal entregado = resultados.stream().filter(Resultado::fueExito)
                .map(Resultado::valor).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal saldoFinal = replicaA.buscarPorId(105).orElseThrow().saldo();
        assertThat(saldoFinal).isGreaterThanOrEqualTo(BigDecimal.ZERO);
        assertThat(saldoFinal).as("saldo final = 10000 - lo entregado").isEqualByComparingTo(
                new BigDecimal("10000").subtract(entregado));
        assertThat(entregado).isLessThanOrEqualTo(new BigDecimal("10000"));
    }
}
