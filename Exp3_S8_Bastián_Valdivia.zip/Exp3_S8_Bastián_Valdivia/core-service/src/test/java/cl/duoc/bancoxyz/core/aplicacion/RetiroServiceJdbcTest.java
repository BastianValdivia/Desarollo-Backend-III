package cl.duoc.bancoxyz.core.aplicacion;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.adaptador.CuentaRepositoryJdbc;
import cl.duoc.bancoxyz.core.adaptador.GeneradorIdentificadoresJdbc;
import cl.duoc.bancoxyz.core.adaptador.OutboxJdbc;
import cl.duoc.bancoxyz.core.adaptador.RegistroIdempotenciaJdbc;
import cl.duoc.bancoxyz.core.config.CoreProperties;
import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaReutilizadaException;
import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;
import cl.duoc.bancoxyz.core.soporte.Concurrencia;
import cl.duoc.bancoxyz.core.soporte.Concurrencia.Resultado;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * El caso de uso de retiro completo (servicio de aplicacion + adaptadores JDBC reales), con dos
 * instancias del servicio que comparten una sola base: dos replicas del core.
 *
 * <p>Es la prueba de extremo a extremo de las tres garantias de un retiro cuando hay mas de una
 * replica: el folio nunca se repite entre replicas, un reintento con la misma clave no descuenta dos
 * veces aunque caiga en la otra, y retiros simultaneos nunca dejan el saldo negativo.
 */
class RetiroServiceJdbcTest {

    private static HikariDataSource poolA;
    private static HikariDataSource poolB;
    private static RetiroService replicaA;
    private static RetiroService replicaB;
    private static CuentaRepositoryJdbc cuentas;

    private static RetiroService servicio(HikariDataSource pool) {
        JdbcClient jdbc = JdbcClient.create(pool);
        DataSourceTransactionManager gestor = new DataSourceTransactionManager(pool);
        CoreProperties propiedades = new CoreProperties(
                new CoreProperties.Paginacion(20, 100), "CLP", new CoreProperties.Folio("RET", 6));
        Clock reloj = Clock.fixed(Instant.parse("2026-09-11T15:00:00Z"), ZoneId.of("UTC"));
        return new RetiroService(new CuentaRepositoryJdbc(jdbc, gestor), new RegistroIdempotenciaJdbc(jdbc, gestor),
                new GeneradorIdentificadoresJdbc(jdbc), propiedades, reloj, new OutboxJdbc(jdbc), gestor);
    }

    @BeforeAll
    static void prepararBase() {
        PostgresDePrueba.Base base = PostgresDePrueba.crearBaseMigrada();
        poolA = base.nuevoPool(10);
        poolB = base.nuevoPool(10);
        replicaA = servicio(poolA);
        replicaB = servicio(poolB);
        cuentas = new CuentaRepositoryJdbc(JdbcClient.create(poolA), new DataSourceTransactionManager(poolA));
    }

    @AfterAll
    static void cerrar() {
        poolA.close();
        poolB.close();
    }

    @Test
    @DisplayName("El folio tiene la forma RET-yyyyMMdd-NNNNNN y las dos replicas nunca emiten el mismo")
    void foliosUnicosEntreReplicas() {
        ResultadoRetiro deA = replicaA.retirar(120, new BigDecimal("1000"), null);
        ResultadoRetiro deB = replicaB.retirar(120, new BigDecimal("1000"), null);

        assertThat(deA.folio()).matches("RET-20260911-\\d{6}");
        assertThat(deB.folio()).matches("RET-20260911-\\d{6}");
        assertThat(deB.folio()).isNotEqualTo(deA.folio());
    }

    @Test
    @DisplayName("Reintento con la misma Idempotency-Key en la otra replica: mismo folio y un solo descuento")
    void reintentoConLaMismaClave() {
        ResultadoRetiro primero = replicaA.retirar(121, new BigDecimal("1000"), "cajero-corte-de-red-1");
        ResultadoRetiro reintento = replicaB.retirar(121, new BigDecimal("1000"), "cajero-corte-de-red-1");

        assertThat(reintento.folio()).isEqualTo(primero.folio());
        assertThat(reintento).isEqualTo(primero);
        BigDecimal saldoInicial = primero.saldoAnterior();
        assertThat(cuentas.buscarPorId(121).orElseThrow().saldo())
                .isEqualByComparingTo(saldoInicial.subtract(new BigDecimal("1000")));
    }

    @Test
    @DisplayName("Dos cuentas con la misma Idempotency-Key: cada una retira lo suyo y ninguna ve el comprobante de la otra")
    void laMismaClaveEnDosCuentas() {
        ResultadoRetiro deLa122 = replicaA.retirar(122, new BigDecimal("1000"), "clave-de-dos-cuentas");
        BigDecimal saldo123Antes = cuentas.buscarPorId(123).orElseThrow().saldo();

        ResultadoRetiro deLa123 = replicaB.retirar(123, new BigDecimal("1000"), "clave-de-dos-cuentas");

        assertThat(deLa123.folio()).isNotEqualTo(deLa122.folio());
        assertThat(deLa123.saldoAnterior()).isEqualByComparingTo(saldo123Antes);
        assertThat(cuentas.buscarPorId(123).orElseThrow().saldo())
                .isEqualByComparingTo(saldo123Antes.subtract(new BigDecimal("1000")));
    }

    @Test
    @DisplayName("La misma clave en la misma cuenta con otro importe: se rechaza y el saldo no cambia")
    void claveReutilizadaConOtroImporte() {
        replicaA.retirar(124, new BigDecimal("1000"), "clave-con-importe");
        BigDecimal saldo = cuentas.buscarPorId(124).orElseThrow().saldo();

        assertThatThrownBy(() -> replicaB.retirar(124, new BigDecimal("2000"), "clave-con-importe"))
                .isInstanceOf(ClaveIdempotenciaReutilizadaException.class);

        assertThat(cuentas.buscarPorId(124).orElseThrow().saldo()).isEqualByComparingTo(saldo);
    }

    @Test
    @DisplayName("20 retiros simultaneos con claves distintas entre dos replicas: 12 pasan, 8 se rechazan, saldo 0, folios unicos")
    void concurrenciaDelServicioEntreReplicas() {
        List<Callable<ResultadoRetiro>> tareas = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            RetiroService replica = (i % 2 == 0) ? replicaA : replicaB;
            String clave = "conc-" + i;
            tareas.add(() -> replica.retirar(116, new BigDecimal("1000"), clave));
        }

        List<Resultado<ResultadoRetiro>> resultados = Concurrencia.enParalelo(tareas);

        List<Resultado<ResultadoRetiro>> exitos = resultados.stream().filter(Resultado::fueExito).toList();
        assertThat(exitos).hasSize(12);
        assertThat(resultados.stream().filter(r -> r.error() instanceof SaldoInsuficienteException).count())
                .isEqualTo(8);
        assertThat(exitos.stream().map(r -> r.valor().folio()).distinct()).as("12 folios distintos").hasSize(12);
        assertThat(cuentas.buscarPorId(116).orElseThrow().saldo()).isEqualByComparingTo(BigDecimal.ZERO);
        assertThat(cuentas.buscarPorId(116).orElseThrow().movimientos()).hasSize(42 + 12);
    }
}
