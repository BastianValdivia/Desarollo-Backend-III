package cl.duoc.bancoxyz.core.eventos;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;

import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * El liderazgo del relay con el lock consultivo de PostgreSQL: solo una replica es lider, el relevo
 * ocurre al ceder o al caer la conexion, y nadie queda lider sin serlo.
 */
class LiderRelayTest {

    private static HikariDataSource pool;
    private static JdbcClient jdbc;

    @BeforeAll
    static void preparar() {
        pool = PostgresDePrueba.crearBase().nuevoPool(6);
        jdbc = JdbcClient.create(pool);
    }

    @AfterAll
    static void cerrar() {
        pool.close();
    }

    @Test
    @DisplayName("De dos replicas solo una es lider, y la otra lo es en cuanto la primera cede")
    void soloUnaEsLider() {
        try (LiderRelay a = new LiderRelay(pool); LiderRelay b = new LiderRelay(pool)) {
            assertThat(a.esLider()).as("la primera en preguntar toma el liderazgo").isTrue();
            assertThat(b.esLider()).as("la segunda no puede mientras la primera lo tenga").isFalse();
            assertThat(a.esLider()).as("la lider sigue siendolo en el ciclo siguiente").isTrue();
            assertThat(b.esLider()).isFalse();

            a.close();

            assertThat(b.esLider()).as("al ceder, la otra toma el relevo en su proximo ciclo").isTrue();
            assertThat(a.esLider()).as("y la que cedio ya no es lider").isFalse();
        }
    }

    @Test
    @DisplayName("Si la conexion de la lider muere (caida del proceso), PostgreSQL libera el lock y otra replica toma el relevo")
    void relevoPorCaidaDeLaConexion() {
        try (LiderRelay a = new LiderRelay(pool); LiderRelay b = new LiderRelay(pool)) {
            assertThat(a.esLider()).isTrue();
            assertThat(b.esLider()).isFalse();

            // Se mata a la sesion que tiene el lock, como si el proceso hubiera muerto: PostgreSQL libera el
            // lock solo, sin que nadie lo pida.
            int terminadas = jdbc.sql("""
                            SELECT count(pg_terminate_backend(pid)) FROM pg_locks
                             WHERE locktype = 'advisory' AND granted
                               AND pid <> pg_backend_pid()""")
                    .query(Integer.class).single();
            assertThat(terminadas).as("habia una sesion con el lock").isEqualTo(1);

            // La replica que pregunta primero se queda con el liderazgo; la lider caida ya no lo es.
            assertThat(b.esLider()).as("la otra replica toma el relevo").isTrue();
            assertThat(a.esLider()).as("la lider original detecto que su conexion murio y no sigue publicando").isFalse();
        }
    }
}
