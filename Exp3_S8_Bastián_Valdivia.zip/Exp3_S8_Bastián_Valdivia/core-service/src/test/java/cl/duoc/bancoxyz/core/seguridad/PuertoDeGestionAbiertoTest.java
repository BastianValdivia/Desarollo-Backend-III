package cl.duoc.bancoxyz.core.seguridad;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalManagementPort;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.core.soporte.EmisorDePrueba;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * El healthcheck de Docker sigue funcionando: con el puerto de gestion separado, {@code /actuator/health}
 * responde sin token, y los endpoints que no se exponen (env, configprops, heapdump) siguen sin existir.
 * En el puerto de servicio, en cambio, {@code /actuator/...} exige token como cualquier otra ruta.
 *
 * <p>Es el equivalente, para el core, de lo que {@code SeguridadPuertoGestionConfigTest} comprueba en la
 * libreria compartida de los BFF.
 */
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"management.server.port=0"})
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
class PuertoDeGestionAbiertoTest {

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @LocalServerPort
    private int puertoDeServicio;

    @LocalManagementPort
    private int puertoDeGestion;

    private final HttpClient cliente = HttpClient.newHttpClient();

    private HttpResponse<String> get(int puerto, String ruta) throws Exception {
        return cliente.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + puerto + ruta)).GET().build(),
                HttpResponse.BodyHandlers.ofString());
    }

    @Test
    @DisplayName("El puerto de gestion responde health (UP) y metrics sin token")
    void gestionAbierta() throws Exception {
        assertThat(puertoDeGestion).isNotEqualTo(puertoDeServicio);

        HttpResponse<String> salud = get(puertoDeGestion, "/actuator/health");
        assertThat(salud.statusCode()).isEqualTo(200);
        assertThat(salud.body()).contains("UP");
        assertThat(get(puertoDeGestion, "/actuator/metrics").statusCode()).isEqualTo(200);
    }

    @Test
    @DisplayName("env, configprops y heapdump no existen en el puerto de gestion (404, no 401)")
    void loQueNoSeExponeNoExiste() throws Exception {
        for (String ruta : new String[] {"/actuator/env", "/actuator/configprops", "/actuator/heapdump"}) {
            assertThat(get(puertoDeGestion, ruta).statusCode()).as(ruta).isEqualTo(404);
        }
    }

    @Test
    @DisplayName("En el puerto de servicio, /actuator/health exige token")
    void elPuertoDeServicioNoSirveActuator() throws Exception {
        assertThat(get(puertoDeServicio, "/actuator/health").statusCode()).isEqualTo(401);
    }
}
