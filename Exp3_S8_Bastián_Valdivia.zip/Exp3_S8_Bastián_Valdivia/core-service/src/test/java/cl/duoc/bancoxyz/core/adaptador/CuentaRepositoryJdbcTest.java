package cl.duoc.bancoxyz.core.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.Movimiento;
import cl.duoc.bancoxyz.core.dominio.OrigenDato;
import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.TipoCuenta;
import cl.duoc.bancoxyz.core.dominio.TipoMovimiento;
import cl.duoc.bancoxyz.core.dominio.error.CuentaNoEncontradaException;
import cl.duoc.bancoxyz.core.dominio.error.MontoInvalidoException;
import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * El adaptador JDBC de las cuentas contra un PostgreSQL real (Testcontainers), con la base ya
 * migrada: las 50 cuentas de la carga inicial.
 *
 * <p>Comprueba que el adaptador cumple el contrato del puerto {@code CuentaRepository} igual que lo
 * cumplia el de memoria del S5 (mismas cuentas, mismo orden de historial, mismos errores) y que el
 * retiro es atomico. La concurrencia entre replicas esta aparte, en {@code RetiroConcurrenteJdbcTest}.
 * Cada prueba recibe su propia base recien migrada (crearla cuesta menos de un segundo): como varias
 * modifican saldos o agregan cuentas, compartir una dejaria a cada una dependiendo del orden en que
 * corrieron las demas.
 */
class CuentaRepositoryJdbcTest {

    private HikariDataSource pool;
    private CuentaRepositoryJdbc repositorio;
    private JdbcClient jdbc;

    @BeforeEach
    void prepararBase() {
        pool = PostgresDePrueba.crearBaseMigrada().nuevoPool(5);
        jdbc = JdbcClient.create(pool);
        repositorio = new CuentaRepositoryJdbc(jdbc, new DataSourceTransactionManager(pool));
    }

    @AfterEach
    void cerrar() {
        pool.close();
    }

    @Test
    @DisplayName("Las 50 cuentas de la carga estan en la base, de la 101 a la 150")
    void listarTodasDevuelveLasCincuenta() {
        List<Cuenta> cuentas = List.copyOf(repositorio.listarTodas());

        assertThat(cuentas).hasSize(50);
        assertThat(cuentas).extracting(Cuenta::id).first().isEqualTo(101);
        assertThat(cuentas).extracting(Cuenta::id).last().isEqualTo(150);
        assertThat(cuentas.stream().mapToInt(c -> c.movimientos().size()).sum()).isEqualTo(686);
    }

    @Test
    @DisplayName("Las cuentas de control tienen los valores medidos en el S5 (incluida la 130 sin movimientos)")
    void lasCuentasDeControlCuadran() {
        verificar(116, "Diana Prince", "12000", TipoCuenta.HIPOTECA, 30, 42);
        verificar(106, "Diana Prince", "5000", TipoCuenta.AHORRO, 35, 43);
        verificar(105, "Alice Brown", "10000", TipoCuenta.PRESTAMO, 25, 39);
        verificar(101, "Bob Johnson", "8000", TipoCuenta.HIPOTECA, 35, 29);
        verificar(130, "John Doe", "5000", TipoCuenta.PRESTAMO, 25, 0);
    }

    @Test
    @DisplayName("Una cuenta inexistente da Optional vacio, no una excepcion")
    void cuentaInexistente() {
        assertThat(repositorio.buscarPorId(999)).isEmpty();
    }

    @Test
    @DisplayName("El historial sale del mas reciente al mas antiguo, con desempate por id")
    void historialEnOrdenCanonico() {
        List<Movimiento> movimientos = repositorio.buscarPorId(116).orElseThrow().movimientos();

        for (int i = 1; i < movimientos.size(); i++) {
            Movimiento anterior = movimientos.get(i - 1);
            Movimiento actual = movimientos.get(i);
            assertThat(anterior.fecha()).isAfterOrEqualTo(actual.fecha());
            if (anterior.fecha().isEqual(actual.fecha())) {
                assertThat(anterior.id()).isGreaterThan(actual.id());
            }
        }
    }

    @Test
    @DisplayName("Un retiro descuenta el saldo, registra el movimiento y devuelve el comprobante")
    void retiroExitoso() {
        ResultadoRetiro comprobante = repositorio.debitar(
                105, new BigDecimal("3000"), "RET-PRUEBA-1", LocalDate.of(2026, 3, 10), 9001L);

        assertThat(comprobante.folio()).isEqualTo("RET-PRUEBA-1");
        assertThat(comprobante.saldoAnterior()).isEqualByComparingTo("10000");
        assertThat(comprobante.montoRetirado()).isEqualByComparingTo("3000");
        assertThat(comprobante.saldoPosterior()).isEqualByComparingTo("7000");

        Cuenta cuenta = repositorio.buscarPorId(105).orElseThrow();
        assertThat(cuenta.saldo()).isEqualByComparingTo("7000");
        assertThat(cuenta.movimientos()).hasSize(40);
        Movimiento apunte = cuenta.movimientos().stream().filter(m -> m.id() == 9001L).findFirst().orElseThrow();
        assertThat(apunte.tipo()).isEqualTo(TipoMovimiento.RETIRO);
        assertThat(apunte.origen()).isEqualTo(OrigenDato.RETIRO_ATM);
        assertThat(apunte.monto()).isEqualByComparingTo("3000");
        assertThat(apunte.fecha()).isEqualTo(LocalDate.of(2026, 3, 10));
    }

    @Test
    @DisplayName("El apunte del retiro tiene la misma descripcion que genera el dominio (Cuenta.conRetiro)")
    void laDescripcionDelApunteCoincideConElDominio() {
        Cuenta modelo = new Cuenta(1, "Titular", new BigDecimal("5000"), 30, TipoCuenta.AHORRO, List.of());
        Movimiento delDominio = modelo.conRetiro(new BigDecimal("1000"), 1L, LocalDate.of(2026, 1, 1))
                .movimientos().get(0);

        assertThat(CuentaRepositoryJdbc.DESCRIPCION_RETIRO_ATM).isEqualTo(delDominio.descripcion());
    }

    @Test
    @DisplayName("Retirar mas que el saldo da SaldoInsuficiente y no modifica nada; retirar justo el saldo si se puede")
    void saldoInsuficienteNoDejaEfectosParciales() {
        assertThatThrownBy(() -> repositorio.debitar(
                110, new BigDecimal("999999"), "RET-PRUEBA-2", LocalDate.now(), 9002L))
                .isInstanceOf(SaldoInsuficienteException.class);

        Cuenta antes = repositorio.buscarPorId(110).orElseThrow();
        assertThat(antes.saldo()).isGreaterThan(BigDecimal.ZERO);
        assertThat(antes.movimientos()).noneMatch(m -> m.id() == 9002L);
        // Se repite con el saldo exacto: retirar TODO el saldo es valido (>=), y un peso mas no.
        BigDecimal saldo = antes.saldo();
        assertThatThrownBy(() -> repositorio.debitar(
                110, saldo.add(BigDecimal.ONE), "RET-PRUEBA-3", LocalDate.now(), 9003L))
                .isInstanceOf(SaldoInsuficienteException.class);
        repositorio.debitar(110, saldo, "RET-PRUEBA-4", LocalDate.now(), 9004L);
        assertThat(repositorio.buscarPorId(110).orElseThrow().saldo()).isEqualByComparingTo(BigDecimal.ZERO);
    }

    @Test
    @DisplayName("Un retiro sobre una cuenta inexistente lanza CuentaNoEncontrada")
    void cuentaInexistenteEnRetiro() {
        assertThatThrownBy(() -> repositorio.debitar(
                999, new BigDecimal("1000"), "RET-PRUEBA-5", LocalDate.now(), 9005L))
                .isInstanceOf(CuentaNoEncontradaException.class);
    }

    @Test
    @DisplayName("Un monto que se redondea a cero se rechaza como invalido, no como un error 500 de la base")
    void montoQueSeRedondeaACero() {
        assertThatThrownBy(() -> repositorio.debitar(
                111, new BigDecimal("0.001"), "RET-PRUEBA-6", LocalDate.now(), 9006L))
                .isInstanceOf(MontoInvalidoException.class);
    }

    @Test
    @DisplayName("Si falla el apunte del movimiento, el descuento se deshace (todo o nada)")
    void siFallaElApunteSeDeshaceElDescuento() {
        BigDecimal saldoAntes = repositorio.buscarPorId(112).orElseThrow().saldo();
        // El id 1 ya existe (es un movimiento de la carga): el INSERT del apunte viola la clave primaria
        // DESPUES de que el UPDATE ya descontara dentro de la misma transaccion.
        assertThatThrownBy(() -> repositorio.debitar(
                112, new BigDecimal("1000"), "RET-PRUEBA-7", LocalDate.now(), 1L))
                .isInstanceOf(DataIntegrityViolationException.class);

        assertThat(repositorio.buscarPorId(112).orElseThrow().saldo()).isEqualByComparingTo(saldoAntes);
    }

    @Test
    @DisplayName("La base rechaza un saldo negativo aunque alguien se salte la condicion del UPDATE")
    void laRestriccionCheckEsLaUltimaLineaDeDefensa() {
        assertThatThrownBy(() -> jdbc.sql("UPDATE cuenta SET saldo = -1 WHERE id = 113").update())
                .isInstanceOf(DataIntegrityViolationException.class)
                .hasMessageContaining("cuenta_saldo_no_negativo");
    }

    @Test
    @DisplayName("guardar inserta una cuenta nueva y, al repetirlo, la reemplaza con exactamente sus movimientos")
    void guardarInsertaYReemplaza() {
        Movimiento a = new Movimiento(8001L, 777, LocalDate.of(2026, 1, 5), TipoMovimiento.DEPOSITO,
                new BigDecimal("100"), "uno", OrigenDato.CSV_SEMILLA);
        Movimiento b = new Movimiento(8002L, 777, LocalDate.of(2026, 1, 6), TipoMovimiento.PAGO,
                new BigDecimal("50"), null, OrigenDato.CSV_SEMILLA);
        repositorio.guardar(new Cuenta(777, "Cuenta Nueva", new BigDecimal("500"), 40, TipoCuenta.AHORRO,
                List.of(a, b)));

        Cuenta guardada = repositorio.buscarPorId(777).orElseThrow();
        assertThat(guardada.titular()).isEqualTo("Cuenta Nueva");
        assertThat(guardada.movimientos()).containsExactly(b, a);
        assertThat(guardada.movimientos().get(0).descripcion()).as("la descripcion ausente se conserva").isNull();

        repositorio.guardar(new Cuenta(777, "Titular Cambiado", new BigDecimal("900"), 41, TipoCuenta.PRESTAMO,
                List.of(a)));

        Cuenta reemplazada = repositorio.buscarPorId(777).orElseThrow();
        assertThat(reemplazada.titular()).isEqualTo("Titular Cambiado");
        assertThat(reemplazada.saldo()).isEqualByComparingTo("900");
        assertThat(reemplazada.tipo()).isEqualTo(TipoCuenta.PRESTAMO);
        assertThat(reemplazada.movimientos()).containsExactly(a);

        repositorio.guardar(new Cuenta(777, "Sin Historial", new BigDecimal("900"), 41, TipoCuenta.PRESTAMO,
                List.of()));
        assertThat(repositorio.buscarPorId(777).orElseThrow().movimientos()).isEmpty();
    }

    private void verificar(int id, String titular, String saldo, TipoCuenta tipo, int edad, int movimientos) {
        Cuenta cuenta = repositorio.buscarPorId(id).orElseThrow();

        assertThat(cuenta.titular()).as("titular de la cuenta %d", id).isEqualTo(titular);
        assertThat(cuenta.saldo()).as("saldo de la cuenta %d", id).isEqualByComparingTo(saldo);
        assertThat(cuenta.tipo()).as("tipo de la cuenta %d", id).isEqualTo(tipo);
        assertThat(cuenta.edadTitular()).as("edad de la cuenta %d", id).isEqualTo(edad);
        assertThat(cuenta.movimientos()).as("movimientos de la cuenta %d", id).hasSize(movimientos);
    }
}
