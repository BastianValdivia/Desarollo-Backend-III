package cl.duoc.bancoxyz.core.ingesta;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.MotivoDescarte;
import cl.duoc.bancoxyz.core.dominio.ReporteCalidad;

/**
 * La ingesta del S5, ahora sin estado y sin base de datos, reproduce <strong>los mismos
 * numeros</strong> sobre el dataset real.
 *
 * <p>Esta es la prueba de regresion de la carga: la migracion V2 de Flyway le entrega a PostgreSQL
 * exactamente lo que esta clase produce, asi que si estas cifras se mantienen y las pruebas de
 * Testcontainers confirman que la base las guarda, la carga en PostgreSQL da los numeros del S5. No
 * necesita Docker: corre aunque no haya base.
 */
class IngestaDatasetTest {

    private static IngestaDataset.ResultadoIngesta carga;

    @BeforeAll
    static void cargar() {
        carga = new IngestaDataset(new ReglaConsolidacion(), new ParserFechas(),
                new IngestaDataset.Origen("data/semana_3/intereses.csv",
                        "data/semana_3/cuentas_anuales.csv",
                        "data/semana_3/transacciones.csv")).cargar();
    }

    @Test
    @DisplayName("50 cuentas, 686 movimientos y 1000 transacciones sin conciliar, como en el S5")
    void lasCifrasDelS5() {
        ReporteCalidad reporte = carga.reporte();

        assertThat(carga.cuentas()).hasSize(50);
        assertThat(carga.cuentas().stream().mapToInt(c -> c.movimientos().size()).sum()).isEqualTo(686);
        assertThat(carga.loteNoConciliado()).hasSize(1000);
        assertThat(reporte.cuentasConsolidadas()).isEqualTo(50);
        assertThat(reporte.movimientosCargados()).isEqualTo(686);
        assertThat(reporte.transaccionesNoConciliadas()).isEqualTo(1000);
    }

    @Test
    @DisplayName("Los descartes informados por motivo coinciden con los medidos en el S5")
    void losDescartesPorMotivo() {
        Map<MotivoDescarte, Integer> descartes = carga.reporte().descartesPorMotivo();

        assertThat(descartes).containsOnly(
                Map.entry(MotivoDescarte.EDAD_FUERA_DE_RANGO, 362),
                Map.entry(MotivoDescarte.FECHA_ILEGIBLE, 0),
                Map.entry(MotivoDescarte.MONTO_NO_POSITIVO, 314),
                Map.entry(MotivoDescarte.SALDO_INVALIDO, 207),
                Map.entry(MotivoDescarte.TIPO_INVALIDO, 326));
    }

    @Test
    @DisplayName("Las filas duplicadas descartadas por archivo son 0, 9 y 0")
    void losDuplicadosPorArchivo() {
        List<Integer> duplicadas = carga.reporte().archivos().stream()
                .map(ReporteCalidad.ArchivoLeido::duplicadasDescartadas).toList();

        assertThat(duplicadas).containsExactly(0, 9, 0);
    }

    @Test
    @DisplayName("Los ids de movimiento son 1 a 686 sin repetir, y el ultimo queda registrado para la secuencia")
    void losIdsDeMovimientoSonCorrelativos() {
        List<Long> ids = carga.cuentas().stream().flatMap(c -> c.movimientos().stream())
                .map(m -> m.id()).sorted().toList();

        assertThat(ids).hasSize(686).doesNotHaveDuplicates();
        assertThat(ids.get(0)).isEqualTo(1L);
        assertThat(ids.get(685)).isEqualTo(686L);
        assertThat(carga.ultimoIdMovimiento()).isEqualTo(686L);
    }

    @Test
    @DisplayName("Dos cargas del mismo dataset producen exactamente el mismo estado (la migracion es reproducible)")
    void laCargaEsDeterminista() {
        IngestaDataset.ResultadoIngesta otra = new IngestaDataset(new ReglaConsolidacion(), new ParserFechas(),
                new IngestaDataset.Origen("data/semana_3/intereses.csv",
                        "data/semana_3/cuentas_anuales.csv",
                        "data/semana_3/transacciones.csv")).cargar();

        for (int i = 0; i < carga.cuentas().size(); i++) {
            Cuenta a = carga.cuentas().get(i);
            Cuenta b = otra.cuentas().get(i);
            assertThat(b.id()).isEqualTo(a.id());
            assertThat(b.saldo()).isEqualByComparingTo(a.saldo());
            assertThat(b.movimientos()).isEqualTo(a.movimientos());
        }
        assertThat(otra.loteNoConciliado()).isEqualTo(carga.loteNoConciliado());
    }

    @Test
    @DisplayName("Las cuentas de control tienen los valores medidos a mano sobre el dataset")
    void lasCuentasDeControl() {
        Cuenta c116 = carga.cuentas().stream().filter(c -> c.id() == 116).findFirst().orElseThrow();
        Cuenta c130 = carga.cuentas().stream().filter(c -> c.id() == 130).findFirst().orElseThrow();

        assertThat(c116.saldo()).isEqualByComparingTo(new BigDecimal("12000"));
        assertThat(c116.movimientos()).hasSize(42);
        assertThat(c130.movimientos()).isEmpty();
    }
}
