package cl.duoc.bancoxyz.core.ingesta;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Pruebas del interprete de fechas.
 *
 * <p>Vigilan dos cosas distintas. La primera es que los cuatro formatos que conviven en el archivo
 * se reconozcan todos. La segunda, y mas sutil, es que el criterio de ambiguedad este realmente
 * aplicado: {@code 08-03-2024} tiene que ser el 8 de marzo y no el 3 de agosto. Como las dos
 * lecturas producen fechas validas, ningun error delataria una eleccion equivocada.
 */
class ParserFechasTest {

    private final ParserFechas parser = new ParserFechas();

    @ParameterizedTest(name = "{0} se interpreta como {1}")
    @CsvSource({
            "2024-03-08, 2024-03-08",
            "2024/03/08, 2024-03-08",
            "08-03-2024, 2024-03-08",
            "08/03/2024, 2024-03-08"})
    @DisplayName("Los cuatro formatos del archivo apuntan al mismo dia")
    void losCuatroFormatosSeResuelven(String entrada, String esperado) {
        assertThat(parser.parsear(entrada)).contains(LocalDate.parse(esperado));
    }

    @Test
    @DisplayName("Con el ano al final, el primer numero es el DIA (criterio chileno, no estadounidense)")
    void laAmbiguedadSeResuelveComoDiaPrimero() {
        // 08-03-2024 admite dos lecturas validas y la eleccion es una decision declarada, no un
        // descubrimiento. Si el criterio fuera "mes primero", esta fecha seria el 3 de agosto.
        assertThat(parser.parsear("08-03-2024")).contains(LocalDate.of(2024, 3, 8));

        // Esta otra fecha del dataset solo admite una lectura: 24 no puede ser un mes. Es la
        // comprobacion empirica de que el criterio elegido es el que el archivo usa de verdad.
        assertThat(parser.parsear("24-07-2024")).contains(LocalDate.of(2024, 7, 24));
    }

    @Test
    @DisplayName("Una fecha de dos digitos NO se interpreta como un ano del siglo I")
    void elAnoDeDosDigitosNoSeTragaLaFecha() {
        // Esta es la trampa que justifica seleccionar el formato con una expresion regular antes de
        // parsear. Encadenando formateadores en try/catch, el patron yyyy acepta anchos variables y
        // puede leer "24" como ano sin lanzar ninguna excepcion, produciendo fechas del ano 24 que
        // solo se descubren mirando el historial.
        LocalDate resultado = parser.parsear("24-07-2024").orElseThrow();

        assertThat(resultado.getYear()).isEqualTo(2024);
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "no-es-fecha", "2024-13-01", "31-02-2024", "8-3-2024", "2024-3-8"})
    @DisplayName("Lo ilegible devuelve ausencia y nunca una fecha inventada")
    void loIlegibleNoSeAdivina(String entrada) {
        // Sustituir una fecha ilegible por la de hoy o por una por defecto seria inventar un dato
        // financiero. La ausencia se cuenta en el reporte de calidad y se puede auditar.
        assertThat(parser.parsear(entrada)).isEmpty();
    }

    @Test
    @DisplayName("Un nulo no rompe la ingesta")
    void elNuloSeTolera() {
        assertThat(parser.parsear(null)).isEmpty();
    }
}
