package cl.duoc.bancoxyz.core.ingesta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import cl.duoc.bancoxyz.core.dominio.TipoCuenta;
import cl.duoc.bancoxyz.core.dominio.TipoMovimiento;

/**
 * Pruebas del normalizador de texto, la pieza que hace que dos formas de escribir lo mismo se
 * conviertan en la misma cadena.
 */
class NormalizadorTextoTest {

    @Test
    @DisplayName("Deposito con y sin tilde son el mismo tipo de movimiento")
    void lasTildesNoCreanUnTipoNuevo() {
        // Son 52 filas reales del dataset. Sin esta normalizacion se perderian en silencio: no
        // fallaria nada, simplemente habria 52 movimientos menos de los que deberia haber.
        assertThat(TipoMovimiento.parse("depósito")).contains(TipoMovimiento.DEPOSITO);
        assertThat(TipoMovimiento.parse("deposito")).contains(TipoMovimiento.DEPOSITO);
        assertThat(TipoMovimiento.parse("  DEPOSITO  ")).contains(TipoMovimiento.DEPOSITO);
    }

    @ParameterizedTest
    @ValueSource(strings = {"-1", "unknown", "invalid", "desconocido", "", "   "})
    @DisplayName("Todos los centinelas del dataset se unifican en DESCONOCIDO, no en null")
    void losCentinelasSonAusenciaExplicita(String centinela) {
        String normalizado = NormalizadorTexto.normalizar(centinela);

        assertThat(NormalizadorTexto.esDesconocido(normalizado))
                .as("una constante con nombre se puede comparar y probar; un null explota lejos de su origen")
                .isTrue();
        assertThat(TipoCuenta.parse(centinela)).isEmpty();
    }

    @Test
    @DisplayName("Lo que se muestra conserva mayusculas y tildes")
    void loQueSeMuestraNoSeNormaliza() {
        // Normalizar sirve para decidir si dos valores son el mismo, no para decidir como se
        // escribe el nombre que va a ver el cliente en pantalla.
        assertThat(NormalizadorTexto.limpiarParaMostrar("  Diana Prince  ")).isEqualTo("Diana Prince");
        assertThat(NormalizadorTexto.limpiarParaMostrar("   "))
                .as("una cadena vacia ocupa bytes para no decir nada; el contrato admite nulo")
                .isNull();
    }
}
