package cl.duoc.bancoxyz.core.adaptador;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.dominio.Pagina;
import cl.duoc.bancoxyz.core.dominio.ReporteCalidad;
import cl.duoc.bancoxyz.core.dominio.TransaccionNoConciliada;
import cl.duoc.bancoxyz.core.ingesta.IngestaDataset;
import cl.duoc.bancoxyz.core.ingesta.ParserFechas;
import cl.duoc.bancoxyz.core.ingesta.ReglaConsolidacion;
import cl.duoc.bancoxyz.core.soporte.Concurrencia;
import cl.duoc.bancoxyz.core.soporte.Concurrencia.Resultado;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * Los adaptadores de solo lectura (lote sin conciliar y reporte de calidad) y los generadores de
 * identificadores, contra la base migrada.
 *
 * <p>Lo que se comprueba es que lo que la base devuelve es <strong>idéntico</strong> a lo que produce
 * la ingesta del S5 en memoria: la migracion V2 no perdio ni deformo nada al pasar por PostgreSQL.
 */
class LecturasJdbcTest {

    private static HikariDataSource pool;
    private static LoteNoConciliadoRepositoryJdbc lote;
    private static ReporteCalidadRepositoryJdbc reporte;
    private static GeneradorIdentificadoresJdbc generador;
    private static IngestaDataset.ResultadoIngesta esperado;

    @BeforeAll
    static void prepararBase() {
        PostgresDePrueba.Base base = PostgresDePrueba.crearBaseMigrada();
        pool = base.nuevoPool(10);
        JdbcClient jdbc = JdbcClient.create(pool);
        lote = new LoteNoConciliadoRepositoryJdbc(jdbc);
        reporte = new ReporteCalidadRepositoryJdbc(jdbc, new DataSourceTransactionManager(pool));
        generador = new GeneradorIdentificadoresJdbc(jdbc);
        esperado = new IngestaDataset(new ReglaConsolidacion(), new ParserFechas(),
                new IngestaDataset.Origen("data/semana_3/intereses.csv", "data/semana_3/cuentas_anuales.csv",
                        "data/semana_3/transacciones.csv")).cargar();
    }

    @AfterAll
    static void cerrar() {
        pool.close();
    }

    @Test
    @DisplayName("El lote sin conciliar tiene 1000 transacciones, en el orden del archivo y sin deformar")
    void loteCompletoEnOrden() {
        assertThat(lote.total()).isEqualTo(1000);

        List<TransaccionNoConciliada> leidas = new ArrayList<>();
        for (int pagina = 0; pagina < 10; pagina++) {
            leidas.addAll(lote.paginar(pagina, 100).contenido());
        }

        assertThat(leidas).isEqualTo(esperado.loteNoConciliado());
    }

    @Test
    @DisplayName("Paginacion del lote: pagina intermedia, ultima incompleta y pagina mas alla del final (vacia, sin error)")
    void paginacionDelLote() {
        Pagina<TransaccionNoConciliada> primera = lote.paginar(0, 20);
        assertThat(primera.contenido()).hasSize(20);
        assertThat(primera.totalElementos()).isEqualTo(1000);
        assertThat(primera.totalPaginas()).isEqualTo(50);

        Pagina<TransaccionNoConciliada> incompleta = lote.paginar(83, 12);
        assertThat(incompleta.contenido()).hasSize(1000 - 83 * 12);

        Pagina<TransaccionNoConciliada> fuera = lote.paginar(100, 12);
        assertThat(fuera.contenido()).isEmpty();
        assertThat(fuera.totalElementos()).isEqualTo(1000);

        assertThat(lote.paginar(Integer.MAX_VALUE, 100).contenido())
                .as("una pagina absurda no desborda el OFFSET").isEmpty();
    }

    @Test
    @DisplayName("El reporte de calidad guardado es el mismo que produce la ingesta: 50, 686, 1000 y los descartes")
    void elReporteSobreviveALaBase() {
        ReporteCalidad guardado = reporte.obtener();
        ReporteCalidad enMemoria = esperado.reporte();

        assertThat(guardado.cuentasConsolidadas()).isEqualTo(50);
        assertThat(guardado.movimientosCargados()).isEqualTo(686);
        assertThat(guardado.transaccionesNoConciliadas()).isEqualTo(1000);
        assertThat(guardado.archivos()).isEqualTo(enMemoria.archivos());
        assertThat(guardado.descartesPorMotivo()).isEqualTo(enMemoria.descartesPorMotivo());
        assertThat(guardado.descartesPorMotivo()).hasSize(5);
        assertThat(guardado.generadoEn()).isNotBlank();
    }

    @Test
    @DisplayName("El primer id de movimiento que reparte la base es el 687: continua tras los 686 de la carga")
    void laSecuenciaDeMovimientosContinuaTrasLaCarga() {
        assertThat(generador.siguienteIdMovimiento()).isEqualTo(687L);
        assertThat(generador.siguienteIdMovimiento()).isEqualTo(688L);
    }

    @Test
    @DisplayName("Cuarenta peticiones simultaneas de folio reciben cuarenta correlativos distintos")
    void losFoliosNuncaSeRepiten() {
        List<Callable<Long>> tareas = new ArrayList<>();
        for (int i = 0; i < 40; i++) {
            tareas.add(generador::siguienteCorrelativoFolio);
        }

        List<Resultado<Long>> resultados = Concurrencia.enParalelo(tareas);

        assertThat(resultados).allMatch(Resultado::fueExito);
        assertThat(resultados.stream().map(Resultado::valor).distinct()).hasSize(40);
    }
}
