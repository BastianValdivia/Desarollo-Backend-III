package cl.duoc.bancoxyz.core.adaptador;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.soporte.Concurrencia;
import cl.duoc.bancoxyz.core.soporte.Concurrencia.Resultado;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * El comportamiento de las migraciones de Flyway: la carga inicial ocurre <strong>una sola vez</strong>,
 * aunque arranquen varias replicas a la vez o se reinicie el servicio, y no pisa los retiros hechos.
 *
 * <p>Estas pruebas son la evidencia, sobre un PostgreSQL real, de dos afirmaciones de F3: "el bloqueo
 * de Flyway impide que dos replicas carguen a la vez" y "reiniciar el core conserva los retiros". La
 * demostracion con contenedores esta en la bitacora; esta es la version automatica.
 */
class MigracionesFlywayTest {

    @Test
    @DisplayName("Dos replicas que migran a la vez sobre una base vacia cargan el dataset UNA sola vez")
    void dosReplicasMigrandoALaVez() {
        PostgresDePrueba.Base base = PostgresDePrueba.crearBase();

        List<Callable<Boolean>> arranques = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            arranques.add(() -> {
                base.migrar();
                return true;
            });
        }
        List<Resultado<Boolean>> resultados = Concurrencia.enParalelo(arranques);

        assertThat(resultados).as("ningun arranque falla (por ejemplo por clave duplicada)")
                .allMatch(Resultado::fueExito);
        try (HikariDataSource pool = base.nuevoPool(2)) {
            JdbcClient jdbc = JdbcClient.create(pool);
            assertThat(jdbc.sql("SELECT count(*) FROM cuenta").query(Integer.class).single()).isEqualTo(50);
            assertThat(jdbc.sql("SELECT count(*) FROM movimiento").query(Integer.class).single()).isEqualTo(686);
            assertThat(jdbc.sql("SELECT count(*) FROM transaccion_no_conciliada").query(Integer.class).single())
                    .isEqualTo(1000);
            assertThat(jdbc.sql("SELECT count(*) FROM reporte_calidad").query(Integer.class).single()).isEqualTo(1);
            assertThat(jdbc.sql("SELECT version FROM flyway_schema_history WHERE success ORDER BY installed_rank")
                    .query(String.class).list())
                    .as("cada version se aplico exactamente una vez").containsExactly("1", "2", "3", "4");
        }
    }

    @Test
    @DisplayName("Reiniciar (volver a migrar) conserva los retiros: la carga no se repite ni vuelve al estado inicial")
    void reiniciarConservaLosRetiros() {
        PostgresDePrueba.Base base = PostgresDePrueba.crearBaseMigrada();

        try (HikariDataSource antes = base.nuevoPool(2)) {
            CuentaRepositoryJdbc cuentas = new CuentaRepositoryJdbc(
                    JdbcClient.create(antes), new DataSourceTransactionManager(antes));
            cuentas.debitar(116, new BigDecimal("4000"), "RET-ANTES-DEL-REINICIO", LocalDate.now(), 900_001L);
        }

        // "Reinicio": el proceso muere (el pool se cerro arriba) y otro arranca: vuelve a ejecutar Flyway.
        base.migrar();

        try (HikariDataSource despues = base.nuevoPool(2)) {
            CuentaRepositoryJdbc cuentas = new CuentaRepositoryJdbc(
                    JdbcClient.create(despues), new DataSourceTransactionManager(despues));
            assertThat(cuentas.buscarPorId(116).orElseThrow().saldo())
                    .as("el retiro sigue descontado: 12000 - 4000").isEqualByComparingTo("8000");
            assertThat(cuentas.buscarPorId(116).orElseThrow().movimientos()).hasSize(43);
            assertThat(JdbcClient.create(despues).sql("SELECT count(*) FROM cuenta").query(Integer.class).single())
                    .as("no se duplicaron las cuentas").isEqualTo(50);
        }
    }

    @Test
    @DisplayName("El esquema trae la tabla outbox en su forma definitiva de F7 (V4: payload de texto, event_id unico, topico)")
    void laTablaOutboxExiste() {
        PostgresDePrueba.Base base = PostgresDePrueba.crearBaseMigrada();
        try (HikariDataSource pool = base.nuevoPool(2)) {
            JdbcClient jdbc = JdbcClient.create(pool);

            List<String> columnas = jdbc.sql("""
                    SELECT column_name FROM information_schema.columns
                     WHERE table_name = 'outbox' ORDER BY ordinal_position""").query(String.class).list();
            assertThat(columnas).containsExactly(
                    "id", "tipo", "clave", "creado", "publicado", "payload", "event_id", "topico");

            // El sobre se guarda como texto: se publica exactamente lo escrito (jsonb reordenaria las claves).
            assertThat(jdbc.sql("SELECT data_type FROM information_schema.columns "
                    + "WHERE table_name = 'outbox' AND column_name = 'payload'")
                    .query(String.class).single()).isEqualTo("text");

            String evento = "6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11";
            jdbc.sql("""
                    INSERT INTO outbox (event_id, tipo, topico, clave, payload)
                    VALUES (:id::uuid, 'RETIRO_EJECUTADO', 'bancoxyz.retiros.v1', '116', '{"monto":1000}')""")
                    .param("id", evento).update();
            assertThat(jdbc.sql("SELECT count(*) FROM outbox WHERE publicado IS NULL").query(Integer.class).single())
                    .as("un evento nuevo queda pendiente de publicar").isEqualTo(1);

            // El mismo evento no puede quedar dos veces en la bandeja.
            org.assertj.core.api.Assertions.assertThatThrownBy(() -> jdbc.sql("""
                    INSERT INTO outbox (event_id, tipo, topico, clave, payload)
                    VALUES (:id::uuid, 'RETIRO_EJECUTADO', 'bancoxyz.retiros.v1', '116', '{}')""")
                    .param("id", evento).update())
                    .isInstanceOf(org.springframework.dao.DuplicateKeyException.class);
        }
    }
}
