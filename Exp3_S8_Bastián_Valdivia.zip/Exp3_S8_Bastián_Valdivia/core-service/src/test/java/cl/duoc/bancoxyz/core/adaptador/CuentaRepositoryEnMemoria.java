package cl.duoc.bancoxyz.core.adaptador;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.error.CuentaNoEncontradaException;
import cl.duoc.bancoxyz.core.puerto.CuentaRepository;

/**
 * <strong>Adaptador</strong> que implementa {@link CuentaRepository} guardando las cuentas en un
 * {@link ConcurrentHashMap} dentro del proceso.
 *
 * <p><strong>Desde F3 vive en {@code src/test}.</strong> Ya no es el adaptador de produccion (lo
 * reemplaza {@code CuentaRepositoryJdbc}, sobre PostgreSQL): se conserva como implementacion de
 * referencia del puerto para las pruebas unitarias que no necesitan una base, y porque
 * {@code RetiroConcurrenteTest} documenta con ella la semantica que el adaptador JDBC debe igualar.
 * El comentario de abajo sobre "se pierde todo al apagar el proceso" describe esta version, no el
 * sistema.
 *
 * <p>Rol en la arquitectura: es la unica clase del core que sabe <em>donde</em> vive el estado del
 * banco. Todo lo demas habla con el puerto. Si manana se migra a una base de datos, esta clase se
 * reemplaza por otra y ni los servicios ni los controladores ni los tres BFF se enteran.
 *
 * <p><strong>Por que un mapa en memoria y no H2 con JPA.</strong> Es un intercambio explicito. H2
 * se ve mas profesional y trae transacciones declarativas, pero agrega entidades, repositorios,
 * dialecto, origen de datos y ciclo de vida de sesion, que es donde mas se atasca quien esta
 * aprendiendo, y ninguna de esas piezas ensena nada sobre el patron BFF, que es el objeto del
 * ejercicio. El mapa, en cambio, da atomicidad real (la que se ve en {@link #debitar}), arranca
 * siempre y reinicia el estado limpio en cada ejecucion, lo cual hace que la evidencia sea
 * reproducible. La limitacion, que hay que declarar en vez de esconder: al apagar el proceso se
 * pierde todo, y una segunda instancia del core tendria su propio estado.
 *
 * <p><strong>Por que {@code ConcurrentHashMap} y no {@code HashMap}.</strong> Un servidor web
 * atiende cada peticion en un hilo distinto. Con un {@code HashMap} normal, dos peticiones
 * simultaneas pueden corromper la estructura interna del mapa y producir fallos que no se
 * reproducen. Pero la razon principal no es esa: es que este mapa ofrece
 * {@link ConcurrentHashMap#compute}, que es el mecanismo con el que se construye el retiro
 * atomico.
 */
public class CuentaRepositoryEnMemoria implements CuentaRepository {

    private final Map<Integer, Cuenta> cuentas = new ConcurrentHashMap<>();

    @Override
    public Optional<Cuenta> buscarPorId(int cuentaId) {
        return Optional.ofNullable(cuentas.get(cuentaId));
    }

    @Override
    public Collection<Cuenta> listarTodas() {
        // La vista se envuelve como no modificable para que ningun llamador pueda borrar cuentas
        // del banco por accidente a traves de una coleccion que creia de solo lectura.
        return Collections.unmodifiableCollection(cuentas.values());
    }

    @Override
    public void guardar(Cuenta cuenta) {
        cuentas.put(cuenta.id(), cuenta);
    }

    /**
     * {@inheritDoc}
     *
     * <p><strong>ESTE METODO ES EL CORAZON DEL EJERCICIO. Vale la pena leerlo despacio.</strong>
     *
     * <p>La version equivocada, que parece razonable y funciona en todas las pruebas manuales:
     *
     * <pre>
     * Cuenta c = cuentas.get(id);                  // 1. leer
     * if (c.saldo().compareTo(monto) &lt; 0) { ... }  // 2. validar
     * cuentas.put(id, c.conRetiro(monto, ...));    // 3. escribir
     * </pre>
     *
     * <p>Con dos cajeros retirando 8.000 de una cuenta que tiene 12.000, los dos hilos pueden
     * ejecutar el paso 1 antes de que ninguno llegue al 3. Los dos leen 12.000, los dos concluyen
     * que alcanza, y los dos escriben 4.000. El banco entrego 16.000 de una cuenta que tenia
     * 12.000 y el saldo final ni siquiera queda negativo: queda <em>mal</em>, sin ningun error,
     * sin ninguna excepcion y sin ninguna linea de log. Es el fallo silencioso mas caro que puede
     * tener un sistema bancario.
     *
     * <p>La version correcta es la de abajo. {@code compute} recibe una funcion y la ejecuta
     * <strong>manteniendo bloqueado el compartimento del mapa correspondiente a esa clave</strong>.
     * Leer, validar y escribir dejan de ser tres pasos y pasan a ser uno solo: mientras la funcion
     * corre para la cuenta 116, ningun otro hilo puede entrar a la 116. El segundo retiro no se
     * pierde ni falla por un error tecnico: <em>espera</em>, y cuando entra ve el saldo que dejo el
     * primero, que es exactamente lo que debe pasar.
     *
     * <p>Tres detalles del codigo que no son evidentes:
     *
     * <ul>
     *   <li><strong>El bloqueo es por clave, no por mapa.</strong> Un retiro sobre la cuenta 105 no
     *       espera a uno sobre la 116. Se paga exclusion solo donde hace falta.</li>
     *   <li><strong>Si la funcion lanza una excepcion, el mapa no se toca.</strong> Es lo que da
     *       el "o ninguno" de la atomicidad: cuando el saldo no alcanza,
     *       {@code Cuenta.conRetiro} lanza desde dentro de la funcion, {@code compute} propaga la
     *       excepcion y la entrada queda con el valor anterior. No hay que deshacer nada a mano.</li>
     *   <li><strong>El comprobante se saca con un {@link AtomicReference}.</strong> {@code compute}
     *       devuelve la cuenta nueva, no el comprobante, y una variable local normal no se puede
     *       asignar desde dentro de una lambda. El {@code AtomicReference} es el recipiente donde
     *       la funcion deja el resultado para que lo recoja quien llamo. No se usa por
     *       concurrencia: solo un hilo escribe en el, por construccion.</li>
     * </ul>
     *
     * <p>Una regla que hay que respetar con {@code compute} y que aqui se cumple: dentro de la
     * funcion <strong>no se puede tocar este mismo mapa</strong> (ni siquiera leerlo), porque el
     * bloqueo ya esta tomado y la llamada se quedaria esperandose a si misma. Todo lo que la
     * funcion necesita llega por parametro.
     */
    @Override
    public ResultadoRetiro debitar(int cuentaId, BigDecimal monto, String folio, LocalDate fecha,
                                   long idMovimiento) {

        AtomicReference<ResultadoRetiro> comprobante = new AtomicReference<>();

        cuentas.compute(cuentaId, (id, actual) -> {
            if (actual == null) {
                // Lanzar desde dentro de compute deja la entrada tal como estaba (aqui, ausente).
                throw new CuentaNoEncontradaException(id);
            }

            // conRetiro valida el saldo y construye la cuenta nueva en una sola expresion; si no
            // alcanza, lanza SaldoInsuficienteException y esta entrada del mapa no se modifica.
            Cuenta actualizada = actual.conRetiro(monto, idMovimiento, fecha);

            comprobante.set(new ResultadoRetiro(
                    folio,
                    actual.saldo(),
                    monto,
                    actualizada.saldo()));

            return actualizada;
        });

        return comprobante.get();
    }
}
