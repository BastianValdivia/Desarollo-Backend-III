package cl.duoc.bancoxyz.core.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.time.Duration;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.cloud.context.scope.refresh.RefreshScope;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.support.TestPropertySourceUtils;

import jakarta.servlet.ServletException;

/**
 * La latencia inyectable del core: vale 0 por defecto, afecta solo a {@code /internal/**} y se cambia en
 * caliente con un refresh (sin reiniciar). No necesita PostgreSQL: arma solo estas dos piezas.
 */
@DisplayName("Latencia inyectable del core")
class LatenciaInyectadaTest {

    @org.springframework.context.annotation.Configuration(proxyBeanMethods = false)
    @org.springframework.context.annotation.Import({LatenciaInyectada.class, LatenciaInyectadaFilter.class})
    static class ConfiguracionDeLatencia {
    }

    private long milisegundosQueTarda(LatenciaInyectadaFilter filtro, String ruta) throws ServletException, IOException {
        MockHttpServletRequest peticion = new MockHttpServletRequest("GET", ruta);
        peticion.setRequestURI(ruta);
        long inicio = System.nanoTime();
        filtro.doFilter(peticion, new MockHttpServletResponse(), new MockFilterChain());
        return (System.nanoTime() - inicio) / 1_000_000;
    }

    @Test
    @DisplayName("Por defecto (caos.latencia-ms = 0) no agrega ninguna espera")
    void porDefectoNoEspera() {
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(RefreshAutoConfiguration.class))
                .withUserConfiguration(ConfiguracionDeLatencia.class)
                .run(ctx -> {
                    assertThat(ctx.getBean(LatenciaInyectada.class).latencia()).isEqualTo(Duration.ZERO);
                    assertThat(milisegundosQueTarda(ctx.getBean(LatenciaInyectadaFilter.class),
                            "/internal/v1/cuentas/116")).isLessThan(100);
                });
    }

    @Test
    @DisplayName("Con 300 ms espera en /internal/** y NO en otras rutas")
    void soloAfectaAInternal() {
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(RefreshAutoConfiguration.class))
                .withUserConfiguration(ConfiguracionDeLatencia.class)
                .withPropertyValues("caos.latencia-ms=300")
                .run(ctx -> {
                    LatenciaInyectadaFilter filtro = ctx.getBean(LatenciaInyectadaFilter.class);
                    assertThat(milisegundosQueTarda(filtro, "/internal/v1/cuentas/116/saldo")).isGreaterThanOrEqualTo(290);
                    assertThat(milisegundosQueTarda(filtro, "/actuator/health")).isLessThan(100);
                });
    }

    @Test
    @DisplayName("Un refresh cambia la latencia sin reiniciar: 0 -> 400 ms -> 0")
    void elRefreshLaCambiaEnCaliente() {
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(RefreshAutoConfiguration.class))
                .withUserConfiguration(ConfiguracionDeLatencia.class)
                .run(ctx -> {
                    LatenciaInyectadaFilter filtro = ctx.getBean(LatenciaInyectadaFilter.class);
                    assertThat(milisegundosQueTarda(filtro, "/internal/v1/x")).isLessThan(100);

                    // Es lo que hace POST /actuator/refresh tras releer el config-server: cambia la
                    // propiedad y destruye los beans @RefreshScope.
                    TestPropertySourceUtils.addInlinedPropertiesToEnvironment(ctx, "caos.latencia-ms=400");
                    ctx.getBean(RefreshScope.class).refreshAll();
                    assertThat(milisegundosQueTarda(filtro, "/internal/v1/x")).isGreaterThanOrEqualTo(390);

                    TestPropertySourceUtils.addInlinedPropertiesToEnvironment(ctx, "caos.latencia-ms=0");
                    ctx.getBean(RefreshScope.class).refreshAll();
                    assertThat(milisegundosQueTarda(filtro, "/internal/v1/x")).isLessThan(100);
                });
    }

    @Test
    @DisplayName("Un valor absurdo o negativo se acota: nunca deja al core colgado")
    void seAcotaElValor() {
        assertThat(new LatenciaInyectada(10_000_000).latencia().toMillis()).isEqualTo(LatenciaInyectada.MAXIMO_MS);
        assertThat(new LatenciaInyectada(-5).latencia()).isEqualTo(Duration.ZERO);
    }
}
