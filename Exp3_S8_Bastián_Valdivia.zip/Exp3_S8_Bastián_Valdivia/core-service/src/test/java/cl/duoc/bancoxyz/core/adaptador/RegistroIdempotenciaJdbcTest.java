package cl.duoc.bancoxyz.core.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaReutilizadaException;
import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;
import cl.duoc.bancoxyz.core.soporte.Concurrencia;
import cl.duoc.bancoxyz.core.soporte.Concurrencia.Resultado;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * El registro de idempotencia sobre la clave primaria de una tabla, con el descuento real dentro de la
 * misma transaccion.
 *
 * <p>Responde la pregunta que hace una restriccion unica: cuando el cajero reintenta con la misma
 * {@code Idempotency-Key}, y el reintento puede caer en la OTRA replica del core (que no comparte
 * memoria con la primera), se descuenta una sola vez y se devuelve el mismo folio? Cada "replica" de
 * estas pruebas es un pool de conexiones propio sobre la misma base.
 */
class RegistroIdempotenciaJdbcTest {

    private static PostgresDePrueba.Base base;
    private static HikariDataSource poolA;
    private static HikariDataSource poolB;
    private static CuentaRepositoryJdbc cuentasA;
    private static CuentaRepositoryJdbc cuentasB;
    private static RegistroIdempotenciaJdbc registroA;
    private static RegistroIdempotenciaJdbc registroB;
    private static JdbcClient jdbc;

    @BeforeAll
    static void prepararBase() {
        base = PostgresDePrueba.crearBaseMigrada();
        poolA = base.nuevoPool(10);
        poolB = base.nuevoPool(10);
        jdbc = JdbcClient.create(poolA);
        DataSourceTransactionManager gestorA = new DataSourceTransactionManager(poolA);
        DataSourceTransactionManager gestorB = new DataSourceTransactionManager(poolB);
        cuentasA = new CuentaRepositoryJdbc(jdbc, gestorA);
        cuentasB = new CuentaRepositoryJdbc(JdbcClient.create(poolB), gestorB);
        registroA = new RegistroIdempotenciaJdbc(jdbc, gestorA);
        registroB = new RegistroIdempotenciaJdbc(JdbcClient.create(poolB), gestorB);
    }

    @AfterAll
    static void cerrar() {
        poolA.close();
        poolB.close();
    }

    private static ResultadoRetiro retirar(RegistroIdempotenciaJdbc registro, CuentaRepositoryJdbc cuentas,
                                           int cuenta, String clave, String folio, long idMovimiento) {
        return registro.ejecutarUnaSolaVez(cuenta, clave, new BigDecimal("1000"), () ->
                cuentas.debitar(cuenta, new BigDecimal("1000"), folio, LocalDate.now(), idMovimiento));
    }

    @Test
    @DisplayName("La misma clave en la OTRA replica devuelve el mismo folio y el saldo baja una sola vez")
    void reintentoEnOtraReplica() {
        ResultadoRetiro primero = retirar(registroA, cuentasA, 116, "clave-reintento", "RET-A-1", 400_001L);
        ResultadoRetiro reintento = retirar(registroB, cuentasB, 116, "clave-reintento", "RET-B-2", 400_002L);

        assertThat(reintento.folio()).as("el mismo folio de la primera vez").isEqualTo("RET-A-1");
        assertThat(reintento).isEqualTo(primero);
        assertThat(cuentasA.buscarPorId(116).orElseThrow().saldo()).as("12000 - 1000, una sola vez")
                .isEqualByComparingTo("11000");
        assertThat(cuentasA.buscarPorId(116).orElseThrow().movimientos())
                .as("un solo apunte nuevo (42 + 1)").hasSize(43);
    }

    @Test
    @DisplayName("Diez reintentos simultaneos con la misma clave repartidos entre dos replicas: un solo descuento")
    void reintentosSimultaneos() {
        AtomicInteger ejecuciones = new AtomicInteger();
        List<Callable<ResultadoRetiro>> tareas = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RegistroIdempotenciaJdbc registro = (i % 2 == 0) ? registroA : registroB;
            CuentaRepositoryJdbc cuentas = (i % 2 == 0) ? cuentasA : cuentasB;
            int numero = i;
            tareas.add(() -> registro.ejecutarUnaSolaVez(106, "clave-simultanea", new BigDecimal("1000"), () -> {
                ejecuciones.incrementAndGet();
                return cuentas.debitar(106, new BigDecimal("1000"), "RET-SIM-" + numero, LocalDate.now(),
                        500_000L + numero);
            }));
        }

        List<Resultado<ResultadoRetiro>> resultados = Concurrencia.enParalelo(tareas);

        assertThat(resultados).allMatch(Resultado::fueExito);
        assertThat(ejecuciones.get()).as("la operacion se ejecuto exactamente una vez").isEqualTo(1);
        assertThat(resultados.stream().map(r -> r.valor().folio()).distinct())
                .as("los diez reciben el mismo folio").hasSize(1);
        assertThat(cuentasA.buscarPorId(106).orElseThrow().saldo()).isEqualByComparingTo("4000");
    }

    @Test
    @DisplayName("Un retiro rechazado por saldo no se recuerda: la clave queda libre para reintentar")
    void elFracasoNoSeRecuerda() {
        assertThatThrownBy(() -> registroA.ejecutarUnaSolaVez(130, "clave-fallida", new BigDecimal("999999"), () ->
                cuentasA.debitar(130, new BigDecimal("999999"), "RET-X", LocalDate.now(), 600_001L)))
                .isInstanceOf(SaldoInsuficienteException.class);

        assertThat(jdbc.sql("SELECT count(*) FROM idempotencia WHERE clave = 'clave-fallida'")
                .query(Integer.class).single()).as("la reserva se deshizo con la transaccion").isZero();

        // La misma clave, ahora con un monto que si cabe: se ejecuta de verdad.
        ResultadoRetiro comprobante = retirar(registroA, cuentasA, 130, "clave-fallida", "RET-OK", 600_002L);
        assertThat(comprobante.folio()).isEqualTo("RET-OK");
    }

    @Test
    @DisplayName("Claves distintas son retiros distintos: cada una descuenta")
    void clavesDistintas() {
        retirar(registroA, cuentasA, 117, "clave-distinta-1", "RET-D-1", 700_001L);
        retirar(registroB, cuentasB, 117, "clave-distinta-2", "RET-D-2", 700_002L);

        BigDecimal saldoInicial = jdbc.sql("""
                SELECT c.saldo + COALESCE(SUM(m.monto), 0) FROM cuenta c
                  LEFT JOIN movimiento m ON m.cuenta_id = c.id AND m.origen = 'RETIRO_ATM'
                 WHERE c.id = 117 GROUP BY c.saldo""").query(BigDecimal.class).single();
        assertThat(cuentasA.buscarPorId(117).orElseThrow().saldo())
                .isEqualByComparingTo(saldoInicial.subtract(new BigDecimal("2000")));
    }

    @Test
    @DisplayName("La misma clave en OTRA cuenta no recibe el comprobante ajeno: ejecuta su propio retiro")
    void laClaveVaPorCuenta() {
        ResultadoRetiro deLa118 = retirar(registroA, cuentasA, 118, "clave-compartida", "RET-118", 800_001L);
        ResultadoRetiro deLa119 = retirar(registroB, cuentasB, 119, "clave-compartida", "RET-119", 800_002L);

        assertThat(deLa119.folio()).as("su propio folio, no el de la 118").isEqualTo("RET-119");
        assertThat(cuentasA.buscarPorId(118).orElseThrow().saldo())
                .as("la 118 bajo una sola vez").isEqualByComparingTo(deLa118.saldoPosterior());
        assertThat(cuentasA.buscarPorId(119).orElseThrow().saldo())
                .as("la 119 SI se descuento, no se confirmo sin ejecutar").isEqualByComparingTo(deLa119.saldoPosterior());
        assertThat(jdbc.sql("SELECT count(*) FROM idempotencia WHERE clave = 'clave-compartida'")
                .query(Integer.class).single()).as("una fila por cuenta").isEqualTo(2);
    }

    @Test
    @DisplayName("La misma clave en la misma cuenta con OTRO importe se rechaza y no descuenta nada")
    void claveReutilizadaConOtroImporte() {
        retirar(registroA, cuentasA, 120, "clave-reutilizada", "RET-R1", 810_001L);
        BigDecimal saldoTrasElPrimero = cuentasA.buscarPorId(120).orElseThrow().saldo();

        assertThatThrownBy(() -> registroB.ejecutarUnaSolaVez(120, "clave-reutilizada", new BigDecimal("3000"), () ->
                cuentasB.debitar(120, new BigDecimal("3000"), "RET-R2", LocalDate.now(), 810_002L)))
                .isInstanceOf(ClaveIdempotenciaReutilizadaException.class);

        assertThat(cuentasA.buscarPorId(120).orElseThrow().saldo())
                .as("el rechazo no toco el saldo").isEqualByComparingTo(saldoTrasElPrimero);
        // Un reintento verdadero (mismo importe) sigue devolviendo el comprobante original.
        assertThat(retirar(registroB, cuentasB, 120, "clave-reutilizada", "RET-R3", 810_003L).folio())
                .isEqualTo("RET-R1");
    }

    @Test
    @DisplayName("La restriccion unica es la garantia: insertar el mismo par (cuenta, clave) dos veces a mano falla en la base")
    void laBaseRechazaLaClaveRepetida() {
        jdbc.sql("INSERT INTO idempotencia (cuenta_id, clave, folio) VALUES (116, 'clave-a-mano', 'F1')").update();

        assertThatThrownBy(() -> jdbc.sql(
                "INSERT INTO idempotencia (cuenta_id, clave, folio) VALUES (116, 'clave-a-mano', 'F2')").update())
                .isInstanceOf(DataIntegrityViolationException.class)
                .hasMessageContaining("idempotencia_pkey");

        // En otra cuenta la misma cadena es otra fila: la clave primaria es el par.
        jdbc.sql("INSERT INTO idempotencia (cuenta_id, clave, folio) VALUES (106, 'clave-a-mano', 'F3')").update();
    }
}
