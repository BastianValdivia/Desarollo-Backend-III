package cl.duoc.bancoxyz.core.seguridad;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.List;
import java.util.Properties;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
import org.springframework.boot.context.properties.source.MapConfigurationPropertySource;

/**
 * La audiencia del core no puede desaparecer en silencio: sin ella, Spring Boot no agrega el validador y el core
 * aceptaria tokens de cualquier servicio. Estas pruebas fijan el comportamiento de la guarda; que el rechazo de otra
 * audiencia funciona de punta a punta lo prueba SeguridadOAuth2CoreTest.
 */
@DisplayName("Core: guarda de arranque de la audiencia")
class GuardaAudienciaCoreTest {

    @Test
    @DisplayName("Con la audiencia core-service el arranque sigue")
    void conLaAudienciaDelCoreArranca() {
        assertThatCode(() -> new GuardaAudienciaCore(List.of("core-service"))).doesNotThrowAnyException();
        assertThatCode(() -> new GuardaAudienciaCore(List.of(" core-service "))).doesNotThrowAnyException();
        assertThatCode(() -> new GuardaAudienciaCore(List.of("otra", "core-service"))).doesNotThrowAnyException();
    }

    @Test
    @DisplayName("Sin audiencia, con una lista vacia o con la de otro servicio, el arranque falla y nombra la propiedad")
    void sinLaAudienciaDelCoreFalla() {
        assertThatThrownBy(() -> new GuardaAudienciaCore(List.of()))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("spring.security.oauth2.resourceserver.jwt.audiences")
                .hasMessageContaining("core-service");
        assertThatThrownBy(() -> new GuardaAudienciaCore(null)).isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> new GuardaAudienciaCore(List.of("auditoria-service")))
                .isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> new GuardaAudienciaCore(List.of("")))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    @DisplayName("Un config-repo/core-service.yml sin la propiedad se detecta con la misma lectura que usa Spring")
    void laConfiguracionRealDeclaraLaAudiencia() throws Exception {
        // Se lee el archivo REAL que entrega el config-server (ruta relativa a la carpeta del modulo, como en las
        // demas pruebas): si alguien borra la audiencia de ahi, esta prueba falla antes que el arranque.
        var fuentes = new org.springframework.boot.env.YamlPropertySourceLoader()
                .load("core-service", new org.springframework.core.io.FileSystemResource("../config-repo/core-service.yml"));
        Properties propiedades = new Properties();
        fuentes.forEach(f -> {
            @SuppressWarnings("unchecked")
            var origen = (org.springframework.core.env.EnumerablePropertySource<Object>) f;
            for (String nombre : origen.getPropertyNames()) {
                propiedades.put(nombre, origen.getProperty(nombre));
            }
        });
        ConfigurationPropertySource fuente = new MapConfigurationPropertySource(propiedades);
        List<String> audiencias = new Binder(fuente)
                .bind("spring.security.oauth2.resourceserver.jwt.audiences", Bindable.listOf(String.class))
                .orElse(List.of());

        assertThat(audiencias).contains("core-service");
        assertThatCode(() -> new GuardaAudienciaCore(audiencias)).doesNotThrowAnyException();
    }
}
