package cl.duoc.bancoxyz.core.adaptador;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaReutilizadaException;
import cl.duoc.bancoxyz.core.puerto.RegistroIdempotencia;

/**
 * <strong>Adaptador</strong> que implementa {@link RegistroIdempotencia} con un mapa de (cuenta, clave)
 * a comprobante.
 *
 * <p><strong>Desde F3 vive en {@code src/test}.</strong> Ya no es el adaptador de produccion (lo
 * reemplaza {@code RegistroIdempotenciaJdbc}, con la clave primaria de una tabla): se conserva como
 * implementacion de referencia para las pruebas unitarias del puerto.
 *
 * <p>Rol en la arquitectura: recuerda que retiros ya se hicieron, para que un reintento del cajero
 * por corte de red no cobre dos veces. Es el complemento del retiro atomico: aquel evita que dos
 * peticiones <em>distintas</em> se pisen; este evita que la <em>misma</em> peticion cuente dos
 * veces.
 *
 * <p><strong>Por que {@code computeIfAbsent} y no "consultar y despues guardar".</strong> Igual
 * que en el repositorio de cuentas, la version en dos pasos deja una ventana: dos reintentos
 * simultaneos con la misma clave consultan a la vez, los dos encuentran el mapa vacio, y los dos
 * ejecutan el retiro. {@code computeIfAbsent} ejecuta la funcion bajo el bloqueo de esa clave, de
 * modo que el segundo reintento espera y despues recibe el comprobante que dejo el primero, sin
 * ejecutar nada. Ejecutar el retiro <em>dentro</em> de la funcion no es un detalle: es lo que hace
 * que "una sola vez" sea cierto.
 *
 * <p><strong>Una regla que aqui se cumple y conviene conocer.</strong> Dentro de la funcion de
 * {@code computeIfAbsent} esta prohibido tocar <em>este mismo</em> mapa. La funcion que se recibe
 * si toca otro mapa (el de cuentas, a traves del repositorio), y eso es legitimo y seguro: son
 * estructuras distintas con bloqueos distintos, y el orden de adquisicion es siempre el mismo
 * (primero idempotencia, despues cuenta), de modo que no puede producirse un abrazo mortal.
 *
 * <p><strong>Si la operacion falla, no se guarda nada.</strong> Cuando el retiro lanza (saldo
 * insuficiente, por ejemplo), la excepcion sale de la funcion, {@code computeIfAbsent} no crea la
 * entrada y la clave queda libre. Es el comportamiento deseado: un retiro rechazado por saldo debe
 * poder reintentarse con la misma clave despues de un deposito. Recordar los fracasos convertiria
 * un rechazo transitorio en uno permanente.
 *
 * <p>Limitacion declarada: el registro vive en memoria y crece sin limite mientras el proceso
 * corra. En produccion llevaria una expiracion (las claves de idempotencia suelen vivir 24 horas)
 * y un almacen compartido entre instancias. Para la escala de esta demostracion, unas pocas
 * decenas de claves, no se justifica.
 */
public class RegistroIdempotenciaEnMemoria implements RegistroIdempotencia {

    /** La identidad de un reintento es el par (cuenta, clave), igual que en la tabla. */
    private record Llave(int cuentaId, String clave) {
    }

    private final Map<Llave, ResultadoRetiro> comprobantes = new ConcurrentHashMap<>();

    @Override
    public ResultadoRetiro ejecutarUnaSolaVez(int cuentaId, String clave, BigDecimal monto,
                                              Supplier<ResultadoRetiro> operacion) {
        ResultadoRetiro comprobante = comprobantes.computeIfAbsent(new Llave(cuentaId, clave), ignorada -> operacion.get());
        if (comprobante.montoRetirado().compareTo(monto) != 0) {
            throw new ClaveIdempotenciaReutilizadaException(cuentaId, monto);
        }
        return comprobante;
    }
}
