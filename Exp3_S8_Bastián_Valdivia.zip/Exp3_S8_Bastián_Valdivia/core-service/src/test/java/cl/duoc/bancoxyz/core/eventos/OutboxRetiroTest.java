package cl.duoc.bancoxyz.core.eventos;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.adaptador.OutboxJdbc;
import cl.duoc.bancoxyz.core.aplicacion.RetiroService;
import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;
import cl.duoc.bancoxyz.core.soporte.ServiciosDePrueba;
import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.DatosRetiro;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.TiposEvento;
import cl.duoc.bancoxyz.eventos.Topicos;

/**
 * La mitad "escritura" del patron outbox: el evento queda en la MISMA transaccion que el retiro. Sin Kafka
 * (esta prueba no lo necesita: el outbox es solo una tabla).
 */
class OutboxRetiroTest {

    private static HikariDataSource pool;
    private static JdbcClient jdbc;
    private static RetiroService retiros;

    @BeforeAll
    static void preparar() {
        pool = PostgresDePrueba.crearBaseMigrada().nuevoPool(5);
        jdbc = JdbcClient.create(pool);
        retiros = ServiciosDePrueba.retiroService(pool);
    }

    @AfterAll
    static void cerrar() {
        pool.close();
    }

    @BeforeEach
    void vaciar() {
        jdbc.sql("DELETE FROM outbox").update();
    }

    private static long eventosEnElOutbox() {
        return jdbc.sql("SELECT count(*) FROM outbox").query(Long.class).single();
    }

    @Test
    @DisplayName("Un retiro deja UN evento RETIRO_EJECUTADO en el outbox, con las cifras del comprobante")
    void retiroDejaSuEvento() {
        var comprobante = retiros.retirar(120, new BigDecimal("3000"), null);

        assertThat(eventosEnElOutbox()).isEqualTo(1);
        var fila = jdbc.sql("SELECT tipo, topico, clave, payload, publicado FROM outbox").query().singleRow();
        assertThat(fila.get("tipo")).isEqualTo("RETIRO_EJECUTADO");
        assertThat(fila.get("topico")).isEqualTo(Topicos.RETIROS);
        assertThat(fila.get("clave")).as("la clave es la cuenta").isEqualTo("120");
        assertThat(fila.get("publicado")).as("nace pendiente").isNull();

        SobreEvento evento = CodecEventos.leer((String) fila.get("payload"));
        assertThat(evento.tipo()).isEqualTo(TiposEvento.RETIRO_EJECUTADO);
        assertThat(evento.version()).isEqualTo(1);
        assertThat(evento.origen()).isEqualTo("core-service");
        DatosRetiro datos = evento.datosComo(DatosRetiro.class);
        assertThat(datos.cuentaId()).isEqualTo(120);
        assertThat(datos.folio()).isEqualTo(comprobante.folio());
        assertThat(datos.monto()).isEqualByComparingTo("3000");
        assertThat(datos.saldoAnterior()).isEqualByComparingTo(comprobante.saldoAnterior());
        assertThat(datos.saldoPosterior()).isEqualByComparingTo(comprobante.saldoPosterior());
        assertThat(datos.moneda()).isEqualTo("CLP");
        long movimiento = jdbc.sql("SELECT count(*) FROM movimiento WHERE id = :id")
                .param("id", datos.movimientoId()).query(Long.class).single();
        assertThat(movimiento).as("el evento apunta al movimiento que dejo el retiro").isEqualTo(1);
    }

    @Test
    @DisplayName("Un retiro rechazado por saldo insuficiente no deja evento: no se anuncia lo que no ocurrio")
    void retiroRechazadoNoDejaEvento() {
        assertThatThrownBy(() -> retiros.retirar(120, new BigDecimal("999999999"), null))
                .isInstanceOf(SaldoInsuficienteException.class);

        assertThat(eventosEnElOutbox()).isZero();
    }

    @Test
    @DisplayName("Un reintento con la misma Idempotency-Key devuelve el mismo comprobante y NO genera un segundo evento")
    void reintentoIdempotenteNoDuplicaElEvento() {
        String clave = "clave-" + UUID.randomUUID();

        var primero = retiros.retirar(121, new BigDecimal("2000"), clave);
        var reintento = retiros.retirar(121, new BigDecimal("2000"), clave);

        assertThat(reintento.folio()).isEqualTo(primero.folio());
        assertThat(eventosEnElOutbox()).as("un solo retiro, un solo evento").isEqualTo(1);
    }

    @Test
    @DisplayName("El evento y el descuento son atomicos: si la transaccion se deshace, no queda ni el uno ni el otro")
    void siSeDeshaceNoQuedaNada() {
        BigDecimal saldoAntes = jdbc.sql("SELECT saldo FROM cuenta WHERE id = 122").query(BigDecimal.class).single();
        TransactionTemplate transaccion = new TransactionTemplate(new DataSourceTransactionManager(pool));
        OutboxJdbc outbox = new OutboxJdbc(jdbc);

        assertThatThrownBy(() -> transaccion.executeWithoutResult(estado -> {
            jdbc.sql("UPDATE cuenta SET saldo = saldo - 1000 WHERE id = 122").update();
            outbox.registrar(Topicos.RETIROS, "122", SobreEvento.nuevo(TiposEvento.RETIRO_EJECUTADO, 1,
                    java.time.Instant.now(), "core-service", java.util.Map.of("cuentaId", 122)));
            throw new IllegalStateException("falla despues de escribir el evento");
        })).isInstanceOf(IllegalStateException.class);

        assertThat(eventosEnElOutbox()).as("el evento se deshizo junto con el descuento").isZero();
        assertThat(jdbc.sql("SELECT saldo FROM cuenta WHERE id = 122").query(BigDecimal.class).single())
                .isEqualByComparingTo(saldoAntes);
    }

    @Test
    @DisplayName("El outbox se niega a escribir fuera de una transaccion (el evento y el cambio dejarian de ser atomicos)")
    void sinTransaccionSeNiega() {
        OutboxJdbc outbox = new OutboxJdbc(jdbc);

        assertThatThrownBy(() -> outbox.registrar(Topicos.RETIROS, "1", SobreEvento.nuevo(
                TiposEvento.RETIRO_EJECUTADO, 1, java.time.Instant.now(), "core-service", java.util.Map.of())))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("transaccion");
        assertThat(eventosEnElOutbox()).isZero();
    }

    @Test
    @DisplayName("Retiros de cuentas distintas quedan en el outbox en el orden en que se confirmaron")
    void ordenDeConfirmacion() {
        retiros.retirar(120, new BigDecimal("1000"), null);
        retiros.retirar(121, new BigDecimal("1000"), null);
        retiros.retirar(120, new BigDecimal("1000"), null);

        List<String> claves = jdbc.sql("SELECT clave FROM outbox ORDER BY id").query(String.class).list();
        assertThat(claves).containsExactly("120", "121", "120");
    }
}
