package cl.duoc.bancoxyz.core.eventos;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.kafka.core.KafkaTemplate;

import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.aplicacion.RetiroService;
import cl.duoc.bancoxyz.core.soporte.Concurrencia;
import cl.duoc.bancoxyz.eventos.soporte.KafkaDePrueba;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;
import cl.duoc.bancoxyz.core.soporte.ServiciosDePrueba;
import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.DatosRetiro;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.Topicos;

/**
 * El relay del outbox contra un PostgreSQL y un Kafka REALES: publica, no duplica y conserva el orden por
 * cuenta, tambien con varias replicas compitiendo y con Kafka inalcanzable.
 *
 * <p>Cada prueba trabaja con los eventos de SU base (identificados por {@code eventId}) y los busca en el
 * topico compartido: asi no depende de lo que hayan dejado las otras.
 */
class RelayOutboxTest {

    private static HikariDataSource pool;
    private static JdbcClient jdbc;
    private static RetiroService retiros;
    private static KafkaTemplate<String, String> kafka;

    @BeforeAll
    static void preparar() {
        pool = PostgresDePrueba.crearBaseMigrada().nuevoPool(20);
        jdbc = JdbcClient.create(pool);
        retiros = ServiciosDePrueba.retiroService(pool);
        kafka = KafkaDePrueba.plantilla(KafkaDePrueba.bootstrap());
    }

    @AfterAll
    static void cerrar() {
        kafka.destroy();
        pool.close();
    }

    private static RelayOutbox relay(LiderRelay lider, KafkaTemplate<String, String> plantilla, int lote) {
        EventosProperties propiedades = new EventosProperties(new EventosProperties.Relay(
                true, Duration.ofMillis(200), lote, Duration.ofSeconds(5), Duration.ofDays(1)));
        return new RelayOutbox(jdbc, new DataSourceTransactionManager(pool), lider,
                new PublicadorKafka(plantilla, propiedades), propiedades);
    }

    private static LiderRelay siempreLider() {
        return new LiderRelay(pool) {
            @Override
            public boolean esLider() {
                return true;
            }
        };
    }

    private static long pendientes() {
        return jdbc.sql("SELECT count(*) FROM outbox WHERE publicado IS NULL").query(Long.class).single();
    }

    private static Set<String> idsDeEventosPendientes() {
        return new HashSet<>(jdbc.sql("SELECT event_id::text FROM outbox WHERE publicado IS NULL")
                .query(String.class).list());
    }

    private static List<Integer> cuentasConSaldo(int cuantas) {
        List<Integer> cuentas = jdbc.sql("SELECT id FROM cuenta WHERE saldo >= 5000 ORDER BY id LIMIT :n")
                .param("n", cuantas).query(Integer.class).list();
        assertThat(cuentas).as("el dataset tiene cuentas con saldo suficiente para la prueba").hasSize(cuantas);
        return cuentas;
    }

    /** Eventos del topico (en el orden del log por particion) que pertenecen a los ids dados. */
    private static List<ConsumerRecord<String, String>> delTopico(Set<String> ids) {
        List<ConsumerRecord<String, String>> todos = KafkaDePrueba.leerHasta(Topicos.RETIROS,
                leidos -> leidos.stream().filter(r -> ids.contains(CodecEventos.leer(r.value()).eventId()))
                        .count() >= ids.size(), Duration.ofSeconds(30));
        return todos.stream().filter(r -> ids.contains(CodecEventos.leer(r.value()).eventId())).toList();
    }

    @Test
    @DisplayName("Publica lo pendiente: cada retiro llega a Kafka con la cuenta como clave, y el outbox queda marcado")
    void publica() {
        List<Integer> cuentas = cuentasConSaldo(3);
        for (int cuenta : cuentas) {
            retiros.retirar(cuenta, new BigDecimal("1000"), null);
        }
        Set<String> ids = idsDeEventosPendientes();
        assertThat(ids).hasSize(3);

        try (LiderRelay lider = new LiderRelay(pool)) {
            int publicados = relay(lider, kafka, 200).publicarPendientes();

            assertThat(publicados).isEqualTo(3);
        }
        assertThat(pendientes()).as("nada queda pendiente").isZero();

        List<ConsumerRecord<String, String>> enKafka = delTopico(ids);
        assertThat(enKafka).hasSize(3);
        for (ConsumerRecord<String, String> registro : enKafka) {
            SobreEvento evento = CodecEventos.leer(registro.value());
            DatosRetiro datos = evento.datosComo(DatosRetiro.class);
            assertThat(registro.key()).as("la clave es la cuenta").isEqualTo(Integer.toString(datos.cuentaId()));
            assertThat(cuentas).contains(datos.cuentaId());
            assertThat(evento.tipo()).isEqualTo("RETIRO_EJECUTADO");
            assertThat(evento.origen()).isEqualTo("core-service");
            assertThat(datos.monto()).isEqualByComparingTo("1000");
            assertThat(datos.saldoAnterior().subtract(datos.saldoPosterior())).isEqualByComparingTo("1000");
            assertThat(new String(registro.headers().lastHeader("eventId").value()))
                    .as("la cabecera eventId coincide con el del sobre").isEqualTo(evento.eventId());
        }
    }

    @Test
    @DisplayName("No duplica: un segundo ciclo no vuelve a publicar, y dos relays compitiendo publican cada evento una sola vez")
    void noDuplica() throws Exception {
        List<Integer> cuentas = cuentasConSaldo(4);
        for (int i = 0; i < 20; i++) {
            retiros.retirar(cuentas.get(i % cuentas.size()), new BigDecimal("500"), null);
        }
        Set<String> ids = idsDeEventosPendientes();
        assertThat(ids).hasSize(20);

        // Dos relays SIN eleccion de lider (los dos creen serlo), lotes chicos, en paralelo: el peor caso.
        // Lo que impide el duplicado es el bloqueo de filas (FOR UPDATE), no el liderazgo.
        RelayOutbox uno = relay(siempreLider(), kafka, 3);
        RelayOutbox otro = relay(siempreLider(), kafka, 3);
        List<Callable<Integer>> tareas = new ArrayList<>();
        for (RelayOutbox relay : List.of(uno, otro)) {
            tareas.add(() -> {
                int total = 0;
                int ciclo;
                while ((ciclo = relay.publicarPendientes()) > 0) {
                    total += ciclo;
                }
                return total;
            });
        }
        List<Concurrencia.Resultado<Integer>> resultados = Concurrencia.enParalelo(tareas);
        int sumaPublicada = resultados.stream().mapToInt(r -> r.valor() == null ? 0 : r.valor()).sum();
        assertThat(resultados).allMatch(Concurrencia.Resultado::fueExito);
        assertThat(sumaPublicada).as("entre los dos relays se publicaron exactamente 20").isEqualTo(20);

        // Un ciclo mas no encuentra nada.
        assertThat(uno.publicarPendientes()).isZero();
        assertThat(pendientes()).isZero();

        List<ConsumerRecord<String, String>> enKafka = delTopico(ids);
        Map<String, Integer> vecesPorEvento = new HashMap<>();
        enKafka.forEach(r -> vecesPorEvento.merge(CodecEventos.leer(r.value()).eventId(), 1, Integer::sum));
        assertThat(vecesPorEvento).as("cada evento esta en Kafka").hasSize(20);
        assertThat(vecesPorEvento.values()).as("y exactamente una vez").containsOnly(1);
    }

    @Test
    @DisplayName("Conserva el orden por cuenta: con retiros concurrentes y lotes chicos, la cadena de saldos de cada cuenta sale intacta")
    void conservaElOrdenPorCuenta() {
        List<Integer> cuentas = cuentasConSaldo(5);
        int retirosPorCuenta = 8;
        List<Callable<Object>> tareas = new ArrayList<>();
        for (int cuenta : cuentas) {
            for (int i = 0; i < retirosPorCuenta; i++) {
                tareas.add(() -> retiros.retirar(cuenta, new BigDecimal("500"), null));
            }
        }
        // 40 retiros simultaneos: dos de la misma cuenta se serializan por el UPDATE de la fila.
        Concurrencia.enParalelo(tareas).forEach(r -> assertThat(r.fueExito()).isTrue());
        Set<String> ids = idsDeEventosPendientes();
        assertThat(ids).hasSize(cuentas.size() * retirosPorCuenta);

        // Lote de 7: varios ciclos, varios lotes por particion, para que el orden se ponga a prueba.
        RelayOutbox relay = relay(siempreLider(), kafka, 7);
        int total = 0;
        int ciclo;
        while ((ciclo = relay.publicarPendientes()) > 0) {
            total += ciclo;
        }
        assertThat(total).isEqualTo(ids.size());

        List<ConsumerRecord<String, String>> enKafka = delTopico(ids);
        Map<String, List<DatosRetiro>> porCuenta = new HashMap<>();
        for (ConsumerRecord<String, String> registro : enKafka) {
            porCuenta.computeIfAbsent(registro.key(), k -> new ArrayList<>())
                    .add(CodecEventos.leer(registro.value()).datosComo(DatosRetiro.class));
        }
        assertThat(porCuenta).hasSize(cuentas.size());
        porCuenta.forEach((cuenta, eventos) -> {
            assertThat(eventos).as("cuenta %s", cuenta).hasSize(retirosPorCuenta);
            // Cada retiro parte del saldo con que quedo el anterior: si dos eventos se hubieran invertido,
            // la cadena se rompe en ese punto.
            for (int i = 1; i < eventos.size(); i++) {
                assertThat(eventos.get(i).saldoAnterior())
                        .as("cuenta %s, evento %d: parte del saldo final del anterior", cuenta, i)
                        .isEqualByComparingTo(eventos.get(i - 1).saldoPosterior());
            }
        });
    }

    @Test
    @DisplayName("Con Kafka inalcanzable no se pierde nada: el evento sigue pendiente y se entrega cuando Kafka vuelve")
    void conKafkaInalcanzableElEventoEspera() {
        List<Integer> cuentas = cuentasConSaldo(1);
        retiros.retirar(cuentas.get(0), new BigDecimal("1000"), null);
        Set<String> ids = idsDeEventosPendientes();
        assertThat(ids).hasSize(1);

        // Un productor apuntado a un puerto donde no escucha nadie.
        KafkaTemplate<String, String> muerto = KafkaDePrueba.plantilla("127.0.0.1:1");
        try {
            RelayOutbox relayRoto = relay(siempreLider(), muerto, 200);
            assertThat(relayRoto.publicarPendientes()).as("no pudo publicar").isZero();
            assertThat(idsDeEventosPendientes()).as("el evento sigue en el outbox").isEqualTo(ids);
        } finally {
            muerto.destroy();
        }

        // Kafka "vuelve": un relay con el productor bueno entrega lo que esperaba.
        assertThat(relay(siempreLider(), kafka, 200).publicarPendientes()).isEqualTo(1);
        assertThat(pendientes()).isZero();
        assertThat(delTopico(ids)).hasSize(1);
    }
}
