package cl.duoc.bancoxyz.core.soporte;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import cl.duoc.bancoxyz.core.adaptador.CuentaRepositoryJdbc;
import cl.duoc.bancoxyz.core.adaptador.GeneradorIdentificadoresJdbc;
import cl.duoc.bancoxyz.core.adaptador.OutboxJdbc;
import cl.duoc.bancoxyz.core.adaptador.RegistroIdempotenciaJdbc;
import cl.duoc.bancoxyz.core.aplicacion.RetiroService;
import cl.duoc.bancoxyz.core.config.CoreProperties;

/** Arma el caso de uso de retiro con los adaptadores JDBC reales sobre un pool dado. */
public final class ServiciosDePrueba {

    private ServiciosDePrueba() {
    }

    public static RetiroService retiroService(DataSource pool) {
        JdbcClient jdbc = JdbcClient.create(pool);
        DataSourceTransactionManager gestor = new DataSourceTransactionManager(pool);
        CoreProperties propiedades = new CoreProperties(
                new CoreProperties.Paginacion(20, 100), "CLP", new CoreProperties.Folio("RET", 6));
        Clock reloj = Clock.fixed(Instant.parse("2026-09-11T15:00:00Z"), ZoneId.of("UTC"));
        return new RetiroService(new CuentaRepositoryJdbc(jdbc, gestor), new RegistroIdempotenciaJdbc(jdbc, gestor),
                new GeneradorIdentificadoresJdbc(jdbc), propiedades, reloj, new OutboxJdbc(jdbc), gestor);
    }
}
