package cl.duoc.bancoxyz.core.seguridad;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.ssl.DefaultSslBundleRegistry;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.test.util.ReflectionTestUtils;

/**
 * El core conserva las claves publicas del auth-server sin vencimiento: con el auth-server caido no espera el timeout
 * de la descarga en cada peticion (medido: 2.011 ms por peticion cuando la cache por defecto, de 5 minutos, vencia).
 * El comportamiento completo, con un servidor de claves que se apaga, se prueba en plataforma-comun con la misma
 * logica; aqui se comprueba que el core la aplica.
 */
@DisplayName("Core: claves del auth-server con cache sin vencimiento")
class ConfianzaEnElAuthServerConfigTest {

    @Test
    @DisplayName("El constructor del decodificador recibe una cache de Spring sin vencimiento")
    void laCacheDeClavesNoVence() {
        NimbusJwtDecoder.JwkSetUriJwtDecoderBuilder constructor = NimbusJwtDecoder.withJwkSetUri("http://127.0.0.1:1/jwks");

        new ConfianzaEnElAuthServerConfig()
                .descargaDeClavesConLaCaInterna(new DefaultSslBundleRegistry(), Duration.ofSeconds(1), Duration.ofSeconds(1))
                .customize(constructor);

        assertThat(ReflectionTestUtils.getField(constructor, "cache")).isInstanceOf(ConcurrentMapCache.class);
    }
}
