package cl.duoc.bancoxyz.core.soporte;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Suelta muchas tareas <strong>a la vez</strong> para provocar la carrera que se quiere probar.
 *
 * <p>Un error de concurrencia solo aparece cuando dos hilos coinciden en una ventana de
 * microsegundos. Si los hilos se lanzaran escalonados, la prueba pasaria incluso con codigo
 * defectuoso. Por eso todas las tareas se quedan esperando en una barrera
 * ({@link CountDownLatch}) y arrancan juntas cuando se abre.
 */
public final class Concurrencia {

    private Concurrencia() {
    }

    /** Resultado de una tarea: el valor que devolvio o la excepcion con que termino. */
    public record Resultado<T>(T valor, Throwable error) {

        public boolean fueExito() {
            return error == null;
        }
    }

    /**
     * Ejecuta las tareas en paralelo, todas liberadas por la misma barrera, y devuelve el resultado
     * de cada una en el mismo orden. Falla si alguna tarda mas de 30 s (un interbloqueo).
     */
    public static <T> List<Resultado<T>> enParalelo(List<Callable<T>> tareas) {
        CountDownLatch salida = new CountDownLatch(1);
        ExecutorService piscina = Executors.newFixedThreadPool(tareas.size());
        try {
            List<Future<Resultado<T>>> futuros = new ArrayList<>();
            for (Callable<T> tarea : tareas) {
                futuros.add(piscina.submit(() -> {
                    salida.await();
                    try {
                        return new Resultado<>(tarea.call(), null);
                    } catch (Throwable e) {
                        return new Resultado<>(null, e);
                    }
                }));
            }
            salida.countDown();
            List<Resultado<T>> resultados = new ArrayList<>();
            for (Future<Resultado<T>> futuro : futuros) {
                resultados.add(futuro.get(30, TimeUnit.SECONDS));
            }
            return resultados;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(e);
        } catch (ExecutionException | TimeoutException e) {
            throw new IllegalStateException("Las tareas no terminaron: posible interbloqueo", e);
        } finally {
            piscina.shutdownNow();
        }
    }
}
