package cl.duoc.bancoxyz.core.seguridad;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.core.soporte.EmisorDePrueba;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * La matriz de seguridad del core contra un Tomcat real, con tokens firmados de verdad y validados por
 * el mismo camino que en produccion (descarga del JWKS, firma, emisor, vigencia, audiencia y scope).
 *
 * <p>Es la prueba de la fase F4: sin token 401, token vencido 401, token de otra audiencia 401, scope
 * insuficiente 403 (el token del BFF web intentando un retiro) y token valido 200. Cada fila de la
 * matriz cambia exactamente una variable respecto de un token valido, de modo que el motivo del rechazo
 * no es ambiguo.
 *
 * <p>Contra un servidor real y no con MockMvc porque entre las pruebas esta la de las variantes de URL
 * ({@code ;x=1}, letras codificadas), que dependen de como el contenedor normaliza la ruta antes de que
 * la vea Spring Security. MockMvc arma la peticion a mano y no reproduce esa normalizacion.
 *
 * <p>El emisor que espera el core es {@code https://localhost:9000} y NADA escucha ahi durante estas
 * pruebas: que el contexto arranque y los tokens se validen demuestra que, con {@code jwk-set-uri} e
 * {@code issuer-uri} juntos, Spring Boot no intenta el descubrimiento OIDC (el punto "A VERIFICAR" del
 * plan para esta fase).
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
class SeguridadOAuth2CoreTest {

    private static final EmisorDePrueba EMISOR = EmisorDePrueba.compartido();

    private static final String CUENTA = "/internal/v1/cuentas/116";
    private static final String MOVIMIENTOS = "/internal/v1/cuentas/116/movimientos";
    private static final String SALDO = "/internal/v1/cuentas/116/saldo";
    private static final String RETIRO = "/internal/v1/cuentas/116/retiros";
    private static final String CALIDAD = "/internal/v1/admin/calidad-datos";
    private static final String NO_CONCILIADAS = "/internal/v1/admin/transacciones-no-conciliadas";

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @LocalServerPort
    private int puerto;

    private final HttpClient cliente = HttpClient.newHttpClient();

    // ---------------------------------------------------------------------------------------------
    // Ayudas
    // ---------------------------------------------------------------------------------------------

    private HttpResponse<String> llamar(String metodo, String ruta, String autorizacion, String cuerpo)
            throws IOException, InterruptedException {
        HttpRequest.Builder peticion = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + puerto + ruta));
        if (autorizacion != null) {
            peticion.header("Authorization", autorizacion);
        }
        if (cuerpo != null) {
            peticion.header("Content-Type", "application/json");
            peticion.header("Idempotency-Key", "k-" + System.nanoTime());
            peticion.method(metodo, HttpRequest.BodyPublishers.ofString(cuerpo));
        } else {
            peticion.method(metodo, HttpRequest.BodyPublishers.noBody());
        }
        return cliente.send(peticion.build(), HttpResponse.BodyHandlers.ofString());
    }

    private HttpResponse<String> get(String ruta, String token) throws IOException, InterruptedException {
        return llamar("GET", ruta, token == null ? null : "Bearer " + token, null);
    }

    private HttpResponse<String> retirar(String cuenta, String token) throws IOException, InterruptedException {
        return llamar("POST", "/internal/v1/cuentas/" + cuenta + "/retiros", "Bearer " + token, "{\"monto\":1000}");
    }

    private static final String WEB = "bff-web";
    private static final String[] SCOPES_WEB = {"cuentas:leer", "movimientos:leer", "auditoria:leer"};

    private String tokenWeb() {
        return EMISOR.tokenDe(WEB, SCOPES_WEB).emitir();
    }

    // ---------------------------------------------------------------------------------------------
    // 401: el core no sabe quien llama
    // ---------------------------------------------------------------------------------------------

    @ParameterizedTest(name = "sin token, GET {0} responde 401 token_ausente")
    @ValueSource(strings = {CUENTA, MOVIMIENTOS, SALDO, CALIDAD, NO_CONCILIADAS})
    @DisplayName("Sin token todo endpoint responde 401, con el motivo token_ausente y el desafio Bearer")
    void sinTokenEs401(String ruta) throws Exception {
        HttpResponse<String> respuesta = get(ruta, null);

        assertThat(respuesta.statusCode()).isEqualTo(401);
        assertThat(respuesta.headers().firstValue("WWW-Authenticate")).hasValueSatisfying(
                v -> assertThat(v).startsWith("Bearer"));
        assertThat(respuesta.headers().firstValue("Content-Type")).hasValueSatisfying(
                v -> assertThat(v).contains("application/problem+json"));
        assertThat(respuesta.body()).contains("\"motivo\":\"token_ausente\"").contains("\"status\":401")
                .doesNotContain("Diana Prince");
    }

    @Test
    @DisplayName("Sin token, el retiro (POST) tambien responde 401 y no descuenta nada")
    void sinTokenElRetiroEs401() throws Exception {
        HttpResponse<String> respuesta = llamar("POST", RETIRO, null, "{\"monto\":1000}");

        assertThat(respuesta.statusCode()).isEqualTo(401);
        assertThat(respuesta.body()).contains("token_ausente");
    }

    @Test
    @DisplayName("Un token vencido responde 401 token_invalido")
    void tokenVencidoEs401() throws Exception {
        String vencido = EMISOR.tokenDe(WEB, SCOPES_WEB).vencido().emitir();

        HttpResponse<String> respuesta = get(CUENTA, vencido);

        assertThat(respuesta.statusCode()).isEqualTo(401);
        assertThat(respuesta.body()).contains("\"motivo\":\"token_invalido\"");
        // El cuerpo no explica por que fallo la validacion: eso es del log del servidor.
        assertThat(respuesta.body()).doesNotContainIgnoringCase("expired").doesNotContainIgnoringCase("vencid");
    }

    @Test
    @DisplayName("Un token firmado y vigente pero de OTRA audiencia responde 401")
    void tokenDeOtraAudienciaEs401() throws Exception {
        String deOtroServicio = EMISOR.tokenDe(WEB, SCOPES_WEB).conAudiencia("auditoria-service").emitir();

        HttpResponse<String> respuesta = get(CUENTA, deOtroServicio);

        assertThat(respuesta.statusCode()).isEqualTo(401);
        assertThat(respuesta.body()).contains("token_invalido");
    }

    @Test
    @DisplayName("Un token con varias audiencias sirve si una de ellas es core-service (el caso de bff-web)")
    void tokenConVariasAudienciasSirve() throws Exception {
        String conDos = EMISOR.tokenDe(WEB, SCOPES_WEB).conAudiencia("core-service", "auditoria-service").emitir();

        assertThat(get(CUENTA, conDos).statusCode()).isEqualTo(200);
    }

    @Test
    @DisplayName("Un token de otro emisor responde 401")
    void tokenDeOtroEmisorEs401() throws Exception {
        String otroEmisor = EMISOR.tokenDe(WEB, SCOPES_WEB).conEmisor("https://otro-emisor.example").emitir();

        assertThat(get(CUENTA, otroEmisor).statusCode()).isEqualTo(401);
    }

    @Test
    @DisplayName("Un token firmado con una clave que el JWKS no publica responde 401")
    void tokenFirmadoPorOtraClaveEs401() throws Exception {
        String falsificado = EMISOR.tokenDe(WEB, SCOPES_WEB).firmadoPorOtraClave().emitir();

        assertThat(get(CUENTA, falsificado).statusCode()).isEqualTo(401);
    }

    @Test
    @DisplayName("Un JWT sin firma (alg none) y un texto cualquiera responden 401")
    void tokenSinFirmaYBasuraSon401() throws Exception {
        String valido = tokenWeb();
        String[] partes = valido.split("\\.");
        // Cabecera {"alg":"none"} y el mismo contenido, sin firma: el ataque clasico de "alg none".
        String cabeceraNone = java.util.Base64.getUrlEncoder().withoutPadding()
                .encodeToString("{\"alg\":\"none\"}".getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String sinFirma = cabeceraNone + "." + partes[1] + ".";

        assertThat(get(CUENTA, sinFirma).statusCode()).isEqualTo(401);
        assertThat(get(CUENTA, "esto-no-es-un-jwt").statusCode()).isEqualTo(401);
    }

    @Test
    @DisplayName("Un token alterado despues de firmado (se le agrega un scope) responde 401")
    void tokenAlteradoEs401() throws Exception {
        String soloCuentas = EMISOR.tokenDe("bff-mobile", "cuentas:leer").emitir();
        String[] partes = soloCuentas.split("\\.");
        String payload = new String(java.util.Base64.getUrlDecoder().decode(partes[1]),
                java.nio.charset.StandardCharsets.UTF_8)
                .replace("\"cuentas:leer\"", "\"cuentas:leer\",\"retiros:ejecutar\"");
        String alterado = partes[0] + "."
                + java.util.Base64.getUrlEncoder().withoutPadding()
                        .encodeToString(payload.getBytes(java.nio.charset.StandardCharsets.UTF_8))
                + "." + partes[2];

        assertThat(alterado).isNotEqualTo(soloCuentas);
        assertThat(retirar("116", alterado).statusCode()).isEqualTo(401);
    }

    @Test
    @DisplayName("Una cabecera propia con la credencial fija del S5 ya no abre nada, y Authorization que no sea Bearer tampoco")
    void lasCredencialesAntiguasNoSirven() throws Exception {
        HttpResponse<String> conCabeceraVieja = cliente.send(
                HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + puerto + CUENTA))
                        .header("X-Credencial-De-Servicio", "token-de-desarrollo-no-usar-en-produccion").GET().build(),
                HttpResponse.BodyHandlers.ofString());
        HttpResponse<String> conBasic = llamar("GET", CUENTA, "Basic dXN1YXJpbzpjbGF2ZQ==", null);

        assertThat(conCabeceraVieja.statusCode()).isEqualTo(401);
        assertThat(conBasic.statusCode()).isEqualTo(401);
        assertThat(conBasic.body()).contains("token_ausente");
    }

    // ---------------------------------------------------------------------------------------------
    // 403: el token es valido y no alcanza
    // ---------------------------------------------------------------------------------------------

    @Test
    @DisplayName("El token del BFF web intentando un retiro responde 403: su token no mueve dinero")
    void elBffWebNoPuedeRetirar() throws Exception {
        HttpResponse<String> respuesta = retirar("116", tokenWeb());

        assertThat(respuesta.statusCode()).isEqualTo(403);
        assertThat(respuesta.headers().firstValue("WWW-Authenticate")).hasValueSatisfying(
                v -> assertThat(v).contains("insufficient_scope"));
        assertThat(respuesta.body()).contains("\"motivo\":\"permiso_insuficiente\"").contains("\"status\":403");
    }

    /** Cliente, scopes que tiene, endpoint, metodo: todo lo que NO debe poder hacer cada BFF. */
    static Stream<Arguments> loQueCadaBffNoPuedeHacer() {
        return Stream.of(
                // bff-web (cuentas, movimientos, auditoria): ni saldo ni retiros
                Arguments.of("bff-web", "GET", SALDO),
                Arguments.of("bff-web", "POST", RETIRO),
                // bff-mobile (solo cuentas:leer)
                Arguments.of("bff-mobile", "GET", MOVIMIENTOS),
                Arguments.of("bff-mobile", "GET", SALDO),
                Arguments.of("bff-mobile", "POST", RETIRO),
                Arguments.of("bff-mobile", "GET", CALIDAD),
                Arguments.of("bff-mobile", "GET", NO_CONCILIADAS),
                // bff-atm (saldo y retiros): ni cuentas, ni movimientos, ni administracion
                Arguments.of("bff-atm", "GET", CUENTA),
                Arguments.of("bff-atm", "GET", MOVIMIENTOS),
                Arguments.of("bff-atm", "GET", CALIDAD),
                Arguments.of("bff-atm", "GET", NO_CONCILIADAS));
    }

    private static String[] scopesDe(String cliente) {
        return switch (cliente) {
            case "bff-web" -> SCOPES_WEB;
            case "bff-mobile" -> new String[] {"cuentas:leer"};
            case "bff-atm" -> new String[] {"saldo:leer", "retiros:ejecutar"};
            default -> throw new IllegalArgumentException(cliente);
        };
    }

    @ParameterizedTest(name = "{0} no puede {1} {2}: 403")
    @MethodSource("loQueCadaBffNoPuedeHacer")
    @DisplayName("Minimo privilegio: cada BFF recibe 403 en lo que sus scopes no cubren")
    void cadaBffRecibe403EnLoQueNoEsSuyo(String cliente, String metodo, String ruta) throws Exception {
        String token = EMISOR.tokenDe(cliente, scopesDe(cliente)).emitir();

        HttpResponse<String> respuesta = llamar(metodo, ruta, "Bearer " + token,
                "POST".equals(metodo) ? "{\"monto\":1000}" : null);

        assertThat(respuesta.statusCode()).isEqualTo(403);
        assertThat(respuesta.body()).contains("permiso_insuficiente");
    }

    @Test
    @DisplayName("Un token valido pero sin ningun scope responde 403 en todo")
    void sinScopesEs403() throws Exception {
        String sinScopes = EMISOR.tokenDe("bff-web").emitir();

        for (String ruta : new String[] {CUENTA, MOVIMIENTOS, SALDO, CALIDAD, NO_CONCILIADAS}) {
            assertThat(get(ruta, sinScopes).statusCode()).as(ruta).isEqualTo(403);
        }
    }

    // ---------------------------------------------------------------------------------------------
    // 200: lo que cada BFF SI puede hacer
    // ---------------------------------------------------------------------------------------------

    static Stream<Arguments> loQueCadaBffPuedeHacer() {
        return Stream.of(
                Arguments.of("bff-web", CUENTA, "\"cuentaId\":116"),
                Arguments.of("bff-web", MOVIMIENTOS, "\"movimientos\""),
                Arguments.of("bff-web", CALIDAD, "\"cuentasConsolidadas\""),
                Arguments.of("bff-web", NO_CONCILIADAS, "\"transacciones\""),
                Arguments.of("bff-mobile", CUENTA, "\"cuentaId\":116"),
                Arguments.of("bff-atm", SALDO, "\"saldo\""));
    }

    @ParameterizedTest(name = "{0} con su token: GET {1} responde 200")
    @MethodSource("loQueCadaBffPuedeHacer")
    @DisplayName("Con un token valido y el scope del endpoint se responde 200")
    void conElScopeCorrectoEs200(String cliente, String ruta, String fragmento) throws Exception {
        HttpResponse<String> respuesta = get(ruta, EMISOR.tokenDe(cliente, scopesDe(cliente)).emitir());

        assertThat(respuesta.statusCode()).isEqualTo(200);
        assertThat(respuesta.body()).contains(fragmento);
    }

    @Test
    @DisplayName("El BFF del cajero, con retiros:ejecutar, retira (200) y recibe su comprobante")
    void elBffAtmRetira() throws Exception {
        HttpResponse<String> respuesta = retirar("150", EMISOR.tokenDe("bff-atm", scopesDe("bff-atm")).emitir());

        assertThat(respuesta.statusCode()).isEqualTo(200);
        assertThat(respuesta.body()).contains("\"folio\"").contains("\"montoRetirado\"");
    }

    // ---------------------------------------------------------------------------------------------
    // Lo que nadie declaro se rechaza; ninguna variante de la URL evita la regla
    // ---------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Una ruta que ninguna regla declara se rechaza aun con un token de todos los scopes")
    void loNoDeclaradoSeRechaza() throws Exception {
        String todos = EMISOR.tokenDe(WEB, "cuentas:leer", "movimientos:leer", "saldo:leer",
                "retiros:ejecutar", "auditoria:leer").emitir();

        assertThat(get("/internal/v1/no-existe", todos).statusCode()).isEqualTo(403);
        assertThat(llamar("DELETE", CUENTA, "Bearer " + todos, null).statusCode()).isEqualTo(403);
        assertThat(get("/actuator/env", todos).statusCode()).isEqualTo(403);
        assertThat(get("/", todos).statusCode()).isEqualTo(403);
    }

    @Test
    @DisplayName("/actuator/... en el puerto de servicio exige token (el puerto de gestion es el unico abierto)")
    void actuatorEnElPuertoDeServicioNoEsPublico() throws Exception {
        assertThat(get("/actuator/health", null).statusCode()).isEqualTo(401);
        assertThat(get("/actuator/metrics", null).statusCode()).isEqualTo(401);
    }

    @ParameterizedTest(name = "sin token, {0} nunca responde 200")
    @ValueSource(strings = {
            "/internal;x=1/v1/cuentas/116",
            "/internal/v1;x=1/cuentas/116",
            "/%69nternal/v1/cuentas/116",
            "/internal/%76%31/cuentas/116",
            "/internal/v1/cuentas/116/saldo",
            "/internal;x=1/v1/cuentas/116/movimientos",
            "/internal;x=1/v1/admin/calidad-datos",
            "/%69nternal/v1/admin/transacciones-no-conciliadas",
            "/internal/v1/cuentas/116/",
            "/internal/v1/cuentas/116/../116",
            "/internal//v1/cuentas/116",
            "/INTERNAL/v1/cuentas/116",
    })
    @DisplayName("Ninguna variante de la URL evita el token (heredado del S5: el filtro anterior se podia eludir)")
    void ningunaVarianteEvitaElToken(String ruta) throws Exception {
        HttpResponse<String> respuesta = get(ruta, null);

        // 401 si la ruta llega a la regla; 400 si el firewall de Spring Security rechaza la forma de la URL;
        // 404 no hay: el servidor no responde "no existe" a algo sin credencial.
        assertThat(respuesta.statusCode()).isIn(400, 401);
        assertThat(respuesta.body()).doesNotContain("Diana Prince").doesNotContain("\"cuentaId\"");
    }

    @Test
    @DisplayName("Con token, una letra codificada (%69) llega a la misma regla que la ruta normal; la forma con ; se rechaza")
    void variantesConToken() throws Exception {
        String token = tokenWeb();

        // El contenedor decodifica %69 a "i" antes de enrutar: es la ruta normal y se autoriza igual.
        assertThat(get("/%69nternal/v1/cuentas/116", token).statusCode()).isEqualTo(200);
        // El parametro de ruta ";x=1" lo rechaza el firewall: no se enruta, ni con un token valido.
        HttpResponse<String> conParametroDeRuta = get("/internal;x=1/v1/cuentas/116", token);
        assertThat(conParametroDeRuta.statusCode()).isEqualTo(400);
        assertThat(conParametroDeRuta.body()).contains("\"motivo\":\"peticion_invalida\"");
        // Mayusculas: otra ruta que ninguna regla declara.
        assertThat(get("/INTERNAL/v1/cuentas/116", token).statusCode()).isIn(400, 403);
    }
}
