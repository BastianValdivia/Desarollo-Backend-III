package cl.duoc.bancoxyz.core.adaptador;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.TipoCuenta;
import cl.duoc.bancoxyz.core.dominio.TipoMovimiento;
import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;

/**
 * <strong>La prueba mas importante del proyecto.</strong> Responde la pregunta que cualquier
 * revisor tecnico hace primero: si dos cajeros retiran de la misma cuenta en el mismo instante,
 * puede el saldo quedar negativo?
 *
 * <p>Lo que se prueba aqui no se puede comprobar mirando el codigo ni haciendo peticiones a mano: un
 * error de concurrencia solo aparece cuando dos hilos coinciden en la ventana exacta, y esa ventana
 * dura microsegundos. La forma de provocarla a proposito es soltar muchos hilos <em>a la vez</em>
 * sobre la misma cuenta, y para eso sirve el {@link CountDownLatch}: todos los hilos se quedan
 * esperando en la misma linea y arrancan juntos cuando el contador llega a cero. Sin esa barrera,
 * los hilos se lanzarian escalonadamente y la prueba pasaria incluso con codigo defectuoso.
 *
 * <p>Con la version ingenua (leer, validar, escribir por separado) esta prueba falla: varios hilos
 * leen el mismo saldo, todos concluyen que alcanza y todos escriben. Con
 * {@code ConcurrentHashMap.compute}, los hilos se serializan por cuenta y cada uno ve el saldo que
 * dejo el anterior.
 */
class RetiroConcurrenteTest {

    private static final int CUENTA = 116;
    private static final int HILOS = 20;

    @Test
    @DisplayName("20 retiros simultaneos de 1000 sobre un saldo de 12000: exactamente 12 pasan y el saldo queda en cero")
    void veinteRetirosSimultaneosNoDejanElSaldoNegativo() throws InterruptedException {
        CuentaRepositoryEnMemoria repositorio = new CuentaRepositoryEnMemoria();
        repositorio.guardar(new Cuenta(CUENTA, "Diana Prince", new BigDecimal("12000"), 30,
                TipoCuenta.HIPOTECA, List.of()));

        BigDecimal monto = new BigDecimal("1000");
        AtomicLong idMovimiento = new AtomicLong(1000);
        AtomicInteger exitosos = new AtomicInteger();
        AtomicInteger rechazados = new AtomicInteger();

        // Barrera de salida: los 20 hilos esperan aqui y se sueltan a la vez, para maximizar la
        // probabilidad de que coincidan dentro de la seccion critica.
        CountDownLatch salida = new CountDownLatch(1);
        CountDownLatch terminados = new CountDownLatch(HILOS);

        try (ExecutorService piscina = Executors.newFixedThreadPool(HILOS)) {
            for (int i = 0; i < HILOS; i++) {
                piscina.submit(() -> {
                    try {
                        salida.await();
                        repositorio.debitar(CUENTA, monto, "RET-PRUEBA", LocalDate.now(),
                                idMovimiento.incrementAndGet());
                        exitosos.incrementAndGet();
                    } catch (SaldoInsuficienteException saldoNoAlcanza) {
                        // Rechazo legitimo: la cuenta ya no tenia dinero. Es el resultado correcto
                        // para los 8 hilos que llegan tarde.
                        rechazados.incrementAndGet();
                    } catch (InterruptedException interrumpido) {
                        Thread.currentThread().interrupt();
                    } finally {
                        terminados.countDown();
                    }
                });
            }

            salida.countDown();
            assertThat(terminados.await(10, TimeUnit.SECONDS))
                    .as("los 20 hilos deben terminar; si no, hay un interbloqueo")
                    .isTrue();
        }

        Cuenta finalCuenta = repositorio.buscarPorId(CUENTA).orElseThrow();

        // LA ASERCION QUE IMPORTA. 12000 / 1000 = 12 retiros posibles, ni uno mas.
        assertThat(exitosos.get()).isEqualTo(12);
        assertThat(rechazados.get()).isEqualTo(HILOS - 12);

        assertThat(finalCuenta.saldo())
                .as("el saldo tiene que ser exacto, y sobre todo nunca negativo")
                .isEqualByComparingTo(BigDecimal.ZERO);

        // La otra mitad de la atomicidad: por cada descuento hay EXACTAMENTE un movimiento. Si
        // hubiera menos, algun saldo se descontó sin dejar rastro en el historial; si hubiera mas,
        // se registro un apunte de un retiro que nunca ocurrio. Las dos cosas son descuadres.
        assertThat(finalCuenta.movimientos()).hasSize(12);
        assertThat(finalCuenta.movimientos())
                .allMatch(m -> m.tipo() == TipoMovimiento.RETIRO);
    }

    @Test
    @DisplayName("Un retiro rechazado por saldo no modifica nada: ni el saldo ni el historial")
    void elRechazoNoDejaEfectosParciales() {
        CuentaRepositoryEnMemoria repositorio = new CuentaRepositoryEnMemoria();
        repositorio.guardar(new Cuenta(106, "Diana Prince", new BigDecimal("5000"), 35,
                TipoCuenta.AHORRO, List.of()));

        // El caso congelado de la demostracion: retirar 8000 de una cuenta con 5000.
        try {
            repositorio.debitar(106, new BigDecimal("8000"), "RET-PRUEBA", LocalDate.now(), 1L);
        } catch (SaldoInsuficienteException esperada) {
            // Es el resultado que se esperaba.
        }

        Cuenta cuenta = repositorio.buscarPorId(106).orElseThrow();

        // "Ambas cosas o ninguna" tambien cubre el fracaso: la excepcion sale desde DENTRO de la
        // funcion de compute, asi que la entrada del mapa nunca se reemplaza. No hay nada que
        // deshacer a mano, que es precisamente la ventaja de esta forma de escribirlo.
        assertThat(cuenta.saldo()).isEqualByComparingTo(new BigDecimal("5000"));
        assertThat(cuenta.movimientos()).isEmpty();
    }
}
