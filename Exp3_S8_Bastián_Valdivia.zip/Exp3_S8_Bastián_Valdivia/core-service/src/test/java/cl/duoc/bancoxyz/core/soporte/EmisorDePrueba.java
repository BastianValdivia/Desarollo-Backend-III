package cl.duoc.bancoxyz.core.soporte;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import org.springframework.security.oauth2.jose.jws.SignatureAlgorithm;
import org.springframework.security.oauth2.jwt.JwsHeader;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.security.oauth2.jwt.NimbusJwtEncoder;
import org.springframework.test.context.DynamicPropertyRegistry;

import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.sun.net.httpserver.HttpServer;

/**
 * Hace de auth-server en las pruebas del core: publica un JWKS por HTTP y firma tokens con la clave
 * correspondiente.
 *
 * <p>Es lo bastante real como para que el core ejerza TODO su camino de validacion: descarga las claves
 * de {@code jwk-set-uri} por la red (con el servidor HTTP del JDK), verifica la firma RSA, y compara
 * emisor, vigencia y audiencia con los validadores de Spring Security. Lo unico que no cubre es TLS, que
 * se comprueba al levantar los contenedores.
 *
 * <p>Los tokens se construyen con un constructor fluido que parte de uno valido para el BFF pedido
 * ({@link #tokenDe}) y permite estropear una sola cosa a la vez ({@code vencido()},
 * {@code conAudiencia(...)}, {@code firmadoPorOtraClave()}...): asi cada prueba de la matriz cambia
 * exactamente una variable y el motivo del rechazo no es ambiguo.
 *
 * <p>Una unica instancia para toda la JVM de pruebas ({@link #compartido()}): los contextos de Spring que
 * se cachean entre clases comparten asi el mismo puerto y la misma clave.
 */
public final class EmisorDePrueba {

    /** El emisor que el core espera (el que fija el auth-server en contenedores). */
    public static final String EMISOR = "https://localhost:9000";

    /** Lo que declara el core en {@code audiences}. */
    public static final String AUDIENCIA_DEL_CORE = "core-service";

    private static EmisorDePrueba instancia;

    private final RSAKey claveDeFirma;
    private final HttpServer servidor;

    private EmisorDePrueba() {
        this.claveDeFirma = nuevaClave("clave-de-prueba");
        try {
            JWKSet publicas = new JWKSet(claveDeFirma.toPublicJWK());
            byte[] cuerpo = publicas.toString().getBytes(StandardCharsets.UTF_8);
            servidor = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
            servidor.createContext("/oauth2/jwks", intercambio -> {
                intercambio.getResponseHeaders().add("Content-Type", "application/json");
                intercambio.sendResponseHeaders(200, cuerpo.length);
                intercambio.getResponseBody().write(cuerpo);
                intercambio.close();
            });
            servidor.start();
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo iniciar el servidor de claves de prueba", e);
        }
    }

    /** La instancia unica de la JVM (se crea la primera vez que se pide). */
    public static synchronized EmisorDePrueba compartido() {
        if (instancia == null) {
            instancia = new EmisorDePrueba();
        }
        return instancia;
    }

    /** Fija en el contexto de Spring la direccion de las claves de este emisor y el emisor esperado. */
    public static void registrar(DynamicPropertyRegistry registro) {
        EmisorDePrueba emisor = compartido();
        registro.add("spring.security.oauth2.resourceserver.jwt.jwk-set-uri", emisor::urlDeClaves);
        registro.add("spring.security.oauth2.resourceserver.jwt.issuer-uri", () -> EMISOR);
    }

    public String urlDeClaves() {
        return "http://127.0.0.1:" + servidor.getAddress().getPort() + "/oauth2/jwks";
    }

    /** Un token valido para el cliente dado, con los scopes dados y la audiencia del core. */
    public TokenDePrueba tokenDe(String cliente, String... scopes) {
        return new TokenDePrueba(cliente, List.of(scopes));
    }

    private static RSAKey nuevaClave(String id) {
        try {
            KeyPairGenerator generador = KeyPairGenerator.getInstance("RSA");
            generador.initialize(2048);
            KeyPair par = generador.generateKeyPair();
            return new RSAKey.Builder((RSAPublicKey) par.getPublic())
                    .privateKey((RSAPrivateKey) par.getPrivate())
                    .keyID(id)
                    .build();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Un JWT en construccion: parte de uno valido y deja estropear una cosa a la vez. */
    public final class TokenDePrueba {

        private final String cliente;
        private final List<String> scopes;
        private List<String> audiencia = List.of(AUDIENCIA_DEL_CORE);
        private String emisor = EMISOR;
        private Instant emision = Instant.now().minusSeconds(5);
        private Instant vencimiento = Instant.now().plusSeconds(300);
        private RSAKey clave = claveDeFirma;

        private TokenDePrueba(String cliente, List<String> scopes) {
            this.cliente = cliente;
            this.scopes = scopes;
        }

        /** Vencido hace diez minutos, mas alla de la tolerancia de reloj de 60 s. */
        public TokenDePrueba vencido() {
            this.emision = Instant.now().minusSeconds(900);
            this.vencimiento = Instant.now().minusSeconds(600);
            return this;
        }

        public TokenDePrueba conAudiencia(String... audiencias) {
            this.audiencia = List.of(audiencias);
            return this;
        }

        public TokenDePrueba conEmisor(String emisor) {
            this.emisor = emisor;
            return this;
        }

        /** Firmado con una clave RSA distinta de la que publica el JWKS (y con el mismo kid). */
        public TokenDePrueba firmadoPorOtraClave() {
            this.clave = nuevaClave(claveDeFirma.getKeyID());
            return this;
        }

        /** El JWT compacto, listo para {@code Authorization: Bearer <valor>}. */
        public String emitir() {
            NimbusJwtEncoder codificador = new NimbusJwtEncoder(new ImmutableJWKSet<>(new JWKSet(clave)));
            JwtClaimsSet claims = JwtClaimsSet.builder()
                    .issuer(emisor)
                    .subject(cliente)
                    .audience(audiencia)
                    .issuedAt(emision)
                    .expiresAt(vencimiento)
                    .id(UUID.randomUUID().toString())
                    .claim("scope", scopes)
                    .claim("client_id", cliente)
                    .build();
            JwsHeader cabecera = JwsHeader.with(SignatureAlgorithm.RS256).keyId(clave.getKeyID()).build();
            return codificador.encode(JwtEncoderParameters.from(cabecera, claims)).getTokenValue();
        }
    }
}
