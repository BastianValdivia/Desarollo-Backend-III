package cl.duoc.bancoxyz.core.soporte;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.atomic.AtomicInteger;

import org.flywaydb.core.Flyway;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.testcontainers.containers.PostgreSQLContainer;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.core.migracion.V2__CargaInicialDataset;

/**
 * Un PostgreSQL 16 real, levantado con Testcontainers, compartido por todas las pruebas de la JVM.
 *
 * <p>Rol en las pruebas: las pruebas de los adaptadores JDBC (y las que arrancan la aplicacion
 * completa) hablan con el mismo motor que usa el sistema, no con una base en memoria que se comporte
 * parecido. El {@code UPDATE} condicional, el bloqueo de filas, {@code ON CONFLICT} y el bloqueo
 * consultivo de Flyway son comportamientos de PostgreSQL; un sustituto los probaria a medias.
 *
 * <p><strong>Un contenedor, muchas bases.</strong> Arrancar un contenedor tarda segundos; crear una
 * base dentro de el, milisegundos. Por eso el contenedor se levanta una sola vez por JVM y cada clase
 * de prueba pide su propia base ({@link #crearBase()}): comparten el motor pero no el estado, de
 * modo que una prueba que retira dinero no altera los saldos de otra.
 *
 * <p>La imagen es la misma que usa {@code docker-compose.yaml} ({@code postgres:16.15-alpine3.24}), para
 * que las pruebas y el sistema hablen con la misma version del motor. Necesita Docker en marcha.
 */
public final class PostgresDePrueba {

    private static final PostgreSQLContainer<?> CONTENEDOR = new PostgreSQLContainer<>("postgres:16.15-alpine3.24");

    private static final AtomicInteger CONTADOR_DE_BASES = new AtomicInteger();

    static {
        CONTENEDOR.start();
        // Ryuk (el recolector de Testcontainers) apaga el contenedor si la JVM muere de golpe. Esto
        // lo apaga ademas en la salida normal, tambien cuando Ryuk esta desactivado.
        Runtime.getRuntime().addShutdownHook(new Thread(CONTENEDOR::stop));
    }

    private PostgresDePrueba() {
    }

    /** Una base de datos recien creada dentro del contenedor. */
    public record Base(String url, String usuario, String clave) {

        /**
         * Un pool de conexiones nuevo contra esta base. Cada pool equivale a <strong>una replica del
         * core</strong>: dos pools sobre la misma base se comportan como dos procesos distintos, que
         * es lo que importa para comprobar que la exclusion la da la base y no la JVM.
         */
        public HikariDataSource nuevoPool(int maximoDeConexiones) {
            HikariConfig configuracion = new HikariConfig();
            configuracion.setJdbcUrl(url);
            configuracion.setUsername(usuario);
            configuracion.setPassword(clave);
            configuracion.setMaximumPoolSize(maximoDeConexiones);
            return new HikariDataSource(configuracion);
        }

        /** Aplica las migraciones del core (esquema V1 y carga inicial V2), como lo hace el arranque. */
        public void migrar() {
            Flyway.configure()
                    .dataSource(url, usuario, clave)
                    .locations("classpath:db/migration")
                    .javaMigrations(new V2__CargaInicialDataset())
                    .load()
                    .migrate();
        }
    }

    /** Crea una base vacia, sin esquema. */
    public static Base crearBase() {
        String nombre = "core_prueba_" + CONTADOR_DE_BASES.incrementAndGet();
        try (Connection conexion = DriverManager.getConnection(
                CONTENEDOR.getJdbcUrl(), CONTENEDOR.getUsername(), CONTENEDOR.getPassword());
             Statement sentencia = conexion.createStatement()) {
            sentencia.execute("CREATE DATABASE " + nombre);
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo crear la base de prueba " + nombre, e);
        }
        String url = CONTENEDOR.getJdbcUrl().replaceFirst("/[^/?]+(\\?|$)", "/" + nombre + "$1");
        return new Base(url, CONTENEDOR.getUsername(), CONTENEDOR.getPassword());
    }

    /** Crea una base y le aplica las migraciones: queda con las 50 cuentas cargadas. */
    public static Base crearBaseMigrada() {
        Base base = crearBase();
        base.migrar();
        return base;
    }

    /**
     * Para las pruebas que arrancan la aplicacion completa ({@code @SpringBootTest}): apunta su
     * {@code DataSource} a una base nueva y vacia, y es la propia aplicacion (Flyway, al arrancar)
     * la que la migra, como en produccion.
     *
     * <p>Se usa con {@code @ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)}.
     * Cada contexto de Spring distinto recibe su propia base.
     */
    public static class Inicializador implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext contexto) {
            Base base = crearBase();
            TestPropertyValues.of(
                    "spring.datasource.url=" + base.url(),
                    "spring.datasource.username=" + base.usuario(),
                    "spring.datasource.password=" + base.clave()).applyTo(contexto);
        }
    }
}
