package cl.duoc.bancoxyz.core.ingesta;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.MotivoDescarte;
import cl.duoc.bancoxyz.core.dominio.TipoCuenta;

/**
 * Pruebas de la regla de consolidacion.
 *
 * <p>La prueba que da nombre a esta clase es {@link #elDesempateDelSaldoEsNumericoYNoAlfabetico()}.
 * Vigila un fallo que <strong>no produce ningun error</strong>: si el desempate ordenara textos en
 * lugar de numeros, el sistema arrancaria igual de contento atribuyendole a la cuenta 101 cuatro
 * mil pesos que no le corresponden, y nadie se enteraria hasta que alguien comparara la cifra a
 * mano. Un bug que cambia el dinero del banco sin dejar rastro es exactamente el tipo de cosa que
 * una prueba automatica tiene que atrapar.
 */
class ReglaConsolidacionTest {

    private final ReglaConsolidacion regla = new ReglaConsolidacion();

    @Test
    @DisplayName("Con empate entre 8000 y 12000 gana 8000: el desempate compara numeros, no texto")
    void elDesempateDelSaldoEsNumericoYNoAlfabetico() {
        // Reproduce el empate real de la cuenta 101 del dataset: dos saldos con la misma cantidad
        // de votos. Como texto, "12000" es MENOR que "8000", porque el caracter '1' viene antes que
        // el '8'; como numeros, 8000 es menor. El resultado del sistema depende de cual de las dos
        // comparaciones se este haciendo, y no hay ningun error que lo delate.
        List<FilaInteres> filas = List.of(
                new FilaInteres("101", "Bob Johnson", "8000", "35", "hipoteca"),
                new FilaInteres("101", "Bob Johnson", "8000", "35", "hipoteca"),
                new FilaInteres("101", "Bob Johnson", "12000", "35", "hipoteca"),
                new FilaInteres("101", "Bob Johnson", "12000", "35", "hipoteca"));

        Optional<Cuenta> cuenta = regla.consolidar(101, filas, List.of(), new ContadorDescartes());

        assertThat(cuenta).isPresent();
        assertThat(cuenta.get().saldo())
                .as("con desempate lexicografico saldria 12000, que es el bug que esta prueba vigila")
                .isEqualByComparingTo(new BigDecimal("8000"));
    }

    @Test
    @DisplayName("La moda gana aunque no sea el primer valor que aparece en el archivo")
    void laModaNoDependeDelOrdenDeLasFilas() {
        // Si la regla fuera "la primera fila valida" en vez de "la moda", el resultado dependeria
        // del orden fisico del archivo: reordenarlo cambiaria el estado del banco, que es
        // indefendible ante cualquier pregunta.
        List<FilaInteres> filas = List.of(
                new FilaInteres("116", "Clark Kent", "5000", "30", "ahorro"),
                new FilaInteres("116", "Diana Prince", "12000", "30", "hipoteca"),
                new FilaInteres("116", "Diana Prince", "12000", "30", "hipoteca"),
                new FilaInteres("116", "Diana Prince", "12000", "30", "hipoteca"));

        Cuenta cuenta = regla.consolidar(116, filas, List.of(), new ContadorDescartes()).orElseThrow();

        assertThat(cuenta.titular()).isEqualTo("Diana Prince");
        assertThat(cuenta.saldo()).isEqualByComparingTo(new BigDecimal("12000"));
        assertThat(cuenta.tipo()).isEqualTo(TipoCuenta.HIPOTECA);
        assertThat(cuenta.edadTitular()).isEqualTo(30);
    }

    @Test
    @DisplayName("Los centinelas no votan y quedan contados en el reporte de calidad")
    void losValoresInvalidosNoVotanYSeCuentan() {
        // Si los centinelas votaran, en muchas cuentas el valor mas frecuente seria "-1", y el
        // sistema publicaria un tipo de cuenta inventado que nadie podria distinguir de uno real.
        List<FilaInteres> filas = List.of(
                new FilaInteres("114", "Unknown", "", "150", "-1"),
                new FilaInteres("114", "Unknown", "", "100", "unknown"),
                new FilaInteres("114", "Alice Brown", "10000", "25", "prestamo"));

        ContadorDescartes contador = new ContadorDescartes();
        Cuenta cuenta = regla.consolidar(114, filas, List.of(), contador).orElseThrow();

        assertThat(cuenta.titular()).isEqualTo("Alice Brown");
        assertThat(cuenta.tipo()).isEqualTo(TipoCuenta.PRESTAMO);
        assertThat(cuenta.edadTitular()).isEqualTo(25);

        assertThat(contador.cuantos(MotivoDescarte.SALDO_INVALIDO)).isEqualTo(2);
        assertThat(contador.cuantos(MotivoDescarte.TIPO_INVALIDO)).isEqualTo(2);
        assertThat(contador.cuantos(MotivoDescarte.EDAD_FUERA_DE_RANGO))
                .as("100 y 150 son centinelas, no edades de un titular bancario")
                .isEqualTo(2);
    }

    @Test
    @DisplayName("El titular conserva sus tildes y mayusculas: normalizar sirve para comparar, no para mostrar")
    void elTitularSePublicaComoVenia() {
        List<FilaInteres> filas = List.of(
                new FilaInteres("120", "Jose Perez", "7000", "40", "ahorro"),
                new FilaInteres("120", "Jose Perez", "7000", "40", "ahorro"));

        Cuenta cuenta = regla.consolidar(120, filas, List.of(), new ContadorDescartes()).orElseThrow();

        assertThat(cuenta.titular())
                .as("si saliera en minusculas, la normalizacion se estaria aplicando al dato de salida")
                .isEqualTo("Jose Perez");
    }

    @Test
    @DisplayName("Una cuenta sin ningun valor valido no se publica en vez de publicarse inventada")
    void sinNingunValorValidoNoHayCuenta() {
        List<FilaInteres> filas = List.of(new FilaInteres("999", "Unknown", "", "150", "-1"));

        Optional<Cuenta> cuenta = regla.consolidar(999, filas, List.of(), new ContadorDescartes());

        assertThat(cuenta)
                .as("es preferible no publicar la cuenta que publicarla con campos por defecto")
                .isEmpty();
    }
}
