package cl.duoc.bancoxyz.core.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaReutilizadaException;

/**
 * Pruebas del registro de idempotencia: la pieza que hace que un reintento del cajero sea seguro.
 */
class RegistroIdempotenciaEnMemoriaTest {

    private final RegistroIdempotenciaEnMemoria registro = new RegistroIdempotenciaEnMemoria();

    @Test
    @DisplayName("La misma clave dos veces ejecuta una sola vez y devuelve el mismo folio")
    void mismaClaveMismoFolioUnSoloDescuento() {
        AtomicInteger ejecuciones = new AtomicInteger();

        ResultadoRetiro primero = registro.ejecutarUnaSolaVez(116, "clave-001", new BigDecimal("3000"), () -> {
            ejecuciones.incrementAndGet();
            return new ResultadoRetiro("RET-20260911-000001", new BigDecimal("12000"),
                    new BigDecimal("3000"), new BigDecimal("9000"));
        });

        ResultadoRetiro segundo = registro.ejecutarUnaSolaVez(116, "clave-001", new BigDecimal("3000"), () -> {
            ejecuciones.incrementAndGet();
            return new ResultadoRetiro("RET-20260911-000002", new BigDecimal("9000"),
                    new BigDecimal("3000"), new BigDecimal("6000"));
        });

        assertThat(ejecuciones.get())
                .as("la segunda operacion NO debe llegar a ejecutarse: si se ejecuta, hubo dos descuentos")
                .isEqualTo(1);
        assertThat(segundo.folio()).isEqualTo(primero.folio());
        assertThat(segundo).isEqualTo(primero);
    }

    @Test
    @DisplayName("Claves distintas ejecutan operaciones distintas")
    void clavesDistintasNoSeInterfieren() {
        AtomicInteger ejecuciones = new AtomicInteger();

        registro.ejecutarUnaSolaVez(116, "clave-A", new BigDecimal("1000"), () -> comprobanteConFolio(ejecuciones, "RET-A"));
        registro.ejecutarUnaSolaVez(116, "clave-B", new BigDecimal("1000"), () -> comprobanteConFolio(ejecuciones, "RET-B"));

        assertThat(ejecuciones.get()).isEqualTo(2);
    }

    @Test
    @DisplayName("Un fracaso no se recuerda: la clave queda libre para reintentar")
    void elFracasoNoSeGuarda() {
        assertThatThrownBy(() -> registro.ejecutarUnaSolaVez(116, "clave-C", new BigDecimal("1000"), () -> {
            throw new IllegalStateException("saldo insuficiente simulado");
        })).isInstanceOf(IllegalStateException.class);

        // Recordar los fracasos convertiria un rechazo transitorio (saldo insuficiente hoy) en uno
        // permanente: el cliente depositaria, reintentaria con la misma clave y el banco le
        // devolveria el error guardado sin volver a mirar el saldo.
        AtomicInteger ejecuciones = new AtomicInteger();
        registro.ejecutarUnaSolaVez(116, "clave-C", new BigDecimal("1000"), () -> comprobanteConFolio(ejecuciones, "RET-C"));

        assertThat(ejecuciones.get()).isEqualTo(1);
    }

    @Test
    @DisplayName("La misma clave en OTRA cuenta es una operacion nueva: se ejecuta y no recibe el comprobante ajeno")
    void laClaveVaPorCuenta() {
        AtomicInteger ejecuciones = new AtomicInteger();

        registro.ejecutarUnaSolaVez(116, "clave-compartida", new BigDecimal("1000"),
                () -> comprobanteConFolio(ejecuciones, "RET-116"));
        ResultadoRetiro deOtra = registro.ejecutarUnaSolaVez(106, "clave-compartida", new BigDecimal("1000"),
                () -> comprobanteConFolio(ejecuciones, "RET-106"));

        assertThat(deOtra.folio()).isEqualTo("RET-106");
        assertThat(ejecuciones.get()).isEqualTo(2);
    }

    @Test
    @DisplayName("La misma clave en la misma cuenta con otro importe se rechaza y no ejecuta nada")
    void claveReutilizadaConOtroImporte() {
        AtomicInteger ejecuciones = new AtomicInteger();
        registro.ejecutarUnaSolaVez(116, "clave-D", new BigDecimal("1000"),
                () -> comprobanteConFolio(ejecuciones, "RET-D"));

        assertThatThrownBy(() -> registro.ejecutarUnaSolaVez(116, "clave-D", new BigDecimal("2000"),
                () -> comprobanteConFolio(ejecuciones, "RET-D2")))
                .isInstanceOf(ClaveIdempotenciaReutilizadaException.class);
        assertThat(ejecuciones.get()).isEqualTo(1);
    }

    private ResultadoRetiro comprobanteConFolio(AtomicInteger contador, String folio) {
        contador.incrementAndGet();
        return new ResultadoRetiro(folio, new BigDecimal("12000"), new BigDecimal("1000"),
                new BigDecimal("11000"));
    }
}
