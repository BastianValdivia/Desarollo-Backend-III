package cl.duoc.bancoxyz.core.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import cl.duoc.bancoxyz.core.soporte.EmisorDePrueba;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * Los errores de quien llama no deben salir como 500 del core.
 *
 * <p>La ruta del retiro declara {@code consumes = application/json}. Un {@code curl -d} sin la
 * cabecera de tipo manda el cuerpo como formulario y Spring lanza
 * {@code HttpMediaTypeNotSupportedException}. Sin un manejador propio la red de seguridad del
 * advice lo convertia en 500 "Error interno", que acusa al core de una averia que no existe. La
 * prueba pasa por la cadena de filtros real (con un token de servicio de verdad, validado contra un
 * JWKS) para comprobar el comportamiento que ve un cliente de verdad.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
class ManejadorErroresCoreTest {

    private static final String RETIRO = "/internal/v1/cuentas/116/retiros";

    /** Un token real del BFF del cajero (firmado y validado por el core como en produccion). */
    private static final String TOKEN_DEL_CAJERO = "Bearer " + EmisorDePrueba.compartido()
            .tokenDe("bff-atm", "saldo:leer", "retiros:ejecutar").emitir();

    @DynamicPropertySource
    static void claves(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;

    @Test
    @DisplayName("Un retiro con Content-Type de formulario responde 415 en problem+json, no 500")
    void retiroConFormularioEs415() throws Exception {
        mvc.perform(post(RETIRO)
                        .header("Authorization", TOKEN_DEL_CAJERO)
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .content("monto=1000"))
                .andExpect(status().isUnsupportedMediaType())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.status").value(415))
                .andExpect(jsonPath("$.motivo").value("peticion_invalida"));
    }

    @Test
    @DisplayName("Un retiro con JSON ilegible sigue respondiendo 400")
    void retiroConJsonIlegibleEs400() throws Exception {
        mvc.perform(post(RETIRO)
                        .header("Authorization", TOKEN_DEL_CAJERO)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{no es json"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.motivo").value("peticion_invalida"));
    }

    @Test
    @DisplayName("Una Idempotency-Key de 201 caracteres responde 400 con su motivo, no 500 de la base")
    void claveDeIdempotenciaDemasiadoLargaEs400() throws Exception {
        mvc.perform(post(RETIRO)
                        .header("Authorization", TOKEN_DEL_CAJERO)
                        .header("Idempotency-Key", "k".repeat(201))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"monto\":1000}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.motivo").value("clave_idempotencia_invalida"));
    }

    @Test
    @DisplayName("Una Idempotency-Key de exactamente 200 caracteres se acepta y el retiro se hace")
    void claveDeIdempotenciaDeLargoMaximoSeAcepta() throws Exception {
        mvc.perform(post(RETIRO)
                        .header("Authorization", TOKEN_DEL_CAJERO)
                        .header("Idempotency-Key", "k".repeat(200))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"monto\":1000}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.folio").exists());
    }

    @Test
    @DisplayName("Misma Idempotency-Key en dos cuentas: cada una retira lo suyo, sin ver el comprobante de la otra")
    void laMismaClaveEnDosCuentasNoFiltraElComprobante() throws Exception {
        String clave = "clave-compartida-entre-cuentas";

        String de116 = mvc.perform(post(RETIRO)
                        .header("Authorization", TOKEN_DEL_CAJERO)
                        .header("Idempotency-Key", clave)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"monto\":3000}"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();

        mvc.perform(post("/internal/v1/cuentas/106/retiros")
                        .header("Authorization", TOKEN_DEL_CAJERO)
                        .header("Idempotency-Key", clave)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"monto\":1000}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.montoRetirado").value(1000))
                .andExpect(jsonPath("$.saldoAnterior").value(org.hamcrest.Matchers.comparesEqualTo(5000.0)))
                .andExpect(jsonPath("$.folio").value(org.hamcrest.Matchers.not(
                        org.hamcrest.Matchers.equalTo(folioDe(de116)))));
    }

    @Test
    @DisplayName("Misma clave y misma cuenta con otro importe: 422 clave_idempotencia_reutilizada, sin descontar")
    void claveReutilizadaConOtroImporteEs422() throws Exception {
        String clave = "clave-con-importe-cambiado";
        mvc.perform(post(RETIRO)
                        .header("Authorization", TOKEN_DEL_CAJERO)
                        .header("Idempotency-Key", clave)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"monto\":1000}"))
                .andExpect(status().isOk());

        mvc.perform(post(RETIRO)
                        .header("Authorization", TOKEN_DEL_CAJERO)
                        .header("Idempotency-Key", clave)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"monto\":2000}"))
                .andExpect(status().isUnprocessableEntity())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("clave_idempotencia_reutilizada"));
    }

    private static String folioDe(String json) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"folio\":\"([^\"]+)\"").matcher(json);
        if (!m.find()) {
            throw new IllegalStateException("la respuesta no trae folio: " + json);
        }
        return m.group(1);
    }
}
