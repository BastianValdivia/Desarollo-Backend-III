package cl.duoc.bancoxyz.core.eventos;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.core.aplicacion.RetiroService;
import cl.duoc.bancoxyz.core.soporte.EmisorDePrueba;
import cl.duoc.bancoxyz.eventos.soporte.KafkaDePrueba;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;
import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.DatosRetiro;
import cl.duoc.bancoxyz.eventos.Topicos;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * La aplicacion COMPLETA (relay encendido, Resilience4j, productor real de config-repo) frente a un Kafka
 * que se cae y vuelve: el contenedor se CONGELA (docker pause), que es un broker inalcanzable de verdad.
 *
 * <p>Comprueba lo que promete el outbox:
 * <ol>
 *   <li>con Kafka sano el evento sale solo (nadie llama al relay a mano: lo mueve el planificador);</li>
 *   <li>con Kafka caido, los retiros SIGUEN funcionando y rapido, los eventos quedan pendientes y el
 *       circuito {@code kafka} se abre (el relay deja de insistir);</li>
 *   <li>al volver Kafka, el circuito se cierra y los eventos se entregan, sin perder ninguno y en orden (la
 *       entrega es al menos una vez: puede haber reenvios).</li>
 * </ol>
 *
 * <p>Tambien verifica que el productor efectivo tiene el caracter pedido ({@code acks=all}, idempotente,
 * lz4): la configuracion que llega de config-repo es la que Spring Boot aplica.
 */
@SpringBootTest
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class RelayConKafkaCaidoTest {

    @DynamicPropertySource
    static void propiedades(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
        registro.add("spring.kafka.bootstrap-servers", KafkaDePrueba::bootstrap);
        registro.add("eventos.relay.habilitado", () -> "true");
        registro.add("eventos.relay.intervalo", () -> "200ms");
        // Con Kafka caido, el circuito se vuelve a probar a los 2 s (en produccion, 10 s): la prueba dura menos.
        registro.add("resilience4j.circuitbreaker.instances.kafka.wait-duration-in-open-state", () -> "2s");
    }

    @AfterAll
    static void dejarKafkaSano() {
        KafkaDePrueba.reanudar();
    }

    @Autowired
    private RetiroService retiros;
    @Autowired
    private JdbcClient jdbc;
    @Autowired
    private CircuitBreakerRegistry circuitos;
    @Autowired
    private MeterRegistry metricas;
    @Autowired
    private ProducerFactory<?, ?> fabricaDeProductores;

    private long pendientes() {
        return jdbc.sql("SELECT count(*) FROM outbox WHERE publicado IS NULL").query(Long.class).single();
    }

    @Test
    @DisplayName("El core entrega los eventos solo; con Kafka caido los retiros siguen y el circuito se abre; al volver se entrega todo, sin perder ni desordenar")
    void kafkaSeCaeYVuelve() {
        // --- El productor efectivo tiene el caracter que pide config-repo --------------------------------
        Map<String, Object> config = fabricaDeProductores.getConfigurationProperties();
        assertThat(config.get("acks")).isEqualTo("all");
        assertThat(String.valueOf(config.get("enable.idempotence"))).isEqualTo("true");
        assertThat(config.get("compression.type")).isEqualTo("lz4");

        // --- 1. Kafka sano: el evento sale solo ----------------------------------------------------------
        retiros.retirar(116, new BigDecimal("1000"), null);
        Awaitility.await().atMost(30, TimeUnit.SECONDS).until(() -> pendientes() == 0);

        // --- 2. Kafka caido: los retiros siguen, rapido ---------------------------------------------------
        KafkaDePrueba.pausar();
        try {
            long inicio = System.nanoTime();
            retiros.retirar(116, new BigDecimal("1000"), null);
            retiros.retirar(116, new BigDecimal("1000"), null);
            retiros.retirar(116, new BigDecimal("1000"), null);
            Duration duracion = Duration.ofNanos(System.nanoTime() - inicio);
            assertThat(duracion).as("tres retiros con Kafka caido no esperan a Kafka").isLessThan(Duration.ofSeconds(3));

            CircuitBreaker circuito = circuitos.circuitBreaker("kafka");
            Awaitility.await().atMost(60, TimeUnit.SECONDS)
                    .until(() -> circuito.getState() == CircuitBreaker.State.OPEN
                            || circuito.getState() == CircuitBreaker.State.HALF_OPEN);
            assertThat(pendientes()).as("los 3 eventos esperan en el outbox").isEqualTo(3);
            assertThat(metricas.get("outbox.pendientes").gauge().value())
                    .as("la metrica outbox.pendientes lo refleja").isEqualTo(3.0);
        } finally {
            // --- 3. Kafka vuelve ----------------------------------------------------------------------------
            KafkaDePrueba.reanudar();
        }

        Awaitility.await().atMost(90, TimeUnit.SECONDS).until(() -> pendientes() == 0);
        Awaitility.await().atMost(30, TimeUnit.SECONDS)
                .until(() -> circuitos.circuitBreaker("kafka").getState() == CircuitBreaker.State.CLOSED);

        // Los 4 eventos de la cuenta 116 estan en Kafka y encadenados (orden por cuenta). La entrega es AL MENOS
        // UNA VEZ: un lote que el productor dio por vencido mientras el broker estaba congelado pudo llegar igual
        // cuando se descongelo, y el relay lo reenvia. Esos duplicados son legitimos (por eso los consumidores
        // son idempotentes por eventId); lo que no puede pasar es perder un evento ni invertir su orden.
        List<ConsumerRecord<String, String>> enKafka = KafkaDePrueba.leerHasta(Topicos.RETIROS,
                leidos -> leidos.stream().filter(r -> "116".equals(r.key()))
                        .map(r -> CodecEventos.leer(r.value()).datosComo(DatosRetiro.class).folio())
                        .distinct().count() >= 4, Duration.ofSeconds(30));
        Map<String, DatosRetiro> primeraAparicion = new LinkedHashMap<>();
        enKafka.stream().filter(r -> "116".equals(r.key()))
                .map(r -> CodecEventos.leer(r.value()).datosComo(DatosRetiro.class))
                .forEach(d -> primeraAparicion.putIfAbsent(d.folio(), d));
        List<DatosRetiro> deLaCuenta = List.copyOf(primeraAparicion.values());
        assertThat(deLaCuenta).as("los 4 retiros llegaron, ninguno se perdio").hasSize(4);
        for (int i = 1; i < deLaCuenta.size(); i++) {
            assertThat(deLaCuenta.get(i).saldoAnterior())
                    .as("la primera aparicion de cada evento respeta el orden de la cuenta")
                    .isEqualByComparingTo(deLaCuenta.get(i - 1).saldoPosterior());
        }
        long total = enKafka.stream().filter(r -> "116".equals(r.key())).count();
        System.out.println("Registros de la cuenta 116 en Kafka: " + total + " (4 eventos distintos; los demas son "
                + "reenvios de la entrega al menos una vez)");
    }
}
