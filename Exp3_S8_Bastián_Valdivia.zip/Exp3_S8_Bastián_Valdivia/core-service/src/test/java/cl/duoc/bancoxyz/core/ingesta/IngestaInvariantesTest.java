package cl.duoc.bancoxyz.core.ingesta;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.Movimiento;
import cl.duoc.bancoxyz.core.dominio.ReporteCalidad;
import cl.duoc.bancoxyz.core.dominio.TipoCuenta;
import cl.duoc.bancoxyz.core.puerto.CuentaRepository;
import cl.duoc.bancoxyz.core.puerto.ReporteCalidadRepository;
import cl.duoc.bancoxyz.core.soporte.PostgresDePrueba;

/**
 * Verifica sobre el <strong>dataset real</strong> los invariantes que la ingesta tiene que
 * reproducir en cada arranque.
 *
 * <p>Rol de esta clase: es la prueba de humo del proyecto. Las demas pruebas verifican piezas
 * aisladas con datos inventados; esta levanta la aplicacion completa, deja que lea los tres CSV de
 * verdad y comprueba las cifras medidas. Si alguna no cuadra, hay un error en la ingesta y este es
 * el primer sitio donde mirar.
 *
 * <p>Los numeros no son aspiraciones: estan medidos sobre {@code data/semana_3} y son
 * reproducibles. Escribirlos como aserciones es lo que impide que una "mejora" posterior de la
 * ingesta cambie el estado del banco sin que nadie se entere.
 */
@SpringBootTest
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
class IngestaInvariantesTest {

    @Autowired
    private CuentaRepository cuentaRepository;

    @Autowired
    private ReporteCalidadRepository reporteCalidad;

    @Test
    @DisplayName("Quedan exactamente 50 cuentas, de la 101 a la 150, y ninguna con campos vacios")
    void cincuentaCuentasSinCamposNulos() {
        List<Cuenta> cuentas = List.copyOf(cuentaRepository.listarTodas());

        assertThat(cuentas).hasSize(50);
        assertThat(cuentas).allSatisfy(cuenta -> {
            assertThat(cuenta.id()).isBetween(101, 150);
            assertThat(cuenta.titular()).isNotBlank();
            assertThat(cuenta.saldo()).isNotNull().isGreaterThan(BigDecimal.ZERO);
            assertThat(cuenta.tipo()).isNotNull();
            assertThat(cuenta.edadTitular()).isBetween(18, 99);
            assertThat(cuenta.movimientos())
                    .as("la coleccion vacia es un resultado; el nulo obliga a cada cliente a defenderse")
                    .isNotNull();
        });
    }

    @Test
    @DisplayName("Todos los saldos caen dentro del conjunto medido {5000, 7000, 8000, 10000, 12000}")
    void losSaldosEstanEnElConjuntoConocido() {
        Set<String> esperados = Set.of("5000", "7000", "8000", "10000", "12000");

        assertThat(cuentaRepository.listarTodas())
                .allSatisfy(cuenta -> assertThat(cuenta.saldo().stripTrailingZeros().toPlainString())
                        .isIn(esperados));
    }

    @Test
    @DisplayName("El saldo de la cuenta 101 es 8000: el desempate se hizo con numeros")
    void laCuenta101PruebaElDesempateNumerico() {
        Cuenta cuenta = cuentaRepository.buscarPorId(101).orElseThrow();

        assertThat(cuenta.saldo())
                .as("si aqui saliera 12000, el comparador estaria ordenando cadenas de texto")
                .isEqualByComparingTo(new BigDecimal("8000"));
    }

    @Test
    @DisplayName("Las cuentas de control coinciden con los valores medidos a mano sobre el dataset")
    void lasCuentasDeControlCuadran() {
        verificar(116, "Diana Prince", "12000", TipoCuenta.HIPOTECA, 30, 42);
        verificar(106, "Diana Prince", "5000", TipoCuenta.AHORRO, 35, 43);
        verificar(105, "Alice Brown", "10000", TipoCuenta.PRESTAMO, 25, 39);
        verificar(101, "Bob Johnson", "8000", TipoCuenta.HIPOTECA, 35, 29);
        verificar(150, "Bob Johnson", "8000", TipoCuenta.HIPOTECA, 40, 0);

        // Caso borde deliberado: 30 de las 50 cuentas no aparecen en cuentas_anuales.csv y por
        // tanto no tienen ni un movimiento. La 130 es la que se usa para demostrar que la API
        // responde bien sin historial.
        verificar(130, "John Doe", "5000", TipoCuenta.PRESTAMO, 25, 0);
    }

    @Test
    @DisplayName("Se cargaron 686 movimientos validos y las 1000 transacciones sin conciliar")
    void elReporteDeCalidadCuadraConLoMedido() {
        ReporteCalidad reporte = reporteCalidad.obtener();

        assertThat(reporte.cuentasConsolidadas()).isEqualTo(50);
        assertThat(reporte.movimientosCargados()).isEqualTo(686);
        assertThat(reporte.transaccionesNoConciliadas()).isEqualTo(1000);

        // Las cinco claves congeladas estan siempre, aunque alguna valga cero: un motivo ausente
        // seria ambiguo entre "no ocurrio" y "no se midio".
        assertThat(reporte.descartesPorMotivo()).hasSize(5);

        ReporteCalidad.ArchivoLeido intereses = reporte.archivos().stream()
                .filter(a -> a.archivo().endsWith("intereses.csv"))
                .findFirst().orElseThrow();

        assertThat(intereses.filasLeidas()).isEqualTo(1000);
        assertThat(intereses.filasUnicas()).isEqualTo(991);
        assertThat(intereses.duplicadasDescartadas())
                .as("los 9 duplicados exactos se eliminan ANTES de votar, o pueden dar vuelta un empate")
                .isEqualTo(9);
    }

    @Test
    @DisplayName("El historial viene del mas reciente al mas antiguo, con un orden total y estable")
    void elHistorialVieneOrdenadoDelMasRecienteAlMasAntiguo() {
        List<Movimiento> movimientos = cuentaRepository.buscarPorId(116).orElseThrow().movimientos();

        for (int i = 1; i < movimientos.size(); i++) {
            Movimiento anterior = movimientos.get(i - 1);
            Movimiento actual = movimientos.get(i);

            assertThat(anterior.fecha()).isAfterOrEqualTo(actual.fecha());
            if (anterior.fecha().isEqual(actual.fecha())) {
                // El desempate por id garantiza un orden TOTAL. Sin el, una paginacion podria
                // repetir u omitir elementos al pasar de pagina, y el sintoma aparece lejos de la
                // causa.
                assertThat(anterior.id()).isGreaterThan(actual.id());
            }
        }
    }

    @Test
    @DisplayName("Todos los montos son positivos: el signo vive en el tipo, no en el numero")
    void ningunMontoEsNegativo() {
        assertThat(cuentaRepository.listarTodas())
                .allSatisfy(cuenta -> assertThat(cuenta.movimientos())
                        .allSatisfy(m -> assertThat(m.monto()).isGreaterThan(BigDecimal.ZERO)));
    }

    private void verificar(int id, String titular, String saldo, TipoCuenta tipo, int edad, int movimientos) {
        Cuenta cuenta = cuentaRepository.buscarPorId(id).orElseThrow();

        assertThat(cuenta.titular()).as("titular de la cuenta %d", id).isEqualTo(titular);
        assertThat(cuenta.saldo()).as("saldo de la cuenta %d", id).isEqualByComparingTo(new BigDecimal(saldo));
        assertThat(cuenta.tipo()).as("tipo de la cuenta %d", id).isEqualTo(tipo);
        assertThat(cuenta.edadTitular()).as("edad de la cuenta %d", id).isEqualTo(edad);
        assertThat(cuenta.movimientos()).as("movimientos de la cuenta %d", id).hasSize(movimientos);
    }
}
