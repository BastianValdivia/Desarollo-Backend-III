package cl.duoc.bancoxyz.core.ingesta;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.Movimiento;
import cl.duoc.bancoxyz.core.dominio.MotivoDescarte;
import cl.duoc.bancoxyz.core.dominio.TipoCuenta;

/**
 * Convierte las muchas filas contradictorias de un mismo {@code cuenta_id} en <strong>una sola
 * cuenta canonica</strong>.
 *
 * <h2>El problema</h2>
 *
 * <p>El archivo {@code intereses.csv} no tiene una fila por cuenta: tiene hasta veinte filas para
 * la misma cuenta, y se contradicen entre si. La cuenta 101 aparece con cinco titulares distintos,
 * con los saldos 5000, 7000, 8000, 10000 y 12000, y con edades que incluyen los centinelas 100 y
 * 150. No hay una fila "buena" marcada de alguna manera: son todas iguales de creibles.
 *
 * <h2>El hecho incomodo que hay que aceptar antes de programar nada</h2>
 *
 * <p>Los datos de este corte del dataset son <strong>ruido, no corrupcion recuperable</strong>, y
 * eso esta medido, no supuesto: existe un corte anterior del mismo dataset, limpio, con un unico
 * titular por cuenta, donde la cuenta 101 es John Doe con saldo 5000. La moda de este corte da Bob
 * Johnson con saldo 8000. <strong>El ruido no preserva la verdad original.</strong>
 *
 * <p>La consecuencia de ingenieria es liberadora: <em>no existe un titular verdadero ni un saldo
 * verdadero que recuperar</em>. Cualquier regla de consolidacion es una convencion, y lo unico que
 * se le puede exigir con propiedad es que sea <strong>determinista, documentada y
 * reproducible</strong>. Prometer que "recupera el dato real" seria mentir.
 *
 * <h2>La regla adoptada: moda por campo, con desempate declarado</h2>
 *
 * <table border="1">
 *   <caption>Un voto por fila valida, campo a campo</caption>
 *   <tr><th>Paso</th><th>Que hace</th><th>Desempate</th></tr>
 *   <tr><td>0</td><td>Deduplicar filas exactas (son 9 de 1000)</td><td>previo a votar</td></tr>
 *   <tr><td>1</td><td>Titular mas frecuente, ignorando {@code Unknown}</td><td>alfabetico ascendente</td></tr>
 *   <tr><td>2</td><td>Saldo mas frecuente entre los positivos</td><td><strong>el menor NUMERICO</strong></td></tr>
 *   <tr><td>3</td><td>Tipo mas frecuente dentro de los tres reales</td><td>alfabetico</td></tr>
 *   <tr><td>4</td><td>Edad mas frecuente dentro de [18, 99]</td><td>la menor</td></tr>
 * </table>
 *
 * <p><strong>Por que el paso 0 tiene que ocurrir primero.</strong> Una fila exactamente duplicada
 * mete dos votos identicos por el mismo valor. Con nueve duplicados repartidos, eso basta para dar
 * vuelta un empate y cambiar el saldo de una cuenta sin que nadie lo note. Deduplicar antes de
 * votar es lo que hace que la regla sea reproducible.
 *
 * <p><strong>Por que los valores invalidos no votan.</strong> Un {@code -1} en la columna de tipo
 * no es "un tipo raro": es la ausencia de dato. Si votara, el valor mas frecuente de muchas
 * cuentas seria {@code -1}. Se excluyen del recuento y se cuentan aparte en el reporte de calidad.
 *
 * <h2>LA TRAMPA. El desempate del saldo tiene que ser numerico</h2>
 *
 * <p>Es un fallo silencioso que cambia el dinero del banco sin producir ningun error, y por eso
 * este parrafo esta escrito con tanto detalle.
 *
 * <p>Los saldos llegan del archivo como <em>texto</em>. La forma comoda de desempatar es ordenar
 * esos textos y quedarse con el primero. Medido sobre el dataset: la cuenta 101 tiene un empate
 * perfecto entre {@code "8000"} y {@code "12000"}, cinco votos cada uno. Ordenados como texto, se
 * comparan caracter a caracter: el primer caracter de {@code "12000"} es {@code '1'} y el de
 * {@code "8000"} es {@code '8'}, y como {@code '1'} viene antes que {@code '8'}, gana
 * <strong>12000</strong>. Ordenados como numeros, gana <strong>8000</strong>.
 *
 * <p>Nada falla. No hay excepcion, no hay advertencia, y el sistema arranca igual de contento
 * atribuyendole a esa cuenta 4.000 pesos que no le corresponden. <strong>El saldo congelado de la
 * cuenta 101 es 8.000; si la API devuelve 12.000, el comparador esta ordenando cadenas.</strong>
 *
 * <p>La defensa esta en la firma del metodo {@link #moda}: obliga a entregar un
 * {@link Comparator} sobre el tipo ya convertido. Para desempatar saldos hay que pasarle un
 * comparador de {@link BigDecimal}, y para eso hay que haber convertido antes. El error no se
 * evita con disciplina, se evita porque el tipo no deja escribirlo.
 *
 * <p><strong>Por que el desempate es "el menor" y no "el mayor".</strong> Es un criterio
 * conservador y hay que poder defenderlo: ante dos saldos igual de creibles, el banco se atribuye
 * el menor, porque no debe declarar tener mas dinero del que puede justificar. Un error hacia
 * abajo es una molestia; hacia arriba es un descuadre contable.
 */
public class ReglaConsolidacion {

    /** Literal del archivo que significa "no se sabe quien es el titular". */
    private static final String TITULAR_DESCONOCIDO_NORMALIZADO = "unknown";

    /** Edad minima admisible. Por debajo, el dato es ruido o un centinela. */
    private static final int EDAD_MINIMA = 18;

    /**
     * Edad maxima admisible.
     *
     * <p>Deja fuera los centinelas 100 y 150 del archivo, que no son edades sino marcadores. Una
     * persona de 105 anos existe; un titular bancario de 150 no, y que el archivo use justamente
     * esos dos numeros redondos delata que son marcadores y no observaciones.
     */
    private static final int EDAD_MAXIMA = 99;

    /**
     * Consolida todas las filas de una misma cuenta en la cuenta canonica.
     *
     * @param cuentaId    identificador de la cuenta que se esta consolidando
     * @param filas       filas <strong>ya deduplicadas</strong> que corresponden a esa cuenta
     * @param movimientos historial ya cargado y validado desde {@code cuentas_anuales.csv}; llega
     *                    vacio para las 30 cuentas del rango 121 a 150, que no tienen ninguno
     * @param contador    cuaderno donde se anotan los valores que no pudieron votar
     * @return la cuenta canonica, o vacio si ningun campo obligatorio logro reunir un solo voto
     *         valido. Sobre este dataset eso no ocurre nunca (el invariante medido es "50 cuentas,
     *         cero campos nulos"), pero la firma no lo da por hecho: si algun dia ocurriera, es
     *         preferible no publicar la cuenta que publicarla con campos inventados
     */
    public Optional<Cuenta> consolidar(int cuentaId, List<FilaInteres> filas,
                                       List<Movimiento> movimientos, ContadorDescartes contador) {

        Optional<String> titular = moda(
                valoresValidos(filas, FilaInteres::nombre, this::titularValido, contador, null),
                Comparator.naturalOrder());

        Optional<BigDecimal> saldo = moda(
                valoresValidos(filas, FilaInteres::saldo, this::saldoValido, contador,
                        MotivoDescarte.SALDO_INVALIDO),
                // AQUI esta la trampa neutralizada: el comparador es sobre BigDecimal, asi que la
                // comparacion es aritmetica y no alfabetica. BigDecimal.compareTo trata 8000 y
                // 8000.00 como iguales, que es lo correcto para dinero.
                Comparator.naturalOrder());

        Optional<TipoCuenta> tipo = moda(
                valoresValidos(filas, FilaInteres::tipo, TipoCuenta::parse, contador,
                        MotivoDescarte.TIPO_INVALIDO),
                // Los enumerados se comparan por su orden de declaracion, que aqui coincide con el
                // alfabetico (AHORRO, HIPOTECA, PRESTAMO). Se deja explicito para que quien agregue
                // un cuarto producto sepa que el orden de declaracion tiene consecuencias.
                Comparator.comparing(TipoCuenta::name));

        Optional<Integer> edad = moda(
                valoresValidos(filas, FilaInteres::edad, this::edadValida, contador,
                        MotivoDescarte.EDAD_FUERA_DE_RANGO),
                Comparator.naturalOrder());

        if (titular.isEmpty() || saldo.isEmpty() || tipo.isEmpty() || edad.isEmpty()) {
            return Optional.empty();
        }

        return Optional.of(new Cuenta(cuentaId, titular.get(), saldo.get(), edad.get(), tipo.get(), movimientos));
    }

    /**
     * Aplica un interprete a una columna de todas las filas y devuelve solo los valores que
     * resultaron validos, anotando los demas en el contador.
     *
     * <p>Estar en un metodo aparte es lo que garantiza que <strong>validar y contar sean el mismo
     * acto</strong>. Si fueran dos pasos, tarde o temprano un campo se validaria sin contarse y el
     * reporte de calidad diria que se descarto menos de lo que realmente se descarto, que es peor
     * que no tener reporte.
     *
     * @param motivo motivo a anotar, o {@code null} cuando la columna no tiene un motivo propio en
     *               el contrato (es el caso del titular: el contrato congela cinco motivos y
     *               ninguno corresponde a un nombre ausente)
     */
    private <T> List<T> valoresValidos(List<FilaInteres> filas,
                                       java.util.function.Function<FilaInteres, String> columna,
                                       java.util.function.Function<String, Optional<T>> interprete,
                                       ContadorDescartes contador,
                                       MotivoDescarte motivo) {

        List<T> validos = new java.util.ArrayList<>();
        for (FilaInteres fila : filas) {
            Optional<T> interpretado = interprete.apply(columna.apply(fila));
            if (interpretado.isPresent()) {
                validos.add(interpretado.get());
            } else if (motivo != null) {
                contador.anotar(motivo);
            }
        }
        return validos;
    }

    /**
     * Calcula la moda: el valor que mas veces aparece.
     *
     * <p><strong>Como se cuenta sin perder el determinismo.</strong> El recuento usa un
     * {@link LinkedHashMap}, que conserva el orden en que los valores aparecieron por primera vez.
     * Con un {@code HashMap} corriente el orden de iteracion depende de los codigos hash y puede
     * cambiar entre versiones de Java; ante un empate que el comparador no resolviera, el resultado
     * podria variar entre maquinas. Aqui el comparador siempre resuelve, pero el mapa ordenado
     * elimina la duda de raiz y no cuesta nada.
     *
     * <p><strong>El desempate no es opcional.</strong> El comparador es un parametro obligatorio y
     * no un valor por defecto escondido: quien llame a este metodo tiene que declarar, en la linea
     * de la llamada, como se rompe un empate. Es exactamente la decision que en la cuenta 101
     * determina si el banco cree tener 8.000 o 12.000, y por eso tiene que estar a la vista.
     *
     * @param valores      valores validos que votan; puede venir vacia
     * @param desempatador orden a aplicar entre los valores empatados en primer lugar; gana el
     *                     <strong>menor</strong> segun este orden
     * @return el valor ganador, o vacio si nadie voto
     */
    private <T> Optional<T> moda(List<T> valores, Comparator<T> desempatador) {
        if (valores.isEmpty()) {
            return Optional.empty();
        }

        Map<T, Integer> votos = new LinkedHashMap<>();
        for (T valor : valores) {
            votos.merge(valor, 1, Integer::sum);
        }

        int maximo = votos.values().stream().max(Integer::compare).orElseThrow();

        return votos.entrySet().stream()
                .filter(entrada -> entrada.getValue() == maximo)
                .map(Map.Entry::getKey)
                .min(desempatador);
    }

    /**
     * Un titular vale si no esta vacio y no es el literal {@code Unknown}.
     *
     * <p>Se compara sobre la forma normalizada (sin tildes, en minusculas) pero se
     * <strong>devuelve el texto original</strong>. Esa asimetria es deliberada: normalizar sirve
     * para decidir si dos valores son el mismo, no para decidir como se escribe el nombre que vera
     * el cliente. Si se devolviera la forma normalizada, la API mostraria "diana prince".
     */
    private Optional<String> titularValido(String valorCrudo) {
        String normalizado = NormalizadorTexto.normalizar(valorCrudo);
        if (NormalizadorTexto.esDesconocido(normalizado)
                || TITULAR_DESCONOCIDO_NORMALIZADO.equals(normalizado)) {
            return Optional.empty();
        }
        return Optional.ofNullable(NormalizadorTexto.limpiarParaMostrar(valorCrudo));
    }

    /**
     * Un saldo vale si es un numero mayor que cero.
     *
     * <p>Se construye con {@code new BigDecimal(String)} y jamas desde un {@code double}: pasar por
     * {@code double} introduciria el error de representacion binaria justo en el unico punto donde
     * el texto se convierte en dinero, que es el peor lugar posible para introducirlo.
     *
     * <p>Un saldo negativo o en cero se trata como invalido y no como dato. Un banco puede tener
     * cuentas en cero, desde luego; pero en <em>este</em> dataset esos valores conviven con celdas
     * vacias y centinelas, y el invariante verificado es que los saldos consolidados estan siempre
     * en el conjunto {5000, 7000, 8000, 10000, 12000}. Admitir el cero como voto valido romperia
     * ese invariante sin aportar ninguna informacion.
     */
    private Optional<BigDecimal> saldoValido(String valorCrudo) {
        String texto = valorCrudo == null ? "" : valorCrudo.trim();
        if (texto.isEmpty()) {
            return Optional.empty();
        }
        try {
            BigDecimal valor = new BigDecimal(texto);
            return valor.compareTo(BigDecimal.ZERO) > 0 ? Optional.of(valor) : Optional.empty();
        } catch (NumberFormatException noEsNumero) {
            return Optional.empty();
        }
    }

    /** Una edad vale si es un entero dentro del rango humano plausible para un titular bancario. */
    private Optional<Integer> edadValida(String valorCrudo) {
        String texto = valorCrudo == null ? "" : valorCrudo.trim();
        if (texto.isEmpty()) {
            return Optional.empty();
        }
        try {
            int valor = Integer.parseInt(texto);
            return (valor >= EDAD_MINIMA && valor <= EDAD_MAXIMA) ? Optional.of(valor) : Optional.empty();
        } catch (NumberFormatException noEsNumero) {
            return Optional.empty();
        }
    }
}
