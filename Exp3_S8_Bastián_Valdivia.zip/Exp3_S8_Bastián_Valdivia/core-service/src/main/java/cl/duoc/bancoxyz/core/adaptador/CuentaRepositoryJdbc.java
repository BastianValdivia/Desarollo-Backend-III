package cl.duoc.bancoxyz.core.adaptador;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.Movimiento;
import cl.duoc.bancoxyz.core.dominio.OrigenDato;
import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.TipoCuenta;
import cl.duoc.bancoxyz.core.dominio.TipoMovimiento;
import cl.duoc.bancoxyz.core.dominio.error.CuentaNoEncontradaException;
import cl.duoc.bancoxyz.core.dominio.error.MontoInvalidoException;
import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;
import cl.duoc.bancoxyz.core.puerto.CuentaRepository;

/**
 * <strong>Adaptador</strong> de {@link CuentaRepository} sobre PostgreSQL, con JDBC.
 *
 * <p>Rol en la arquitectura: reemplaza a la version en memoria del S5. El puerto, el dominio y los
 * servicios de aplicacion no cambian; esta clase es la unica que sabe que el estado vive en una base
 * de datos y que los tres BFF, y ahora tambien las dos replicas del core, comparten ese estado.
 *
 * <h2>Por que {@link #debitar} no necesita bloqueos escritos a mano</h2>
 *
 * <p>El S5 hacia atomico el retiro con {@code ConcurrentHashMap.compute}, que bloquea una clave
 * dentro de <em>un</em> proceso. Con dos replicas del core ese mecanismo deja de servir: cada proceso
 * tiene su propio mapa y nadie los coordina. La exclusion tiene que vivir donde esta el dato, y aqui
 * es una sola sentencia:
 *
 * <pre>
 * UPDATE cuenta SET saldo = saldo - :monto WHERE id = :id AND saldo &gt;= :monto
 * </pre>
 *
 * <p>La condicion {@code saldo >= monto} se evalua <em>dentro</em> de la misma sentencia que hace el
 * descuento, sobre la fila que PostgreSQL tiene bloqueada para escribirla. Dos retiros simultaneos
 * sobre la misma cuenta se ordenan solos: el segundo espera a que el primero confirme, vuelve a
 * evaluar la condicion con el saldo que dejo el primero y, si ya no alcanza, no actualiza ninguna
 * fila. No hay ventana entre "leer" y "escribir" porque son una sola operacion. Es la version SQL
 * de lo que en el S5 era {@code compute}, y la comprueban las pruebas con Testcontainers incluso
 * entre dos conexiones distintas (que es lo que son dos replicas).
 *
 * <p>Tres detalles que no son evidentes:
 *
 * <ul>
 *   <li><strong>El saldo anterior se deduce, no se lee.</strong> {@code UPDATE ... RETURNING saldo}
 *       devuelve el saldo ya descontado; el anterior es ese mas el monto. Leerlo antes con un
 *       {@code SELECT} reabriria la ventana que se acaba de cerrar.</li>
 *   <li><strong>El descuento y el apunte del movimiento van en la misma transaccion.</strong> Si el
 *       {@code INSERT} fallara, el descuento se deshace: no puede quedar un saldo que baja sin
 *       historial. La unidad es "ambas cosas o ninguna".</li>
 *   <li><strong>La transaccion se une a la que ya este abierta</strong> (propagacion
 *       {@code REQUIRED}). El registro de idempotencia abre una y llama a esta operacion dentro de
 *       ella, de modo que reservar la clave, descontar y registrar el movimiento forman una sola
 *       transaccion.</li>
 * </ul>
 *
 * <p>Ademas, la restriccion {@code CHECK (saldo >= 0)} del esquema es la ultima linea de defensa: si
 * algun dia alguien escribiera un {@code UPDATE} sin la condicion, la base rechazaria el saldo
 * negativo en lugar de aceptarlo en silencio.
 */
@Repository
public class CuentaRepositoryJdbc implements CuentaRepository {

    /**
     * Texto del apunte que genera un retiro. Es el mismo literal que usa {@code Cuenta.conRetiro} en
     * el dominio; una prueba comprueba que ambos coinciden, para que no se separen sin que nadie lo
     * note.
     */
    static final String DESCRIPCION_RETIRO_ATM = "Retiro por cajero automatico";

    private final JdbcClient jdbc;
    private final TransactionTemplate escritura;
    private final TransactionTemplate lectura;

    public CuentaRepositoryJdbc(JdbcClient jdbc, PlatformTransactionManager gestorTransacciones) {
        this.jdbc = jdbc;
        this.escritura = new TransactionTemplate(gestorTransacciones);
        // Lectura de una cuenta = dos consultas (la cuenta y sus movimientos). REPEATABLE READ les da
        // la misma foto de la base: sin eso, un retiro confirmado entre las dos produciria una
        // cuenta cuyo saldo no coincide con su historial.
        this.lectura = new TransactionTemplate(gestorTransacciones);
        this.lectura.setReadOnly(true);
        this.lectura.setIsolationLevel(TransactionDefinition.ISOLATION_REPEATABLE_READ);
    }

    // ------------------------------------------------------------------------------------------
    // Lectura
    // ------------------------------------------------------------------------------------------

    @Override
    public Optional<Cuenta> buscarPorId(int cuentaId) {
        return lectura.execute(estado -> {
            List<FilaCuenta> cuentas = jdbc.sql("""
                            SELECT id, titular, saldo, edad_titular, tipo FROM cuenta WHERE id = :id""")
                    .param("id", cuentaId)
                    .query((rs, fila) -> FilaCuenta.de(rs))
                    .list();
            if (cuentas.isEmpty()) {
                return Optional.<Cuenta>empty();
            }
            List<Movimiento> movimientos = jdbc.sql("""
                            SELECT id, cuenta_id, fecha, tipo, monto, descripcion, origen
                              FROM movimiento WHERE cuenta_id = :id""")
                    .param("id", cuentaId)
                    .query((rs, fila) -> mapearMovimiento(rs))
                    .list();
            // El constructor de Cuenta ordena el historial en el orden canonico (fecha descendente,
            // id descendente): el orden no depende del que devuelva la base.
            return Optional.of(cuentas.get(0).aCuenta(movimientos));
        });
    }

    @Override
    public Collection<Cuenta> listarTodas() {
        return lectura.execute(estado -> {
            Map<Integer, List<Movimiento>> porCuenta = new HashMap<>();
            jdbc.sql("""
                            SELECT id, cuenta_id, fecha, tipo, monto, descripcion, origen FROM movimiento""")
                    .query((rs, fila) -> mapearMovimiento(rs))
                    .list()
                    .forEach(m -> porCuenta.computeIfAbsent(m.cuentaId(), id -> new ArrayList<>()).add(m));

            return jdbc.sql("SELECT id, titular, saldo, edad_titular, tipo FROM cuenta ORDER BY id")
                    .query((rs, fila) -> FilaCuenta.de(rs))
                    .list()
                    .stream()
                    .map(c -> c.aCuenta(porCuenta.getOrDefault(c.id(), List.of())))
                    .toList();
        });
    }

    // ------------------------------------------------------------------------------------------
    // Escritura
    // ------------------------------------------------------------------------------------------

    /**
     * {@inheritDoc}
     *
     * <p>Reemplaza de verdad: la cuenta queda con exactamente los movimientos recibidos (los demas
     * se borran), igual que {@code put} sobre el mapa del S5. Todo en una transaccion.
     */
    @Override
    public void guardar(Cuenta cuenta) {
        escritura.executeWithoutResult(estado -> {
            jdbc.sql("""
                            INSERT INTO cuenta (id, titular, saldo, edad_titular, tipo)
                            VALUES (:id, :titular, :saldo, :edad, :tipo)
                            ON CONFLICT (id) DO UPDATE
                               SET titular = EXCLUDED.titular, saldo = EXCLUDED.saldo,
                                   edad_titular = EXCLUDED.edad_titular, tipo = EXCLUDED.tipo""")
                    .param("id", cuenta.id())
                    .param("titular", cuenta.titular())
                    .param("saldo", cuenta.saldo())
                    .param("edad", cuenta.edadTitular())
                    .param("tipo", cuenta.tipo().name())
                    .update();

            List<Long> ids = cuenta.movimientos().stream().map(Movimiento::id).toList();
            if (ids.isEmpty()) {
                jdbc.sql("DELETE FROM movimiento WHERE cuenta_id = :id")
                        .param("id", cuenta.id()).update();
            } else {
                jdbc.sql("DELETE FROM movimiento WHERE cuenta_id = :id AND id NOT IN (:ids)")
                        .param("id", cuenta.id()).param("ids", ids).update();
            }

            for (Movimiento m : cuenta.movimientos()) {
                jdbc.sql("""
                                INSERT INTO movimiento (id, cuenta_id, fecha, tipo, monto, descripcion, origen)
                                VALUES (:id, :cuenta, :fecha, :tipo, :monto, :descripcion, :origen)
                                ON CONFLICT (id) DO UPDATE
                                   SET cuenta_id = EXCLUDED.cuenta_id, fecha = EXCLUDED.fecha,
                                       tipo = EXCLUDED.tipo, monto = EXCLUDED.monto,
                                       descripcion = EXCLUDED.descripcion, origen = EXCLUDED.origen""")
                        .param("id", m.id())
                        .param("cuenta", m.cuentaId())
                        .param("fecha", m.fecha())
                        .param("tipo", m.tipo().name())
                        .param("monto", m.monto())
                        .param("descripcion", m.descripcion())
                        .param("origen", m.origen().name())
                        .update();
            }
        });
    }

    @Override
    public ResultadoRetiro debitar(int cuentaId, BigDecimal monto, String folio, LocalDate fecha,
                                   long idMovimiento) {

        // El saldo y los movimientos viven con dos decimales. Se redondea ANTES de tocar la base para
        // que lo que se descuenta sea exactamente lo que queda apuntado (el dominio del S5 hace lo
        // mismo en el constructor de Cuenta y de Movimiento).
        BigDecimal importe = monto.setScale(2, RoundingMode.HALF_UP);
        if (importe.signum() <= 0) {
            // Un 0,001 pasa la validacion de "mayor que cero" y se redondea a 0,00; un movimiento de
            // cero violaria el CHECK de la tabla y seria un 500. Se rechaza como el monto invalido que es.
            throw new MontoInvalidoException(monto);
        }

        return escritura.execute(estado -> {
            // LA SENTENCIA QUE HACE ATOMICO EL RETIRO (ver el javadoc de la clase).
            Optional<BigDecimal> saldoPosterior = jdbc.sql("""
                            UPDATE cuenta SET saldo = saldo - :monto
                             WHERE id = :id AND saldo >= :monto
                         RETURNING saldo""")
                    .param("monto", importe)
                    .param("id", cuentaId)
                    .query(BigDecimal.class)
                    .optional();

            if (saldoPosterior.isEmpty()) {
                // Cero filas actualizadas: o la cuenta no existe o el saldo no alcanza. Se distingue
                // con una lectura, que aqui ya no es una ventana de carrera porque no se decide nada
                // con ella: solo se elige el mensaje del error. La excepcion deshace la transaccion
                // (no se habia modificado nada) y la clave de idempotencia reservada queda libre.
                BigDecimal saldoActual = jdbc.sql("SELECT saldo FROM cuenta WHERE id = :id")
                        .param("id", cuentaId)
                        .query(BigDecimal.class)
                        .optional()
                        .orElseThrow(() -> new CuentaNoEncontradaException(cuentaId));
                throw new SaldoInsuficienteException(cuentaId, saldoActual, importe);
            }

            jdbc.sql("""
                            INSERT INTO movimiento (id, cuenta_id, fecha, tipo, monto, descripcion, origen)
                            VALUES (:id, :cuenta, :fecha, :tipo, :monto, :descripcion, :origen)""")
                    .param("id", idMovimiento)
                    .param("cuenta", cuentaId)
                    .param("fecha", fecha)
                    .param("tipo", TipoMovimiento.RETIRO.name())
                    .param("monto", importe)
                    .param("descripcion", DESCRIPCION_RETIRO_ATM)
                    .param("origen", OrigenDato.RETIRO_ATM.name())
                    .update();

            return new ResultadoRetiro(folio, saldoPosterior.get().add(importe), importe, saldoPosterior.get());
        });
    }

    // ------------------------------------------------------------------------------------------
    // Mapeo de filas
    // ------------------------------------------------------------------------------------------

    /** Una fila de {@code cuenta}, antes de unirle su historial. */
    private record FilaCuenta(int id, String titular, BigDecimal saldo, int edad, TipoCuenta tipo) {

        static FilaCuenta de(ResultSet rs) throws SQLException {
            return new FilaCuenta(rs.getInt("id"), rs.getString("titular"), rs.getBigDecimal("saldo"),
                    rs.getInt("edad_titular"), TipoCuenta.valueOf(rs.getString("tipo")));
        }

        Cuenta aCuenta(List<Movimiento> movimientos) {
            return new Cuenta(id, titular, saldo, edad, tipo, movimientos);
        }
    }

    private static Movimiento mapearMovimiento(ResultSet rs) throws SQLException {
        return new Movimiento(
                rs.getLong("id"),
                rs.getInt("cuenta_id"),
                rs.getObject("fecha", LocalDate.class),
                TipoMovimiento.valueOf(rs.getString("tipo")),
                rs.getBigDecimal("monto"),
                rs.getString("descripcion"),
                OrigenDato.valueOf(rs.getString("origen")));
    }
}
