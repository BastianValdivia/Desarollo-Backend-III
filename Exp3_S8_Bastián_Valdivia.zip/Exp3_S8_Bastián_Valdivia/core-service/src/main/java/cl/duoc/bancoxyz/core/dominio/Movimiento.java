package cl.duoc.bancoxyz.core.dominio;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;

/**
 * Un apunte del historial de una cuenta: una fecha, una naturaleza y un importe.
 *
 * <p>Rol en la arquitectura: es la entidad que compone el historial dentro del agregado
 * {@link Cuenta}. No existe por si sola fuera de una cuenta y por eso no tiene su propio
 * repositorio: se llega a un movimiento pasando siempre por su cuenta.
 *
 * <p><strong>Por que es un {@code record} y no una clase con setters.</strong> Un movimiento ya
 * ocurrido no cambia: un banco no edita un apunte, emite otro que lo corrige. Hacerlo inmutable
 * convierte esa regla contable en una propiedad del lenguaje, y ademas es lo que permite que
 * varios hilos lean el historial de una cuenta a la vez sin ningun tipo de bloqueo.
 *
 * <p><strong>Por que {@code monto} es {@link BigDecimal} y no {@code double}.</strong> Un
 * {@code double} guarda los numeros en base 2, y la mayoria de los importes decimales no tienen
 * representacion exacta en base 2; los errores se acumulan al sumar. En un sistema que maneja
 * dinero eso es descalificatorio. La regla del proyecto, sin excepciones: todo importe se
 * construye desde {@code String} ({@code new BigDecimal("3000")}, jamas desde un {@code double})
 * y se compara con {@code compareTo} y nunca con {@code equals}, porque
 * {@code BigDecimal.equals} considera distintos a {@code 5000} y {@code 5000.00}.
 *
 * <p><strong>Por que {@code monto} es siempre positivo.</strong> El signo vive en
 * {@link TipoMovimiento#esCargo()}. Guardar montos negativos duplicaria la informacion del signo
 * en dos lugares que pueden contradecirse, y la contradiccion existe de verdad en el dataset: hay
 * 254 montos negativos cuya columna de tipo ya dice {@code deposito}. La ingesta los descarta en
 * lugar de aplicarles valor absoluto, porque un monto negativo con tipo abono es una
 * contradiccion, no un dato del que se pueda recuperar una verdad.
 *
 * @param id          identificador tecnico asignado por la ingesta. El CSV no trae ninguno, y sin
 *                    un identificador estable no habria forma de desempatar dos movimientos de la
 *                    misma fecha de manera reproducible entre dos arranques
 * @param cuentaId    cuenta a la que pertenece, entre 101 y 150
 * @param fecha       dia del movimiento, ya resuelto a un unico formato pese a que el archivo de
 *                    origen convive con cuatro
 * @param tipo        naturaleza del movimiento; es la unica fuente de verdad del signo
 * @param monto       importe, siempre positivo
 * @param descripcion texto decorativo del CSV. <strong>Admite nulo</strong> y puede contradecir al
 *                    tipo; cuando eso ocurre, manda el tipo
 * @param origen      si vino del CSV de semilla o lo genero un retiro del cajero
 */
public record Movimiento(
        long id,
        int cuentaId,
        LocalDate fecha,
        TipoMovimiento tipo,
        BigDecimal monto,
        String descripcion,
        OrigenDato origen) {

    /**
     * Constructor compacto: normaliza la escala del importe a dos decimales.
     *
     * <p>Un {@code record} permite interceptar sus propios argumentos antes de asignarlos, y este
     * es el unico camino por el que se crea un movimiento, venga del CSV o de un retiro del cajero.
     * Poner aqui la escala garantiza que los dos origenes produzcan la misma forma: sin esto, un
     * monto sembrado saldria como {@code 2500.00} y uno recien retirado como {@code 3000}, para el
     * mismo tipo de dato y en la misma lista.
     */
    public Movimiento {
        if (monto != null) {
            monto = monto.setScale(2, java.math.RoundingMode.HALF_UP);
        }
    }

    /**
     * Orden en que el core entrega siempre los movimientos: <strong>del mas reciente al mas
     * antiguo</strong>.
     *
     * <p>Esta constante es el unico lugar del proyecto donde se decide ese orden, y la decision
     * tiene tres consecuencias que conviene entender porque afectan a los tres canales:
     *
     * <ol>
     *   <li>Es la convencion de cualquier cartola bancaria: la primera pagina trae lo ultimo que
     *       paso, que es lo que el cliente abrio la aplicacion para ver.</li>
     *   <li>Hace que "los cinco ultimos movimientos" del canal movil sean literalmente los cinco
     *       primeros elementos de la lista. Si el orden fuera ascendente, cada canal tendria que
     *       recorrer la cola y darla vuelta, y bastaria que uno se equivocara para mostrar los
     *       cinco mas antiguos sin que nada fallara.</li>
     *   <li>Un retiro recien hecho por el cajero queda en la posicion cero, asi que el efecto de
     *       la operacion critica se ve de inmediato desde los otros dos canales.</li>
     * </ol>
     *
     * <p>El desempate por {@code id} descendente no es cosmetico: hay decenas de movimientos que
     * comparten fecha, y sin un segundo criterio estable el orden dependeria del algoritmo de
     * ordenamiento y podria cambiar entre ejecuciones. Una paginacion cuyo orden no es total
     * puede repetir u omitir elementos al pasar de pagina, y el sintoma aparece lejos de la causa.
     */
    public static final Comparator<Movimiento> ORDEN_CANONICO =
            Comparator.comparing(Movimiento::fecha).reversed()
                    .thenComparing(Comparator.comparingLong(Movimiento::id).reversed());
}
