package cl.duoc.bancoxyz.core.ingesta;

import java.text.Normalizer;
import java.util.Locale;
import java.util.Set;

/**
 * Limpia los valores de texto del CSV para que dos formas de escribir lo mismo se conviertan en la
 * misma cadena, y para que los valores que no significan nada se conviertan en una ausencia
 * explicita.
 *
 * <p>Rol en la arquitectura: es la primera pieza que toca el dato sucio. Todo valor que vaya a
 * compararse contra un enumerado pasa por aqui antes, sin excepcion, y por eso el tratamiento de
 * las tildes y de los centinelas es identico en toda la ingesta.
 *
 * <p><strong>Trampa 1: la misma palabra escrita de dos maneras.</strong> El archivo trae
 * {@code deposito} 296 veces sin tilde y 52 veces con tilde sobre la {@code o}. Para un
 * {@code equals} son dos palabras distintas, asi que 52 movimientos reales se perderian
 * silenciosamente. La solucion no es reemplazar esa letra concreta: eso funciona hasta que
 * aparezca la siguiente palabra acentuada. La solucion es
 * {@link Normalizer#normalize(CharSequence, Normalizer.Form)} en forma NFD, que <em>separa</em>
 * cada letra acentuada en dos caracteres, la letra base y la marca del acento, seguido de borrar
 * todas las marcas con {@code \\p{M}}. Dos lineas que resuelven el problema para cualquier
 * acento, dieresis o cedilla, en cualquier idioma.
 *
 * <p><strong>Trampa 2: los valores que parecen datos y no lo son.</strong> El archivo usa varios
 * centinelas para decir "no se": {@code -1} y {@code unknown} en {@code intereses.csv},
 * {@code invalid} y {@code desconocido} en {@code transacciones.csv}, ademas de la celda vacia.
 * Todos se traducen a la <strong>misma constante explicita</strong>, {@link #DESCONOCIDO}, en vez
 * de a {@code null}. La diferencia importa: un {@code null} que se cuela produce un
 * {@code NullPointerException} lejos del lugar donde nacio, mientras que una constante con nombre
 * se puede comparar, imprimir en un log y probar en un test. Solo despues, y de forma deliberada,
 * los metodos {@code parse} de los enumerados convierten esa constante en un
 * {@code Optional.empty()} que el reporte de calidad cuenta.
 *
 * <p>La clase es final y sin constructor publico: es un ayudante sin estado, no un objeto que
 * tenga sentido crear.
 */
public final class NormalizadorTexto {

    /**
     * Valor unico al que se traduce cualquier centinela del dataset.
     *
     * <p>Se escribe en mayusculas y con un guion bajo a proposito: ningun valor legitimo del
     * archivo tiene esa forma, asi que no puede confundirse con un dato real ni por casualidad.
     */
    public static final String DESCONOCIDO = "__DESCONOCIDO__";

    /**
     * Los centinelas encontrados en el dataset, ya en su forma normalizada.
     *
     * <p>Estan aqui, en una constante con nombre, y no repartidos en condicionales por el codigo:
     * cuando aparezca un centinela nuevo se agrega una linea en un solo lugar. {@code n/a},
     * {@code null} y {@code none} se incluyen por prudencia aunque no se hayan observado: cuestan
     * cero y cubren las variantes habituales de un exportador de datos.
     */
    private static final Set<String> CENTINELAS =
            Set.of("", "-1", "unknown", "invalid", "desconocido", "n/a", "null", "none", "nan");

    private NormalizadorTexto() {
    }

    /**
     * Devuelve el valor sin tildes, sin espacios sobrantes y en minusculas; o {@link #DESCONOCIDO}
     * si el valor era nulo o uno de los centinelas.
     *
     * @param valorCrudo texto tal como venia en el archivo; admite nulo
     */
    public static String normalizar(String valorCrudo) {
        if (valorCrudo == null) {
            return DESCONOCIDO;
        }

        // NFD separa "o con tilde" en "o" + "marca de acento agudo"; \p{M} designa esas marcas.
        String sinTildes = Normalizer.normalize(valorCrudo, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");

        // Locale.ROOT y no el del sistema: con el idioma turco, "I".toLowerCase() da una i sin
        // punto, y una ingesta que funciona aqui fallaria en la maquina de otro. Es el ejemplo
        // clasico de un bug que depende de la configuracion regional.
        String limpio = sinTildes.trim().toLowerCase(Locale.ROOT);

        return CENTINELAS.contains(limpio) ? DESCONOCIDO : limpio;
    }

    /**
     * Indica si un valor <strong>ya normalizado</strong> representa una ausencia.
     *
     * <p>Existe para que ninguna otra clase tenga que comparar contra la constante a mano, que es
     * donde se cuela el error de escribirla mal.
     */
    public static boolean esDesconocido(String valorNormalizado) {
        return DESCONOCIDO.equals(valorNormalizado);
    }

    /**
     * Limpia un texto que se va a <strong>mostrar</strong>, no a comparar: recorta los espacios y
     * nada mas.
     *
     * <p>Los nombres de titular y las descripciones conservan sus tildes y sus mayusculas, porque
     * son datos que el cliente va a leer en pantalla. La normalizacion agresiva de arriba sirve
     * para decidir si dos valores son el mismo, no para decidir como se escriben. Devuelve
     * {@code null} cuando no queda nada, porque el contrato declara que {@code descripcion} admite
     * nulo y una cadena vacia ocuparia bytes para no decir nada.
     */
    public static String limpiarParaMostrar(String valorCrudo) {
        if (valorCrudo == null) {
            return null;
        }
        String recortado = valorCrudo.trim();
        return recortado.isEmpty() ? null : recortado;
    }
}
