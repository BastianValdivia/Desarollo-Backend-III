package cl.duoc.bancoxyz.core.ingesta;

/**
 * Una fila de {@code intereses.csv} tal como se leyo, <strong>sin interpretar</strong>.
 *
 * <p>Rol en la arquitectura: separa "leer el archivo" de "decidir que significa". La ingesta
 * primero convierte cada linea en uno de estos records, con los cinco valores todavia como texto,
 * y solo despues la regla de consolidacion vota sobre ellos. Sin esta separacion, el parseo y la
 * regla de negocio quedarian mezclados en el mismo bucle y ninguno de los dos podria probarse solo.
 *
 * <p><strong>Por que los campos siguen siendo {@code String}.</strong> Convertirlos aqui obligaria
 * a decidir demasiado pronto que hacer con un saldo vacio o con un tipo {@code -1}. La regla de
 * consolidacion necesita ver los valores invalidos para poder <em>ignorarlos al votar</em> y
 * contarlos en el reporte; si llegaran ya convertidos a nulo, la informacion de por que se
 * descartaron ya se habria perdido.
 *
 * <p>Al ser un record, la igualdad se compara campo a campo, y eso es justo lo que permite
 * deduplicar las filas exactas con un conjunto sin escribir nada mas.
 */
public record FilaInteres(String cuentaId, String nombre, String saldo, String edad, String tipo) {
}
