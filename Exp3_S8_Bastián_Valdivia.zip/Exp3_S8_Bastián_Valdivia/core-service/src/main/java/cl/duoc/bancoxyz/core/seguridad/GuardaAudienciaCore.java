package cl.duoc.bancoxyz.core.seguridad;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Hace fallar el arranque del core si no exige la audiencia {@code core-service} en los tokens.
 *
 * <p>Spring Boot agrega el validador de audiencia al decodificador de tokens <strong>solo si</strong> la
 * propiedad {@code spring.security.oauth2.resourceserver.jwt.audiences} tiene un valor. Si esa propiedad
 * faltara o quedara vacia (por ejemplo, un cambio equivocado en {@code config-repo/core-service.yml}),
 * Boot no se queja: el core arrancaria aceptando tokens firmados y vigentes de <em>cualquier</em>
 * audiencia, es decir, un token pedido para otro servicio serviria para retirar dinero. Una proteccion
 * que se apaga en silencio es peor que ninguna, porque nadie vuelve a mirarla.
 *
 * <p>Esta guarda convierte ese caso en un error de arranque con un mensaje que nombra la propiedad. La
 * prueba de otra audiencia ({@code SeguridadOAuth2CoreTest}) sigue siendo la que demuestra que el
 * rechazo funciona; esta clase garantiza que la configuracion que lo activa no desaparezca.
 */
@Component
public class GuardaAudienciaCore {

    /** La audiencia que el auth-server pone en los tokens emitidos para este servicio. */
    static final String AUDIENCIA_DEL_CORE = "core-service";

    public GuardaAudienciaCore(
            @Value("${spring.security.oauth2.resourceserver.jwt.audiences:}") List<String> audiencias) {
        boolean exigeLaPropia = audiencias != null && audiencias.stream()
                .anyMatch(a -> AUDIENCIA_DEL_CORE.equals(a == null ? null : a.trim()));
        if (!exigeLaPropia) {
            throw new IllegalStateException("El core debe exigir la audiencia '" + AUDIENCIA_DEL_CORE
                    + "' en los tokens, y 'spring.security.oauth2.resourceserver.jwt.audiences' vale "
                    + audiencias + ". Sin ella aceptaria tokens emitidos para cualquier otro servicio."
                    + " Revisa config-repo/core-service.yml.");
        }
    }
}
