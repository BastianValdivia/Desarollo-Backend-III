package cl.duoc.bancoxyz.core.config;

import java.io.IOException;
import java.time.Duration;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Aplica la espera de {@link LatenciaInyectada} a cada peticion {@code /internal/**}.
 *
 * <p>Va justo despues del filtro que registra las peticiones y antes de la seguridad, de modo que el
 * tiempo que se ve en el log ({@code ... en N ms}) incluye la latencia inyectada: es la evidencia de que
 * el core estuvo lento de verdad y no solo el BFF. Lee la latencia en CADA peticion a traves del proxy
 * del bean {@code @RefreshScope}, asi que un {@code POST /actuator/refresh} la cambia sin reiniciar.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 20)
public class LatenciaInyectadaFilter extends OncePerRequestFilter {

    private static final String PREFIJO = "/internal/";

    private final LatenciaInyectada latencia;

    public LatenciaInyectadaFilter(LatenciaInyectada latencia) {
        this.latencia = latencia;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest peticion) {
        return !peticion.getRequestURI().startsWith(PREFIJO);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest peticion, HttpServletResponse respuesta,
                                    FilterChain cadena) throws ServletException, IOException {
        Duration espera = latencia.latencia();
        if (!espera.isZero()) {
            try {
                Thread.sleep(espera);
            } catch (InterruptedException interrumpido) {
                // El cliente se fue o el servidor se apaga: se conserva la interrupcion y se sigue.
                Thread.currentThread().interrupt();
            }
        }
        cadena.doFilter(peticion, respuesta);
    }
}
