package cl.duoc.bancoxyz.core.dominio;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;

/**
 * La cuenta bancaria canonica: <strong>raiz de agregado</strong> del dominio.
 *
 * <p>Rol en la arquitectura: es la unidad de consistencia del sistema. "Raiz de agregado"
 * significa que el saldo y el historial de movimientos forman un todo que solo se modifica en
 * bloque y a traves de esta clase; nadie puede tocar la lista de movimientos por un lado y el
 * saldo por otro. Esa propiedad es la que hace posible que el retiro sea atomico.
 *
 * <p><strong>Por que es inmutable.</strong> Todos los campos son finales y {@link #conRetiro}
 * no modifica la cuenta: devuelve una cuenta <em>nueva</em>. A primera vista parece un rodeo
 * (por que no simplemente restarle al saldo?), y es justamente lo contrario. Con objetos
 * mutables, dos hilos que retiran a la vez pueden ver estados a medio construir: el saldo ya
 * descontado pero el movimiento todavia no registrado. Con objetos inmutables ese estado
 * intermedio no existe: o se ve la cuenta vieja completa, o se ve la nueva completa. El unico
 * punto donde hay que garantizar exclusion es el reemplazo de la referencia, y de eso se encarga
 * el adaptador de repositorio con {@code ConcurrentHashMap.compute}.
 *
 * <p><strong>Por que el historial se guarda ya ordenado.</strong> Mantener el invariante "la
 * lista siempre esta en {@link Movimiento#ORDEN_CANONICO}" dentro del constructor evita que cada
 * consulta tenga que reordenar y, sobre todo, evita que un camino olvide hacerlo. El costo se
 * paga una sola vez, al construir.
 */
public final class Cuenta {

    private final int id;
    private final String titular;
    private final BigDecimal saldo;
    private final int edadTitular;
    private final TipoCuenta tipo;
    private final List<Movimiento> movimientos;

    /**
     * Construye una cuenta canonica. Los cuatro primeros campos son el resultado de la regla de
     * consolidacion; ninguno admite nulo, y esa exigencia es deliberada: el invariante verificado
     * del proyecto es "50 cuentas, cero campos nulos", asi que una cuenta con un campo vacio es un
     * error de la ingesta que debe explotar aqui y no aparecer como {@code null} en un JSON.
     */
    public Cuenta(int id, String titular, BigDecimal saldo, int edadTitular, TipoCuenta tipo,
                  List<Movimiento> movimientos) {
        this.id = id;
        this.titular = Objects.requireNonNull(titular, "titular");

        // La escala se fija AQUI, en el unico camino por el que se construye una cuenta, y no en
        // cada sitio que produce un saldo. El contrato congela los importes con dos decimales
        // (12000.00), y dejarlo a criterio de cada llamador terminaria publicando "12000" desde un
        // endpoint y "12000.00" desde otro para el mismo dinero: no es un error de calculo, pero un
        // cliente estricto que compare las dos cadenas de texto las vera distintas.
        // HALF_UP y no UNNECESSARY porque ampliar la escala nunca redondea, y si algun dia llegara
        // un importe con mas decimales es preferible redondearlo que abortar la ingesta entera.
        this.saldo = Objects.requireNonNull(saldo, "saldo").setScale(2, RoundingMode.HALF_UP);
        this.edadTitular = edadTitular;
        this.tipo = Objects.requireNonNull(tipo, "tipo");

        List<Movimiento> copia = new ArrayList<>(Objects.requireNonNull(movimientos, "movimientos"));
        copia.sort(Movimiento.ORDEN_CANONICO);
        // unmodifiableList sobre una copia propia, no sobre la lista recibida: si se envolviera la
        // lista del llamador, quien la paso todavia tendria una referencia mutable y podria
        // cambiarla por debajo, con lo cual la inmutabilidad seria solo aparente.
        this.movimientos = Collections.unmodifiableList(copia);
    }

    public int id() {
        return id;
    }

    public String titular() {
        return titular;
    }

    public BigDecimal saldo() {
        return saldo;
    }

    public int edadTitular() {
        return edadTitular;
    }

    public TipoCuenta tipo() {
        return tipo;
    }

    /** Historial completo, del mas reciente al mas antiguo. La lista devuelta no es modificable. */
    public List<Movimiento> movimientos() {
        return movimientos;
    }

    /**
     * Devuelve la cuenta que resulta de retirar {@code monto}: saldo descontado y un movimiento
     * nuevo de tipo {@link TipoMovimiento#RETIRO} incorporado al historial.
     *
     * <p><strong>Este metodo es el corazon del ejercicio.</strong> Las dos cosas que el retiro
     * tiene que hacer, descontar el saldo y registrar el apunte, ocurren en una unica expresion
     * que construye un unico objeto. No hay ningun instante en que exista una cuenta con el saldo
     * ya descontado y el movimiento todavia sin registrar, porque no hay dos pasos: hay uno.
     * "Atomico o ninguno" deja de ser una promesa del programador y pasa a ser una propiedad de la
     * forma del codigo.
     *
     * <p>La validacion de saldo se hace <em>aqui dentro</em> y no en el servicio de aplicacion a
     * proposito. Si viviera fuera, entre la comprobacion y la construccion de la cuenta nueva
     * habria una ventana por la que otro hilo podria colarse (el clasico "comprobar y despues
     * actuar"). Dentro del metodo, la comprobacion y la construccion son inseparables, y el
     * adaptador se encarga de que el metodo entero se ejecute bajo exclusion para esa cuenta.
     *
     * @param monto        importe a retirar; se asume ya validado como positivo por el servicio
     * @param idMovimiento identificador tecnico para el apunte nuevo
     * @param fecha        dia que queda registrado en el movimiento
     * @return una cuenta nueva; la actual queda intacta
     * @throws SaldoInsuficienteException si el saldo actual es menor que el monto pedido
     */
    public Cuenta conRetiro(BigDecimal monto, long idMovimiento, LocalDate fecha) {
        // compareTo y no equals: BigDecimal.equals distingue 5000 de 5000.00, y esa distincion,
        // que es correcta para "misma representacion", es un bug cuando lo que se pregunta es
        // "mismo dinero".
        if (saldo.compareTo(monto) < 0) {
            throw new SaldoInsuficienteException(id, saldo, monto);
        }

        List<Movimiento> historial = new ArrayList<>(movimientos);
        historial.add(new Movimiento(
                idMovimiento,
                id,
                fecha,
                TipoMovimiento.RETIRO,
                monto,
                "Retiro por cajero automatico",
                OrigenDato.RETIRO_ATM));

        return new Cuenta(id, titular, saldo.subtract(monto), edadTitular, tipo, historial);
    }
}
