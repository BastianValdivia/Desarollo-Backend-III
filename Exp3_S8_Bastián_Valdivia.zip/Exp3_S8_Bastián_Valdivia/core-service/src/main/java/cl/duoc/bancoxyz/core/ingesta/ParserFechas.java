package cl.duoc.bancoxyz.core.ingesta;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;


/**
 * Convierte las fechas del CSV a {@link LocalDate}, resolviendo los <strong>cuatro</strong>
 * formatos que conviven en el mismo archivo.
 *
 * <p>Rol en la arquitectura: es la pieza de ingesta que impide que el historial del banco se llene
 * de fechas equivocadas. Se declara como componente de Spring, y no como clase de metodos
 * estaticos, porque es una <em>regla de negocio</em> sobre como interpretar el dataset: tenerla
 * como objeto permite probarla sola y, si manana llegan datos de otro pais, sustituirla.
 *
 * <p><strong>Reparto medido en {@code cuentas_anuales.csv}</strong>, sin una sola fila que no
 * encaje en alguno: {@code dd-MM-yyyy} 255 veces, {@code yyyy-MM-dd} 253, {@code yyyy/MM/dd} 246 y
 * {@code dd/MM/yyyy} 246.
 *
 * <h2>Por que se elige el formato con una expresion regular ANTES de parsear</h2>
 *
 * <p>La forma intuitiva es probar los cuatro formateadores uno tras otro dentro de un
 * {@code try/catch} y quedarse con el primero que no lance. <strong>Esa forma esta mal, y falla en
 * silencio</strong>, que es lo peor que puede pasar.
 *
 * <p>El motivo es que el patron {@code yyyy} de {@link DateTimeFormatter} acepta un numero
 * <em>variable</em> de digitos. Si se prueba primero {@code yyyy-MM-dd} contra el texto
 * {@code 24-07-2024}, el formateador lee {@code 24} como el ano, {@code 07} como el mes y
 * {@code 2024} como... el dia, ahi si falla. Pero con {@code 08-03-2024} contra
 * {@code yyyy/MM/dd} el separador salva la situacion, y hay combinaciones de dos digitos donde el
 * parseo <em>tiene exito</em> y produce una fecha del siglo I. No hay excepcion, no hay aviso, y
 * el error solo se descubre cuando alguien mira el historial y ve el ano 24.
 *
 * <p>Seleccionar el formato por la <em>forma</em> del texto elimina el problema de raiz: cada
 * expresion regular fija la cantidad exacta de digitos de cada posicion, asi que solo puede
 * coincidir un patron y el formateador recibe un texto que ya se sabe compatible. Si no coincide
 * ninguno, la respuesta es una ausencia contada en el reporte de calidad, nunca una adivinanza.
 *
 * <h2>La ambiguedad real, y el criterio que se aplica</h2>
 *
 * <p>Hay fechas que, miradas solas, admiten dos lecturas. {@code 08-03-2024} puede ser el 8 de
 * marzo (dia primero, criterio europeo y chileno) o el 3 de agosto (mes primero, criterio de
 * Estados Unidos). El dato en si no alcanza para decidir: <strong>la ambiguedad no se resuelve
 * mirando el archivo, se resuelve declarando un criterio</strong>.
 *
 * <p><strong>Criterio adoptado, y su fundamento:</strong> cuando el ano va al final, el primer
 * numero es el <strong>dia</strong>. Es decir {@code dd-MM-yyyy} y {@code dd/MM/yyyy}, nunca
 * {@code MM-dd-yyyy}. Tres razones, en orden de peso:
 *
 * <ol>
 *   <li>Es la convencion de Chile, que es donde opera el Banco XYZ. Un sistema que interpreta las
 *       fechas de sus clientes con el criterio de otro pais produce cartolas equivocadas.</li>
 *   <li>Es consistente con los otros dos formatos del mismo archivo, que empiezan por el ano y
 *       siguen con mes y dia: en los cuatro, los componentes van de mayor a menor unidad, salvo por
 *       el ano desplazado al final.</li>
 *   <li>Es verificable contra el propio dataset. Hay filas con un primer componente mayor que 12,
 *       por ejemplo {@code 24-07-2024}, que <em>solo</em> pueden leerse como dia; ninguna
 *       interpretacion de mes es posible. Si el criterio fuera "mes primero", esas filas no
 *       existirian o serian ilegibles.</li>
 * </ol>
 *
 * <p>Bajo este criterio, la fila real {@code 103,08-03-2024,deposito,3000,Retiro parcial} queda
 * registrada como <strong>8 de marzo de 2024</strong>, que es lo que el contrato muestra en su
 * ejemplo de respuesta como {@code "2024-03-08"}.
 *
 * <p>La ambiguedad es, ademas, intrinsecamente irresoluble para las fechas donde ambos componentes
 * son menores o iguales a 12: el criterio no "acierta" en esas filas, las <em>define</em>. Eso es
 * exactamente lo que hay que declarar en la documentacion en vez de disimularlo.
 */
public class ParserFechas {

    /**
     * Formato y su expresion regular de reconocimiento, emparejados.
     *
     * <p>Van juntos en un record para que no puedan desincronizarse: no hay forma de agregar un
     * patron sin agregar su regla de reconocimiento, que es el error que dejaria vuelta a colar la
     * estrategia de "probar y ver que pasa".
     */
    private record FormatoFecha(Pattern forma, DateTimeFormatter formateador, String descripcion) {
    }

    /**
     * Los cuatro formatos, con las cantidades de digitos <strong>ancladas</strong> por
     * {@code ^} y {@code $}.
     *
     * <p>{@link ResolverStyle#STRICT} junto con {@code uuuu} (y no {@code yyyy}) hace que el 31 de
     * febrero sea un error en vez de corregirse en silencio al 28. {@code yyyy} significa "ano de
     * la era" y obliga a declarar la era; {@code uuuu} es el ano proleptico y es el que funciona
     * en modo estricto sin mas ceremonia. Es un detalle oscuro de la API de fechas de Java que
     * cuesta una tarde descubrir y una letra arreglar.
     */
    private static final List<FormatoFecha> FORMATOS = List.of(
            new FormatoFecha(
                    Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$"),
                    DateTimeFormatter.ofPattern("uuuu-MM-dd").withResolverStyle(ResolverStyle.STRICT),
                    "yyyy-MM-dd"),
            new FormatoFecha(
                    Pattern.compile("^\\d{4}/\\d{2}/\\d{2}$"),
                    DateTimeFormatter.ofPattern("uuuu/MM/dd").withResolverStyle(ResolverStyle.STRICT),
                    "yyyy/MM/dd"),
            new FormatoFecha(
                    Pattern.compile("^\\d{2}-\\d{2}-\\d{4}$"),
                    DateTimeFormatter.ofPattern("dd-MM-uuuu").withResolverStyle(ResolverStyle.STRICT),
                    "dd-MM-yyyy"),
            new FormatoFecha(
                    Pattern.compile("^\\d{2}/\\d{2}/\\d{4}$"),
                    DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT),
                    "dd/MM/yyyy"));

    /**
     * Interpreta una fecha del archivo.
     *
     * @param valorCrudo texto de la columna de fecha; admite nulo y espacios alrededor
     * @return la fecha, o vacio si el texto no corresponde a ninguno de los cuatro formatos. Quien
     *         llama debe contar esa ausencia como {@code FECHA_ILEGIBLE}, nunca sustituirla por la
     *         fecha de hoy ni por una fecha inventada
     */
    public Optional<LocalDate> parsear(String valorCrudo) {
        if (valorCrudo == null) {
            return Optional.empty();
        }
        String texto = valorCrudo.trim();

        for (FormatoFecha formato : FORMATOS) {
            if (formato.forma().matcher(texto).matches()) {
                try {
                    return Optional.of(LocalDate.parse(texto, formato.formateador()));
                } catch (DateTimeParseException fechaImposible) {
                    // La forma coincidia pero el valor no existe en el calendario (por ejemplo
                    // 31-02-2024). Es una fecha ilegible, no un formato distinto: no se sigue
                    // probando con los demas patrones, porque ninguno podria coincidir.
                    return Optional.empty();
                }
            }
        }
        return Optional.empty();
    }

    /**
     * Nombre del formato que reconoceria a este texto, para poder publicar el reparto medido en el
     * log de calidad de datos. Devuelve vacio si ninguno lo reconoce.
     */
    public Optional<String> formatoDetectado(String valorCrudo) {
        if (valorCrudo == null) {
            return Optional.empty();
        }
        String texto = valorCrudo.trim();
        return FORMATOS.stream()
                .filter(f -> f.forma().matcher(texto).matches())
                .map(FormatoFecha::descripcion)
                .findFirst();
    }
}
