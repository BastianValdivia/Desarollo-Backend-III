package cl.duoc.bancoxyz.core.api;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.bancoxyz.core.aplicacion.ConsultaCuentaService;
import cl.duoc.bancoxyz.core.aplicacion.RetiroService;
import cl.duoc.bancoxyz.core.api.dto.CuentaCoreResponse;
import cl.duoc.bancoxyz.core.api.dto.PaginaMovimientosResponse;
import cl.duoc.bancoxyz.core.api.dto.RetiroRequest;
import cl.duoc.bancoxyz.core.api.dto.RetiroResponse;
import cl.duoc.bancoxyz.core.api.dto.SaldoCoreResponse;
import cl.duoc.bancoxyz.core.config.CoreProperties;
import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.TipoMovimiento;

/**
 * API interna de cuentas del {@code core-service}: los cuatro recursos que consumen los tres BFF.
 *
 * <h2>Por que las rutas empiezan por /internal y no por /api</h2>
 *
 * <p>No es cosmetica. Cualquiera que mire una linea de registro o una salida de consola sabe de
 * inmediato, sin conocer los puertos de memoria, si esta viendo trafico de un canal
 * ({@code /api/web}, {@code /api/mobile}, {@code /api/atm}) o del backend de dominio
 * ({@code /internal/v1}). En un sistema de cuatro procesos parecidos, esa legibilidad vale mucho
 * mas que lo que cuesta.
 *
 * <p>El {@code v1} es la promesa de compatibilidad: el dia que un campo tenga que cambiar de forma
 * incompatible, aparece {@code /internal/v2} y los BFF migran cuando pueden, en vez de romperse
 * todos a la vez.
 *
 * <h2>Que hace y que no hace esta clase</h2>
 *
 * <p>Un controlador traduce: recibe HTTP, llama a un caso de uso y convierte el resultado a DTO.
 * <strong>No hay ni una linea de logica de negocio aqui</strong>, y eso es intencional. Si la regla
 * de saldo viviera en este metodo, no se podria probar sin levantar un servidor, y se rompería el
 * dia que el mismo caso de uso se necesitara desde otro transporte.
 *
 * <p>Toda esta clase esta detras del servidor de recursos OAuth2 ({@code SeguridadCoreConfig}): una
 * peticion sin un token valido no llega hasta aqui (401), y una con un token al que le falta el scope
 * del endpoint tampoco (403). Que scope exige cada ruta se decide alli, en un solo lugar, y no en estos
 * metodos.
 */
@RestController
@RequestMapping(value = "/internal/v1/cuentas", produces = MediaType.APPLICATION_JSON_VALUE)
public class CuentaInternaController {

    private final ConsultaCuentaService consultaCuentaService;
    private final RetiroService retiroService;
    private final CoreProperties propiedades;

    public CuentaInternaController(ConsultaCuentaService consultaCuentaService,
                                   RetiroService retiroService,
                                   CoreProperties propiedades) {
        this.consultaCuentaService = consultaCuentaService;
        this.retiroService = retiroService;
        this.propiedades = propiedades;
    }

    /**
     * La cuenta completa con <strong>todos</strong> sus movimientos.
     *
     * <p>Es la linea base contra la que se mide cuanto recorta cada canal. Una cuenta sin historial
     * devuelve {@code "movimientos": []}, nunca {@code null}.
     *
     * <p>Devuelve 404 si la cuenta no existe. Notese que <strong>no</strong> devuelve 403 por
     * cuenta ajena: el core no sabe quien pregunta, solo que quien pregunta traia la credencial de
     * servicio. La titularidad la comprueba cada BFF, que si conoce la identidad del cliente porque
     * la lleva dentro del token.
     */
    @GetMapping("/{cuentaId}")
    public CuentaCoreResponse obtenerCuenta(@PathVariable int cuentaId) {
        Cuenta cuenta = consultaCuentaService.obtenerCuenta(cuentaId);
        return CuentaCoreResponse.de(cuenta, propiedades.moneda());
    }

    /**
     * Solo el saldo: {@code cuentaId}, {@code saldo} y {@code moneda}.
     *
     * <p><strong>Este endpoint es la razon por la que el movil y el cajero no sobrecargan al
     * core.</strong> Sin el, tendrian que pedir la cuenta completa y quedarse con un campo, lo que
     * obligaria al core a construir y serializar 42 movimientos para tirarlos a la basura. Lo que
     * se ahorra no es solo lo que viaja por la red: es el trabajo del servidor, que es la mitad del
     * problema que la mayoria de las implementaciones deja sin atacar.
     */
    @GetMapping("/{cuentaId}/saldo")
    public SaldoCoreResponse obtenerSaldo(@PathVariable int cuentaId) {
        Cuenta cuenta = consultaCuentaService.obtenerCuenta(cuentaId);
        return SaldoCoreResponse.de(cuenta, propiedades.moneda());
    }

    /**
     * Una pagina del historial, con filtros opcionales.
     *
     * <p>Los cuatro parametros son opcionales y componibles. {@code desde} y {@code hasta} se
     * escriben en formato ISO ({@code 2024-03-08}) y son inclusivos en ambos extremos, que es como
     * lo entiende una persona que pide "los movimientos de marzo".
     *
     * @param tipo se recibe como texto y se convierte a mano en vez de dejar que Spring enlace el
     *             enumerado directamente. El motivo es el mensaje de error: con enlace automatico,
     *             un valor equivocado produce un 400 generico del servidor que no se parece al
     *             resto de la API; convertido aqui, produce el mismo cuerpo RFC 7807 que todo lo
     *             demas
     */
    @GetMapping("/{cuentaId}/movimientos")
    public PaginaMovimientosResponse listarMovimientos(
            @PathVariable int cuentaId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta,
            @RequestParam(required = false) String tipo) {

        TipoMovimiento tipoFiltro = (tipo == null || tipo.isBlank())
                ? null
                : TipoMovimiento.parse(tipo).orElseThrow(
                        () -> new IllegalArgumentException("Tipo de movimiento desconocido: " + tipo));

        return PaginaMovimientosResponse.de(
                cuentaId,
                consultaCuentaService.paginarMovimientos(cuentaId, page, size, desde, hasta, tipoFiltro));
    }

    /**
     * <strong>Retiro: la operacion critica del sistema.</strong> Es el unico endpoint del core que
     * modifica el estado.
     *
     * <p>Los codigos que puede devolver, y lo que significa cada uno:
     * <ul>
     *   <li><strong>200</strong>: se descontó y se registro el movimiento. Ambas cosas, o ninguna.</li>
     *   <li><strong>400</strong> {@code monto_no_positivo}: la peticion esta mal formada y
     *       reintentarla igual siempre va a fallar.</li>
     *   <li><strong>404</strong> {@code recurso_no_encontrado}: no existe esa cuenta.</li>
     *   <li><strong>409</strong> {@code saldo_insuficiente}: la peticion es valida y es el
     *       <em>estado</em> el que no da. La misma peticion, despues de un deposito, funcionaria.</li>
     * </ul>
     *
     * <p><strong>La cabecera {@code Idempotency-Key} es lo que hace seguro un reintento.</strong>
     * Si al cajero se le corta la red antes de recibir la respuesta, no tiene forma de saber si el
     * banco alcanzo a descontar. Reenviando la peticion con la misma clave, el core devuelve el
     * mismo folio y las mismas cifras sin volver a tocar el saldo. Es opcional en la firma, para no
     * obligar a un cliente que no la necesita, y el canal cajero siempre la envia, que es el canal
     * donde un corte de red cuesta dinero de verdad.
     *
     * <p>Importante: la idempotencia vive <strong>aqui</strong>, en el dueno del estado, y no en el
     * BFF del cajero. Si viviera alli, dos instancias de ese BFF tendrian cada una su propio
     * registro y un reintento que cayera en la otra descontaria por segunda vez.
     */
    @PostMapping(value = "/{cuentaId}/retiros", consumes = MediaType.APPLICATION_JSON_VALUE)
    public RetiroResponse retirar(
            @PathVariable int cuentaId,
            @RequestBody RetiroRequest peticion,
            @RequestHeader(value = "Idempotency-Key", required = false) String claveIdempotencia) {

        return RetiroResponse.de(
                retiroService.retirar(cuentaId, peticion.monto(), claveIdempotencia));
    }
}
