package cl.duoc.bancoxyz.core.eventos;

import java.time.Duration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.FixedDelayTask;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

/**
 * El latido del relay: un ciclo, una pausa fija, otro ciclo.
 *
 * <p>Pausa fija DESPUES de terminar cada ciclo ({@code fixedDelay}) y no a ritmo fijo: si un ciclo se
 * demora porque Kafka responde lento, el siguiente no se encima ni se acumula. Se registra por codigo y no
 * con {@code @Scheduled} porque asi la pausa sale de {@link EventosProperties} como un {@link Duration}
 * ({@code 500ms}); la anotacion solo entiende milisegundos o ISO-8601. Vive en su propia clase, y no dentro
 * de {@link EventosConfig}, porque una clase anidada se escanea por separado y no heredaria la condicion de
 * la clase que la contiene.
 */
@Component
@ConditionalOnProperty(name = "eventos.relay.habilitado", havingValue = "true")
public class PlanificadorRelay implements SchedulingConfigurer {

    /** Espera inicial: deja que el servicio termine de arrancar y registrarse antes del primer ciclo. */
    private static final Duration RETRASO_INICIAL = Duration.ofSeconds(5);

    private final RelayOutbox relay;
    private final EventosProperties propiedades;

    public PlanificadorRelay(RelayOutbox relay, EventosProperties propiedades) {
        this.relay = relay;
        this.propiedades = propiedades;
    }

    @Override
    public void configureTasks(ScheduledTaskRegistrar registro) {
        registro.addFixedDelayTask(new FixedDelayTask(relay::publicarPendientes,
                propiedades.relay().intervalo(), RETRASO_INICIAL));
    }
}
