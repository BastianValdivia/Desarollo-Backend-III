package cl.duoc.bancoxyz.core.adaptador;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import cl.duoc.bancoxyz.core.puerto.GeneradorIdentificadores;

/**
 * <strong>Adaptador</strong> de {@link GeneradorIdentificadores} sobre las secuencias de PostgreSQL
 * ({@code folio_retiro_seq} y {@code movimiento_id_seq}, creadas en la migracion V1).
 *
 * <p>{@code nextval} es atomico y no bloquea a los demas: dos replicas que lo piden a la vez reciben
 * numeros distintos sin esperarse. Por eso no hace falta ninguna transaccion ni ningun bloqueo
 * escrito a mano; la unicidad la garantiza el motor.
 */
@Repository
public class GeneradorIdentificadoresJdbc implements GeneradorIdentificadores {

    private final JdbcClient jdbc;

    public GeneradorIdentificadoresJdbc(JdbcClient jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public long siguienteCorrelativoFolio() {
        return jdbc.sql("SELECT nextval('folio_retiro_seq')").query(Long.class).single();
    }

    @Override
    public long siguienteIdMovimiento() {
        return jdbc.sql("SELECT nextval('movimiento_id_seq')").query(Long.class).single();
    }
}
