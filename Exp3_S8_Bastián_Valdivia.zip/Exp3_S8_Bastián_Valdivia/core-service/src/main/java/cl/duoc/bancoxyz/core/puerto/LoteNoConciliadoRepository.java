package cl.duoc.bancoxyz.core.puerto;

import cl.duoc.bancoxyz.core.dominio.Pagina;
import cl.duoc.bancoxyz.core.dominio.TransaccionNoConciliada;

/**
 * <strong>Puerto</strong> de lectura del lote de {@code transacciones.csv}, el archivo que no se
 * pudo vincular a ninguna cuenta.
 *
 * <p>Rol en la arquitectura: es deliberadamente pobre. Solo ofrece lectura paginada y un conteo,
 * porque este lote no participa en ninguna regla de negocio: no suma al saldo de nadie, no se
 * puede retirar contra el y no se puede corregir sin inventar datos. Que la interfaz sea tan
 * estrecha <em>es</em> la documentacion de esa decision: no hay ningun metodo que permita
 * asignarle una cuenta a una transaccion, asi que el error no se puede cometer por descuido.
 *
 * <p>Su unico consumidor es {@code GET /internal/v1/admin/transacciones-no-conciliadas}, que el
 * canal web expone solo a un ejecutivo. Un cliente no tiene nada que hacer con un lote que no es
 * suyo; un ejecutivo de banco si, porque conciliarlo es exactamente su trabajo.
 */
public interface LoteNoConciliadoRepository {

    /** Una pagina del lote, en el mismo orden en que venia el archivo. */
    Pagina<TransaccionNoConciliada> paginar(int pagina, int tamano);

    /** Cuantas transacciones tiene el lote completo. Valor esperado sobre el dataset: 1000. */
    int total();
}
