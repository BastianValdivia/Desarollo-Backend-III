package cl.duoc.bancoxyz.core.seguridad;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.web.firewall.RequestRejectedException;
import org.springframework.security.web.firewall.RequestRejectedHandler;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import cl.duoc.bancoxyz.core.api.dto.RespuestaErrorCore;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Responde 400 en {@code application/problem+json} a las URL que el firewall de Spring Security
 * rechaza ({@code ;x=1}, {@code %2e}, {@code //}, saltos de linea...).
 *
 * <p>El firewall rechaza esas formas <em>antes</em> de evaluar ninguna regla: son la clase de URL con
 * la que se intento eludir el filtro del S5 (el contenedor las normalizaba de un modo y la regla las
 * leia de otro). El comportamiento por defecto es {@code response.sendError(400)}, y {@code sendError}
 * hace que el contenedor reenvie la peticion a {@code /error}, donde el cuerpo ya no es el del core. Aqui
 * se escribe la respuesta directamente: el cliente recibe el mismo formato que en cualquier otro error
 * de la API, y el motivo concreto queda en el log.
 */
@Component
public class RechazoDeUrlCore implements RequestRejectedHandler {

    private static final Logger log = LoggerFactory.getLogger(RechazoDeUrlCore.class);

    private final ObjectMapper objectMapper;

    public RechazoDeUrlCore(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public void handle(HttpServletRequest peticion, HttpServletResponse respuesta,
                       RequestRejectedException excepcion) throws IOException {
        log.warn("URL rechazada por el firewall en {} (se responde 400): {}", peticion.getMethod(),
                excepcion.getMessage());

        respuesta.setStatus(HttpStatus.BAD_REQUEST.value());
        respuesta.setContentType(MediaType.APPLICATION_PROBLEM_JSON_VALUE);
        respuesta.setCharacterEncoding(StandardCharsets.UTF_8.name());
        // La ruta del cuerpo es la que el servidor interpreta, no el texto crudo del cliente: asi el
        // cuerpo no refleja de vuelta secuencias raras que el firewall acaba de rechazar.
        objectMapper.writeValue(respuesta.getOutputStream(), RespuestaErrorCore.de(
                HttpStatus.BAD_REQUEST, "Peticion invalida", "peticion_invalida",
                "La URL contiene secuencias no permitidas", "(url rechazada)"));
    }
}
