package cl.duoc.bancoxyz.core.dominio;

import java.math.BigDecimal;

/**
 * Lo que queda de un retiro ejecutado: su comprobante.
 *
 * <p>Rol en la arquitectura: es el valor que el core devuelve al cajero y, sobre todo, es
 * <strong>lo que se guarda en el registro de idempotencia</strong>. Ante un reintento con la misma
 * clave, el core no vuelve a descontar: devuelve este mismo objeto, con el mismo folio y las
 * mismas cifras. Por eso tiene que ser inmutable y contener todo lo que el cliente necesita, sin
 * depender del estado actual de la cuenta: si al reintentar se recalculara el saldo posterior
 * leyendo la cuenta, y entre medio hubiera ocurrido otro retiro, el comprobante repetido mostraria
 * una cifra distinta a la del original.
 *
 * <p>Los cuatro nombres de campo estan congelados en el contrato y el canal cajero los reenvia tal
 * cual, agregandoles su propio {@code desglose} de billetes. El core no sabe de billetes: las
 * denominaciones son configuracion del canal, no dominio del banco.
 *
 * @param folio          identificador unico y estable de la operacion
 * @param saldoAnterior  saldo que tenia la cuenta antes del descuento
 * @param montoRetirado  importe efectivamente retirado
 * @param saldoPosterior saldo que quedo despues del descuento
 */
public record ResultadoRetiro(
        String folio,
        BigDecimal saldoAnterior,
        BigDecimal montoRetirado,
        BigDecimal saldoPosterior) {

    /**
     * Constructor compacto: lleva los tres importes a dos decimales.
     *
     * <p>El saldo anterior y el posterior vienen de la cuenta, que ya los guarda con esa escala,
     * pero el monto viene del <em>cuerpo de la peticion</em>: si el cliente escribio {@code 3000},
     * Jackson lo entrega con escala cero y el comprobante saldria con dos importes escritos
     * {@code 12000.00} y uno escrito {@code 3000}, en el mismo objeto JSON. No es un error de
     * calculo (el dinero es el mismo), pero es una incoherencia visible que obliga a cada
     * consumidor a normalizar por su cuenta. Normalizar en la frontera del dominio es mas barato
     * que pedirle a todos los clientes que lo hagan.
     */
    public ResultadoRetiro {
        saldoAnterior = escala(saldoAnterior);
        montoRetirado = escala(montoRetirado);
        saldoPosterior = escala(saldoPosterior);
    }

    private static BigDecimal escala(BigDecimal importe) {
        return importe == null ? null : importe.setScale(2, java.math.RoundingMode.HALF_UP);
    }
}
