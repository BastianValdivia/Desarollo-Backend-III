package cl.duoc.bancoxyz.core.dominio.error;

import java.math.BigDecimal;

/**
 * Se intento retirar mas dinero del que la cuenta tiene.
 *
 * <p>Rol en la arquitectura: es la salvaguarda final del saldo, y se lanza desde
 * {@code Cuenta.conRetiro}, es decir <strong>dentro</strong> de la operacion atomica. Esa
 * ubicacion es lo que hace imposible el escenario clasico de dos retiros simultaneos que juntos
 * dejan el saldo negativo: la comprobacion no ocurre antes de la mutacion, ocurre como parte
 * indivisible de ella.
 *
 * <p>Se traduce a <strong>409 Conflict</strong> con motivo {@code saldo_insuficiente}. El codigo
 * 409 y no 400: la peticion esta perfectamente bien formada y el monto es valido; lo que falla es
 * el <em>estado</em> de la cuenta en este instante. La misma peticion, hecha despues de un
 * deposito, funcionaria sin cambiar una coma.
 *
 * <p>El caso de demostracion congelado es la cuenta 106, con saldo 5.000, intentando retirar
 * 8.000: ese monto pasa a proposito las validaciones de multiplo, minimo y tope del canal cajero,
 * de modo que la evidencia prueba el saldo y no otra cosa.
 */
public class SaldoInsuficienteException extends ExcepcionNegocio {

    private final int cuentaId;
    private final BigDecimal saldoDisponible;
    private final BigDecimal montoSolicitado;

    public SaldoInsuficienteException(int cuentaId, BigDecimal saldoDisponible, BigDecimal montoSolicitado) {
        super("saldo_insuficiente",
                "La cuenta " + cuentaId + " no tiene saldo suficiente para retirar " + montoSolicitado.toPlainString());
        this.cuentaId = cuentaId;
        this.saldoDisponible = saldoDisponible;
        this.montoSolicitado = montoSolicitado;
    }

    public int cuentaId() {
        return cuentaId;
    }

    /**
     * Saldo que habia al momento del rechazo.
     *
     * <p>Se guarda para poder registrarlo en el log del core, <strong>no</strong> para devolverlo
     * en el cuerpo del error: el canal cajero omite el campo {@code detail} precisamente para no
     * exponer cifras en una pantalla que esta en la via publica.
     */
    public BigDecimal saldoDisponible() {
        return saldoDisponible;
    }

    public BigDecimal montoSolicitado() {
        return montoSolicitado;
    }
}
