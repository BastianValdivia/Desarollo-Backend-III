package cl.duoc.bancoxyz.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Punto de entrada del <strong>core-service</strong>, el backend de dominio del Banco XYZ.
 *
 * <p>Este servicio <em>no</em> es un BFF y no debe confundirse con uno. Su papel en la
 * arquitectura es ser el <strong>dueno unico del estado</strong>: lee los CSV de semilla al
 * arrancar, consolida las 50 cuentas canonicas y las mantiene en memoria. Los tres BFF
 * (web, movil y cajero) le consultan por HTTP y ninguno guarda su propia copia de los datos.
 *
 * <p>Por que un unico dueno del estado y no un CSV por canal: el retiro por cajero
 * <strong>muta el saldo</strong>. Con copias separadas, un retiro hecho desde el cajero seria
 * invisible desde la web y desde el movil, y la demostracion de consistencia entre canales,
 * que es el corazon del proyecto, se caeria.
 *
 * <p>Su frontera de red es deliberadamente estrecha y se configura en
 * {@code config-repo/core-service.yml}: escucha en el puerto 8080 <strong>atado a 127.0.0.1</strong>, de
 * modo que no es alcanzable desde fuera del computador. Sus rutas empiezan por
 * {@code /internal/v1} y no por {@code /api}, para que cualquier linea de evidencia deje claro
 * por si sola que se trata del servicio interno y no de un canal. Desde la fase F4 es ademas un
 * <strong>servidor de recursos OAuth2</strong>: todo {@code /internal/**} exige el token de servicio que
 * el auth-server entrego al BFF que llama, con el scope del endpoint (ver
 * {@code seguridad.SeguridadCoreConfig}).
 *
 * <p>Esta clase queda intencionalmente sin logica. En Spring Boot la clase principal es solo el
 * disparador: toda la funcionalidad vive en beans que el contenedor descubre por escaneo.
 * Poner logica aqui la haria imposible de probar de forma aislada.
 */
@SpringBootApplication
/*
 * Por que esta segunda anotacion existe desde el primer dia, aunque hoy no haya ninguna clase
 * de propiedades todavia:
 *
 * @SpringBootApplication incluye el escaneo de COMPONENTES (@Service, @Component, @RestController)
 * pero NO incluye el escaneo de PROPIEDADES. Una clase anotada solo con @ConfigurationProperties
 * no se registra como bean, y la aplicacion muere al arrancar con un mensaje del tipo
 * "Parameter 0 of constructor ... required a bean of type '...Properties' that could not be found",
 * que no apunta a la causa real.
 *
 * Agregarla ahora, vacia de efecto, cuesta una linea. Agregarla despues cuesta una sesion de
 * depuracion a ciegas justo cuando se esta externalizando el primer valor de configuracion.
 */
@ConfigurationPropertiesScan("cl.duoc.bancoxyz.core")
public class CoreServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoreServiceApplication.class, args);
    }
}
