package cl.duoc.bancoxyz.core.seguridad;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.server.resource.web.access.BearerTokenAccessDeniedHandler;
import org.springframework.security.oauth2.server.resource.web.BearerTokenAuthenticationEntryPoint;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import cl.duoc.bancoxyz.core.api.dto.RespuestaErrorCore;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Responde los rechazos de seguridad del core con el mismo cuerpo {@code application/problem+json}
 * (RFC 7807) que el resto de su API, mas la cabecera {@code WWW-Authenticate} que exige el estandar de
 * portadores (RFC 6750).
 *
 * <h2>Por que a mano y no con lo que trae Spring Security</h2>
 *
 * <p>Los rechazos ocurren en la cadena de filtros, antes de que la peticion llegue a ningun
 * controlador, asi que el {@code @RestControllerAdvice} del core no participa. El comportamiento por
 * defecto de Spring Security responde con la cabecera y <em>sin cuerpo</em>: correcto para el
 * protocolo, pero distinto de todo lo demas que devuelve este servicio, y justo en el escenario que
 * demuestra que la proteccion funciona. Aqui se delega la cabecera en las clases estandar
 * ({@link BearerTokenAuthenticationEntryPoint}, {@link BearerTokenAccessDeniedHandler}) y solo se
 * agrega el cuerpo.
 *
 * <h2>Los dos casos, y por que son codigos distintos</h2>
 *
 * <ul>
 *   <li><strong>401</strong>: el core no sabe quien llama. No trajo token ({@code token_ausente}) o
 *       trajo uno que no sirve ({@code token_invalido}): mal firmado, vencido, de otro emisor o con
 *       una audiencia que no es este servicio. Repetir la llamada con el mismo token no cambia nada.</li>
 *   <li><strong>403</strong>: el core sabe quien llama (el token es valido) y no se lo permite
 *       ({@code permiso_insuficiente}): al token le falta el scope del endpoint. Es el caso de un token
 *       del BFF web intentando un retiro.</li>
 * </ul>
 *
 * <p>El cuerpo nunca dice <em>por que</em> fallo la validacion (que claim, que fecha): esa informacion
 * le sirve a quien quiera fabricar un token aceptable. El motivo concreto se deja en el log del
 * servidor, donde lo ve quien opera el sistema.
 */
@Component
public class ManejadorSeguridadCore implements AuthenticationEntryPoint, AccessDeniedHandler {

    private static final Logger log = LoggerFactory.getLogger(ManejadorSeguridadCore.class);

    private final ObjectMapper objectMapper;
    private final BearerTokenAuthenticationEntryPoint cabecera401 = new BearerTokenAuthenticationEntryPoint();
    private final BearerTokenAccessDeniedHandler cabecera403 = new BearerTokenAccessDeniedHandler();

    /**
     * @param objectMapper el mismo de la aplicacion, para que este cuerpo se serialice igual que los
     *                     demas errores de la API
     */
    public ManejadorSeguridadCore(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public void commence(HttpServletRequest peticion, HttpServletResponse respuesta,
                         AuthenticationException excepcion) throws IOException {
        // "No trajo token" y "trajo uno invalido" son diagnosticos distintos: lo primero suele ser un
        // script al que se le olvido la cabecera, lo segundo un token que el core no acepta.
        boolean tokenInvalido = excepcion instanceof OAuth2AuthenticationException;
        String motivo = tokenInvalido ? "token_invalido" : "token_ausente";
        String detalle = tokenInvalido
                ? "El token presentado no es valido para este servicio"
                : "Falta el token de acceso: se espera Authorization: Bearer <token>";

        log.warn("Acceso rechazado a {} {}: {} ({})", peticion.getMethod(), peticion.getRequestURI(),
                motivo, tokenInvalido ? excepcion.getMessage() : "sin credencial");

        cabecera401.commence(peticion, respuesta, excepcion);
        escribir(respuesta, HttpStatus.UNAUTHORIZED, "Token de servicio requerido", motivo, detalle,
                peticion.getRequestURI());
    }

    @Override
    public void handle(HttpServletRequest peticion, HttpServletResponse respuesta,
                       AccessDeniedException excepcion) throws IOException {
        Authentication autenticacion = SecurityContextHolder.getContext().getAuthentication();
        log.warn("Permiso insuficiente en {} {}: el cliente '{}' tiene {}", peticion.getMethod(),
                peticion.getRequestURI(), autenticacion == null ? "?" : autenticacion.getName(),
                autenticacion == null ? "[]" : autenticacion.getAuthorities());

        cabecera403.handle(peticion, respuesta, excepcion);
        escribir(respuesta, HttpStatus.FORBIDDEN, "Permiso insuficiente", "permiso_insuficiente",
                "El token es valido pero no tiene el permiso que exige este recurso",
                peticion.getRequestURI());
    }

    private void escribir(HttpServletResponse respuesta, HttpStatus estado, String titulo, String motivo,
                          String detalle, String ruta) throws IOException {
        respuesta.setStatus(estado.value());
        respuesta.setContentType(MediaType.APPLICATION_PROBLEM_JSON_VALUE);
        respuesta.setCharacterEncoding(StandardCharsets.UTF_8.name());
        objectMapper.writeValue(respuesta.getOutputStream(),
                RespuestaErrorCore.de(estado, titulo, motivo, detalle, ruta));
    }
}
