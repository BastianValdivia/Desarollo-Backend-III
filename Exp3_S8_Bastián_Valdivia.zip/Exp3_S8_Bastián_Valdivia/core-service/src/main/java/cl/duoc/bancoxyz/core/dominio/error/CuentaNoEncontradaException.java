package cl.duoc.bancoxyz.core.dominio.error;

/**
 * Se pidio una cuenta que no existe en el banco.
 *
 * <p>Rol en la arquitectura: es el unico camino por el que el core produce un 404. Las cuentas
 * canonicas son exactamente 50, con identificadores del 101 al 150; cualquier otro numero llega
 * aqui.
 *
 * <p><strong>Distincion que se implementa mal con frecuencia.</strong> Este 404 significa "el
 * recurso no existe". No debe usarse para "el recurso existe pero no es tuyo": eso es un 403 con
 * motivo {@code cuenta_ajena} y se resuelve en el BFF, que es quien conoce la identidad del
 * cliente. El core no sabe quien pregunta, solo que le hablo alguien con la credencial de
 * servicio, asi que no puede ni debe decidir sobre titularidad.
 */
public class CuentaNoEncontradaException extends ExcepcionNegocio {

    private final int cuentaId;

    public CuentaNoEncontradaException(int cuentaId) {
        super("recurso_no_encontrado", "No existe la cuenta " + cuentaId);
        this.cuentaId = cuentaId;
    }

    public int cuentaId() {
        return cuentaId;
    }
}
