package cl.duoc.bancoxyz.core.adaptador;

import java.time.LocalDate;
import java.util.List;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import cl.duoc.bancoxyz.core.dominio.Pagina;
import cl.duoc.bancoxyz.core.dominio.TransaccionNoConciliada;
import cl.duoc.bancoxyz.core.puerto.LoteNoConciliadoRepository;

/**
 * <strong>Adaptador</strong> de {@link LoteNoConciliadoRepository} sobre la tabla
 * {@code transaccion_no_conciliada}.
 *
 * <p>El lote se escribe una sola vez (migracion V2) y despues solo se lee, asi que no hay nada que
 * proteger de la concurrencia: una consulta paginada con {@code LIMIT/OFFSET} sobre la columna
 * {@code orden}, que conserva el orden del archivo. Una pagina mas alla del final devuelve una lista
 * vacia, no un error (el mismo comportamiento que la version en memoria).
 */
@Repository
public class LoteNoConciliadoRepositoryJdbc implements LoteNoConciliadoRepository {

    private final JdbcClient jdbc;

    public LoteNoConciliadoRepositoryJdbc(JdbcClient jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public Pagina<TransaccionNoConciliada> paginar(int pagina, int tamano) {
        // El desplazamiento se calcula en long: pagina * tamano puede desbordar un int si el cliente
        // pide una pagina absurda, y un desbordamiento daria un OFFSET negativo y un error 500.
        long desde = (long) pagina * tamano;

        List<TransaccionNoConciliada> contenido = jdbc.sql("""
                        SELECT id, fecha, monto, tipo_crudo
                          FROM transaccion_no_conciliada
                         ORDER BY orden
                         LIMIT :tamano OFFSET :desde""")
                .param("tamano", tamano)
                .param("desde", desde)
                .query((rs, fila) -> new TransaccionNoConciliada(
                        rs.getLong("id"),
                        rs.getObject("fecha", LocalDate.class),
                        rs.getBigDecimal("monto"),
                        rs.getString("tipo_crudo")))
                .list();

        return new Pagina<>(List.copyOf(contenido), pagina, tamano, total());
    }

    @Override
    public int total() {
        return jdbc.sql("SELECT count(*) FROM transaccion_no_conciliada").query(Integer.class).single();
    }
}
