package cl.duoc.bancoxyz.core.dominio;

import java.util.List;

/**
 * Un trozo de una coleccion grande, con los datos que el cliente necesita para pedir el siguiente.
 *
 * <p>Rol en la arquitectura: es el tipo que devuelven las consultas paginadas del dominio, para
 * que el controlador no tenga que calcular indices ni totales. Se escribe a mano, sin usar
 * {@code org.springframework.data.domain.Page}, por dos razones: el proyecto no incluye Spring
 * Data (no hay base de datos, el estado vive en un mapa en memoria), y el JSON que produce
 * {@code Page} trae una quincena de campos con nombres en ingles que no son los que congela el
 * contrato.
 *
 * <p>Los cuatro campos de paginacion del contrato ({@code pagina}, {@code tamano},
 * {@code totalElementos}, {@code totalPaginas}) se derivan directamente de este record en el DTO
 * de salida.
 *
 * @param contenido      los elementos de esta pagina; nunca nulo, puede venir vacio
 * @param pagina         indice de la pagina, <strong>empezando en cero</strong>
 * @param tamano         cuantos elementos se pidieron por pagina
 * @param totalElementos cuantos elementos hay en total, no solo en esta pagina
 * @param <T>            tipo de los elementos
 */
public record Pagina<T>(List<T> contenido, int pagina, int tamano, long totalElementos) {

    /**
     * Cuantas paginas hacen falta para recorrer todos los elementos.
     *
     * <p>Es una division con redondeo hacia arriba escrita sin numeros con coma: 42 elementos de a
     * 20 son 3 paginas y no 2,1. Se calcula aqui en vez de guardarse como campo para que no pueda
     * quedar desincronizado con {@code totalElementos}.
     */
    public int totalPaginas() {
        if (tamano <= 0) {
            return 0;
        }
        return (int) ((totalElementos + tamano - 1) / tamano);
    }
}
