package cl.duoc.bancoxyz.core.seguridad;

import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.security.oauth2.resource.servlet.JwkSetUriJwtDecoderBuilderCustomizer;
import org.springframework.boot.ssl.NoSuchSslBundleException;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.boot.web.client.ClientHttpRequestFactories;
import org.springframework.boot.web.client.ClientHttpRequestFactorySettings;
import org.springframework.cache.Cache;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * Hace que el core descargue las claves del auth-server (JWKS) por HTTPS confiando en la CA interna.
 *
 * <p>En contenedores, {@code jwk-set-uri} vale {@code https://auth-server:9000/oauth2/jwks} y el
 * certificado del auth-server lo firma la CA interna del proyecto, que la JVM no conoce. Si existe el
 * bundle SSL {@code interna} ({@code spring.ssl.bundle.jks.interna.truststore.*}, un truststore con
 * <em>solo</em> esa CA) la descarga lo usa: el core confia en el auth-server de este despliegue y en
 * nada mas, sin desactivar la verificacion ni tocar el almacen de la JVM. Sin bundle (JVM locales, donde
 * el auth-server habla HTTP) usa la configuracion normal.
 *
 * <p>Se engancha a la autoconfiguracion de Spring Boot con su punto de extension
 * ({@link JwkSetUriJwtDecoderBuilderCustomizer}) en vez de declarar un {@code JwtDecoder} propio, para
 * que el emisor y la audiencia sigan validandose con las propiedades estandar
 * ({@code issuer-uri} y {@code audiences}) y no con codigo a medida. Con {@code jwk-set-uri} e
 * {@code issuer-uri} juntos, Boot no hace descubrimiento OIDC (no llama a
 * {@code /.well-known/openid-configuration}): usa la direccion de las claves tal cual y solo compara el
 * emisor contra el claim {@code iss}. Eso es lo que permite que el emisor sea {@code https://localhost:9000}
 * (el que ven los clientes) mientras las claves se leen por {@code https://auth-server:9000}. Lo prueba
 * {@code SeguridadOAuth2CoreTest}.
 *
 * <p>La descarga lleva tiempos de espera propios: un auth-server colgado no debe dejar hilos del core
 * esperando. Las claves se guardan en una cache SIN vencimiento y solo se vuelven a descargar ante un
 * {@code kid} desconocido, de modo que una caida del auth-server (de cualquier duracion) no impide validar
 * tokens de claves ya conocidas ni hace esperar a cada peticion el timeout de la descarga. Lo comprueba
 * {@code ConfianzaEnElAuthServerConfigTest}.
 */
@Configuration(proxyBeanMethods = false)
public class ConfianzaEnElAuthServerConfig {

    private static final Logger log = LoggerFactory.getLogger(ConfianzaEnElAuthServerConfig.class);

    /** Nombre del bundle SSL con la CA interna, igual en el core y en los BFF. */
    static final String BUNDLE_DE_CONFIANZA = "interna";

    @Bean
    public JwkSetUriJwtDecoderBuilderCustomizer descargaDeClavesConLaCaInterna(
            SslBundles bundles,
            @Value("${seguridad.jwks.timeout-conexion:2s}") Duration timeoutConexion,
            @Value("${seguridad.jwks.timeout-lectura:2s}") Duration timeoutLectura) {

        ClientHttpRequestFactorySettings ajustes = ClientHttpRequestFactorySettings.DEFAULTS
                .withConnectTimeout(timeoutConexion)
                .withReadTimeout(timeoutLectura);
        try {
            ajustes = ajustes.withSslBundle(bundles.getBundle(BUNDLE_DE_CONFIANZA));
            log.info("La descarga de claves del auth-server confia solo en la CA del bundle '{}'",
                    BUNDLE_DE_CONFIANZA);
        } catch (NoSuchSslBundleException sinBundle) {
            log.info("Sin bundle SSL '{}': la descarga de claves usa la configuracion normal de la JVM",
                    BUNDLE_DE_CONFIANZA);
        }
        RestTemplate http = new RestTemplate(ClientHttpRequestFactories.get(ajustes));

        // F6: las claves se guardan en una cache SIN vencimiento. Sin esto, Spring Security conserva el JWKS 5 minutos y
        // despues lo vuelve a descargar ANTES de validar el token: con el auth-server caido, cada peticion esperaba el
        // timeout de la descarga (2 s) y los BFF vencian su propio timeout de lectura (medido con
        // scripts/caos/auth-server-caido.sh: replicas del core con 2.011 ms por peticion). Con esta cache la descarga
        // ocurre una vez y solo se repite ante un kid desconocido (rotacion de claves), que es lo que la clase siempre
        // dijo que hacia. Una cache de Spring usada como objeto: no requiere @EnableCaching.
        Cache cacheDeClaves = new ConcurrentMapCache("jwks-auth-server");
        return constructor -> constructor.restOperations(http).cache(cacheDeClaves);
    }
}
