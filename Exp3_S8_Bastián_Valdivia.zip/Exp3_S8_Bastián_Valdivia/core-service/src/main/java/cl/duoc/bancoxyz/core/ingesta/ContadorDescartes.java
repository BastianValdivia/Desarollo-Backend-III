package cl.duoc.bancoxyz.core.ingesta;

import java.util.EnumMap;
import java.util.Map;

import cl.duoc.bancoxyz.core.dominio.MotivoDescarte;

/**
 * Lleva la cuenta de cuantos valores ignoro la ingesta y por que motivo.
 *
 * <p>Rol en la arquitectura: es el cuaderno de la ingesta. Existe para que el reporte de calidad
 * publique numeros <strong>medidos en vivo</strong> en vez de cifras escritas a mano en un
 * documento, que es la diferencia entre una afirmacion comprobable y una que hay que creer.
 *
 * <p><strong>Por que un {@link EnumMap} y no un {@code HashMap}.</strong> Un {@code EnumMap} se
 * apoya en que las claves son un enumerado: por dentro es un arreglo indexado por la posicion de
 * cada constante, asi que no calcula codigos hash ni resuelve colisiones, y ademas itera siempre en
 * el orden de declaracion del enumerado. Ese orden estable es lo que hace que el JSON del reporte
 * salga igual en cada arranque, que es lo que permite compararlo entre ejecuciones.
 *
 * <p>Las cinco claves se inicializan en cero en el constructor, no a medida que aparecen. El
 * contrato exige que las cinco esten presentes <em>aunque valgan cero</em>, y un motivo ausente se
 * leeria como "esto no se midio" cuando en realidad significa "esto no ocurrio nunca", que es una
 * afirmacion mucho mas fuerte y que conviene poder hacer.
 *
 * <p>No es una clase pensada para varios hilos: la ingesta corre una sola vez, en el hilo de
 * arranque, antes de que exista la primera peticion HTTP. Anadirle sincronizacion seria pagar por
 * un problema que no existe.
 */
public class ContadorDescartes {

    private final Map<MotivoDescarte, Integer> conteo = new EnumMap<>(MotivoDescarte.class);

    public ContadorDescartes() {
        for (MotivoDescarte motivo : MotivoDescarte.values()) {
            conteo.put(motivo, 0);
        }
    }

    /** Registra que un valor mas se ignoro por este motivo. */
    public void anotar(MotivoDescarte motivo) {
        conteo.merge(motivo, 1, Integer::sum);
    }

    public int cuantos(MotivoDescarte motivo) {
        return conteo.get(motivo);
    }

    /** Copia inmutable para publicar en el reporte, de modo que nadie pueda alterarla despues. */
    public Map<MotivoDescarte, Integer> instantanea() {
        return Map.copyOf(conteo);
    }
}
