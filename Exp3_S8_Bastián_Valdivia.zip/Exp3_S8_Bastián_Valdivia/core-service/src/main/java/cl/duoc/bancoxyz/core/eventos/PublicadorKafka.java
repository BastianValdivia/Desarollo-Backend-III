package cl.duoc.bancoxyz.core.eventos;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

/**
 * Entrega un lote de eventos a Kafka y dice cuantos, EN ORDEN, quedaron confirmados.
 *
 * <p>Es la frontera con Kafka y por eso lleva la proteccion de Resilience4j (instancia {@code kafka},
 * configurada en {@code config-repo/config-repo/core-service.yml}):
 *
 * <ul>
 *   <li><strong>Retry</strong>: un fallo pasajero (cambio de lider, reconexion) se reintenta de inmediato
 *       antes de rendirse hasta el ciclo siguiente.</li>
 *   <li><strong>CircuitBreaker</strong>: con Kafka caido, cada intento esperaria varios segundos. Tras
 *       unos fallos el circuito se abre y el relay deja de intentarlo (el rechazo es instantaneo) hasta
 *       que una llamada de prueba confirme que Kafka volvio. Sin el, el relay pasaria el dia esperando
 *       plazos y manteniendo abierta una transaccion.</li>
 *   <li><strong>Respaldo</strong>: es el propio outbox. Un fallo no pierde nada; el evento sigue pendiente
 *       y se entrega cuando el circuito se cierre.</li>
 * </ul>
 *
 * <p><strong>Por que devuelve un conteo y no lanza ante el primer fallo.</strong> Los envios son
 * asincronos y se agrupan en lotes del productor. Si los 40 primeros se confirmaron y el 41 fallo, los 40
 * ya estan en Kafka: hay que marcarlos como publicados, o se republicarian. Se devuelve el largo del
 * prefijo confirmado y el relay marca exactamente ese prefijo (el orden se corta en el primer fallo: un
 * evento posterior confirmado se republicara, nunca se salta uno anterior). Solo cuando NO se confirmo
 * ninguno se lanza {@link KafkaNoDisponibleException}, que es lo que Retry y CircuitBreaker miran.
 */
@Component
@ConditionalOnProperty(name = "eventos.relay.habilitado", havingValue = "true")
public class PublicadorKafka {

    private final KafkaTemplate<String, String> kafka;
    private final EventosProperties propiedades;

    public PublicadorKafka(KafkaTemplate<String, String> kafka, EventosProperties propiedades) {
        this.kafka = kafka;
        this.propiedades = propiedades;
    }

    /**
     * @param lote eventos en orden de publicacion
     * @return cuantos, desde el primero, confirmo Kafka (con {@code acks=all})
     * @throws KafkaNoDisponibleException si no se confirmo ni el primero
     */
    @Retry(name = "kafka")
    @CircuitBreaker(name = "kafka")
    public int publicar(List<EventoPendiente> lote) {
        List<CompletableFuture<?>> envios = new ArrayList<>(lote.size());
        Throwable fallo = null;

        for (EventoPendiente evento : lote) {
            try {
                ProducerRecord<String, String> registro =
                        new ProducerRecord<>(evento.topico(), evento.clave(), evento.payload());
                // Cabecera con el id del evento: kafka-ui y los consumidores pueden identificarlo sin parsear.
                registro.headers().add("eventId", evento.eventId().getBytes(StandardCharsets.UTF_8));
                envios.add(kafka.send(registro));
            } catch (RuntimeException e) {
                // Por ejemplo: no se puede construir el productor (el nombre "kafka" no resuelve) o se agoto
                // max.block.ms esperando metadatos. Lo ya enviado se espera abajo.
                fallo = e;
                break;
            }
        }
        kafka.flush();

        int confirmados = 0;
        long limite = System.nanoTime() + propiedades.relay().plazoEnvio().toNanos();
        for (CompletableFuture<?> envio : envios) {
            try {
                envio.get(Math.max(1, limite - System.nanoTime()), TimeUnit.NANOSECONDS);
                confirmados++;
            } catch (ExecutionException | TimeoutException e) {
                fallo = e.getCause() != null ? e.getCause() : e;
                break;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                fallo = e;
                break;
            }
        }

        if (confirmados == 0 && fallo != null) {
            throw new KafkaNoDisponibleException("Kafka no confirmo ningun evento del lote de " + lote.size(), fallo);
        }
        return confirmados;
    }
}
