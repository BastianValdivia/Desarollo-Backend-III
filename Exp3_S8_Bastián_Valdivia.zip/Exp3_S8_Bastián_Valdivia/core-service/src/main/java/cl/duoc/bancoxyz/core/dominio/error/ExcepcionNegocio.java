package cl.duoc.bancoxyz.core.dominio.error;

/**
 * Base de las excepciones que representan una <strong>regla de negocio incumplida</strong>, por
 * oposicion a un fallo tecnico.
 *
 * <p>Rol en la arquitectura: es la frontera entre el dominio y el mundo exterior. Cada subclase
 * trae consigo un {@code motivo}, que es una palabra del vocabulario del banco congelada en el
 * contrato ({@code saldo_insuficiente}, {@code recurso_no_encontrado}...). Ese motivo es
 * exactamente el campo que los scripts de evidencia leen del cuerpo de error, y tenerlo aqui
 * dentro es lo que permite que el manejador de errores sea generico en vez de una cadena de
 * {@code instanceof}.
 *
 * <p><strong>Por que estas excepciones NO conocen su codigo HTTP.</strong> Es la decision de
 * diseno mas facil de hacer al reves. Poner un campo {@code status = 409} aqui seria comodo, y
 * ataria el dominio al protocolo: la regla "no se puede retirar mas de lo que hay" es cierta
 * tambien si manana el core se consume por mensajeria o desde una prueba unitaria, donde 409 no
 * significa nada. La traduccion de motivo a codigo HTTP es trabajo de la capa de API y vive, toda
 * junta y visible, en un unico {@code switch} del manejador de errores. Asi el dominio no importa
 * ni una clase de Spring ni de Jakarta.
 *
 * <p>Extiende {@link RuntimeException} y no {@code Exception} a proposito: una regla de negocio
 * incumplida no es algo que cada llamador intermedio deba capturar y volver a lanzar. Sube limpia
 * hasta la capa que sabe traducirla.
 */
public abstract class ExcepcionNegocio extends RuntimeException {

    private final String motivo;

    protected ExcepcionNegocio(String motivo, String mensaje) {
        super(mensaje);
        this.motivo = motivo;
    }

    /** Palabra del vocabulario congelado del contrato que identifica la regla incumplida. */
    public String motivo() {
        return motivo;
    }
}
