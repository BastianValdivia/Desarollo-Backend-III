package cl.duoc.bancoxyz.core.api.dto;

import org.springframework.http.HttpStatus;

/**
 * Cuerpo de error del core, con el formato <strong>RFC 7807</strong>
 * ({@code application/problem+json}).
 *
 * <p>Rol en la arquitectura: es la <em>unica</em> forma en que el core comunica un fallo. Que todos
 * los errores tengan la misma forma, desde el 401 del filtro hasta el 409 del saldo, es lo que
 * permite que un cliente escriba un solo camino de manejo de errores en vez de uno por endpoint.
 *
 * <p><strong>Por que RFC 7807 y no un JSON inventado.</strong> Es un estandar publicado, asi que
 * las herramientas y los clientes ya saben leerlo, y evita la discusion de si el campo se llama
 * {@code error}, {@code message} o {@code mensaje}. El tipo de contenido
 * {@code application/problem+json} avisa desde la cabecera que el cuerpo es un problema y no un
 * resultado.
 *
 * <p><strong>El campo que de verdad importa es {@code motivo}.</strong> Los otros cinco son para
 * que una persona entienda; {@code motivo} es para que un programa decida. Su valor sale de un
 * vocabulario cerrado y congelado ({@code recurso_no_encontrado}, {@code saldo_insuficiente},
 * {@code token_ausente}...), y es el campo que leen los scripts de verificacion. Un texto
 * descriptivo se puede reformular sin avisar; un motivo congelado, no.
 *
 * <p><strong>Por que el core NO incluye el campo {@code canal}.</strong> El contrato declara
 * {@code canal} con tres valores posibles: {@code WEB}, {@code MOVIL} y {@code ATM}. El core no es
 * ninguno de los tres: es el backend de dominio, y agregarle un cuarto valor inventado seria
 * ampliar por la puerta de atras un vocabulario que esta congelado. Cada BFF construye su propio
 * cuerpo de error, con su canal y con el detalle que su cliente puede ver, y usa el {@code motivo}
 * de esta respuesta como insumo para decidir cual.
 *
 * @param type     URI del catalogo de errores. Identifica la <em>clase</em> de problema, y es
 *                 estable aunque el texto cambie
 * @param title    titulo corto y estable, pensado para una persona
 * @param status   codigo HTTP. Debe coincidir con el de la respuesta real; si no coinciden, el
 *                 cliente tiene dos verdades y elige mal
 * @param detail   explicacion del caso concreto
 * @param instance la ruta que se pidio, para poder correlacionar con los registros del servidor
 * @param motivo   valor del vocabulario congelado. <strong>Es el campo que se lee por programa</strong>
 */
public record RespuestaErrorCore(
        String type,
        String title,
        int status,
        String detail,
        String instance,
        String motivo) {

    /** Base del catalogo de errores, congelada en el contrato. */
    private static final String CATALOGO = "https://bancoxyz.duoc.cl/errores/";

    /**
     * Construye el cuerpo derivando el {@code type} del propio motivo.
     *
     * <p>La URI se arma reemplazando los guiones bajos del motivo por guiones medios
     * ({@code saldo_insuficiente} produce {@code .../saldo-insuficiente}). Derivarla en vez de
     * escribirla a mano en cada sitio garantiza que los dos campos no puedan contradecirse, que es
     * el tipo de incoherencia que aparece cuando se agrega un error nuevo copiando y pegando otro.
     */
    public static RespuestaErrorCore de(HttpStatus estado, String titulo, String motivo,
                                        String detalle, String ruta) {
        return new RespuestaErrorCore(
                CATALOGO + motivo.replace('_', '-'),
                titulo,
                estado.value(),
                detalle,
                ruta,
                motivo);
    }
}
