package cl.duoc.bancoxyz.core.api.dto;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import cl.duoc.bancoxyz.core.dominio.MotivoDescarte;
import cl.duoc.bancoxyz.core.dominio.ReporteCalidad;

/**
 * Reporte de calidad de la ingesta. Respuesta de
 * {@code GET /internal/v1/admin/calidad-datos}.
 *
 * <p>Rol en la arquitectura: publica, como datos consultables en vivo, lo que la ingesta escribio
 * en el log al arrancar. Es de los recursos con mejor retorno por esfuerzo del proyecto: cuesta
 * muy poco y permite que la documentacion del sistema cite <strong>numeros reproducibles</strong>
 * en vez de cifras escritas a mano que nadie puede verificar sin abrir el codigo.
 *
 * <p><strong>Por que las cinco claves de {@code descartesPorMotivo} van siempre, incluso en
 * cero.</strong> Un motivo ausente es ambiguo: puede significar "no ocurrio" o "no se midio". Un
 * motivo presente con valor cero solo puede significar lo primero, y esa es una afirmacion mucho
 * mas fuerte. El mapa se construye recorriendo el enumerado completo, de modo que agregar un motivo
 * nuevo lo hace aparecer aqui sin tocar esta clase.
 *
 * <p>Los valores esperados sobre el dataset de referencia: {@code cuentasConsolidadas} 50,
 * {@code movimientosCargados} 686 y {@code transaccionesNoConciliadas} 1000. Si alguno no cuadra,
 * hay un error en la ingesta y este endpoint es el primer lugar donde mirarlo.
 */
public record ReporteCalidadResponse(
        String generadoEn,
        List<ArchivoResponse> archivos,
        Map<String, Integer> descartesPorMotivo,
        int cuentasConsolidadas,
        int movimientosCargados,
        int transaccionesNoConciliadas) {

    /** Lo medido sobre un archivo del dataset. */
    public record ArchivoResponse(String archivo, int filasLeidas, int filasUnicas,
                                  int duplicadasDescartadas) {
    }

    public static ReporteCalidadResponse de(ReporteCalidad reporte) {
        // LinkedHashMap para que las claves salgan siempre en el orden de declaracion del
        // enumerado: un JSON con orden estable se puede comparar entre dos ejecuciones con un
        // simple diff, y esa comparabilidad es lo que convierte al reporte en evidencia.
        Map<String, Integer> descartes = new LinkedHashMap<>();
        for (MotivoDescarte motivo : MotivoDescarte.values()) {
            descartes.put(motivo.name(), reporte.descartesPorMotivo().getOrDefault(motivo, 0));
        }

        List<ArchivoResponse> archivos = reporte.archivos().stream()
                .map(a -> new ArchivoResponse(a.archivo(), a.filasLeidas(), a.filasUnicas(),
                        a.duplicadasDescartadas()))
                .toList();

        return new ReporteCalidadResponse(
                reporte.generadoEn(),
                archivos,
                descartes,
                reporte.cuentasConsolidadas(),
                reporte.movimientosCargados(),
                reporte.transaccionesNoConciliadas());
    }
}
