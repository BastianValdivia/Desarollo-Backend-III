package cl.duoc.bancoxyz.core.eventos;

import java.time.Instant;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;

/**
 * El <strong>relay del outbox</strong>: lleva a Kafka lo que el core dejo anotado en la tabla
 * {@code outbox}, en orden, y marca lo que Kafka confirmo.
 *
 * <p>Cada ciclo ({@link #publicarPendientes()}):
 *
 * <ol>
 *   <li>Si esta replica no es la lider ({@link LiderRelay}), no hace nada.</li>
 *   <li>En una transaccion, lee los pendientes mas antiguos con {@code FOR UPDATE}: las filas quedan
 *       bloqueadas hasta el commit.</li>
 *   <li>Las entrega a Kafka ({@link PublicadorKafka}, protegido con Resilience4j) y espera la
 *       confirmacion con {@code acks=all}.</li>
 *   <li>Marca como publicadas SOLO las confirmadas, y confirma la transaccion.</li>
 * </ol>
 *
 * <p><strong>Garantias y su costo.</strong> Entrega AL MENOS UNA VEZ: si el proceso muere entre la
 * confirmacion de Kafka y el commit de la marca, el evento se publica otra vez (los consumidores lo
 * descartan por su {@code eventId}). Orden por cuenta: se publica por id ascendente, el productor es
 * idempotente (no reordena al reintentar) y la clave lleva todos los eventos de una cuenta a la misma
 * particion. El unico caso en que un evento posterior podria adelantarse a uno anterior de su misma
 * cuenta es un fallo parcial dentro de un lote (el anterior no se confirma y el posterior si): se acepta
 * y se documenta (docs/eventos.md), porque cerrarlo exigiria enviar de a uno y esperar cada ack.
 *
 * <p><strong>Por que {@code FOR UPDATE}, ademas del lider.</strong> El lock de liderazgo evita la
 * competencia en el caso normal; el bloqueo de filas la hace imposible aun en el caso anormal. Si dos
 * relays leyeran a la vez, el segundo espera al commit del primero, vuelve a evaluar el filtro
 * {@code publicado IS NULL}, ve las filas ya marcadas y las salta: no duplica y no desordena.
 *
 * <p>Cuando Kafka no esta, el ciclo termina sin marcar nada y la transaccion se deshace: el evento sigue
 * pendiente y se entrega cuando vuelva. El retiro nunca depende de esto: ya esta confirmado.
 */
public class RelayOutbox {

    private static final Logger log = LoggerFactory.getLogger(RelayOutbox.class);

    private final JdbcClient jdbc;
    private final TransactionTemplate transaccion;
    private final LiderRelay lider;
    private final PublicadorKafka publicador;
    private final EventosProperties.Relay configuracion;

    /** Para avisar una sola vez cuando Kafka se cae y cuando vuelve, en vez de una linea por ciclo. */
    private volatile boolean kafkaCaido;
    private volatile Instant ultimaLimpieza = Instant.EPOCH;

    public RelayOutbox(JdbcClient jdbc, PlatformTransactionManager gestorTransacciones, LiderRelay lider,
                       PublicadorKafka publicador, EventosProperties propiedades) {
        this.jdbc = jdbc;
        this.transaccion = new TransactionTemplate(gestorTransacciones);
        this.lider = lider;
        this.publicador = publicador;
        this.configuracion = propiedades.relay();
    }

    /**
     * Un ciclo del relay.
     *
     * @return cuantos eventos se publicaron y marcaron en este ciclo (0 si no es lider, no hay nada
     *         pendiente o Kafka no respondio)
     */
    public int publicarPendientes() {
        if (!lider.esLider()) {
            return 0;
        }
        try {
            Integer publicados = transaccion.execute(estado -> publicarLote());
            avisarSiKafkaVolvio(publicados == null ? 0 : publicados);
            limpiarPublicadosAntiguos();
            return publicados == null ? 0 : publicados;
        } catch (CallNotPermittedException e) {
            // El circuito esta abierto: Kafka sigue caido y ni siquiera se intento. Es lo esperado.
            avisarSiKafkaCayo("circuito abierto", e);
            return 0;
        } catch (KafkaNoDisponibleException e) {
            avisarSiKafkaCayo(e.getMessage(), e);
            return 0;
        } catch (RuntimeException e) {
            // Un error de base de datos u otro imprevisto: el ciclo se pierde, el siguiente reintenta.
            log.error("Relay del outbox: ciclo fallido ({}). Los eventos siguen pendientes.", e.toString());
            return 0;
        }
    }

    private int publicarLote() {
        List<EventoPendiente> lote = jdbc.sql("""
                        SELECT id, event_id, topico, clave, payload
                          FROM outbox
                         WHERE publicado IS NULL
                         ORDER BY id
                         LIMIT :lote
                           FOR UPDATE""")
                .param("lote", configuracion.lote())
                .query((rs, fila) -> new EventoPendiente(rs.getLong("id"), rs.getString("event_id"),
                        rs.getString("topico"), rs.getString("clave"), rs.getString("payload")))
                .list();
        if (lote.isEmpty()) {
            return 0;
        }

        int confirmados = publicador.publicar(lote);

        List<Long> ids = lote.subList(0, confirmados).stream().map(EventoPendiente::id).toList();
        if (!ids.isEmpty()) {
            jdbc.sql("UPDATE outbox SET publicado = now() WHERE id IN (:ids)").param("ids", ids).update();
            log.info("Relay del outbox: {} evento(s) publicado(s) (ids {} a {}, topico {}).", ids.size(),
                    ids.get(0), ids.get(ids.size() - 1), lote.get(0).topico());
        }
        return ids.size();
    }

    private void avisarSiKafkaCayo(String motivo, Exception e) {
        if (!kafkaCaido) {
            kafkaCaido = true;
            log.warn("Relay del outbox: Kafka no responde ({}). Los eventos quedan en el outbox y se entregaran "
                    + "cuando vuelva.", motivo);
        } else {
            log.debug("Relay del outbox: Kafka sigue sin responder.", e);
        }
    }

    private void avisarSiKafkaVolvio(int publicados) {
        if (kafkaCaido && publicados > 0) {
            kafkaCaido = false;
            log.info("Relay del outbox: Kafka volvio; entregando lo pendiente.");
        }
    }

    /**
     * Borra las filas ya publicadas mas viejas que la retencion. Corre como maximo una vez por minuto:
     * es mantenimiento, no trabajo de cada ciclo.
     */
    private void limpiarPublicadosAntiguos() {
        Instant ahora = Instant.now();
        if (ahora.isBefore(ultimaLimpieza.plusSeconds(60))) {
            return;
        }
        ultimaLimpieza = ahora;
        int borradas = jdbc.sql("""
                        DELETE FROM outbox
                         WHERE publicado IS NOT NULL
                           AND publicado < now() - make_interval(secs => :segundos)""")
                .param("segundos", (double) configuracion.retencion().toSeconds())
                .update();
        if (borradas > 0) {
            log.info("Relay del outbox: {} fila(s) publicadas hace mas de {} borradas.", borradas,
                    configuracion.retencion());
        }
    }
}
