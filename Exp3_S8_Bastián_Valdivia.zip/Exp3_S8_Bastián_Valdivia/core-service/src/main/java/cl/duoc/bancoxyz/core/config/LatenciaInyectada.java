package cl.duoc.bancoxyz.core.config;

import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * La latencia que el core agrega a cada peticion {@code /internal/**}, leida de la propiedad
 * {@code caos.latencia-ms} de {@code config-repo/core-service.yml}. Vale 0 por defecto: en operacion
 * normal esta clase no hace nada.
 *
 * <h2>Para que existe</h2>
 *
 * <p>Es la herramienta para demostrar con numeros el comportamiento de los BFF ante un core LENTO (el
 * cortacircuitos que abre por llamadas lentas, el mamparo que rechaza lo que excede su limite, los
 * timeouts de lectura), que es distinto de un core CAIDO y no se consigue deteniendo un contenedor. Los
 * scripts de {@code scripts/caos/} cambian el valor en {@code config-repo/}, llaman a
 * {@code POST /actuator/refresh} en cada replica y lo vuelven a dejar en 0.
 *
 * <h2>Por que {@code @RefreshScope}</h2>
 *
 * <p>Un bean de este ambito se destruye con cada {@code refresh} y se vuelve a crear, leyendo otra vez
 * la propiedad, la proxima vez que alguien lo usa. Por eso el cambio se activa sin reiniciar el core. Un
 * {@code @ConfigurationProperties} de tipo {@code record} no sirve para esto: ya se vio en F1 que el
 * refresh no reconstruye los records, que quedan con el valor del arranque.
 *
 * <h2>Limites que lo mantienen inofensivo</h2>
 * <ul>
 *   <li>Solo afecta a {@code /internal/**} (ver {@link LatenciaInyectadaFilter}); el puerto de gestion y
 *       los healthchecks nunca se frenan.</li>
 *   <li>Se acota a {@value #MAXIMO_MS} ms: un valor absurdo en el YAML no puede dejar al core colgado
 *       para siempre.</li>
 *   <li>Si es mayor que 0, deja un WARN al crearse, para que no pase desapercibido en el log.</li>
 * </ul>
 */
@Component
@RefreshScope
public class LatenciaInyectada {

    /** Tope de la latencia inyectable, en milisegundos. */
    public static final long MAXIMO_MS = 30_000;

    private static final Logger log = LoggerFactory.getLogger(LatenciaInyectada.class);

    private final Duration latencia;

    public LatenciaInyectada(@Value("${caos.latencia-ms:0}") long milisegundos) {
        long acotada = Math.max(0, Math.min(milisegundos, MAXIMO_MS));
        this.latencia = Duration.ofMillis(acotada);
        if (acotada > 0) {
            log.warn("LATENCIA INYECTADA: cada peticion a /internal/** espera {} ms (caos.latencia-ms). "
                    + "Es una herramienta de demostracion; en operacion normal vale 0.", acotada);
        } else {
            log.info("Sin latencia inyectada (caos.latencia-ms = 0).");
        }
    }

    /** La espera que se aplica a cada peticion; {@link Duration#ZERO} si no hay caos. */
    public Duration latencia() {
        return latencia;
    }
}
