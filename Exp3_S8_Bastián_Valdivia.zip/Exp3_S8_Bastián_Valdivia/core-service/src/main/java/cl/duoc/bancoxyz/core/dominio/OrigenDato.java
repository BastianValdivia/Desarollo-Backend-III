package cl.duoc.bancoxyz.core.dominio;

/**
 * Procedencia de un {@link Movimiento} dentro del historial de una cuenta.
 *
 * <p>Rol en la arquitectura: permite distinguir, mirando un solo campo, lo que el sistema
 * <em>sembro</em> al arrancar de lo que <em>genero</em> mientras corria. Sin este enumerado, un
 * retiro hecho por el cajero durante la demostracion seria indistinguible de una fila cualquiera
 * del CSV, y la evidencia de que la operacion critica funciona perderia su prueba mas directa.
 *
 * <p>El contrato congela este campo en la respuesta del core con el nombre {@code origen}, y
 * establece que los canales web y movil <strong>no</strong> lo exponen hacia afuera: es
 * informacion util para el backend de dominio y ruido para la pantalla de un cliente. Ese recorte
 * es, en pequeno, lo que hace un BFF.
 */
public enum OrigenDato {

    /** La fila venia en {@code cuentas_anuales.csv} y se cargo durante la ingesta de arranque. */
    CSV_SEMILLA,

    /** El movimiento lo genero un retiro ejecutado a traves del canal cajero. */
    RETIRO_ATM
}
