package cl.duoc.bancoxyz.core.aplicacion;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import cl.duoc.bancoxyz.core.config.CoreProperties;
import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaInvalidaException;
import cl.duoc.bancoxyz.core.dominio.error.MontoInvalidoException;
import cl.duoc.bancoxyz.core.puerto.CuentaRepository;
import cl.duoc.bancoxyz.core.puerto.GeneradorIdentificadores;
import cl.duoc.bancoxyz.core.puerto.RegistroIdempotencia;
import cl.duoc.bancoxyz.core.puerto.SalidaDeEventos;
import cl.duoc.bancoxyz.eventos.DatosRetiro;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.TiposEvento;
import cl.duoc.bancoxyz.eventos.Topicos;

/**
 * El caso de uso critico del sistema: <strong>retirar dinero</strong>.
 *
 * <p>Rol en la arquitectura: coordina las cuatro garantias que un retiro tiene que dar, cada una
 * resuelta por una pieza distinta. Vale la pena tener claro cual hace que:
 *
 * <table border="1">
 *   <caption>De que se encarga cada pieza</caption>
 *   <tr><th>Garantia</th><th>Quien la da</th><th>Como</th></tr>
 *   <tr><td>El monto es un importe valido</td><td>este servicio</td><td>validacion previa</td></tr>
 *   <tr><td>Un reintento no cobra dos veces</td><td>{@link RegistroIdempotencia}</td>
 *       <td>clave primaria (cuenta, clave) de la tabla {@code idempotencia}</td></tr>
 *   <tr><td>Descontar y registrar ocurren juntos, y dos retiros a la vez no dejan el saldo
 *       negativo</td><td>{@link CuentaRepository#debitar}</td>
 *       <td>{@code UPDATE} condicional en una transaccion</td></tr>
 *   <tr><td>El resto del sistema se entera, y no se entera de un retiro que no ocurrio</td>
 *       <td>{@link SalidaDeEventos}</td>
 *       <td>el evento se escribe en la tabla {@code outbox} en la MISMA transaccion (F7)</td></tr>
 * </table>
 *
 * <p><strong>El orden en que se aplican no es casual.</strong> Primero la idempotencia y despues
 * el debito. Si fuera al reves, un reintento ejecutaria el debito antes de descubrir que la clave
 * ya existia, y el "una sola vez" seria falso justo en el caso que la idempotencia existe para
 * cubrir.
 *
 * <p><strong>Que NO valida este servicio, y por que.</strong> Las reglas de monto multiplo de
 * 1.000, minimo de 1.000 y tope de 10.000 por transaccion son <em>politica del canal cajero</em>,
 * no del banco: un retiro por transferencia interna no tiene por que ser multiplo de mil. Viven en
 * {@code bff-atm} y se aplican antes de llegar aqui. El core valida solo lo innegociable, que es
 * que el monto sea positivo: un monto negativo tratado como retiro <em>aumentaria</em> el saldo, y
 * el dueno del estado no puede confiar en que todos sus clientes se porten bien.
 */
@Service
public class RetiroService {

    private static final Logger log = LoggerFactory.getLogger(RetiroService.class);

    /** Valor del campo {@code origen} de los eventos que emite este servicio. */
    private static final String ORIGEN_DE_EVENTOS = "core-service";

    private static final DateTimeFormatter DIA_DEL_FOLIO = DateTimeFormatter.ofPattern("uuuuMMdd");

    private final CuentaRepository cuentaRepository;
    private final RegistroIdempotencia registroIdempotencia;
    private final GeneradorIdentificadores identificadores;
    private final CoreProperties propiedades;
    private final Clock reloj;
    private final SalidaDeEventos salidaDeEventos;
    private final TransactionTemplate transaccion;

    /**
     * @param identificadores reparte el correlativo del folio y el identificador del movimiento
     *                    desde secuencias de la base: son unicos entre TODAS las replicas del core
     *                    y continuan la numeracion de los movimientos sembrados desde el CSV (en el
     *                    S5 salian de un contador del proceso, que con dos replicas chocaria)
     * @param reloj       se inyecta en vez de llamar a {@code LocalDate.now()} directamente para
     *                    que una prueba pueda fijar el dia y verificar el formato del folio sin
     *                    depender de cuando se ejecute
     * @param salidaDeEventos donde se anota el evento del retiro (outbox)
     * @param gestorTransacciones el mismo que usan los adaptadores: permite que el descuento y el
     *                    registro del evento compartan UNA transaccion tambien cuando el retiro llega
     *                    sin clave de idempotencia (con clave, la transaccion ya la abre el registro)
     */
    public RetiroService(CuentaRepository cuentaRepository,
                         RegistroIdempotencia registroIdempotencia,
                         GeneradorIdentificadores identificadores,
                         CoreProperties propiedades,
                         Clock reloj,
                         SalidaDeEventos salidaDeEventos,
                         PlatformTransactionManager gestorTransacciones) {
        this.cuentaRepository = cuentaRepository;
        this.registroIdempotencia = registroIdempotencia;
        this.identificadores = identificadores;
        this.propiedades = propiedades;
        this.reloj = reloj;
        this.salidaDeEventos = salidaDeEventos;
        this.transaccion = new TransactionTemplate(gestorTransacciones);
    }

    /**
     * Ejecuta un retiro.
     *
     * @param cuentaId       cuenta de la que se retira
     * @param monto          importe solicitado
     * @param claveIdempotencia valor de la cabecera {@code Idempotency-Key}. Puede ser
     *                          {@code null} o vacio: en ese caso el retiro se ejecuta sin
     *                          proteccion contra reintentos, que es lo correcto para un cliente que
     *                          no la pidio. El canal cajero siempre la envia, precisamente porque
     *                          es el canal donde un corte de red cuesta dinero real
     * @return el comprobante. Ante una clave repetida, <strong>el mismo</strong> comprobante de la
     *         primera vez: mismo folio y mismas cifras, sin un segundo descuento
     * @throws MontoInvalidoException si el monto no es positivo (se traduce a 400)
     * @throws ClaveIdempotenciaInvalidaException si la clave pasa de 200 caracteres (400)
     * @throws cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaReutilizadaException si la clave ya
     *         se uso en esa cuenta con otro importe (422). La clave vale por cuenta: la misma cadena
     *         en otra cuenta es una operacion nueva
     * @throws cl.duoc.bancoxyz.core.dominio.error.CuentaNoEncontradaException si la cuenta no
     *         existe (404)
     * @throws cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException si el saldo no alcanza
     *         (409). En ese caso no se modifica nada y la clave de idempotencia queda libre para
     *         reintentar
     */
    public ResultadoRetiro retirar(int cuentaId, BigDecimal monto, String claveIdempotencia) {

        if (monto == null || monto.compareTo(BigDecimal.ZERO) <= 0) {
            throw new MontoInvalidoException(monto);
        }

        if (claveIdempotencia == null || claveIdempotencia.isBlank()) {
            log.info("Retiro sin clave de idempotencia sobre la cuenta {}", cuentaId);
            return debitar(cuentaId, monto);
        }

        // La clave es la clave primaria de una tabla: se valida su largo antes de llegar a la base.
        if (claveIdempotencia.length() > ClaveIdempotenciaInvalidaException.LARGO_MAXIMO) {
            throw new ClaveIdempotenciaInvalidaException(claveIdempotencia.length());
        }

        // La operacion se entrega envuelta en una lambda, sin ejecutar. El registro decide si
        // llamarla o devolver lo guardado, y hace esa decision y la ejecucion en un solo paso
        // indivisible. Si aqui se ejecutara antes y se guardara despues, dos reintentos
        // simultaneos retirarian dos veces.
        ResultadoRetiro comprobante = registroIdempotencia.ejecutarUnaSolaVez(
                cuentaId, claveIdempotencia, monto, () -> debitar(cuentaId, monto));

        log.info("Retiro sobre la cuenta {} con clave {}: folio {}",
                cuentaId, claveIdempotencia, comprobante.folio());
        return comprobante;
    }

    /**
     * El descuento propiamente tal.
     *
     * <p>Aqui se prepara un folio y un identificador de movimiento y se une el descuento con el registro
     * del evento en una transaccion. El trabajo delicado, que es que descontar y apuntar el movimiento
     * ocurran juntos y bajo exclusion por cuenta, esta
     * en {@link CuentaRepository#debitar}, porque solo el adaptador conoce el mecanismo de
     * exclusion de su almacen. Ese reparto de responsabilidades es el que permitio pasar de la
     * memoria a PostgreSQL (F3) sin tocar este servicio, salvo para sacar los identificadores de
     * secuencias compartidas.
     */
    private ResultadoRetiro debitar(int cuentaId, BigDecimal monto) {
        LocalDate hoy = LocalDate.now(reloj);
        String folio = generarFolio(hoy);
        long idMovimiento = identificadores.siguienteIdMovimiento();

        // Descuento y evento en UNA transaccion. Si el retiro llega con clave de idempotencia ya hay una
        // abierta (la del registro) y esta se une a ella; si no, se abre aqui. En ambos casos el evento
        // se anota DESPUES del UPDATE de la cuenta: ese UPDATE bloquea la fila hasta el commit, y asi
        // los eventos de una misma cuenta quedan en el outbox en el orden en que se confirmaron.
        ResultadoRetiro comprobante = transaccion.execute(estado -> {
            ResultadoRetiro resultado = cuentaRepository.debitar(cuentaId, monto, folio, hoy, idMovimiento);
            salidaDeEventos.registrar(Topicos.RETIROS, Integer.toString(cuentaId),
                    SobreEvento.nuevo(TiposEvento.RETIRO_EJECUTADO, 1, reloj.instant(), ORIGEN_DE_EVENTOS,
                            new DatosRetiro(cuentaId, resultado.folio(), resultado.montoRetirado(),
                                    resultado.saldoAnterior(), resultado.saldoPosterior(), idMovimiento,
                                    propiedades.moneda())));
            return resultado;
        });

        log.info("Debito aplicado: cuenta {} | saldo {} -> {} | monto {} | folio {}",
                cuentaId, comprobante.saldoAnterior().toPlainString(),
                comprobante.saldoPosterior().toPlainString(), monto.toPlainString(), folio);

        return comprobante;
    }

    /**
     * Construye un folio con la forma {@code RET-yyyyMMdd-NNNNNN}.
     *
     * <p>El contrato pide que el folio sea unico y estable por clave de idempotencia, y deja libre
     * su formato. Se elige uno legible por una persona: se ve el dia de la operacion sin
     * descifrarlo, y como el correlativo va relleno con ceros a la izquierda, ordenar folios como
     * texto los ordena tambien cronologicamente dentro del dia.
     *
     * <p>El correlativo sale de una secuencia de la base, no de un contador del proceso: con dos
     * replicas del core, un contador local emitiria el mismo folio dos veces, y tras un reinicio
     * volveria a empezar de 1.
     *
     * <p>La estabilidad por clave no la da este metodo: la da el registro de idempotencia, que
     * simplemente no vuelve a llamarlo cuando la clave ya se habia visto. Un folio aleatorio seria
     * igual de valido mientras se genere una sola vez por clave.
     */
    private String generarFolio(LocalDate dia) {
        long numero = identificadores.siguienteCorrelativoFolio();
        String correlativo = String.format("%0" + propiedades.folio().anchoNumero() + "d", numero);
        return propiedades.folio().prefijo() + "-" + DIA_DEL_FOLIO.format(dia) + "-" + correlativo;
    }
}
