package cl.duoc.bancoxyz.core.puerto;

/**
 * <strong>Puerto</strong> que reparte los identificadores que un retiro necesita y que tienen que
 * ser unicos <em>en todo el sistema</em>, no solo dentro de un proceso.
 *
 * <p><strong>Por que existe.</strong> En el S5 el correlativo del folio y el identificador del
 * movimiento salian de un {@code AtomicLong} dentro del proceso. Con un solo core eso bastaba; con
 * dos replicas cada una numeraria por su cuenta y emitiria el mismo folio, y tras cada reinicio la
 * numeracion volveria a empezar de 1. Los identificadores unicos son, por naturaleza, estado
 * compartido, y el estado compartido tiene un solo dueno: la base de datos (secuencias).
 *
 * <p>Los numeros son unicos y crecientes, <strong>no necesariamente consecutivos</strong>: una
 * secuencia no se deshace con la transaccion, de modo que un retiro rechazado por saldo consume un
 * numero y deja un hueco. Igual que en el S5, donde el rechazo tambien consumia el correlativo.
 */
public interface GeneradorIdentificadores {

    /** Siguiente correlativo para el folio del comprobante ({@code RET-20260911-000123}). */
    long siguienteCorrelativoFolio();

    /** Siguiente identificador de movimiento, para el apunte que genera un retiro. */
    long siguienteIdMovimiento();
}
