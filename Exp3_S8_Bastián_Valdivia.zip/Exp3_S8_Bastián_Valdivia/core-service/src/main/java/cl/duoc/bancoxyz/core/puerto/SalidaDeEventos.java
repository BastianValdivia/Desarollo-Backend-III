package cl.duoc.bancoxyz.core.puerto;

import cl.duoc.bancoxyz.eventos.SobreEvento;

/**
 * <strong>Puerto</strong> por el que el dominio anuncia hechos que ocurrieron ("se ejecuto un retiro")
 * sin saber como llegan a quien los escucha.
 *
 * <p>El dominio solo pide que el evento quede REGISTRADO junto con el cambio de estado que lo origino.
 * Que despues viaje por Kafka, por otro medio o por ninguno es asunto del adaptador y del relay. Es el
 * mismo reparto que los demas puertos del core: el servicio de aplicacion no conoce el almacen.
 *
 * <p>Contrato: se llama DENTRO de la transaccion del cambio de estado. Un adaptador que no pueda unirse
 * a esa transaccion rompe la garantia (el evento y el cambio dejarian de ser atomicos) y debe negarse.
 */
public interface SalidaDeEventos {

    /**
     * Registra un evento para su publicacion posterior.
     *
     * @param topico topico de destino
     * @param clave  clave del registro (decide la particion: el orden solo se garantiza dentro de una)
     * @param evento el sobre a publicar
     * @throws IllegalStateException si no hay una transaccion activa
     */
    void registrar(String topico, String clave, SobreEvento evento);
}
