package cl.duoc.bancoxyz.core.adaptador;

import java.math.BigDecimal;
import java.util.function.Supplier;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaReutilizadaException;
import cl.duoc.bancoxyz.core.puerto.RegistroIdempotencia;

/**
 * <strong>Adaptador</strong> de {@link RegistroIdempotencia} sobre la tabla {@code idempotencia},
 * cuya <strong>clave primaria</strong> es el par (cuenta, {@code Idempotency-Key}).
 *
 * <p>Rol en la arquitectura: que un reintento del cajero (corte de red, respuesta perdida) no cobre
 * dos veces. En el S5 lo hacia {@code computeIfAbsent} sobre un mapa del proceso; con dos replicas del
 * core el reintento puede caer en la otra, que no comparte ese mapa y descontaria de nuevo. El
 * registro tiene que estar donde esta el estado: la base.
 *
 * <h2>Por que la clave es (cuenta, clave) y no solo la clave</h2>
 *
 * <p>La {@code Idempotency-Key} la elige el cliente. Con la clave sola como llave primaria, dos
 * clientes que eligieran la misma cadena chocaban: el segundo recibia el comprobante del primero
 * (folio, saldos e importe de otra cuenta) sin que se descontara nada de la suya. Atada a la cuenta,
 * la misma cadena en otra cuenta es una operacion nueva e independiente. Dentro de la misma cuenta,
 * repetir la clave con <em>otro importe</em> no es un reintento y se rechaza
 * ({@link ClaveIdempotenciaReutilizadaException}).
 *
 * <h2>Como la restriccion unica vuelve idempotente el retiro</h2>
 *
 * <p>Todo ocurre en <strong>una transaccion</strong>:
 *
 * <ol>
 *   <li>{@code INSERT ... ON CONFLICT (cuenta_id, clave) DO NOTHING} intenta reservar la clave. Si dos
 *       peticiones con la misma cuenta y clave llegan a la vez (aunque sea a replicas distintas), la base deja
 *       pasar a una y <em>hace esperar a la otra</em> hasta que la primera confirme o deshaga: es el
 *       bloqueo de la restriccion unica, y es lo que sustituye al bloqueo por clave del mapa.</li>
 *   <li>Si la insercion reservo la clave (1 fila), este es el primer intento: se ejecuta la
 *       operacion (el descuento, que se une a esta misma transaccion) y se guarda el comprobante.</li>
 *   <li>Si no (0 filas), la clave ya estaba usada en esa cuenta y su transaccion ya confirmo: si el
 *       importe coincide se devuelve el comprobante guardado, <strong>con el mismo folio</strong>,
 *       sin tocar el saldo; si no coincide, se rechaza la reutilizacion de la clave.</li>
 * </ol>
 *
 * <p><strong>Si la operacion falla, la reserva se deshace con ella.</strong> Un retiro rechazado por
 * saldo insuficiente lanza una excepcion, la transaccion se revierte y la clave queda libre: el
 * rechazo puede reintentarse con la misma clave despues de un deposito. Igual que en la version en
 * memoria, un fracaso no se recuerda.
 *
 * <p><strong>Por que se reserva antes de ejecutar y no se inserta al final.</strong> Insertar despues
 * dejaria la ventana que esta clase existe para cerrar: dos reintentos ejecutarian el descuento y solo
 * el segundo {@code INSERT} chocaria, cuando ya se descontaron dos veces. Reservar primero hace que el
 * segundo espere <em>antes</em> de descontar.
 */
@Repository
public class RegistroIdempotenciaJdbc implements RegistroIdempotencia {

    private final JdbcClient jdbc;
    private final TransactionTemplate transaccion;

    public RegistroIdempotenciaJdbc(JdbcClient jdbc, PlatformTransactionManager gestorTransacciones) {
        this.jdbc = jdbc;
        this.transaccion = new TransactionTemplate(gestorTransacciones);
    }

    @Override
    public ResultadoRetiro ejecutarUnaSolaVez(int cuentaId, String clave, BigDecimal monto,
                                              Supplier<ResultadoRetiro> operacion) {
        return transaccion.execute(estado -> {
            int reservada = jdbc.sql("""
                            INSERT INTO idempotencia (cuenta_id, clave) VALUES (:cuenta, :clave)
                            ON CONFLICT (cuenta_id, clave) DO NOTHING""")
                    .param("cuenta", cuentaId)
                    .param("clave", clave)
                    .update();

            if (reservada == 0) {
                return comprobanteGuardado(cuentaId, clave, monto);
            }

            ResultadoRetiro comprobante = operacion.get();

            jdbc.sql("""
                            UPDATE idempotencia
                               SET folio = :folio, saldo_anterior = :anterior,
                                   monto_retirado = :monto, saldo_posterior = :posterior
                             WHERE cuenta_id = :cuenta AND clave = :clave""")
                    .param("folio", comprobante.folio())
                    .param("anterior", comprobante.saldoAnterior())
                    .param("monto", comprobante.montoRetirado())
                    .param("posterior", comprobante.saldoPosterior())
                    .param("cuenta", cuentaId)
                    .param("clave", clave)
                    .update();
            return comprobante;
        });
    }

    private ResultadoRetiro comprobanteGuardado(int cuentaId, String clave, BigDecimal montoPedido) {
        ResultadoRetiro guardado = jdbc.sql("""
                        SELECT folio, saldo_anterior, monto_retirado, saldo_posterior
                          FROM idempotencia WHERE cuenta_id = :cuenta AND clave = :clave""")
                .param("cuenta", cuentaId)
                .param("clave", clave)
                .query((rs, fila) -> new ResultadoRetiro(
                        rs.getString("folio"),
                        rs.getBigDecimal("saldo_anterior"),
                        rs.getBigDecimal("monto_retirado"),
                        rs.getBigDecimal("saldo_posterior")))
                .optional()
                // La fila existe y esta confirmada (si no, el INSERT habria esperado). Llegar aqui sin
                // ella significaria que alguien borro la clave entre las dos sentencias.
                .orElseThrow(() -> new IllegalStateException(
                        "La clave de idempotencia " + clave + " existia y desaparecio durante la consulta"));

        // compareTo y no equals: 3000 y 3000.00 son el mismo importe aunque difiera la escala.
        if (guardado.montoRetirado().compareTo(montoPedido) != 0) {
            throw new ClaveIdempotenciaReutilizadaException(cuentaId, montoPedido);
        }
        return guardado;
    }
}
