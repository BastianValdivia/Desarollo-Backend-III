package cl.duoc.bancoxyz.core.api.dto;

import java.math.BigDecimal;

/**
 * Cuerpo de la peticion de retiro: un unico campo, {@code monto}.
 *
 * <p>Rol en la arquitectura: es la entrada del unico endpoint que <strong>muta el estado</strong>
 * del banco.
 *
 * <p><strong>Por que la clave de idempotencia NO es un campo de este cuerpo.</strong> Viaja en la
 * cabecera {@code Idempotency-Key}, que es donde la industria la pone y donde el contrato la
 * congela. La razon es conceptual: la clave no describe <em>que</em> operacion se pide (eso es el
 * monto), sino <em>como</em> debe tratarse el reintento de esa peticion. Es metadato del
 * protocolo, no dato del negocio. Ademas, asi el cuerpo de un reintento es byte a byte identico al
 * del original, que es justo lo que se quiere poder afirmar.
 *
 * <p>{@link BigDecimal} y no {@code double}, tambien en la entrada: Jackson lee el numero JSON
 * directamente a {@code BigDecimal} sin pasar por coma flotante, asi que el importe que escribio el
 * cliente es exactamente el que llega al dominio.
 */
public record RetiroRequest(BigDecimal monto) {
}
