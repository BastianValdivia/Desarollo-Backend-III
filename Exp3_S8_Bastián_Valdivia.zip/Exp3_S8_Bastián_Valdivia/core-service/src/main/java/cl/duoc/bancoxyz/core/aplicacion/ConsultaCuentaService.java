package cl.duoc.bancoxyz.core.aplicacion;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.core.config.CoreProperties;
import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.Movimiento;
import cl.duoc.bancoxyz.core.dominio.Pagina;
import cl.duoc.bancoxyz.core.dominio.TipoMovimiento;
import cl.duoc.bancoxyz.core.dominio.error.CuentaNoEncontradaException;
import cl.duoc.bancoxyz.core.puerto.CuentaRepository;

/**
 * Casos de uso de <strong>lectura</strong> sobre las cuentas.
 *
 * <p>Rol en la arquitectura: es la capa de aplicacion. Su trabajo es coordinar, no calcular: pide
 * datos al puerto, aplica los filtros y los limites que corresponden y entrega objetos de dominio.
 * No sabe nada de HTTP (no aparece aqui ninguna anotacion de Spring Web ni ningun codigo de estado)
 * y no sabe nada de mapas ni de archivos (todo pasa por {@link CuentaRepository}). Esa doble
 * ignorancia es lo que la hace probable sin levantar un servidor y reutilizable si manana el core
 * se consumiera por otro transporte.
 *
 * <p><strong>Por que la cuenta no encontrada se convierte en excepcion aqui y no se propaga como
 * {@code Optional} hasta el controlador.</strong> El puerto devuelve {@code Optional} porque "no
 * esta" es un resultado legitimo de una busqueda. Pero desde el punto de vista del caso de uso
 * "consultar la cuenta 999", que no exista es un <em>fracaso</em>, y traducirlo aqui a una
 * excepcion de negocio evita que cada controlador repita el mismo {@code orElseThrow} y evita que
 * alguno se olvide y devuelva {@code null}.
 */
@Service
public class ConsultaCuentaService {

    private final CuentaRepository cuentaRepository;
    private final CoreProperties propiedades;

    public ConsultaCuentaService(CuentaRepository cuentaRepository, CoreProperties propiedades) {
        this.cuentaRepository = cuentaRepository;
        this.propiedades = propiedades;
    }

    /**
     * La cuenta canonica completa, con <strong>todos</strong> sus movimientos.
     *
     * <p>Este es el recurso que sirve de <em>linea base</em> para comparar cuanto recorta cada
     * canal: el core entrega todo, y cada BFF decide que parte de ese todo necesita su cliente. Una
     * cuenta sin movimientos devuelve la lista vacia y nunca {@code null}: la coleccion vacia es un
     * resultado, el nulo es una trampa que obliga a cada consumidor a defenderse.
     *
     * @throws CuentaNoEncontradaException si el identificador no corresponde a ninguna cuenta
     */
    public Cuenta obtenerCuenta(int cuentaId) {
        return cuentaRepository.buscarPorId(cuentaId)
                .orElseThrow(() -> new CuentaNoEncontradaException(cuentaId));
    }

    /**
     * Una pagina del historial de movimientos, con filtros opcionales por rango de fechas y por
     * tipo.
     *
     * <p><strong>Por que este endpoint existe si {@link #obtenerCuenta} ya trae los movimientos.</strong>
     * Porque traer 686 movimientos para mostrar los ultimos 20 es desperdiciar trabajo en el core,
     * ancho de banda en la red y memoria en el cliente. Ofrecer las dos formas permite que cada
     * canal elija: la web pagina, el movil pide un resumen corto y el cajero ni siquiera mira el
     * historial.
     *
     * <p>El recorte se hace <strong>en el servidor</strong> y el tamano pedido se limita al maximo
     * configurado. Confiar en que el cliente pida poco no es una politica: es la ausencia de una.
     *
     * @param pagina indice base cero; un valor negativo se trata como cero
     * @param tamano elementos por pagina; se recorta al maximo configurado y nunca baja de uno
     * @param desde  fecha minima inclusive, o {@code null} para no filtrar
     * @param hasta  fecha maxima inclusive, o {@code null} para no filtrar
     * @param tipo   tipo de movimiento a conservar, o {@code null} para no filtrar
     */
    public Pagina<Movimiento> paginarMovimientos(int cuentaId, int pagina, Integer tamano,
                                                 LocalDate desde, LocalDate hasta,
                                                 TipoMovimiento tipo) {

        Cuenta cuenta = obtenerCuenta(cuentaId);

        int paginaSegura = Math.max(0, pagina);
        int tamanoSeguro = normalizarTamano(tamano);

        // El orden del historial ya viene garantizado por el constructor de Cuenta (del mas
        // reciente al mas antiguo). Filtrar conserva ese orden, asi que no hay que reordenar: la
        // pagina 0 sigue siendo la de los movimientos mas recientes que cumplen el filtro.
        List<Movimiento> filtrados = cuenta.movimientos().stream()
                .filter(m -> desde == null || !m.fecha().isBefore(desde))
                .filter(m -> hasta == null || !m.fecha().isAfter(hasta))
                .filter(m -> tipo == null || m.tipo() == tipo)
                .toList();

        int inicio = Math.min(paginaSegura * tamanoSeguro, filtrados.size());
        int fin = Math.min(inicio + tamanoSeguro, filtrados.size());

        return new Pagina<>(filtrados.subList(inicio, fin), paginaSegura, tamanoSeguro, filtrados.size());
    }

    /** Cuantas cuentas canonicas hay. Lo consume el reporte de calidad. */
    public int cantidadDeCuentas() {
        return cuentaRepository.listarTodas().size();
    }

    /**
     * Traduce el tamano pedido por el cliente a uno que el servicio esta dispuesto a atender.
     *
     * <p>Se recorta en silencio en vez de rechazar la peticion con un 400. Es una decision, y
     * conviene saber que es una: para un endpoint interno consumido por los propios BFF, devolver
     * la primera pagina con el maximo permitido es mas util que devolver un error, y el cliente ve
     * en el campo {@code tamano} de la respuesta que se le aplico un tope. Un API publico deberia
     * preferir el 400, porque ahi el cliente es ajeno y conviene que el desacuerdo sea explicito.
     */
    private int normalizarTamano(Integer tamanoPedido) {
        int porDefecto = propiedades.paginacion().tamanoPorDefecto();
        int maximo = propiedades.paginacion().tamanoMaximo();

        return Optional.ofNullable(tamanoPedido)
                .filter(t -> t > 0)
                .map(t -> Math.min(t, maximo))
                .orElse(porDefecto);
    }
}
