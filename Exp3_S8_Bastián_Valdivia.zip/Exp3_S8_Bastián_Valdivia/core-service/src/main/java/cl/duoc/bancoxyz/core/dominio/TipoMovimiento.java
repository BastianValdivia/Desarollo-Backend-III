package cl.duoc.bancoxyz.core.dominio;

import java.util.Optional;

import cl.duoc.bancoxyz.core.ingesta.NormalizadorTexto;

/**
 * Naturaleza de un {@link Movimiento}: que le hizo al saldo de la cuenta.
 *
 * <p>Rol en la arquitectura: aqui vive <strong>la regla de signo</strong> del proyecto, y vive
 * solo aqui. El campo {@code monto} de un movimiento es siempre positivo; quien decide si ese
 * dinero entro o salio es el tipo, a traves de {@link #esCargo()}.
 *
 * <p><strong>Por que la regla de signo esta en el enumerado y no en condicionales sueltos.</strong>
 * La alternativa natural es escribir {@code if (tipo == RETIRO || tipo == COMPRA || tipo == PAGO)}
 * cada vez que haga falta sumar cargos. Ese condicional termina copiado en el servicio de
 * consulta, en el calculo del resumen y en la proyeccion de cada canal; el dia que se agregue un
 * quinto tipo de movimiento habra que encontrar las copias una por una, y la que se olvide no
 * producira ningun error: solo un total mal sumado. Con la regla dentro del enumerado, agregar un
 * tipo obliga a decidir su signo en el mismo archivo donde se declara.
 *
 * <p><strong>Un dato del archivo que conviene conocer antes de leer el codigo de ingesta.</strong>
 * El CSV trae descripciones que <em>contradicen</em> a la columna de tipo. Existe realmente la
 * fila {@code 103,08-03-2024,deposito,3000,Retiro parcial}. La decision congelada del proyecto es
 * que la columna {@code transaccion} es la unica fuente de verdad y la descripcion se arrastra
 * como texto decorativo. No es un error de la ingesta, es una propiedad del dataset.
 */
public enum TipoMovimiento {

    DEPOSITO,
    RETIRO,
    COMPRA,
    PAGO;

    /**
     * Indica si el movimiento resta dinero de la cuenta.
     *
     * <p>Es {@code false} unicamente para {@link #DEPOSITO}. Se escribe con un {@code !=} contra
     * el unico abono y no con una lista de los tres cargos a proposito: si manana se agrega el
     * tipo {@code TRANSFERENCIA_RECIBIDA}, quien lo agregue tiene que venir a este metodo, que es
     * exactamente lo que se quiere.
     */
    public boolean esCargo() {
        return this != DEPOSITO;
    }

    /**
     * Convierte un valor crudo del CSV en un tipo de movimiento.
     *
     * <p>Esta es la conversion que resuelve las 52 filas donde la palabra {@code deposito} viene
     * <em>con tilde</em>: {@link NormalizadorTexto} descompone el texto en Unicode y elimina las
     * marcas diacriticas, de modo que ambas grafias llegan aqui como la misma cadena. La
     * alternativa de hacer {@code replace("o con tilde", "o")} caso por caso funciona hasta que
     * aparece la siguiente palabra acentuada.
     *
     * @param valorCrudo texto tal como venia en la columna {@code transaccion}; admite nulo
     * @return el tipo reconocido, o vacio si el valor era invalido o ilegible
     */
    public static Optional<TipoMovimiento> parse(String valorCrudo) {
        String limpio = NormalizadorTexto.normalizar(valorCrudo);
        if (NormalizadorTexto.esDesconocido(limpio)) {
            return Optional.empty();
        }
        for (TipoMovimiento candidato : values()) {
            if (candidato.name().toLowerCase().equals(limpio)) {
                return Optional.of(candidato);
            }
        }
        return Optional.empty();
    }
}
