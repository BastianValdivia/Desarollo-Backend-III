package cl.duoc.bancoxyz.core.api;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.bancoxyz.core.api.dto.ReporteCalidadResponse;
import cl.duoc.bancoxyz.core.api.dto.TransaccionesNoConciliadasResponse;
import cl.duoc.bancoxyz.core.config.CoreProperties;
import cl.duoc.bancoxyz.core.puerto.LoteNoConciliadoRepository;
import cl.duoc.bancoxyz.core.puerto.ReporteCalidadRepository;

/**
 * API interna de administracion: los dos recursos que no son de un cliente sino del
 * <strong>banco</strong>.
 *
 * <p>Rol en la arquitectura: separa lo operativo de lo comercial. Un cliente consulta su cuenta; un
 * ejecutivo consulta la salud de los datos y los lotes pendientes de conciliar. Que sean rutas
 * distintas es lo que permite que el canal web les exija una autoridad distinta
 * ({@code ROLE_EJECUTIVO}) a la de un cliente, y eso es autorizacion granular <em>dentro</em> de un
 * mismo canal, no solo entre canales.
 *
 * <p>Los dos recursos viven bajo {@code /internal/v1/admin} y, como todo {@code /internal/**},
 * exigen un token de servicio; ademas exigen el scope {@code auditoria:leer}, que solo tiene el cliente
 * {@code bff-web}. La proteccion por identidad de persona la agrega el BFF web encima.
 */
@RestController
@RequestMapping(value = "/internal/v1/admin", produces = MediaType.APPLICATION_JSON_VALUE)
public class AdminInternoController {

    private final ReporteCalidadRepository reporteCalidad;
    private final LoteNoConciliadoRepository loteNoConciliado;
    private final CoreProperties propiedades;

    public AdminInternoController(ReporteCalidadRepository reporteCalidad,
                                  LoteNoConciliadoRepository loteNoConciliado,
                                  CoreProperties propiedades) {
        this.reporteCalidad = reporteCalidad;
        this.loteNoConciliado = loteNoConciliado;
        this.propiedades = propiedades;
    }

    /**
     * Que leyo, que descarto y que produjo la ingesta de arranque.
     *
     * <p>Devuelve exactamente los mismos numeros que la ingesta escribio en el log al arrancar,
     * porque salen del mismo objeto. Esa coincidencia no es casual: es lo que permite citar cifras
     * en la documentacion del proyecto y que cualquiera pueda comprobarlas con una llamada, en vez
     * de tener que creerlas.
     *
     * <p>Las cifras describen <strong>la carga</strong>, no el estado actual del banco: un retiro
     * del cajero agrega un movimiento y no mueve el 686 de este reporte. Es deliberado, porque un
     * numero que cambia segun cuando se consulte no sirve como evidencia.
     */
    @GetMapping("/calidad-datos")
    public ReporteCalidadResponse calidadDatos() {
        return ReporteCalidadResponse.de(reporteCalidad.obtener());
    }

    /**
     * El lote de {@code transacciones.csv}, paginado y sin maquillar.
     *
     * <p>Son 1000 filas que <strong>no se pudieron vincular a ninguna cuenta</strong>: el archivo
     * no tiene columna de cuenta y sus ids, del 1 al 1000 sin repetir, no coinciden con nada. Se
     * publican tal cual, con las fechas ilegibles en nulo, los montos vacios en nulo y los tipos
     * crudos incluidos {@code invalid} y {@code desconocido}.
     *
     * <p>Repartir estas filas entre las 50 cuentas para tener un historial mas nutrido seria
     * fabricar datos financieros, que es peor que reconocer que un archivo no se pudo conciliar.
     */
    @GetMapping("/transacciones-no-conciliadas")
    public TransaccionesNoConciliadasResponse transaccionesNoConciliadas(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(required = false) Integer size) {

        int tamano = (size == null || size <= 0)
                ? propiedades.paginacion().tamanoPorDefecto()
                : Math.min(size, propiedades.paginacion().tamanoMaximo());

        return TransaccionesNoConciliadasResponse.de(
                loteNoConciliado.paginar(Math.max(0, page), tamano));
    }
}
