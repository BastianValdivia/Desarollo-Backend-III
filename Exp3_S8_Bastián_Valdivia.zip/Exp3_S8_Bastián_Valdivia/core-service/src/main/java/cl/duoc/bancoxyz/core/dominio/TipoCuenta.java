package cl.duoc.bancoxyz.core.dominio;

import java.util.Optional;

import cl.duoc.bancoxyz.core.ingesta.NormalizadorTexto;

/**
 * Producto bancario al que pertenece una {@link Cuenta}.
 *
 * <p>Rol en la arquitectura: es parte del <strong>lenguaje del dominio</strong>. Que el tipo sea
 * un enumerado y no un {@code String} significa que el compilador, y no una revision humana,
 * garantiza que nunca circule por el sistema un tipo de cuenta que el banco no reconoce.
 *
 * <p><strong>Por que el metodo de conversion devuelve {@link Optional} y no lanza excepcion ni
 * cae a un valor por defecto.</strong> El CSV de semilla trae 326 valores que no son ninguno de
 * los tres productos reales: el centinela {@code -1} y el literal {@code unknown}. Hay tres
 * formas de tratarlos y solo una es honesta:
 *
 * <ul>
 *   <li><em>Poner AHORRO por defecto</em>: inventa un dato indistinguible de uno real. Una vez
 *       dentro del sistema, nadie puede volver a separarlos. Es la peor opcion y es la mas comun.</li>
 *   <li><em>Lanzar excepcion</em>: aborta la ingesta completa por una fila mala entre mil.</li>
 *   <li><em>Devolver ausencia</em>: el valor no existe, se cuenta en el reporte de calidad y la
 *       fila no vota en la consolidacion. La ausencia se puede auditar; el valor inventado, no.</li>
 * </ul>
 *
 * <p>Esta clase es la que fija el vocabulario de salida en MAYUSCULAS ({@code AHORRO},
 * {@code HIPOTECA}, {@code PRESTAMO}) que el contrato congela para el campo JSON
 * {@code tipoCuenta}: al serializar el enumerado, Jackson escribe su nombre tal cual, de modo que
 * el contrato y el codigo no pueden divergir sin que el compilador se entere.
 */
public enum TipoCuenta {

    AHORRO,
    HIPOTECA,
    PRESTAMO;

    /**
     * Convierte un valor crudo del CSV en un tipo de cuenta, tolerando la suciedad del origen.
     *
     * <p>Delega la limpieza en {@link NormalizadorTexto} en lugar de repetirla aqui: asi el
     * tratamiento de tildes y de centinelas es <em>identico</em> para los dos enumerados del
     * dominio, y arreglarlo en un solo lugar lo arregla en ambos.
     *
     * @param valorCrudo texto tal como venia en la columna del archivo; admite nulo
     * @return el tipo reconocido, o vacio si el valor era invalido, centinela o ilegible
     */
    public static Optional<TipoCuenta> parse(String valorCrudo) {
        String limpio = NormalizadorTexto.normalizar(valorCrudo);
        if (NormalizadorTexto.esDesconocido(limpio)) {
            return Optional.empty();
        }
        for (TipoCuenta candidato : values()) {
            // El enumerado se declara en MAYUSCULAS y el normalizador entrega minusculas sin
            // tildes, asi que la comparacion se hace sobre la forma normalizada de ambos lados.
            if (candidato.name().toLowerCase().equals(limpio)) {
                return Optional.of(candidato);
            }
        }
        return Optional.empty();
    }
}
