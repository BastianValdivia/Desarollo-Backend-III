package cl.duoc.bancoxyz.core.adaptador;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import cl.duoc.bancoxyz.core.dominio.MotivoDescarte;
import cl.duoc.bancoxyz.core.dominio.ReporteCalidad;
import cl.duoc.bancoxyz.core.puerto.ReporteCalidadRepository;

/**
 * <strong>Adaptador</strong> de {@link ReporteCalidadRepository}: reconstruye el reporte de la carga
 * inicial a partir de las tres tablas {@code reporte_calidad*} que dejo la migracion V2.
 *
 * <p>La lectura se hace en una sola transaccion de solo lectura para que las tres consultas vean la
 * misma foto, aunque en la practica el reporte no cambia despues de la carga.
 */
@Repository
public class ReporteCalidadRepositoryJdbc implements ReporteCalidadRepository {

    private final JdbcClient jdbc;
    private final TransactionTemplate lectura;

    public ReporteCalidadRepositoryJdbc(JdbcClient jdbc, PlatformTransactionManager gestorTransacciones) {
        this.jdbc = jdbc;
        this.lectura = new TransactionTemplate(gestorTransacciones);
        this.lectura.setReadOnly(true);
    }

    @Override
    public ReporteCalidad obtener() {
        return lectura.execute(estado -> {
            record Cabecera(String generadoEn, int cuentas, int movimientos, int transacciones) {
            }
            Cabecera cabecera = jdbc.sql("""
                            SELECT generado_en, cuentas_consolidadas, movimientos_cargados,
                                   transacciones_no_conciliadas
                              FROM reporte_calidad WHERE id = 1""")
                    .query((rs, fila) -> new Cabecera(rs.getString(1), rs.getInt(2), rs.getInt(3), rs.getInt(4)))
                    .single();

            List<ReporteCalidad.ArchivoLeido> archivos = jdbc.sql("""
                            SELECT archivo, filas_leidas, filas_unicas, duplicadas_descartadas
                              FROM reporte_calidad_archivo ORDER BY orden""")
                    .query((rs, fila) -> new ReporteCalidad.ArchivoLeido(
                            rs.getString(1), rs.getInt(2), rs.getInt(3), rs.getInt(4)))
                    .list();

            // Las cinco claves estan siempre, aunque alguna valga cero: un motivo ausente seria
            // ambiguo entre "no ocurrio" y "no se midio".
            Map<MotivoDescarte, Integer> descartes = new EnumMap<>(MotivoDescarte.class);
            for (MotivoDescarte motivo : MotivoDescarte.values()) {
                descartes.put(motivo, 0);
            }
            jdbc.sql("SELECT motivo, cantidad FROM reporte_calidad_descarte")
                    .query((rs, fila) -> Map.entry(MotivoDescarte.valueOf(rs.getString(1)), rs.getInt(2)))
                    .list()
                    .forEach(descarte -> descartes.put(descarte.getKey(), descarte.getValue()));

            return new ReporteCalidad(cabecera.generadoEn(), archivos, Map.copyOf(descartes),
                    cabecera.cuentas(), cabecera.movimientos(), cabecera.transacciones());
        });
    }
}
