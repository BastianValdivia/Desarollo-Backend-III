package cl.duoc.bancoxyz.core.api.dto;

import java.math.BigDecimal;

import cl.duoc.bancoxyz.core.dominio.Cuenta;

/**
 * Solo el saldo: tres campos. Respuesta de {@code GET /internal/v1/cuentas/{id}/saldo}.
 *
 * <p>Rol en la arquitectura: es una de las piezas mas importantes del proyecto y la mas facil de
 * pasar por alto. <strong>Este endpoint existe para que el movil y el cajero no tengan que traer la
 * cuenta completa.</strong>
 *
 * <p>La diferencia es de fondo, no de tamano de respuesta. Si el cajero pidiera
 * {@code /cuentas/116} y se quedara con un campo, el core habria construido igualmente la lista de
 * 42 movimientos, la habria serializado entera y la habria mandado por la red para que el BFF la
 * tirara a la basura. Lo que se optimiza aqui no es solo lo que viaja: es el
 * <strong>trabajo aguas arriba</strong>, que es la mitad del problema que casi todas las
 * implementaciones ignoran.
 *
 * <p>Comparese con la respuesta del canal cajero, que reduce esto todavia mas: alli son dos campos,
 * {@code saldoDisponible} y {@code moneda}, sin {@code cuentaId}, porque quien mira esa pantalla
 * esta en la calle y ya sabe de que tarjeta se trata.
 */
public record SaldoCoreResponse(int cuentaId, BigDecimal saldo, String moneda) {

    public static SaldoCoreResponse de(Cuenta cuenta, String moneda) {
        return new SaldoCoreResponse(cuenta.id(), cuenta.saldo(), moneda);
    }
}
