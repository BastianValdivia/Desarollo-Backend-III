package cl.duoc.bancoxyz.core.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Todos los valores configurables del {@code core-service}, enlazados desde
 * {@code config-repo/core-service.yml} bajo el prefijo {@code core}.
 *
 * <p>Rol en la arquitectura: es el <strong>punto unico de externalizacion</strong>. La regla dura
 * del proyecto es que ningun parametro operativo vive como constante dentro del codigo: cambiar el
 * tamano de pagina o la moneda tiene que ser editar una linea de
 * configuracion y no recompilar. Eso es directamente lo que hace que un sistema sea facil de
 * extender y operar.
 *
 * <p><strong>Por que records anidados y no una clase con setters.</strong> Un record enlazado por
 * constructor es inmutable: una vez arrancada la aplicacion, nadie puede cambiar el tamano de
 * pagina en caliente desde otro bean. Ademas agrupar por temas ({@code paginacion},
 * {@code folio}) hace que el YAML se lea como un indice del servicio en vez
 * de como una lista plana de treinta claves.
 *
 * <p><strong>La anotacion que hay que recordar, porque su ausencia no se diagnostica sola.</strong>
 * {@code @SpringBootApplication} incluye el escaneo de componentes pero <em>no</em> el de
 * propiedades. Una clase anotada solo con {@code @ConfigurationProperties} no se registra como
 * bean, y el arranque muere con un mensaje del tipo "Parameter 0 of constructor ... required a
 * bean of type '...CoreProperties' that could not be found", que no apunta a la causa real. Por eso
 * {@code CoreServiceApplication} lleva {@code @ConfigurationPropertiesScan} desde el primer dia.
 *
 * <p><strong>Por que todos los valores tienen {@link DefaultValue}.</strong> Para que el servicio
 * arranque aunque el YAML este incompleto, y para que los valores por defecto queden escritos en
 * un lugar que se puede leer. El YAML sigue siendo la fuente de verdad en operacion; estos
 * defectos son la red de seguridad, no el plan.
 *
 * @param paginacion limites de las consultas paginadas
 * @param moneda     codigo de moneda que acompana a todo importe en las respuestas
 * @param folio      como se construyen los identificadores de comprobante de retiro
 */
@ConfigurationProperties(prefix = "core")
public record CoreProperties(
        @DefaultValue Paginacion paginacion,
        @DefaultValue("CLP") String moneda,
        @DefaultValue Folio folio) {

    /**
     * Limites de paginacion.
     *
     * <p>El maximo se valida <strong>en el servidor</strong> y no se confia en que el cliente pida
     * poco: sin tope, un {@code size=100000} obliga al core a construir una respuesta enorme, que
     * es una forma trivial de agotar la memoria del servicio. Es el mismo motivo por el que el
     * canal movil ni siquiera expone parametros de paginacion hacia afuera.
     *
     * @param tamanoPorDefecto cuantos elementos por pagina si el cliente no dice nada
     * @param tamanoMaximo     techo duro; una peticion mayor se recorta a este valor
     */
    public record Paginacion(
            @DefaultValue("20") int tamanoPorDefecto,
            @DefaultValue("100") int tamanoMaximo) {
    }

    /**
     * Forma del identificador de comprobante de un retiro.
     *
     * <p>El contrato exige que el folio sea una cadena unica y <strong>estable por
     * {@code Idempotency-Key}</strong>, y deja su formato exacto sin congelar. Se elige
     * {@code RET-yyyyMMdd-NNNNNN} porque es legible por una persona (se ve de un vistazo el dia de
     * la operacion) y ordenable como texto, que es lo que se quiere de un numero de comprobante.
     *
     * @param prefijo     texto inicial del folio
     * @param anchoNumero cuantos digitos tiene el correlativo, rellenado con ceros a la izquierda
     */
    public record Folio(
            @DefaultValue("RET") String prefijo,
            @DefaultValue("6") int anchoNumero) {
    }
}
