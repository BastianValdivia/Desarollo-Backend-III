package cl.duoc.bancoxyz.core.adaptador;

import java.util.UUID;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import cl.duoc.bancoxyz.core.puerto.SalidaDeEventos;
import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.SobreEvento;

/**
 * Adaptador de {@link SalidaDeEventos} sobre la tabla {@code outbox} de PostgreSQL (migracion V4).
 *
 * <p>Su unico trabajo es un {@code INSERT} que comparte la transaccion del retiro: como usa el mismo
 * {@code DataSource} que el resto de los adaptadores, la conexion de la transaccion en curso es la
 * suya, y el evento se confirma o se deshace junto con el descuento. Esa es la garantia entera del
 * patron; por eso se niega a escribir si no hay transaccion (en modo autocommit el INSERT se confirmaria
 * solo, y el cambio de estado podria deshacerse despues dejando un evento de algo que no ocurrio).
 *
 * <p>El sobre se guarda como texto ya serializado, que es exactamente lo que el relay publicara: lo que
 * se escribe es lo que se entrega, sin una segunda serializacion que pueda diferir.
 */
@Repository
public class OutboxJdbc implements SalidaDeEventos {

    private final JdbcClient jdbc;

    public OutboxJdbc(JdbcClient jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public void registrar(String topico, String clave, SobreEvento evento) {
        if (!TransactionSynchronizationManager.isActualTransactionActive()) {
            throw new IllegalStateException("El outbox solo se escribe dentro de la transaccion del cambio de "
                    + "estado que origina el evento: sin ella el evento y el cambio no serian atomicos.");
        }
        jdbc.sql("""
                        INSERT INTO outbox (event_id, tipo, topico, clave, payload)
                        VALUES (:eventId, :tipo, :topico, :clave, :payload)""")
                .param("eventId", UUID.fromString(evento.eventId()))
                .param("tipo", evento.tipo())
                .param("topico", topico)
                .param("clave", clave)
                .param("payload", CodecEventos.escribir(evento))
                .update();
    }
}
