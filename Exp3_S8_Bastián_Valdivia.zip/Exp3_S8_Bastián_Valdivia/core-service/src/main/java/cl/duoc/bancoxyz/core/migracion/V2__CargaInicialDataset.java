package cl.duoc.bancoxyz.core.migracion;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.flywaydb.core.api.migration.BaseJavaMigration;
import org.flywaydb.core.api.migration.Context;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.Movimiento;
import cl.duoc.bancoxyz.core.dominio.ReporteCalidad;
import cl.duoc.bancoxyz.core.dominio.TransaccionNoConciliada;
import cl.duoc.bancoxyz.core.ingesta.IngestaDataset;
import cl.duoc.bancoxyz.core.ingesta.ParserFechas;
import cl.duoc.bancoxyz.core.ingesta.ReglaConsolidacion;

/**
 * Migracion de Flyway que <strong>carga el dataset una sola vez</strong>: ejecuta la ingesta del S5
 * sobre los tres CSV y escribe el resultado en las tablas que creo {@code V1__esquema_inicial.sql}.
 *
 * <p>Rol en la arquitectura: es el reemplazo del {@code @PostConstruct} del S5, que sembraba mapas en
 * memoria en <em>cada</em> arranque. Aqui la siembra es un hecho de la historia de la base de datos:
 * Flyway la ejecuta la primera vez, anota la version 2 en {@code flyway_schema_history} y no la vuelve
 * a ejecutar jamas. Un reinicio, o una segunda replica, encuentra las 50 cuentas (con los retiros ya
 * hechos) y sigue.
 *
 * <h2>Por que dos replicas no pueden cargar a la vez</h2>
 *
 * <p>Antes de migrar, Flyway toma un bloqueo consultivo de PostgreSQL ({@code pg_advisory_lock}) sobre
 * la base. Si dos replicas arrancan juntas, una migra y la otra espera el bloqueo; cuando lo obtiene,
 * ve la version 2 ya aplicada y no hace nada. La carga ocurre una vez y entera: la migracion corre
 * dentro de una transaccion, de modo que si falla a la mitad no queda ninguna cuenta a medias.
 *
 * <h2>Decisiones</h2>
 *
 * <ul>
 *   <li><strong>Es un bean ({@code @Component}) en vez de una clase descubierta por escaneo.</strong>
 *       Spring Boot registra en Flyway todos los beans {@code JavaMigration}. Evita depender del
 *       escaneo de clases dentro del jar anidado de Spring Boot, que ha dado problemas en otras
 *       versiones, y no cuesta nada.</li>
 *   <li><strong>Los CSV y las reglas son los del S5, fijos.</strong> Una migracion es una foto de
 *       un momento: no lee {@code core.ingesta.*} de la configuracion, porque una migracion cuyo
 *       resultado cambia segun el perfil activo no es reproducible. Apuntar a otro corte del dataset
 *       exigiria una migracion nueva, no un cambio de propiedad.</li>
 *   <li><strong>No usa los repositorios de la aplicacion.</strong> Escribe con JDBC directo sobre la
 *       conexion de Flyway (la misma transaccion). Los adaptadores evolucionan con el codigo; una
 *       migracion ya aplicada no debe cambiar jamas de comportamiento. Ojo con el alcance de esa
 *       garantia: SI reutiliza {@code IngestaDataset}, {@code ReglaConsolidacion} y {@code ParserFechas}
 *       del S5, asi que la reproducibilidad vale mientras esas clases no cambien (una base nueva cargaria
 *       distinto de una ya migrada si cambian). Lo vigila {@code IngestaDatasetTest}.</li>
 *   <li><strong>Los identificadores de movimiento se conservan</strong> (1 a 686, en el orden del
 *       archivo) y la secuencia {@code movimiento_id_seq} continua desde el mayor, de modo que los
 *       retiros nuevos no chocan con los de la carga.</li>
 * </ul>
 *
 * <p>Flyway deduce la version y la descripcion del nombre de la clase: {@code V2__CargaInicialDataset}
 * es la version 2, "CargaInicialDataset".
 */
@Component
@SuppressWarnings("checkstyle:TypeName")
public class V2__CargaInicialDataset extends BaseJavaMigration {

    private static final Logger log = LoggerFactory.getLogger(V2__CargaInicialDataset.class);

    /** El corte del dataset de la entrega (semana_3), fijo a proposito: ver el javadoc de la clase. */
    private static final IngestaDataset.Origen DATASET = new IngestaDataset.Origen(
            "data/semana_3/intereses.csv",
            "data/semana_3/cuentas_anuales.csv",
            "data/semana_3/transacciones.csv");

    /** Cuantas filas se mandan por viaje a la base. */
    private static final int LOTE = 500;

    @Override
    public void migrate(Context contexto) {
        IngestaDataset.ResultadoIngesta carga =
                new IngestaDataset(new ReglaConsolidacion(), new ParserFechas(), DATASET).cargar();

        // Se escribe sobre la conexion de Flyway (suppressClose: no la cierra, es de Flyway), o sea
        // dentro de SU transaccion. No se abre otra: la carga es todo o nada.
        JdbcTemplate jdbc = new JdbcTemplate(new SingleConnectionDataSource(contexto.getConnection(), true));

        List<Object[]> filasCuenta = new ArrayList<>();
        List<Object[]> filasMovimiento = new ArrayList<>();
        for (Cuenta cuenta : carga.cuentas()) {
            filasCuenta.add(new Object[] {cuenta.id(), cuenta.titular(), cuenta.saldo(),
                    cuenta.edadTitular(), cuenta.tipo().name()});
            for (Movimiento m : cuenta.movimientos()) {
                filasMovimiento.add(new Object[] {m.id(), m.cuentaId(), Date.valueOf(m.fecha()),
                        m.tipo().name(), m.monto(), m.descripcion(), m.origen().name()});
            }
        }
        jdbc.batchUpdate("""
                INSERT INTO cuenta (id, titular, saldo, edad_titular, tipo) VALUES (?, ?, ?, ?, ?)""",
                filasCuenta, LOTE, (ps, fila) -> establecer(ps, fila));
        // Las cuentas van primero: movimiento.cuenta_id es una clave foranea.
        jdbc.batchUpdate("""
                INSERT INTO movimiento (id, cuenta_id, fecha, tipo, monto, descripcion, origen)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                filasMovimiento, LOTE, (ps, fila) -> establecer(ps, fila));

        // La secuencia continua despues del ultimo id asignado por la ingesta.
        jdbc.queryForObject("SELECT setval('movimiento_id_seq', ?)", Long.class, carga.ultimoIdMovimiento());

        List<Object[]> filasLote = new ArrayList<>();
        int orden = 0;
        for (TransaccionNoConciliada t : carga.loteNoConciliado()) {
            filasLote.add(new Object[] {++orden, t.id(),
                    t.fecha() == null ? null : Date.valueOf(t.fecha()), t.monto(), t.tipoCrudo()});
        }
        jdbc.batchUpdate("""
                INSERT INTO transaccion_no_conciliada (orden, id, fecha, monto, tipo_crudo)
                VALUES (?, ?, ?, ?, ?)""",
                filasLote, LOTE, (ps, fila) -> establecer(ps, fila));

        guardarReporte(jdbc, carga.reporte());

        log.info("Carga inicial del dataset: {} cuentas, {} movimientos y {} transacciones sin conciliar "
                        + "guardadas en PostgreSQL (la secuencia de movimientos sigue en {})",
                carga.cuentas().size(), filasMovimiento.size(), filasLote.size(), carga.ultimoIdMovimiento());
    }

    private static void guardarReporte(JdbcTemplate jdbc, ReporteCalidad reporte) {
        jdbc.update("""
                INSERT INTO reporte_calidad (id, generado_en, cuentas_consolidadas, movimientos_cargados,
                                             transacciones_no_conciliadas)
                VALUES (1, ?, ?, ?, ?)""",
                reporte.generadoEn(), reporte.cuentasConsolidadas(), reporte.movimientosCargados(),
                reporte.transaccionesNoConciliadas());

        int orden = 0;
        for (ReporteCalidad.ArchivoLeido a : reporte.archivos()) {
            jdbc.update("""
                    INSERT INTO reporte_calidad_archivo (orden, archivo, filas_leidas, filas_unicas,
                                                         duplicadas_descartadas)
                    VALUES (?, ?, ?, ?, ?)""",
                    ++orden, a.archivo(), a.filasLeidas(), a.filasUnicas(), a.duplicadasDescartadas());
        }
        reporte.descartesPorMotivo().forEach((motivo, cantidad) -> jdbc.update(
                "INSERT INTO reporte_calidad_descarte (motivo, cantidad) VALUES (?, ?)", motivo.name(), cantidad));
    }

    private static void establecer(java.sql.PreparedStatement ps, Object[] fila) throws java.sql.SQLException {
        for (int i = 0; i < fila.length; i++) {
            ps.setObject(i + 1, fila[i]);
        }
    }
}
