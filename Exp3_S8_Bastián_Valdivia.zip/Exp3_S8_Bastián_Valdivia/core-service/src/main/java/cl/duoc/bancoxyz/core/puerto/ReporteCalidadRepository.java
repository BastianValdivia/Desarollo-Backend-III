package cl.duoc.bancoxyz.core.puerto;

import cl.duoc.bancoxyz.core.dominio.ReporteCalidad;

/**
 * <strong>Puerto</strong> de lectura del reporte de calidad de datos de la carga inicial.
 *
 * <p>Rol en la arquitectura: en el S5 el reporte vivia dentro del cargador de CSV, que lo armaba en
 * memoria al arrancar. Desde que la carga ocurre una sola vez (migracion de Flyway) y no en cada
 * arranque, el reporte tiene que sobrevivir a la ejecucion que lo produjo: se guarda en la base y
 * cualquier replica lo lee de alli. Este puerto es esa lectura.
 *
 * <p>Sus cifras describen <strong>la carga</strong>, no el estado actual: un retiro agrega un
 * movimiento al banco y no cambia el 686 del reporte. Es lo que lo hace reproducible como
 * evidencia entre dos arranques, y entre dos replicas.
 */
public interface ReporteCalidadRepository {

    /** El reporte de la carga inicial, tal como quedo guardado. */
    ReporteCalidad obtener();
}
