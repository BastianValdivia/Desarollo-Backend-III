package cl.duoc.bancoxyz.core.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import cl.duoc.bancoxyz.core.dominio.Movimiento;

/**
 * Un movimiento tal como lo publica el core. <strong>Cinco campos, todos congelados</strong>.
 *
 * <p>Rol en la arquitectura: es el maximo de informacion que el sistema tiene sobre un apunte.
 * Cada BFF proyecta un subconjunto: el canal web quita {@code origen}, y el canal movil se queda
 * con solo tres campos ({@code fecha}, {@code tipo}, {@code monto}). Comparar este DTO con los de
 * los canales es, literalmente, ver el patron BFF en accion.
 *
 * <p><strong>Por que {@code origen} esta aqui y no en los canales.</strong> Distingue un
 * movimiento sembrado desde el CSV de uno generado por un retiro del cajero. Es informacion
 * valiosa para el backend y ruido para la pantalla de un cliente, que no tiene ningun concepto de
 * "archivo de semilla".
 *
 * @param fecha       siempre {@code yyyy-MM-dd} en la salida, aunque el archivo de origen conviva
 *                    con cuatro formatos distintos. Normalizar en la frontera es lo que impide que
 *                    la suciedad del dataset se filtre al contrato
 * @param tipo        en MAYUSCULAS. Jackson serializa el nombre del enumerado tal cual, de modo que
 *                    el contrato no puede divergir del codigo sin un error de compilacion
 * @param monto       siempre positivo; el signo vive en {@code tipo}
 * @param descripcion texto decorativo, <strong>admite {@code null}</strong> y puede contradecir al
 *                    tipo. Cuando eso ocurre, manda el tipo
 * @param origen      {@code CSV_SEMILLA} o {@code RETIRO_ATM}
 */
public record MovimientoCoreResponse(
        LocalDate fecha,
        String tipo,
        BigDecimal monto,
        String descripcion,
        String origen) {

    public static MovimientoCoreResponse de(Movimiento movimiento) {
        return new MovimientoCoreResponse(
                movimiento.fecha(),
                movimiento.tipo().name(),
                movimiento.monto(),
                movimiento.descripcion(),
                movimiento.origen().name());
    }
}
