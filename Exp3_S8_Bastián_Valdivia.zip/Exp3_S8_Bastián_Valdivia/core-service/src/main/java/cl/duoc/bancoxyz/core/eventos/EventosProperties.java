package cl.duoc.bancoxyz.core.eventos;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Valores configurables de la publicacion de eventos, bajo el prefijo {@code eventos}.
 *
 * <p>El relay viene APAGADO por defecto y se enciende en los perfiles que si tienen donde publicar
 * ({@code core-service-docker.yml}, {@code core-service-local.yml}). Asi las pruebas que arrancan la
 * aplicacion completa no intentan hablar con un Kafka que no existe, y el interruptor sirve tambien para
 * apagarlo en operacion sin tocar codigo.
 *
 * @param relay como y cuando el relay vacia el outbox hacia Kafka
 */
@ConfigurationProperties(prefix = "eventos")
public record EventosProperties(@DefaultValue Relay relay) {

    /**
     * @param habilitado  si el relay corre. Apagado, los eventos igual se escriben en el outbox y esperan
     * @param intervalo   pausa entre un ciclo y el siguiente. Es la latencia minima de entrega de un
     *                    evento nuevo: 500 ms es imperceptible para una notificacion y no satura la base
     * @param lote        maximo de eventos por ciclo. Acota el tiempo que una transaccion mantiene bloqueadas
     *                    las filas y el tamano de lo que se reenvia si un ciclo se interrumpe
     * @param plazoEnvio  cuanto espera el relay la confirmacion de Kafka de un lote. Coincide con el
     *                    {@code delivery.timeout.ms} del productor: pasado ese tiempo el productor ya se rindio
     * @param retencion   cuanto se conservan las filas YA publicadas antes de borrarlas. El outbox es una
     *                    bandeja, no un historial: el historial vive en Kafka y en la base de auditoria
     */
    public record Relay(
            @DefaultValue("false") boolean habilitado,
            @DefaultValue("500ms") Duration intervalo,
            @DefaultValue("200") int lote,
            @DefaultValue("5s") Duration plazoEnvio,
            @DefaultValue("1d") Duration retencion) {

        public Relay {
            if (lote < 1) {
                throw new IllegalArgumentException("eventos.relay.lote debe ser al menos 1.");
            }
            if (intervalo.isNegative() || intervalo.isZero()) {
                throw new IllegalArgumentException("eventos.relay.intervalo debe ser positivo.");
            }
        }
    }
}
