package cl.duoc.bancoxyz.core.api.dto;

import cl.duoc.bancoxyz.core.dominio.Pagina;

/**
 * Objeto {@code paginacion} de las respuestas paginadas. <strong>Nombres de campo congelados</strong>.
 *
 * <p>Rol en la arquitectura: traduce el {@link Pagina} del dominio al JSON exacto que el contrato
 * declara. Que exista esta clase, en vez de serializar {@code Pagina} directamente, es lo que
 * permite cambiar el dominio sin romper a los tres BFF que ya consumen la API.
 *
 * <p>Dos detalles que parecen manias y no lo son:
 * <ul>
 *   <li>{@code tamano} va <strong>sin la letra virgulilla</strong>. Un campo JSON con caracteres no
 *       ASCII funciona, pero atraviesa shells, scripts y editores con codificaciones distintas, y
 *       basta un eslabon mal configurado para que el consumidor busque una clave que no encuentra.</li>
 *   <li>{@code pagina} empieza en <strong>cero</strong>. Es la convencion de toda la API y esta
 *       declarada para que nadie tenga que descubrirla probando.</li>
 * </ul>
 */
public record PaginacionResponse(int pagina, int tamano, long totalElementos, int totalPaginas) {

    public static PaginacionResponse de(Pagina<?> pagina) {
        return new PaginacionResponse(
                pagina.pagina(), pagina.tamano(), pagina.totalElementos(), pagina.totalPaginas());
    }
}
