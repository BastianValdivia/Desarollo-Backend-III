package cl.duoc.bancoxyz.core.api.dto;

import java.util.List;

import cl.duoc.bancoxyz.core.dominio.Movimiento;
import cl.duoc.bancoxyz.core.dominio.Pagina;

/**
 * Una pagina del historial. Respuesta de {@code GET /internal/v1/cuentas/{id}/movimientos}.
 *
 * <p>Rol en la arquitectura: envuelve la lista de movimientos junto con los datos que el cliente
 * necesita para pedir la pagina siguiente. Incluye {@code cuentaId} aunque el cliente acabe de
 * escribirlo en la URL: una respuesta que se puede guardar, registrar o reenviar sin perder a quien
 * pertenece vale mucho mas que los pocos bytes que ahorraria omitirlo.
 */
public record PaginaMovimientosResponse(
        int cuentaId,
        List<MovimientoCoreResponse> movimientos,
        PaginacionResponse paginacion) {

    public static PaginaMovimientosResponse de(int cuentaId, Pagina<Movimiento> pagina) {
        return new PaginaMovimientosResponse(
                cuentaId,
                pagina.contenido().stream().map(MovimientoCoreResponse::de).toList(),
                PaginacionResponse.de(pagina));
    }
}
