package cl.duoc.bancoxyz.core.puerto;

import java.math.BigDecimal;
import java.util.function.Supplier;

import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;

/**
 * <strong>Puerto</strong> que garantiza que una operacion pedida varias veces con la misma clave
 * se ejecute una sola vez.
 *
 * <p><strong>El problema real que resuelve.</strong> Un cajero automatico envia la orden de
 * retiro y la red se corta antes de que llegue la respuesta. El cajero no tiene forma de saber si
 * el banco alcanzo a descontar o no. Si reintenta y el banco vuelve a descontar, el cliente pierde
 * dinero; si no reintenta y el banco no habia descontado, el cliente no recibe su plata. La unica
 * salida es que el reintento sea <em>seguro</em>: el cajero manda la misma
 * {@code Idempotency-Key} y el banco, si ya la vio, devuelve el mismo comprobante sin volver a
 * tocar el saldo.
 *
 * <p><strong>Por que este registro vive en el core y no en el BFF del cajero.</strong> Es la
 * misma razon por la que existe el core: la idempotencia protege una <em>mutacion de estado</em>,
 * y el estado tiene un unico dueno. Si el registro viviera en {@code bff-atm}, dos instancias de
 * ese BFF tendrian cada una su propio registro, no compartirian nada, y un reintento que cayera en
 * la otra instancia descontaria por segunda vez. El BFF, por tanto, <strong>reenvia</strong> la
 * cabecera y no guarda nada.
 *
 * <p><strong>Por que el metodo recibe la operacion en vez de devolver lo que encuentre.</strong>
 * La forma ingenua es "pregunto si existe; si no existe, ejecuto y guardo". Entre la pregunta y el
 * guardado caben dos reintentos simultaneos, y ambos ejecutarian el retiro. Al entregar la
 * operacion al registro, es la implementacion la que puede envolver consulta, ejecucion y
 * guardado en un unico paso indivisible.
 */
public interface RegistroIdempotencia {

    /**
     * Ejecuta {@code operacion} solo si {@code clave} no se habia usado antes <strong>en esa
     * cuenta</strong>; si ya se habia usado, devuelve el resultado guardado entonces sin volver a
     * ejecutar nada.
     *
     * <p><strong>La clave vale por cuenta, no globalmente.</strong> La {@code Idempotency-Key} la elige
     * el cliente, y dos clientes distintos pueden elegir la misma cadena. Si el registro la tratara
     * como global, el segundo recibiria el comprobante del primero (folio y saldos de otra cuenta) sin
     * que se le descontara nada: una filtracion de datos y un retiro confirmado sin ejecutarse. Por
     * eso la identidad de un reintento es el par (cuenta, clave).
     *
     * <p>Dentro de la misma cuenta, un reintento repite la peticion tal cual; si la clave llega con
     * <em>otro importe</em> no es un reintento sino una clave reutilizada, y se rechaza.
     *
     * @param cuentaId  cuenta de la que se retira: acota el alcance de la clave
     * @param clave     valor de la cabecera {@code Idempotency-Key}
     * @param monto     importe pedido: se compara con el de la primera vez para detectar la reutilizacion
     * @param operacion el retiro a ejecutar, envuelto para que solo corra si hace falta
     * @return el comprobante, nuevo o recuperado. En ambos casos con el <strong>mismo folio</strong>
     * @throws cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaReutilizadaException si la clave ya
     *         se uso en esa cuenta con un importe distinto
     */
    ResultadoRetiro ejecutarUnaSolaVez(int cuentaId, String clave, BigDecimal monto,
                                       Supplier<ResultadoRetiro> operacion);
}
