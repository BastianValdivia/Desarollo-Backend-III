package cl.duoc.bancoxyz.core.seguridad;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

import jakarta.servlet.DispatcherType;

/**
 * La seguridad del core: un <strong>servidor de recursos OAuth2</strong>.
 *
 * <p>Desde la fase F4 el core no se protege con una cabecera fija sino con tokens JWT que emite el
 * auth-server (el unico emisor del sistema). Por cada peticion a {@code /internal/**}, Spring Security
 * valida el token en este orden y se detiene en el primer fallo (401):
 * <ol>
 *   <li><strong>Que haya un token</strong> {@code Authorization: Bearer ...}.</li>
 *   <li><strong>La firma</strong>, con la clave publica del auth-server que se descarga de su JWKS
 *       ({@code spring.security.oauth2.resourceserver.jwt.jwk-set-uri}). Un token firmado con otra clave
 *       no pasa.</li>
 *   <li><strong>El emisor</strong> ({@code iss}) exacto del auth-server de este despliegue.</li>
 *   <li><strong>La vigencia</strong> ({@code exp} y {@code nbf}), con la tolerancia de reloj por
 *       defecto de Spring Security (60 s).</li>
 *   <li><strong>La audiencia</strong> ({@code aud}): el token debe haberse emitido para
 *       {@code core-service}. Un token firmado y vigente pero pensado para otro servicio se rechaza: es
 *       lo que impide reutilizar en el core un token obtenido para otra cosa.</li>
 * </ol>
 * Solo despues se evalua la autorizacion (403): el scope que exige el endpoint.
 *
 * <h2>Scope por endpoint (minimo privilegio, decision D2)</h2>
 *
 * <p>Cada cliente del auth-server tiene registrados solo los scopes que necesita, y el core exige uno
 * distinto por operacion. Con eso, un BFF comprometido llega solo hasta donde llegan sus scopes:
 * <table>
 *   <caption>Scope que exige cada endpoint y quien lo tiene</caption>
 *   <tr><th>Endpoint</th><th>Scope</th><th>Clientes</th></tr>
 *   <tr><td>GET /internal/v1/cuentas/{id}</td><td>cuentas:leer</td><td>bff-web, bff-mobile</td></tr>
 *   <tr><td>GET /internal/v1/cuentas/{id}/movimientos</td><td>movimientos:leer</td><td>bff-web</td></tr>
 *   <tr><td>GET /internal/v1/cuentas/{id}/saldo</td><td>saldo:leer</td><td>bff-atm</td></tr>
 *   <tr><td>POST /internal/v1/cuentas/{id}/retiros</td><td>retiros:ejecutar</td><td>bff-atm</td></tr>
 *   <tr><td>GET /internal/v1/admin/**</td><td>auditoria:leer</td><td>bff-web</td></tr>
 * </table>
 *
 * <h2>Scope y autoridad</h2>
 *
 * <p>Un <em>scope</em> es lo que el auth-server le concede a un cliente en el token ({@code scope}); una
 * <em>autoridad</em> es como Spring Security representa un permiso dentro de la aplicacion. Spring
 * convierte cada scope en la autoridad {@code SCOPE_<scope>} (por eso las reglas de abajo preguntan por
 * {@code SCOPE_cuentas:leer}), y {@code hasAuthority} compara contra esa lista.
 *
 * <h2>Lo que no esta permitido, por defecto</h2>
 *
 * <p>Toda regla es explicita (metodo y ruta) y lo que no coincide con ninguna cae en
 * {@code denyAll()}. No hay una lista de "rutas protegidas" con el resto abierto, que es la forma del
 * filtro anterior y la que se podia eludir con variantes de la URL: aqui una ruta que nadie declaro,
 * escrita como se escriba, se rechaza. Las variantes con {@code ;} o {@code %2e} las rechaza ademas el
 * firewall de Spring Security antes de llegar a estas reglas. Lo prueba
 * {@code SeguridadOAuth2CoreTest}.
 *
 * <p>No hay sesion ni CSRF: es una API sin estado, cuyos llamantes son servicios y no navegadores, y
 * cada peticion trae su propio token.
 */
@Configuration(proxyBeanMethods = false)
public class SeguridadCoreConfig {

    /** Prefijo que Spring Security le pone a cada scope al convertirlo en autoridad. */
    private static final String SCOPE = "SCOPE_";

    public static final String CUENTAS_LEER = SCOPE + "cuentas:leer";
    public static final String MOVIMIENTOS_LEER = SCOPE + "movimientos:leer";
    public static final String SALDO_LEER = SCOPE + "saldo:leer";
    public static final String RETIROS_EJECUTAR = SCOPE + "retiros:ejecutar";
    public static final String AUDITORIA_LEER = SCOPE + "auditoria:leer";

    private static final String CUENTAS = "/internal/v1/cuentas/";

    @Bean
    @Order(Ordered.LOWEST_PRECEDENCE)
    public SecurityFilterChain cadenaDelServicio(HttpSecurity http, ManejadorSeguridadCore manejador)
            throws Exception {
        http
                .authorizeHttpRequests(reglas -> reglas
                        // Cuando el contenedor reenvia a /error una respuesta que ya tiene su estado (un 500 de
                        // un filtro, por ejemplo), esa segunda pasada no debe exigir token: si lo hiciera, el
                        // 500 llegaria al cliente disfrazado de 401. Solo vale para el reenvio interno: un
                        // cliente que pida /error por la red cae en el denyAll del final.
                        .dispatcherTypeMatchers(DispatcherType.ERROR).permitAll()
                        .requestMatchers(HttpMethod.GET, CUENTAS + "*").hasAuthority(CUENTAS_LEER)
                        .requestMatchers(HttpMethod.GET, CUENTAS + "*/movimientos").hasAuthority(MOVIMIENTOS_LEER)
                        .requestMatchers(HttpMethod.GET, CUENTAS + "*/saldo").hasAuthority(SALDO_LEER)
                        .requestMatchers(HttpMethod.POST, CUENTAS + "*/retiros").hasAuthority(RETIROS_EJECUTAR)
                        .requestMatchers(HttpMethod.GET, "/internal/v1/admin/**").hasAuthority(AUDITORIA_LEER)
                        .anyRequest().denyAll())
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(Customizer.withDefaults())
                        .authenticationEntryPoint(manejador)
                        .accessDeniedHandler(manejador))
                .exceptionHandling(errores -> errores
                        .authenticationEntryPoint(manejador)
                        .accessDeniedHandler(manejador))
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(sesion -> sesion.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
        return http.build();
    }
}
