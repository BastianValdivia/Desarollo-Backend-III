package cl.duoc.bancoxyz.core.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import cl.duoc.bancoxyz.core.dominio.Pagina;
import cl.duoc.bancoxyz.core.dominio.TransaccionNoConciliada;

/**
 * Una pagina del lote de {@code transacciones.csv}, el archivo que no se pudo vincular a ninguna
 * cuenta. Respuesta de {@code GET /internal/v1/admin/transacciones-no-conciliadas}.
 *
 * <p>Rol en la arquitectura: expone un problema operativo real en vez de esconderlo. El archivo no
 * tiene columna de cuenta y no puede tenerla, asi que no hay forma honesta de sumarlo al historial
 * de nadie. En lugar de descartarlo en silencio, el sistema lo publica como lo que es: un lote
 * pendiente de conciliacion, destinado a un ejecutivo del banco, que es quien tiene por trabajo
 * conciliarlo.
 *
 * <p><strong>Aqui la suciedad se muestra a proposito.</strong> {@code fecha} y {@code monto} son
 * nulos cuando el archivo no traia un valor legible, y {@code tipo} se publica <em>crudo</em>,
 * incluidos los valores {@code invalid} y {@code desconocido}. Limpiarlos produciria una lista
 * prolija que afirmaria algo falso: que el lote esta conciliado.
 */
public record TransaccionesNoConciliadasResponse(
        List<TransaccionResponse> transacciones,
        PaginacionResponse paginacion) {

    /**
     * @param id        identificador propio del archivo, de 1 a 1000.
     *                  <strong>No es un numero de cuenta</strong>
     * @param tipo      valor literal de la columna, sin normalizar
     */
    public record TransaccionResponse(long id, LocalDate fecha, BigDecimal monto, String tipo) {
    }

    public static TransaccionesNoConciliadasResponse de(Pagina<TransaccionNoConciliada> pagina) {
        return new TransaccionesNoConciliadasResponse(
                pagina.contenido().stream()
                        .map(t -> new TransaccionResponse(t.id(), t.fecha(), t.monto(), t.tipoCrudo()))
                        .toList(),
                PaginacionResponse.de(pagina));
    }
}
