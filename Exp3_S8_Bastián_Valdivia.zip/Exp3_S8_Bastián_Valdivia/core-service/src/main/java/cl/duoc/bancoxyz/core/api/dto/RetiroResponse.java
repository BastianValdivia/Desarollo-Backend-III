package cl.duoc.bancoxyz.core.api.dto;

import java.math.BigDecimal;

import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;

/**
 * Comprobante de un retiro: <strong>cuatro campos congelados</strong>.
 *
 * <p>Rol en la arquitectura: es lo que el core le devuelve al canal cajero, y es la prueba
 * documental de la operacion. Que incluya el saldo anterior y el posterior, y no solo el final, no
 * es redundancia: permite que el comprobante se audite por si mismo, sin tener que consultar el
 * estado de la cuenta en otro momento.
 *
 * <p><strong>Lo que este DTO deliberadamente no tiene: el desglose de billetes.</strong> El canal
 * cajero agrega ese campo por su cuenta. El core no sabe de billetes y no debe saber: las
 * denominaciones son configuracion de una maquina concreta, y un retiro por transferencia o por
 * caja no tiene ninguna. Meter {@code desglose} aqui contaminaria el backend de dominio con un
 * concepto de presentacion y ataria el banco entero al inventario de un cajero.
 *
 * <p><strong>El folio ante un reintento es el mismo.</strong> Esa es la promesa observable de la
 * idempotencia: enviar dos veces la misma {@code Idempotency-Key} devuelve dos respuestas
 * identicas, con un solo descuento efectivo. Si los folios difieren, hubo dos retiros.
 */
public record RetiroResponse(
        String folio,
        BigDecimal saldoAnterior,
        BigDecimal montoRetirado,
        BigDecimal saldoPosterior) {

    public static RetiroResponse de(ResultadoRetiro resultado) {
        return new RetiroResponse(
                resultado.folio(),
                resultado.saldoAnterior(),
                resultado.montoRetirado(),
                resultado.saldoPosterior());
    }
}
