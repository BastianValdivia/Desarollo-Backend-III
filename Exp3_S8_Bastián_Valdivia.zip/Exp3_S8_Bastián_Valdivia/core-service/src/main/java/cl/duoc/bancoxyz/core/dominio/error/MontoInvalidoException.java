package cl.duoc.bancoxyz.core.dominio.error;

import java.math.BigDecimal;

/**
 * El monto de un retiro no es un importe que tenga sentido: viene nulo, en cero o negativo.
 *
 * <p>Rol en la arquitectura: es la <strong>defensa en profundidad</strong> del core. Las reglas de
 * monto del cajero (multiplo de 1.000, minimo 1.000, tope 10.000) son politica del canal y viven
 * en {@code bff-atm}, que las aplica antes de llamar aqui. Este core, sin embargo, es el dueno del
 * estado y no puede confiar en que todos sus clientes se comporten: un monto negativo, tratado
 * como retiro, <em>aumentaria</em> el saldo. Por eso el core valida lo minimo e innegociable, que
 * es que el importe sea positivo.
 *
 * <p>Se traduce a <strong>400 Bad Request</strong>: a diferencia del saldo insuficiente, aqui el
 * problema esta en la peticion misma y reintentarla tal cual siempre va a fallar.
 *
 * <p>Nota sobre el contrato: el catalogo congelado de motivos cubre los errores que un
 * <em>canal</em> devuelve a un cliente, y no incluye ningun valor para el 400 porque, en el flujo
 * normal, el cajero rechaza antes cualquier monto raro y esta respuesta nunca llega a verse desde
 * fuera. El motivo {@code monto_no_positivo} es por tanto una extension interna del core,
 * declarada aqui para que no se lea como un descuido.
 */
public class MontoInvalidoException extends ExcepcionNegocio {

    private final BigDecimal montoSolicitado;

    public MontoInvalidoException(BigDecimal montoSolicitado) {
        super("monto_no_positivo",
                "El monto de un retiro debe ser mayor que cero, y se recibio: " + montoSolicitado);
        this.montoSolicitado = montoSolicitado;
    }

    public BigDecimal montoSolicitado() {
        return montoSolicitado;
    }
}
