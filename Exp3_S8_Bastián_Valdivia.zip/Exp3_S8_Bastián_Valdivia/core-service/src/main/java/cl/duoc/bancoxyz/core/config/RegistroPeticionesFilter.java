package cl.duoc.bancoxyz.core.config;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Deja una linea de log por peticion con <strong>la instancia que la atendio</strong>.
 *
 * <p>Rol en la arquitectura: desde F3 el core corre en dos replicas detras de Eureka, y los BFF
 * reparten las llamadas entre ellas con un balanceador de carga del lado del cliente. Cuando algo
 * sale bien, nadie ve cual de las dos respondio; este filtro lo hace visible. Es la evidencia directa
 * del reparto ("estas peticiones las atendio la instancia A y estas la B") y, en las pruebas de
 * resiliencia de F6, de que el trafico pasa a la replica sobreviviente cuando la otra cae.
 *
 * <p><strong>El identificador de instancia</strong> es el nombre de host del contenedor (los
 * primeros doce caracteres de su id, los mismos que muestra {@code docker ps}) junto con su IP en la
 * red interna, que es la que Eureka registra. Se obtiene de las propiedades que Spring Cloud ya
 * resuelve ({@code spring.cloud.client.hostname} y {@code spring.cloud.client.ip-address}), de modo
 * que coincide con lo que se ve en el dashboard de Eureka.
 *
 * <p>Corre en el puerto de servicio, no en el de gestion: los healthchecks de Docker (cada 10 s por
 * replica) no llenan el log. Registra metodo, ruta (sin parametros de consulta: no hay motivo para
 * copiar al log datos del cliente), estado y duracion. Va primero en la cadena para ver tambien las
 * peticiones que otro filtro rechaza con 401.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 10)
public class RegistroPeticionesFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(RegistroPeticionesFilter.class);

    private final String instancia;

    public RegistroPeticionesFilter(Environment entorno) {
        String host = entorno.getProperty("spring.cloud.client.hostname", "desconocido");
        String ip = entorno.getProperty("spring.cloud.client.ip-address", "?");
        this.instancia = host + " (" + ip + ")";
    }

    @Override
    protected void doFilterInternal(HttpServletRequest peticion, HttpServletResponse respuesta,
                                    FilterChain cadena) throws ServletException, IOException {
        long inicio = System.nanoTime();
        try {
            cadena.doFilter(peticion, respuesta);
        } finally {
            log.info("{} {} -> {} en {} ms, atendida por la instancia {}",
                    peticion.getMethod(), peticion.getRequestURI(), respuesta.getStatus(),
                    (System.nanoTime() - inicio) / 1_000_000, instancia);
        }
    }
}
