package cl.duoc.bancoxyz.core.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import cl.duoc.bancoxyz.core.api.dto.RespuestaErrorCore;
import cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaInvalidaException;
import cl.duoc.bancoxyz.core.dominio.error.ClaveIdempotenciaReutilizadaException;
import cl.duoc.bancoxyz.core.dominio.error.CuentaNoEncontradaException;
import cl.duoc.bancoxyz.core.dominio.error.ExcepcionNegocio;
import cl.duoc.bancoxyz.core.dominio.error.MontoInvalidoException;
import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Convierte cualquier fallo del core en un cuerpo <strong>RFC 7807</strong> uniforme.
 *
 * <h2>Que es un RestControllerAdvice, para quien no lo ha visto</h2>
 *
 * <p>Es una clase que Spring consulta cuando un controlador lanza una excepcion. En lugar de que
 * cada metodo tenga su propio {@code try/catch} para traducir errores a respuestas HTTP, se
 * escriben los casos <strong>una sola vez</strong> aqui. El beneficio practico es doble: los
 * controladores quedan sin ruido, y ningun camino puede olvidarse de traducir un error y terminar
 * devolviendo la pagina de error generica del servidor.
 *
 * <h2>Por que la traduccion de motivo a codigo HTTP vive aqui y no en las excepciones</h2>
 *
 * <p>Las excepciones de {@code dominio.error} no conocen HTTP: no tienen ningun campo con un 404 ni
 * un 409. Eso es deliberado. La regla "no se puede retirar mas de lo que hay" es cierta tambien si
 * manana el core se consumiera por mensajeria, donde los codigos HTTP no significan nada. La
 * traduccion es asunto de la capa que habla HTTP, y tenerla toda junta en el metodo
 * {@link #estadoPara} hace que se pueda leer el mapeo completo de un vistazo, en vez de tener que
 * abrir cinco clases de excepcion para reconstruirlo.
 *
 * <h2>La distincion 400 contra 409, que se implementa mal a menudo</h2>
 *
 * <p>Un monto negativo es <strong>400</strong>: la peticion esta mal formada y reintentarla tal cual
 * siempre fallara. Un saldo que no alcanza es <strong>409</strong>: la peticion es impecable y es el
 * <em>estado</em> el que no da; esa misma peticion, despues de un deposito, funcionaria sin cambiar
 * una coma. Elegir el codigo correcto le dice al cliente si debe corregir su peticion o reintentar
 * mas tarde, que son dos acciones muy distintas.
 *
 * <h2>Por que los motivos se escriben aqui a mano y no se importan de una constante</h2>
 *
 * <p>Los cuatro literales que emite esta clase ({@code recurso_no_encontrado},
 * {@code metodo_no_permitido}, {@code peticion_invalida} y {@code error_interno}) existen tambien
 * como constantes en {@code MotivosError}, dentro de {@code plataforma-comun}, y los tres BFF los
 * importan de alli. El core no: el contrato le prohibe depender de ese modulo, porque no emite
 * tokens ni consume el core y agregar la dependencia por cuatro cadenas haria ficticia la frontera
 * entre el backend de dominio y los canales. Asi que para este servicio la fuente compartida es la
 * seccion 7.1 del contrato y no un archivo Java. La consecuencia practica, que conviene tener
 * presente: si alguna vez cambia la grafia de un motivo, esta clase hay que revisarla a mano, y no
 * dejara de compilar como aviso.
 *
 * <h2>Por que nunca se filtra un stacktrace</h2>
 *
 * <p>El manejador general devuelve un texto neutro y deja el detalle tecnico en el registro del
 * servidor. Un stacktrace en el cuerpo de la respuesta le entrega a cualquiera el mapa de las
 * clases internas y las versiones de las librerias, que es informacion util solo para quien quiera
 * atacar el sistema. El diagnostico se hace en el log, que esta del lado seguro.
 */
@RestControllerAdvice
public class ManejadorErroresCore {

    private static final Logger log = LoggerFactory.getLogger(ManejadorErroresCore.class);

    /**
     * Todas las reglas de negocio incumplidas, con un solo metodo.
     *
     * <p>Captura la clase base {@link ExcepcionNegocio}, de modo que agregar una excepcion de
     * negocio nueva no obliga a tocar esta clase: basta declarar su codigo en {@link #estadoPara}.
     */
    @ExceptionHandler(ExcepcionNegocio.class)
    public ResponseEntity<RespuestaErrorCore> manejarNegocio(ExcepcionNegocio excepcion,
                                                            HttpServletRequest peticion) {
        HttpStatus estado = estadoPara(excepcion);

        // Nivel info y no error: una regla de negocio incumplida es funcionamiento normal del
        // sistema, no una averia. Registrar 409 como error llenaria el log de ruido y haria que los
        // errores de verdad pasen desapercibidos.
        log.info("Regla de negocio rechazada en {} {}: {} ({})",
                peticion.getMethod(), peticion.getRequestURI(), excepcion.motivo(), estado.value());

        return construir(estado, tituloPara(estado), excepcion.motivo(),
                excepcion.getMessage(), peticion);
    }

    /**
     * Mapa completo de regla de negocio a codigo HTTP. <strong>Es el unico lugar donde vive esta
     * traduccion.</strong>
     */
    private HttpStatus estadoPara(ExcepcionNegocio excepcion) {
        if (excepcion instanceof CuentaNoEncontradaException) {
            return HttpStatus.NOT_FOUND;
        }
        if (excepcion instanceof SaldoInsuficienteException) {
            return HttpStatus.CONFLICT;
        }
        if (excepcion instanceof MontoInvalidoException || excepcion instanceof ClaveIdempotenciaInvalidaException) {
            return HttpStatus.BAD_REQUEST;
        }
        // 422 y no 409: el 409 de este servicio significa "saldo insuficiente" y los BFF lo traducen asi;
        // una clave reutilizada con otro importe es una peticion que se entiende pero no se procesa, y
        // reintentarla igual siempre fallara (hace falta una clave nueva).
        if (excepcion instanceof ClaveIdempotenciaReutilizadaException) {
            return HttpStatus.UNPROCESSABLE_ENTITY;
        }
        // Una excepcion de negocio nueva y sin mapear cae aqui. Se elige 422 (la peticion se
        // entendio pero no se pudo procesar) y no 500, porque sigue siendo un rechazo de negocio y
        // no una averia del servidor: mentir con un 500 haria que el cliente reintentara en vano.
        return HttpStatus.UNPROCESSABLE_ENTITY;
    }

    private String tituloPara(HttpStatus estado) {
        return switch (estado) {
            case NOT_FOUND -> "Recurso no encontrado";
            case CONFLICT -> "Operacion rechazada";
            case BAD_REQUEST -> "Peticion invalida";
            default -> "Operacion no procesable";
        };
    }

    /**
     * Una ruta que no existe en el core.
     *
     * <p>Se traduce al mismo motivo {@code recurso_no_encontrado} que una cuenta inexistente. Es
     * una decision, no un descuido: desde fuera, "esta ruta no existe" y "este recurso no existe"
     * son la misma informacion, y distinguirlas solo le diria a quien sondea el servicio cuales de
     * sus rutas adivinadas son correctas.
     *
     * <p><strong>Por que se declaran DOS excepciones y no una.</strong> Spring cambio de mecanismo:
     * {@code NoHandlerFoundException} es la clasica, y solo se lanza si se activa la propiedad
     * {@code spring.mvc.throw-exception-if-no-handler-found}. Desde Spring Framework 6.1, una ruta
     * sin controlador cae en el manejador de recursos estaticos y termina lanzando
     * {@code NoResourceFoundException}. Declarar solo la primera deja la segunda sin capturar, y
     * entonces la atrapa el manejador general y <strong>responde 500 a lo que es un 404</strong>:
     * un error de cliente disfrazado de averia del servidor. Es exactamente el tipo de detalle que
     * solo se descubre probando de verdad la ruta inexistente.
     */
    @ExceptionHandler({NoHandlerFoundException.class, NoResourceFoundException.class})
    public ResponseEntity<RespuestaErrorCore> manejarRutaInexistente(HttpServletRequest peticion) {
        return construir(HttpStatus.NOT_FOUND, "Recurso no encontrado", "recurso_no_encontrado",
                "No existe el recurso solicitado en este servicio", peticion);
    }

    /**
     * La ruta existe pero no acepta ese verbo (por ejemplo, un {@code DELETE} sobre una cuenta).
     *
     * <p>Es <strong>405</strong> y no 404: decir "no existe" cuando el recurso si existe confundiria
     * a quien esta integrando. La cabecera {@code Allow}, que Spring agrega, le dice ademas que
     * verbos si puede usar.
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<RespuestaErrorCore> manejarVerboNoSoportado(
            HttpRequestMethodNotSupportedException excepcion, HttpServletRequest peticion) {

        return construir(HttpStatus.METHOD_NOT_ALLOWED, "Metodo no permitido", "metodo_no_permitido",
                "El recurso existe pero no acepta el verbo " + excepcion.getMethod(), peticion);
    }

    /**
     * Parametros que el servicio no puede interpretar: un tipo de movimiento desconocido, una fecha
     * mal escrita, un cuerpo JSON que no encaja.
     *
     * <p>Se agrupan porque desde el punto de vista del cliente son el mismo problema: lo que mando
     * no se entiende, y tiene que corregirlo el. Sin este metodo, cada uno de estos casos devolveria
     * el cuerpo de error por defecto del servidor, que no se parece en nada al resto de la API.
     */
    @ExceptionHandler({IllegalArgumentException.class,
            org.springframework.web.method.annotation.MethodArgumentTypeMismatchException.class,
            org.springframework.http.converter.HttpMessageNotReadableException.class,
            org.springframework.web.bind.MissingServletRequestParameterException.class})
    public ResponseEntity<RespuestaErrorCore> manejarPeticionInvalida(Exception excepcion,
                                                                     HttpServletRequest peticion) {
        log.info("Peticion invalida en {} {}: {}",
                peticion.getMethod(), peticion.getRequestURI(), excepcion.getMessage());

        return construir(HttpStatus.BAD_REQUEST, "Peticion invalida", "peticion_invalida",
                "La peticion no se pudo interpretar: revise parametros, formato de fecha y cuerpo JSON",
                peticion);
    }

    /**
     * El cuerpo llego con un {@code Content-Type} que la ruta no consume (el retiro exige
     * {@code application/json}).
     *
     * <p>Es un error de quien llama, no del core: 415 y no 500. Sin este manejador la red de
     * seguridad de mas abajo lo convertia en un "Error interno" que mandaba a un operador a buscar
     * una averia donde solo faltaba una cabecera. El {@code motivo} es {@code peticion_invalida},
     * el mismo del 400: reintentar igual siempre fallara.
     */
    @ExceptionHandler(org.springframework.web.HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<RespuestaErrorCore> manejarTipoContenidoNoSoportado(
            org.springframework.web.HttpMediaTypeNotSupportedException excepcion,
            HttpServletRequest peticion) {
        log.info("Tipo de contenido no soportado en {} {}: {}",
                peticion.getMethod(), peticion.getRequestURI(), excepcion.getContentType());

        return construir(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "Tipo de contenido no soportado",
                "peticion_invalida", "El cuerpo debe enviarse como application/json", peticion);
    }

    /**
     * La red de seguridad: cualquier fallo no previsto.
     *
     * <p>Existe para que <strong>ninguna</strong> respuesta del core se salga del formato
     * RFC 7807, ni siquiera cuando el error es un defecto del propio codigo. Es el unico manejador
     * que registra en nivel {@code error} y con la traza completa, porque aqui si hay una averia
     * que alguien tiene que arreglar. Al cliente le llega un texto neutro: el detalle tecnico se
     * queda del lado del servidor.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<RespuestaErrorCore> manejarInesperado(Exception excepcion,
                                                               HttpServletRequest peticion) {
        log.error("Fallo no controlado en {} {}", peticion.getMethod(), peticion.getRequestURI(), excepcion);

        return construir(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno", "error_interno",
                "El servicio no pudo completar la operacion", peticion);
    }

    /**
     * Arma la respuesta, fijando siempre el tipo de contenido {@code application/problem+json}.
     *
     * <p>Ese tipo es parte del estandar y no un adorno: le dice al cliente, desde la cabecera y sin
     * mirar el cuerpo, que lo que viene describe un problema. Fijarlo en un unico lugar garantiza
     * que ningun manejador se olvide de ponerlo.
     */
    private ResponseEntity<RespuestaErrorCore> construir(HttpStatus estado, String titulo,
                                                         String motivo, String detalle,
                                                         HttpServletRequest peticion) {
        return ResponseEntity.status(estado)
                .contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .body(RespuestaErrorCore.de(estado, titulo, motivo, detalle, peticion.getRequestURI()));
    }
}
