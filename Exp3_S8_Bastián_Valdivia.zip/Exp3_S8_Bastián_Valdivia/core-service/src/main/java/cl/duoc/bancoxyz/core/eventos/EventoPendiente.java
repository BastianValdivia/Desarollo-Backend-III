package cl.duoc.bancoxyz.core.eventos;

/**
 * Una fila del outbox que espera publicarse.
 *
 * @param id      posicion en el outbox (el relay publica en este orden)
 * @param eventId identificador del evento (el del sobre)
 * @param topico  topico de destino
 * @param clave   clave del registro de Kafka
 * @param payload el sobre ya serializado
 */
public record EventoPendiente(long id, String eventId, String topico, String clave, String payload) {
}
