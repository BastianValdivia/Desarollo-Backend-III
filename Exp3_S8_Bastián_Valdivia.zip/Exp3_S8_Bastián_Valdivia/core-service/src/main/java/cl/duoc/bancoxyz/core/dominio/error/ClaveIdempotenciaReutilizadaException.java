package cl.duoc.bancoxyz.core.dominio.error;

import java.math.BigDecimal;

/**
 * La misma {@code Idempotency-Key} ya se uso en esa cuenta para retirar <strong>otro importe</strong>.
 *
 * <p>Rol en la arquitectura: un reintento legitimo repite la peticion tal cual, asi que misma cuenta y
 * misma clave implican mismo importe. Si el importe cambia, el cliente esta reutilizando una clave
 * para una operacion distinta (un defecto suyo). Devolverle el comprobante guardado le confirmaria un
 * retiro que no pidio, y ejecutarlo ignoraria la garantia de "una sola vez por clave"; la unica
 * respuesta segura es rechazarlo y que elija una clave nueva.
 *
 * <p>La clave se considera <em>por cuenta</em>: la misma cadena en otra cuenta no es un reintento sino
 * una operacion distinta, y nunca llega aqui (ver {@code V3__idempotencia_por_cuenta.sql}). El mensaje
 * no incluye el importe ni el folio guardados: revelarlos no aporta al cliente legitimo, que ya
 * conoce su propia peticion.
 */
public class ClaveIdempotenciaReutilizadaException extends ExcepcionNegocio {

    public ClaveIdempotenciaReutilizadaException(int cuentaId, BigDecimal montoPedido) {
        super("clave_idempotencia_reutilizada",
                "La Idempotency-Key ya se uso en la cuenta " + cuentaId
                        + " para un retiro de otro importe (ahora se pidio " + montoPedido.toPlainString()
                        + "). Use una clave nueva para una operacion distinta");
    }
}
