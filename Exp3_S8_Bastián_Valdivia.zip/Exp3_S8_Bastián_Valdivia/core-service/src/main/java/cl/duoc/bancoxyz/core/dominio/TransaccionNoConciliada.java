package cl.duoc.bancoxyz.core.dominio;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Una fila de {@code transacciones.csv}, el archivo que <strong>no se pudo vincular a ninguna
 * cuenta</strong>.
 *
 * <p>Rol en la arquitectura: representa un lote operativo pendiente de conciliacion. No es un
 * {@link Movimiento} y no se mezcla con ellos, porque no se sabe a que cuenta pertenece: el
 * archivo tiene ids propios del 1 al 1000, sin repetir, y ninguna columna vinculable a los
 * {@code cuenta_id} del resto del dataset.
 *
 * <p><strong>Por que estos datos se exponen crudos, con su suciedad a la vista.</strong> Los tres
 * campos se entregan tal como venian: la fecha es nula si era ilegible, el monto es nulo si venia
 * vacio, y el tipo se publica sin normalizar, incluidos los 308 {@code invalid} y los 63
 * {@code desconocido}. Maquillarlos daria una lista prolija que afirmaria algo falso: que el lote
 * esta conciliado. Un lote no conciliado que se presenta como tal es informacion; el mismo lote
 * presentado como si estuviera limpio es una mentira operativa.
 *
 * <p><strong>Lo que esta prohibido hacer con este archivo, y por que.</strong> La tentacion obvia
 * es repartir las 1000 filas entre las 50 cuentas por modulo, por turno o al azar, y tener asi un
 * historial mas nutrido. Eso seria <em>fabricar datos financieros</em>: inventar que una persona
 * concreta hizo una transaccion concreta. Es peor que declarar honestamente que el archivo no se
 * pudo conciliar, y es la clase de decision que un revisor detecta de inmediato.
 *
 * @param id        identificador propio del archivo, de 1 a 1000. <strong>No es un numero de
 *                  cuenta</strong>, y confundirlos es el error mas facil de cometer aqui
 * @param fecha     fecha resuelta, o nulo si no encajaba en ninguno de los cuatro formatos
 * @param monto     importe, o nulo si la celda venia vacia
 * @param tipoCrudo valor literal de la columna de tipo, sin normalizar
 */
public record TransaccionNoConciliada(long id, LocalDate fecha, BigDecimal monto, String tipoCrudo) {
}
