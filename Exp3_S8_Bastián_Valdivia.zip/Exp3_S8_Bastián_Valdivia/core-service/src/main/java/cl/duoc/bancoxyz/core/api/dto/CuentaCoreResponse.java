package cl.duoc.bancoxyz.core.api.dto;

import java.math.BigDecimal;
import java.util.List;

import cl.duoc.bancoxyz.core.dominio.Cuenta;

/**
 * La cuenta canonica completa. Es la respuesta de {@code GET /internal/v1/cuentas/{id}} y la
 * <strong>linea base de medicion</strong> del proyecto.
 *
 * <p>Rol en la arquitectura: representa "todo lo que el banco sabe de esta cuenta". Cada canal se
 * mide contra ella: si la respuesta del cajero pesa lo mismo que esta, el canal no esta adaptando
 * nada y el patron BFF no se esta ejerciendo.
 *
 * <p><strong>Dos nombres de campo que se equivocan solos si no se tiene cuidado.</strong> Es
 * {@code edadTitular} y no {@code edad}, y es {@code tipoCuenta} y no {@code tipo}. Son los nombres
 * congelados del contrato, y un desacuerdo aqui no produce un error: produce un campo que el
 * consumidor lee como nulo y muestra vacio en pantalla, que es mucho mas dificil de diagnosticar
 * que una excepcion.
 *
 * @param movimientos <strong>todos</strong> los movimientos validos. Para una cuenta sin historial
 *                    (la 130 es el caso de control) va la lista vacia {@code []} y
 *                    <strong>nunca {@code null}</strong>: un arreglo vacio le dice al cliente "no
 *                    hay nada"; un nulo le dice "arreglatelas", y cada cliente se defiende de
 *                    manera distinta o no se defiende
 */
public record CuentaCoreResponse(
        int cuentaId,
        String titular,
        String tipoCuenta,
        BigDecimal saldo,
        int edadTitular,
        String moneda,
        List<MovimientoCoreResponse> movimientos) {

    public static CuentaCoreResponse de(Cuenta cuenta, String moneda) {
        return new CuentaCoreResponse(
                cuenta.id(),
                cuenta.titular(),
                cuenta.tipo().name(),
                cuenta.saldo(),
                cuenta.edadTitular(),
                moneda,
                cuenta.movimientos().stream().map(MovimientoCoreResponse::de).toList());
    }
}
