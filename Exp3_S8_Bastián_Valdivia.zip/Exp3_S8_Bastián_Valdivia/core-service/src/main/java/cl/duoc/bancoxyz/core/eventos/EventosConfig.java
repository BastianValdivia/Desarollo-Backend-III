package cl.duoc.bancoxyz.core.eventos;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.PlatformTransactionManager;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * Enciende el relay del outbox cuando {@code eventos.relay.habilitado=true}.
 *
 * <p>Todo es condicional a esa propiedad: con el relay apagado (pruebas, o una replica que se quiera
 * excluir) el core ni siquiera crea el productor de Kafka, y los eventos solo se acumulan en el outbox.
 * El planificador usa un hilo propio de Spring: un ciclo lento (Kafka caido) no retrasa nada mas.
 */
@Configuration
@ConditionalOnProperty(name = "eventos.relay.habilitado", havingValue = "true")
@EnableScheduling
public class EventosConfig {

    /** Cierra la conexion del lider al apagar el servicio, para ceder el relevo de inmediato. */
    @Bean(destroyMethod = "close")
    public LiderRelay liderRelay(DataSource dataSource) {
        return new LiderRelay(dataSource);
    }

    @Bean
    public RelayOutbox relayOutbox(JdbcClient jdbc, PlatformTransactionManager gestor, LiderRelay lider,
                                   PublicadorKafka publicador, EventosProperties propiedades) {
        return new RelayOutbox(jdbc, gestor, lider, publicador, propiedades);
    }

    /**
     * Metrica {@code outbox.pendientes}: cuantos eventos esperan salir. Con Kafka sano es 0; con Kafka caido
     * crece con cada retiro y vuelve a 0 al recuperarse. Se consulta en
     * {@code /actuator/metrics/outbox.pendientes} (puerto de gestion).
     */
    @Bean
    public Gauge outboxPendientes(MeterRegistry registro, JdbcClient jdbc) {
        return Gauge.builder("outbox.pendientes", () -> {
                    try {
                        Long n = jdbc.sql("SELECT count(*) FROM outbox WHERE publicado IS NULL")
                                .query(Long.class).single();
                        return n.doubleValue();
                    } catch (RuntimeException e) {
                        return Double.NaN;
                    }
                })
                .description("Eventos del outbox que aun no se publicaron en Kafka")
                .register(registro);
    }
}
