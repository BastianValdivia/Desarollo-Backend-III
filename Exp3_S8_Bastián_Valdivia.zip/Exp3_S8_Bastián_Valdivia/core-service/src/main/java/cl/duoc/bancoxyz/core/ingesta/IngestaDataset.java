package cl.duoc.bancoxyz.core.ingesta;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.Movimiento;
import cl.duoc.bancoxyz.core.dominio.MotivoDescarte;
import cl.duoc.bancoxyz.core.dominio.OrigenDato;
import cl.duoc.bancoxyz.core.dominio.ReporteCalidad;
import cl.duoc.bancoxyz.core.dominio.TipoMovimiento;
import cl.duoc.bancoxyz.core.dominio.TransaccionNoConciliada;

/**
 * Lee los tres CSV del classpath, los limpia, consolida las 50 cuentas canonicas y arma el reporte
 * de calidad. <strong>No guarda nada</strong>: devuelve un {@link ResultadoIngesta} y quien lo
 * llama decide donde dejarlo.
 *
 * <p>Rol en la arquitectura: es el <strong>orquestador</strong> de la ingesta. No sabe interpretar
 * fechas (eso lo hace {@link ParserFechas}), ni resolver contradicciones (eso lo hace
 * {@link ReglaConsolidacion}), ni limpiar texto (eso lo hace {@link NormalizadorTexto}). Su trabajo
 * es leer lineas y repartirlas entre esos especialistas. Esa division es la que permite probar la
 * regla de consolidacion sin tocar un archivo.
 *
 * <h2>Que cambio respecto del S5 (F3) y que no</h2>
 *
 * <p>La logica de limpieza y consolidacion es la del S5, intacta: por eso la carga da los mismos
 * numeros (50 cuentas, 686 movimientos, 1000 sin conciliar y los mismos descartes). Cambia
 * <em>quien la invoca</em> y <em>donde deja el resultado</em>. En el S5 era un
 * {@code @PostConstruct} que sembraba mapas en memoria cada vez que el proceso arrancaba. Con
 * PostgreSQL el estado ya no se siembra en cada arranque: la carga ocurre una sola vez, dentro de
 * la migracion Flyway {@code V2__CargaInicialDataset}, que llama a esta clase y escribe el
 * resultado en la base. Asi una segunda replica, o un reinicio, encuentra los datos ya cargados
 * (y los retiros ya hechos) en lugar de volver al estado inicial.
 *
 * <p>Esta clase deliberadamente <strong>no es un bean de Spring</strong>: una migracion debe poder
 * ejecutarse antes de que exista el contexto de la aplicacion y no debe depender de la
 * configuracion de un entorno concreto (una migracion que da resultados distintos segun el
 * perfil activo no es una migracion). Se construye a mano con sus colaboradores sin estado.
 *
 * <h2>Por que se leen los archivos a mano y no con una libreria de CSV</h2>
 *
 * <p>Esta verificado sobre el dataset que los tres archivos tienen siempre el mismo numero de
 * columnas, cero comillas y cero comas dentro de un valor. En esas condiciones, agregar OpenCSV
 * seria una dependencia mas que instalar, aprender y explicar, a cambio de nada.
 *
 * <p>Lo que si es obligatorio es el {@code -1} de {@code split(",", -1)}. Sin el, Java descarta
 * los campos vacios del final de la linea, y hay descripciones vacias: la fila
 * {@code 110,24-07-2024,retiro,1500,} se convertiria en un arreglo de cuatro elementos en vez de
 * cinco, y el codigo fallaria con un error de indice o, peor, leeria la columna equivocada.
 */
public class IngestaDataset {

    private static final Logger log = LoggerFactory.getLogger(IngestaDataset.class);

    /**
     * Lo que produce la ingesta: todo el estado inicial del banco, sin haberlo guardado todavia.
     *
     * @param cuentas             las cuentas canonicas, cada una con su historial dentro
     * @param loteNoConciliado    las filas de {@code transacciones.csv}, en el orden del archivo
     * @param reporte             el reporte de calidad, congelado al terminar la carga
     * @param ultimoIdMovimiento  el mayor identificador asignado a un movimiento: la secuencia de la
     *                            base debe continuar desde aqui para que los retiros nuevos no choquen
     */
    public record ResultadoIngesta(List<Cuenta> cuentas,
                                   List<TransaccionNoConciliada> loteNoConciliado,
                                   ReporteCalidad reporte,
                                   long ultimoIdMovimiento) {
    }

    /**
     * Rutas de los tres CSV dentro del classpath. Viajan dentro del jar: el servicio carga los datos
     * en cualquier maquina sin que nadie copie archivos ni ajuste una ruta absoluta.
     */
    public record Origen(String archivoCuentas, String archivoMovimientos, String archivoTransacciones) {
    }

    private final ReglaConsolidacion reglaConsolidacion;
    private final ParserFechas parserFechas;
    private final Origen archivosOrigen;

    /**
     * Reparte identificadores a los movimientos. El CSV no trae ninguno, y sin un identificador
     * estable no habria forma de desempatar de manera reproducible dos movimientos de la misma
     * fecha al ordenar el historial. Se numeran en el orden del archivo (1 a 686), de modo que dos
     * cargas del mismo dataset producen los mismos identificadores.
     */
    private long ultimoIdMovimiento = 0;

    public IngestaDataset(ReglaConsolidacion reglaConsolidacion,
                          ParserFechas parserFechas,
                          Origen archivosOrigen) {
        this.reglaConsolidacion = reglaConsolidacion;
        this.parserFechas = parserFechas;
        this.archivosOrigen = archivosOrigen;
    }

    /**
     * Ejecuta la ingesta completa y devuelve su resultado.
     *
     * <p>Una instancia sirve para <strong>una</strong> ejecucion (lleva la secuencia de ids de
     * movimiento): para repetirla se crea otra.
     */
    public ResultadoIngesta cargar() {
        long comienzo = System.currentTimeMillis();
        ContadorDescartes contador = new ContadorDescartes();
        List<ReporteCalidad.ArchivoLeido> archivos = new ArrayList<>();

        // ORDEN OBLIGATORIO: primero los movimientos, porque la cuenta canonica se construye ya con
        // su historial dentro. Cuenta es inmutable, asi que no hay forma de "agregarle" los
        // movimientos despues sin reconstruirla entera.
        Map<Integer, List<Movimiento>> movimientosPorCuenta = cargarMovimientos(contador, archivos);
        List<Cuenta> cuentas = cargarYConsolidarCuentas(movimientosPorCuenta, contador, archivos);
        List<TransaccionNoConciliada> lote = cargarLoteNoConciliado(archivos);

        int movimientosCargados = movimientosPorCuenta.values().stream().mapToInt(List::size).sum();

        ReporteCalidad reporte = new ReporteCalidad(
                Instant.now().truncatedTo(ChronoUnit.SECONDS).toString(),
                List.copyOf(archivos),
                contador.instantanea(),
                cuentas.size(),
                movimientosCargados,
                lote.size());

        registrarLogDeCalidad(contador, archivos, cuentas.size(), movimientosCargados,
                lote.size(), System.currentTimeMillis() - comienzo);

        return new ResultadoIngesta(List.copyOf(cuentas), List.copyOf(lote), reporte, ultimoIdMovimiento);
    }

    // ------------------------------------------------------------------------------------------
    // intereses.csv  ->  las 50 cuentas canonicas
    // ------------------------------------------------------------------------------------------

    private List<Cuenta> cargarYConsolidarCuentas(Map<Integer, List<Movimiento>> movimientosPorCuenta,
                                                  ContadorDescartes contador,
                                                  List<ReporteCalidad.ArchivoLeido> archivos) {

        String archivo = archivosOrigen.archivoCuentas();
        List<String> lineas = leerLineasDeDatos(archivo);

        // PASO 0 DE LA REGLA: deduplicar filas EXACTAS antes de que nadie vote.
        // LinkedHashSet elimina repetidos y conserva el orden de aparicion, de modo que el
        // resultado no depende de codigos hash y es igual en cada arranque. Son 9 filas de 1000, y
        // ese punado basta para dar vuelta un empate y cambiar el saldo de una cuenta.
        LinkedHashSet<String> unicas = new LinkedHashSet<>(lineas);
        archivos.add(new ReporteCalidad.ArchivoLeido(
                archivo, lineas.size(), unicas.size(), lineas.size() - unicas.size()));

        // TreeMap y no HashMap: agrupa por cuenta y ademas deja las cuentas ordenadas de la 101 a la
        // 150, lo que hace que el log de arranque y cualquier volcado sean legibles y comparables.
        Map<Integer, List<FilaInteres>> filasPorCuenta = new TreeMap<>();
        for (String linea : unicas) {
            String[] c = linea.split(",", -1);
            if (c.length < 5) {
                continue;
            }
            Optional<Integer> cuentaId = enteroValido(c[0]);
            if (cuentaId.isEmpty()) {
                continue;
            }
            filasPorCuenta.computeIfAbsent(cuentaId.get(), id -> new ArrayList<>())
                    .add(new FilaInteres(c[0], c[1], c[2], c[3], c[4]));
        }

        List<Cuenta> consolidadas = new ArrayList<>();
        for (Map.Entry<Integer, List<FilaInteres>> entrada : filasPorCuenta.entrySet()) {
            int cuentaId = entrada.getKey();
            List<Movimiento> historial = movimientosPorCuenta.getOrDefault(cuentaId, List.of());

            Optional<Cuenta> cuenta =
                    reglaConsolidacion.consolidar(cuentaId, entrada.getValue(), historial, contador);

            if (cuenta.isPresent()) {
                consolidadas.add(cuenta.get());
            } else {
                // No deberia ocurrir con este dataset (invariante medido: cero campos nulos), pero
                // si ocurriera, es preferible no publicar la cuenta que publicarla inventada.
                log.warn("Ingesta: la cuenta {} no reunio ningun valor valido en algun campo "
                        + "obligatorio y queda fuera del banco", cuentaId);
            }
        }
        return consolidadas;
    }

    // ------------------------------------------------------------------------------------------
    // cuentas_anuales.csv  ->  los 686 movimientos validos
    // ------------------------------------------------------------------------------------------

    private Map<Integer, List<Movimiento>> cargarMovimientos(ContadorDescartes contador,
                                                             List<ReporteCalidad.ArchivoLeido> archivos) {

        String archivo = archivosOrigen.archivoMovimientos();
        List<String> lineas = leerLineasDeDatos(archivo);
        LinkedHashSet<String> unicas = new LinkedHashSet<>(lineas);
        archivos.add(new ReporteCalidad.ArchivoLeido(
                archivo, lineas.size(), unicas.size(), lineas.size() - unicas.size()));

        Map<Integer, List<Movimiento>> porCuenta = new TreeMap<>();
        // Reparto de formatos de fecha, solo para el log: es el numero que demuestra que los cuatro
        // formatos se reconocieron de verdad y no que uno se comio a los otros.
        Map<String, Integer> formatos = new LinkedHashMap<>();

        for (String linea : unicas) {
            String[] c = linea.split(",", -1);
            if (c.length < 5) {
                continue;
            }

            Optional<Integer> cuentaId = enteroValido(c[0]);
            if (cuentaId.isEmpty()) {
                continue;
            }

            // Orden de validacion deliberado: fecha, tipo y monto. Cada fila se cuenta por el
            // PRIMER motivo que la invalida y despues se abandona, para que la suma de descartes no
            // cuente dos veces la misma fila y el reporte siga cuadrando.
            parserFechas.formatoDetectado(c[1]).ifPresent(f -> formatos.merge(f, 1, Integer::sum));

            Optional<LocalDate> fecha = parserFechas.parsear(c[1]);
            if (fecha.isEmpty()) {
                contador.anotar(MotivoDescarte.FECHA_ILEGIBLE);
                continue;
            }

            Optional<TipoMovimiento> tipo = TipoMovimiento.parse(c[2]);
            if (tipo.isEmpty()) {
                contador.anotar(MotivoDescarte.TIPO_INVALIDO);
                continue;
            }

            Optional<BigDecimal> monto = montoPositivo(c[3]);
            if (monto.isEmpty()) {
                // Vacio, negativo o cero. No se aplica valor absoluto a proposito: el signo ya
                // viaja en la columna de tipo, asi que un monto negativo es una contradiccion y no
                // un dato del que se pueda recuperar una verdad. Son 314 filas de 1000.
                contador.anotar(MotivoDescarte.MONTO_NO_POSITIVO);
                continue;
            }

            porCuenta.computeIfAbsent(cuentaId.get(), id -> new ArrayList<>())
                    .add(new Movimiento(
                            ++ultimoIdMovimiento,
                            cuentaId.get(),
                            fecha.get(),
                            tipo.get(),
                            monto.get().setScale(2, RoundingMode.HALF_UP),
                            NormalizadorTexto.limpiarParaMostrar(c[4]),
                            OrigenDato.CSV_SEMILLA));
        }

        log.info("Ingesta: reparto de formatos de fecha reconocidos en {} -> {}", archivo, formatos);
        return porCuenta;
    }

    // ------------------------------------------------------------------------------------------
    // transacciones.csv  ->  el lote que NO se pudo conciliar
    // ------------------------------------------------------------------------------------------

    /**
     * Carga {@code transacciones.csv} tal cual, sin limpiarlo y sin vincularlo a ninguna cuenta.
     *
     * <p>Este archivo <strong>no tiene columna {@code cuenta_id}</strong> y no puede tenerla: sus
     * ids van del 1 al 1000 sin repetir y ninguna otra columna es vinculable. La tentacion obvia es
     * repartir las filas entre las cuentas por modulo, por turno o al azar, para tener un historial
     * mas nutrido. Eso seria <em>fabricar datos financieros</em>, y es peor que declarar
     * honestamente que el archivo no se pudo conciliar.
     *
     * <p>Por eso aqui no se descarta nada y no se cuenta ningun motivo: las 1000 filas se guardan
     * con la suciedad a la vista, incluidos los tipos {@code invalid} y {@code desconocido}. El
     * unico consumidor es el reporte de un ejecutivo, que es quien tiene por trabajo conciliarlo.
     */
    private List<TransaccionNoConciliada> cargarLoteNoConciliado(List<ReporteCalidad.ArchivoLeido> archivos) {
        String archivo = archivosOrigen.archivoTransacciones();
        List<String> lineas = leerLineasDeDatos(archivo);
        LinkedHashSet<String> unicas = new LinkedHashSet<>(lineas);
        archivos.add(new ReporteCalidad.ArchivoLeido(
                archivo, lineas.size(), unicas.size(), lineas.size() - unicas.size()));

        List<TransaccionNoConciliada> lote = new ArrayList<>();
        for (String linea : lineas) {
            String[] c = linea.split(",", -1);
            if (c.length < 4) {
                continue;
            }
            Optional<Integer> id = enteroValido(c[0]);
            if (id.isEmpty()) {
                continue;
            }
            lote.add(new TransaccionNoConciliada(
                    id.get(),
                    parserFechas.parsear(c[1]).orElse(null),
                    montoCrudo(c[2]).orElse(null),
                    NormalizadorTexto.limpiarParaMostrar(c[3])));
        }

        return lote;
    }

    // ------------------------------------------------------------------------------------------
    // El log de calidad de datos
    // ------------------------------------------------------------------------------------------

    /**
     * Escribe en el log de arranque lo que la ingesta leyo, descarto y produjo.
     *
     * <p><strong>Por que este log vale la pena.</strong> Es lo que separa el rigor de la suerte.
     * Cualquiera puede cargar un CSV y que "funcione"; lo que demuestra que los datos se analizaron
     * es poder responder con numeros medidos cuantas filas se perdieron y por que motivo cada una.
     * Ademas, estas mismas cifras se publican en
     * {@code GET /internal/v1/admin/calidad-datos}, de modo que la documentacion del proyecto puede
     * citar valores reproducibles en vivo en lugar de cifras escritas a mano.
     *
     * <p>Los valores esperados sobre el dataset de referencia, que sirven como prueba de humo al
     * arrancar: 50 cuentas, 686 movimientos, 1000 transacciones sin conciliar y 9 duplicados
     * exactos en {@code intereses.csv}.
     */
    private void registrarLogDeCalidad(ContadorDescartes contador,
                                       List<ReporteCalidad.ArchivoLeido> archivos,
                                       int cuentas, int movimientos, int transacciones, long milis) {

        log.info("==================== CALIDAD DE DATOS DE LA INGESTA ====================");
        log.info("  ---- lo que se leyo ----");
        for (ReporteCalidad.ArchivoLeido a : archivos) {
            log.info(String.format("  %-40s filas %4d | unicas %4d | duplicadas descartadas %d",
                    a.archivo(), a.filasLeidas(), a.filasUnicas(), a.duplicadasDescartadas()));
        }
        log.info("  ---- valores ignorados, por motivo ----");
        for (MotivoDescarte motivo : MotivoDescarte.values()) {
            log.info(String.format("  %-24s %5d", motivo.name(), contador.cuantos(motivo)));
        }
        log.info("  ---- lo que quedo ----");
        log.info(String.format("  %-24s %5d   (esperado 50)", "cuentas consolidadas", cuentas));
        log.info(String.format("  %-24s %5d   (esperado 686)", "movimientos cargados", movimientos));
        log.info(String.format("  %-24s %5d   (esperado 1000)", "sin conciliar", transacciones));
        log.info(String.format("  ingesta completada en %d ms", milis));
        log.info("=======================================================================");
    }

    // ------------------------------------------------------------------------------------------
    // Utilidades de lectura
    // ------------------------------------------------------------------------------------------

    /**
     * Lee un archivo del classpath y devuelve sus lineas de datos, <strong>sin la cabecera</strong>
     * y sin lineas en blanco.
     *
     * <p>Se lee del classpath y no del disco a proposito: asi los CSV viajan dentro del jar y el
     * servicio arranca en cualquier maquina sin que nadie tenga que copiar archivos ni ajustar una
     * ruta absoluta. El precio es que la semilla es de solo lectura, lo cual aqui es una ventaja:
     * cada arranque parte del mismo estado y la evidencia es reproducible.
     *
     * <p>El juego de caracteres se fija en UTF-8 de forma explicita. Sin eso, Java usa el del
     * sistema operativo, que en Windows suele ser Windows-1252, y los 52 {@code deposito} con tilde
     * llegarian con la letra rota. El sintoma aparece lejos de la causa: un titular mal escrito en
     * una respuesta JSON.
     */
    private List<String> leerLineasDeDatos(String rutaEnClasspath) {
        ClassPathResource recurso = new ClassPathResource(rutaEnClasspath);
        try (InputStream entrada = recurso.getInputStream();
             BufferedReader lector = new BufferedReader(
                     new InputStreamReader(entrada, StandardCharsets.UTF_8))) {

            List<String> lineas = new ArrayList<>();
            String linea;
            boolean primera = true;
            while ((linea = lector.readLine()) != null) {
                if (primera) {
                    primera = false;
                    continue;
                }
                if (!linea.isBlank()) {
                    lineas.add(linea);
                }
            }
            return lineas;

        } catch (IOException noSePudoLeer) {
            // Se convierte en no comprobada para que el fallo suba y la aplicacion NO arranque.
            // Un core sin datos no puede atender ninguna peticion util; arrancar igual solo
            // convertiria un error claro de arranque en cincuenta 404 inexplicables.
            throw new UncheckedIOException(
                    "No se pudo leer el archivo de semilla del classpath: " + rutaEnClasspath, noSePudoLeer);
        }
    }

    private Optional<Integer> enteroValido(String valorCrudo) {
        try {
            return Optional.of(Integer.parseInt(valorCrudo.trim()));
        } catch (RuntimeException noEsEntero) {
            return Optional.empty();
        }
    }

    /** Monto que sirve como movimiento: numerico y estrictamente mayor que cero. */
    private Optional<BigDecimal> montoPositivo(String valorCrudo) {
        return montoCrudo(valorCrudo).filter(m -> m.compareTo(BigDecimal.ZERO) > 0);
    }

    /** Monto tal cual venga, incluso negativo o cero: solo para el lote sin conciliar. */
    private Optional<BigDecimal> montoCrudo(String valorCrudo) {
        String texto = valorCrudo == null ? "" : valorCrudo.trim();
        if (texto.isEmpty()) {
            return Optional.empty();
        }
        try {
            return Optional.of(new BigDecimal(texto));
        } catch (NumberFormatException noEsNumero) {
            return Optional.empty();
        }
    }
}
