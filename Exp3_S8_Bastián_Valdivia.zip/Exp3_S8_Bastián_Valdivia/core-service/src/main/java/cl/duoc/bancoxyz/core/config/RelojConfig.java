package cl.duoc.bancoxyz.core.config;

import java.time.Clock;
import java.time.ZoneId;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Publica el reloj del sistema como un bean inyectable.
 *
 * <p>Rol en la arquitectura: es una pieza minuscula con una consecuencia grande. Un servicio que
 * llama a {@code LocalDate.now()} directamente <strong>no se puede probar</strong> en lo que
 * respecta al tiempo: no hay forma de escribir una prueba que verifique que el folio de un retiro
 * lleva la fecha correcta sin que esa prueba dependa del dia en que se ejecute, ni de comprobar el
 * comportamiento en un cambio de mes sin esperar al cambio de mes.
 *
 * <p>Inyectando un {@link Clock}, la produccion recibe este bean y una prueba recibe
 * {@code Clock.fixed(...)}, que devuelve siempre el mismo instante. El codigo de produccion no
 * cambia ni una linea. Es el ejemplo mas barato y mas claro de por que inyectar dependencias en vez
 * de crearlas dentro: lo que se inyecta se puede sustituir.
 *
 * <p>La zona horaria se fija en la de Santiago y no se deja la del sistema operativo. El motivo es
 * concreto: la fecha que lleva un movimiento y la que lleva el folio tienen que ser las del dia
 * bancario chileno, no las del huso donde por casualidad corra el servidor. Un retiro hecho a las
 * 22:00 en Chile no debe quedar registrado con la fecha del dia siguiente porque el proceso corra
 * en UTC.
 */
@Configuration
public class RelojConfig {

    private static final ZoneId ZONA_DEL_BANCO = ZoneId.of("America/Santiago");

    @Bean
    public Clock reloj() {
        return Clock.system(ZONA_DEL_BANCO);
    }
}
