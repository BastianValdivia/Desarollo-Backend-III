package cl.duoc.bancoxyz.core.eventos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Elige UN solo relay activo entre las replicas del core, con un <strong>lock consultivo de
 * PostgreSQL</strong> ({@code pg_try_advisory_lock}).
 *
 * <p><strong>Por que hace falta.</strong> Con dos replicas publicando el mismo outbox a la vez, los
 * eventos de una cuenta podrian salir intercalados o repetidos, y el orden por cuenta (la razon de que la
 * clave sea la cuenta) se perderia. Con un lider, solo una replica publica y la otra queda en espera.
 *
 * <p><strong>Como funciona.</strong> Un lock consultivo de sesion pertenece a una CONEXION de la base,
 * no a una transaccion: se conserva mientras esa conexion viva. El lider guarda una conexion dedicada con
 * el lock tomado; las demas replicas intentan tomarlo en cada ciclo y fallan mientras exista. Si el lider
 * muere (o se cae su conexion), PostgreSQL libera el lock solo y la siguiente replica en intentar pasa a
 * ser lider en menos de un ciclo. No hay reloj, ni latido, ni estado que limpiar: la base es el arbitro.
 *
 * <p>Esta clase solo decide el liderazgo; la correccion del reparto no depende de ella: el relay ademas
 * lee con {@code FOR UPDATE}, de modo que incluso en la ventana en que dos replicas se creyeran lideres
 * no se duplicaria ni se desordenaria nada (ver {@link RelayOutbox}).
 *
 * <p>No es segura para uso concurrente: la invoca un solo hilo, el del planificador del relay.
 */
public class LiderRelay implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(LiderRelay.class);

    /**
     * Identificador del lock (un numero de 64 bits que el servicio elige; PostgreSQL no lo asocia a
     * ninguna tabla). Es el ASCII de "RELAYOUT": distinto de cualquier otro lock del sistema.
     */
    static final long CLAVE_DEL_LOCK = 0x52454C41594F5554L;

    private final DataSource dataSource;
    private Connection conexionDelLider;

    public LiderRelay(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * Dice si esta replica es hoy el lider, tomando el liderazgo si esta libre.
     *
     * <p>Si ya era lider comprueba que su conexion siga viva: una conexion perdida significa que el lock
     * ya no es suyo, y seguir publicando como lider seria publicar sin serlo.
     */
    public boolean esLider() {
        if (conexionDelLider != null) {
            if (conexionViva(conexionDelLider)) {
                return true;
            }
            log.warn("Relay del outbox: la conexion del lider se perdio; esta replica deja de ser lider.");
            cerrarSilencioso(conexionDelLider);
            conexionDelLider = null;
        }
        return intentarTomarLiderazgo();
    }

    private boolean intentarTomarLiderazgo() {
        Connection conexion = null;
        try {
            conexion = dataSource.getConnection();
            try (PreparedStatement consulta = conexion.prepareStatement("SELECT pg_try_advisory_lock(?)")) {
                consulta.setLong(1, CLAVE_DEL_LOCK);
                try (ResultSet resultado = consulta.executeQuery()) {
                    resultado.next();
                    if (resultado.getBoolean(1)) {
                        conexionDelLider = conexion;
                        log.info("Relay del outbox: esta replica es ahora la LIDER (lock consultivo {}).",
                                CLAVE_DEL_LOCK);
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            log.warn("Relay del outbox: no se pudo consultar el lock de lider: {}", e.getMessage());
        }
        // No obtuvo el lock: la conexion vuelve al pool. Una conexion con el lock tomado NUNCA debe volver
        // al pool (el siguiente que la use heredaria el liderazgo sin saberlo); por eso solo se llega aqui
        // sin lock.
        cerrarSilencioso(conexion);
        return false;
    }

    private static boolean conexionViva(Connection conexion) {
        try {
            return conexion.isValid(2);
        } catch (SQLException e) {
            return false;
        }
    }

    private static void cerrarSilencioso(Connection conexion) {
        if (conexion == null) {
            return;
        }
        try {
            conexion.close();
        } catch (SQLException e) {
            log.debug("Error al cerrar la conexion del relay: {}", e.getMessage());
        }
    }

    /**
     * Cede el liderazgo. Se llama al apagar el servicio: cerrar la conexion libera el lock de inmediato y
     * la otra replica toma el relevo en su proximo ciclo, sin esperar a que PostgreSQL note la caida.
     *
     * <p>Una conexion de Hikari con un lock de sesion no se limpia al devolverla, asi que se libera
     * explicitamente antes de cerrar.
     */
    @Override
    public void close() {
        if (conexionDelLider == null) {
            return;
        }
        try (PreparedStatement consulta = conexionDelLider.prepareStatement("SELECT pg_advisory_unlock(?)")) {
            consulta.setLong(1, CLAVE_DEL_LOCK);
            consulta.execute();
        } catch (SQLException e) {
            log.debug("No se pudo liberar el lock de lider (se libera al cerrar la conexion): {}", e.getMessage());
        }
        cerrarSilencioso(conexionDelLider);
        conexionDelLider = null;
        log.info("Relay del outbox: esta replica cedio el liderazgo.");
    }
}
