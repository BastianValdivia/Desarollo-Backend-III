package cl.duoc.bancoxyz.core.dominio;

import java.util.List;
import java.util.Map;

/**
 * Fotografia de lo que ocurrio durante la ingesta de arranque: cuanto se leyo, cuanto se descarto
 * y por que, y cuanto quedo.
 *
 * <p>Rol en la arquitectura: es la salida auditable del proceso de carga. Se calcula una sola vez,
 * al arrancar, y despues solo se lee; por eso es inmutable y por eso sus numeros <strong>no
 * cambian</strong> cuando un retiro del cajero agrega un movimiento. Describe la ingesta, no el
 * estado actual del banco, y confundir las dos cosas haria que el valor 686 dejara de ser
 * reproducible entre dos arranques identicos.
 *
 * <p><strong>Por que este reporte existe.</strong> El dataset es ruido: hay hasta ocho titulares
 * distintos para un mismo numero de cuenta, cuatro formatos de fecha conviviendo y centinelas
 * como {@code -1} en las columnas de tipo. Cualquier proceso de carga va a tirar filas. La
 * diferencia entre cargar datos y analizarlos es poder responder con numeros medidos en vivo a la
 * pregunta "que se perdio y por que", en lugar de con una frase.
 *
 * @param generadoEn                  instante ISO-8601 en UTC en que termino la ingesta
 * @param archivos                    una entrada por archivo leido
 * @param descartesPorMotivo          cuantos valores se ignoraron por cada motivo; estan las cinco
 *                                    claves aunque alguna valga cero
 * @param cuentasConsolidadas         cuantas cuentas canonicas quedaron. Valor esperado: 50
 * @param movimientosCargados         cuantos movimientos validos se sembraron. Valor esperado: 686
 * @param transaccionesNoConciliadas  tamano del lote de {@code transacciones.csv}, que no se pudo
 *                                    vincular a ninguna cuenta. Valor esperado: 1000
 */
public record ReporteCalidad(
        String generadoEn,
        List<ArchivoLeido> archivos,
        Map<MotivoDescarte, Integer> descartesPorMotivo,
        int cuentasConsolidadas,
        int movimientosCargados,
        int transaccionesNoConciliadas) {

    /**
     * Lo medido sobre un archivo concreto del dataset.
     *
     * <p>{@code filasUnicas} y {@code duplicadasDescartadas} no son adorno: la deduplicacion de
     * filas exactas tiene que ocurrir <strong>antes</strong> de consolidar, porque un duplicado
     * exacto mete dos votos identicos y puede dar vuelta un empate. Publicar los dos numeros deja
     * a la vista que ese paso existio.
     *
     * @param archivo               nombre del archivo, tal como esta en el classpath
     * @param filasLeidas           filas de datos leidas, sin contar la cabecera
     * @param filasUnicas           filas que quedaron tras eliminar duplicados exactos
     * @param duplicadasDescartadas diferencia entre las dos anteriores
     */
    public record ArchivoLeido(String archivo, int filasLeidas, int filasUnicas, int duplicadasDescartadas) {
    }
}
