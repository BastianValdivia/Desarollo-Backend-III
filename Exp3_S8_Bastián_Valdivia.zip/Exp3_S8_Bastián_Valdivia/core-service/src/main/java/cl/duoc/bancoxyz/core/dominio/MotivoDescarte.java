package cl.duoc.bancoxyz.core.dominio;

/**
 * Las razones por las que la ingesta puede rechazar un valor del CSV de semilla.
 *
 * <p>Rol en la arquitectura: es el vocabulario del <strong>reporte de calidad de datos</strong>.
 * Cada vez que la ingesta ignora algo, lo hace nombrando cual de estos motivos aplica, y el
 * contador correspondiente sube. El resultado se publica en
 * {@code GET /internal/v1/admin/calidad-datos}.
 *
 * <p><strong>Por que un enumerado y no cadenas sueltas.</strong> El contrato congela las cinco
 * claves del objeto {@code descartesPorMotivo} y exige que las cinco aparezcan <em>aunque valgan
 * cero</em>. Con un enumerado, recorrer {@code values()} garantiza que ninguna falte, y una
 * clave mal escrita es un error de compilacion en vez de una clave que el consumidor nunca
 * encuentra.
 *
 * <p>Lo que distingue un proceso de carga riguroso de uno que tuvo suerte no es no descartar
 * nada: es <strong>saber exactamente cuanto descarto y por que</strong>, y poder demostrarlo con
 * un numero reproducible en vez de con una afirmacion escrita a mano en un documento.
 */
public enum MotivoDescarte {

    /** Saldo vacio, no numerico o no positivo en {@code intereses.csv}. */
    SALDO_INVALIDO,

    /** Tipo de cuenta o de movimiento que no corresponde a ningun valor real ({@code -1}, {@code unknown}). */
    TIPO_INVALIDO,

    /** Edad fuera del rango admisible, incluidos los centinelas 100 y 150 del archivo. */
    EDAD_FUERA_DE_RANGO,

    /** Monto de movimiento vacio, negativo o en cero: contradice al signo que ya lleva el tipo. */
    MONTO_NO_POSITIVO,

    /** Fecha que no encaja en ninguno de los cuatro formatos que conviven en el archivo. */
    FECHA_ILEGIBLE
}
