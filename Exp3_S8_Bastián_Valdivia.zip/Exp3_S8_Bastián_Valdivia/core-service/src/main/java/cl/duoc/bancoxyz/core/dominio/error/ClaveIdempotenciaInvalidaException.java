package cl.duoc.bancoxyz.core.dominio.error;

/**
 * La {@code Idempotency-Key} recibida no se puede usar como clave del registro de idempotencia.
 *
 * <p>Rol en la arquitectura: desde F3 el registro es una tabla cuya clave primaria incluye la
 * {@code Idempotency-Key} (junto con la cuenta), y una columna tiene un largo maximo ({@link #LARGO_MAXIMO}). Sin esta
 * validacion, una clave mas larga llegaria a la base, que la rechazaria con un error tecnico que el
 * cliente veria como un 500 inexplicable; con ella, el cliente recibe un 400 que le dice que su
 * cabecera es el problema. En el S5 no habia limite porque la clave era la llave de un mapa en
 * memoria.
 */
public class ClaveIdempotenciaInvalidaException extends ExcepcionNegocio {

    /** Largo maximo de la clave; coincide con {@code varchar(200)} de la tabla {@code idempotencia}. */
    public static final int LARGO_MAXIMO = 200;

    public ClaveIdempotenciaInvalidaException(int largoRecibido) {
        super("clave_idempotencia_invalida",
                "La cabecera Idempotency-Key tiene " + largoRecibido + " caracteres y el maximo es " + LARGO_MAXIMO);
    }
}
