package cl.duoc.bancoxyz.core.puerto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Optional;

import cl.duoc.bancoxyz.core.dominio.Cuenta;
import cl.duoc.bancoxyz.core.dominio.ResultadoRetiro;
import cl.duoc.bancoxyz.core.dominio.error.CuentaNoEncontradaException;
import cl.duoc.bancoxyz.core.dominio.error.SaldoInsuficienteException;

/**
 * <strong>Puerto</strong> de acceso a las cuentas: lo que el nucleo de la aplicacion necesita
 * saber hacer con ellas, expresado sin decir <em>donde</em> estan guardadas.
 *
 * <p><strong>Que es un puerto, para quien acaba de encontrarse con la palabra.</strong> Un puerto
 * es una interfaz que declara el dominio, no la infraestructura. La direccion de la dependencia
 * es lo que importa: {@code aplicacion} depende de esta interfaz, y
 * {@code adaptador.CuentaRepositoryEnMemoria} tambien depende de ella (implementandola). Nadie
 * depende del mapa concreto. Consecuencias practicas, no teoricas:
 *
 * <ul>
 *   <li>Cambiar el almacenamiento por una base de datos es escribir un
 *       {@code CuentaRepositoryJpa} y no tocar ni una linea de los servicios ni de los tres BFF.
 *       El punto de extension esta declarado, no es una promesa.</li>
 *   <li>Una prueba puede pasar una implementacion falsa y probar el servicio sin levantar nada.</li>
 *   <li>El dominio nunca importa una clase de infraestructura. Si aqui apareciera un tipo de
 *       Spring o de JDBC, el puerto habria dejado de serlo.</li>
 * </ul>
 *
 * <p><strong>Por que {@link #debitar} vive aqui y no en el servicio de aplicacion.</strong> Es la
 * decision de diseno central de este puerto. La tentacion es exponer {@code buscarPorId} y
 * {@code guardar} y que el servicio haga "leo, valido, escribo". Esos tres pasos separados dejan
 * una ventana entre la lectura y la escritura por la que otro hilo se cuela, y el saldo puede
 * quedar negativo. Solo el adaptador conoce el mecanismo de exclusion de su almacen (aqui, el
 * bloqueo por clave de {@code ConcurrentHashMap}; en una base de datos, una transaccion). Por eso
 * el puerto declara la <em>operacion de negocio completa</em> y deja que cada implementacion la
 * haga atomica con sus propios medios.
 */
public interface CuentaRepository {

    /**
     * Busca una cuenta por su identificador.
     *
     * <p>Devuelve {@link Optional} y no {@code null}: la firma obliga al llamador a decidir
     * explicitamente que hacer cuando no existe, en vez de dejarlo descubrirlo con un
     * {@code NullPointerException} tres lineas mas abajo.
     */
    Optional<Cuenta> buscarPorId(int cuentaId);

    /** Todas las cuentas canonicas. Se usa para el conteo del reporte de calidad. */
    Collection<Cuenta> listarTodas();

    /**
     * Inserta o reemplaza una cuenta.
     *
     * <p>Existe para que la ingesta siembre el estado inicial al arrancar. <strong>No</strong> es
     * el camino para modificar un saldo: para eso esta {@link #debitar}, que es la unica operacion
     * de mutacion con garantia de atomicidad.
     */
    void guardar(Cuenta cuenta);

    /**
     * Descuenta {@code monto} del saldo y registra el movimiento correspondiente,
     * <strong>de forma atomica</strong>.
     *
     * <p>Atomica significa aqui que las dos cosas ocurren juntas o no ocurre ninguna, y ademas que
     * dos llamadas simultaneas sobre la <em>misma</em> cuenta se ejecutan una despues de la otra y
     * nunca entrelazadas. La segunda ve el saldo que dejo la primera, de modo que dos retiros
     * concurrentes no pueden dejar la cuenta en negativo.
     *
     * @param cuentaId     cuenta a debitar
     * @param monto        importe positivo a retirar
     * @param folio        identificador del comprobante, generado por el servicio de aplicacion
     * @param fecha        fecha con la que queda registrado el movimiento
     * @param idMovimiento identificador tecnico del apunte nuevo
     * @return el comprobante con saldo anterior, monto y saldo posterior
     * @throws CuentaNoEncontradaException si la cuenta no existe
     * @throws SaldoInsuficienteException  si el saldo no alcanza. En ese caso <strong>no</strong>
     *                                     se modifica nada
     */
    ResultadoRetiro debitar(int cuentaId, BigDecimal monto, String folio, LocalDate fecha, long idMovimiento);
}
