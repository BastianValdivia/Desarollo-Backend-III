package cl.duoc.bancoxyz.core.eventos;

/**
 * Kafka no confirmo la recepcion de ningun evento del lote: esta caido, inalcanzable o demasiado lento.
 *
 * <p>Es la UNICA excepcion que Resilience4j cuenta como fallo del circuito {@code kafka}. No es un error
 * del retiro (que ya esta confirmado en la base) sino de la entrega, y la entrega se reintenta sola:
 * el evento sigue en el outbox.
 */
public class KafkaNoDisponibleException extends RuntimeException {

    public KafkaNoDisponibleException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
