-- =====================================================================
-- V4: la bandeja de salida (outbox) pasa a su diseno definitivo (F7).
-- =====================================================================
-- V1 dejo creada la tabla "outbox" como preparacion ("hoy nadie la escribe"). Con F7 se escribe y se lee
-- de verdad, y su forma de entonces (contenido jsonb, sin topico ni identificador del evento) se queda
-- corta. V1 no se edita (una migracion aplicada es inmutable): este archivo ajusta la tabla. Como nadie
-- la habia escrito, no hay datos que migrar.
--
-- PROBLEMA QUE RESUELVE EL PATRON: la DOBLE ESCRITURA. Un retiro tiene que descontar el saldo (PostgreSQL)
-- y avisar al resto del sistema (Kafka). Son dos sistemas y ninguna transaccion abarca a ambos:
--   * si se descuenta y despues falla la publicacion, el retiro existe y nadie se entera;
--   * si se publica y despues falla el descuento, se avisa de un retiro que no ocurrio.
-- SOLUCION: el evento se escribe en ESTA tabla, en la MISMA transaccion que el descuento. O quedan ambos
-- o no queda ninguno. Un proceso aparte (el relay, RelayOutbox) lee lo pendiente y lo publica en Kafka;
-- si Kafka no esta, el evento espera aqui y se entrega al volver.
--
-- GARANTIA RESULTANTE: entrega AL MENOS UNA VEZ. Si el relay publica y cae antes de marcar la fila, el
-- evento se publica de nuevo. Por eso los consumidores son idempotentes por event_id.
--
-- ORDEN: id es la posicion global del evento y el relay publica por id ascendente. Para una misma cuenta
-- ese orden coincide con el de confirmacion, porque el INSERT se hace DESPUES del UPDATE de la cuenta, y
-- ese UPDATE bloquea la fila hasta el commit: un segundo retiro de la cuenta no llega al INSERT antes de
-- que el primero haya confirmado.

-- Texto y no jsonb: se publica EXACTAMENTE lo que se escribio (jsonb reordena las claves y normaliza el
-- texto, y el sobre que ve Kafka debe ser el que el productor armo).
ALTER TABLE outbox DROP COLUMN contenido;
ALTER TABLE outbox ADD COLUMN payload text NOT NULL;

-- Identificador del evento (el eventId del sobre). UNIQUE: el mismo evento no puede quedar dos veces.
ALTER TABLE outbox ADD COLUMN event_id uuid NOT NULL;
ALTER TABLE outbox ADD CONSTRAINT outbox_event_id_unico UNIQUE (event_id);

-- Topico de destino. "tipo" (ya existente) queda para el tipo del evento (RETIRO_EJECUTADO).
ALTER TABLE outbox ADD COLUMN topico varchar(120) NOT NULL;
