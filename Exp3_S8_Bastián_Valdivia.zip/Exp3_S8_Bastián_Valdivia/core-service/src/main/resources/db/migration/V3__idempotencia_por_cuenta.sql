-- =====================================================================
-- V3: la clave de idempotencia deja de ser global y pasa a ser POR CUENTA.
-- =====================================================================
-- Defecto que corrige: en V1 la clave primaria de "idempotencia" era solo la Idempotency-Key. Dos
-- clientes distintos que usaran la misma clave (la elige el cajero, no el banco) chocaban: el segundo
-- recibia el comprobante del primero (folio, saldos, importe de OTRA cuenta) sin que se descontara
-- nada de la suya. Era una filtracion de datos entre clientes y un retiro legitimo confirmado sin
-- ejecutarse.
--
-- Solucion: la clave pasa a ser (cuenta_id, clave). Una Idempotency-Key solo identifica un reintento
-- DENTRO de la cuenta que la uso; otra cuenta con la misma cadena es una operacion nueva e
-- independiente. Dentro de la misma cuenta, reutilizar la clave con otro importe lo rechaza el codigo
-- (RegistroIdempotenciaJdbc) comparando contra monto_retirado.
--
-- V1 no se edita: una migracion aplicada es inmutable (Flyway compara su suma de verificacion). Los
-- comentarios de V1 que dicen "la clave primaria es la Idempotency-Key" describen el estado de V1;
-- el vigente es el de este archivo.
--
-- cuenta_id NO es clave foranea de cuenta(id) a proposito: la reserva de la clave se inserta antes
-- de descontar, y un retiro sobre una cuenta inexistente debe terminar en 404 (cuenta no
-- encontrada) y no en un error de integridad. Esa transaccion se deshace entera, asi que nunca queda
-- una fila huerfana.

-- Las filas previas no dicen de que cuenta eran y no se pueden deducir. El registro es una ventana
-- de reintentos (un corte de red dura segundos), no un historial: los retiros ya confirmados viven
-- en "movimiento" y no dependen de esta tabla. Descartarlas solo significa que un reintento de una
-- operacion anterior a esta migracion ya no se reconoce, lo cual no ocurre en la practica.
DELETE FROM idempotencia;

ALTER TABLE idempotencia DROP CONSTRAINT idempotencia_pkey;
ALTER TABLE idempotencia ADD COLUMN cuenta_id integer NOT NULL;
ALTER TABLE idempotencia ADD CONSTRAINT idempotencia_pkey PRIMARY KEY (cuenta_id, clave);
