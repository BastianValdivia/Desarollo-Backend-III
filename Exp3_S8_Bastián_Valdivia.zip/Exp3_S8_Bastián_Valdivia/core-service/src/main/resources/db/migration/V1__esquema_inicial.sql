-- =====================================================================
-- V1: esquema del core-service (base "core").
-- =====================================================================
-- Flyway ejecuta este archivo UNA vez por base de datos y deja constancia en la tabla
-- flyway_schema_history. Una migracion ya aplicada no se edita nunca: si algo cambia, se agrega
-- V3, V4... (Flyway compara la suma de verificacion y se niega a seguir si un archivo aplicado
-- cambio). La carga del dataset NO esta aqui sino en la migracion Java V2, que necesita leer los
-- CSV con las reglas de la ingesta del S5.
--
-- Principio de este esquema: la base es la ultima linea de defensa de las reglas de negocio.
-- El codigo ya valida que el saldo alcance, pero las restricciones CHECK y UNIQUE hacen que un
-- error del codigo, o un acceso directo a la base, no pueda dejar el banco en un estado
-- imposible (saldo negativo, dos retiros con la misma clave).

-- ---------------------------------------------------------------------
-- Cuentas
-- ---------------------------------------------------------------------
CREATE TABLE cuenta (
    id           integer       PRIMARY KEY,
    titular      varchar(120)  NOT NULL,
    -- numeric y no double: el dinero no admite error de redondeo binario.
    saldo        numeric(15,2) NOT NULL,
    edad_titular integer       NOT NULL,
    tipo         varchar(20)   NOT NULL,
    -- NUNCA negativo: aunque un UPDATE olvidara su condicion, la base lo rechaza.
    CONSTRAINT cuenta_saldo_no_negativo CHECK (saldo >= 0),
    CONSTRAINT cuenta_tipo_valido CHECK (tipo IN ('AHORRO', 'HIPOTECA', 'PRESTAMO'))
);

-- ---------------------------------------------------------------------
-- Movimientos de cada cuenta (los 686 del CSV y los retiros posteriores)
-- ---------------------------------------------------------------------
-- El identificador sale de una secuencia, que es compartida por TODAS las replicas del core:
-- con un contador en memoria cada replica numeraria por su cuenta y los ids chocarian.
CREATE SEQUENCE movimiento_id_seq AS bigint;

CREATE TABLE movimiento (
    id          bigint        PRIMARY KEY DEFAULT nextval('movimiento_id_seq'),
    cuenta_id   integer       NOT NULL REFERENCES cuenta (id),
    fecha       date          NOT NULL,
    tipo        varchar(20)   NOT NULL,
    monto       numeric(15,2) NOT NULL,
    -- Admite NULL: el dataset trae descripciones vacias y el S5 las conserva como ausentes.
    descripcion text,
    origen      varchar(20)   NOT NULL,
    -- El signo vive en el tipo, no en el numero: un monto es siempre positivo.
    CONSTRAINT movimiento_monto_positivo CHECK (monto > 0),
    CONSTRAINT movimiento_tipo_valido CHECK (tipo IN ('DEPOSITO', 'RETIRO', 'COMPRA', 'PAGO')),
    CONSTRAINT movimiento_origen_valido CHECK (origen IN ('CSV_SEMILLA', 'RETIRO_ATM'))
);
ALTER SEQUENCE movimiento_id_seq OWNED BY movimiento.id;

-- El historial se pide siempre de una cuenta, del mas reciente al mas antiguo.
CREATE INDEX movimiento_por_cuenta ON movimiento (cuenta_id, fecha DESC, id DESC);

-- ---------------------------------------------------------------------
-- Folios de retiro
-- ---------------------------------------------------------------------
-- El correlativo del comprobante (RET-20260911-000123). Una secuencia y no un contador en
-- memoria: dos replicas no pueden emitir el mismo folio, y un reinicio no vuelve a empezar de 1.
-- Una secuencia no es transaccional: un retiro rechazado consume un numero y deja un hueco, igual
-- que en el S5. Los folios son unicos y crecientes, no necesariamente consecutivos.
CREATE SEQUENCE folio_retiro_seq AS bigint;

-- ---------------------------------------------------------------------
-- Transacciones sin conciliar (transacciones.csv): el lote que no se pudo vincular a ninguna cuenta
-- ---------------------------------------------------------------------
-- "orden" conserva el orden del archivo (la API las pagina en ese orden) y es la clave: el "id" del
-- CSV puede repetirse, y el S5 las conserva todas tal como venian.
CREATE TABLE transaccion_no_conciliada (
    orden     integer       PRIMARY KEY,
    id        bigint        NOT NULL,
    fecha     date,
    monto     numeric,
    tipo_crudo text
);

-- ---------------------------------------------------------------------
-- Reporte de calidad de datos de la carga (una sola fila: la de la carga inicial)
-- ---------------------------------------------------------------------
CREATE TABLE reporte_calidad (
    id                            smallint    PRIMARY KEY,
    generado_en                   varchar(40) NOT NULL,
    cuentas_consolidadas          integer     NOT NULL,
    movimientos_cargados          integer     NOT NULL,
    transacciones_no_conciliadas  integer     NOT NULL,
    CONSTRAINT reporte_calidad_unico CHECK (id = 1)
);

CREATE TABLE reporte_calidad_archivo (
    orden                  integer      PRIMARY KEY,
    archivo                varchar(255) NOT NULL,
    filas_leidas           integer      NOT NULL,
    filas_unicas           integer      NOT NULL,
    duplicadas_descartadas integer      NOT NULL
);

CREATE TABLE reporte_calidad_descarte (
    motivo   varchar(40) PRIMARY KEY,
    cantidad integer     NOT NULL
);

-- ---------------------------------------------------------------------
-- Registro de idempotencia de los retiros
-- ---------------------------------------------------------------------
-- La clave primaria ES la garantia: dos retiros simultaneos con la misma Idempotency-Key intentan
-- insertar la misma fila, la base deja pasar a uno y hace esperar al otro hasta que el primero
-- confirme o deshaga. Es lo que vuelve idempotente el retiro sin ningun bloqueo escrito a mano.
-- Las columnas del comprobante son NULL solo mientras la transaccion que reservo la clave esta
-- abierta; al confirmar quedan siempre completas.
CREATE TABLE idempotencia (
    clave           varchar(200)  PRIMARY KEY,
    folio           varchar(40),
    saldo_anterior  numeric(15,2),
    monto_retirado  numeric(15,2),
    saldo_posterior numeric(15,2),
    creado          timestamptz   NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- Outbox: eventos pendientes de publicar (F7)
-- ---------------------------------------------------------------------
-- Guardar el retiro y publicar el evento en Kafka son dos operaciones que pueden fallar por
-- separado. El patron outbox las junta: el evento se escribe en ESTA tabla dentro de la misma
-- transaccion del retiro, y un proceso aparte (el relay, F7) lo publica y marca "publicado".
-- La tabla se crea ahora para que F7 no tenga que tocar el esquema de los retiros; hoy nadie la
-- escribe.
CREATE TABLE outbox (
    id        bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tipo      varchar(100) NOT NULL,
    -- Clave de particion del evento (la cuenta): conserva el orden por cuenta en Kafka.
    clave     varchar(100) NOT NULL,
    contenido jsonb        NOT NULL,
    creado    timestamptz  NOT NULL DEFAULT now(),
    publicado timestamptz
);

-- El relay solo mira lo pendiente, y lo lee en orden de llegada.
CREATE INDEX outbox_pendientes ON outbox (id) WHERE publicado IS NULL;
