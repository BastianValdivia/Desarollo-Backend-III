# Índice de evidencias

Este índice dice qué demuestra cada archivo de `evidencias/` y a qué criterio de la pauta de evaluación responde. Los archivos los
genera **un solo comando**, `scripts/verificar.sh`, ejecutado desde un clon limpio; no se escriben a mano.

## Cómo se generó y cómo reproducirlo

```bash
git clone <repositorio> && cd <repositorio>   # o descomprime el .zip y entra a la carpeta
scripts/verificar.sh                  # camino del evaluador: docker compose up -d --build --wait y TODAS las comprobaciones
scripts/verificar.sh --rapido         # sin escenarios de caos ni medición de escalado
```

Duración medida en una máquina de 4 CPU con las imágenes ya construidas: unos 33 minutos la verificación completa y unos 11 con `--rapido`
(más unos 4,5 minutos de `--con-pruebas`; la primera construcción de las imágenes depende de la red). Requisitos: Docker con Compose v2.20 o
superior, `bash`, `curl` y `python3`. Cada archivo de `evidencias/salidas/` empieza con una
cabecera (qué prueba, criterio de la pauta, **comando exacto**, fecha UTC y entorno), sigue con la **salida literal** del comando
(sin la línea `Picked up JAVA_TOOL_OPTIONS` que algunas JVM imprimen) y termina con el **código de salida** y la duración. Cada
comprobación es una línea `PASS` o `FAIL` con el dato real que la sostiene, y cada archivo cierra con su línea `RESULTADO`. El resumen
final de `verificar.sh` imprime PASS o FAIL por criterio y termina con código 0 solo si todo pasó.

**Qué cambia entre una ejecución y otra, y qué no.** No cambian el resultado PASS de cada comprobación, los códigos HTTP, las cifras
del dominio (50 cuentas, 686 movimientos), la forma de las tablas ni los conteos de comprobaciones de casi todos los archivos. Dos
conteos pueden variar en una o dos comprobaciones porque el guion verifica lo que ocurrió y eso depende del reparto: cuántos retiros
simultáneos llegan al core (los otros los rechaza el mamparo del cajero con 503, ver `21-compose-postgres-replicas-f3.txt`) y si los
registros del primer arranque siguen disponibles (`21-...` lo anota como INFO y no como PASS cuando los contenedores ya se recrearon).
Sí cambian, porque son de la máquina y del momento: fechas y horas, identificadores de contenedor y de instancia, folios de retiro,
los tiempos de arranque y de los escenarios de resiliencia, y la memoria en reposo (en `planificacion/bitacora/F8-F9.md` se midieron
variaciones de 10 a 20 % entre corridas iguales).

## Criterio 1: OAuth 2.0 (20 puntos)

Descriptor del 100 %: flujo funcional que asegura la protección de datos y servicios.

| Archivo | Qué demuestra |
|---|---|
| `evidencias/salidas/30-oauth2-servidor-recursos-f4.txt` | El auth-server publica su descubrimiento OIDC y su JWKS por HTTPS verificado con la CA interna. Los BFF obtienen un token de servicio por `client_credentials` con los scopes mínimos de cada uno, el core exige un scope por endpoint (matriz 401 sin token, 403 sin el scope, 200 con él), rechaza tokens falsificados, vencidos o de otra audiencia, y cada BFF **reutiliza** su token en lugar de pedir uno por petición. Ningún secreto de cliente está en git, en el compose, en el entorno ni en las imágenes. |
| `evidencias/salidas/31-oauth2-login-usuarios-f5.txt` | El login de usuarios es del auth-server: `authorization_code` con PKCE para web y móvil, y el grant de extensión tarjeta y PIN para el cajero. Vigencias de 1800, 3600 y 180 s, audiencia propia de cada canal, `device_id` atado al token móvil. Lo que se rechaza: un código canjeado con otro `code_verifier`, una solicitud sin PKCE, una `redirect_uri` no registrada, el móvil sin `device_id`, el grant `password`, un scope que el cliente no tiene, un terminal desconocido o con secreto errado. Tres PIN errados bloquean la tarjeta 15 minutos (ni el PIN correcto la libera) y reiniciar el auth-server la libera. |
| `evidencias/salidas/32-oauth2-matriz-3x3.txt` | La barrera de audiencia: el token de cada canal solo sirve en su propio BFF (diagonal 200, las seis celdas cruzadas 401). |
| `evidencias/salidas/40-no-regresion-s5.txt` | Los comportamientos de seguridad del S5 siguen vigentes (sin token 401, vigencias, titularidad 403, permisos de cliente y ejecutivo, token atado al dispositivo, terminales autorizados). Ver "No regresión del S5" más abajo. |
| `evidencias/salidas/72-ms-auth-server.txt` | Evidencia de ejecución del auth-server: arranque, salud y un token real emitido con sus claims. |
| `evidencias/capturas/04-login-auth-server.png` | La página de login del auth-server, capturada tras verificar la cadena de certificados con la CA interna (la captura muestra el formulario; que se sirve por HTTPS con ese certificado lo demuestran `30-oauth2-servidor-recursos-f4.txt` y `40-no-regresion-s5.txt`). |

## Criterio 2: imágenes Docker (20 puntos)

Descriptor del 100 %: imágenes funcionales para todos los microservicios, con portabilidad y despliegue eficiente.

| Archivo | Qué demuestra |
|---|---|
| `evidencias/salidas/10-imagenes-f2.txt` | Una imagen `bancoxyz/<servicio>:1.0.0` por cada uno de los 9 microservicios, construida en dos etapas (sin Maven, JDK ni git en la imagen final), con cuatro capas de jar, `HEALTHCHECK` y memoria relativa al contenedor; usuario 10001; ningún secreto dentro de las imágenes; volúmenes de secretos con dueño 10001 y permisos mínimos; `secretos-init` idempotente; HTTPS con la CA interna. |
| `evidencias/salidas/11-imagenes-f8.txt` | Calidad de producción: los 9 procesos corren como UID 10001 (la excepción, `secretos-init`, es una tarea única de unos segundos, sin red y con solo tres capacidades); sin secretos en el historial de capas, en las variables de entorno, en el sistema de archivos ni dentro de los `.jar`; `docker compose config` sin advertencias; ninguna imagen `latest` y versión exacta en cada `FROM`; límites de memoria, CPU y procesos con todo `healthy`; las 6 imágenes base publican `linux/amd64` y `linux/arm64`. |
| `evidencias/salidas/12-tabla-despliegue.txt` | La tabla medida sobre un arranque real (`down` y `up -d` sin construir): tamaño de imagen (disco y contenido), capas, tiempo de arranque (el de la aplicación y el hasta `healthy`), memoria en reposo (mediana de tres lecturas) y límite de cada servicio. |
| `evidencias/salidas/13-limites-tras-la-carga.txt` | Tras toda la verificación (incluidos los escenarios de caos) ningún contenedor fue terminado por falta de memoria y la memoria de cada uno frente a su límite. |

## Criterio 3: `docker-compose.yaml` (20 puntos)

Descriptor del 100 %: configurado correctamente, orquesta todos los componentes necesarios de manera funcional.

| Archivo | Qué demuestra |
|---|---|
| `evidencias/salidas/01-arranque.txt` | `docker compose up -d --wait` levanta los 16 contenedores del sistema completo con un solo comando y todos quedan `healthy` (o terminan bien, las dos tareas únicas), con el `docker compose ps -a` final. |
| `evidencias/salidas/20-compose-config-eureka-f1.txt` | Config Server entrega la configuración de cada servicio y perfil desde `config-repo/`; Eureka registra los servicios; los BFF llaman al core por su nombre lógico; Actuator vive en un puerto de gestión aparte y sin endpoints sensibles; un cambio en `config-repo/` y `POST /actuator/refresh` se aplica sin reiniciar. |
| `evidencias/salidas/21-compose-postgres-replicas-f3.txt` | PostgreSQL con una base y un usuario por servicio (cada usuario no puede leer las otras), la carga que da los números del S5, dos réplicas del core que reparten la carga, retiros simultáneos sin doble descuento, la misma clave de idempotencia entre réplicas, y el estado que sobrevive al reinicio. |
| `evidencias/salidas/22-compose-reinicio-automatico.txt` | La política `restart: unless-stopped`: qué forma de terminar el proceso la activa (`kill 1` desde dentro) y cuáles no (`docker kill`, `docker stop`, que Docker toma por una detención manual), y que el servicio vuelve a registrarse en Eureka. |
| `evidencias/salidas/61-kafka-escalado.txt` | Escalado horizontal: el mismo lote con 1, 3 y 4 consumidores (ver criterio 5). |
| `evidencias/salidas/10-imagenes-f2.txt` y `evidencias/salidas/11-imagenes-f8.txt` | También respaldan este criterio: redes `borde` e `interna` (el core, PostgreSQL y Kafka sin puertos publicados), puertos publicados solo donde corresponde, límites de recursos y `compose config` sin advertencias. |
| `evidencias/capturas/01-eureka-dashboard.png` | El dashboard de Eureka con los siete servicios clientes registrados y sin el aviso de emergencia (con las dos réplicas del core y de notificaciones). |

## Criterio 4: Resilience4j (20 puntos)

Descriptor del 100 %: correctamente en los microservicios, garantizando resiliencia ante fallos.

| Archivo | Qué demuestra |
|---|---|
| `evidencias/salidas/50-resiliencia-core-caido.txt` | Las dos réplicas del core caen: el circuito de los tres BFF pasa por CLOSED, OPEN, HALF_OPEN y de nuevo CLOSED (eventos de Actuator). Web y móvil sirven el último dato conocido marcado como desactualizado; el cajero **falla cerrado** con 503 y sin inventar un saldo. |
| `evidencias/salidas/51-resiliencia-core-lento.txt` | Con latencia inyectada en el core, el circuito abre **por llamadas lentas**, sin que haya errores. |
| `evidencias/salidas/52-resiliencia-rafaga-mamparo.txt` | Una ráfaga simultánea contra el mamparo (Bulkhead): el exceso se rechaza al instante, se cuenta y se responde con el respaldo. |
| `evidencias/salidas/53-resiliencia-replica-muere.txt` | Una réplica del core muere durante 100 peticiones: salen 100 de 100 con 200 (reintento y reparto entre réplicas). |
| `evidencias/salidas/54-resiliencia-auth-server-caido.txt` | El auth-server cae: los BFF siguen sirviendo con el token de servicio vigente (A), intentan renovarlo en sus últimos 30 s, fallan y siguen con el vigente (B); con el token vencido y el auth-server caído la respuesta es controlada: el cajero 503 sin saldo y la web el último dato conocido marcado como desactualizado, nunca un 500 (C); al volver el auth-server todo se normaliza y el circuito pasa por CLOSED, OPEN, HALF_OPEN y CLOSED (D). |
| `evidencias/salidas/60-kafka-eventos-f7.txt` | Resilience4j fuera de los BFF: con Kafka detenido los retiros siguen y el outbox acumula; la pasarela simulada de notificaciones con CircuitBreaker, Retry y Bulkhead; el panel del ejecutivo sale **sin** la sección de auditoría si ese servicio cae. |

## Criterio 5: Kafka (15 puntos)

Descriptor del 100 %: completamente funcional, comunicación eficiente y escalable entre microservicios.

| Archivo | Qué demuestra |
|---|---|
| `evidencias/salidas/60-kafka-eventos-f7.txt` | Un retiro produce un evento (outbox en la misma transacción, relay con líder único) que llega a **dos** grupos de consumidores, notificaciones y auditoría; un reintento con la misma clave no produce un segundo evento; las particiones se reparten entre las réplicas y el lag queda en cero; un mensaje inválido va a la DLT sin bloquear; los reintentos no bloqueantes; la API de auditoría exige OAuth2; los eventos de seguridad del auth-server. |
| `evidencias/salidas/61-kafka-escalado.txt` | La tabla de escalado: el mismo lote de 900 eventos con 1, 3 y 4 consumidores. Con 3 el tiempo baja casi a un tercio y el cuarto consumidor queda ocioso (0 particiones): un tópico de 3 particiones no se reparte entre más de 3. |
| `evidencias/salidas/77-ms-notificaciones-service.txt` y `evidencias/salidas/78-ms-auditoria-service.txt` | Los dos consumidores en acción: las filas que guardó cada uno a partir del evento del retiro y el reparto de particiones del grupo. |
| `evidencias/capturas/02-kafka-ui-topicos.png` | Kafka UI: los tópicos `bancoxyz.retiros.v1` y `bancoxyz.seguridad.v1` con 3 particiones, y los tópicos de reintento y DLT de cada consumidor. |
| `evidencias/capturas/03-kafka-ui-grupos.png` | Kafka UI: los grupos de consumidores `notificaciones` y `auditoria`. |

## Criterio 6: entrega (5 puntos)

Descriptor del 100 %: los tres aspectos, código fuente, documentación y evidencia de ejecución.

| Archivo | Qué demuestra |
|---|---|
| `evidencias/salidas/79-entrega.txt` | **Código:** los 9 microservicios con módulo Maven y `Dockerfile`, compose y `.dockerignore` con su nombre exacto, fin de línea LF en los scripts, ningún documento del curso versionado. **Documentación:** README definitivo (objetivo, arquitectura, estructura, ejecución, seguridad, resiliencia, trazabilidad y limitaciones, sin restos del S5, con cada cifra de sus tablas igual a la evidencia: comprobaciones por archivo y pruebas por módulo, y enlaces que existen), propuesta técnica, guía de estudio, contrato de eventos y una bitácora por fase. **Evidencia:** este índice existe y es exacto en las dos direcciones (todo lo que cita existe y todo lo que hay está citado), hay evidencia de arranque, salud y resultado de cada microservicio, están las capturas, y ningún valor secreto real del sistema aparece en las evidencias. |
| `evidencias/salidas/00-pruebas-unitarias.txt` | Las pruebas unitarias y de integración de los 11 módulos (`./mvnw -B verify`, con PostgreSQL y Kafka reales por Testcontainers): el total de cada módulo, el resumen del reactor, el veredicto `BUILD SUCCESS` y la suma, con las fallas, los errores y las pruebas omitidas en cero (ninguna se salta ni se deshabilita). Solo se genera con `scripts/verificar.sh --con-pruebas`. |
| `evidencias/salidas/80-capturas.txt` | La salida de `scripts/capturar-pantallas.js` que tomó las cuatro capturas (se regenera solo si el equipo tiene Node con Playwright; si no, se conservan las capturas versionadas). |

### Evidencia de ejecución de cada microservicio

Como piden las instrucciones de la actividad ("la ejecución de cada microservicio y los resultados generados"). Cada archivo trae tres
bloques: **1. ARRANQUE** (estado, instante de inicio, reinicios, usuario y la línea `Started ... in N seconds` de su propio registro),
**2. SALUD** (`HEALTHCHECK` de Docker, `/actuator/health` y el registro en Eureka) y **3. RESULTADO** (una operación real del
servicio con su respuesta).

| Microservicio | Archivo | Resultado que muestra |
|---|---|---|
| `config-server` | `evidencias/salidas/70-ms-config-server.txt` | La configuración que entrega para `bff-web` con los perfiles `docker,demo,bff`: las fuentes de `config-repo/` y el nombre lógico del core. |
| `eureka-server` | `evidencias/salidas/71-ms-eureka-server.txt` | Los siete servicios clientes registrados con todas sus instancias en `UP`, y el dashboard. |
| `auth-server` | `evidencias/salidas/72-ms-auth-server.txt` | Descubrimiento OIDC, JWKS y un token de servicio real con sus claims; un secreto de cliente errado da 401. |
| `core-service` | `evidencias/salidas/73-ms-core-service.txt` | La cuenta 116 leída de PostgreSQL con un token de servicio, las 50 cuentas y 686 movimientos de la carga, las migraciones de Flyway, el 401 y el 403 de OAuth2 y el reparto entre sus dos réplicas. |
| `bff-web` | `evidencias/salidas/74-ms-bff-web.txt` | Login web con PKCE, consulta de la cuenta, el 403 por titularidad, el panel del ejecutivo y los circuitos de Resilience4j. |
| `bff-mobile` | `evidencias/salidas/75-ms-bff-mobile.txt` | Login móvil con `device_id`, resumen de la cuenta, el 401 desde otro dispositivo y el circuito del core. |
| `bff-atm` | `evidencias/salidas/76-ms-bff-atm.txt` | Login con tarjeta y PIN, saldo, un retiro con su folio y el reintento idempotente que devuelve el mismo folio. |
| `notificaciones-service` | `evidencias/salidas/77-ms-notificaciones-service.txt` | La notificación guardada a partir del evento del retiro, las particiones del grupo y el circuito de la pasarela. |
| `auditoria-service` | `evidencias/salidas/78-ms-auditoria-service.txt` | Los eventos auditados por tipo, la API de lectura protegida (200 con el scope `auditoria:leer`, 401 sin token) y el lag en cero. |

## No regresión del S5 (lista 3.1 del plan)

`evidencias/salidas/40-no-regresion-s5.txt` ejecuta `scripts/verificar-no-regresion.sh`, que comprueba cada fila de la lista:
sin token los tres canales responden 401; vigencias de 1800, 3600 y 180 s; matriz 3x3; titularidad; permisos distintos dentro de un
canal; token móvil atado al dispositivo; terminales autorizados del cajero; HTTPS en los tres BFF con su identidad; optimización por
canal (tamaños, gzip, caché y ETag); retiro atómico e idempotente; carga de 50 cuentas y 686 movimientos con los descartes
informados; y los casos borde (la cuenta 130 sin movimientos y una cuenta inexistente).

## Qué no se verificó aquí

La ejecución sobre **Windows y macOS con Docker Desktop** no se pudo probar en el entorno donde se generaron estas evidencias (Linux
con Docker Engine). Sí se comprobó lo que se puede comprobar sin ellos: los scripts con el `bash` 3.2.57 que trae macOS, los
fines de línea LF forzados por `.gitattributes` con `core.autocrlf=true`, y las rutas relativas (ver la bitácora de F8-F9, sección 9a).
