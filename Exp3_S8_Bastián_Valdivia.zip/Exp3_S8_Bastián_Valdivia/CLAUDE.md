# CLAUDE.md: convenciones del proyecto

Sumativa individual Exp3 S8 de Desarrollo Backend III (PBY2203, Duoc UC): "Desarrollando
microservicios y resiliencia en la nube con Spring Cloud", sobre el Banco XYZ. Parte del proyecto S5
(patrón BFF), que queda como línea base en el commit `dd2e301` (etiqueta `s5-base`), y lo lleva a
Spring Cloud, OAuth2, Resilience4j, Kafka, PostgreSQL y Docker. El plan maestro es `planificacion/PLAN_NOTA_MAXIMA.md` (decisiones D1 a D12,
lista de no regresión en 3.1 y seis reglas en la sección 2). Cada fase deja su bitácora en
`planificacion/bitacora/<FASE>.md`. Lee el plan y las bitácoras anteriores antes de tocar nada.

## Reglas de trabajo

- Idioma: español en documentación, commits, logs y comentarios. Documentos Markdown claros y sin
  rayas largas (em dash).
- Java: estilo del S5. Javadoc explicativo en las clases nuevas y comentarios que dicen por qué, no qué.
- Calidad de producción. Nunca se deshabilitan, saltan ni borran pruebas para pasar: se arregla la
  causa. `./mvnw -B verify` debe quedar verde.
- Evidencia honesta: no se afirma nada que no se ejecutó. Toda afirmación de éxito sale de un
  comando real con su salida real.
- Ningún secreto en git ni dentro de las imágenes: claves, keystores, truststores, contraseñas
  generadas, secretos de clientes. Las credenciales de los usuarios de demostración (`cliente116`,
  tarjetas y PIN del S5) sí se publican, porque el evaluador las necesita.
- Los documentos oficiales del curso (`docs/enunciado/`) nunca se versionan: llevan aviso de
  derechos reservados de Duoc UC.
- Portabilidad: el evaluador usa Windows o macOS con Docker Desktop. Nada que dependa del entorno
  de desarrollo dentro del repo, rutas relativas, y los `.sh` con fin de línea LF (lo fuerza
  `.gitattributes`, porque se montan en contenedores Linux).
- El puerto del proxy de un entorno de nube puede cambiar: nunca se escribe en archivos del repo.
- Sin regresiones del S5: la lista 3.1 del plan debe seguir pasando en cada fase.
- Sin CI/CD: no se usa GitHub Actions, no se crea `.github/workflows/` y no se relanzan corridas
  antiguas. Lo decidió el usuario el 3 de octubre: no lo pidió y, con el repositorio privado, cada
  corrida gastaba minutos de su cuota. La verificación es local, con `scripts/verificar.sh`.

## Git

- Rama de trabajo `claude/exp3-s8`. `main` solo recibe el resultado final (F10): no se modifica ni se
  empuja a ella antes.
- Commits pequeños y descriptivos con prefijo `feat:`, `fix:`, `docs:`, `test:`, `chore:` o
  `refactor:`. Nunca `--force`, nunca se reescribe historia.
- Antes de cada commit, `git status` sin archivos que no deban versionarse.

## Estructura de módulos

Proyecto Maven multimódulo, Java 21, Spring Boot 3.3.13, BOM de Spring Cloud 2023.0.6 importado en
el POM padre. Versiones y propiedades (`spring-cloud.version`, `resilience4j.version`) viven solo
en el `pom.xml` raíz.

| Módulo | Qué es | Puerto de servicio | Puerto de gestión (local) |
|---|---|---|---|
| `plataforma-comun` | Biblioteca compartida (lectura de claims, confianza en el JWKS del auth-server, cliente del core balanceado por Eureka con el token de servicio OAuth2 de cada BFF, errores, seguridad del puerto de gestión). Desde F5 no emite tokens; su test-jar trae `EmisorDePrueba`, que usan las pruebas de los BFF. Desde F6 trae `CoreClientResiliente` (Retry, CircuitBreaker y Bulkhead de Resilience4j alrededor de cada llamada al core), el respaldo de último dato conocido de web y móvil y la resiliencia del token de servicio | no aplica | no aplica |
| `eventos-contrato` | Contrato de los eventos de Kafka (F7): el sobre `SobreEvento` (`eventId`, `tipo`, `version`, `ocurridoEn`, `origen`, `datos`), `CodecEventos` (escribe y valida), `TiposEvento`, `Topicos` y los datos de cada evento. Solo Jackson: sin Spring ni Kafka. Lo usan productores y consumidores. Especificación en `docs/eventos.md` | no aplica | no aplica |
| `config-server` | Spring Cloud Config Server (perfil `native`, sirve `config-repo/`) | 8888 (HTTP) | 8085 |
| `eureka-server` | Registro y descubrimiento (Eureka) | 8761 (HTTP) | 8086 |
| `auth-server` | Servidor de autorización (Spring Authorization Server): único emisor de tokens. `client_credentials` para los BFF (F4); desde F5 también el login de usuarios: `authorization_code` con PKCE para web y móvil, y el grant de extensión tarjeta y PIN para el cajero (política de PIN incluida) | 9000 (HTTPS con la CA interna en contenedores, HTTP en local) | 8087 en local, 8081 en contenedores |
| `core-service` | Backend de dominio: cuentas, movimientos, retiros. Estado en PostgreSQL (F3); dos réplicas en el compose. Servidor de recursos OAuth2 con un scope por endpoint (F4). Desde F7 escribe un evento por retiro en la tabla `outbox` (misma transacción) y un relay con líder único (lock consultivo de PostgreSQL) lo publica en Kafka | 8080 (HTTP, solo loopback en local) | 8081 |
| `notificaciones-service` | Consumidor de eventos de Kafka (F7): grupo `notificaciones`, dos réplicas en el compose; idempotente por `eventId` en su base `notificaciones`; pasarela de envío simulada (latencia y tasa de fallo configurables) protegida con CircuitBreaker, Retry y Bulkhead; reintentos no bloqueantes (`@RetryableTopic`) y DLT. Sin API de negocio | 8100 (sin API) | 8088 en local, 8081 en contenedores |
| `auditoria-service` | Consumidor de eventos de Kafka (F7): grupo `auditoria`, guarda cada evento en su base `auditoria` (idempotente) y expone una API de lectura protegida por OAuth2 (scope `auditoria:leer`, audiencia `auditoria-service`) que consume el panel del ejecutivo de `bff-web` | 8110 (HTTP, solo red interna) | 8089 en local, 8081 en contenedores |
| `bff-web` | BFF del canal web (solo valida tokens del auth-server: JWKS, emisor y audiencia `bff-web`). Desde F7 trae el panel del ejecutivo (`/v1/admin/panel`), que consume `auditoria-service` con Resilience4j | 8443 (HTTPS, `/api/web`) | 8082 |
| `bff-mobile` | BFF del canal móvil (valida; además `X-Device-Id` contra el claim `device_id` y baja de dispositivo) | 8444 (HTTPS, `/api/mobile`) | 8083 |
| `bff-atm` | BFF del cajero (valida; además el claim `terminal` debe estar registrado) | 8445 (HTTPS, `/api/atm`) | 8084 |

PostgreSQL 16 (servicio `postgres` del compose, no es un módulo Maven) guarda las bases `core`,
`auditoria` y `notificaciones`, cada una con su usuario; solo vive en la red interna y sin puertos.
Kafka 3.9.1 en modo KRaft (servicio `kafka`, un nodo, tampoco es un módulo Maven; la tarea `kafka-init` declara los
tópicos con `docker/kafka/crear-topicos.sh`) vive también solo en la red interna y sin puertos.

Cada módulo con servicio lleva su propio `Dockerfile` (`config-server` y `eureka-server` lo recibieron en F2,
`notificaciones-service` y `auditoria-service` en F7) y está en el `<modules>` del POM padre.

La configuración de `core-service` y los tres BFF ya no vive en su `application.yml` (que solo
lleva el nombre, la dirección del config-server y dos valores de desarrollo con aspecto de
credencial): está en `config-repo/` (`application.yml` común, `application-<perfil>.yml` y
`<servicio>.yml` / `<servicio>-<perfil>.yml`) y la entrega el config-server. Perfiles: `local` y
`demo` por defecto (JVM en el equipo), `docker,demo` en contenedores, `test` en las pruebas. Los tres BFF activan
además el perfil `bff` (`docker,demo,bff` en el compose, `local,demo,bff` por defecto), que entrega
`config-repo/application-bff.yml` (el Resilience4j común de F6): desde F7 el core y otros servicios también usan
Resilience4j y no pueden recibir ese bloque, porque nombra excepciones de `plataforma-comun`. Las
pruebas no usan config-server ni Eureka: su perfil `test` los desactiva y lee los mismos archivos de
`config-repo/` por ruta relativa (`../config-repo/`), así que deben ejecutarse desde la carpeta del
módulo (Maven lo hace).

## Cómo compilar, probar y levantar

Para compilar y probar hacen falta JDK 21 (Maven viene como wrapper, `./mvnw`) y **Docker en marcha**:
desde F3 las pruebas del core levantan un PostgreSQL 16 real con Testcontainers (sin Docker fallan, no
se saltan). Para
levantar el sistema completo y ejecutar los scripts de verificación y medición en modo Docker basta
Docker con Compose v2 (más `bash`, `python3` y `curl`): las herramientas Java de prueba
(`FirmarTokenDePrueba.java`, `GzipCuestaBytes.java`) corren dentro de un contenedor con la imagen
`bancoxyz/secretos-init` (ver `firmar_token` y `gzip_cuesta_bytes` en `scripts/lib-entorno.sh`). Con
`ENTORNO=local` los scripts usan el `java` del equipo.

### Camino principal: contenedores (desde F2)

```bash
docker compose up -d --build --wait  # desde un clon limpio; --wait vuelve con todo healthy (~1 min)
docker compose ps -a               # 16 contenedores: servicios healthy y las dos tareas únicas Exited (0); sin -a solo salen los 14 en marcha
curl --cacert certs/ca.crt https://localhost:8443/api/web/v1/cuentas/116   # 401: llega, falta token
docker compose down                # detiene (sin -v conserva los secretos; con -v arranque en frío)
```

Sin `--wait`, `up -d` vuelve con los BFF aún arrancando (nada depende de ellos) y un `curl` inmediato
se rechaza durante unos 15 a 20 s. Si el Compose no admite `--wait`, `scripts/esperar-sano.sh` espera
a todos. Los scripts de verificación lo llaman solos.

`secretos-init` genera, al primer arranque, una CA interna, los certificados TLS de los BFF y el
resto de los secretos en volúmenes con nombre (uno por servicio), y exporta solo `certs/ca.crt` al
host. Nada de eso va a git ni a las imágenes. Los scripts de verificación corren contra los
contenedores por defecto (`ENTORNO=docker`, con `--cacert certs/ca.crt`, sin `-k`):

```bash
scripts/verificar-f2.sh              # contenedores: usuario, red, imágenes, secretos, TLS (PASS/FAIL)
scripts/verificar-no-regresion.sh    # lista 3.1 del plan contra el sistema en marcha
scripts/verificar-f1.sh              # Config Server, Eureka, Actuator y refresh
scripts/verificar-f3.sh              # PostgreSQL, carga, retiros entre réplicas, reinicio, usuarios de base
scripts/verificar-f4.sh              # OAuth2 entre servicios: OIDC, tokens, matriz 401/403/200 del core, reutilización del token
scripts/login-web.sh | login-movil.sh | login-cajero.sh   # login de usuarios contra el auth-server (F5); con --token imprimen solo el token
scripts/verificar-matriz-3x3.sh      # matriz 3x3: diagonal 200 y seis celdas cruzadas 401 (audiencia)
scripts/restablecer-demo.sh          # devuelve los saldos de la carga (deshace solo los retiros del cajero)
scripts/verificar-f5.sh              # F5: login con PKCE y tarjeta/PIN, rechazos, bloqueo de PIN y su liberacion (PASS/FAIL, ~1 min)
scripts/verificar-f8.sh              # F8: UID 10001, sin secretos en capas, compose sin advertencias, sin latest, limites, multiarquitectura
scripts/medir-despliegue.sh [--frio] # F8: tabla de tamano de imagen, arranque y memoria en reposo de cada servicio (medir-arranque.sh lo invoca)
scripts/evidencia-microservicio.sh <servicio>   # F9: arranque, salud y resultado de UNO de los 9 microservicios (PASS/FAIL)
scripts/verificar-entrega.sh         # F9/F10: criterio 6 (codigo, README definitivo con sus cifras contra la evidencia, evidencias/INDICE.md, secretos fuera de las evidencias)
scripts/empaquetar-entrega.sh Nombres_Apellidos   # F10: genera Exp3_S8_Nombres_Apellidos.zip (una carpeta, sin secretos, certs, target ni docs/enunciado) y lo vuelve a abrir para comprobarlo
scripts/respaldar-postgres.sh [restaurar <carpeta>]   # F10: copia de seguridad (pg_dump) y restauracion de las tres bases, en respaldos/ (manual)
scripts/verificar.sh [--rapido] [--sin-construir]   # F9: TODO en un comando, PASS/FAIL por criterio de la pauta y evidencias/salidas/NN-*.txt (~33 min; --rapido ~11 min; con las imagenes ya construidas, en 4 CPU)
node scripts/capturar-pantallas.js   # F9: capturas de Eureka, Kafka UI y login del auth-server (Playwright, opcional)
scripts/verificar-f7.sh              # F7: Kafka, outbox, consumidores, DLT, API de auditoría y panel (PASS/FAIL, ~7 min)
scripts/medir-escalado.sh [lote] [rep]  # F7: el mismo lote con 1, 3 y 4 consumidores (tabla de escalado, ~8 min)
scripts/caos/core-caido.sh           # F6: ambas réplicas del core caen; circuitos CLOSED, OPEN, HALF_OPEN y CLOSED (~4 min)
scripts/caos/core-lento.sh [--sin-movil]  # F6: latencia inyectada; el circuito abre por lentitud (~7 min; ~2 min con --sin-movil)
scripts/caos/rafaga-bulkhead.sh      # F6: ráfaga simultánea contra el mamparo (~3 min)
scripts/caos/replica-muere.sh        # F6: una réplica muere durante 100 peticiones; deben salir 100 de 100 (~2 min)
scripts/caos/reinicio-automatico.sh [--matriz]   # F6: qué forma de terminar el proceso activa restart: unless-stopped
scripts/caos/auth-server-caido.sh    # F6: el auth-server cae; los BFF siguen con el token de servicio vigente (~7 min)
```

### JVM locales (flujo del S5 y F1)

```bash
./scripts/generar-secretos.sh   # una vez, ANTES de compilar: los secretos locales viajan dentro del .jar
./mvnw -B verify                # compila, ejecuta las 610 pruebas (necesita Docker) y empaqueta
scripts/levantar-local.sh       # PostgreSQL desechable, config-server, eureka, auth-server, core y los 3 BFF; exporta BFF_*_KEYSTORE_PASSWORD y genera los secretos de cliente OAuth2 (run/secretos-locales.env)
ENTORNO=local scripts/verificar-no-regresion.sh
scripts/detener-local.sh
```

El total de pruebas es la suma de las líneas `Tests run:` del resumen de cada módulo (hoy 16 en
`eventos-contrato`, 45 en `plataforma-comun`, 26 en `config-server`, 2 en `eureka-server`, 117 en `auth-server`, 161 en
`core-service`, 18 en `notificaciones-service`, 30 en `auditoria-service`, 71 en `bff-web`, 61 en `bff-mobile` y 63 en
`bff-atm`). Desde F7 las pruebas del core también necesitan
descargar `apache/kafka:3.9.1` (Testcontainers). Con `java -jar` a mano, los BFF necesitan la
variable `BFF_WEB_KEYSTORE_PASSWORD` (y sus dos hermanas): el jar ya no lleva contraseña de
keystore; `levantar-local.sh` las exporta con el valor con que `generar-secretos.sh` crea los
keystores.

## Detalles que ahorran tiempo

- Entrega (F10): `README.md` (definitivo, con cada cifra comprobada contra `evidencias/` por `scripts/verificar-readme.py`, que corre dentro
  de `verificar-entrega.sh`), `docs/propuesta-tecnica.md`, `docs/guia-de-estudio.md` y `docs/eventos.md`. El zip se arma con
  `scripts/empaquetar-entrega.sh Nombres_Apellidos` (nunca a mano: el script excluye secretos, `certs/`, `target/` y `docs/enunciado/` y se
  vuelve a comprobar). Si cambian pruebas o cifras de la verificacion, se actualiza el README (el criterio 6 lo exige). `main` solo recibe el
  resultado final.
- Despliegue (F8): las imagenes base llevan version EXACTA (`maven:3.9.16-eclipse-temurin-21`,
  `eclipse-temurin:21.0.12.1_1-jre-alpine-3.24` y `-jdk-alpine-3.24`, `postgres:16.15-alpine3.24`, `apache/kafka:3.9.1`,
  `kafbat/kafka-ui:v1.5.0`): al actualizar una, se cambia en todos los Dockerfile, en el compose y en las pruebas
  (`PostgresDePrueba`). Cada contenedor de larga vida tiene `mem_limit`, `cpus` y `pids_limit` (anclas `x-recursos-*` del
  compose: 512 MiB para config y eureka, 768 MiB para el resto de los servicios Spring, 1 GiB para Kafka); la JVM toma el 75 % del
  limite como heap. `secretos-init` sigue como root (debe hacer chown) pero con `cap_drop: ALL` salvo CHOWN, DAC_OVERRIDE y FOWNER,
  sin red y de solo lectura. CDS se midio y se descarto (bitacora F8-F9, seccion 8a). Valores y mediciones: `planificacion/bitacora/F8-F9.md`.
- Docker Hub responde 429 de vez en cuando: `verificar-f8.sh` reintenta la consulta de plataformas con espera creciente.
- Verificacion integral (F9): `scripts/verificar.sh` escribe `evidencias/salidas/NN-*.txt` (comando, fecha, entorno, salida literal y
  codigo de salida) e `evidencias/INDICE.md` dice que criterio de la pauta prueba cada una. Las cifras de tiempo y memoria varian
  entre corridas; los conteos de comprobaciones y las salidas PASS no.
- Mensajería (F7): el contrato y las garantías están en `docs/eventos.md`. El retiro escribe su evento en `outbox` (V4) en la
  misma transacción; `RelayOutbox` (líder único con `LiderRelay`, lock consultivo de sesión) lo publica. Con Kafka detenido
  (`docker compose stop kafka`) los retiros siguen y `outbox.pendientes` (`/actuator/metrics/outbox.pendientes` del core)
  crece; al volver Kafka se vacía. Los tópicos de reintento y la DLT de cada consumidor llevan el nombre del grupo
  (`bancoxyz.retiros.v1-notificaciones-dlt`, `...-auditoria-retry-2000`); cada mensaje que llega a la DLT queda también en la
  tabla `carta_muerta` de la base del servicio. Para mirar: `kafka-ui` en `http://localhost:8090`, o
  `docker compose exec kafka /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --describe --group notificaciones`.
  Las bases de los consumidores se consultan con `docker compose exec postgres psql -U postgres -d notificaciones|auditoria`.
  La pasarela simulada se cambia en caliente editando `notificaciones.pasarela.*` en `config-repo/notificaciones-service.yml` y
  `POST /actuator/refresh` en cada réplica (`verificar-f7.sh` lo hace y lo restaura). Un PIN errado de una tarjeta de prueba
  (150) emite `PIN_INCORRECTO`; se limpia con su PIN correcto (9999). La imagen `secretos-init` lleva su script dentro: al
  agregar un servicio con secretos hay que reconstruirla.
- Resiliencia (F6): `CoreClientResiliente` (`@Primary`, en `plataforma-comun`) es el `CoreClient` que usan los canales y
  decora a `RestCoreClient` con `Retry( CircuitBreaker( Bulkhead( llamada ) ) )`; la configuración está en `config-repo/`
  (`application.yml` lo común, `bff-*.yml` el mamparo y el respaldo). Falla = `CoreNoDisponibleException` (timeouts,
  conexión rechazada, 5xx, sin instancias); un 4xx de negocio no abre el circuito. Se reintenta todo GET y el retiro solo
  con su `Idempotency-Key`. Web y móvil sirven el último dato conocido (menos de 10 minutos) con las cabeceras
  `X-Datos-Desactualizados`, `X-Datos-Antiguedad-Segundos`, `Warning` y `Cache-Control: no-store`; el cajero falla
  cerrado (`resiliencia.respaldo.habilitado: false`: el bean no existe). El Actuator de cada BFF (puerto de gestión)
  trae `circuitbreakers`, `circuitbreakerevents`, `retries`, `bulkheads` y `/actuator/health/resiliencia`; el grupo de
  health vive en `bff-*.yml` porque Spring Boot no arranca un servicio cuyo grupo incluye un contribuyente que no
  existe (core y auth-server no tienen Resilience4j). Valores finales y su razón: `planificacion/bitacora/F6.md`.
- No habilites los reintentos del balanceador (`spring.cloud.loadbalancer.retry.enabled: false`): con `spring-retry` en
  el classpath reintenta por su cuenta cada GET y duplica las llamadas al core y las esperas (medido en F6).
- Caos (F6): `caos.latencia-ms` de `config-repo/core-service.yml` (0 por defecto, `@RefreshScope`) frena cada
  petición `/internal/**` del core; los scripts de `scripts/caos/` lo cambian, llaman a `POST /actuator/refresh` en cada
  réplica y lo dejan en 0 (con `trap`). Si un script de caos se interrumpe, revisa `git diff config-repo/core-service.yml`
  y `docker compose ps` (puede quedar el core detenido o una réplica muerta: `docker compose start core-service`).
- Reinicio automático (F6): `restart: unless-stopped` solo actúa si el proceso termina por sí mismo. `docker kill`,
  `docker kill -s TERM` y `docker stop` NO lo activan (Docker los toma por una detención manual) y
  `docker exec <c> kill -9 1` no hace nada (el núcleo no entrega SIGKILL al PID 1 desde dentro). Lo que sí lo activa:
  `docker exec <c> kill 1` (SIGTERM desde dentro). Para simular la muerte de una réplica sin reinicio se usa `docker kill`.
- Los circuitos solo se reinician al cambiar de estado: un escenario que deja fallos o llamadas lentas en la ventana de
  un circuito que sigue CLOSED los arrastra al siguiente (`limpiar_ventana` en `scripts/caos/lib-caos.sh`).
- Mamparo del cajero (F6): `bff-atm` admite 5 llamadas simultáneas al core (20 en web y móvil). Diez retiros simultáneos
  dan 5 éxitos y 5 rechazos que pueden ser 409 (saldo) o 503 (mamparo lleno, no llegaron al core); por eso
  `verificar-no-regresion.sh` y `verificar-f3.sh` aceptan ambos códigos sin relajar el invariante (el saldo baja solo
  por los éxitos). `verificar-f1.sh` y `verificar-f4.sh` también se adaptaron a los endpoints y reinicios de F6.

- Límite de intentos (F5): 3 fallos seguidos bloquean 15 minutos tanto la clave de un usuario web o móvil
  (`ProveedorDeClaveConBloqueo`, contador `RegistroIntentosClave`) como el PIN de una tarjeta
  (`RegistroIntentosPin`); la lógica común está en `RegistroIntentos`. El estado vive en memoria: para liberar
  un usuario o una tarjeta bloqueados en una demostración basta `docker compose restart auth-server`. Los
  scripts no deben fallar a propósito la clave de `cliente116`, `cliente105` ni `ejecutivo1`.
- Login de usuarios (F5): `cliente116` / `Cliente.2026` (una sola clave por usuario, antes `Web.2026` y
  `Mov.2026`), `cliente105` / `Cliente.2026`, `ejecutivo1` / `Exec.2026`; cajero con tarjeta y PIN del S5 y
  el secreto del terminal `atm-scl-001`, que genera `secretos-init` y se lee del volumen del auth-server
  (`secreto_terminal` en `scripts/lib-entorno.sh`). Los BFF no tienen clave de firma. Los casos que el
  auth-server no emite (cuenta 130, token vencido, terminal inexistente) se forjan con `firmar_token`, que
  firma con la clave del auth-server dentro de un contenedor efímero sin red. `expires_in` marca 1799, 3599
  y 179 s (un segundo menos por el redondeo); el `exp - iat` del JWT es 1800, 3600 y 180.
- Los secretos de contenedores viven solo en volúmenes (`secretos-init`); los servicios los leen de
  `/run/secrets` (rutas en `config-repo/<bff>-docker.yml`; contraseñas y secreto del cliente OAuth2 por `configtree`).
  Las imágenes no llevan ninguno: `.dockerignore` deja fuera `secrets/`, `*.p12`, `*.pem` y `*.crt`.
- El core no publica puertos y el puerto de gestión (8081) tampoco: los scripts los consultan con
  `docker compose exec` (ver `scripts/lib-entorno.sh`). Con dos réplicas, `exec core-service` elige la
  primera; para sumar las dos (métricas) o recorrerlas se usa `gestion_core_todas` o `docker compose ps -q`.
- El estado del core vive en PostgreSQL y sobrevive a los reinicios (`docker compose restart` no
  devuelve los saldos iniciales). Para repetir una demostración: `scripts/restablecer-demo.sh`. Para un
  arranque en frío de verdad: `docker compose down -v` (borra también los datos y los secretos).
- Las contraseñas de las bases las genera `secretos-init` en el volumen `secretos-postgres` (dueño 70,
  el usuario `postgres`); el core recibe la suya como propiedad `spring.datasource.password` por
  `configtree`. Se ven solo con `docker compose exec postgres cat /run/secrets/<base>.password`. El script
  `docker/postgres/init/01-bases-y-usuarios.sh` crea bases y usuarios y corre solo con el volumen de datos vacío.
- Cada petición al core deja una línea `... atendida por la instancia <id>` (`RegistroPeticionesFilter`);
  el `<id>` es el del contenedor y coincide con el `instanceId` de Eureka. Es la evidencia del reparto.
- Flyway: `V1__esquema_inicial.sql`, `V2__CargaInicialDataset` (Java, reutiliza la ingesta del S5), `V3__idempotencia_por_cuenta.sql` y `V4__outbox.sql` (F7). Una
  migración aplicada no se edita: los cambios van en una migración nueva (`V5...`). Las pruebas usan Testcontainers 1.21.4
  (la 1.19.8 de Boot no habla con Docker Engine 29).
- Antes de capturar evidencia, `unset JAVA_TOOL_OPTIONS` (regla del S5): sin eso cada `java` o
  `keytool` imprime una línea con datos del entorno que acaba pegada en la evidencia.
- Actuator vive en un puerto de gestión aparte (HTTP, sin `context-path`, `/actuator/...`), igual en
  los cuatro servicios y nunca publicado: en local solo escucha en 127.0.0.1 y en Docker no se
  mapea al host. Expone `health`, `info`, `metrics` y `refresh` (los tres BFF suman `circuitbreakers`,
  `circuitbreakerevents`, `retries`, `retryevents`, `bulkheads` y `bulkheadevents` de Resilience4j); `env`,
  `configprops` y `heapdump` no existen (404). En el puerto de servicio de los BFF `/actuator/health` responde 404 y el resto de `/actuator/...` 401 sin token;
  en el del core (desde F4, con default-deny) responde 401 sin token y 403 con un token que no lo declara.
- Demostración de refresh: editar `info.demostracion.mensaje` en `config-repo/application.yml`,
  `curl -X POST http://127.0.0.1:8081/actuator/refresh` y `curl http://127.0.0.1:8081/actuator/info`.
- Una instancia muerta sale de Eureka en unos 30 s con el perfil `demo` (arriendos cortos, ver el
  costo en `eureka-server/src/main/resources/application.yml`); el balanceador deja de enviarle
  tráfico en cuanto el cliente descarga la lista nueva (cada 5 s).
- Los `medir-*.sh` leen las métricas en los puertos de gestión. El `capturar-evidencias.sh` del S5 se eliminó en F10: lo
  reemplaza `scripts/verificar.sh` (y escribiría sobre `evidencias/`, que hoy es la salida de esa verificación).
- El refresh no reconstruye el cliente de Eureka (`eureka.client.refresh.enable: false`): tras un
  `POST /actuator/refresh` la API responde de inmediato. Consecuencia: una propiedad `eureka.*`
  cambiada en `config-repo` exige reiniciar el servicio.
- Precedencia de `config-repo`, de menor a mayor: `application.yml`, `<servicio>.yml`, y por cada
  perfil activo (el último gana) `application-<perfil>.yml` y encima `<servicio>-<perfil>.yml`.
- `run/`, `target/`, `certs/` y las carpetas `secrets/` de los módulos están en `.gitignore`.
- El S5 original (código, plan, guías y evidencia) se consulta con `git show dd2e301:<ruta>`. Se usa el
  hash porque viaja en cualquier clon; la etiqueta `s5-base` apunta al mismo commit, pero no se pudo
  subir al remoto (ver `planificacion/bitacora/F0.md`).
