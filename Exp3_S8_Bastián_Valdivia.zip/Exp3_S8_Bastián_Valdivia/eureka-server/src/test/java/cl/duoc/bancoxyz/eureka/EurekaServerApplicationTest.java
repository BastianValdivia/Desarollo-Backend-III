package cl.duoc.bancoxyz.eureka;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

/**
 * Comprueba que el registro arranca y que cumple su contrato basico: aceptar el registro de un
 * cliente y listarlo en {@code /eureka/apps}, que es lo que consulta la verificacion de la fase.
 *
 * <p>Corre con el perfil {@code demo} porque es el que se usa al demostrar el sistema; asi la
 * prueba tambien valida que el bloque de arriendos cortos del {@code application.yml} es valido.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles({"demo"})
class EurekaServerApplicationTest {

    @Autowired
    private TestRestTemplate http;

    @Test
    @DisplayName("El registro arranca y /eureka/apps responde 200 con la lista de aplicaciones")
    void registroVacioAlArrancar() {
        HttpHeaders cabeceras = new HttpHeaders();
        cabeceras.setAccept(List.of(MediaType.APPLICATION_JSON));
        ResponseEntity<String> respuesta = http.exchange(
                "/eureka/apps", HttpMethod.GET, new HttpEntity<>(cabeceras), String.class);

        assertThat(respuesta.getStatusCode().value()).isEqualTo(200);
        assertThat(respuesta.getBody()).contains("\"applications\"");
    }

    @Test
    @DisplayName("Un servicio que se registra aparece en /eureka/apps con su nombre logico")
    void unServicioRegistradoApareceEnLaLista() {
        String instancia = """
                {"instance": {
                  "instanceId": "prueba:core-service:8080",
                  "hostName": "localhost",
                  "app": "CORE-SERVICE",
                  "ipAddr": "127.0.0.1",
                  "vipAddress": "core-service",
                  "status": "UP",
                  "port": {"$": 8080, "@enabled": "true"},
                  "dataCenterInfo": {
                    "@class": "com.netflix.appinfo.InstanceInfo$DefaultDataCenterInfo",
                    "name": "MyOwn"}
                }}
                """;
        HttpHeaders cabeceras = new HttpHeaders();
        cabeceras.setContentType(MediaType.APPLICATION_JSON);
        cabeceras.setAccept(List.of(MediaType.APPLICATION_JSON));

        ResponseEntity<String> alta = http.exchange(
                "/eureka/apps/CORE-SERVICE", HttpMethod.POST, new HttpEntity<>(instancia, cabeceras), String.class);
        assertThat(alta.getStatusCode().is2xxSuccessful()).isTrue();

        ResponseEntity<String> lista = http.exchange(
                "/eureka/apps", HttpMethod.GET, new HttpEntity<>(cabeceras), String.class);
        assertThat(lista.getBody()).contains("CORE-SERVICE").contains("prueba:core-service:8080");
    }
}
