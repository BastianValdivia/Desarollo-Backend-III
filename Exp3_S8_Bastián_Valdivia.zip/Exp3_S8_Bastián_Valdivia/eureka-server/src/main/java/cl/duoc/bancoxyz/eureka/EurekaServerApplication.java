package cl.duoc.bancoxyz.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Registro de servicios del Banco XYZ (Netflix Eureka).
 *
 * <p>Cada microservicio se registra aqui con su nombre logico y renueva su "arriendo" con un
 * latido periodico. Los clientes descargan la lista y la usan para resolver nombres como
 * {@code core-service} a una direccion concreta. Si un servicio deja de latir, Eureka lo
 * expulsa de la lista al vencer su arriendo.
 *
 * <p>Este servidor no se registra en si mismo ni descarga el registro: es una instancia unica,
 * sin pares con los que replicarse. La disponibilidad se refuerza con la politica de reinicio
 * de Docker, no con un cluster de Eureka (se declara como limitacion).
 */
@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurekaServerApplication.class, args);
    }
}
