package cl.duoc.bancoxyz.eventos;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * El contrato del sobre: lo que se escribe se lee igual, y todo lo que lo incumple se rechaza con
 * {@link EventoInvalidoException} (que los consumidores mandan a la DLT sin reintentar).
 */
class CodecEventosTest {

    private static final Instant INSTANTE = Instant.parse("2026-09-11T15:00:00.123Z");

    private static SobreEvento retiro() {
        return SobreEvento.nuevo(TiposEvento.RETIRO_EJECUTADO, 1, INSTANTE, "core-service",
                new DatosRetiro(116, "RET-20260911-000001", new BigDecimal("3000.00"),
                        new BigDecimal("12000.00"), new BigDecimal("9000.00"), 700L, "CLP"));
    }

    @Test
    @DisplayName("Un evento escrito se lee igual, con los seis campos del contrato")
    void idaYVuelta() {
        SobreEvento original = retiro();

        String json = CodecEventos.escribir(original);
        SobreEvento leido = CodecEventos.leer(json);

        assertThat(leido.eventId()).isEqualTo(original.eventId());
        assertThat(leido.tipo()).isEqualTo("RETIRO_EJECUTADO");
        assertThat(leido.version()).isEqualTo(1);
        assertThat(leido.ocurridoEn()).isEqualTo(INSTANTE);
        assertThat(leido.origen()).isEqualTo("core-service");
        DatosRetiro datos = leido.datosComo(DatosRetiro.class);
        assertThat(datos.cuentaId()).isEqualTo(116);
        assertThat(datos.folio()).isEqualTo("RET-20260911-000001");
        assertThat(datos.monto()).isEqualByComparingTo("3000");
        assertThat(datos.saldoPosterior()).isEqualByComparingTo("9000");
        assertThat(datos.movimientoId()).isEqualTo(700L);
    }

    @Test
    @DisplayName("El JSON usa exactamente los nombres del contrato y escribe el instante en ISO-8601 UTC")
    void nombresDelContrato() {
        String json = CodecEventos.escribir(retiro());

        assertThat(json).contains("\"eventId\":\"", "\"tipo\":\"RETIRO_EJECUTADO\"", "\"version\":1",
                "\"ocurridoEn\":\"2026-09-11T15:00:00.123Z\"", "\"origen\":\"core-service\"", "\"datos\":{");
        // Los importes son numeros JSON exactos, no texto ni notacion cientifica.
        assertThat(json).contains("\"monto\":3000.00");
    }

    @Test
    @DisplayName("Los campos de seguridad que no aplican se omiten, y el sujeto de una tarjeta va enmascarado")
    void seguridadOmiteLoQueNoAplica() {
        SobreEvento pin = SobreEvento.nuevo(TiposEvento.PIN_INCORRECTO, 1, INSTANTE, "auth-server",
                new DatosSeguridad("400000******0116", "atm-scl-001", "pin_incorrecto", 1, 2, null));

        String json = CodecEventos.escribir(pin);

        assertThat(json).doesNotContain("bloqueadoHasta");
        assertThat(CodecEventos.leer(json).datosComo(DatosSeguridad.class).intentosRestantes()).isEqualTo(2);
    }

    @Test
    @DisplayName("Un campo desconocido no rompe la lectura (compatibilidad hacia adelante)")
    void toleraCamposNuevos() {
        String json = """
                {"eventId":"%s","tipo":"RETIRO_EJECUTADO","version":1,"ocurridoEn":"2026-09-11T15:00:00Z",
                 "origen":"core-service","campoDelFuturo":true,
                 "datos":{"cuentaId":116,"folio":"F","monto":1000,"saldoAnterior":2000,"saldoPosterior":1000,
                          "movimientoId":1,"moneda":"CLP","canal":"nuevo"}}""".formatted(UUID.randomUUID());

        assertThat(CodecEventos.leer(json).datosComo(DatosRetiro.class).cuentaId()).isEqualTo(116);
    }

    @ParameterizedTest(name = "[{index}] se rechaza: {0}")
    @ValueSource(strings = {
            "esto no es json",
            "[1,2,3]",
            "{}",
            "{\"tipo\":\"RETIRO_EJECUTADO\",\"version\":1,\"ocurridoEn\":\"2026-09-11T15:00:00Z\",\"origen\":\"x\",\"datos\":{}}",
            "{\"eventId\":\"no-es-uuid\",\"tipo\":\"RETIRO_EJECUTADO\",\"version\":1,\"ocurridoEn\":\"2026-09-11T15:00:00Z\",\"origen\":\"x\",\"datos\":{}}",
            "{\"eventId\":\"6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11\",\"tipo\":\"RETIRO_EJECUTADO\",\"version\":\"1\",\"ocurridoEn\":\"2026-09-11T15:00:00Z\",\"origen\":\"x\",\"datos\":{}}",
            "{\"eventId\":\"6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11\",\"tipo\":\"RETIRO_EJECUTADO\",\"version\":1,\"ocurridoEn\":\"ayer\",\"origen\":\"x\",\"datos\":{}}",
            "{\"eventId\":\"6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11\",\"tipo\":\"RETIRO_EJECUTADO\",\"version\":1,\"ocurridoEn\":\"2026-09-11T15:00:00Z\",\"origen\":\"x\",\"datos\":\"texto\"}",
            "{\"eventId\":\"6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11\",\"tipo\":\"RETIRO_EJECUTADO\",\"version\":7,\"ocurridoEn\":\"2026-09-11T15:00:00Z\",\"origen\":\"x\",\"datos\":{}}",
            "{\"eventId\":\"6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11\",\"tipo\":\"TIPO_INVENTADO\",\"version\":1,\"ocurridoEn\":\"2026-09-11T15:00:00Z\",\"origen\":\"x\",\"datos\":{}}"
    })
    void rechazaLoInvalido(String mensaje) {
        assertThatThrownBy(() -> CodecEventos.leer(mensaje)).isInstanceOf(EventoInvalidoException.class);
    }

    @Test
    @DisplayName("Un mensaje nulo o en blanco se rechaza")
    void rechazaVacio() {
        assertThatThrownBy(() -> CodecEventos.leer(null)).isInstanceOf(EventoInvalidoException.class);
        assertThatThrownBy(() -> CodecEventos.leer("  ")).isInstanceOf(EventoInvalidoException.class);
    }

    @Test
    @DisplayName("Los tipos de seguridad se distinguen de los de negocio")
    void clasificaTipos() {
        assertThat(TiposEvento.esDeSeguridad(TiposEvento.PIN_INCORRECTO)).isTrue();
        assertThat(TiposEvento.esDeSeguridad(TiposEvento.RETIRO_EJECUTADO)).isFalse();
        assertThat(TiposEvento.soportado(TiposEvento.RETIRO_EJECUTADO, 2)).isFalse();
    }
}
