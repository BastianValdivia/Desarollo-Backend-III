package cl.duoc.bancoxyz.eventos.soporte;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Predicate;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.testcontainers.kafka.KafkaContainer;

import cl.duoc.bancoxyz.eventos.Topicos;

/**
 * Un Kafka REAL (imagen {@code apache/kafka:3.9.1}, modo KRaft, la misma del compose) compartido por todas
 * las pruebas de un mismo proceso de pruebas que lo necesitan (una por modulo), igual que la base de
 * PostgreSQL de cada servicio. Vive en el jar de pruebas de {@code eventos-contrato} y lo usan, con scope
 * test, el core, el auth-server y los dos consumidores: asi no hay cuatro copias del mismo codigo.
 *
 * <p>Se prueba contra un broker de verdad y no contra uno simulado porque lo que importa aqui son
 * comportamientos del broker: que la idempotencia del productor no duplique, que la clave decida la
 * particion y que el orden se conserve dentro de ella. Ademas permite congelar el contenedor
 * ({@link #pausar()}) para emular un Kafka caido sin parar el proceso.
 *
 * <p>Los dos topicos de negocio se crean con las 3 particiones del sistema (si no, el broker los crearia al
 * vuelo con 1 y las pruebas de orden y de reparto no probarian nada).
 */
public final class KafkaDePrueba {

    private static final KafkaContainer CONTENEDOR = new KafkaContainer("apache/kafka:3.9.1");

    static {
        CONTENEDOR.start();
        Runtime.getRuntime().addShutdownHook(new Thread(CONTENEDOR::stop));
        try (AdminClient admin = AdminClient.create(Map.<String, Object>of("bootstrap.servers", bootstrap()))) {
            admin.createTopics(List.of(
                    new NewTopic(Topicos.RETIROS, Topicos.PARTICIONES, (short) 1),
                    new NewTopic(Topicos.SEGURIDAD, Topicos.PARTICIONES, (short) 1))).all().get();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo crear el topico de pruebas", e);
        }
    }

    private KafkaDePrueba() {
    }

    public static String bootstrap() {
        return CONTENEDOR.getBootstrapServers();
    }

    /** Congela el broker: sigue "vivo" pero no responde nada, como un Kafka inalcanzable. */
    public static void pausar() {
        CONTENEDOR.getDockerClient().pauseContainerCmd(CONTENEDOR.getContainerId()).exec();
    }

    /** Descongela el broker. Es seguro llamarlo aunque no este pausado (se ignora ese error). */
    public static void reanudar() {
        try {
            CONTENEDOR.getDockerClient().unpauseContainerCmd(CONTENEDOR.getContainerId()).exec();
        } catch (RuntimeException e) {
            // No estaba pausado: nada que hacer.
        }
    }

    /**
     * Una plantilla con el mismo caracter que el productor de produccion (config-repo/application.yml):
     * {@code acks=all}, idempotente, lz4, lotes y plazos cortos.
     */
    public static KafkaTemplate<String, String> plantilla(String bootstrap) {
        Map<String, Object> propiedades = new HashMap<>();
        propiedades.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        propiedades.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        propiedades.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        propiedades.put(ProducerConfig.ACKS_CONFIG, "all");
        propiedades.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        propiedades.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "lz4");
        propiedades.put(ProducerConfig.LINGER_MS_CONFIG, 20);
        propiedades.put(ProducerConfig.BATCH_SIZE_CONFIG, 32768);
        propiedades.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, 2000);
        propiedades.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, 5000);
        propiedades.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, 2000);
        return new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(propiedades));
    }

    /**
     * Lee el topico desde el principio, en TODAS sus particiones, hasta que la condicion se cumpla o venza
     * el plazo. Devuelve lo leido (el orden relativo dentro de cada particion es el del log).
     */
    public static List<ConsumerRecord<String, String>> leerHasta(
            String topico, Predicate<List<ConsumerRecord<String, String>>> condicion, Duration plazo) {
        Properties propiedades = new Properties();
        propiedades.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap());
        propiedades.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        propiedades.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        List<ConsumerRecord<String, String>> leidos = new ArrayList<>();
        long limite = System.nanoTime() + plazo.toNanos();
        try (KafkaConsumer<String, String> consumidor = new KafkaConsumer<>(propiedades)) {
            List<TopicPartition> particiones = consumidor.partitionsFor(topico).stream()
                    .map(p -> new TopicPartition(topico, p.partition())).toList();
            consumidor.assign(particiones);
            consumidor.seekToBeginning(particiones);
            while (System.nanoTime() < limite) {
                ConsumerRecords<String, String> lote = consumidor.poll(Duration.ofMillis(300));
                lote.forEach(leidos::add);
                if (condicion.test(leidos)) {
                    break;
                }
            }
        }
        return leidos;
    }
}
