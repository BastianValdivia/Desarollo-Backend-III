package cl.duoc.bancoxyz.eventos;

/**
 * Nombres de los topicos de Kafka del sistema.
 *
 * <p>El sufijo {@code .v1} es la version del CONTRATO del topico: un cambio incompatible de formato
 * no se hace sobre este topico sino en uno nuevo ({@code .v2}), de modo que productores y consumidores
 * viejos y nuevos pueden convivir mientras migran. Un campo opcional nuevo, en cambio, no cambia el
 * nombre (ver docs/eventos.md, seccion de compatibilidad).
 *
 * <p>La clave de cada registro decide la particion (hash de la clave), y dentro de una particion el
 * orden esta garantizado: por eso la clave de los retiros es la cuenta (los eventos de una cuenta
 * llegan en el orden en que ocurrieron) y la de seguridad es el usuario o la tarjeta enmascarada.
 */
public final class Topicos {

    /** Retiros ejecutados por el core. Clave: numero de cuenta. */
    public static final String RETIROS = "bancoxyz.retiros.v1";

    /** Eventos de seguridad del auth-server. Clave: usuario o tarjeta enmascarada. */
    public static final String SEGURIDAD = "bancoxyz.seguridad.v1";

    /** Particiones con que se crean los topicos de negocio: es el techo de consumidores utiles por grupo. */
    public static final int PARTICIONES = 3;

    private Topicos() {
    }
}
