package cl.duoc.bancoxyz.eventos;

import java.math.BigDecimal;

/**
 * Contenido de {@link TiposEvento#RETIRO_EJECUTADO}, version 1.
 *
 * <p>Describe un retiro ya confirmado en la base del core. Lleva las cifras del comprobante y el id del
 * movimiento que dejo en el historial, para que un consumidor pueda cruzar el evento con los datos del
 * core sin consultarlo.
 *
 * @param cuentaId        cuenta de la que se retiro
 * @param folio           folio del comprobante ({@code RET-yyyyMMdd-NNNNNN})
 * @param monto           importe retirado
 * @param saldoAnterior   saldo antes del retiro
 * @param saldoPosterior  saldo despues del retiro
 * @param movimientoId    id del movimiento registrado en el core
 * @param moneda          codigo de moneda (CLP)
 */
public record DatosRetiro(
        int cuentaId,
        String folio,
        BigDecimal monto,
        BigDecimal saldoAnterior,
        BigDecimal saldoPosterior,
        long movimientoId,
        String moneda) {
}
