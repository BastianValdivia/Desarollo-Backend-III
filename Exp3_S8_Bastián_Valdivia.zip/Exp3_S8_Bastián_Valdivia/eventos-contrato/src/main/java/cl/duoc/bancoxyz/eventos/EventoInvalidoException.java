package cl.duoc.bancoxyz.eventos;

/**
 * El mensaje recibido no cumple el contrato de eventos: no es JSON, le falta un campo obligatorio o
 * trae un tipo o una version desconocidos.
 *
 * <p>Es un error PERMANENTE: reintentar el mismo mensaje dara el mismo resultado. Por eso los
 * consumidores lo declaran no reintentable y el mensaje va directo a la DLT, sin gastar los
 * reintentos no bloqueantes ni detener el consumo de la particion.
 */
public class EventoInvalidoException extends RuntimeException {

    public EventoInvalidoException(String mensaje) {
        super(mensaje);
    }

    public EventoInvalidoException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
