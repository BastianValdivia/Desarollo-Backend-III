package cl.duoc.bancoxyz.eventos;

import java.time.Instant;
import java.util.UUID;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * El sobre versionado que envuelve a todo evento del sistema. Es el contrato (docs/eventos.md).
 *
 * <p>Seis campos, todos obligatorios:
 *
 * <ul>
 *   <li>{@code eventId}: UUID unico del evento. Es la CLAVE DE IDEMPOTENCIA de los consumidores: Kafka
 *       entrega "al menos una vez", asi que un evento puede llegar repetido, y el consumidor lo
 *       reconoce por este valor.</li>
 *   <li>{@code tipo}: que ocurrio (ver {@link TiposEvento}).</li>
 *   <li>{@code version}: version del formato de {@code datos} para ese tipo.</li>
 *   <li>{@code ocurridoEn}: instante en que ocurrio el hecho (no cuando se publico ni cuando se
 *       proceso), en UTC.</li>
 *   <li>{@code origen}: servicio que lo emitio.</li>
 *   <li>{@code datos}: el contenido propio del tipo, un objeto JSON.</li>
 * </ul>
 *
 * <p>La clave del registro de Kafka (cuenta, usuario) NO va dentro del sobre: es metadato del
 * transporte y decide la particion. Los datos que la contienen (por ejemplo {@code cuentaId}) si van
 * en {@code datos}, para que el evento se entienda sin su clave.
 *
 * @param eventId    UUID del evento, en texto
 * @param tipo       tipo del evento
 * @param version    version del formato, desde 1
 * @param ocurridoEn instante del hecho
 * @param origen     servicio emisor
 * @param datos      contenido, objeto JSON
 */
public record SobreEvento(
        String eventId,
        String tipo,
        int version,
        Instant ocurridoEn,
        String origen,
        JsonNode datos) {

    /** Crea un evento nuevo con identificador aleatorio. */
    public static SobreEvento nuevo(String tipo, int version, Instant ocurridoEn, String origen, Object datos) {
        return new SobreEvento(UUID.randomUUID().toString(), tipo, version, ocurridoEn, origen,
                CodecEventos.comoArbol(datos));
    }

    /** Interpreta {@code datos} como la clase indicada (por ejemplo {@link DatosRetiro}). */
    public <T> T datosComo(Class<T> clase) {
        return CodecEventos.convertir(datos, clase);
    }
}
