package cl.duoc.bancoxyz.eventos;

import java.util.Map;
import java.util.Set;

/**
 * Catalogo de tipos de evento y de las versiones que cada uno admite.
 *
 * <p>El campo {@code tipo} del sobre dice QUE ocurrio y {@code version} dice con que forma se
 * describe. Un consumidor que recibe un tipo o una version que no conoce no puede interpretarlo con
 * seguridad: lo rechaza como invalido (va a la DLT) en vez de adivinar. Este catalogo es la lista de lo
 * que el sistema entiende hoy.
 */
public final class TiposEvento {

    /** Un retiro se ejecuto en el core (topico {@link Topicos#RETIROS}). */
    public static final String RETIRO_EJECUTADO = "RETIRO_EJECUTADO";

    /** Una clave de usuario web o movil fue rechazada (topico {@link Topicos#SEGURIDAD}). */
    public static final String LOGIN_FALLIDO = "LOGIN_FALLIDO";

    /** Un usuario web o movil quedo bloqueado por intentos de clave agotados. */
    public static final String USUARIO_BLOQUEADO = "USUARIO_BLOQUEADO";

    /** El PIN de una tarjeta fue rechazado en un cajero. */
    public static final String PIN_INCORRECTO = "PIN_INCORRECTO";

    /** Una tarjeta quedo bloqueada por PIN errado repetido. */
    public static final String TARJETA_BLOQUEADA = "TARJETA_BLOQUEADA";

    private static final Map<String, Set<Integer>> VERSIONES = Map.of(
            RETIRO_EJECUTADO, Set.of(1),
            LOGIN_FALLIDO, Set.of(1),
            USUARIO_BLOQUEADO, Set.of(1),
            PIN_INCORRECTO, Set.of(1),
            TARJETA_BLOQUEADA, Set.of(1));

    private TiposEvento() {
    }

    /** Verdadero si el tipo existe y esa version esta definida. */
    public static boolean soportado(String tipo, int version) {
        return VERSIONES.getOrDefault(tipo, Set.of()).contains(version);
    }

    /** Verdadero si el tipo es de seguridad (viaja por {@link Topicos#SEGURIDAD}). */
    public static boolean esDeSeguridad(String tipo) {
        return LOGIN_FALLIDO.equals(tipo) || USUARIO_BLOQUEADO.equals(tipo)
                || PIN_INCORRECTO.equals(tipo) || TARJETA_BLOQUEADA.equals(tipo);
    }
}
