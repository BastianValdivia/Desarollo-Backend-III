package cl.duoc.bancoxyz.eventos;

import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Contenido de los eventos de seguridad (version 1 de {@code LOGIN_FALLIDO}, {@code USUARIO_BLOQUEADO},
 * {@code PIN_INCORRECTO} y {@code TARJETA_BLOQUEADA}).
 *
 * <p>Nunca lleva una clave, un PIN ni un numero de tarjeta completo: el sujeto de una tarjeta va
 * enmascarado (primeros 6 y ultimos 4 digitos), que basta para reconocerla en una investigacion y no
 * sirve para usarla. Los campos que no aplican a un tipo se omiten del JSON.
 *
 * @param sujeto             usuario (login) o tarjeta enmascarada
 * @param terminal           terminal del cajero, solo en eventos de tarjeta
 * @param motivo             causa corta y estable (por ejemplo {@code clave_incorrecta})
 * @param intentosFallidos   fallos seguidos acumulados, si se conoce
 * @param intentosRestantes  intentos que quedan antes del bloqueo, si se conoce
 * @param bloqueadoHasta     fin del bloqueo, solo en los eventos de bloqueo
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record DatosSeguridad(
        String sujeto,
        String terminal,
        String motivo,
        Integer intentosFallidos,
        Integer intentosRestantes,
        Instant bloqueadoHasta) {
}
