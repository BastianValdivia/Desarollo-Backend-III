package cl.duoc.bancoxyz.eventos;

import java.time.Instant;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * Escribe y lee el sobre de eventos como texto JSON.
 *
 * <p>Los servicios mandan a Kafka un {@code String} y no dejan que una libreria serialice por ellos.
 * Asi el contrato lo controla este codigo y no la configuracion de un serializador, y un mensaje
 * invalido se detecta en {@link #leer(String)} dentro del consumidor, donde se puede mandar a la DLT.
 * (Con un deserializador JSON en el cliente de Kafka, un mensaje roto fallaria antes de entrar al
 * consumidor y bloquearia la particion.)
 *
 * <p>La lectura es TOLERANTE con los campos desconocidos: un productor mas nuevo puede agregar campos
 * opcionales sin romper a los consumidores viejos. Es lo que permite evolucionar sin cambiar de version.
 * Los importes se escriben como numeros JSON exactos (sin pasar por {@code double}).
 */
public final class CodecEventos {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
            .enable(com.fasterxml.jackson.core.JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN)
            .setNodeFactory(JsonNodeFactory.withExactBigDecimals(true));

    private CodecEventos() {
    }

    /** Escribe el sobre como JSON compacto. */
    public static String escribir(SobreEvento evento) {
        try {
            return MAPPER.writeValueAsString(evento);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("No se pudo serializar el evento " + evento.eventId(), e);
        }
    }

    /**
     * Lee y VALIDA un mensaje.
     *
     * @throws EventoInvalidoException si no es JSON, falta un campo obligatorio, el {@code eventId} no es
     *         un UUID, o el tipo o la version no estan definidos en {@link TiposEvento}
     */
    public static SobreEvento leer(String json) {
        if (json == null || json.isBlank()) {
            throw new EventoInvalidoException("El mensaje esta vacio.");
        }
        JsonNode raiz;
        try {
            raiz = MAPPER.readTree(json);
        } catch (JsonProcessingException e) {
            throw new EventoInvalidoException("El mensaje no es JSON valido.", e);
        }
        if (raiz == null || !raiz.isObject()) {
            throw new EventoInvalidoException("El mensaje no es un objeto JSON.");
        }
        String eventId = texto(raiz, "eventId");
        try {
            UUID.fromString(eventId);
        } catch (IllegalArgumentException e) {
            throw new EventoInvalidoException("eventId no es un UUID: " + eventId, e);
        }
        String tipo = texto(raiz, "tipo");
        JsonNode nodoVersion = raiz.get("version");
        if (nodoVersion == null || !nodoVersion.isInt() || nodoVersion.intValue() < 1) {
            throw new EventoInvalidoException("version debe ser un entero desde 1.");
        }
        int version = nodoVersion.intValue();
        Instant ocurridoEn;
        try {
            ocurridoEn = Instant.parse(texto(raiz, "ocurridoEn"));
        } catch (java.time.format.DateTimeParseException e) {
            throw new EventoInvalidoException("ocurridoEn no es un instante ISO-8601.", e);
        }
        String origen = texto(raiz, "origen");
        JsonNode datos = raiz.get("datos");
        if (datos == null || !datos.isObject()) {
            throw new EventoInvalidoException("datos debe ser un objeto JSON.");
        }
        if (!TiposEvento.soportado(tipo, version)) {
            throw new EventoInvalidoException("Tipo o version no soportados: " + tipo + " v" + version);
        }
        return new SobreEvento(eventId, tipo, version, ocurridoEn, origen, datos);
    }

    private static String texto(JsonNode raiz, String campo) {
        JsonNode nodo = raiz.get(campo);
        if (nodo == null || !nodo.isTextual() || nodo.textValue().isBlank()) {
            throw new EventoInvalidoException("Falta el campo obligatorio de texto: " + campo);
        }
        return nodo.textValue();
    }

    static JsonNode comoArbol(Object datos) {
        return MAPPER.valueToTree(datos);
    }

    static <T> T convertir(JsonNode datos, Class<T> clase) {
        try {
            return MAPPER.treeToValue(datos, clase);
        } catch (JsonProcessingException e) {
            throw new EventoInvalidoException("Los datos no corresponden a " + clase.getSimpleName(), e);
        }
    }
}
