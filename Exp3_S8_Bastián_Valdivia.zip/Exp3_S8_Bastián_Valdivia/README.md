# Banco XYZ: microservicios y resiliencia en la nube con Spring Cloud

Sumativa individual Exp3 S8 de Desarrollo Backend III (PBY2203, Duoc UC). Parte del proyecto de la
semana 5 (patrón Backend for Frontend, línea base en el commit `dd2e301`) y lo lleva a una
arquitectura de microservicios lista para la nube: Spring Cloud (Config Server y Eureka), OAuth 2.0
con Spring Authorization Server, Resilience4j, mensajería con Kafka, PostgreSQL y Docker.

**Para empezar rápido:** instala Docker Desktop (Compose v2.20 o superior) y ejecuta, desde la
carpeta del proyecto, `docker compose up -d --build --wait`. Todo el sistema (16 contenedores) queda
`healthy` con ese único comando. Los pasos completos están en la sección
[Cómo ejecutar el proyecto](#cómo-ejecutar-el-proyecto).

## Contenido

1. [Objetivo](#objetivo)
2. [Arquitectura](#arquitectura)
3. [Estructura del código](#estructura-del-código)
4. [Requisitos](#requisitos)
5. [Cómo ejecutar el proyecto](#cómo-ejecutar-el-proyecto)
6. [Usuarios y tarjetas de demostración](#usuarios-y-tarjetas-de-demostración)
7. [Catálogo de endpoints](#catálogo-de-endpoints)
8. [Seguridad](#seguridad)
9. [Resiliencia](#resiliencia)
10. [Eventos con Kafka](#eventos-con-kafka)
11. [Despliegue](#despliegue)
12. [Pruebas y verificación](#pruebas-y-verificación)
13. [Trazabilidad con la pauta de evaluación](#trazabilidad-con-la-pauta-de-evaluación)
14. [Decisiones de diseño](#decisiones-de-diseño)
15. [Limitaciones conocidas](#limitaciones-conocidas)
16. [Documentación del repositorio](#documentación-del-repositorio)

---

## Objetivo

El Banco XYZ atiende a sus clientes por tres canales: un sitio **web**, una aplicación **móvil** y
los **cajeros automáticos** (ATM). En la semana 5 cada canal tenía su propio backend (patrón BFF) y
todo el dominio vivía en memoria de un único proceso, con tokens que cada BFF firmaba por su cuenta.
Eso sirve para una demostración, pero no para operar en la nube.

Este proyecto resuelve cinco problemas concretos, que son los que pide la actividad:

| Problema | Respuesta del proyecto |
|---|---|
| Cada BFF emite sus propios tokens y el core se protegía con una cabecera fija | Un **servidor de autorización OAuth 2.0** (Spring Authorization Server) es el único que emite tokens; los servicios solo los validan |
| Los servicios se encuentran por direcciones fijas y su configuración está dentro de cada uno | **Config Server** y **Eureka** (Spring Cloud): configuración centralizada y descubrimiento por nombre |
| Si el core cae o se vuelve lento, los tres canales caen con él | **Resilience4j** (Retry, CircuitBreaker y Bulkhead) con un comportamiento de respaldo distinto por canal |
| Un retiro no tiene forma de avisar a otros sistemas sin acoplarlos | **Kafka** con patrón outbox: un retiro genera un evento que consumen notificaciones y auditoría |
| El sistema solo corre en la máquina del autor | **Docker**: una imagen por microservicio y un `docker-compose.yaml` que levanta todo con un comando |

Lo que no cambia es el comportamiento visible del S5 (login por canal, titularidad de cuentas,
retiro atómico e idempotente, optimización por canal): una lista de doce comprobaciones de no
regresión sigue pasando completa (`evidencias/salidas/40-no-regresion-s5.txt`, 60 comprobaciones).

La propuesta técnica, con el problema, las alternativas descartadas, los riesgos y el alcance, está
en [`docs/propuesta-tecnica.md`](docs/propuesta-tecnica.md).

---

## Arquitectura

### Vista general

```mermaid
flowchart LR
  subgraph Cliente["Cliente (tu equipo)"]
    NAV[Navegador]
    APP[App móvil]
    ATM[Cajero ATM]
  end
  subgraph Borde["Red borde: puertos publicados"]
    AS["auth-server 9000 HTTPS"]
    W["bff-web 8443 HTTPS"]
    M["bff-mobile 8444 HTTPS"]
    A["bff-atm 8445 HTTPS"]
    EU["eureka-server 127.0.0.1:8761"]
    KUI["kafka-ui 127.0.0.1:8090"]
  end
  subgraph Interna["Red interna: sin salida a Internet, sin puertos publicados"]
    CFG["config-server 8888"]
    CORE["core-service x2 8080"]
    PG[("PostgreSQL 16<br/>core, auditoria, notificaciones")]
    K[("Kafka 3.9.1 KRaft")]
    N["notificaciones-service x2"]
    AU["auditoria-service 8110"]
  end
  NAV -->|authorization_code + PKCE| AS
  APP -->|authorization_code + PKCE| AS
  ATM -->|tarjeta + PIN| AS
  NAV -->|Bearer| W
  APP -->|Bearer| M
  ATM -->|Bearer| A
  W -->|token de servicio, Resilience4j| CORE
  M -->|token de servicio, Resilience4j| CORE
  A -->|token de servicio, Resilience4j| CORE
  W -->|token de servicio, Resilience4j| AU
  CORE --> PG
  CORE -->|outbox + relay| K
  AS -->|eventos de seguridad| K
  K --> N
  K --> AU
  N --> PG
  AU --> PG
```

Todos los servicios de negocio leen su configuración del `config-server` (carpeta `config-repo/`) y
se registran en `eureka-server`; esas dos flechas no se dibujan para no llenar el diagrama. Los
servicios se llaman por **nombre lógico** (`http://core-service`), nunca por dirección.

### Un retiro de punta a punta

```mermaid
sequenceDiagram
  participant T as Cajero
  participant AS as auth-server
  participant B as bff-atm
  participant C as core-service
  participant DB as PostgreSQL
  participant R as relay (líder)
  participant K as Kafka
  participant N as notificaciones
  participant AU as auditoria
  T->>AS: tarjeta + PIN + secreto del terminal
  AS-->>T: token (3 min, audiencia bff-atm)
  T->>B: POST /retiros con Idempotency-Key
  B->>B: valida token, titularidad y reglas del retiro
  B->>C: retiro con token de servicio (Retry, CircuitBreaker, Bulkhead)
  C->>DB: una transacción: UPDATE saldo + movimiento + clave + outbox
  C-->>B: folio y saldos
  B-->>T: folio, saldos y billetes
  R->>DB: lee el outbox pendiente
  R->>K: publica RETIRO_EJECUTADO (clave: cuenta)
  K-->>N: grupo notificaciones
  K-->>AU: grupo auditoria
```

### Componentes

Nueve microservicios propios (cada uno con su imagen `bancoxyz/<servicio>:1.0.0`) y la
infraestructura que los sostiene. El compose levanta 16 contenedores (`evidencias/salidas/01-arranque.txt`).

| Componente | Tipo | Puerto de servicio | Publicado al host | Réplicas | Datos |
|---|---|---|---|---|---|
| `config-server` | microservicio (Spring Cloud Config, perfil `native`) | 8888 | no | 1 | `config-repo/` |
| `eureka-server` | microservicio (Spring Cloud Netflix) | 8761 | `127.0.0.1:8761` (dashboard) | 1 | memoria |
| `auth-server` | microservicio (Spring Authorization Server) | 9000, HTTPS | `9000` | 1 | clave de firma en su volumen |
| `core-service` | microservicio (dominio: cuentas, movimientos, retiros) | 8080 | no | 2 | base `core` |
| `bff-web` | microservicio (BFF del canal web) | 8443, HTTPS, `/api/web` | `8443` | 1 | caché local |
| `bff-mobile` | microservicio (BFF del canal móvil) | 8444, HTTPS, `/api/mobile` | `8444` | 1 | caché local |
| `bff-atm` | microservicio (BFF del cajero) | 8445, HTTPS, `/api/atm` | `8445` | 1 | ninguno |
| `notificaciones-service` | microservicio (consumidor de Kafka) | 8100 (sin API) | no | 2 | base `notificaciones` |
| `auditoria-service` | microservicio (consumidor de Kafka y API protegida) | 8110 | no | 1 | base `auditoria` |
| `postgres` | infraestructura (PostgreSQL 16.15) | 5432 | no | 1 | volumen `postgres-datos` |
| `kafka` | infraestructura (Kafka 3.9.1, modo KRaft, un nodo) | 9092 | no | 1 | volumen `kafka-datos` |
| `kafka-init` | tarea única: declara los tópicos y termina | no aplica | no | 1 | ninguno |
| `kafka-ui` | observabilidad (kafbat/kafka-ui v1.5.0) | 8080 | `127.0.0.1:8090` | 1 | ninguno |
| `secretos-init` | tarea única: genera la CA interna y los secretos y termina | no aplica | no | 1 | volúmenes de secretos |

Cada servicio con Actuator lo expone en un **puerto de gestión aparte** (8081 en contenedores, HTTP,
nunca publicado) con solo `health`, `info`, `metrics` y `refresh`; los BFF suman los endpoints de
Resilience4j. `env`, `configprops` y `heapdump` no existen (404).

Hay dos redes. `borde` lleva lo que el usuario alcanza (los tres BFF, el auth-server, el dashboard
de Eureka y kafka-ui). `interna` está declarada `internal: true`: sus contenedores no tienen salida a
Internet y Docker no publica puertos de ella, y ahí viven el core, PostgreSQL, Kafka, config-server y
los consumidores, sin ningún puerto publicado. Una precisión medida: en un anfitrión **Linux** la IP
de un contenedor de esa red (172.31.250.x) sí responde desde el propio equipo, porque el puente de
Docker vive en él; en Docker Desktop (Windows y macOS) no. Por eso lo que protege al core no es la
red sino el token OAuth2 que exige en todo `/internal/**`.

### Por qué no hay API Gateway

La arquitectura de referencia de la guía incluye un gateway. Aquí cada BFF ya es la puerta de
entrada de su canal; poner un gateway delante volvería a centralizar lo que el patrón BFF separó a
propósito, y la pauta no lo pide.

---

## Estructura del código

Proyecto Maven multimódulo (Java 21, Spring Boot 3.3.13, BOM de Spring Cloud 2023.0.6 importado en
el POM padre; las versiones viven solo en `pom.xml`).

```text
.
├── pom.xml                      POM padre: versiones, BOM de Spring Cloud, lista de módulos
├── docker-compose.yaml          orquesta los 16 contenedores
├── config-repo/                 configuración que entrega el config-server (por servicio y perfil)
├── plataforma-comun/            biblioteca compartida (ver abajo)
├── eventos-contrato/            contrato de los eventos de Kafka (solo Jackson)
├── config-server/               Spring Cloud Config Server            (Dockerfile)
├── eureka-server/               registro y descubrimiento             (Dockerfile)
├── auth-server/                 servidor de autorización OAuth 2.0    (Dockerfile)
├── core-service/                dominio, PostgreSQL, outbox, relay    (Dockerfile)
├── bff-web/  bff-mobile/  bff-atm/        los tres BFF                (Dockerfile cada uno)
├── notificaciones-service/      consumidor de eventos                 (Dockerfile)
├── auditoria-service/           consumidor de eventos y API           (Dockerfile)
├── docker/                      secretos-init (imagen), init de PostgreSQL y tópicos de Kafka
├── scripts/                     login, verificación, medición y escenarios de caos
├── evidencias/                  salidas literales de la ejecución, capturas e INDICE.md
├── docs/                        propuesta técnica, contrato de eventos y guía de estudio
└── planificacion/               plan maestro y una bitácora por fase
```

| Módulo | Qué contiene |
|---|---|
| `plataforma-comun` | Lo que comparten los BFF y que es **mecanismo, nunca política**: lectura de claims, confianza en el JWKS del auth-server, cliente del core balanceado por Eureka con el token de servicio OAuth2, `CoreClientResiliente` (Retry, CircuitBreaker y Bulkhead), respaldo de último dato conocido, formato de errores RFC 7807 y la seguridad del puerto de gestión. No emite tokens. |
| `eventos-contrato` | El sobre `SobreEvento`, `CodecEventos` (escribe y valida), `TiposEvento`, `Topicos` y los datos de cada evento. Sin Spring ni Kafka: lo usan productores y consumidores para no desviarse. |
| `core-service` | Capas `api` (controladores `/internal/**`), `aplicacion`, dominio y adaptadores JDBC (Flyway: `V1` esquema, `V2` carga inicial del dataset, `V3` idempotencia por cuenta, `V4` outbox). Servidor de recursos OAuth2 con un scope por endpoint. |
| `bff-web`, `bff-mobile`, `bff-atm` | Un BFF por canal en capas `api`, `aplicacion` y `seguridad`. Solo **validan** tokens; cada uno decide su política de canal (paginación, caché, reglas del retiro, respaldo). |
| `auth-server` | Clientes `client_credentials` de los BFF, clientes públicos `web-app` y `mobile-app` (`authorization_code` + PKCE), grant de extensión tarjeta y PIN, política de intentos y publicación de eventos de seguridad. |
| `notificaciones-service`, `auditoria-service` | Consumidores idempotentes por `eventId`, con reintentos no bloqueantes y DLT. Auditoría además expone su API de lectura. |

La duplicación entre los tres BFF es deliberada: lo que cambia entre canales (política) vive en cada
BFF y lo que no (mecanismo) vive en `plataforma-comun`.

---

## Requisitos

| Necesitas | Detalle |
|---|---|
| Docker Desktop (Windows o macOS) o Docker Engine (Linux) con **Compose v2.20 o superior** y buildx | Es el **único requisito** para levantar y probar el sistema: no hace falta JDK ni Maven (se compilan dentro de las imágenes). `scripts/verificar.sh` comprueba la versión de Compose antes de empezar. |
| Memoria | El sistema completo ocupa unos 3 GiB en reposo (3044 MiB medidos, `evidencias/salidas/12-tabla-despliegue.txt`). Recomendación (no medida): asigna al menos 6 GiB a Docker Desktop. |
| CPU | Los tiempos de este documento se midieron con 4 CPU. Con menos, el arranque es más lento. |
| `bash`, `curl` y `python3` | Solo para los scripts de login y verificación. En Windows, usa **Git Bash** o **WSL**, con Python 3 instalado desde python.org (el alias de la Microsoft Store no ejecuta nada: los scripts lo detectan y lo dicen). Usa el `curl` de Git Bash; si el `curl.exe` nativo de Windows (Schannel) rechaza el certificado de la CA interna por no poder comprobar su revocación, agrega `--ssl-no-revoke`. El camino principal (`docker compose up`) funciona también desde PowerShell. |
| Internet en la primera construcción | Para bajar imágenes base y dependencias de Maven. La primera construcción tarda varios minutos y depende de tu red. |
| JDK 21 (opcional) | Solo si quieres ejecutar `./mvnw -B verify` en tu equipo (y Docker en marcha: las pruebas usan PostgreSQL y Kafka reales con Testcontainers). |

---

## Cómo ejecutar el proyecto

### Camino estándar: un comando

```bash
git clone https://github.com/abaquedano1/bastian-backend3-tercera-entrega
cd bastian-backend3-tercera-entrega
docker compose up -d --build --wait
```

El `.zip` de la entrega trae lo mismo y no depende de GitHub.
Si recibiste el proyecto como `.zip`, descomprímelo, entra a la carpeta y ejecuta solo la última
línea (los scripts de verificación también funcionan sin `.git`: revisan los archivos de la carpeta). El comando construye las diez imágenes propias, genera los secretos y la CA interna en
volúmenes, y vuelve cuando todos los servicios están `healthy`. Con las imágenes ya construidas, el
arranque en frío tardó 71 s en la máquina de pruebas (`evidencias/salidas/01-arranque.txt`) y 66 s
hasta que todo estuvo listo en la medición de `12-tabla-despliegue.txt`. La **primera construcción** suma varios minutos.

```bash
docker compose ps -a              # 16 contenedores: los servicios 'healthy' y las dos tareas únicas 'Exited (0)' (sin -a, Compose solo lista los 14 que siguen corriendo)
```

Si tu Compose no admite `--wait`, ejecuta `docker compose up -d --build` y luego
`scripts/esperar-sano.sh`.

### Primera comprobación

`secretos-init` deja en `certs/ca.crt` la CA interna que firmó los certificados TLS. Se usa con
`--cacert`, nunca con `-k`:

```bash
curl --cacert certs/ca.crt https://localhost:8443/api/web/v1/cuentas/116
# 401: llegaste al servicio, falta el token
```

Sin `--cacert`, `curl` rechaza el certificado, que es lo correcto.

### Iniciar sesión en cada canal

El login es del `auth-server`. Cada script ejecuta el flujo completo con `curl`; con `--token`
imprime solo el token de acceso.

```bash
scripts/login-web.sh                  # muestra cada paso del flujo PKCE, la respuesta y los claims del JWT
TW=$(scripts/login-web.sh --token)    # web: cliente116 / Cliente.2026 (vigencia 30 min)
TM=$(scripts/login-movil.sh --token)  # móvil: mismo usuario, device_id dispositivo-demo-01 (vigencia 60 min)
TA=$(scripts/login-cajero.sh --token) # cajero: tarjeta 4000000000000116 y PIN 1234 (vigencia 3 min)
```

### Usar los tokens

```bash
curl --cacert certs/ca.crt -H "Authorization: Bearer $TW" https://localhost:8443/api/web/v1/cuentas/116
curl --cacert certs/ca.crt -H "Authorization: Bearer $TM" -H "X-Device-Id: dispositivo-demo-01" \
     https://localhost:8444/api/mobile/v1/cuentas/116/resumen
curl --cacert certs/ca.crt -H "Authorization: Bearer $TA" \
     https://localhost:8445/api/atm/v1/cuentas/116/saldo-disponible
```

Un retiro por el cajero (el token del cajero dura 3 minutos: pídelo justo antes). La misma
`Idempotency-Key` repetida devuelve el mismo folio y el saldo baja una sola vez:

```bash
TA=$(scripts/login-cajero.sh --token)
curl --cacert certs/ca.crt -X POST https://localhost:8445/api/atm/v1/cuentas/116/retiros \
     -H "Authorization: Bearer $TA" -H 'Content-Type: application/json' \
     -H 'Idempotency-Key: demo-116-001' -d '{"monto":5000}'
```

Después del retiro puedes mirar los eventos: **kafka-ui** en `http://localhost:8090` (tópicos y
grupos), el dashboard de **Eureka** en `http://localhost:8761`, o el panel del ejecutivo
(`GET /api/web/v1/admin/panel` con el token de `ejecutivo1`, que lee la auditoría).

### Verificar el sistema

```bash
scripts/verificar.sh                  # TODO en un comando: PASS o FAIL por criterio de la pauta (~33 min)
scripts/verificar.sh --rapido         # sin escenarios de caos ni escalado (~11 min); termina en 'PASS PARCIAL'
scripts/verificar-no-regresion.sh     # la lista de no regresión del S5 contra el sistema en marcha (~17 s)
scripts/verificar-matriz-3x3.sh       # el token de cada canal solo sirve en su BFF (3 s)
scripts/verificar-f7.sh               # Kafka: outbox, consumidores, DLT, auditoría y panel (~7 min)
scripts/caos/core-caido.sh            # escenario de resiliencia: el core cae y vuelve (~4 min)
scripts/restablecer-demo.sh           # devuelve los saldos de la carga si hiciste retiros a mano
```

`scripts/verificar.sh` escribe `evidencias/salidas/NN-*.txt` y termina con código 0 solo si todo
pasó. El mapa de qué prueba cada archivo está en [`evidencias/INDICE.md`](evidencias/INDICE.md).
Los demás scripts están listados en `CLAUDE.md`. Dos avisos honestos: la sección 5 de
`verificar-f8.sh` consulta el registro de imágenes por Internet y puede dar FAIL por
"sin conexión al registro" si Docker Hub limita tus consultas (no es un fallo del sistema), y la
construcción de las imágenes necesita Internet.

### Detener

```bash
docker compose down        # detiene; conserva datos y secretos
docker compose down -v     # además borra volúmenes: el siguiente arranque es en frío
```

### Diagnóstico de los fallos más frecuentes

| Síntoma | Causa | Qué hacer |
|---|---|---|
| `curl` inmediato tras `up -d` (sin `--wait`) es rechazado | Los BFF aún arrancan (unos 15 a 20 s) | Usa `--wait` o `scripts/esperar-sano.sh` |
| `curl: (60) SSL certificate problem` | Falta `--cacert certs/ca.crt` | Agrégalo; no uses `-k` |
| Tras tres claves o PINs errados "no entra" | 3 fallos bloquean 15 minutos (política de seguridad) | `docker compose restart auth-server` libera el bloqueo (el contador vive en memoria) |
| Un retiro da 409 `saldo_insuficiente` en la cuenta 106 | Quedaron saldos modificados de una prueba | `scripts/restablecer-demo.sh` |
| 401 en el cajero a los pocos minutos | El token del cajero dura 3 minutos | Pide otro con `scripts/login-cajero.sh --token` |
| El dashboard de Eureka muestra un aviso rojo de emergencia | Autopreservación durante el primer minuto | Espera un minuto |
| El build falla con 429 | El registro de imágenes o Maven Central limita tu IP | Reintenta más tarde |
| `Pool overlaps with other one on this address space` al levantar | La red `interna` usa la subred fija 172.31.250.0/24 y choca con otra red o una VPN de tu equipo | Cambia la subred en `docker-compose.yaml` en los dos lugares que la nombran (`networks.interna.ipam` y `SPRING_CLOUD_INETUTILS_PREFERRED_NETWORKS`) |
| `python3 no funciona en este equipo` | Falta Python 3, o es el alias de la Microsoft Store | Instálalo desde python.org y desactiva el alias de la Tienda |
| `rm: cannot remove 'certs'` en Linux con `--frio` | `certs/` lo crea Docker como root | Es inofensivo: `secretos-init` reescribe `certs/ca.crt` |

---

## Usuarios y tarjetas de demostración

Estas credenciales son **de demostración y están publicadas a propósito**: el evaluador las
necesita para probar. Se guardan como hashes BCrypt en `config-repo/auth-server.yml`. Los secretos
de verdad (claves, certificados, secretos de clientes y contraseñas de las bases) se generan al
primer arranque y no están en git ni en las imágenes.

| Canal | Credencial | Dato adicional | Cuenta | Para qué sirve |
|---|---|---|---|---|
| Web (cliente) | `cliente116` / `Cliente.2026` | ninguno | 116 | Camino feliz del canal web |
| Web (cliente 2) | `cliente105` / `Cliente.2026` | ninguno | 105 | Provocar el 403 por titularidad al pedir la cuenta 116 |
| Web (ejecutivo) | `ejecutivo1` / `Exec.2026` | ninguno | no aplica | Rutas `/v1/admin/**` y el panel del ejecutivo |
| Móvil | `cliente116` / `Cliente.2026` | `device_id` (por defecto `dispositivo-demo-01`) y `X-Device-Id` en cada petición | 116 | Camino feliz y token atado al dispositivo |
| Cajero principal | tarjeta `4000000000000116`, PIN `1234` | terminal `atm-scl-001` | 116 | Saldo y retiro |
| Cajero saldo bajo | tarjeta `4000000000000106`, PIN `5678` | terminal `atm-scl-001` | 106 | Provocar `saldo_insuficiente` |
| Cajero solo consulta | tarjeta `4000000000000105`, PIN `4321` | terminal `atm-scl-001` | 105 | Único origen del 403 `permiso_insuficiente` en el retiro |
| Cajero sacrificable | tarjeta `4000000000000150`, PIN `9999` | terminal `atm-scl-001` | 150 | La única tarjeta que los scripts bloquean a propósito |

El secreto del terminal `atm-scl-001` lo genera `secretos-init` y `scripts/login-cajero.sh` lo lee
del volumen del auth-server: en un cajero real viviría en su equipo.

---

## Catálogo de endpoints

Los BFF viven bajo su `context-path` (`/api/web`, `/api/mobile`, `/api/atm`). Las rutas del core y
de auditoría solo son alcanzables desde la red interna y exigen un token OAuth2 de servicio.

### `auth-server` (9000, HTTPS)

| Ruta | Para qué |
|---|---|
| `GET /.well-known/openid-configuration` | Descubrimiento OIDC |
| `GET /oauth2/jwks` | Claves públicas (JWKS) con que los servicios validan las firmas |
| `GET /oauth2/authorize` y `GET/POST /login` | Inicio del flujo `authorization_code` con PKCE y formulario de login |
| `POST /oauth2/token` | Emisión de tokens: `client_credentials`, `authorization_code` y el grant de extensión `urn:bancoxyz:params:oauth:grant-type:tarjeta-pin` |

### `core-service` (8080, solo red interna)

Todo `/internal/**` exige `Authorization: Bearer` con audiencia `core-service`. Sin token, 401
`token_ausente`; con un token al que le falta el scope, 403 `permiso_insuficiente`.

| Verbo | Ruta | Scope | Devuelve |
|---|---|---|---|
| GET | `/internal/v1/cuentas/{id}` | `cuentas:leer` | Cuenta canónica con todos sus movimientos |
| GET | `/internal/v1/cuentas/{id}/saldo` | `saldo:leer` | Solo el saldo |
| GET | `/internal/v1/cuentas/{id}/movimientos?page&size&desde&hasta&tipo` | `movimientos:leer` | Una página de movimientos |
| POST | `/internal/v1/cuentas/{id}/retiros` | `retiros:ejecutar` | Retiro atómico e idempotente (cabecera `Idempotency-Key`) |
| GET | `/internal/v1/admin/calidad-datos` | `auditoria:leer` | Reporte de calidad de la ingesta |
| GET | `/internal/v1/admin/transacciones-no-conciliadas?page&size` | `auditoria:leer` | Lote de transacciones sin cuenta |

### `auditoria-service` (8110, solo red interna)

Exige audiencia `auditoria-service` y scope `auditoria:leer`.

| Verbo | Ruta | Devuelve |
|---|---|---|
| GET | `/internal/v1/auditoria/eventos?tipo&cuenta&sujeto&pagina&tamano` | Eventos guardados, del más reciente al más antiguo |
| GET | `/internal/v1/auditoria/resumen` | Total de eventos y conteo por tipo |

### `bff-web` (8443, HTTPS, `/api/web`)

| Verbo | Ruta | Autoridad exigida | Devuelve |
|---|---|---|---|
| GET | `/v1/cuentas/{id}` | `PERM_cuenta:leer` y ser el titular | Ficha, resumen y primera página de movimientos |
| GET | `/v1/cuentas/{id}/movimientos?page&size&desde&hasta&tipo` | `PERM_movimientos:leer` y titular | Página de movimientos (`size` máximo 100, validado en el servidor) |
| GET | `/v1/cuentas/{id}/resumen-mensual` | `PERM_resumen:leer` y titular | Agregados por mes (exclusivo de web) |
| GET | `/v1/admin/transacciones-no-conciliadas?page&size` | `ROLE_EJECUTIVO` | Lote no conciliado (exclusivo de web) |
| GET | `/v1/admin/calidad-datos` | `ROLE_EJECUTIVO` | Reporte de la ingesta (exclusivo de web) |
| GET | `/v1/admin/panel?cuenta` | `ROLE_EJECUTIVO` | Calidad de datos más actividad reciente desde auditoría; si auditoría cae, sale sin esa sección y lo avisa |

### `bff-mobile` (8444, HTTPS, `/api/mobile`)

`X-Device-Id` se exige en todas las peticiones y debe coincidir con el claim `device_id` del token.

| Verbo | Ruta | Autoridad exigida | Devuelve |
|---|---|---|---|
| GET | `/v1/cuentas/{id}/resumen` | `PERM_saldo:leer`, titular y dispositivo | Saldo, titular abreviado y los 5 últimos movimientos; emite `ETag` débil y responde 304 |
| POST | `/v1/dispositivos/baja` | `PERM_dispositivo:gestionar` | Da de baja el dispositivo del token; desde entonces cada petición suya recibe 401 `dispositivo_no_coincide` |

### `bff-atm` (8445, HTTPS, `/api/atm`)

| Verbo | Ruta | Autoridad exigida | Devuelve |
|---|---|---|---|
| GET | `/v1/cuentas/{id}/saldo-disponible` | `PERM_saldo:leer` y titular | `{"saldoDisponible":12000.00,"moneda":"CLP"}` |
| POST | `/v1/cuentas/{id}/retiros` | `PERM_retiro:ejecutar` y titular | Folio, saldos y desglose de billetes. Cuerpo `{"monto":n}` y `Idempotency-Key` |
| GET | `/v1/denominaciones` | `PERM_saldo:leer` | `[1000, 2000, 5000, 10000]` |

Reglas del retiro, validadas en este orden: múltiplo de 1.000 (422 `monto_no_multiplo`), mínimo
1.000 (422 `monto_bajo_minimo`), máximo 10.000 por operación (422 `supera_tope_transaccion`) y saldo
suficiente (422 `saldo_insuficiente`). El tope es 10.000 porque el saldo más alto del dataset es
12.000: con un tope mayor la regla nunca se ejercería.

**Lo exclusivo de cada canal** (404 en los otros dos): resumen mensual, no conciliadas, calidad de
datos y panel (web); baja de dispositivo (móvil); retiro y denominaciones (cajero). Si los tres
expusieran lo mismo serían el mismo backend desplegado tres veces.

Los errores salen en formato RFC 7807 (`application/problem+json`) con un campo `motivo` estable;
el cajero añade `codigoPantalla` y `mensajePantalla` (por ejemplo `E-090`).

---

## Seguridad

### Los roles de OAuth 2.0 en este proyecto

| Rol | Quién |
|---|---|
| Servidor de autorización | `auth-server` (Spring Authorization Server): el **único** que firma tokens |
| Servidor de recursos | `core-service`, `auditoria-service` y los tres BFF: validan firma (por JWKS), emisor, vigencia y audiencia |
| Cliente | Los BFF ante el core y auditoría (`client_credentials`); `web-app` y `mobile-app` (públicos, PKCE); el terminal `atm-scl-001` (confidencial) |
| Propietario del recurso | La persona que inicia sesión |

El emisor es fijo, `https://localhost:9000`, y las claves públicas se leen por la dirección interna
`https://auth-server:9000/oauth2/jwks`. Así el emisor del token es el mismo dentro y fuera de Docker.

### Flujos por canal

| Canal | Cliente | Flujo | Vigencia | Audiencia | Dato propio del token |
|---|---|---|---|---|---|
| Web | `web-app` (público) | `authorization_code` + PKCE | 30 min | `bff-web` | permisos del usuario en el canal |
| Móvil | `mobile-app` (público) | `authorization_code` + PKCE con `device_id` | 60 min | `bff-mobile` | claim `device_id` |
| Cajero | `atm-scl-001` (confidencial) | Grant de extensión: tarjeta + PIN, autenticado con el secreto del terminal | 3 min | `bff-atm` | claim `terminal` |
| BFF a servicios | `bff-web`, `bff-mobile`, `bff-atm` | `client_credentials` | 5 min | `core-service` (web también `auditoria-service`) | scopes mínimos |

La vigencia real del JWT (`exp - iat`) es 1800, 3600 y 180 s. El campo `expires_in` de la respuesta
del endpoint de tokens marca 1799, 3599 y 179 s: un segundo menos por el redondeo. Los scripts de
login muestran ambas cifras (`evidencias/salidas/40-no-regresion-s5.txt`, sección 13).

El cajero usa un **grant de extensión** porque no tiene navegador. El grant `password` no se usa:
la RFC 9700 lo prohíbe y Spring Authorization Server no lo implementa.

### Scopes mínimos por cliente de servicio

| Cliente | Scopes | Audiencias |
|---|---|---|
| `bff-web` | `cuentas:leer`, `movimientos:leer`, `auditoria:leer` | `core-service`, `auditoria-service` |
| `bff-mobile` | `cuentas:leer` | `core-service` |
| `bff-atm` | `saldo:leer`, `retiros:ejecutar` | `core-service` |

Si alguien compromete el BFF web, su token no sirve para retirar dinero (403). La matriz de
401, 403 y 200 del core, con tokens reales, está en `evidencias/salidas/30-oauth2-servidor-recursos-f4.txt`
(85 comprobaciones).

### La barrera entre canales: la audiencia

Hay una sola clave de firma, así que la barrera entre canales es la **audiencia**: cada BFF solo
acepta tokens cuyo `aud` lo nombre. Un token de web presentado al cajero recibe 401
`audiencia_invalida`. La matriz 3x3 (`evidencias/salidas/32-oauth2-matriz-3x3.txt`):

```text
token \ canal      web:8443 movil:8444   atm:8445
web                     200        401        401
movil                   401        200        401
cajero                  401        401        200
```

### Autorización en tres niveles

| Nivel | Pregunta | Dónde | Prueba |
|---|---|---|---|
| Rol | ¿qué perfil eres? | `/v1/admin/**` exige `ROLE_EJECUTIVO` en `bff-web` | cliente en el panel: 403 `permiso_insuficiente` |
| Operación | ¿qué puedes hacer? | `POST .../retiros` exige `PERM_retiro:ejecutar` en `bff-atm` | tarjeta de solo consulta: 403 |
| Dato | ¿sobre qué cuenta? | el claim `cuentaId` contra la ruta, en el servicio | token de la cuenta 116 pidiendo la 105: 403 `cuenta_ajena` |

Además, el móvil compara `X-Device-Id` con el claim `device_id`, y el cajero exige que el claim
`terminal` esté registrado (`terminal_no_registrado`).

### Política de intentos

Tres fallos seguidos bloquean 15 minutos: la clave de un usuario (web y móvil) y el PIN de una
tarjeta. El bloqueo se decide **antes** de comparar la clave, bajo un candado por usuario, así que
el cuarto intento con la clave correcta tampoco entra. Responde igual que una clave incorrecta. Los
bloqueos se publican como eventos de seguridad.

### TLS y secretos

- Los tres BFF y el auth-server sirven HTTPS (TLS 1.3 y 1.2), cada uno con **su propio certificado**
  firmado por la CA interna `Banco XYZ CA interna` (`CN=bff-web`, `CN=bff-mobile`, `CN=bff-atm`),
  verificado en `evidencias/salidas/40-no-regresion-s5.txt`.
- Los tramos internos (BFF al core, consumidores, config, Eureka) van por HTTP dentro de la red
  `interna`, que no es alcanzable desde el host. Es una limitación declarada; en producción serían
  TLS mutuo.
- Ningún secreto está en git ni dentro de las imágenes. `secretos-init` genera, al primer arranque,
  la CA, los keystores, la clave de firma del auth-server, los secretos de cliente y las
  contraseñas de las bases, en un volumen por servicio que cada uno monta solo para sí. Se
  comprueba de cuatro formas (historial de capas, variables de entorno de la imagen, sistema de
  archivos y dentro de cada `.jar`) en `evidencias/salidas/11-imagenes-f8.txt`, y al revés: los
  valores secretos reales no aparecen en ninguna evidencia (`79-entrega.txt`).
- Precisión sobre los secretos de cliente: el archivo de cada secreto en el volumen del auth-server
  (modo 0400, dueño 10001) contiene el valor en claro; el hash BCrypt solo existe en memoria del
  servidor. La clave privada de firma vive en el mismo volumen, por lo que un hash en disco no
  sumaría protección real.
- El documento de descubrimiento OIDC lista capacidades por defecto de Spring Authorization Server
  (por ejemplo `device_code` o `token-exchange`) que **ningún cliente registrado tiene**: cada
  cliente de servicio solo puede `client_credentials`. Intentar otra cosa da `unauthorized_client`
  o `invalid_grant`.

### Guardas de seguridad que no se apagan en silencio

- El `core-service` **no arranca** si no exige la audiencia `core-service` (`GuardaAudienciaCore`): Spring Boot solo agrega el
  validador de audiencia cuando esa propiedad tiene valor, y sin él el core aceptaría tokens firmados y vigentes de cualquier otro
  servicio. Una prueba lee el `config-repo/core-service.yml` real.
- Un cliente que no usa `authorization_code` (por ejemplo `bff-web`) que llame a `/oauth2/authorize` recibe 400 `unauthorized_client`, sin
  redirección aunque traiga una `redirect_uri` propia. Antes recibía un 500 con una traza completa en el registro.
- La página de login lleva una `Content-Security-Policy` restrictiva (`default-src 'none'`, solo estilos en línea, sin `<base>`, sin
  incrustarse en un marco). No lleva `form-action` a propósito: Chrome lo aplica también a la redirección posterior al login hacia la
  `redirect_uri` de la aplicación y bloquearía el último paso del flujo.

### Una nota sobre "Spring Cloud Security"

La descripción de la actividad nombra Spring Cloud Security. El artefacto
`spring-cloud-starter-security` publicó su última versión (2.2.5) en 2021 y no forma parte de los
trenes actuales de Spring Cloud. Hoy esa función la cumplen **Spring Security OAuth2 Resource
Server y Client** y **Spring Authorization Server**, que es lo que recomienda la propia guía de
aprendizaje y lo que usa este proyecto.

---

## Resiliencia

### Dónde hay Resilience4j

| Llamada | Mecanismos | Respaldo si falla |
|---|---|---|
| BFF a `core-service` (los tres) | Retry, CircuitBreaker, Bulkhead | Web y móvil: último dato conocido marcado como desactualizado. Cajero: 503 con pantalla `E-090`, **falla cerrado** |
| BFF a `auth-server` (token de servicio) | Retry, CircuitBreaker | Sigue con el token vigente; si venció, 503 controlado (en web, el último dato) |
| `bff-web` a `auditoria-service` | Retry, CircuitBreaker, Bulkhead (10) | El panel del ejecutivo sale sin la sección de actividad y lo avisa |
| Relay del core a Kafka | CircuitBreaker, Retry | El evento queda en la tabla `outbox` hasta que Kafka vuelva |
| `auth-server` a Kafka (eventos de seguridad) | CircuitBreaker, Retry sobre una cola en memoria | El evento espera en la cola; el login nunca espera a Kafka |
| `notificaciones-service` a la pasarela simulada | CircuitBreaker, Retry, Bulkhead (10) | Reintento por tópico y luego DLT |

El `core-service` y el `auth-server` no llaman a otros servicios por red, salvo Kafka, que sí está
protegido (relay del core y cola de eventos de seguridad). La base de datos del core se maneja con
el pool de conexiones (`connection-timeout` de 5 s). Los BFF, que son quienes llaman a dependencias
remotas, llevan los tres mecanismos. No hay un escenario de caos con PostgreSQL detenido; es una
limitación declarada.

### Valores del llamado BFF a core y su razón

Configuración en `config-repo/application-bff.yml` (común) y `config-repo/bff-*.yml` (por canal).

| Parámetro | Valor | Razón (medida en la fase F6) |
|---|---|---|
| Timeout de conexión | 500 ms | Conectar a una réplica viva tarda menos de 5 ms; a una réplica muerta la conexión espera hasta el límite. Con 1 s cada petición que caía en la muerta tardaba ~1,2 s y contaba como lenta |
| Timeout de lectura | 2 s por intento | Lo normal son 7 a 60 ms. Se usa el timeout del cliente HTTP porque el `TimeLimiter` solo cancela llamadas asíncronas |
| Retry | 3 intentos, espera 200 ms con factor 2 y azar de 50 %, solo errores de infraestructura | Con 2 intentos una petición agotó sus reintentos cuando Eureka reordenó la lista; con 3 no |
| Qué se reintenta | Todo GET, y el retiro **solo** con su `Idempotency-Key` | Reintentar una operación que cambia estado duplica su efecto; con la clave, el core devuelve el mismo folio |
| CircuitBreaker | ventana de 10 llamadas, mínimo 5; abre con 70 % de fallos o 50 % de lentas (más de 1 s) | Con 50 % de umbral una sola réplica muerta abría el circuito aunque cada petición se salvara con el reintento |
| Espera en OPEN | 10 s, paso automático a HALF_OPEN con 3 llamadas de prueba | Permite ver HALF_OPEN sin esperar una petición; una sola llamada podría cerrar el circuito por casualidad |
| Bulkhead | 20 llamadas simultáneas en web y móvil, 5 en el cajero, espera 0 | El cajero es un parque finito de terminales y su dependencia es la más sensible |
| Respaldo web y móvil | último dato de menos de 10 minutos, hasta 500 entradas | Más viejo que eso es mejor un 503 honesto que un saldo de hace una hora |
| Reintentos del balanceador | desactivados | Con `spring-retry` en el classpath reintentaba cada GET por su cuenta: una petición tardó 12,6 s en vez de 6,5 s |

El detalle completo de cada valor, con las salidas, está en `planificacion/bitacora/F6.md`
(sección 3 de la parte 6b).

### Cómo se ve cada mecanismo funcionando

| Escenario (script) | Qué demuestra | Evidencia |
|---|---|---|
| `scripts/caos/core-caido.sh` | Las dos réplicas del core caen: el circuito de los tres BFF pasa por CLOSED, OPEN, HALF_OPEN y CLOSED. Web y móvil sirven el último dato marcado como desactualizado (12 de 12); el cajero responde 503 sin saldo y sin folio | `50-resiliencia-core-caido.txt`, 34 comprobaciones |
| `scripts/caos/core-lento.sh` | Con latencia inyectada el circuito abre **por llamadas lentas**, con cero errores | `51-resiliencia-core-lento.txt`, 22 |
| `scripts/caos/rafaga-bulkhead.sh` | Ráfaga simultánea: el cajero atiende 5 de 5 y rechaza 15 al instante; web atiende 20 y responde 40 con respaldo; el circuito sigue CLOSED (rechazar no es fallar) | `52-resiliencia-rafaga-mamparo.txt`, 25 |
| `scripts/caos/replica-muere.sh` | Una réplica del core muere durante 100 peticiones: 100 de 100 con 200 y dato fresco; el Retry rescató 36 en web y 36 en el cajero | `53-resiliencia-replica-muere.txt`, 16 |
| `scripts/caos/auth-server-caido.sh` | El auth-server cae: los BFF siguen con el token vigente, intentan renovarlo en sus últimos 30 s y vencido responden de forma controlada, nunca 500 | `54-resiliencia-auth-server-caido.txt`, 18 |
| `scripts/caos/reinicio-automatico.sh` | `restart: unless-stopped` reinicia un contenedor cuyo proceso termina solo (`docker exec <c> kill 1`) y el servicio vuelve a Eureka; `docker kill` no lo activa | `22-compose-reinicio-automatico.txt`, 5 |
| Parte de `verificar-f7.sh` | Con Kafka detenido los retiros siguen y el outbox acumula; con auditoría detenida el panel responde 200 sin esa sección | `60-kafka-eventos-f7.txt`, 73 |

**Por qué el cajero falla cerrado.** Entrega dinero físico: un saldo de hace un minuto es dinero que
ya no existe, y un retiro simulado con el core caído es una entrega sin registro. Por eso no tiene
respaldo, responde 503 y cada retiro viaja con su `Idempotency-Key`.

**Consecuencia deliberada del Bulkhead sobre la lista de no regresión.** En el S5, diez retiros
simultáneos dejaban 5 éxitos y 5 rechazos por saldo (409). Con el mamparo del cajero en 5, los
rechazos son una mezcla de 409 y 503 (estos últimos no llegaron al core). El invariante se mantiene:
5 éxitos y saldo final 0 (`40-no-regresion-s5.txt`, sección 23).

### Herramienta de demostración dentro de la imagen

`caos.latencia-ms` (0 por defecto, en `config-repo/core-service.yml`) inyecta latencia en el core
para los escenarios de caos. Es una herramienta de demostración que viaja en la imagen; solo se
activa editando la configuración y ejecutando `POST /actuator/refresh` en el puerto de gestión, que
no se publica.

---

## Eventos con Kafka

El contrato (sobre, tipos de evento, garantías, reintentos, DLT, compatibilidad), el diagrama de la
arquitectura de eventos y la tabla de escalado están en [`docs/eventos.md`](docs/eventos.md). Resumen:

| Pieza | Decisión |
|---|---|
| Broker | `apache/kafka:3.9.1` en modo KRaft, un nodo, solo en la red interna. No se copió el compose de la guía (ver [Decisiones](#decisiones-de-diseño), D5) |
| Tópicos | `bancoxyz.retiros.v1` (clave: la cuenta) y `bancoxyz.seguridad.v1` (clave: usuario o tarjeta enmascarada), 3 particiones cada uno, declarados por `kafka-init` (el broker no crea tópicos solo) |
| Productor del core | **Outbox**: el evento se escribe en la tabla `outbox` en la misma transacción que el descuento; un relay con **líder único** (lock consultivo de PostgreSQL) lo publica con `acks=all`, idempotencia, compresión `lz4` y lotes |
| Garantía | Al menos una vez, con orden por cuenta; los consumidores son idempotentes por `eventId` |
| Consumidores | `notificaciones` (2 réplicas) y `auditoria` (1): cada grupo recibe todos los eventos; reintentos no bloqueantes (`@RetryableTopic`, 5 intentos, espera de 2 a 16 s) y DLT por grupo |
| Eventos de seguridad | `LOGIN_FALLIDO`, `USUARIO_BLOQUEADO`, `PIN_INCORRECTO`, `TARJETA_BLOQUEADA`, sin claves, PIN ni número de tarjeta completo |

**Qué se demostró** (`evidencias/salidas/60-kafka-eventos-f7.txt`, 73 comprobaciones): un retiro
llega a los dos grupos; un reintento con la misma clave no produce un segundo evento; con Kafka
detenido los 5 retiros responden 200, sus 5 eventos esperan en el outbox y se entregan al volver, sin
duplicados; un mensaje inválido va directo a la DLT sin bloquear la partición; con la pasarela caída
el evento pasa por un tópico de reintento y luego a la DLT; la API de auditoría rechaza sin token
(401), sin el scope (403) y con otra audiencia (401).

**Escalado medido** (`evidencias/salidas/61-kafka-escalado.txt`): el mismo lote de 900 eventos, con
una pasarela simulada de 20 ms por evento.

| Consumidores | Procesamiento del lote (ms) | Promedio (ms) | Eventos por segundo | Aceleración | Ociosos |
|---|---|---|---|---|---|
| 1 | 21021 / 20508 | 20764 | 43,3 | 1,00 | 0 |
| 3 | 6917 / 6932 | 6924 | 130,0 | 3,00 | 0 |
| 4 | 6856 / 6350 | 6603 | 136,3 | 3,14 | 1 |

Con 3 consumidores el tiempo baja a un tercio. Con 4, el cuarto queda con 0 particiones (ocioso) y el
tiempo no mejora de forma significativa (6603 ms contra 6924 ms con 3, una diferencia que está dentro del
ruido): un tópico de 3 particiones no se reparte entre más de 3 consumidores, y por eso las
particiones fijan el techo de escalado. Con solo 2 repeticiones por fila, las cifras de tiempo varían
del orden del 8 % entre corridas (la aceleración con 3 consumidores fue 2,87, 2,88, 2,93, 3,00 y 3,02 en
corridas distintas del mismo guion, y con 4 llegó a 3,14: pasar de 3,00 es ruido, no ganancia real).
Además el costo por evento es simulado (un `sleep` de 20 ms), no trabajo real.

Con **dos** réplicas de notificaciones el reparto es 4 y 2 particiones y no 3 y 3: el asignador por
defecto (Range) entrega 2 de cada tópico a la primera réplica y 1 de cada uno a la segunda
(`77-ms-notificaciones-service.txt`). Con 3 réplicas queda 2, 2 y 2.

---

## Despliegue

### Imágenes

Una imagen por microservicio, construida en **dos etapas** con BuildKit: una etapa de compilación
con Maven y caché de dependencias, y una imagen final que solo lleva el JRE (sin Maven, JDK ni git).
El jar se extrae en capas (`jarmode=tools`), de modo que un cambio en el código no invalida las
capas de dependencias. Usuario no root (UID 10001), `HEALTHCHECK` contra el puerto de gestión y
memoria relativa al límite del contenedor (`-XX:MaxRAMPercentage=75`). Las imágenes base llevan
**versión exacta** (por ejemplo `eclipse-temurin:21.0.12.1_1-jre-alpine-3.24` y
`postgres:16.15-alpine3.24`) y las seis bases publican `linux/amd64` y `linux/arm64`, así que corren
también en Apple Silicon.

La excepción única al "todo corre como 10001" es la tarea `secretos-init`, que corre como root
unos segundos porque debe dejar cada volumen de secretos con el dueño de su servicio (10001, y 70
para PostgreSQL) y solo root puede cambiar dueños. Está acotada: `cap_drop: ALL` salvo `CHOWN`,
`DAC_OVERRIDE` y `FOWNER`, sin red, sistema de archivos de solo lectura y 512 MiB. Se declara y se
comprueba (`11-imagenes-f8.txt`).

La caché de dependencias de Maven es un montaje de BuildKit compartido por todas las construcciones con `sharing=locked`: como
`docker compose up --build` construye las imágenes en paralelo y Maven solo se protege de escrituras simultáneas dentro de su
propio proceso, el modo `locked` hace que cada compilación espere su turno en vez de arriesgar un jar a medias en una caché
vacía. El `COPY . .` de la etapa de compilación invalida esa capa ante cualquier cambio del repositorio (la caché de dependencias
evita volver a bajarlas, pero Maven vuelve a compilar).

El primer renglón de cada `Dockerfile` es `# syntax=docker/dockerfile:1`, y el paso de compilación
incluye un gancho opcional (secretos `maven-settings` y `proxy-truststore`) que permite compilar
detrás de un proxy corporativo con CA propia sin modificar el archivo. Si no se entregan esos
secretos, compila directo contra Internet.

### Tamaño, arranque y memoria (medidos)

Del archivo `evidencias/salidas/12-tabla-despliegue.txt`, en una máquina de 4 CPU. Sirven para
comparar servicios entre sí, no son una garantía: entre corridas varían del orden del 10 al 20 %.

| Servicio | Disco (MB) | Capas | Réplicas | Arranque de la app (s) | Memoria en reposo por réplica (MiB) | Límite (MiB) |
|---|---:|---:|---:|---:|---:|---:|
| config-server | 367 | 11 | 1 | 7,0 | 151 | 512 |
| eureka-server | 393 | 11 | 1 | 9,0 | 189 | 512 |
| auth-server | 435 | 11 | 1 | 11,1 | 220 | 768 |
| core-service | 436 | 11 | 2 | 17,6 | 225 | 768 |
| bff-web | 397 | 11 | 1 | 13,1 | 218 | 768 |
| bff-mobile | 397 | 11 | 1 | 13,2 | 215 | 768 |
| bff-atm | 395 | 11 | 1 | 12,4 | 210 | 768 |
| notificaciones-service | 428 | 11 | 2 | 19,3 | 241 | 768 |
| auditoria-service | 430 | 11 | 1 | 16,0 | 226 | 768 |
| postgres | 420 | 11 | 1 | n/a | 82 | 512 |
| kafka | 563 | 10 | 1 | n/a | 362 | 1024 |
| kafka-ui | 637 | 7 | 1 | 14,4 | 242 | 768 |

Memoria total en reposo: 3044 MiB. Tiempo desde `docker compose up -d` hasta que todo está listo:
66 s (con las imágenes ya construidas). Los contenedores tienen `mem_limit`, `cpus` y `pids_limit`;
ninguno fue terminado por falta de memoria tras toda la verificación
(`evidencias/salidas/13-limites-tras-la-carga.txt`). Los límites además aceleran el arranque en la
máquina de pruebas (la JVM sin límite dimensiona su heap para toda la máquina); el detalle y la
medición están en `planificacion/bitacora/F8-F9.md`.

### Compose

`docker-compose.yaml` (sin la clave `version`, que es obsoleta en Compose v2; nombre del proyecto
`bancoxyz`) declara: las redes `borde` e `interna`; un volumen de secretos por servicio, más
`postgres-datos` y `kafka-datos`; `depends_on` con `service_healthy` y
`service_completed_successfully`; `restart: unless-stopped`; `cap_drop: ALL`, `no-new-privileges`
y sistema de archivos de solo lectura en los servicios de larga vida; rotación de logs; y
`docker compose config` sin advertencias (`11-imagenes-f8.txt`). El `core-service` y
`notificaciones-service` usan `deploy.replicas: 2`: es el **escalado horizontal** y Eureka con el
balanceador reparte la carga entre réplicas (`21-compose-postgres-replicas-f3.txt`: 10 y 10
peticiones).

### Datos y respaldo

El estado del core vive en PostgreSQL con Flyway y sobrevive a los reinicios. `docker compose down
-v` lo borra. Cada base (`core`, `auditoria`, `notificaciones`) tiene su propio usuario y ninguno
puede leer las otras. Para copias de seguridad hay un guion manual, `scripts/respaldar-postgres.sh`
(ver [Limitaciones](#limitaciones-conocidas): no es un respaldo programado).

---

## Pruebas y verificación

### Pruebas unitarias y de integración

`./mvnw -B verify` ejecuta **610 pruebas** en 11 módulos, todas verdes, con 0 fallas, 0 errores y 0
omitidas (`evidencias/salidas/00-pruebas-unitarias.txt`). Las del core y los consumidores usan
PostgreSQL y Kafka reales con Testcontainers, por lo que necesitan Docker en marcha.

| Módulo | Pruebas |
|---|---:|
| `eventos-contrato` | 16 |
| `plataforma-comun` | 45 |
| `config-server` | 26 |
| `eureka-server` | 2 |
| `auth-server` | 117 |
| `core-service` | 161 |
| `notificaciones-service` | 18 |
| `auditoria-service` | 30 |
| `bff-web` | 71 |
| `bff-mobile` | 61 |
| `bff-atm` | 63 |

### Verificación del sistema en ejecución

`scripts/verificar.sh` levanta el sistema, ejecuta los guiones de F2 a F8 y los seis escenarios de
caos, y escribe 31 archivos en `evidencias/salidas/` (cabecera con el comando exacto, fecha y
entorno; salida literal; código de salida). El resumen termina con código 0 solo si todo pasó.
Cada archivo cierra con su línea `RESULTADO` (`79-entrega.txt`, el criterio 6, es el que comprueba este mismo README y por eso no
lista su cifra aquí):

| Archivo | Comprobaciones | Archivo | Comprobaciones |
|---|---:|---|---:|
| `10-imagenes-f2` | 166 | `50-resiliencia-core-caido` | 34 |
| `11-imagenes-f8` | 109 | `51-resiliencia-core-lento` | 22 |
| `20-compose-config-eureka-f1` | 62 | `52-resiliencia-rafaga-mamparo` | 25 |
| `21-compose-postgres-replicas-f3` | 91 | `53-resiliencia-replica-muere` | 16 |
| `22-compose-reinicio-automatico` | 5 | `54-resiliencia-auth-server-caido` | 18 |
| `30-oauth2-servidor-recursos-f4` | 85 | `60-kafka-eventos-f7` | 73 |
| `31-oauth2-login-usuarios-f5` | 38 | `61-kafka-escalado` | 2 |
| `32-oauth2-matriz-3x3` | 9 | `00-pruebas-unitarias` | pruebas: 610 (ver arriba) |
| `40-no-regresion-s5` | 60 | `70` a `78-ms-*` (9 microservicios) | 7, 9, 12, 16, 11, 10, 12, 15, 10 |

Cada microservicio tiene su evidencia de **arranque, salud y resultado** (`70-ms-config-server.txt`
a `78-ms-auditoria-service.txt`), como pide la actividad. Capturas con Chromium sin interfaz en
`evidencias/capturas/` (dashboard de Eureka, Kafka UI con tópicos y con grupos, y la página de login
del auth-server).

Las cifras de tiempo y memoria cambian entre corridas; los conteos de comprobaciones y los PASS no
(salvo uno o dos en `21-...`, que dependen de cuántos retiros simultáneos llegan al core antes de que
el mamparo del cajero rechace el resto; está dicho en el índice). `evidencias/INDICE.md` mapea cada
archivo a su criterio y puntaje.

---

## Trazabilidad con la pauta de evaluación

| # | Criterio (puntos) | Qué se hizo | Dónde en este README | Evidencia |
|---|---|---|---|---|
| 1 | OAuth 2.0 (20) | Servidor de autorización único (Spring Authorization Server); `client_credentials` entre servicios con scopes mínimos; `authorization_code` + PKCE para web y móvil; grant tarjeta y PIN para el cajero; validación de firma, emisor, vigencia y audiencia en todos los servicios | [Seguridad](#seguridad) | `30-oauth2-servidor-recursos-f4`, `31-oauth2-login-usuarios-f5`, `32-oauth2-matriz-3x3`, `40-no-regresion-s5`, `72-ms-auth-server`, `capturas/04-login-auth-server.png` |
| 2 | Imágenes Docker (20) | Una imagen por cada uno de los 9 microservicios, dos etapas, capas, usuario no root, healthcheck, sin secretos, versión exacta, multiarquitectura, tabla medida | [Despliegue](#despliegue) | `10-imagenes-f2`, `11-imagenes-f8`, `12-tabla-despliegue`, `13-limites-tras-la-carga` |
| 3 | docker-compose.yaml (20) | Orquesta los 16 contenedores con redes, volúmenes, healthchecks, `depends_on`, reinicio automático, dos réplicas del core y de notificaciones, límites de recursos | [Despliegue](#despliegue) | `01-arranque`, `20-compose-config-eureka-f1`, `21-compose-postgres-replicas-f3`, `22-compose-reinicio-automatico`, `61-kafka-escalado`, `capturas/01-eureka-dashboard.png` |
| 4 | Resilience4j (20) | Retry, CircuitBreaker y Bulkhead en los tres BFF y en los demás servicios que llaman a una dependencia remota, con respaldo por canal; seis escenarios de caos con números | [Resiliencia](#resiliencia) | `50` a `54-resiliencia-*`, `60-kafka-eventos-f7` |
| 5 | Kafka (15) | Outbox con relay de líder único, dos tópicos de 3 particiones, dos grupos de consumidores idempotentes con reintentos no bloqueantes y DLT, escalado medido | [Eventos con Kafka](#eventos-con-kafka) | `60-kafka-eventos-f7`, `61-kafka-escalado`, `77-ms-notificaciones-service`, `78-ms-auditoria-service`, `capturas/02` y `03` |
| 6 | Entrega (5) | Código en el repositorio, este README, la propuesta técnica, el contrato de eventos y las evidencias por microservicio, todo en una carpeta comprimida con `scripts/empaquetar-entrega.sh` | [Estructura](#estructura-del-código), [Documentación](#documentación-del-repositorio) | `79-entrega`, `00-pruebas-unitarias`, `INDICE.md` |
| RN | No regresión del S5 | Las doce comprobaciones de la lista siguen pasando | [Objetivo](#objetivo) | `40-no-regresion-s5` (60 comprobaciones) |

---

## Decisiones de diseño

Las decisiones D1 a D12 del plan maestro (`planificacion/PLAN_NOTA_MAXIMA.md`), con su razón.

| # | Decisión | Razón |
|---|---|---|
| D1 | Spring Boot 3.3.13, Spring Cloud 2023.0.6 y Resilience4j 2.2.0 | La base del S5 ya funciona en 3.3 y la pauta no evalúa versiones; migrar a Boot 4 (Jackson 3, Spring Security 7) arriesga regresiones sin dar puntos. El soporte OSS de Boot 3.3 terminó el 30-06-2025: se declara como limitación |
| D2 | Un solo emisor de tokens (`auth-server`) y ningún BFF firma | La matriz 3x3 sobrevive por la audiencia; mínimo privilegio entre servicios; el cajero usa un grant de extensión porque no tiene navegador y la política de PIN pasa al servidor de autorización |
| D3 | CA interna y emisor fijo `https://localhost:9000`, con JWKS por la dirección interna | Evita la trampa de Docker en que el token dice un emisor y el servicio espera otro. Con `certs/ca.crt` el evaluador usa `--cacert` en vez de `-k` |
| D4 | PostgreSQL 16, una base y un usuario por servicio, Flyway, carga inicial como migración Java | El estado en memoria no sirve en contenedores con réplicas. Se descartó un job de Spring Batch dedicado: un componente más que puede fallar, sin puntos |
| D5 | Kafka oficial en modo KRaft, no el compose de la guía | `wurstmeister/kafka` y `wurstmeister/zookeeper` se actualizaron por última vez en 2022 y 2019; Kafka 4.0 eliminó ZooKeeper; `version:` es obsoleta en Compose v2. Se eligió Kafka y no JMS porque lo "escalable" se demuestra con particiones y grupos |
| D6 | Resilience4j llamada por llamada, con respaldo por canal | Cada dependencia falla distinto; el cajero falla cerrado. Valores finales y razones en la sección Resiliencia |
| D7 | Secretos generados al primer arranque por `secretos-init`, un volumen por servicio | Nada secreto en git ni en las imágenes; cada servicio monta solo lo suyo |
| D8 | Config Server con backend nativo sobre `config-repo/` montado | Un cambio ahí se aplica con `POST /actuator/refresh`, sin reconstruir imágenes |
| D9 | Sin API Gateway | Cada BFF ya es la puerta de su canal |
| D10 | El archivo se llama `docker-compose.yaml` y no lleva `version` | Es el nombre que escribe la pauta |
| D11 | Puerto de gestión separado, HTTP y no publicado | Los healthchecks no dependen de TLS ni exponen nada al host; nunca se publican `env`, `configprops` ni `heapdump` |
| D12 | Spring Cloud Security se reemplaza por Spring Security OAuth2 y Spring Authorization Server | `spring-cloud-starter-security` quedó en 2.2.5 (2021) y no está en los trenes actuales; es además lo que recomienda la guía |

Otras decisiones que conviene conocer: el core **no** es un BFF (es el dominio, y a él se habla por
HTTP interno con token de servicio); los BFF comparten mecanismo pero no política; la optimización
se decide midiendo (el cajero no comprime ni cachea a propósito; web comprime y cachea 60 s; móvil
usa `ETag` y caché de 30 s: en `40-no-regresion-s5.txt`, el mismo dato pesa 4669 bytes desde el
core, 1973 en web, 368 en móvil y 43 en cajero); la idempotencia del retiro vive en el core porque
es lo único que existe una sola vez.

---

## Limitaciones conocidas

Lo que este proyecto **no** hace o no puede demostrar, dicho sin rodeos.

**Alcance de la verificación**
- **Windows y macOS con Docker Desktop no se probaron en el entorno de desarrollo** (Linux con
  Docker Engine). Sí se comprobó lo que se puede sin ellos: los scripts con el `bash` 3.2.57 que
  trae macOS, un clon con `core.autocrlf=true` y rutas relativas. Los tiempos son de una máquina de
  4 CPU.
- `scripts/verificar-f8.sh` (sección 5) y las construcciones necesitan Internet; un 429 de Docker
  Hub puede dar FAIL sin ser un fallo del sistema.

**Seguridad**
- El puerto de gestión (8081) escucha en todas las interfaces **dentro** del contenedor y su `refresh` y sus métricas no piden
  credencial: lo protege no publicarse al host, pero cualquier contenedor de la red `interna` podría llamarlo.
- En un anfitrión Linux, la IP de un contenedor de la red `interna` responde desde el propio equipo (ver Arquitectura).
- La subred de la red `interna` es fija (172.31.250.0/24): puede chocar con una VPN o una red del equipo (ver el diagnóstico).
- El flujo con JVM locales (`scripts/levantar-local.sh`, para quien no use Docker) usa una contraseña de keystore de demostración
  (`cambiar-en-produccion`) si no se define la variable; el camino por Docker genera contraseñas aleatorias.
- Los tramos internos van por HTTP dentro de la red `interna` (sin TLS mutuo).
- El bloqueo de clave o PIN y las bajas de dispositivo viven en memoria: se pierden al reiniciar el
  servicio. La baja de dispositivo móvil no prueba posesión (el `device_id` lo elige el cliente al
  pedir el código; quien conoce la clave puede pedir un token con otro dispositivo).
- Con tres intentos se distingue una tarjeta que existe (responde `pin_bloqueado` al tercero) de una
  inexistente (siempre `credenciales_invalidas`).
- Spring Boot 3.3 ya no tiene soporte OSS (D1).
- `secretos-init` corre como root (ver Despliegue).
- Ante un 401 persistente del core (por ejemplo, emisor o audiencia mal configurados), cada llamada de un BFF descarta su
  token de servicio y pide uno nuevo al auth-server, con el costo de BCrypt de ese servidor. Está medido como patrón, no limitado
  con una tasa.
- Con el auth-server caído y el token de servicio dentro de sus últimos 30 s de vida, cada petición deja un aviso (WARN) de que no
  pudo renovarlo: es ruido de registro, no un fallo (en la evidencia, 12 avisos en el escenario).
- `kafka-ui` no tiene autenticación y está en la red `borde` además de la `interna`; el puerto solo
  se publica en `127.0.0.1`.

**Datos y operación**
- PostgreSQL y Kafka son de un solo nodo: no hay alta disponibilidad. El respaldo es un guion manual
  (`scripts/respaldar-postgres.sh`), no un respaldo programado.
- La migración `V2` reutiliza clases del código vivo (`IngestaDataset`, `ReglaConsolidacion`,
  `ParserFechas`); su reproducibilidad vale mientras no cambien, y la cubre `IngestaDatasetTest`.
- La entrega de eventos es "al menos una vez". Si un lote falla a medias, un evento posterior de la
  misma cuenta puede quedar por delante de uno anterior en el log (`docs/eventos.md`, sección 4.1).
- El `auth-server` no tiene base de datos: sus eventos de seguridad esperan en una cola en memoria y
  se pierden si el proceso muere durante una caída larga de Kafka.
- El contrato valida el sobre; los campos de `datos` los exige cada consumidor (notificaciones los
  valida; auditoría guarda lo que llega).
- Resilience4j protege las llamadas a dependencias remotas (core, token, auditoría, Kafka,
  pasarela); no hay un escenario de PostgreSQL detenido.
- El escalado se midió con un costo simulado por evento (20 ms) y solo 2 repeticiones por fila.

**Entorno de la demostración**
- La tabla de despliegue y los tiempos de los escenarios son de una corrida concreta.
- El Eureka muestra un aviso de emergencia el primer minuto (autopreservación).
- Un `docker kill` no activa el reinicio automático (Docker lo toma por una orden manual); sí lo
  activa un proceso que termina solo.

---

## Documentación del repositorio

| Documento | Para qué |
|---|---|
| [`docs/propuesta-tecnica.md`](docs/propuesta-tecnica.md) | Problema, propuesta, arquitectura, decisiones y alternativas, riesgos y alcance |
| [`docs/eventos.md`](docs/eventos.md) | Contrato de los eventos, garantías, diagrama y tabla de escalado |
| [`docs/guia-de-estudio.md`](docs/guia-de-estudio.md) | Preguntas y respuestas para explicar cada decisión |
| [`evidencias/INDICE.md`](evidencias/INDICE.md) | Qué demuestra cada archivo de evidencia y a qué criterio responde |
| `planificacion/PLAN_NOTA_MAXIMA.md` | Plan maestro: decisiones D1 a D12, lista de no regresión y reglas |
| `planificacion/bitacora/F0.md` a `F10.md` | Una bitácora por fase: qué se hizo, por qué, cómo verificarlo y salidas reales |
| `CLAUDE.md` | Convenciones del proyecto y lista completa de scripts |

El S5 original (código, plan, guías y evidencia) se consulta con `git show dd2e301:<ruta>`; por
ejemplo, `git show dd2e301:README.md`. Las menciones a la cabecera fija del S5 que quedan en
`planificacion/` son historia de las fases anteriores: en el código, los scripts y la configuración
ya no existe.

El proyecto no usa CI/CD: la verificación es local, con `scripts/verificar.sh`.
