package cl.duoc.bancoxyz.notificaciones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.testcontainers.containers.PostgreSQLContainer;

/**
 * Un PostgreSQL 16 REAL (Testcontainers) compartido por las pruebas del modulo, con una base nueva para cada
 * contexto de Spring (asi ninguna prueba ve los datos de otra). El esquema lo crea Flyway al arrancar la
 * aplicacion, exactamente como en produccion.
 */
public final class PostgresDePrueba {

    private static final PostgreSQLContainer<?> CONTENEDOR = new PostgreSQLContainer<>("postgres:16.15-alpine3.24");
    private static final AtomicInteger CONTADOR = new AtomicInteger();

    static {
        CONTENEDOR.start();
        Runtime.getRuntime().addShutdownHook(new Thread(CONTENEDOR::stop));
    }

    private PostgresDePrueba() {
    }

    /** Crea una base vacia y devuelve su URL JDBC. */
    public static String nuevaBase() {
        String nombre = "notificaciones_prueba_" + CONTADOR.incrementAndGet();
        try (Connection conexion = DriverManager.getConnection(
                CONTENEDOR.getJdbcUrl(), CONTENEDOR.getUsername(), CONTENEDOR.getPassword());
             Statement sentencia = conexion.createStatement()) {
            sentencia.execute("CREATE DATABASE " + nombre);
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo crear la base " + nombre, e);
        }
        return CONTENEDOR.getJdbcUrl().replaceFirst("/[^/?]+(\\?|$)", "/" + nombre + "$1");
    }

    public static String usuario() {
        return CONTENEDOR.getUsername();
    }

    public static String clave() {
        return CONTENEDOR.getPassword();
    }

    /** Apunta {@code spring.datasource.*} de un contexto de Spring a una base nueva. */
    public static class Inicializador implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext contexto) {
            TestPropertyValues.of(
                    "spring.datasource.url=" + nuevaBase(),
                    "spring.datasource.username=" + usuario(),
                    "spring.datasource.password=" + clave()).applyTo(contexto);
        }
    }
}
