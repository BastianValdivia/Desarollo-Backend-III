package cl.duoc.bancoxyz.notificaciones;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.EventoInvalidoException;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.notificaciones.aplicacion.ComponedorDeMensajes;
import cl.duoc.bancoxyz.notificaciones.aplicacion.Notificacion;
import cl.duoc.bancoxyz.notificaciones.aplicacion.ProcesadorDeEventos;
import cl.duoc.bancoxyz.notificaciones.aplicacion.ProcesadorDeEventos.Resultado;
import cl.duoc.bancoxyz.notificaciones.pasarela.PasarelaDeEnvio;
import cl.duoc.bancoxyz.notificaciones.pasarela.PasarelaNoDisponibleException;
import cl.duoc.bancoxyz.notificaciones.persistencia.RepositorioNotificaciones;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

/**
 * La IDEMPOTENCIA del consumidor, contra un PostgreSQL real y con la pasarela reemplazada por un doble
 * (sin Spring ni Kafka: lo que se prueba es la logica de procesar un evento).
 */
class ProcesadorDeEventosTest {

    private static HikariDataSource pool;
    private static JdbcClient jdbc;

    private final List<Notificacion> enviadas = Collections.synchronizedList(new ArrayList<>());
    private final AtomicInteger fallosPendientes = new AtomicInteger();
    private final SimpleMeterRegistry metricas = new SimpleMeterRegistry();
    private ProcesadorDeEventos procesador;

    @BeforeAll
    static void preparar() {
        HikariConfig configuracion = new HikariConfig();
        configuracion.setJdbcUrl(PostgresDePrueba.nuevaBase());
        configuracion.setUsername(PostgresDePrueba.usuario());
        configuracion.setPassword(PostgresDePrueba.clave());
        configuracion.setMaximumPoolSize(8);
        pool = new HikariDataSource(configuracion);
        Flyway.configure().dataSource(pool).locations("classpath:db/migration").load().migrate();
        jdbc = JdbcClient.create(pool);
    }

    @AfterAll
    static void cerrar() {
        pool.close();
    }

    @BeforeEach
    void limpiar() {
        jdbc.sql("DELETE FROM notificacion").update();
        jdbc.sql("DELETE FROM evento_procesado").update();
        enviadas.clear();
        fallosPendientes.set(0);
        PasarelaDeEnvio pasarela = notificacion -> {
            if (fallosPendientes.getAndUpdate(n -> n > 0 ? n - 1 : 0) > 0) {
                throw new PasarelaNoDisponibleException("fallo de prueba");
            }
            enviadas.add(notificacion);
        };
        procesador = new ProcesadorDeEventos(new RepositorioNotificaciones(jdbc), new ComponedorDeMensajes(),
                pasarela, new DataSourceTransactionManager(pool), metricas);
    }

    private static long filas(String tabla) {
        return jdbc.sql("SELECT count(*) FROM " + tabla).query(Long.class).single();
    }

    @Test
    @DisplayName("Un retiro se notifica al titular por SMS y queda registrado")
    void procesaUnRetiro() {
        SobreEvento evento = EventosDePrueba.retiro(116);

        Resultado resultado = procesador.procesar(CodecEventos.escribir(evento), "bancoxyz.retiros.v1", 2, 40L);

        assertThat(resultado).isEqualTo(Resultado.PROCESADO);
        assertThat(enviadas).hasSize(1);
        Notificacion enviada = enviadas.get(0);
        assertThat(enviada.canal()).isEqualTo("SMS");
        assertThat(enviada.destinatario()).isEqualTo("titular-cuenta-116");
        assertThat(enviada.mensaje()).contains("$1.000", "cuenta 116", "RET-20261003-116", "$10.000");
        assertThat(jdbc.sql("SELECT estado FROM notificacion WHERE event_id = :id::uuid")
                .param("id", evento.eventId()).query(String.class).single()).isEqualTo("ENVIADA");
        var procesado = jdbc.sql("SELECT topico, particion, desplazamiento FROM evento_procesado").query().singleRow();
        assertThat(procesado.get("topico")).isEqualTo("bancoxyz.retiros.v1");
        assertThat(procesado.get("particion")).isEqualTo(2);
        assertThat(procesado.get("desplazamiento")).isEqualTo(40L);
        assertThat(metricas.counter("notificaciones.procesadas").count()).isEqualTo(1.0);
    }

    @Test
    @DisplayName("Un evento de seguridad se avisa al equipo de seguridad por correo, con la tarjeta enmascarada")
    void procesaUnEventoDeSeguridad() {
        procesador.procesar(CodecEventos.escribir(EventosDePrueba.pinIncorrecto()), "bancoxyz.seguridad.v1", 0, 1L);

        assertThat(enviadas).hasSize(1);
        assertThat(enviadas.get(0).canal()).isEqualTo("EMAIL");
        assertThat(enviadas.get(0).destinatario()).isEqualTo("seguridad@bancoxyz.cl");
        assertThat(enviadas.get(0).mensaje()).contains("400000******0116", "atm-scl-001", "Intentos restantes: 2");
    }

    @Test
    @DisplayName("IDEMPOTENCIA: el mismo evento recibido dos veces se notifica una sola vez")
    void repetidoSeDescarta() {
        String json = EventosDePrueba.retiroJson(116);

        Resultado primero = procesador.procesar(json, "bancoxyz.retiros.v1", 2, 40L);
        Resultado repetido = procesador.procesar(json, "bancoxyz.retiros.v1", 2, 55L);

        assertThat(primero).isEqualTo(Resultado.PROCESADO);
        assertThat(repetido).isEqualTo(Resultado.DUPLICADO);
        assertThat(enviadas).as("no se avisa dos veces").hasSize(1);
        assertThat(filas("notificacion")).isEqualTo(1);
        assertThat(filas("evento_procesado")).isEqualTo(1);
        assertThat(metricas.counter("notificaciones.duplicadas").count()).isEqualTo(1.0);
    }

    @Test
    @DisplayName("IDEMPOTENCIA entre replicas: el mismo evento procesado a la vez por dos hilos se notifica una sola vez")
    void repetidoSimultaneo() throws Exception {
        String json = EventosDePrueba.retiroJson(105);
        int hilos = 6;
        CountDownLatch salida = new CountDownLatch(1);
        ExecutorService piscina = Executors.newFixedThreadPool(hilos);
        try {
            List<Future<Resultado>> futuros = new ArrayList<>();
            for (int i = 0; i < hilos; i++) {
                int desplazamiento = i;
                Callable<Resultado> tarea = () -> {
                    salida.await();
                    return procesador.procesar(json, "bancoxyz.retiros.v1", 0, desplazamiento);
                };
                futuros.add(piscina.submit(tarea));
            }
            salida.countDown();
            List<Resultado> resultados = new ArrayList<>();
            for (Future<Resultado> futuro : futuros) {
                resultados.add(futuro.get(30, TimeUnit.SECONDS));
            }
            assertThat(resultados.stream().filter(r -> r == Resultado.PROCESADO)).hasSize(1);
            assertThat(resultados.stream().filter(r -> r == Resultado.DUPLICADO)).hasSize(hilos - 1);
        } finally {
            piscina.shutdownNow();
        }
        assertThat(enviadas).hasSize(1);
        assertThat(filas("notificacion")).isEqualTo(1);
    }

    @Test
    @DisplayName("Si la pasarela falla, el evento NO queda como procesado: su reintento se envia y no se confunde con un repetido")
    void fallaDeLaPasarelaDeshaceElRegistro() {
        String json = EventosDePrueba.retiroJson(106);
        fallosPendientes.set(1);

        assertThatThrownBy(() -> procesador.procesar(json, "bancoxyz.retiros.v1", 1, 9L))
                .isInstanceOf(PasarelaNoDisponibleException.class);

        assertThat(filas("evento_procesado")).as("se deshizo con la transaccion").isZero();
        assertThat(filas("notificacion")).isZero();
        assertThat(enviadas).isEmpty();

        // El reintento (otra entrega del mismo evento) ahora si se procesa.
        assertThat(procesador.procesar(json, "bancoxyz.retiros.v1-notificaciones-retry-2000", 1, 0L))
                .isEqualTo(Resultado.PROCESADO);
        assertThat(enviadas).hasSize(1);
        assertThat(filas("notificacion")).isEqualTo(1);
    }

    @ParameterizedTest(name = "[{index}] se rechaza como invalido y no deja rastro: {0}")
    @ValueSource(strings = {
            "esto no es json",
            "{\"eventId\":\"no-uuid\"}",
            "{\"eventId\":\"6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11\",\"tipo\":\"RETIRO_EJECUTADO\",\"version\":9,"
                    + "\"ocurridoEn\":\"2026-10-03T12:00:00Z\",\"origen\":\"x\",\"datos\":{}}",
            "{\"eventId\":\"6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11\",\"tipo\":\"RETIRO_EJECUTADO\",\"version\":1,"
                    + "\"ocurridoEn\":\"2026-10-03T12:00:00Z\",\"origen\":\"x\",\"datos\":{\"cuentaId\":1}}"
    })
    void invalidoSeRechaza(String json) {
        assertThatThrownBy(() -> procesador.procesar(json, "bancoxyz.retiros.v1", 0, 0L))
                .isInstanceOf(EventoInvalidoException.class);

        assertThat(filas("evento_procesado")).isZero();
        assertThat(enviadas).isEmpty();
    }
}
