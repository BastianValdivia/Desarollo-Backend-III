package cl.duoc.bancoxyz.notificaciones;

import java.math.BigDecimal;
import java.time.Instant;

import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.DatosRetiro;
import cl.duoc.bancoxyz.eventos.DatosSeguridad;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.TiposEvento;

/** Fabrica de mensajes validos para las pruebas. */
public final class EventosDePrueba {

    private EventosDePrueba() {
    }

    public static SobreEvento retiro(int cuenta) {
        return SobreEvento.nuevo(TiposEvento.RETIRO_EJECUTADO, 1, Instant.parse("2026-10-03T12:00:00Z"),
                "core-service", new DatosRetiro(cuenta, "RET-20261003-" + cuenta, new BigDecimal("1000.00"),
                        new BigDecimal("11000.00"), new BigDecimal("10000.00"), 700L, "CLP"));
    }

    public static String retiroJson(int cuenta) {
        return CodecEventos.escribir(retiro(cuenta));
    }

    public static SobreEvento pinIncorrecto() {
        return SobreEvento.nuevo(TiposEvento.PIN_INCORRECTO, 1, Instant.parse("2026-10-03T12:00:00Z"),
                "auth-server", new DatosSeguridad("400000******0116", "atm-scl-001", "pin_incorrecto", 1, 2, null));
    }
}
