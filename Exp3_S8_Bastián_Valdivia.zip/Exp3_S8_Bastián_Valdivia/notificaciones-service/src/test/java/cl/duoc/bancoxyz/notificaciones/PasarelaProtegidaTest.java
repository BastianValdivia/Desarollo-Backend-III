package cl.duoc.bancoxyz.notificaciones;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.eventos.soporte.KafkaDePrueba;
import cl.duoc.bancoxyz.notificaciones.aplicacion.Notificacion;
import cl.duoc.bancoxyz.notificaciones.pasarela.PasarelaDeEnvio;
import cl.duoc.bancoxyz.notificaciones.pasarela.PasarelaNoDisponibleException;
import io.github.resilience4j.bulkhead.BulkheadFullException;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.RetryRegistry;

/**
 * La proteccion de la pasarela con Resilience4j (Retry, CircuitBreaker y Bulkhead), con la configuracion real
 * de {@code config-repo/notificaciones-service.yml} y la pasarela simulada real, a la que las pruebas le
 * cambian en caliente la latencia y la tasa de fallo (el mismo mecanismo que usa un refresh).
 *
 * <p>El consumidor de Kafka se detiene ({@code auto-startup=false}): aqui solo se prueba la pasarela.
 */
@SpringBootTest(properties = "spring.kafka.listener.auto-startup=false")
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class PasarelaProtegidaTest {

    private static final String FUENTE = "ajustes-de-la-prueba";
    private static final Notificacion AVISO = new Notificacion("RETIRO_EJECUTADO", "SMS", "titular-cuenta-1", "hola");

    @DynamicPropertySource
    static void propiedades(DynamicPropertyRegistry registro) {
        registro.add("spring.kafka.bootstrap-servers", KafkaDePrueba::bootstrap);
    }

    @Autowired
    private PasarelaDeEnvio pasarela;
    @Autowired
    private ConfigurableEnvironment entorno;
    @Autowired
    private CircuitBreakerRegistry circuitos;
    @Autowired
    private RetryRegistry reintentos;

    private void ajustar(Map<String, Object> valores) {
        entorno.getPropertySources().remove(FUENTE);
        entorno.getPropertySources().addFirst(new MapPropertySource(FUENTE, valores));
    }

    @BeforeEach
    @AfterEach
    void restablecer() {
        entorno.getPropertySources().remove(FUENTE);
        circuitos.circuitBreaker("pasarela").reset();
    }

    @Test
    @DisplayName("Sin fallos, la pasarela envia y el circuito sigue cerrado")
    void funcionaNormal() {
        pasarela.enviar(AVISO);

        assertThat(circuitos.circuitBreaker("pasarela").getState()).isEqualTo(CircuitBreaker.State.CLOSED);
    }

    @Test
    @DisplayName("Retry: un fallo pasajero se reintenta dentro de la misma llamada, y el consumidor no se entera")
    void reintentaUnFalloPasajero() {
        // El primer intento falla y los siguientes no: con tasa 1.0 y luego 0.0 no se puede, asi que se
        // simula con una tasa alta y se acepta cualquiera de los resultados siguientes: lo que se verifica es
        // que ante una pasarela que falla siempre la llamada hace EXACTAMENTE 3 intentos antes de rendirse.
        ajustar(Map.of("notificaciones.pasarela.tasa-fallo", 1.0, "notificaciones.pasarela.latencia-ms", 0));
        long antes = reintentos.retry("pasarela").getMetrics().getNumberOfFailedCallsWithRetryAttempt();

        assertThatThrownBy(() -> pasarela.enviar(AVISO)).isInstanceOf(PasarelaNoDisponibleException.class);

        assertThat(reintentos.retry("pasarela").getMetrics().getNumberOfFailedCallsWithRetryAttempt() - antes)
                .as("una llamada que agoto los reintentos").isEqualTo(1);
        // 3 intentos fallidos quedaron anotados en la ventana del circuito.
        assertThat(circuitos.circuitBreaker("pasarela").getMetrics().getNumberOfFailedCalls()).isEqualTo(3);
    }

    @Test
    @DisplayName("CircuitBreaker: con la pasarela caida el circuito se abre y rechaza al instante, sin esperar a la pasarela")
    void elCircuitoSeAbre() {
        ajustar(Map.of("notificaciones.pasarela.tasa-fallo", 1.0, "notificaciones.pasarela.latencia-ms", 0));
        CircuitBreaker circuito = circuitos.circuitBreaker("pasarela");

        // Cada llamada son hasta 3 intentos fallidos; con 5 intentos minimos el circuito abre durante la segunda
        // llamada (en su segundo intento), y el tercer intento ya lo encuentra abierto.
        assertThatThrownBy(() -> pasarela.enviar(AVISO)).isInstanceOf(PasarelaNoDisponibleException.class);
        assertThatThrownBy(() -> pasarela.enviar(AVISO))
                .isInstanceOfAny(PasarelaNoDisponibleException.class, CallNotPermittedException.class);
        assertThat(circuito.getState()).isEqualTo(CircuitBreaker.State.OPEN);

        // Abierto: rechaza sin llamar a la pasarela (aunque ahora estuviera sana).
        ajustar(Map.of("notificaciones.pasarela.tasa-fallo", 0.0, "notificaciones.pasarela.latencia-ms", 0));
        long inicio = System.nanoTime();
        assertThatThrownBy(() -> pasarela.enviar(AVISO)).isInstanceOf(CallNotPermittedException.class);
        assertThat(TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - inicio)).as("rechazo instantaneo").isLessThan(50);
    }

    @Test
    @DisplayName("Una pasarela mas lenta que su plazo se corta con un timeout (D6: 1 s) en vez de colgar al consumidor")
    void timeoutDeLaPasarela() {
        ajustar(Map.of("notificaciones.pasarela.latencia-ms", 5000, "notificaciones.pasarela.timeout-ms", 50,
                "notificaciones.pasarela.tasa-fallo", 0.0));

        long inicio = System.nanoTime();
        assertThatThrownBy(() -> pasarela.enviar(AVISO))
                .isInstanceOf(PasarelaNoDisponibleException.class).hasMessageContaining("timeout");

        assertThat(TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - inicio))
                .as("3 intentos de 50 ms, no 3 de 5 s").isLessThan(2000);
    }

    @Test
    @DisplayName("Bulkhead: con 10 envios simultaneos en curso, el undecimo se rechaza al instante")
    void elMamparoRechazaElExceso() throws Exception {
        // 400 ms: por debajo del umbral de "llamada lenta" del circuito (500 ms); si no, estas llamadas abririan el
        // circuito por lentitud, que es otro comportamiento (y correcto) distinto del que se prueba aqui.
        ajustar(Map.of("notificaciones.pasarela.latencia-ms", 400, "notificaciones.pasarela.timeout-ms", 2000,
                "notificaciones.pasarela.tasa-fallo", 0.0));
        int hilos = 14;
        CountDownLatch salida = new CountDownLatch(1);
        ExecutorService piscina = Executors.newFixedThreadPool(hilos);
        try {
            List<Future<String>> futuros = new ArrayList<>();
            for (int i = 0; i < hilos; i++) {
                Callable<String> tarea = () -> {
                    salida.await();
                    try {
                        pasarela.enviar(AVISO);
                        return "ok";
                    } catch (BulkheadFullException e) {
                        return "mamparo";
                    }
                };
                futuros.add(piscina.submit(tarea));
            }
            salida.countDown();
            int ok = 0;
            int rechazados = 0;
            for (Future<String> futuro : futuros) {
                if ("ok".equals(futuro.get(30, TimeUnit.SECONDS))) {
                    ok++;
                } else {
                    rechazados++;
                }
            }
            assertThat(ok).as("caben 10 a la vez").isEqualTo(10);
            assertThat(rechazados).as("el exceso se rechaza").isEqualTo(4);
        } finally {
            piscina.shutdownNow();
        }
        assertThat(circuitos.circuitBreaker("pasarela").getState())
                .as("un mamparo lleno no cuenta como fallo de la pasarela").isEqualTo(CircuitBreaker.State.CLOSED);
    }
}
