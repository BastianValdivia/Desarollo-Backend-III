package cl.duoc.bancoxyz.notificaciones;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.Topicos;
import cl.duoc.bancoxyz.eventos.soporte.KafkaDePrueba;
import cl.duoc.bancoxyz.notificaciones.aplicacion.Notificacion;
import cl.duoc.bancoxyz.notificaciones.pasarela.PasarelaDeEnvio;
import cl.duoc.bancoxyz.notificaciones.pasarela.PasarelaNoDisponibleException;

/**
 * El consumidor completo contra Kafka y PostgreSQL reales: llegada, idempotencia, DLT y reintentos no
 * bloqueantes.
 *
 * <p>La pasarela se reemplaza por un doble determinista: falla para las notificaciones de la cuenta 9999 y
 * funciona para el resto. Asi un caso de fallo no depende del azar ni de la proteccion de Resilience4j (que
 * tiene su propia prueba, {@link PasarelaProtegidaTest}). Los reintentos se acortan (3 intentos, 300 ms) para
 * que la prueba no espere los 30 s de produccion.
 */
@SpringBootTest
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class ConsumidorKafkaTest {

    private static final int CUENTA_QUE_FALLA = 9999;

    @DynamicPropertySource
    static void propiedades(DynamicPropertyRegistry registro) {
        registro.add("spring.kafka.bootstrap-servers", KafkaDePrueba::bootstrap);
        registro.add("notificaciones.reintentos.intentos", () -> "3");
        registro.add("notificaciones.reintentos.espera-ms", () -> "300");
        registro.add("notificaciones.reintentos.espera-maxima-ms", () -> "1000");
    }

    @MockBean
    private PasarelaDeEnvio pasarela;

    @Autowired
    private KafkaTemplate<String, String> kafka;
    @Autowired
    private JdbcClient jdbc;

    @BeforeEach
    void pasarelaDeterminista() {
        Mockito.doAnswer(invocacion -> {
            Notificacion n = invocacion.getArgument(0);
            if (n.mensaje().contains("cuenta " + CUENTA_QUE_FALLA + " ")) {
                throw new PasarelaNoDisponibleException("fallo de prueba");
            }
            return null;
        }).when(pasarela).enviar(any());
    }

    private void publicar(String clave, String json) throws Exception {
        kafka.send(Topicos.RETIROS, clave, json).get(10, TimeUnit.SECONDS);
    }

    private long notificaciones(String eventId) {
        return jdbc.sql("SELECT count(*) FROM notificacion WHERE event_id = :id::uuid")
                .param("id", eventId).query(Long.class).single();
    }

    private void esperarNotificacion(String eventId) {
        Awaitility.await().atMost(60, TimeUnit.SECONDS).until(() -> notificaciones(eventId) == 1);
    }

    @Test
    @DisplayName("Un evento publicado en bancoxyz.retiros.v1 llega al consumidor y queda notificado")
    void unEventoLlegaYSeNotifica() throws Exception {
        SobreEvento evento = EventosDePrueba.retiro(116);

        publicar("116", CodecEventos.escribir(evento));

        esperarNotificacion(evento.eventId());
        assertThat(jdbc.sql("SELECT mensaje FROM notificacion WHERE event_id = :id::uuid")
                .param("id", evento.eventId()).query(String.class).single()).contains("cuenta 116");
    }

    @Test
    @DisplayName("El mismo evento entregado tres veces (entrega al menos una vez) se notifica una sola vez")
    void repetidoSeNotificaUnaVez() throws Exception {
        SobreEvento repetido = EventosDePrueba.retiro(120);
        SobreEvento marca = EventosDePrueba.retiro(121);
        String json = CodecEventos.escribir(repetido);

        publicar("120", json);
        publicar("120", json);
        publicar("120", json);
        // Misma clave => misma particion => se consume DESPUES de los tres repetidos.
        publicar("120", CodecEventos.escribir(marca));

        esperarNotificacion(marca.eventId());
        assertThat(notificaciones(repetido.eventId())).as("notificado una sola vez").isEqualTo(1);
    }

    @Test
    @DisplayName("Un mensaje invalido va a la DLT SIN reintentos y NO bloquea la particion: el siguiente se procesa")
    void invalidoVaALaDltSinBloquear() throws Exception {
        String basura = "esto no es un evento " + System.nanoTime();
        SobreEvento siguiente = EventosDePrueba.retiro(122);

        publicar("122", basura);
        publicar("122", CodecEventos.escribir(siguiente));   // misma clave: misma particion, justo despues

        esperarNotificacion(siguiente.eventId());

        // La carta muerta quedo anotada con su causa...
        Awaitility.await().atMost(30, TimeUnit.SECONDS).until(() -> jdbc.sql(
                "SELECT count(*) FROM carta_muerta WHERE payload = :p").param("p", basura)
                .query(Long.class).single() == 1);
        var carta = jdbc.sql("SELECT topico_original, motivo, clave FROM carta_muerta WHERE payload = :p")
                .param("p", basura).query().singleRow();
        assertThat(carta.get("topico_original")).isEqualTo(Topicos.RETIROS);
        assertThat(carta.get("clave")).isEqualTo("122");
        assertThat((String) carta.get("motivo")).contains("JSON");

        // ... y el mensaje esta en el topico DLT de Kafka.
        List<ConsumerRecord<String, String>> enLaDlt = KafkaDePrueba.leerHasta(
                Topicos.RETIROS + "-notificaciones-dlt",
                leidos -> leidos.stream().anyMatch(r -> basura.equals(r.value())), Duration.ofSeconds(30));
        assertThat(enLaDlt).anyMatch(r -> basura.equals(r.value()));
    }

    @Test
    @DisplayName("Un fallo transitorio de la pasarela se reintenta por topicos de reintento (no bloqueantes), "
            + "no detiene la particion y, al agotar los intentos, termina en la DLT")
    void fallaDeLaPasarelaReintentaYTerminaEnLaDlt() throws Exception {
        SobreEvento quefalla = EventosDePrueba.retiro(CUENTA_QUE_FALLA);
        SobreEvento sano = EventosDePrueba.retiro(123);

        long inicio = System.nanoTime();
        publicar("9999", CodecEventos.escribir(quefalla));
        publicar("9999", CodecEventos.escribir(sano));   // misma particion, inmediatamente despues

        // El sano NO espera a los reintentos del que falla: se procesa mientras el otro espera su turno.
        esperarNotificacion(sano.eventId());
        Duration espera = Duration.ofNanos(System.nanoTime() - inicio);
        assertThat(notificaciones(quefalla.eventId())).as("el que falla no se notifico").isZero();

        // El que falla agota los 3 intentos (la entrega original y 2 reintentos) y termina en la DLT.
        Awaitility.await().atMost(60, TimeUnit.SECONDS).until(() -> jdbc.sql(
                "SELECT count(*) FROM carta_muerta WHERE payload LIKE :p")
                .param("p", "%" + quefalla.eventId() + "%").query(Long.class).single() == 1);
        var carta = jdbc.sql("SELECT motivo FROM carta_muerta WHERE payload LIKE :p")
                .param("p", "%" + quefalla.eventId() + "%").query().singleRow();
        assertThat((String) carta.get("motivo")).contains("fallo de prueba");
        assertThat(notificaciones(quefalla.eventId())).isZero();

        // Los topicos de reintento existen y llevan las 3 particiones del sistema.
        try (AdminClient admin = AdminClient.create(Map.<String, Object>of("bootstrap.servers",
                KafkaDePrueba.bootstrap()))) {
            var topicos = admin.listTopics().names().get(10, TimeUnit.SECONDS);
            assertThat(topicos).anyMatch(t -> t.startsWith(Topicos.RETIROS + "-notificaciones-retry"));
            assertThat(topicos).contains(Topicos.RETIROS + "-notificaciones-dlt");
            var descripcion = admin.describeTopics(List.of(Topicos.RETIROS + "-notificaciones-dlt"))
                    .allTopicNames().get(10, TimeUnit.SECONDS);
            assertThat(descripcion.get(Topicos.RETIROS + "-notificaciones-dlt").partitions()).hasSize(3);
        }
        System.out.println("El evento sano se proceso " + espera.toMillis() + " ms despues de publicarse, "
                + "sin esperar los reintentos del que fallaba");
    }
}
