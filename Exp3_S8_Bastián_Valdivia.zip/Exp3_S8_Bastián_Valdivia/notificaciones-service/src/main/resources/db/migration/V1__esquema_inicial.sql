-- =====================================================================
-- notificaciones-service, V1: esquema inicial de la base "notificaciones".
-- =====================================================================
-- Tres tablas, una por pregunta que el servicio tiene que poder responder:
--   evento_procesado  "ya procesaste este evento?"   (idempotencia)
--   notificacion      "que avisaste y a quien?"       (el resultado)
--   carta_muerta      "que no pudiste procesar?"      (la DLT, con su causa)

-- IDEMPOTENCIA. Kafka entrega "al menos una vez": el mismo evento puede llegar dos veces (reenvio del relay,
-- reasignacion de particiones tras una caida). El event_id del sobre es la clave primaria: la segunda vez el
-- INSERT ... ON CONFLICT DO NOTHING no inserta nada y el servicio sabe que es un repetido. Se inserta en la
-- MISMA transaccion que la notificacion: si el envio falla, la fila de aqui se deshace tambien y el
-- reintento no se confunde con un repetido.
CREATE TABLE evento_procesado (
    event_id      uuid         PRIMARY KEY,
    tipo          varchar(60)  NOT NULL,
    topico        varchar(160) NOT NULL,
    particion     integer      NOT NULL,
    desplazamiento bigint      NOT NULL,
    procesado_en  timestamptz  NOT NULL DEFAULT now()
);

CREATE TABLE notificacion (
    id           bigint       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    -- UNIQUE ademas de la clave de evento_procesado: segunda barrera contra una notificacion duplicada.
    event_id     uuid         NOT NULL UNIQUE REFERENCES evento_procesado (event_id),
    tipo         varchar(60)  NOT NULL,
    canal        varchar(20)  NOT NULL,
    destinatario varchar(160) NOT NULL,
    mensaje      text         NOT NULL,
    estado       varchar(20)  NOT NULL,
    creada_en    timestamptz  NOT NULL DEFAULT now(),
    CONSTRAINT notificacion_estado_valido CHECK (estado IN ('ENVIADA'))
);
CREATE INDEX notificacion_por_destinatario ON notificacion (destinatario, id DESC);

-- LA DLT (dead letter topic): lo que no se pudo procesar tras los reintentos, o que nunca pudo procesarse
-- (mensaje invalido). Ademas de quedar en el topico <original>-notificaciones-dlt de Kafka, se anota aqui
-- con su causa para poder consultarlo sin leer el topico.
CREATE TABLE carta_muerta (
    id                bigint       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    topico_original   varchar(160) NOT NULL,
    particion         integer,
    desplazamiento    bigint,
    clave             varchar(160),
    payload           text,
    motivo            text         NOT NULL,
    recibida_en       timestamptz  NOT NULL DEFAULT now()
);
