package cl.duoc.bancoxyz.notificaciones.pasarela;

import cl.duoc.bancoxyz.notificaciones.aplicacion.Notificacion;

/**
 * Puerto hacia el sistema que de verdad entrega el aviso (un proveedor de SMS o de correo).
 *
 * <p>En este proyecto la implementacion es {@link PasarelaSimulada}. El resto del servicio solo conoce esta
 * interfaz, de modo que cambiarla por un cliente real no toca al consumidor ni a la proteccion de
 * Resilience4j.
 */
public interface PasarelaDeEnvio {

    /**
     * Envia el aviso.
     *
     * @throws PasarelaNoDisponibleException si no se pudo entregar
     */
    void enviar(Notificacion notificacion);
}
