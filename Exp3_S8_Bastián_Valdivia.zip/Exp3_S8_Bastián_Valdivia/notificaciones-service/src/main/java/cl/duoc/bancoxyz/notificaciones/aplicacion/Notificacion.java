package cl.duoc.bancoxyz.notificaciones.aplicacion;

/**
 * Un aviso listo para enviar.
 *
 * @param tipo         tipo del evento que lo origino
 * @param canal        medio de envio ({@code SMS} o {@code EMAIL})
 * @param destinatario a quien va
 * @param mensaje      texto del aviso
 */
public record Notificacion(String tipo, String canal, String destinatario, String mensaje) {
}
