package cl.duoc.bancoxyz.notificaciones.consumo;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.DltHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.retrytopic.DltStrategy;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.retry.annotation.Backoff;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.eventos.EventoInvalidoException;
import cl.duoc.bancoxyz.eventos.Topicos;
import cl.duoc.bancoxyz.notificaciones.aplicacion.ProcesadorDeEventos;
import cl.duoc.bancoxyz.notificaciones.persistencia.RepositorioNotificaciones;

/**
 * El consumidor de Kafka: escucha los dos topicos en el grupo {@code notificaciones}.
 *
 * <h2>Grupo de consumidores y escalado</h2>
 *
 * <p>Todas las replicas comparten el {@code groupId}: Kafka reparte entre ellas las particiones (3 por
 * topico) y cada evento lo procesa UNA sola. Si una replica muere, las otras heredan sus particiones. Cada
 * replica usa un hilo ({@code concurrency=1}): asi el escalado se ve en el numero de replicas y no se
 * confunde con el paralelismo interno de una.
 *
 * <h2>Reintentos NO bloqueantes y DLT</h2>
 *
 * <p>Con un reintento bloqueante, un evento que falla detiene la particion entera: nada mas avanza hasta
 * que se resuelve o se rinde, y un solo mensaje enfermo atrasa a todos los de su particion. Con
 * {@link RetryableTopic}, el evento fallido se republica en un topico de reintento (con su espera) y la
 * particion principal sigue con el siguiente mensaje. Tras agotar los intentos, el evento va a la DLT.
 *
 * <ul>
 *   <li>Error de la pasarela (transitorio): se reintenta {@code notificaciones.reintentos.intentos} veces
 *       con espera exponencial y despues va a la DLT.</li>
 *   <li>Mensaje invalido ({@link EventoInvalidoException}, permanente): reintentarlo daria el mismo error,
 *       asi que va <strong>directo</strong> a la DLT.</li>
 * </ul>
 *
 * <p>Los topicos de reintento y de DLT llevan el nombre del grupo ({@code -notificaciones-retry-...},
 * {@code -notificaciones-dlt}): si no, la auditoria, que consume los mismos topicos con otro grupo, y este
 * servicio compartirian el mismo topico de reintento y cada reintento de uno lo veria tambien el otro.
 * Spring los crea al arrancar con las mismas 3 particiones.
 */
@Component
public class ConsumidorDeEventos {

    private static final Logger log = LoggerFactory.getLogger(ConsumidorDeEventos.class);

    private final ProcesadorDeEventos procesador;
    private final RepositorioNotificaciones repositorio;

    public ConsumidorDeEventos(ProcesadorDeEventos procesador, RepositorioNotificaciones repositorio) {
        this.procesador = procesador;
        this.repositorio = repositorio;
    }

    @RetryableTopic(
            attempts = "${notificaciones.reintentos.intentos:5}",
            backoff = @Backoff(
                    delayExpression = "${notificaciones.reintentos.espera-ms:2000}",
                    multiplierExpression = "${notificaciones.reintentos.multiplicador:2.0}",
                    maxDelayExpression = "${notificaciones.reintentos.espera-maxima-ms:20000}"),
            numPartitions = "3",
            replicationFactor = "1",
            retryTopicSuffix = "-notificaciones-retry",
            dltTopicSuffix = "-notificaciones-dlt",
            exclude = EventoInvalidoException.class,
            dltStrategy = DltStrategy.FAIL_ON_ERROR)
    @KafkaListener(
            id = "notificaciones-eventos",
            groupId = "${notificaciones.grupo:notificaciones}",
            topics = {Topicos.RETIROS, Topicos.SEGURIDAD})
    public void consumir(ConsumerRecord<String, String> registro) {
        procesador.procesar(registro.value(), registro.topic(), registro.partition(), registro.offset());
    }

    /**
     * La DLT: el mensaje ya no se reintenta. Los datos de origen y la causa viajan en las cabeceras que agrega
     * Spring Kafka al publicar en la DLT ({@code kafka_original-*} y {@code kafka_exception-*}). Se deja constancia (log y tabla {@code carta_muerta}) con su causa,
     * para que una persona lo revise. No relanza nada: una excepcion aqui bloquearia la propia DLT.
     */
    @DltHandler
    public void cartaMuerta(ConsumerRecord<String, String> registro) {
        String topicoOriginal = comoTexto(registro.headers().lastHeader(KafkaHeaders.ORIGINAL_TOPIC));
        Integer particion = comoEntero(registro.headers().lastHeader(KafkaHeaders.ORIGINAL_PARTITION));
        Long desplazamiento = comoLargo(registro.headers().lastHeader(KafkaHeaders.ORIGINAL_OFFSET));
        String motivo = comoTexto(registro.headers().lastHeader(KafkaHeaders.EXCEPTION_MESSAGE));
        if (topicoOriginal == null) {
            topicoOriginal = registro.topic();
        }
        log.error("DLT: mensaje de {} [{}@{}] clave {} descartado tras agotar los reintentos o por invalido. "
                        + "Motivo: {}", topicoOriginal, particion, desplazamiento, registro.key(), motivo);
        repositorio.guardarCartaMuerta(topicoOriginal, particion, desplazamiento, registro.key(), registro.value(),
                motivo == null ? "sin motivo registrado" : motivo);
    }

    private static String comoTexto(Header cabecera) {
        return cabecera == null ? null : new String(cabecera.value(), StandardCharsets.UTF_8);
    }

    private static Integer comoEntero(Header cabecera) {
        return cabecera == null || cabecera.value().length != Integer.BYTES
                ? null : ByteBuffer.wrap(cabecera.value()).getInt();
    }

    private static Long comoLargo(Header cabecera) {
        return cabecera == null || cabecera.value().length != Long.BYTES
                ? null : ByteBuffer.wrap(cabecera.value()).getLong();
    }
}
