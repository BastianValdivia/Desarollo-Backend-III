package cl.duoc.bancoxyz.notificaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada del <strong>notificaciones-service</strong>: consume los eventos del banco
 * (retiros y seguridad) desde Kafka y avisa por una pasarela de envio.
 *
 * <p>No expone API de negocio. Se escala agregando replicas: todas pertenecen al grupo de consumidores
 * {@code notificaciones}, y Kafka reparte entre ellas las particiones de cada topico (3 por topico, de modo
 * que mas de 3 replicas dejan a las sobrantes ociosas).
 *
 * <p>Sin logica: la clase principal solo dispara el escaneo de componentes.
 */
@SpringBootApplication
public class NotificacionesServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(NotificacionesServiceApplication.class, args);
    }
}
