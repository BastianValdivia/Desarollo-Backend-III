package cl.duoc.bancoxyz.notificaciones.persistencia;

import java.util.UUID;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.notificaciones.aplicacion.Notificacion;

/**
 * Acceso a la base "notificaciones" (JDBC, sin ORM, igual que el core).
 *
 * <p>Las tres operaciones de escritura se llaman dentro de la transaccion que abre
 * {@code ProcesadorDeEventos}: registrar el evento como procesado y guardar su notificacion se confirman
 * juntos o se deshacen juntos.
 */
@Repository
public class RepositorioNotificaciones {

    private final JdbcClient jdbc;

    public RepositorioNotificaciones(JdbcClient jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * Anota el evento como procesado.
     *
     * @return {@code true} si es la PRIMERA vez que se ve este {@code eventId}; {@code false} si ya estaba
     *         (un repetido). Es atomico: si dos replicas reciben el mismo evento a la vez, la clave primaria
     *         hace esperar a la segunda hasta que la primera confirme, y esa segunda ve el conflicto.
     */
    public boolean registrarProcesado(SobreEvento evento, String topico, int particion, long desplazamiento) {
        return jdbc.sql("""
                        INSERT INTO evento_procesado (event_id, tipo, topico, particion, desplazamiento)
                        VALUES (:id, :tipo, :topico, :particion, :desplazamiento)
                        ON CONFLICT (event_id) DO NOTHING""")
                .param("id", UUID.fromString(evento.eventId()))
                .param("tipo", evento.tipo())
                .param("topico", topico)
                .param("particion", particion)
                .param("desplazamiento", desplazamiento)
                .update() == 1;
    }

    public void guardarNotificacion(SobreEvento evento, Notificacion notificacion) {
        jdbc.sql("""
                        INSERT INTO notificacion (event_id, tipo, canal, destinatario, mensaje, estado)
                        VALUES (:id, :tipo, :canal, :destinatario, :mensaje, 'ENVIADA')""")
                .param("id", UUID.fromString(evento.eventId()))
                .param("tipo", notificacion.tipo())
                .param("canal", notificacion.canal())
                .param("destinatario", notificacion.destinatario())
                .param("mensaje", notificacion.mensaje())
                .update();
    }

    /** Anota un mensaje que termino en la DLT, con su causa. */
    public void guardarCartaMuerta(String topicoOriginal, Integer particion, Long desplazamiento, String clave,
                                   String payload, String motivo) {
        jdbc.sql("""
                        INSERT INTO carta_muerta (topico_original, particion, desplazamiento, clave, payload, motivo)
                        VALUES (:topico, :particion, :desplazamiento, :clave, :payload, :motivo)""")
                .param("topico", topicoOriginal)
                .param("particion", particion)
                .param("desplazamiento", desplazamiento)
                .param("clave", clave)
                .param("payload", payload)
                .param("motivo", motivo)
                .update();
    }
}
