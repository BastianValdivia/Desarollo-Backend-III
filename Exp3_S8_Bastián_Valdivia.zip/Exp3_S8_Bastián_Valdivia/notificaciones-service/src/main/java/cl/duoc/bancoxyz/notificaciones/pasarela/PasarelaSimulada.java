package cl.duoc.bancoxyz.notificaciones.pasarela;

import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.notificaciones.aplicacion.Notificacion;

/**
 * Pasarela de envio SIMULADA, con latencia y tasa de fallo configurables.
 *
 * <p>No manda nada a nadie: espera lo que diga {@code notificaciones.pasarela.latencia-ms} y falla con la
 * probabilidad de {@code notificaciones.pasarela.tasa-fallo} (0 a 1). Es la herramienta para ver, con numeros,
 * como se comportan el CircuitBreaker, el Retry y los reintentos no bloqueantes cuando el proveedor se pone
 * lento o se cae, y para medir el escalado del consumidor (la latencia es el costo por mensaje).
 *
 * <p><strong>Un plazo propio.</strong> Un proveedor real se corta con el timeout de su cliente HTTP. Aqui,
 * si la latencia configurada supera {@code notificaciones.pasarela.timeout-ms}, la llamada espera ese plazo y
 * falla por timeout: igual que cortaria un cliente real, y sin colgar el hilo del consumidor.
 *
 * <p><strong>Se lee el entorno en cada llamada</strong> (no un record de propiedades): un
 * {@code POST /actuator/refresh} cambia los valores sin reiniciar, y los {@code @ConfigurationProperties}
 * de tipo record no se reconstruyen con el refresh (pendiente heredado de F1). Leer el {@link Environment}
 * en cada envio es lo que hace que la demostracion de fallos funcione en caliente.
 */
@Component
public class PasarelaSimulada implements PasarelaDeEnvio {

    private static final Logger log = LoggerFactory.getLogger(PasarelaSimulada.class);

    private final Environment entorno;

    public PasarelaSimulada(Environment entorno) {
        this.entorno = entorno;
    }

    @Override
    public void enviar(Notificacion notificacion) {
        long latencia = Math.max(0, entorno.getProperty("notificaciones.pasarela.latencia-ms", Long.class, 0L));
        long timeout = Math.max(1, entorno.getProperty("notificaciones.pasarela.timeout-ms", Long.class, 1000L));
        double tasaDeFallo = entorno.getProperty("notificaciones.pasarela.tasa-fallo", Double.class, 0.0);

        if (latencia > timeout) {
            dormir(timeout);
            throw new PasarelaNoDisponibleException("La pasarela no respondio en " + timeout + " ms (timeout).");
        }
        dormir(latencia);
        if (tasaDeFallo > 0 && ThreadLocalRandom.current().nextDouble() < tasaDeFallo) {
            throw new PasarelaNoDisponibleException("La pasarela rechazo el envio (fallo simulado).");
        }
        log.debug("Enviado por {} a {}: {}", notificacion.canal(), notificacion.destinatario(),
                notificacion.mensaje());
    }

    private static void dormir(long milisegundos) {
        if (milisegundos <= 0) {
            return;
        }
        try {
            Thread.sleep(milisegundos);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new PasarelaNoDisponibleException("Envio interrumpido.");
        }
    }
}
