package cl.duoc.bancoxyz.notificaciones.aplicacion;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.notificaciones.pasarela.PasarelaDeEnvio;
import cl.duoc.bancoxyz.notificaciones.persistencia.RepositorioNotificaciones;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * El caso de uso del servicio: procesar UN evento de forma idempotente.
 *
 * <p>Pasos, todos dentro de una sola transaccion de la base:
 *
 * <ol>
 *   <li>Leer y validar el sobre ({@link CodecEventos#leer}). Si es invalido lanza
 *       {@code EventoInvalidoException}: error permanente, va a la DLT sin reintentos.</li>
 *   <li>Anotar el {@code eventId} como procesado. Si ya estaba, el evento es un repetido: se descarta sin
 *       notificar (es la IDEMPOTENCIA).</li>
 *   <li>Componer el mensaje y enviarlo por la pasarela (protegida con Resilience4j).</li>
 *   <li>Guardar la notificacion.</li>
 * </ol>
 *
 * <p><strong>Por que el envio esta DENTRO de la transaccion.</strong> Si la pasarela falla, la excepcion
 * deshace la anotacion del paso 2: el evento queda como "no procesado" y su reintento (por el topico de
 * reintento) no se confunde con un repetido. Si la anotacion se confirmara antes de enviar, un fallo
 * perderia el aviso para siempre. El costo es conservar una conexion de la base durante el envio (decenas
 * de milisegundos), aceptable con un consumidor de un hilo por replica.
 *
 * <p>Garantia resultante: el aviso se envia AL MENOS una vez por evento (si el proceso muere despues de
 * enviar y antes de confirmar, el reintento lo envia de nuevo, y un proveedor real deberia tambien
 * deduplicar por {@code eventId}) y se REGISTRA exactamente una vez.
 */
@Service
public class ProcesadorDeEventos {

    private static final Logger log = LoggerFactory.getLogger(ProcesadorDeEventos.class);

    /** Lo que paso con un evento. */
    public enum Resultado {
        /** Se notifico y se registro. */
        PROCESADO,
        /** Ya se habia procesado: se descarto sin notificar. */
        DUPLICADO
    }

    private final RepositorioNotificaciones repositorio;
    private final ComponedorDeMensajes componedor;
    private final PasarelaDeEnvio pasarela;
    private final TransactionTemplate transaccion;
    private final Counter procesados;
    private final Counter duplicados;

    public ProcesadorDeEventos(RepositorioNotificaciones repositorio, ComponedorDeMensajes componedor,
                               PasarelaDeEnvio pasarela, PlatformTransactionManager gestor, MeterRegistry metricas) {
        this.repositorio = repositorio;
        this.componedor = componedor;
        this.pasarela = pasarela;
        this.transaccion = new TransactionTemplate(gestor);
        this.procesados = Counter.builder("notificaciones.procesadas")
                .description("Eventos notificados y registrados").register(metricas);
        this.duplicados = Counter.builder("notificaciones.duplicadas")
                .description("Eventos repetidos descartados por la idempotencia").register(metricas);
    }

    /**
     * @param json        el mensaje tal como llego de Kafka
     * @param topico      topico de origen (para el registro)
     * @param particion   particion de origen
     * @param desplazamiento offset dentro de la particion
     * @throws cl.duoc.bancoxyz.eventos.EventoInvalidoException si el mensaje incumple el contrato
     * @throws cl.duoc.bancoxyz.notificaciones.pasarela.PasarelaNoDisponibleException si la pasarela no entrego
     */
    public Resultado procesar(String json, String topico, int particion, long desplazamiento) {
        SobreEvento evento = CodecEventos.leer(json);
        Resultado resultado = transaccion.execute(estado -> {
            if (!repositorio.registrarProcesado(evento, topico, particion, desplazamiento)) {
                return Resultado.DUPLICADO;
            }
            Notificacion notificacion = componedor.componer(evento);
            pasarela.enviar(notificacion);
            repositorio.guardarNotificacion(evento, notificacion);
            return Resultado.PROCESADO;
        });
        if (resultado == Resultado.DUPLICADO) {
            duplicados.increment();
            log.info("Evento {} ({}) repetido: ya estaba procesado, se descarta sin notificar.", evento.eventId(),
                    evento.tipo());
        } else {
            procesados.increment();
            log.info("Evento {} ({}) notificado [{}-{}@{}].", evento.eventId(), evento.tipo(), topico, particion,
                    desplazamiento);
        }
        return resultado;
    }
}
