package cl.duoc.bancoxyz.notificaciones.pasarela;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.notificaciones.aplicacion.Notificacion;
import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

/**
 * La pasarela envuelta en <strong>Resilience4j</strong> (instancia {@code pasarela}, configurada en
 * {@code config-repo/notificaciones-service.yml}). Es la {@code PasarelaDeEnvio} que usa el servicio.
 *
 * <p>Capas, de afuera hacia adentro (el orden por defecto de los aspectos de Resilience4j):
 *
 * <ol>
 *   <li><strong>Retry</strong>: hasta 3 intentos seguidos con una espera corta. Cubre un fallo pasajero
 *       del proveedor sin devolverle el error al consumidor.</li>
 *   <li><strong>CircuitBreaker</strong>: si la mitad de las ultimas llamadas fallan, se abre y rechaza al
 *       instante durante 10 s. Una pasarela caida no hace esperar a cada evento su plazo.</li>
 *   <li><strong>Bulkhead</strong>: como maximo 10 envios simultaneos. Una pasarela lenta no puede ocupar
 *       todos los hilos del consumidor.</li>
 * </ol>
 *
 * <p><strong>El respaldo no esta aqui, esta en Kafka.</strong> Cuando todo esto se agota (reintentos
 * fallidos, circuito abierto o mamparo lleno) la excepcion sube al consumidor, y los reintentos no
 * bloqueantes mandan el evento a un topico de reintento con espera, y luego a la DLT. El evento nunca se
 * pierde ni detiene la particion.
 */
@Component
@Primary
public class PasarelaProtegida implements PasarelaDeEnvio {

    private final PasarelaSimulada pasarela;

    public PasarelaProtegida(PasarelaSimulada pasarela) {
        this.pasarela = pasarela;
    }

    @Override
    @Retry(name = "pasarela")
    @CircuitBreaker(name = "pasarela")
    @Bulkhead(name = "pasarela")
    public void enviar(Notificacion notificacion) {
        pasarela.enviar(notificacion);
    }
}
