package cl.duoc.bancoxyz.notificaciones.aplicacion;

import java.text.NumberFormat;
import java.util.Locale;

import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.eventos.DatosRetiro;
import cl.duoc.bancoxyz.eventos.DatosSeguridad;
import cl.duoc.bancoxyz.eventos.EventoInvalidoException;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.TiposEvento;

/**
 * Convierte un evento del banco en el aviso que se envia.
 *
 * <p>Un retiro avisa al titular de la cuenta por SMS; un evento de seguridad avisa al equipo de seguridad por
 * correo. El mensaje nunca incluye datos que el evento no trae (el contrato ya excluye claves, PIN y numeros
 * de tarjeta completos), asi que lo que sale de aqui es seguro de enviar y de guardar.
 *
 * <p>Si los datos no corresponden al tipo declarado ({@link EventoInvalidoException}), el evento es invalido
 * de forma permanente y va a la DLT sin reintentos.
 */
@Component
public class ComponedorDeMensajes {

    private static final String EQUIPO_DE_SEGURIDAD = "seguridad@bancoxyz.cl";

    private final NumberFormat pesos = NumberFormat.getIntegerInstance(Locale.of("es", "CL"));

    public Notificacion componer(SobreEvento evento) {
        return switch (evento.tipo()) {
            case TiposEvento.RETIRO_EJECUTADO -> deRetiro(evento);
            case TiposEvento.LOGIN_FALLIDO, TiposEvento.USUARIO_BLOQUEADO,
                 TiposEvento.PIN_INCORRECTO, TiposEvento.TARJETA_BLOQUEADA -> deSeguridad(evento);
            default -> throw new EventoInvalidoException("No hay plantilla para el tipo " + evento.tipo());
        };
    }

    private Notificacion deRetiro(SobreEvento evento) {
        DatosRetiro retiro = evento.datosComo(DatosRetiro.class);
        if (retiro.monto() == null || retiro.saldoPosterior() == null || retiro.folio() == null) {
            throw new EventoInvalidoException("El retiro " + evento.eventId() + " no trae monto, saldo o folio.");
        }
        String mensaje = "Retiro de $%s %s en la cuenta %d (folio %s). Saldo disponible: $%s."
                .formatted(pesos.format(retiro.monto()), retiro.moneda() == null ? "" : retiro.moneda(),
                        retiro.cuentaId(), retiro.folio(), pesos.format(retiro.saldoPosterior()));
        return new Notificacion(evento.tipo(), "SMS", "titular-cuenta-" + retiro.cuentaId(), mensaje);
    }

    private Notificacion deSeguridad(SobreEvento evento) {
        DatosSeguridad datos = evento.datosComo(DatosSeguridad.class);
        if (datos.sujeto() == null || datos.sujeto().isBlank()) {
            throw new EventoInvalidoException("El evento de seguridad " + evento.eventId() + " no trae sujeto.");
        }
        String mensaje = switch (evento.tipo()) {
            case TiposEvento.LOGIN_FALLIDO -> "Inicio de sesion fallido del usuario %s (%s). Intentos restantes: %s."
                    .formatted(datos.sujeto(), motivo(datos), numero(datos.intentosRestantes()));
            case TiposEvento.USUARIO_BLOQUEADO -> "Usuario %s bloqueado tras %s intentos fallidos, hasta %s."
                    .formatted(datos.sujeto(), numero(datos.intentosFallidos()), datos.bloqueadoHasta());
            case TiposEvento.PIN_INCORRECTO -> "PIN incorrecto en la tarjeta %s desde el terminal %s. Intentos restantes: %s."
                    .formatted(datos.sujeto(), datos.terminal(), numero(datos.intentosRestantes()));
            default -> "Tarjeta %s bloqueada desde el terminal %s (%s), hasta %s."
                    .formatted(datos.sujeto(), datos.terminal(), motivo(datos), datos.bloqueadoHasta());
        };
        return new Notificacion(evento.tipo(), "EMAIL", EQUIPO_DE_SEGURIDAD, mensaje);
    }

    private static String motivo(DatosSeguridad datos) {
        return datos.motivo() == null ? "sin motivo" : datos.motivo();
    }

    private static String numero(Integer valor) {
        return valor == null ? "?" : valor.toString();
    }
}
