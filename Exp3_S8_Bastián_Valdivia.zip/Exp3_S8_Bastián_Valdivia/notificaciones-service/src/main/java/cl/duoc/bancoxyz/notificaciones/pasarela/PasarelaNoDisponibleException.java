package cl.duoc.bancoxyz.notificaciones.pasarela;

/**
 * La pasarela de envio no pudo entregar el aviso: rechazo, caida o demasiado lenta.
 *
 * <p>Es la excepcion que Resilience4j cuenta como fallo del circuito {@code pasarela} y que reintenta. Un
 * mensaje invalido NO es esto: eso es un error permanente del evento, no de la pasarela.
 */
public class PasarelaNoDisponibleException extends RuntimeException {

    public PasarelaNoDisponibleException(String mensaje) {
        super(mensaje);
    }
}
