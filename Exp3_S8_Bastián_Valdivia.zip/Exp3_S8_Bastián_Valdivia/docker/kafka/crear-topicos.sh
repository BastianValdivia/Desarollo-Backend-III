#!/bin/sh
# =====================================================================
# crear-topicos.sh: crea de forma DECLARATIVA los topicos de negocio de Kafka (F7).
# =====================================================================
# Corre como tarea unica en el servicio "kafka-init" del compose, cuando el broker ya esta sano, y termina.
# Es idempotente (--if-not-exists): se puede ejecutar cuantas veces se quiera.
#
# POR QUE ASI Y NO "auto-create": el broker tiene KAFKA_AUTO_CREATE_TOPICS_ENABLE=false. Con la creacion
# automatica, un productor con un nombre mal escrito crearia un topico nuevo con 1 particion y nadie lo
# notaria; aqui los topicos existen porque estan escritos en este archivo, con las particiones que el
# diseno decidio.
#
# PARTICIONES = 3. Es el techo de consumidores utiles por grupo: un grupo con 4 consumidores deja uno
# ocioso. Se eligieron 3 para poder demostrar el reparto entre las 2 replicas de notificaciones, el
# escalado a 3 y el consumidor ocioso al llegar a 4 (docs/eventos.md).
# REPLICACION = 1. Un solo broker: un factor mayor no podria cumplirse. En produccion serian 3 brokers y
# factor 3 con min.insync.replicas=2 (se declara como limitacion en el README).
# RETENCION = 7 dias. Es lo que permite que un consumidor nuevo (o uno que estuvo caido) lea el historial.
#
# Los topicos de reintento y de cartas muertas (DLT) los crea cada consumidor al arrancar, con el mismo
# numero de particiones (Spring Kafka, @RetryableTopic): su nombre depende del grupo que los usa.
# =====================================================================
set -eu

BROKER="${KAFKA_BOOTSTRAP:-kafka:9092}"
KAFKA_TOPICS=/opt/kafka/bin/kafka-topics.sh

crear() {  # crear <topico>
  "$KAFKA_TOPICS" --bootstrap-server "$BROKER" --create --if-not-exists \
    --topic "$1" --partitions 3 --replication-factor 1 \
    --config retention.ms=604800000 --config min.insync.replicas=1
}

crear bancoxyz.retiros.v1
crear bancoxyz.seguridad.v1

echo "Topicos declarados:"
"$KAFKA_TOPICS" --bootstrap-server "$BROKER" --describe --topic bancoxyz.retiros.v1
"$KAFKA_TOPICS" --bootstrap-server "$BROKER" --describe --topic bancoxyz.seguridad.v1
