#!/bin/sh
# =====================================================================
# 01-bases-y-usuarios.sh: crea una base de datos por servicio, cada una con su propio usuario.
# =====================================================================
# La imagen postgres:16.15-alpine3.24 ejecuta los archivos de /docker-entrypoint-initdb.d UNA sola vez,
# al crear el directorio de datos (el volumen vacio). Despues no vuelven a correr: borrar el
# volumen "postgres-datos" (docker compose down -v) es lo que hace que se ejecuten otra vez.
#
# QUE CREA, y por que asi (principio: privilegios minimos y aislamiento entre servicios)
#   - un usuario por servicio (core, auditoria, notificaciones): LOGIN, sin superusuario, sin
#     crear bases ni roles, sin replicacion;
#   - una base por servicio, de la que ese usuario es DUENO. Es lo que necesita Flyway para crear el
#     esquema, y nada mas: el usuario no administra el servidor ni toca otras bases;
#   - REVOKE ... FROM PUBLIC sobre cada base, sobre la de mantenimiento "postgres" y sobre "template1": por
#     omision PostgreSQL deja entrar (CONNECT) a cualquier usuario a cualquier base. Sin esta
#     revocacion, el usuario "core" podria conectarse a "auditoria" aunque no leyera sus tablas. Asi
#     ni siquiera puede conectarse;
#   - el esquema "public" de cada base queda solo para su dueno.
#
# LAS CONTRASENAS NO ESTAN AQUI. Las genera secretos-init y llegan como archivos de un volumen de
# solo lectura montado en /run/secrets. El comando \set ... `cat archivo` de psql las lee en el
# momento, de modo que no pasan por argumentos de proceso ni por variables de entorno (se verian
# con "docker inspect" o "ps"). Se usa :'contrasena', que psql cita como literal SQL.
#
# El script es POSIX (sh): sirve igual si la imagen lo ejecuta o si lo incluye con "source".
# =====================================================================

for servicio in core auditoria notificaciones; do
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres <<SQL || exit 1
\\set contrasena \`cat /run/secrets/$servicio.password\`
CREATE ROLE $servicio LOGIN PASSWORD :'contrasena'
  NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION;
CREATE DATABASE $servicio OWNER $servicio;
REVOKE ALL ON DATABASE $servicio FROM PUBLIC;
SQL

  # El esquema "public" es el unico donde el servicio crea sus tablas (Flyway).
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$servicio" <<SQL || exit 1
REVOKE ALL ON SCHEMA public FROM PUBLIC;
ALTER SCHEMA public OWNER TO $servicio;
SQL
done

# Las bases de mantenimiento ("postgres") y la plantilla ("template1") tampoco son para los servicios.
# CREATE DATABASE la sigue usando el superusuario, al que esta revocacion no alcanza.
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres <<SQL || exit 1
REVOKE ALL ON DATABASE postgres FROM PUBLIC;
REVOKE ALL ON DATABASE template1 FROM PUBLIC;
SQL
