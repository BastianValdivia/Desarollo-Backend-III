#!/bin/sh
# =====================================================================
# generar-secretos.sh (secretos-init): todo el material criptografico de
# los contenedores, generado UNA vez al primer arranque.
# =====================================================================
# Corre dentro del servicio "secretos-init" de docker-compose.yaml (imagen
# eclipse-temurin:21-jdk-alpine), como tarea unica: genera, escribe y termina.
# Los demas servicios esperan con depends_on "service_completed_successfully".
#
# QUE GENERA
#   1. Una CA INTERNA (autoridad certificadora propia): ca.p12 (con su clave
#      privada, que solo ve ESTE contenedor) y ca.crt.
#   2. Un certificado TLS por cada BFF y por el auth-server, FIRMADO por esa CA,
#      con SAN localhost, 127.0.0.1 y el nombre del servicio de Compose.
#   3. Un truststore (truststore.p12) con la CA, para los servicios que
#      tengan que verificar certificados firmados por ella (el core y los BFF, que
#      validan y piden tokens al auth-server por HTTPS).
#   4. El par RSA PERSISTENTE con que el auth-server firma TODOS los tokens (F4 y F5). Los BFF ya no tienen
#      par de firma (F5): no emiten tokens, solo los validan con la clave publica que publica el auth-server.
#   5. Un secreto por cada cliente OAuth2 de servicio (bff-web, bff-mobile, bff-atm; F4). Cada BFF
#      recibe el suyo como propiedad de Spring (para pedir su token) y el auth-server recibe los
#      tres (para verificar al cliente: los convierte a hash BCrypt al arrancar y solo conserva el hash).
#      Reemplazan a la credencial fija BFF -> core del S5, que ya no existe: el core valida tokens.
#      F5 agrega el secreto del TERMINAL del cajero (atm-scl-001): lo recibe solo el auth-server (el cajero
#      real lo tendria en su propio equipo; aqui lo lee el script scripts/login-cajero.sh del volumen del
#      auth-server, solo para la demostracion).
#   6. Las contrasenas de PostgreSQL (F3): la del superusuario y una por base de datos
#      (core, auditoria, notificaciones). Se generan UNA vez en el volumen "postgres"; el
#      servidor las lee de ahi (POSTGRES_PASSWORD_FILE y el script de inicializacion) y el core
#      recibe la suya como propiedad de configtree (spring.datasource.password).
#   7. F7: la contrasena de la base de cada consumidor de eventos (notificaciones y auditoria) y el truststore de
#      la auditoria (valida tokens, como el core).
#
# DONDE LO DEJA (un volumen con nombre por servicio, montado en /run/secrets)
#   <servicio>/tls/<servicio>.p12              keystore TLS (solo BFF)
#   auth-server/firma/auth-server-{private,public}.pem   clave de firma de tokens (solo el auth-server)
#   <servicio>/truststore/truststore.p12 y truststore.password
#   <servicio>/propiedades/<propiedad>         un archivo por propiedad de Spring
#   postgres/<nombre>.password                 contrasenas de PostgreSQL (dueno 70, el usuario "postgres")
#
# LA CARPETA "propiedades" ES UN ARBOL DE CONFIGURACION (Spring Boot "configtree"):
# el nombre de cada archivo es el nombre de una propiedad y su contenido es el
# valor. Asi la contrasena del keystore (server.ssl.key-store-password) y el
# secreto del cliente OAuth2 llegan al servicio desde un
# archivo del volumen, sin variables de entorno (que se ven con "docker inspect")
# y sin pasar por config-repo (que el config-server entrega sin autenticar).
#
# QUIEN LO LEE: cada volumen queda con dueno 10001 (el usuario no root de las
# imagenes), carpetas 0500 y archivos 0400: el servicio puede leer lo suyo y
# nada mas, y nadie puede escribirlo. Un servicio solo monta SU volumen.
#
# AL HOST SOLO SALE certs/ca.crt (certificado PUBLICO de la CA): es lo que el
# evaluador pasa a "curl --cacert certs/ca.crt". Ninguna clave privada sale.
#
# IDEMPOTENTE: si el material existe, no se regenera (regenerar la CA o una clave
# de firma invalidaria de golpe certificados y tokens, con sintomas lejanos a la
# causa). Una sola excepcion deliberada: si la CA es NUEVA (su volumen estaba
# vacio), todo lo que ella firmo en un arranque anterior queda huerfano, asi que
# se regenera junto con ella.
#
# Solo usa keytool y java (vienen en el JDK): sin openssl, igual que
# scripts/generar-secretos.sh.
# =====================================================================
set -eu

UID_SERVICIOS=10001
# El usuario "postgres" de la imagen postgres:16.15-alpine3.24. El servidor y su script de inicializacion
# leen las contrasenas con ESE usuario, no con el 10001 de los servicios.
UID_POSTGRES=70
# Bases de datos (y su usuario, del mismo nombre) que crea el script de inicializacion de PostgreSQL.
# auditoria y notificaciones las usa F7: se generan ya para que la base se cree completa una sola vez.
BASES="core auditoria notificaciones"
BFFS="bff-web bff-mobile bff-atm"
SERVICIOS="$BFFS core-service auth-server notificaciones-service auditoria-service"
RAIZ=/secretos
CA="$RAIZ/ca"
HOST=/certs
CODIGO=/init

# Validez en dias. Diez anos, como en el S5: un certificado de desarrollo que caduca
# en silencio rompe el handshake en una maquina donde "no se toco nada". En
# produccion serian certificados cortos renovados por un gestor de secretos.
VALIDEZ=3650
DN_BASE="OU=Banco XYZ, O=Duoc UC, L=Santiago, C=CL"

# ---------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------
registrar() { echo "[secretos-init] $*"; }

# Valor aleatorio de 40 caracteres alfanumericos, del generador del sistema.
# Alfanumerico a proposito: viaja como contenido de un archivo y como argumento de
# keytool, y asi no hay que escapar nada.
aleatorio() { tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 40; }

# escribir <ruta> <contenido>: sin salto de linea final. En un configtree el valor
# es el contenido EXACTO del archivo; un "\n" de mas formaria parte de la contrasena.
escribir() { printf '%s' "$2" > "$1"; }

# Directorio temporal DENTRO del volumen del servicio: el "mv" final es un rename
# en el mismo sistema de archivos y por tanto atomico. Un arranque interrumpido
# deja basura en .tmp, nunca un keystore a medias.
nuevo_tmp() { d="$1/.tmp"; rm -rf "$d"; mkdir -p "$d"; echo "$d"; }

# ---------------------------------------------------------------------
# 1. CA interna
# ---------------------------------------------------------------------
mkdir -p "$CA"
chmod 0700 "$CA"
CA_NUEVA=0
if [ -f "$CA/ca.p12" ] && [ -f "$CA/ca.password" ] && [ -f "$CA/ca.crt" ]; then
  registrar "CA interna: ya existe, se conserva"
else
  registrar "CA interna: generando (RSA 4096, $VALIDEZ dias)"
  rm -f "$CA/ca.p12" "$CA/ca.password" "$CA/ca.crt" "$CA"/cliente-*.secret
  escribir "$CA/ca.password" "$(aleatorio)"
  # bc:c = basicConstraints CA:true. keyCertSign: es lo que le permite firmar
  # certificados; sin esa extension, curl rechaza la cadena ("CA cert does not
  # include key usage extension").
  keytool -genkeypair -alias ca -keyalg RSA -keysize 4096 -sigalg SHA256withRSA \
    -validity "$VALIDEZ" -storetype PKCS12 -keystore "$CA/ca.p12" \
    -storepass:file "$CA/ca.password" \
    -dname "CN=Banco XYZ CA interna, $DN_BASE" \
    -ext bc:c -ext KeyUsage:critical=keyCertSign,cRLSign
  keytool -exportcert -rfc -alias ca -keystore "$CA/ca.p12" \
    -storepass:file "$CA/ca.password" -file "$CA/ca.crt"
  CA_NUEVA=1
fi

chmod 0400 "$CA/ca.p12" "$CA/ca.password" "$CA/ca.crt"

# ---------------------------------------------------------------------
# 2. Material de cada servicio
# ---------------------------------------------------------------------
tls_de() {  # tls_de <servicio>: certificado firmado por la CA, dentro de <servicio>.p12
  svc="$1"
  dir="$RAIZ/$svc/tls"
  if [ -f "$dir/$svc.p12" ] && [ -f "$RAIZ/$svc/propiedades/server.ssl.key-store-password" ]; then
    registrar "$svc: certificado TLS ya existe, se conserva"
    return 0
  fi
  registrar "$svc: certificado TLS firmado por la CA (SAN localhost, 127.0.0.1, $svc)"
  mkdir -p "$dir" "$RAIZ/$svc/propiedades"
  t="$(nuevo_tmp "$RAIZ/$svc")"
  clave="$(aleatorio)"
  escribir "$t/clave" "$clave"
  san="SAN=dns:localhost,dns:$svc,ip:127.0.0.1"
  # a) par de claves del servicio en su keystore
  keytool -genkeypair -alias "$svc" -keyalg RSA -keysize 2048 -sigalg SHA256withRSA \
    -validity "$VALIDEZ" -storetype PKCS12 -keystore "$t/$svc.p12" \
    -storepass:file "$t/clave" -keypass:file "$t/clave" \
    -dname "CN=$svc, $DN_BASE" -ext "$san"
  # b) solicitud de firma, c) la CA la firma, d) la respuesta (cadena completa) vuelve
  #    al keystore. EKU serverAuth: el certificado solo sirve para identificar un servidor.
  keytool -certreq -alias "$svc" -keystore "$t/$svc.p12" -storepass:file "$t/clave" \
    -ext "$san" -file "$t/$svc.csr"
  keytool -gencert -alias ca -keystore "$CA/ca.p12" -storepass:file "$CA/ca.password" \
    -infile "$t/$svc.csr" -outfile "$t/$svc.pem" -rfc -validity "$VALIDEZ" \
    -ext "$san" -ext EKU=serverAuth -ext KeyUsage:critical=digitalSignature,keyEncipherment \
    -ext bc:c=ca:false
  keytool -importcert -noprompt -alias ca -file "$CA/ca.crt" -keystore "$t/$svc.p12" \
    -storepass:file "$t/clave"
  keytool -importcert -noprompt -alias "$svc" -file "$t/$svc.pem" -keystore "$t/$svc.p12" \
    -storepass:file "$t/clave"
  # El archivo de la contrasena se mueve el ULTIMO: su existencia es la marca de "completo".
  mv -f "$t/$svc.p12" "$dir/$svc.p12"
  mv -f "$t/clave" "$RAIZ/$svc/propiedades/server.ssl.key-store-password"
  rm -rf "$t"
}

firma_de() {  # firma_de <bff>: par RSA de firma de tokens (formato PEM, PKCS#8 y X.509)
  svc="$1"
  dir="$RAIZ/$svc/firma"
  if [ -f "$dir/$svc-private.pem" ] && [ -f "$dir/$svc-public.pem" ]; then
    registrar "$svc: claves de firma ya existen, se conservan"
    return 0
  fi
  registrar "$svc: claves de firma de tokens (RSA 2048)"
  mkdir -p "$dir"
  rm -f "$dir/$svc-private.pem" "$dir/$svc-public.pem"
  t="$(nuevo_tmp "$RAIZ/$svc")"
  java "$CODIGO/GenerarClaves.java" "$t" "$svc" > /dev/null
  mv -f "$t/$svc-public.pem" "$dir/$svc-public.pem"
  mv -f "$t/$svc-private.pem" "$dir/$svc-private.pem"
  rm -rf "$t"
}

truststore_de() {  # truststore_de <servicio>: truststore PKCS12 con SOLO la CA
  svc="$1"
  dir="$RAIZ/$svc/truststore"
  if [ -f "$dir/truststore.p12" ] && [ -f "$dir/truststore.password" ]; then
    registrar "$svc: truststore ya existe, se conserva"
    return 0
  fi
  registrar "$svc: truststore con la CA"
  mkdir -p "$dir"
  rm -f "$dir/truststore.p12" "$dir/truststore.password"
  t="$(nuevo_tmp "$RAIZ/$svc")"
  escribir "$t/clave" "$(aleatorio)"
  keytool -importcert -noprompt -alias ca -file "$CA/ca.crt" -storetype PKCS12 \
    -keystore "$t/truststore.p12" -storepass:file "$t/clave"
  mv -f "$t/truststore.p12" "$dir/truststore.p12"
  mv -f "$t/clave" "$dir/truststore.password"
  rm -rf "$t"
}

# ---------------------------------------------------------------------
# Contrasenas de PostgreSQL
# ---------------------------------------------------------------------
# Viven en su propio volumen y NO se regeneran con la CA: la base de datos las recibio al crearse
# (el script de inicializacion solo corre con el directorio de datos vacio), asi que cambiarlas
# aqui sin cambiarlas alli dejaria a los servicios sin poder entrar. Para empezar de cero se
# borran los dos volumenes juntos (docker compose down -v).
PG="$RAIZ/postgres"
mkdir -p "$PG"
generar_si_falta() {  # generar_si_falta <archivo> <descripcion>
  if [ -s "$PG/$1" ]; then
    registrar "postgres: $2 ya existe, se conserva"
  else
    escribir "$PG/$1" "$(aleatorio)"
    registrar "postgres: $2 generada"
  fi
}
generar_si_falta postgres.password "contrasena del superusuario"
for base in $BASES; do
  generar_si_falta "$base.password" "contrasena del usuario de la base $base"
done

propiedad_de() {  # propiedad_de <servicio> <propiedad> <archivo-origen>: copia un secreto como propiedad
  svc="$1"; propiedad="$2"; origen="$3"
  mkdir -p "$RAIZ/$svc/propiedades"
  destino="$RAIZ/$svc/propiedades/$propiedad"
  # Se compara contra la fuente unica y se corrige si difiere.
  if [ -f "$destino" ] && [ "$(cat "$destino")" = "$(cat "$origen")" ]; then
    registrar "$svc: $propiedad ya existe, se conserva"
  else
    registrar "$svc: $propiedad"
    cp "$origen" "$destino"
  fi
}

for svc in $SERVICIOS; do
  mkdir -p "$RAIZ/$svc"
  # Una CA nueva deja huerfano lo que firmo la anterior: se parte de cero.
  if [ "$CA_NUEVA" = 1 ]; then
    find "$RAIZ/$svc" -mindepth 1 -delete 2>/dev/null || true
  fi
  # Reparacion tras un arranque interrumpido: basura de un intento anterior.
  rm -rf "$RAIZ/$svc/.tmp"
done

# ---------------------------------------------------------------------
# Secretos de los clientes OAuth2 de servicio (F4)
# ---------------------------------------------------------------------
# Uno por BFF, en la CA (que solo monta este contenedor): es la fuente unica. Se conserva entre
# arranques mientras la CA exista; si la CA es nueva se regenera todo junto (los volumenes de los
# servicios se vaciaron mas arriba) y asi nunca queda un BFF con un secreto que el auth-server no tiene.
# El nombre de la propiedad del BFF es la de Spring Security para el secreto del registro "servicios-internos"
# (la define config-repo/<bff>.yml); el del auth-server, la de autorizacion.clientes.<id>.secreto.
REGISTRO_OAUTH2=servicios-internos
for svc in $BFFS; do
  if [ ! -s "$CA/cliente-$svc.secret" ]; then
    escribir "$CA/cliente-$svc.secret" "$(aleatorio)"
    registrar "secreto del cliente OAuth2 $svc: generado"
  fi
  chmod 0400 "$CA/cliente-$svc.secret"
done

# El terminal del cajero (F5): un cliente confidencial mas, con su propio secreto.
TERMINALES="atm-scl-001"
for t in $TERMINALES; do
  if [ ! -s "$CA/terminal-$t.secret" ]; then
    escribir "$CA/terminal-$t.secret" "$(aleatorio)"
    registrar "secreto del terminal $t: generado"
  fi
  chmod 0400 "$CA/terminal-$t.secret"
done

for svc in $BFFS; do
  tls_de "$svc"
  # F5: los BFF ya no firman tokens. En un volumen creado antes, su par de firma sobra: se retira.
  rm -rf "$RAIZ/$svc/firma"
  truststore_de "$svc"
  # La contrasena del truststore llega como propiedad del bundle SSL "interna" (Spring Boot 3.1+): con
  # el, el BFF verifica el certificado del auth-server al pedir su token (y no confia en nada mas).
  propiedad_de "$svc" spring.ssl.bundle.jks.interna.truststore.password "$RAIZ/$svc/truststore/truststore.password"
  propiedad_de "$svc" "spring.security.oauth2.client.registration.$REGISTRO_OAUTH2.client-secret" "$CA/cliente-$svc.secret"
done
truststore_de core-service
propiedad_de core-service spring.ssl.bundle.jks.interna.truststore.password "$RAIZ/core-service/truststore/truststore.password"

# Limpieza de lo retirado: en un volumen creado antes de F4 quedan la credencial fija BFF -> core del S5
# (en la CA y copiada en cada servicio). Ya nadie la lee; se borra para no dejar un secreto huerfano.
rm -f "$CA/token-servicio"
for svc in $BFFS core-service; do
  rm -f "$RAIZ/$svc/propiedades/core.token-servicio" "$RAIZ/$svc/propiedades/core.seguridad.token-servicio"
done

# El auth-server: certificado TLS, par de firma de tokens PERSISTENTE y los secretos de los tres clientes.
tls_de auth-server
firma_de auth-server
for svc in $BFFS; do
  propiedad_de auth-server "autorizacion.clientes.$svc.secreto" "$CA/cliente-$svc.secret"
done
for t in $TERMINALES; do
  propiedad_de auth-server "autorizacion.terminales.$t.secreto" "$CA/terminal-$t.secret"
done
# La contrasena de la base "core": la misma que PostgreSQL dio de alta para el usuario "core".
propiedad_de core-service spring.datasource.password "$PG/core.password"

# Mensajeria (F7). Los dos consumidores reciben la contrasena de SU base, y la auditoria ademas el truststore
# con la CA interna: es un servidor de recursos OAuth2 y descarga las claves del auth-server por HTTPS (igual
# que el core). Las notificaciones no validan tokens ni hablan por HTTPS: no necesitan truststore. Kafka no
# lleva secretos en este despliegue (PLAINTEXT en la red interna, sin puertos; ver README).
propiedad_de notificaciones-service spring.datasource.password "$PG/notificaciones.password"
truststore_de auditoria-service
propiedad_de auditoria-service spring.ssl.bundle.jks.interna.truststore.password "$RAIZ/auditoria-service/truststore/truststore.password"
propiedad_de auditoria-service spring.datasource.password "$PG/auditoria.password"

# ---------------------------------------------------------------------
# 3. Dueno y permisos minimos
# ---------------------------------------------------------------------
for svc in $SERVICIOS; do
  chown -R "$UID_SERVICIOS:$UID_SERVICIOS" "$RAIZ/$svc"
  find "$RAIZ/$svc" -type d -exec chmod 0500 {} +
  find "$RAIZ/$svc" -type f -exec chmod 0400 {} +
done

# PostgreSQL: dueno 70 (el usuario postgres de su imagen). Un archivo por contrasena, solo lectura.
chown -R "$UID_POSTGRES:$UID_POSTGRES" "$PG"
find "$PG" -type d -exec chmod 0500 {} +
find "$PG" -type f -exec chmod 0400 {} +

# ---------------------------------------------------------------------
# 4. Lo unico que sale al host: el certificado PUBLICO de la CA
# ---------------------------------------------------------------------
# Se copia siempre (es publico y barato): si alguien borro certs/ pero conserva los
# volumenes, vuelve a quedar consistente con la CA que firmo los certificados.
mkdir -p "$HOST"
cp "$CA/ca.crt" "$HOST/ca.crt"
chmod 0644 "$HOST/ca.crt"

registrar "listo. CA exportada a certs/ca.crt:"
keytool -printcert -file "$CA/ca.crt" | grep -E 'Owner:|Valid from:|SHA256:' | sed 's/^/[secretos-init]   /'
