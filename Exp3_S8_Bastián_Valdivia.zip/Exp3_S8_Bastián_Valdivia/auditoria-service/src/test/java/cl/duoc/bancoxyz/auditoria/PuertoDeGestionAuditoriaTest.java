package cl.duoc.bancoxyz.auditoria;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalManagementPort;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.eventos.soporte.KafkaDePrueba;

/**
 * El puerto de gestion del auditoria-service, con un servidor de gestion real en otro puerto: {@code health} y
 * {@code metrics} responden sin token (el healthcheck de Docker los necesita) y todo lo que NO se expone
 * ({@code env}, {@code configprops}, {@code heapdump}, {@code loggers}) responde 404, igual que en el core y los
 * BFF. Un manejador de errores demasiado general convertia estas rutas inexistentes en un 500 con traza en el
 * log (y {@code HEAD} sobre {@code refresh} tambien); esta prueba lo fija.
 *
 * <p>Es el equivalente, para este servicio, de {@code PuertoDeGestionAbiertoTest} del core.
 */
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"management.server.port=0", "spring.kafka.listener.auto-startup=false"})
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class PuertoDeGestionAuditoriaTest {

    @DynamicPropertySource
    static void propiedades(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
        registro.add("spring.kafka.bootstrap-servers", KafkaDePrueba::bootstrap);
    }

    @LocalServerPort
    private int puertoDeServicio;

    @LocalManagementPort
    private int puertoDeGestion;

    private final HttpClient cliente = HttpClient.newHttpClient();

    private HttpResponse<String> pedir(int puerto, String metodo, String ruta) throws Exception {
        return cliente.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + puerto + ruta))
                .method(metodo, HttpRequest.BodyPublishers.noBody()).build(), HttpResponse.BodyHandlers.ofString());
    }

    @Test
    @DisplayName("El puerto de gestion responde health (UP) y metrics sin token")
    void gestionAbierta() throws Exception {
        assertThat(puertoDeGestion).isNotEqualTo(puertoDeServicio);

        HttpResponse<String> salud = pedir(puertoDeGestion, "GET", "/actuator/health");
        assertThat(salud.statusCode()).isEqualTo(200);
        assertThat(salud.body()).contains("UP");
        assertThat(pedir(puertoDeGestion, "GET", "/actuator/metrics").statusCode()).isEqualTo(200);
    }

    @Test
    @DisplayName("env, configprops, heapdump y loggers no existen en el puerto de gestion: 404, no 500")
    void loQueNoSeExponeNoExiste() throws Exception {
        for (String ruta : new String[] {"/actuator/env", "/actuator/configprops", "/actuator/heapdump",
                "/actuator/loggers", "/actuator/nada"}) {
            HttpResponse<String> respuesta = pedir(puertoDeGestion, "GET", ruta);
            assertThat(respuesta.statusCode()).as(ruta).isEqualTo(404);
            assertThat(respuesta.body()).as(ruta).doesNotContain("error_interno");
        }
    }

    @Test
    @DisplayName("Un verbo que el endpoint no acepta (HEAD sobre refresh) es un error de cliente, nunca un 500")
    void verboNoAceptadoNoEs500() throws Exception {
        int estado = pedir(puertoDeGestion, "HEAD", "/actuator/refresh").statusCode();

        assertThat(estado).isBetween(400, 499);
    }
}
