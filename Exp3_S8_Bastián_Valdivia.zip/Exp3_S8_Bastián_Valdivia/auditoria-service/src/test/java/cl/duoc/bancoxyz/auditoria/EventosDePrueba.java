package cl.duoc.bancoxyz.auditoria;

import java.math.BigDecimal;
import java.time.Instant;

import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.DatosRetiro;
import cl.duoc.bancoxyz.eventos.DatosSeguridad;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.TiposEvento;

/** Fabrica de eventos validos para las pruebas. */
public final class EventosDePrueba {

    private EventosDePrueba() {
    }

    public static SobreEvento retiro(int cuenta, Instant ocurridoEn) {
        return SobreEvento.nuevo(TiposEvento.RETIRO_EJECUTADO, 1, ocurridoEn, "core-service",
                new DatosRetiro(cuenta, "RET-20261003-" + cuenta, new BigDecimal("1000.00"),
                        new BigDecimal("11000.00"), new BigDecimal("10000.00"), 700L, "CLP"));
    }

    public static SobreEvento retiro(int cuenta) {
        return retiro(cuenta, Instant.parse("2026-10-03T12:00:00Z"));
    }

    public static SobreEvento pinIncorrecto(String tarjeta, Instant ocurridoEn) {
        return SobreEvento.nuevo(TiposEvento.PIN_INCORRECTO, 1, ocurridoEn, "auth-server",
                new DatosSeguridad(tarjeta, "atm-scl-001", "pin_incorrecto", 1, 2, null));
    }

    public static String json(SobreEvento evento) {
        return CodecEventos.escribir(evento);
    }
}
