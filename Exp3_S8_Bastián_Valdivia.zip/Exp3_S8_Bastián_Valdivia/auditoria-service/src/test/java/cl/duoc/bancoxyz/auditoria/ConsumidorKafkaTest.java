package cl.duoc.bancoxyz.auditoria;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.auditoria.persistencia.RepositorioAuditoria;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.Topicos;
import cl.duoc.bancoxyz.eventos.soporte.KafkaDePrueba;

/**
 * El consumidor de auditoria completo contra Kafka y PostgreSQL reales: llegada, idempotencia, DLT y
 * reintentos no bloqueantes ante una caida pasajera de la base.
 *
 * <p>Los reintentos se acortan (3 intentos, 300 ms) para que la prueba no espere los 30 s de produccion.
 */
@SpringBootTest
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class ConsumidorKafkaTest {

    @DynamicPropertySource
    static void propiedades(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
        registro.add("spring.kafka.bootstrap-servers", KafkaDePrueba::bootstrap);
        registro.add("auditoria.reintentos.intentos", () -> "3");
        registro.add("auditoria.reintentos.espera-ms", () -> "300");
        registro.add("auditoria.reintentos.espera-maxima-ms", () -> "1000");
    }

    @SpyBean
    private RepositorioAuditoria repositorio;
    @Autowired
    private KafkaTemplate<String, String> kafka;
    @Autowired
    private JdbcClient jdbc;

    private void publicar(String topico, String clave, String json) throws Exception {
        kafka.send(topico, clave, json).get(10, TimeUnit.SECONDS);
    }

    private long auditados(String eventId) {
        return jdbc.sql("SELECT count(*) FROM evento_auditado WHERE event_id = :id::uuid")
                .param("id", eventId).query(Long.class).single();
    }

    private void esperarAuditado(String eventId) {
        Awaitility.await().atMost(60, TimeUnit.SECONDS).until(() -> auditados(eventId) == 1);
    }

    @Test
    @DisplayName("Los eventos de los DOS topicos llegan al grupo auditoria y quedan guardados")
    void llegaDeLosDosTopicos() throws Exception {
        SobreEvento retiro = EventosDePrueba.retiro(116);
        SobreEvento seguridad = EventosDePrueba.pinIncorrecto("400000******0116", java.time.Instant.now());

        publicar(Topicos.RETIROS, "116", EventosDePrueba.json(retiro));
        publicar(Topicos.SEGURIDAD, "400000******0116", EventosDePrueba.json(seguridad));

        esperarAuditado(retiro.eventId());
        esperarAuditado(seguridad.eventId());
        assertThat(jdbc.sql("SELECT topico FROM evento_auditado WHERE event_id = :id::uuid")
                .param("id", seguridad.eventId()).query(String.class).single()).isEqualTo(Topicos.SEGURIDAD);
    }

    @Test
    @DisplayName("El mismo evento entregado tres veces (entrega al menos una vez) se guarda una sola vez")
    void repetidoSeGuardaUnaVez() throws Exception {
        SobreEvento repetido = EventosDePrueba.retiro(120);
        SobreEvento marca = EventosDePrueba.retiro(121);
        String json = EventosDePrueba.json(repetido);

        publicar(Topicos.RETIROS, "120", json);
        publicar(Topicos.RETIROS, "120", json);
        publicar(Topicos.RETIROS, "120", json);
        publicar(Topicos.RETIROS, "120", EventosDePrueba.json(marca));   // misma particion, despues de los tres

        esperarAuditado(marca.eventId());
        assertThat(auditados(repetido.eventId())).isEqualTo(1);
    }

    @Test
    @DisplayName("Un mensaje invalido va a la DLT SIN reintentos y NO bloquea la particion: el siguiente se guarda")
    void invalidoVaALaDltSinBloquear() throws Exception {
        String basura = "{\"esto\":\"no cumple el contrato\"," + System.nanoTime() + "}";
        SobreEvento siguiente = EventosDePrueba.retiro(122);

        publicar(Topicos.RETIROS, "122", basura);
        publicar(Topicos.RETIROS, "122", EventosDePrueba.json(siguiente));

        esperarAuditado(siguiente.eventId());
        Awaitility.await().atMost(30, TimeUnit.SECONDS).until(() -> jdbc.sql(
                "SELECT count(*) FROM carta_muerta WHERE payload = :p").param("p", basura)
                .query(Long.class).single() == 1);
        List<ConsumerRecord<String, String>> enLaDlt = KafkaDePrueba.leerHasta(Topicos.RETIROS + "-auditoria-dlt",
                leidos -> leidos.stream().anyMatch(r -> basura.equals(r.value())), Duration.ofSeconds(30));
        assertThat(enLaDlt).anyMatch(r -> basura.equals(r.value()));
    }

    @Test
    @DisplayName("Si la base falla un momento, el evento pasa por un topico de reintento, la particion sigue y al final se guarda")
    void caidaPasajeraDeLaBaseSeReintenta() throws Exception {
        SobreEvento enfermo = EventosDePrueba.retiro(130);
        SobreEvento sano = EventosDePrueba.retiro(131);
        AtomicInteger fallos = new AtomicInteger();
        // El evento "enfermo" falla las dos primeras veces (la base "se cae" un momento) y despues funciona.
        Mockito.doAnswer(invocacion -> {
            SobreEvento evento = invocacion.getArgument(0);
            if (evento.eventId().equals(enfermo.eventId()) && fallos.incrementAndGet() <= 2) {
                throw new DataAccessResourceFailureException("la base no responde (prueba)");
            }
            return invocacion.callRealMethod();
        }).when(repositorio).guardarSiNoEstaba(any(), anyString(), any(), anyInt(), anyLong());

        publicar(Topicos.RETIROS, "130", EventosDePrueba.json(enfermo));
        publicar(Topicos.RETIROS, "130", EventosDePrueba.json(sano));

        esperarAuditado(sano.eventId());           // la particion no se detuvo por el que fallaba
        esperarAuditado(enfermo.eventId());        // y el enfermo se guardo en el tercer intento
        assertThat(fallos.get()).as("fallo dos veces y a la tercera paso").isEqualTo(3);
        assertThat(jdbc.sql("SELECT count(*) FROM carta_muerta WHERE payload LIKE :p")
                .param("p", "%" + enfermo.eventId() + "%").query(Long.class).single())
                .as("no llego a la DLT").isZero();
    }
}
