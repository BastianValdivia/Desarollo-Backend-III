package cl.duoc.bancoxyz.auditoria;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import cl.duoc.bancoxyz.auditoria.api.ManejadorErroresAuditoria;
import cl.duoc.bancoxyz.auditoria.api.dto.RespuestaErrorAuditoria;
import jakarta.servlet.http.HttpServletRequest;

/**
 * La traduccion de errores del auditoria-service sin levantar Spring: una ruta inexistente es 404 (las dos
 * excepciones con que Spring puede decirlo) y un verbo no soportado es 405 con la cabecera {@code Allow}. Solo
 * lo imprevisto de verdad es 500. La seguridad responde antes (403) a un POST sobre la API, de modo que el 405
 * no se alcanza con MockMvc: se comprueba el manejador directamente.
 */
class ManejadorErroresAuditoriaTest {

    private final ManejadorErroresAuditoria manejador = new ManejadorErroresAuditoria();
    private final MockHttpServletRequest peticion = new MockHttpServletRequest("GET", "/internal/v1/auditoria/nada");

    @Test
    @DisplayName("Una ruta inexistente es 404 recurso_no_encontrado en problem+json")
    void rutaInexistente() {
        ResponseEntity<RespuestaErrorAuditoria> r = manejador.rutaInexistente(peticion);

        assertThat(r.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(r.getHeaders().getContentType()).isEqualTo(MediaType.APPLICATION_PROBLEM_JSON);
        assertThat(r.getBody().motivo()).isEqualTo("recurso_no_encontrado");
    }

    @Test
    @DisplayName("El manejador del 404 declara las dos excepciones con que Spring dice 'no existe' (si falta una, el "
            + "manejador general la atrapa y responde 500)")
    void declaraLasDosExcepciones() throws Exception {
        ExceptionHandler declaracion = ManejadorErroresAuditoria.class
                .getMethod("rutaInexistente", HttpServletRequest.class).getAnnotation(ExceptionHandler.class);

        assertThat(declaracion.value()).containsExactlyInAnyOrder(NoHandlerFoundException.class,
                NoResourceFoundException.class);
    }

    @Test
    @DisplayName("Un verbo no soportado es 405 con Allow y problem+json")
    void verboNoPermitido() {
        ResponseEntity<RespuestaErrorAuditoria> r = manejador.verboNoPermitido(
                new HttpRequestMethodNotSupportedException("DELETE", Set.of("GET", "HEAD")), peticion);

        assertThat(r.getStatusCode()).isEqualTo(HttpStatus.METHOD_NOT_ALLOWED);
        assertThat(r.getHeaders().getAllow()).contains(HttpMethod.GET);
        assertThat(r.getBody().motivo()).isEqualTo("metodo_no_permitido");
    }

    @Test
    @DisplayName("Lo imprevisto de verdad sigue siendo 500 error_interno")
    void imprevistoEs500() {
        ResponseEntity<RespuestaErrorAuditoria> r = manejador.inesperado(new IllegalStateException("x"), peticion);

        assertThat(r.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(r.getBody().motivo()).isEqualTo("error_interno");
    }
}
