package cl.duoc.bancoxyz.auditoria;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.simple.JdbcClient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import cl.duoc.bancoxyz.auditoria.aplicacion.RegistradorDeEventos;
import cl.duoc.bancoxyz.auditoria.aplicacion.RegistradorDeEventos.Resultado;
import cl.duoc.bancoxyz.auditoria.persistencia.RepositorioAuditoria;
import cl.duoc.bancoxyz.eventos.EventoInvalidoException;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

/**
 * La IDEMPOTENCIA del consumidor de auditoria, contra un PostgreSQL real (sin Spring ni Kafka: lo que se
 * prueba es la logica de guardar un evento).
 */
class RegistradorDeEventosTest {

    private static HikariDataSource pool;
    private static JdbcClient jdbc;

    private final SimpleMeterRegistry metricas = new SimpleMeterRegistry();
    private RegistradorDeEventos registrador;

    @BeforeAll
    static void preparar() {
        HikariConfig configuracion = new HikariConfig();
        configuracion.setJdbcUrl(PostgresDePrueba.nuevaBase());
        configuracion.setUsername(PostgresDePrueba.usuario());
        configuracion.setPassword(PostgresDePrueba.clave());
        configuracion.setMaximumPoolSize(8);
        pool = new HikariDataSource(configuracion);
        Flyway.configure().dataSource(pool).locations("classpath:db/migration").load().migrate();
        jdbc = JdbcClient.create(pool);
    }

    @AfterAll
    static void cerrar() {
        pool.close();
    }

    @BeforeEach
    void limpiar() {
        jdbc.sql("DELETE FROM evento_auditado").update();
        registrador = new RegistradorDeEventos(new RepositorioAuditoria(jdbc, new ObjectMapper()), metricas);
    }

    private static long guardados() {
        return jdbc.sql("SELECT count(*) FROM evento_auditado").query(Long.class).single();
    }

    @Test
    @DisplayName("Un retiro se guarda con su cuenta, su instante y su contenido intactos")
    void guardaUnRetiro() {
        SobreEvento evento = EventosDePrueba.retiro(116, Instant.parse("2026-10-03T12:34:56Z"));

        Resultado resultado = registrador.registrar(EventosDePrueba.json(evento), "bancoxyz.retiros.v1", "116", 2, 40L);

        assertThat(resultado).isEqualTo(Resultado.GUARDADO);
        var fila = jdbc.sql("""
                SELECT tipo, version, origen, topico, clave, particion, desplazamiento, cuenta_id, sujeto,
                       datos->>'folio' AS folio, datos->>'monto' AS monto, ocurrido_en
                  FROM evento_auditado WHERE event_id = :id::uuid""").param("id", evento.eventId())
                .query().singleRow();
        assertThat(fila.get("tipo")).isEqualTo("RETIRO_EJECUTADO");
        assertThat(fila.get("origen")).isEqualTo("core-service");
        assertThat(fila.get("clave")).isEqualTo("116");
        assertThat(fila.get("particion")).isEqualTo(2);
        assertThat(fila.get("desplazamiento")).isEqualTo(40L);
        assertThat(fila.get("cuenta_id")).isEqualTo(116);
        assertThat(fila.get("sujeto")).isNull();
        assertThat(fila.get("folio")).isEqualTo("RET-20261003-116");
        assertThat(fila.get("monto")).isEqualTo("1000.00");
        assertThat(((java.sql.Timestamp) fila.get("ocurrido_en")).toInstant()).isEqualTo(evento.ocurridoEn());
    }

    @Test
    @DisplayName("Un evento de seguridad se guarda con su sujeto (tarjeta enmascarada) y sin cuenta")
    void guardaUnEventoDeSeguridad() {
        SobreEvento evento = EventosDePrueba.pinIncorrecto("400000******0116", Instant.parse("2026-10-03T12:00:00Z"));

        registrador.registrar(EventosDePrueba.json(evento), "bancoxyz.seguridad.v1", "400000******0116", 1, 3L);

        var fila = jdbc.sql("SELECT cuenta_id, sujeto FROM evento_auditado").query().singleRow();
        assertThat(fila.get("cuenta_id")).isNull();
        assertThat(fila.get("sujeto")).isEqualTo("400000******0116");
    }

    @Test
    @DisplayName("IDEMPOTENCIA: el mismo evento recibido dos veces se guarda una sola vez")
    void repetidoSeDescarta() {
        String json = EventosDePrueba.json(EventosDePrueba.retiro(116));

        Resultado primero = registrador.registrar(json, "bancoxyz.retiros.v1", "116", 2, 40L);
        Resultado repetido = registrador.registrar(json, "bancoxyz.retiros.v1", "116", 2, 55L);

        assertThat(primero).isEqualTo(Resultado.GUARDADO);
        assertThat(repetido).isEqualTo(Resultado.DUPLICADO);
        assertThat(guardados()).isEqualTo(1);
        assertThat(metricas.counter("auditoria.guardados").count()).isEqualTo(1.0);
        assertThat(metricas.counter("auditoria.duplicados").count()).isEqualTo(1.0);
    }

    @Test
    @DisplayName("IDEMPOTENCIA entre replicas: el mismo evento recibido a la vez por seis hilos se guarda una sola vez")
    void repetidoSimultaneo() throws Exception {
        String json = EventosDePrueba.json(EventosDePrueba.retiro(105));
        int hilos = 6;
        CountDownLatch salida = new CountDownLatch(1);
        ExecutorService piscina = Executors.newFixedThreadPool(hilos);
        try {
            List<Future<Resultado>> futuros = new ArrayList<>();
            for (int i = 0; i < hilos; i++) {
                int desplazamiento = i;
                futuros.add(piscina.submit(() -> {
                    salida.await();
                    return registrador.registrar(json, "bancoxyz.retiros.v1", "105", 0, desplazamiento);
                }));
            }
            salida.countDown();
            List<Resultado> resultados = new ArrayList<>();
            for (Future<Resultado> futuro : futuros) {
                resultados.add(futuro.get(30, TimeUnit.SECONDS));
            }
            assertThat(resultados.stream().filter(r -> r == Resultado.GUARDADO)).hasSize(1);
            assertThat(resultados.stream().filter(r -> r == Resultado.DUPLICADO)).hasSize(hilos - 1);
        } finally {
            piscina.shutdownNow();
        }
        assertThat(guardados()).isEqualTo(1);
    }

    @Test
    @DisplayName("Un mensaje que incumple el contrato se rechaza como invalido y no deja rastro")
    void invalidoSeRechaza() {
        assertThatThrownBy(() -> registrador.registrar("esto no es json", "bancoxyz.retiros.v1", "1", 0, 0L))
                .isInstanceOf(EventoInvalidoException.class);
        assertThatThrownBy(() -> registrador.registrar("{\"eventId\":\"6f1b0d2e-1c4a-4a8e-9a53-0d6f3c6b1a11\","
                + "\"tipo\":\"TIPO_INVENTADO\",\"version\":1,\"ocurridoEn\":\"2026-10-03T12:00:00Z\","
                + "\"origen\":\"x\",\"datos\":{}}", "bancoxyz.retiros.v1", "1", 0, 0L))
                .isInstanceOf(EventoInvalidoException.class);

        assertThat(guardados()).isZero();
    }
}
