package cl.duoc.bancoxyz.auditoria;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Instant;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import cl.duoc.bancoxyz.auditoria.aplicacion.RegistradorDeEventos;
import cl.duoc.bancoxyz.eventos.soporte.KafkaDePrueba;

/**
 * La API de auditoria como servidor de recursos OAuth2, con la cadena de filtros real y tokens firmados de
 * verdad (el {@link EmisorDePrueba} hace de auth-server: publica un JWKS y firma): cada rechazo posible y la
 * lectura con el permiso correcto.
 *
 * <p>Es la prueba del criterio "auditoria-service exige token con {@code auditoria:leer}": sin token 401, token
 * malo 401, token valido de otro cliente sin el scope 403, y solo el token con scope y audiencia correctos 200.
 */
@SpringBootTest(properties = "spring.kafka.listener.auto-startup=false")
@AutoConfigureMockMvc
@ContextConfiguration(initializers = PostgresDePrueba.Inicializador.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class AuditoriaApiTest {

    private static final String EVENTOS = "/internal/v1/auditoria/eventos";
    private static final String RESUMEN = "/internal/v1/auditoria/resumen";

    @DynamicPropertySource
    static void propiedades(DynamicPropertyRegistry registro) {
        EmisorDePrueba.registrar(registro);
        registro.add("spring.kafka.bootstrap-servers", KafkaDePrueba::bootstrap);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private JdbcClient jdbc;
    @Autowired
    private RegistradorDeEventos registrador;

    private static String bearer(EmisorDePrueba.TokenDePrueba token) {
        return "Bearer " + token.emitir();
    }

    /** El token del BFF web: el scope y la audiencia que el auth-server le entrega. */
    private static EmisorDePrueba.TokenDePrueba tokenDelBffWeb() {
        return EmisorDePrueba.compartido().tokenDe("bff-web", "cuentas:leer", "movimientos:leer", "auditoria:leer")
                .conAudiencia("core-service", "auditoria-service");
    }

    @BeforeEach
    void sembrar() {
        jdbc.sql("DELETE FROM evento_auditado").update();
        registrar(EventosDePrueba.retiro(116, Instant.parse("2026-10-03T10:00:00Z")), "116", 0);
        registrar(EventosDePrueba.retiro(116, Instant.parse("2026-10-03T11:00:00Z")), "116", 1);
        registrar(EventosDePrueba.retiro(105, Instant.parse("2026-10-03T12:00:00Z")), "105", 2);
        registrar(EventosDePrueba.pinIncorrecto("400000******0116", Instant.parse("2026-10-03T13:00:00Z")),
                "400000******0116", 3);
    }

    private void registrar(cl.duoc.bancoxyz.eventos.SobreEvento evento, String clave, long desplazamiento) {
        String topico = evento.tipo().equals("RETIRO_EJECUTADO") ? "bancoxyz.retiros.v1" : "bancoxyz.seguridad.v1";
        registrador.registrar(EventosDePrueba.json(evento), topico, clave, 0, desplazamiento);
    }

    // ------------------------------------------------------------------------------------------
    // 401: el servicio no sabe quien llama
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Sin token: 401 token_ausente en problem+json, con WWW-Authenticate")
    void sinTokenEs401() throws Exception {
        mvc.perform(get(EVENTOS))
                .andExpect(status().isUnauthorized())
                .andExpect(header().exists("WWW-Authenticate"))
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("token_ausente"));
    }

    @Test
    @DisplayName("Token firmado por otra clave: 401 token_invalido")
    void firmaAjenaEs401() throws Exception {
        mvc.perform(get(EVENTOS).header("Authorization", bearer(tokenDelBffWeb().firmadoPorOtraClave())))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_invalido"));
    }

    @Test
    @DisplayName("Token vencido: 401 token_invalido")
    void vencidoEs401() throws Exception {
        mvc.perform(get(EVENTOS).header("Authorization", bearer(tokenDelBffWeb().vencido())))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_invalido"));
    }

    @Test
    @DisplayName("Token de otro emisor: 401 token_invalido")
    void emisorAjenoEs401() throws Exception {
        mvc.perform(get(EVENTOS).header("Authorization", bearer(tokenDelBffWeb().conEmisor("https://otro-emisor:9000"))))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_invalido"));
    }

    @Test
    @DisplayName("Token con el scope correcto pero emitido SOLO para el core (otra audiencia): 401")
    void audienciaIncorrectaEs401() throws Exception {
        mvc.perform(get(EVENTOS).header("Authorization", bearer(tokenDelBffWeb().conAudiencia("core-service"))))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.motivo").value("token_invalido"));
    }

    // ------------------------------------------------------------------------------------------
    // 403: el servicio sabe quien llama y no se lo permite
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Token valido y con la audiencia correcta pero SIN el scope auditoria:leer (el del BFF movil): 403")
    void sinElScopeEs403() throws Exception {
        var tokenDelMovil = EmisorDePrueba.compartido().tokenDe("bff-mobile", "cuentas:leer")
                .conAudiencia("auditoria-service");

        mvc.perform(get(EVENTOS).header("Authorization", bearer(tokenDelMovil)))
                .andExpect(status().isForbidden())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("permiso_insuficiente"));
        mvc.perform(get(RESUMEN).header("Authorization", bearer(tokenDelMovil)))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("Todo lo que no es /internal/v1/auditoria/** se deniega, aun con el scope correcto (denegacion por defecto)")
    void otrasRutasSeDenieganSiempre() throws Exception {
        mvc.perform(get("/internal/v1/otra-cosa").header("Authorization", bearer(tokenDelBffWeb())))
                .andExpect(status().isForbidden());
        mvc.perform(get("/actuator/health").header("Authorization", bearer(tokenDelBffWeb())))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("Solo se lee: un POST con el token correcto no existe para este servicio (403)")
    void escribirNoSePermite() throws Exception {
        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post(EVENTOS)
                        .header("Authorization", bearer(tokenDelBffWeb())))
                .andExpect(status().isForbidden());
    }

    // ------------------------------------------------------------------------------------------
    // 200: la lectura
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Con el token del BFF web (scope y audiencia correctos): 200, del evento mas reciente al mas antiguo")
    void listaDelMasRecienteAlMasAntiguo() throws Exception {
        mvc.perform(get(EVENTOS).header("Authorization", bearer(tokenDelBffWeb())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(4))
                .andExpect(jsonPath("$.pagina").value(0))
                .andExpect(jsonPath("$.tamano").value(20))
                .andExpect(jsonPath("$.eventos.length()").value(4))
                .andExpect(jsonPath("$.eventos[0].tipo").value("PIN_INCORRECTO"))
                .andExpect(jsonPath("$.eventos[0].datos.sujeto").value("400000******0116"))
                .andExpect(jsonPath("$.eventos[1].datos.cuentaId").value(105))
                .andExpect(jsonPath("$.eventos[3].ocurridoEn").value("2026-10-03T10:00:00Z"));
    }

    @Test
    @DisplayName("Filtra por cuenta, por tipo y por sujeto, y pagina con tamano acotado al maximo")
    void filtrosYPaginacion() throws Exception {
        String auth = bearer(tokenDelBffWeb());
        mvc.perform(get(EVENTOS).param("cuenta", "116").header("Authorization", auth))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(2))
                .andExpect(jsonPath("$.eventos[0].datos.cuentaId").value(116));
        mvc.perform(get(EVENTOS).param("tipo", "PIN_INCORRECTO").header("Authorization", auth))
                .andExpect(jsonPath("$.total").value(1));
        mvc.perform(get(EVENTOS).param("sujeto", "400000******0116").header("Authorization", auth))
                .andExpect(jsonPath("$.total").value(1));
        mvc.perform(get(EVENTOS).param("cuenta", "999").header("Authorization", auth))
                .andExpect(jsonPath("$.total").value(0))
                .andExpect(jsonPath("$.eventos.length()").value(0));
        mvc.perform(get(EVENTOS).param("tamano", "2").param("pagina", "1").header("Authorization", auth))
                .andExpect(jsonPath("$.eventos.length()").value(2))
                .andExpect(jsonPath("$.eventos[0].ocurridoEn").value("2026-10-03T11:00:00Z"));
        mvc.perform(get(EVENTOS).param("tamano", "100000").header("Authorization", auth))
                .andExpect(jsonPath("$.tamano").value(100));
    }

    @Test
    @DisplayName("Un tipo de evento que no existe es 400 en problem+json (no un 500)")
    void tipoInexistenteEs400() throws Exception {
        mvc.perform(get(EVENTOS).param("tipo", "TIPO_INVENTADO").header("Authorization", bearer(tokenDelBffWeb())))
                .andExpect(status().isBadRequest())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("peticion_invalida"));
        mvc.perform(get(EVENTOS).param("cuenta", "abc").header("Authorization", bearer(tokenDelBffWeb())))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Una ruta de la API que no existe es 404 en problem+json (no un 500 con traza), con token valido")
    void rutaInexistenteEs404() throws Exception {
        mvc.perform(get("/internal/v1/auditoria/nada").header("Authorization", bearer(tokenDelBffWeb())))
                .andExpect(status().isNotFound())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.motivo").value("recurso_no_encontrado"));
    }

    @Test
    @DisplayName("El resumen cuenta los eventos por tipo")
    void resumenPorTipo() throws Exception {
        mvc.perform(get(RESUMEN).header("Authorization", bearer(tokenDelBffWeb())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(4))
                .andExpect(jsonPath("$.porTipo.RETIRO_EJECUTADO").value(3))
                .andExpect(jsonPath("$.porTipo.PIN_INCORRECTO").value(1));
    }

    @Test
    @DisplayName("Una URL con secuencias que el firewall rechaza responde 400 en problem+json, aun con token valido")
    void urlRechazadaPorElFirewallEs400() throws Exception {
        mvc.perform(get("/internal/v1/auditoria/eventos;x=1").header("Authorization", bearer(tokenDelBffWeb())))
                .andExpect(status().isBadRequest());
    }
}
