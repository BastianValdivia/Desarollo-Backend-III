-- =====================================================================
-- auditoria-service, V1: esquema inicial de la base "auditoria".
-- =====================================================================
-- Un registro por evento del banco que llego por Kafka, y la carta muerta (DLT) con su causa.

-- El event_id del sobre es la clave primaria: ES la idempotencia. Kafka entrega "al menos una vez", asi que
-- un evento puede llegar repetido; el segundo INSERT ... ON CONFLICT DO NOTHING no inserta nada y el
-- servicio sabe que ya lo tenia. No hace falta una tabla aparte de "procesados" (como en notificaciones):
-- aqui el propio registro auditado es la marca.
CREATE TABLE evento_auditado (
    event_id       uuid         PRIMARY KEY,
    tipo           varchar(60)  NOT NULL,
    version        integer      NOT NULL,
    -- Cuando ocurrio el hecho (viene en el evento), no cuando llego: la auditoria se ordena por esto.
    ocurrido_en    timestamptz  NOT NULL,
    origen         varchar(60)  NOT NULL,
    topico         varchar(160) NOT NULL,
    clave          varchar(160),
    particion      integer      NOT NULL,
    desplazamiento bigint       NOT NULL,
    -- jsonb: se puede consultar por dentro y el contenido no se altera (el sobre completo no hace falta).
    datos          jsonb        NOT NULL,
    -- Columnas derivadas de "datos", para filtrar sin recorrer el JSON: la cuenta (eventos de retiro) y el
    -- usuario o la tarjeta enmascarada (eventos de seguridad).
    cuenta_id      integer,
    sujeto         varchar(160),
    recibido_en    timestamptz  NOT NULL DEFAULT now()
);
CREATE INDEX evento_auditado_por_fecha ON evento_auditado (ocurrido_en DESC, event_id);
CREATE INDEX evento_auditado_por_cuenta ON evento_auditado (cuenta_id, ocurrido_en DESC) WHERE cuenta_id IS NOT NULL;
CREATE INDEX evento_auditado_por_tipo ON evento_auditado (tipo, ocurrido_en DESC);

-- La DLT: lo que no se pudo guardar tras los reintentos, o que nunca pudo guardarse (mensaje invalido).
CREATE TABLE carta_muerta (
    id                bigint       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    topico_original   varchar(160) NOT NULL,
    particion         integer,
    desplazamiento    bigint,
    clave             varchar(160),
    payload           text,
    motivo            text         NOT NULL,
    recibida_en       timestamptz  NOT NULL DEFAULT now()
);
