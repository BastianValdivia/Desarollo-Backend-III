package cl.duoc.bancoxyz.auditoria.api.dto;

import org.springframework.http.HttpStatus;

/**
 * Cuerpo de error del auditoria-service, con el formato <strong>RFC 7807</strong>
 * ({@code application/problem+json}), el mismo que usa el core.
 *
 * <p>Es la unica forma en que este servicio comunica un fallo, venga de la cadena de seguridad (401, 403),
 * del firewall (400) o de un controlador: un cliente (el BFF web) puede tratar todos los rechazos igual. El
 * campo {@code motivo} es un codigo estable en minusculas ({@code token_ausente}, {@code token_invalido},
 * {@code permiso_insuficiente}, {@code peticion_invalida}); el {@code detail} nunca revela por que fallo una
 * validacion de token (le servira a quien quiera fabricar uno).
 *
 * @param type     URI estable que identifica el tipo de error
 * @param title    titulo corto
 * @param status   codigo HTTP
 * @param detail   explicacion para una persona
 * @param instance ruta de la peticion
 * @param motivo   codigo estable del motivo
 */
public record RespuestaErrorAuditoria(
        String type,
        String title,
        int status,
        String detail,
        String instance,
        String motivo) {

    private static final String CATALOGO = "https://bancoxyz.duoc.cl/errores/";

    public static RespuestaErrorAuditoria de(HttpStatus estado, String titulo, String motivo,
                                             String detalle, String ruta) {
        return new RespuestaErrorAuditoria(
                CATALOGO + motivo.replace('_', '-'),
                titulo,
                estado.value(),
                detalle,
                ruta,
                motivo);
    }
}
