package cl.duoc.bancoxyz.auditoria.api;

import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.bancoxyz.auditoria.api.dto.PaginaEventosResponse;
import cl.duoc.bancoxyz.auditoria.api.dto.ResumenAuditoriaResponse;
import cl.duoc.bancoxyz.auditoria.persistencia.RepositorioAuditoria;
import cl.duoc.bancoxyz.eventos.TiposEvento;

/**
 * La API de lectura de la auditoria. Solo lectura, y solo para quien tenga el scope {@code auditoria:leer}
 * (la cadena de filtros {@code SeguridadAuditoriaConfig} lo exige antes de llegar aqui: este controlador no
 * comprueba permisos).
 *
 * <p>Rutas reales (puerto de servicio, red interna; el unico cliente es el BFF web):
 * <ul>
 *   <li>{@code GET /internal/v1/auditoria/eventos?tipo=&cuenta=&sujeto=&pagina=&tamano=}: eventos del mas
 *       reciente al mas antiguo, con filtros opcionales.</li>
 *   <li>{@code GET /internal/v1/auditoria/resumen}: cuantos eventos hay, en total y por tipo.</li>
 * </ul>
 */
@RestController
@RequestMapping(value = "/internal/v1/auditoria", produces = MediaType.APPLICATION_JSON_VALUE)
public class AuditoriaController {

    private final RepositorioAuditoria repositorio;
    private final AuditoriaProperties propiedades;

    public AuditoriaController(RepositorioAuditoria repositorio, AuditoriaProperties propiedades) {
        this.repositorio = repositorio;
        this.propiedades = propiedades;
    }

    /**
     * @param tipo   solo eventos de este tipo (por ejemplo {@code RETIRO_EJECUTADO}); si no es un tipo conocido,
     *               400
     * @param cuenta solo eventos de retiro de esta cuenta
     * @param sujeto solo eventos de seguridad de este usuario o tarjeta enmascarada
     * @param pagina pagina pedida, desde 0 (ausente o negativa vale 0)
     * @param tamano tamano pedido (ausente o menor que 1 vale el de por defecto; se recorta al maximo)
     */
    @GetMapping("/eventos")
    public PaginaEventosResponse listar(
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) Integer cuenta,
            @RequestParam(required = false) String sujeto,
            @RequestParam(required = false) Integer pagina,
            @RequestParam(required = false) Integer tamano) {

        if (tipo != null && !tipoConocido(tipo)) {
            throw new IllegalArgumentException("El tipo de evento no existe: " + tipo);
        }
        int paginaPedida = pagina == null || pagina < 0 ? 0 : pagina;
        int tamanoPedido = tamano == null || tamano < 1
                ? propiedades.paginacion().tamanoPorDefecto()
                : Math.min(tamano, propiedades.paginacion().tamanoMaximo());

        return new PaginaEventosResponse(
                repositorio.listar(tipo, cuenta, sujeto, paginaPedida, tamanoPedido),
                paginaPedida, tamanoPedido, repositorio.contar(tipo, cuenta, sujeto));
    }

    @GetMapping("/resumen")
    public ResumenAuditoriaResponse resumen() {
        Map<String, Long> porTipo = repositorio.contarPorTipo();
        return new ResumenAuditoriaResponse(porTipo.values().stream().mapToLong(Long::longValue).sum(), porTipo);
    }

    private static boolean tipoConocido(String tipo) {
        return TiposEvento.soportado(tipo, 1);
    }
}
