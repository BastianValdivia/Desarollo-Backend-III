package cl.duoc.bancoxyz.auditoria.api.dto;

import java.util.Map;

/**
 * Cuantos eventos hay auditados, en total y por tipo.
 *
 * @param total   todos los eventos
 * @param porTipo cantidad por tipo de evento, ordenado por tipo
 */
public record ResumenAuditoriaResponse(long total, Map<String, Long> porTipo) {
}
