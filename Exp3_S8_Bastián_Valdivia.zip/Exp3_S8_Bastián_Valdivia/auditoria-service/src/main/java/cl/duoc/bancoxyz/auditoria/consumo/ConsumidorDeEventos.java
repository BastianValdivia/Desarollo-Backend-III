package cl.duoc.bancoxyz.auditoria.consumo;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.DltHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.retrytopic.DltStrategy;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.retry.annotation.Backoff;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.eventos.EventoInvalidoException;
import cl.duoc.bancoxyz.eventos.Topicos;
import cl.duoc.bancoxyz.auditoria.aplicacion.RegistradorDeEventos;
import cl.duoc.bancoxyz.auditoria.persistencia.RepositorioAuditoria;

/**
 * El consumidor de Kafka de la auditoria: escucha los dos topicos en el grupo {@code auditoria}.
 *
 * <p>Es un grupo DISTINTO del de notificaciones: cada grupo recibe todos los eventos y avanza por su cuenta,
 * asi que si uno se atrasa o cae, el otro no se entera. Dentro del grupo, las replicas (si se agregan) se
 * reparten las particiones.
 *
 * <p>Reintentos NO bloqueantes y DLT, igual que en notificaciones: un fallo transitorio (la base) manda el
 * evento a un topico de reintento con espera y la particion principal sigue; al agotar los intentos, o si el
 * mensaje es invalido ({@link EventoInvalidoException}, que no se reintenta), va a la DLT
 * ({@code <topico>-auditoria-dlt}). Los nombres llevan el del grupo para no mezclarse con los de
 * notificaciones sobre los mismos topicos.
 */
@Component
public class ConsumidorDeEventos {

    private static final Logger log = LoggerFactory.getLogger(ConsumidorDeEventos.class);

    private final RegistradorDeEventos registrador;
    private final RepositorioAuditoria repositorio;

    public ConsumidorDeEventos(RegistradorDeEventos registrador, RepositorioAuditoria repositorio) {
        this.registrador = registrador;
        this.repositorio = repositorio;
    }

    @RetryableTopic(
            attempts = "${auditoria.reintentos.intentos:5}",
            backoff = @Backoff(
                    delayExpression = "${auditoria.reintentos.espera-ms:2000}",
                    multiplierExpression = "${auditoria.reintentos.multiplicador:2.0}",
                    maxDelayExpression = "${auditoria.reintentos.espera-maxima-ms:20000}"),
            numPartitions = "3",
            replicationFactor = "1",
            retryTopicSuffix = "-auditoria-retry",
            dltTopicSuffix = "-auditoria-dlt",
            exclude = EventoInvalidoException.class,
            dltStrategy = DltStrategy.FAIL_ON_ERROR)
    @KafkaListener(
            id = "auditoria-eventos",
            groupId = "${auditoria.grupo:auditoria}",
            topics = {Topicos.RETIROS, Topicos.SEGURIDAD})
    public void consumir(ConsumerRecord<String, String> registro) {
        registrador.registrar(registro.value(), registro.topic(), registro.key(), registro.partition(), registro.offset());
    }

    /**
     * La DLT: el mensaje ya no se reintenta. Los datos de origen y la causa viajan en las cabeceras que agrega
     * Spring Kafka al publicar en la DLT ({@code kafka_original-*} y {@code kafka_exception-*}). Se deja constancia (log y tabla {@code carta_muerta}) con su causa,
     * para que una persona lo revise. No relanza nada: una excepcion aqui bloquearia la propia DLT.
     */
    @DltHandler
    public void cartaMuerta(ConsumerRecord<String, String> registro) {
        String topicoOriginal = comoTexto(registro.headers().lastHeader(KafkaHeaders.ORIGINAL_TOPIC));
        Integer particion = comoEntero(registro.headers().lastHeader(KafkaHeaders.ORIGINAL_PARTITION));
        Long desplazamiento = comoLargo(registro.headers().lastHeader(KafkaHeaders.ORIGINAL_OFFSET));
        String motivo = comoTexto(registro.headers().lastHeader(KafkaHeaders.EXCEPTION_MESSAGE));
        if (topicoOriginal == null) {
            topicoOriginal = registro.topic();
        }
        log.error("DLT: mensaje de {} [{}@{}] clave {} descartado tras agotar los reintentos o por invalido. "
                        + "Motivo: {}", topicoOriginal, particion, desplazamiento, registro.key(), motivo);
        repositorio.guardarCartaMuerta(topicoOriginal, particion, desplazamiento, registro.key(), registro.value(),
                motivo == null ? "sin motivo registrado" : motivo);
    }

    private static String comoTexto(Header cabecera) {
        return cabecera == null ? null : new String(cabecera.value(), StandardCharsets.UTF_8);
    }

    private static Integer comoEntero(Header cabecera) {
        return cabecera == null || cabecera.value().length != Integer.BYTES
                ? null : ByteBuffer.wrap(cabecera.value()).getInt();
    }

    private static Long comoLargo(Header cabecera) {
        return cabecera == null || cabecera.value().length != Long.BYTES
                ? null : ByteBuffer.wrap(cabecera.value()).getLong();
    }
}
