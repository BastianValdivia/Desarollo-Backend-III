package cl.duoc.bancoxyz.auditoria.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import cl.duoc.bancoxyz.auditoria.api.dto.RespuestaErrorAuditoria;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Traduce los errores de la API de consulta a {@code application/problem+json} (RFC 7807), el mismo formato
 * que el resto de los servicios internos. Sin esto, un parametro mal escrito acabaria en una respuesta de
 * error generica del contenedor.
 */
@RestControllerAdvice
public class ManejadorErroresAuditoria {

    private static final Logger log = LoggerFactory.getLogger(ManejadorErroresAuditoria.class);

    @ExceptionHandler({IllegalArgumentException.class, MethodArgumentTypeMismatchException.class})
    public ResponseEntity<RespuestaErrorAuditoria> peticionInvalida(Exception e, HttpServletRequest peticion) {
        log.warn("Peticion invalida a {}: {}", peticion.getRequestURI(), e.getMessage());
        return responder(HttpStatus.BAD_REQUEST, "Peticion invalida", "peticion_invalida",
                "Un parametro de la consulta no es valido", peticion);
    }

    /**
     * Una ruta que no existe es un 404, no una averia. Se declaran las DOS excepciones porque desde Spring
     * Framework 6.1 una ruta sin controlador cae en el manejador de recursos estaticos y lanza
     * {@code NoResourceFoundException} ({@code NoHandlerFoundException} es la clasica). Sin esto las atrapaba el
     * manejador general de abajo y respondian 500 con una traza en el log, tanto en la API como en el puerto de
     * gestion (donde {@code /actuator/env}, {@code /configprops} y {@code /heapdump} deben ser 404, como en los
     * demas servicios).
     *
     * <p>No distingue "la ruta no existe" de "el recurso no existe": a quien sondea solo le diria cuales de las
     * rutas que adivina son correctas.
     */
    @ExceptionHandler({NoHandlerFoundException.class, NoResourceFoundException.class})
    public ResponseEntity<RespuestaErrorAuditoria> rutaInexistente(HttpServletRequest peticion) {
        return responder(HttpStatus.NOT_FOUND, "Recurso no encontrado", "recurso_no_encontrado",
                "No existe el recurso solicitado en este servicio", peticion);
    }

    /** La ruta existe pero no acepta ese verbo: 405 y no 404 (Spring agrega la cabecera {@code Allow} al error). */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<RespuestaErrorAuditoria> verboNoPermitido(HttpRequestMethodNotSupportedException e,
                                                                    HttpServletRequest peticion) {
        ResponseEntity.BodyBuilder respuesta = ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED)
                .contentType(MediaType.APPLICATION_PROBLEM_JSON);
        if (e.getSupportedHttpMethods() != null) {
            respuesta.allow(e.getSupportedHttpMethods().toArray(new org.springframework.http.HttpMethod[0]));
        }
        return respuesta.body(RespuestaErrorAuditoria.de(HttpStatus.METHOD_NOT_ALLOWED, "Metodo no permitido",
                "metodo_no_permitido", "El recurso existe pero no acepta el verbo " + e.getMethod(),
                peticion.getRequestURI()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<RespuestaErrorAuditoria> inesperado(Exception e, HttpServletRequest peticion) {
        log.error("Error inesperado en {}", peticion.getRequestURI(), e);
        return responder(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno", "error_interno",
                "El servicio no pudo atender la consulta", peticion);
    }

    private static ResponseEntity<RespuestaErrorAuditoria> responder(HttpStatus estado, String titulo, String motivo,
                                                                     String detalle, HttpServletRequest peticion) {
        return ResponseEntity.status(estado).contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .body(RespuestaErrorAuditoria.de(estado, titulo, motivo, detalle, peticion.getRequestURI()));
    }
}
