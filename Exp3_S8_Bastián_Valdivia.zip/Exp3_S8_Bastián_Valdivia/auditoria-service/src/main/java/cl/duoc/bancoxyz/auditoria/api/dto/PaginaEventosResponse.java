package cl.duoc.bancoxyz.auditoria.api.dto;

import java.util.List;

import cl.duoc.bancoxyz.auditoria.persistencia.EventoAuditado;

/**
 * Una pagina de eventos auditados, del mas reciente al mas antiguo.
 *
 * @param eventos     los eventos de la pagina
 * @param pagina      numero de pagina, desde 0
 * @param tamano      tamano pedido (ya acotado al maximo)
 * @param total       cuantos eventos cumplen el filtro en total
 */
public record PaginaEventosResponse(List<EventoAuditado> eventos, int pagina, int tamano, long total) {
}
