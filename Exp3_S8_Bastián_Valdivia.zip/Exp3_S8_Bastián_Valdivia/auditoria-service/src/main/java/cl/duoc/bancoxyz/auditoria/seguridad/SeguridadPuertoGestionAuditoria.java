package cl.duoc.bancoxyz.auditoria.seguridad;

import org.springframework.boot.actuate.autoconfigure.web.server.ConditionalOnManagementPort;
import org.springframework.boot.actuate.autoconfigure.web.server.ManagementPortType;
import org.springframework.boot.web.context.WebServerApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Deja pasar sin token el <strong>puerto de gestion</strong> (Actuator), que no es el del servicio (copia de la del core).
 *
 * <p>Al agregar Spring Security, su cadena de filtros tambien se aplica al servidor de gestion (un
 * contexto hijo con su propio puerto): sin esta cadena, {@code /actuator/health} pediria un token y el
 * healthcheck de Docker marcaria al servicio como caido. El puerto de gestion no se publica (en local solo
 * escucha en 127.0.0.1 y en Docker no se mapea al host) y solo expone {@code health, info, metrics y
 * refresh}; es la misma decision de frontera de confianza que toman los tres BFF.
 *
 * <p><strong>Por que esta copia y no la clase de la libreria compartida.</strong> Es la misma regla que
 * {@code SeguridadPuertoGestionConfig} de {@code plataforma-comun}, repetida en pocas lineas: este servicio
 * no depende de ese modulo (es de los BFF), y traer la libreria entera por una cadena de filtros seria peor
 * que la repeticion.
 *
 * <p>Solo se activa cuando el puerto de gestion es DISTINTO del de servicio, y el emparejador distingue
 * por el contexto que atiende la peticion y no por la ruta: un {@code /actuator/...} pedido al puerto
 * de servicio no coincide y cae en la cadena del servicio, que lo rechaza.
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnManagementPort(ManagementPortType.DIFFERENT)
public class SeguridadPuertoGestionAuditoria {

    private static final RequestMatcher PETICION_AL_PUERTO_DE_GESTION = peticion -> {
        WebApplicationContext contexto =
                WebApplicationContextUtils.getWebApplicationContext(peticion.getServletContext());
        return contexto != null && WebServerApplicationContext.hasServerNamespace(contexto, "management");
    };

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    public SecurityFilterChain cadenaDelPuertoDeGestion(HttpSecurity http) throws Exception {
        http
                .securityMatcher(PETICION_AL_PUERTO_DE_GESTION)
                .authorizeHttpRequests(reglas -> reglas.anyRequest().permitAll())
                // refresh es un POST sin sesion ni cookies: no hay navegador con una sesion que explotar.
                .csrf(csrf -> csrf.disable())
                .sessionManagement(sesion -> sesion.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
        return http.build();
    }
}
