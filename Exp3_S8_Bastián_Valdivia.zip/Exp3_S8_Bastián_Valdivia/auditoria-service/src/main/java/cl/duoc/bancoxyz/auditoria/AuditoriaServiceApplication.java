package cl.duoc.bancoxyz.auditoria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Punto de entrada del <strong>auditoria-service</strong>: guarda cada evento del banco que llega por Kafka y
 * lo ofrece a quien tenga permiso de leerlo (el panel del ejecutivo del canal web).
 *
 * <p>Dos caras, un mismo servicio: consume los eventos en el grupo {@code auditoria} (su propio grupo, para
 * recibir TODOS los eventos independientemente de notificaciones-service) y expone la API de consulta
 * {@code /internal/v1/auditoria/**}, protegida por OAuth2 (scope {@code auditoria:leer}, audiencia
 * {@code auditoria-service}).
 *
 * <p>Sin logica: la clase principal solo dispara el escaneo de componentes.
 */
/*
 * @SpringBootApplication escanea componentes pero NO clases @ConfigurationProperties: sin esta segunda anotacion
 * AuditoriaProperties no se registra y el arranque muere con un mensaje que no apunta a la causa.
 */
@SpringBootApplication
@ConfigurationPropertiesScan("cl.duoc.bancoxyz.auditoria")
public class AuditoriaServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuditoriaServiceApplication.class, args);
    }
}
