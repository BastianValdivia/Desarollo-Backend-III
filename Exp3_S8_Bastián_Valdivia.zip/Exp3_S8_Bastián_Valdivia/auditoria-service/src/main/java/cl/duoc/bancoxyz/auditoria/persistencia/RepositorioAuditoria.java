package cl.duoc.bancoxyz.auditoria.persistencia;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import cl.duoc.bancoxyz.eventos.DatosRetiro;
import cl.duoc.bancoxyz.eventos.DatosSeguridad;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.TiposEvento;

/**
 * Acceso a la base "auditoria" (JDBC, sin ORM, igual que el core y notificaciones).
 */
@Repository
public class RepositorioAuditoria {

    private final JdbcClient jdbc;
    private final ObjectMapper json;

    public RepositorioAuditoria(JdbcClient jdbc, ObjectMapper json) {
        this.jdbc = jdbc;
        this.json = json;
    }

    /**
     * Guarda el evento si no estaba.
     *
     * @return {@code true} si es la primera vez que se ve este {@code eventId}; {@code false} si ya estaba (un
     *         repetido). Una sola sentencia atomica: si dos replicas reciben el mismo evento a la vez, la clave
     *         primaria hace esperar a la segunda hasta que la primera confirme, y esa segunda ve el conflicto.
     */
    public boolean guardarSiNoEstaba(SobreEvento evento, String topico, String clave, int particion,
                                     long desplazamiento) {
        Integer cuenta = null;
        String sujeto = null;
        if (TiposEvento.RETIRO_EJECUTADO.equals(evento.tipo())) {
            cuenta = evento.datosComo(DatosRetiro.class).cuentaId();
        } else if (TiposEvento.esDeSeguridad(evento.tipo())) {
            sujeto = evento.datosComo(DatosSeguridad.class).sujeto();
        }
        return jdbc.sql("""
                        INSERT INTO evento_auditado (event_id, tipo, version, ocurrido_en, origen, topico, clave,
                                                     particion, desplazamiento, datos, cuenta_id, sujeto)
                        VALUES (:id, :tipo, :version, :ocurrido, :origen, :topico, :clave,
                                :particion, :desplazamiento, CAST(:datos AS jsonb), :cuenta, :sujeto)
                        ON CONFLICT (event_id) DO NOTHING""")
                .param("id", UUID.fromString(evento.eventId()))
                .param("tipo", evento.tipo())
                .param("version", evento.version())
                .param("ocurrido", Timestamp.from(evento.ocurridoEn()))
                .param("origen", evento.origen())
                .param("topico", topico)
                .param("clave", clave)
                .param("particion", particion)
                .param("desplazamiento", desplazamiento)
                .param("datos", evento.datos().toString())
                .param("cuenta", cuenta)
                .param("sujeto", sujeto)
                .update() == 1;
    }

    /**
     * Una pagina de eventos, del mas reciente al mas antiguo (por cuando ocurrieron).
     *
     * @param tipo   filtra por tipo, o {@code null}
     * @param cuenta filtra por cuenta (eventos de retiro), o {@code null}
     * @param sujeto filtra por usuario o tarjeta enmascarada (eventos de seguridad), o {@code null}
     */
    public List<EventoAuditado> listar(String tipo, Integer cuenta, String sujeto, int pagina, int tamano) {
        Filtro filtro = filtro(tipo, cuenta, sujeto);
        var consulta = jdbc.sql("""
                        SELECT event_id, tipo, version, ocurrido_en, origen, topico, clave, datos
                          FROM evento_auditado""" + filtro.where
                        + " ORDER BY ocurrido_en DESC, event_id LIMIT :limite OFFSET :desde");
        for (Map.Entry<String, Object> p : filtro.parametros.entrySet()) {
            consulta = consulta.param(p.getKey(), p.getValue());
        }
        return consulta.param("limite", tamano).param("desde", (long) pagina * tamano)
                .query((rs, fila) -> new EventoAuditado(
                        rs.getString("event_id"), rs.getString("tipo"), rs.getInt("version"),
                        rs.getTimestamp("ocurrido_en").toInstant(), rs.getString("origen"),
                        rs.getString("topico"), rs.getString("clave"), leerJson(rs.getString("datos"))))
                .list();
    }

    public long contar(String tipo, Integer cuenta, String sujeto) {
        Filtro filtro = filtro(tipo, cuenta, sujeto);
        var consulta = jdbc.sql("SELECT count(*) FROM evento_auditado" + filtro.where);
        for (Map.Entry<String, Object> p : filtro.parametros.entrySet()) {
            consulta = consulta.param(p.getKey(), p.getValue());
        }
        return consulta.query(Long.class).single();
    }

    /** Cuantos eventos hay de cada tipo, ordenados por tipo. */
    public Map<String, Long> contarPorTipo() {
        Map<String, Long> porTipo = new LinkedHashMap<>();
        jdbc.sql("SELECT tipo, count(*) AS n FROM evento_auditado GROUP BY tipo ORDER BY tipo")
                .query((rs, fila) -> porTipo.put(rs.getString("tipo"), rs.getLong("n"))).list();
        return porTipo;
    }

    public void guardarCartaMuerta(String topicoOriginal, Integer particion, Long desplazamiento, String clave,
                                   String payload, String motivo) {
        jdbc.sql("""
                        INSERT INTO carta_muerta (topico_original, particion, desplazamiento, clave, payload, motivo)
                        VALUES (:topico, :particion, :desplazamiento, :clave, :payload, :motivo)""")
                .param("topico", topicoOriginal)
                .param("particion", particion)
                .param("desplazamiento", desplazamiento)
                .param("clave", clave)
                .param("payload", payload)
                .param("motivo", motivo)
                .update();
    }

    /** WHERE dinamico: solo incluye los filtros que se pidieron, y siempre con parametros (sin concatenar valores). */
    private record Filtro(String where, Map<String, Object> parametros) {
    }

    private static Filtro filtro(String tipo, Integer cuenta, String sujeto) {
        StringBuilder where = new StringBuilder();
        Map<String, Object> parametros = new LinkedHashMap<>();
        if (tipo != null) {
            where.append(where.isEmpty() ? " WHERE " : " AND ").append("tipo = :tipo");
            parametros.put("tipo", tipo);
        }
        if (cuenta != null) {
            where.append(where.isEmpty() ? " WHERE " : " AND ").append("cuenta_id = :cuenta");
            parametros.put("cuenta", cuenta);
        }
        if (sujeto != null) {
            where.append(where.isEmpty() ? " WHERE " : " AND ").append("sujeto = :sujeto");
            parametros.put("sujeto", sujeto);
        }
        return new Filtro(where.toString(), parametros);
    }

    private JsonNode leerJson(String texto) {
        try {
            return json.readTree(texto);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("El campo datos guardado no es JSON valido", e);
        }
    }
}
