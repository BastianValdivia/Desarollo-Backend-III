package cl.duoc.bancoxyz.auditoria.persistencia;

import java.time.Instant;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Un evento ya guardado en la auditoria, tal como lo lee la API.
 *
 * @param eventId     identificador del evento
 * @param tipo        tipo (RETIRO_EJECUTADO, PIN_INCORRECTO, ...)
 * @param version     version del formato de {@code datos}
 * @param ocurridoEn  cuando ocurrio el hecho
 * @param origen      servicio que lo emitio
 * @param topico      topico por donde llego
 * @param clave       clave del registro de Kafka (cuenta, usuario o tarjeta enmascarada)
 * @param datos       el contenido del evento
 */
public record EventoAuditado(String eventId, String tipo, int version, Instant ocurridoEn, String origen,
                             String topico, String clave, JsonNode datos) {
}
