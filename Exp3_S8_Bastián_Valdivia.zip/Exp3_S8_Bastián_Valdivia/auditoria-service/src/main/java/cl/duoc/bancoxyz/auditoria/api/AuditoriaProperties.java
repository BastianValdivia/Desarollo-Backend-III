package cl.duoc.bancoxyz.auditoria.api;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Limites de la API de consulta, bajo el prefijo {@code auditoria.paginacion}.
 *
 * <p>El maximo se valida en el servidor: sin tope, un {@code tamano=100000} obligaria a construir una
 * respuesta enorme (la misma razon por la que el core y el canal web topan sus paginas).
 *
 * @param paginacion tamanos de pagina
 */
@ConfigurationProperties(prefix = "auditoria")
public record AuditoriaProperties(@DefaultValue Paginacion paginacion) {

    public record Paginacion(@DefaultValue("20") int tamanoPorDefecto, @DefaultValue("100") int tamanoMaximo) {
    }
}
