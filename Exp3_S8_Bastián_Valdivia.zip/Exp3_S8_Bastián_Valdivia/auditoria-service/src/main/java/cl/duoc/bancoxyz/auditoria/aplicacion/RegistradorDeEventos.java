package cl.duoc.bancoxyz.auditoria.aplicacion;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cl.duoc.bancoxyz.auditoria.persistencia.RepositorioAuditoria;
import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * El caso de uso del consumidor: guardar UN evento en la auditoria, de forma idempotente.
 *
 * <p>Lee y valida el sobre ({@link CodecEventos#leer}): si incumple el contrato lanza
 * {@code EventoInvalidoException}, error permanente que va a la DLT sin reintentos. Despues lo guarda con
 * una sola sentencia que ignora el repetido ({@code ON CONFLICT DO NOTHING} sobre el {@code eventId}): un
 * evento entregado dos veces queda guardado una sola.
 *
 * <p>Si la base falla, la excepcion sube al consumidor y los reintentos no bloqueantes lo vuelven a intentar
 * mas tarde: la auditoria no pierde eventos por una caida pasajera de su base.
 */
@Service
public class RegistradorDeEventos {

    private static final Logger log = LoggerFactory.getLogger(RegistradorDeEventos.class);

    /** Lo que paso con un evento. */
    public enum Resultado {
        /** Se guardo. */
        GUARDADO,
        /** Ya estaba: se descarto. */
        DUPLICADO
    }

    private final RepositorioAuditoria repositorio;
    private final Counter guardados;
    private final Counter duplicados;

    public RegistradorDeEventos(RepositorioAuditoria repositorio, MeterRegistry metricas) {
        this.repositorio = repositorio;
        this.guardados = Counter.builder("auditoria.guardados")
                .description("Eventos guardados en la auditoria").register(metricas);
        this.duplicados = Counter.builder("auditoria.duplicados")
                .description("Eventos repetidos descartados por la idempotencia").register(metricas);
    }

    /**
     * @throws cl.duoc.bancoxyz.eventos.EventoInvalidoException si el mensaje incumple el contrato
     */
    public Resultado registrar(String json, String topico, String clave, int particion, long desplazamiento) {
        SobreEvento evento = CodecEventos.leer(json);
        if (repositorio.guardarSiNoEstaba(evento, topico, clave, particion, desplazamiento)) {
            guardados.increment();
            log.info("Evento {} ({}) auditado [{}-{}@{}].", evento.eventId(), evento.tipo(), topico, particion,
                    desplazamiento);
            return Resultado.GUARDADO;
        }
        duplicados.increment();
        log.info("Evento {} ({}) repetido: ya estaba auditado, se descarta.", evento.eventId(), evento.tipo());
        return Resultado.DUPLICADO;
    }
}
