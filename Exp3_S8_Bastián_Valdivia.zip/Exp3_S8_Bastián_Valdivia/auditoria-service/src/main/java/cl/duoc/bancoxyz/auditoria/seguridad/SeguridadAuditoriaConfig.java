package cl.duoc.bancoxyz.auditoria.seguridad;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

import jakarta.servlet.DispatcherType;

/**
 * La seguridad de la API de auditoria: un SERVIDOR DE RECURSOS OAuth2 con denegacion por defecto.
 *
 * <p>Quien llama (el BFF web, con su token de servicio) tiene que presentar un JWT que el auth-server haya
 * emitido, que este servicio valida por completo:
 * <ul>
 *   <li><strong>firma</strong>, con las claves publicas del auth-server (JWKS);</li>
 *   <li><strong>emisor</strong> ({@code issuer-uri}) y <strong>vigencia</strong>;</li>
 *   <li><strong>audiencia</strong> {@code auditoria-service} ({@code spring.security.oauth2.resourceserver.jwt.audiences}):
 *       un token emitido para otro servicio (por ejemplo solo para el core) se rechaza aunque este bien firmado;</li>
 *   <li><strong>scope</strong> {@code auditoria:leer}: el permiso de este recurso. Un token de otro BFF, valido
 *       pero sin ese scope, recibe 403 (el del BFF movil o el del cajero, que no lo tienen).</li>
 * </ul>
 *
 * <p>Todo lo que no es {@code /internal/v1/auditoria/**} se deniega ({@code denyAll}): un endpoint nuevo
 * queda cerrado hasta que alguien decida de forma explicita quien puede usarlo. El reenvio de errores del
 * contenedor ({@code DispatcherType.ERROR}) no exige token, para que un error de validacion no se convierta
 * en un 401 que lo tape.
 */
@Configuration(proxyBeanMethods = false)
public class SeguridadAuditoriaConfig {

    /** El permiso que exige la lectura: el scope {@code auditoria:leer} que el auth-server concede al BFF web. */
    public static final String AUDITORIA_LEER = "SCOPE_auditoria:leer";

    @Bean
    @Order(Ordered.LOWEST_PRECEDENCE)
    public SecurityFilterChain cadenaDelServicio(HttpSecurity http, ManejadorSeguridadAuditoria manejador)
            throws Exception {
        http
                .authorizeHttpRequests(reglas -> reglas
                        .dispatcherTypeMatchers(DispatcherType.ERROR).permitAll()
                        .requestMatchers(HttpMethod.GET, "/internal/v1/auditoria/**").hasAuthority(AUDITORIA_LEER)
                        .anyRequest().denyAll())
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(Customizer.withDefaults())
                        .authenticationEntryPoint(manejador)
                        .accessDeniedHandler(manejador))
                .exceptionHandling(errores -> errores
                        .authenticationEntryPoint(manejador)
                        .accessDeniedHandler(manejador))
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(sesion -> sesion.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
        return http.build();
    }
}
