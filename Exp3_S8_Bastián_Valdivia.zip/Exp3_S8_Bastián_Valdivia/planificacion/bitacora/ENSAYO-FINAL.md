# Bitácora ENSAYO-FINAL: corrección de los hallazgos del ensayo del evaluador

**Rama:** `claude/exp3-s8`. **Commit de partida:** `204f7ca` (F10 completa).
**Qué es:** el ensayo de un evaluador estricto encontró cuatro puntos (tres bloqueantes y uno de calificación del criterio 6). Aquí
queda qué era real, qué se corrigió en la causa, qué se disputa y qué no depende del código.

## 1. Hallazgos, uno por uno

| # | Hallazgo | Veredicto | Resolución |
|---|---|---|---|
| 1 | `git clone` del README deja un proyecto que no se puede construir (`main` solo tiene `Initial commit`, repositorio privado) | **Real, mitigado en el README; el resto depende del usuario** | El README clona con `--branch claude/exp3-s8` y explica por qué; avisa que el repositorio puede ser privado y que el `.zip` no depende de GitHub. La fusión en `main` y el acceso del evaluador siguen siendo del usuario (sección 4) |
| 2 | `docker compose ps` no lista las dos tareas únicas (`Exited (0)`) | **Real** | El README usa `docker compose ps -a` y dice por qué. Medido con Compose v5.3.1: `ps` lista 14 filas; `ps -a` lista 16 (`evidencias/salidas/01-arranque.txt` ya mostraba `ps -a`) |
| 3 | Sin `.git` (el `.zip`), `verificar-f4.sh` y `verificar-f3.sh` imprimen `fatal: not a git repository` y dan PASS sin comprobar nada | **Real, corregido en la causa** | Ver sección 2 |
| 4 | Criterio 6 calificado L: estado de la entrega en GitHub, nombre del zip pendiente, documentos de trabajo | **Parcial** | Lo que es código y documentación está corregido (puntos 1 a 3, cifras al día). El resto no se puede resolver aquí (sección 4) y un punto se disputa (sección 3) |

## 2. Punto 3 en detalle: la causa y la corrección

**Causa.** Cuatro comprobaciones usaban `git ls-files` y `git grep` directamente. Sin repositorio, esos comandos fallan, la tubería
cuenta cero archivos y `igual ... 0 "$EN_GIT"` pasa: un PASS sobre una lista vacía. Una búsqueda que no mira nada y dice "0" es peor que
omitirla, porque aparenta una garantía.

**Corrección.**
- `scripts/lib-entorno.sh` trae ahora `archivos_del_proyecto` (la lista con `git ls-files -z` o, sin git, un `find` que descarta
  `.git`, `target`, `run`, `certs`, `secrets`, `respaldos`, `dist` y `__pycache__`), `contar_archivos_con` (regex extendida con rutas
  excluidas), `contar_archivos_con_texto` y `contar_archivos_del_proyecto`. Dice cuál usó en `$ORIGEN_ARCHIVOS`, y el mensaje de la
  comprobación lo repite ("en un archivo de la copia (sin .git: ...)").
- La decisión "hay git" exige `.git` en la raíz además de que `git rev-parse` funcione: un `.zip` descomprimido dentro de otro
  repositorio (una carpeta de tareas con git, por ejemplo) hace que git responda por el repositorio de afuera. `verificar-entrega.sh` y
  `verificar-f8.sh` tenían la misma debilidad y se corrigieron igual.
- Las comprobaciones **fallan si la lista trae menos de 100 archivos** ("no se revisó nada"), en vez de pasar con 0. El proyecto tiene
  554 archivos; sin los cuatro `.gitkeep` de `secrets/` el recorrido ve 550.
- `verificar-f8.sh`: la rama sin `.git` decía `PASS ... comprobacion omitida`. Ahora revisa el árbol con `find` y cuenta de verdad.
- `verificar-f4.sh`, sección 7: encontré un falso positivo latente que el cambio habría expuesto. La búsqueda de `token-servicio` y de la
  cabecera fija excluía `planificacion/` pero no `evidencias/`, y `evidencias/salidas/30-oauth2-servidor-recursos-f4.txt` contiene la
  salida del propio script (el texto "core.token-servicio" de su comprobación). Desde un clon con las evidencias versionadas, la
  comprobación daba 1 en lugar de 0 (`git grep` lo confirmó antes del arreglo). Se excluye `evidencias/` y el mensaje lo dice. La
  búsqueda de `X-Service-Token` se escribe `X-Service-[T]oken` para que el script no se encuentre a sí mismo.

**Verificación (comandos ejecutados).**
- La función contra el repo y contra una copia sin `.git` dentro de otro repositorio git: `git=1 archivos=554` y `git=0 archivos=550`;
  los conteos de la cabecera fija y de la propiedad vieja dan 0 en ambos; el conteo de `SpringBootApplication` da 14, igual que
  `git ls-files -z | xargs -0 grep -lF`. Con una línea con la cabecera plantada en la copia, el conteo pasa a 1 (la búsqueda ve los
  archivos).
- El zip real: `scripts/empaquetar-entrega.sh Ensayo_Final_Prueba` (554 archivos, una carpeta raíz, sin secretos), descomprimido, con el
  stack en marcha y la CA copiada a `certs/`: `verificar-f4.sh` dio **0 líneas `fatal`** y `RESULTADO: 85 comprobaciones, todo PASS`,
  con el mensaje "ningun secreto aparece en un archivo de la copia (sin .git: ...)  (0)"; `verificar-f3.sh`, 91 comprobaciones, todo
  PASS y 0 líneas `fatal`; `verificar-entrega.sh`, 114 comprobaciones, 0 FAIL. Todos con `bash` 3.2.57 al frente del `PATH`. El zip de
  prueba y su copia se borraron.

## 3. Punto disputado

**"Los documentos de trabajo (plan 'nota máxima', pendientes en la bitácora F10) viajan con la entrega."** Se disputa en parte:

- Las bitácoras y el plan son documentación del proceso que el README enlaza y que `verificar-readme.py` y `verificar-entrega.sh`
  exigen; `CLAUDE.md` los define como parte del proyecto. Quitarlos del zip dejaría enlaces rotos en el README, que el propio
  evaluador midió sin roturas. El plan dice en su cabecera "No es un entregable" y el README lo presenta como historia de las fases.
- Lo que sí era un defecto de presentación se corrigió: el título del plan decía "Plan para nota máxima" y ahora dice "Plan maestro:
  Exp3 S8". El **nombre de archivo** (`PLAN_NOTA_MAXIMA.md`) no se cambió porque `CLAUDE.md`, el README, `verificar-entrega.sh` y la
  evidencia `79-entrega.txt` lo citan, y las instrucciones de trabajo de las fases lo fijan; renombrarlo es una decisión del usuario
  (queda anotada en la sección 4).
- Los "pendientes" de la bitácora F10 (sección 7) son los de verdad (fusión, nombre del zip, ensayo en Windows o macOS): ocultarlos
  contradice la regla de evidencia honesta.

## 4. Lo que no se puede resolver desde aquí (depende del usuario)

| Pendiente | Por qué no se resuelve aquí | Qué hacer |
|---|---|---|
| Fusionar `claude/exp3-s8` en `main` | La regla del proyecto prohíbe modificar o empujar `main` antes de F10, y no se crea PR | **Hecho el 4 de octubre** (sección 7): avance rápido aprobado por el usuario; el README volvió a clonar sin `--branch` |
| Acceso del evaluador al repositorio | El repositorio es privado (HTTP 404 anónimo, comprobado por el ensayo); la visibilidad es del dueño | El usuario decidió hacerlo público después de la fusión. Alternativa: entregar solo el `.zip` |
| Nombre real del zip | Es el nombre y los apellidos del estudiante; el script no puede inventarlos | El usuario decidió no entregarlo: el zip se genera como `Exp3_S8_Nombres_Apellidos.zip` y el usuario lo renombra |
| Renombrar `PLAN_NOTA_MAXIMA.md` (opcional) | Está citado en `CLAUDE.md`, el README y `verificar-entrega.sh` | Si se quiere, renombrar y actualizar esas tres referencias y regenerar `79-entrega.txt` |
| Ensayo en Windows o macOS con Docker Desktop | No existen en este entorno | Lo hace el usuario en su computador |

## 5. Evidencia regenerada y cifras

Para que README y evidencias coincidan se ejecutó `scripts/verificar.sh --sin-construir --frio --con-pruebas` desde un **clon limpio**
(`git clone -c core.autocrlf=true --branch claude/exp3-s8`, commit `e34b506`) con `bash` 3.2.57 al frente del `PATH` y las imágenes
reconstruidas desde ese clon: **`RESULTADO GLOBAL: PASS`, 37 min 44 s**, C1 132, C2 291, C3 158, C4 115, C5 75, C6 217 y no regresión
60 comprobaciones PASS; `00-pruebas-unitarias.txt`: 610 pruebas, 0 fallas, 0 errores, 0 omitidas, `BUILD SUCCESS`.

Un primer intento terminó mal por una causa del entorno y no del proyecto: el disco del sandbox se llenó (la caché de compilación de
Docker ocupaba 21 GB) y Maven no pudo escribir (`00-pruebas-unitarias` FAIL con 89 pruebas). Se limpió la caché de compilación
(`docker builder prune -a`) y se repitió la ejecución completa desde un clon nuevo; solo cuenta la segunda.

Las cifras medidas que el README, `docs/eventos.md` y `docs/guia-de-estudio.md` citaban de la corrida anterior se actualizaron a las de
esta: arranque en frío 71 s y 66 s hasta todo listo, memoria en reposo 3044 MiB, la tabla por servicio (arranque de la app, memoria),
la tabla de escalado (1 consumidor 20764 ms, 3 consumidores 6924 ms con aceleración 3,00, 4 consumidores 6603 ms con aceleración 3,14 y
uno ocioso; el texto aclara que superar 3,00 es ruido) y los reintentos que rescató el Retry en la caída de una réplica (36 en web y 36
en el cajero). `scripts/verificar-readme.py` no encuentra diferencias (0 líneas distintas de PASS).

Tras los cambios del README se repitió solo el criterio C6 (`verificar.sh --solo C6`, 216 comprobaciones PASS, 114 en
`79-entrega.txt`); de esa repetición se copiaron `70` a `80` y **no** `01-arranque.txt`, que esa pasada sobrescribe con un arranque en
caliente.

## 6. Cómo verificarlo

```bash
git clone <repositorio> && cd <repositorio>
docker compose up -d --build --wait && docker compose ps -a        # 16 filas: 14 healthy y 2 Exited (0)
scripts/verificar-f4.sh | tail -1                                   # RESULTADO: 85 comprobaciones, todo PASS (con o sin .git)
python3 scripts/verificar-readme.py | grep -vc '^PASS'              # 0
```

## 7. Cierre (4 de octubre)

**El segundo ensayo del evaluador no terminó.** El agente clonó la rama, ejecutó `scripts/verificar.sh` y `./mvnw -B verify`
(`BUILD SUCCESS` a las 23:35 UTC) y después dejó de responder: 36 minutos sin ninguna acción desde las 23:31. Se detuvo el workflow.
Ese ensayo no tiene resultado y aquí no se le atribuye ninguno.

**Lo reemplazó una verificación ejecutada directamente, sin agente**, sobre el commit `d04efaf` (el README ya clona la rama por
defecto):

- `git clone -c core.autocrlf=true --branch claude/exp3-s8` desde GitHub, `bash` 3.2.57 al frente del `PATH` e imágenes
  construidas desde ese clon.
- `scripts/verificar.sh --sin-construir --frio --con-pruebas`: **`RESULTADO GLOBAL: PASS`**, 31 pasos, 0 FAIL, 36 min 59 s.
  Comprobaciones PASS: C1 132, C2 291, C3 158, C4 115, C5 75, C6 217 y no regresión 60 (1048 en total). `00-pruebas-unitarias`:
  610 pruebas, 0 fallas, 0 errores, 0 omitidas.
- Las evidencias versionadas (`evidencias/salidas/`) **no** se reemplazaron con esta corrida: son las de la sección 5, con las que
  coinciden las cifras medidas del README (tiempos y memoria varían entre corridas; los conteos de comprobaciones y los PASS, no).

**Cambios después del corrector** (commit `d04efaf`): el README y `evidencias/INDICE.md` clonan sin `--branch`; la guía de estudio,
la propuesta técnica y `CLAUDE.md` cuentan en pasado por qué se retiró el CI. `scripts/verificar-readme.py` y
`scripts/verificar-entrega.sh` siguen en PASS (0 FAIL).

**Fusión en `main`.** Con el commit que agrega esta sección, `claude/exp3-s8` se une en `main` por avance rápido
(`git push origin claude/exp3-s8:main`): `main` solo tenía el commit inicial que creó GitHub, ancestro de la rama, así que no hay
commit de fusión ni historia reescrita. La aprobó el usuario.

**Zip.** El usuario decidió no entregar su nombre completo: se genera como `Exp3_S8_Nombres_Apellidos.zip` y el usuario lo renombra
antes de subirlo.

**Queda del lado del usuario:** hacer público el repositorio (lo decidió, después de la fusión), el ensayo en su computador con
Windows o macOS y Docker Desktop, y subir el zip.
