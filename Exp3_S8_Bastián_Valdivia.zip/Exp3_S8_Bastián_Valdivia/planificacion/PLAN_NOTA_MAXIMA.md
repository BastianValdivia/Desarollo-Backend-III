# Plan maestro: Exp3 S8

**Actividad:** "Desarrollando microservicios y resiliencia en la nube con Spring Cloud". Sumativa
individual, Desarrollo Backend III (PBY2203).
**Proyecto:** Banco XYZ. Continúa el S5 (patrón BFF) del repo `backend-3-bastian-semana-2`.
**Qué es este documento:** el plan de trabajo. No es un entregable.

---

## 0. Cómo leer este plan

| Etiqueta | Significado |
|---|---|
| **HECHO** | Leído en un documento oficial del curso o verificado con un comando. |
| **RECOMENDACIÓN** | Decisión de diseño, discutible. Lleva su razón al lado. |
| **A VERIFICAR** | Supuesto técnico que se comprueba al inicio de la fase indicada, antes de construir encima. |

Los documentos oficiales están en `docs/enunciado/` como copia local **fuera de git**: llevan un
aviso de derechos reservados de Duoc UC que prohíbe reproducirlos. Este plan los resume, no los copia.

---

## 1. Qué pide la actividad

### 1.1 Instrucciones específicas (HECHO)

- Continuar el proyecto con tres tareas:
  1. implementar OAuth2.0;
  2. crear las imágenes Docker de los microservicios;
  3. configurar un `docker-compose.yaml` que orqueste todos los componentes "para poder lanzar tu
     aplicación en un entorno Cloud".
- La descripción agrega seguridad con Spring Cloud Security, tolerancia a fallos con Resilience4j y
  mensajería asíncrona con Kafka o JMS para una arquitectura orientada a eventos.
- La base son "los microservicios de la semana 6" con los datos de `bank_legacy_data`. Eso supone
  Config Server, Eureka y Resilience4j ya hechos. **En este proyecto no existen**: se construyen aquí
  (F1 y F6).
- Entrega:
  - el repositorio en GitHub, con su propuesta técnica;
  - un README con el objetivo, la estructura del código y las instrucciones de ejecución;
  - evidencia: capturas o salidas de consola de la ejecución **de cada microservicio** y de sus
    resultados.

  Todo va en una carpeta, comprimida como `Exp3_S8_nombresyapellidos`.

### 1.2 Guía de aprendizaje S8 (HECHO)

- **Seguridad:** OAuth 2.0 y JWT, con cuatro piezas: servidor de autorización, token de acceso,
  servidor de recursos y "delegación de seguridad" (los servicios no implementan su propia
  autenticación, la delegan).
  - Sugiere **Spring Authorization Server**.
  - Dice que el BFF "puede administrar una autenticación básica o integrarse con un Auth Server para
    mejorar su implementación".
- **Resiliencia:** nombra Circuit Breakers, Retry Policies y Bulkheads.
- **Docker:**
  - estrategias: reinicio automático, balanceo de carga entre contenedores y escalado horizontal;
  - antes de producción: imágenes optimizadas, monitoreo y respaldo de datos.
- **Arquitectura de referencia:** proveedor de identidad, API Gateway, microservicios, Config Server,
  registro y descubrimiento, circuit breaker, gestión, base de datos y métricas.
- **Su ejemplo de compose** usa `wurstmeister/kafka` con ZooKeeper y `version: '3'`. Se explica en D5
  por qué no se copia.

### 1.3 Pauta (HECHO)

| # | Criterio | Pts | El 100% exige | Lo que baja a 80% |
|---|---|---|---|---|
| 1 | OAuth2.0 | 20 | Flujo funcional que asegura la protección de datos y servicios | 1 a 2 errores que no comprometen la seguridad |
| 2 | Imágenes Docker | 20 | Imágenes funcionales para todos los microservicios, con portabilidad y despliegue eficiente | 1 a 2 errores menores |
| 3 | docker-compose.yaml | 20 | Configurado correctamente, orquesta todos los componentes necesarios de manera funcional | 1 o 2 errores menores, **o faltan componentes no esenciales** |
| 4 | Resilience4j | 20 | Correcto **en los microservicios**, garantizando resiliencia ante fallos | Errores que no afectan la funcionalidad principal |
| 5 | Kafka o JMS | 15 | Completamente funcional, comunicación eficiente y escalable **entre microservicios** | Errores que no afectan la comunicación general |
| 6 | Entrega | 5 | Los 3 aspectos: código, documentación y evidencia | Entrega solo 2 aspectos |

Los niveles son 100, 80, 60, 30 y 0%. El encabezado de la pauta dice "formativa" y las
instrucciones dicen "sumativa individual". Es un error de plantilla y no cambia nada.

---

## 2. Cómo se gana el 100%: seis reglas para todas las fases

1. **Cero errores observables.** Lo que separa 100 de 80 es "1 a 2 errores". No se gana haciendo
   más, se gana logrando que nada falle cuando el evaluador mira.
2. **Lo que no tiene evidencia no existe.** Cada afirmación del README apunta a una salida de consola
   o a una captura.
3. **Clon limpio y un comando.** El evaluador no prepara nada a mano antes de `docker compose up`.
4. **Cada palabra del descriptor es una condición.** "Todos los microservicios", "todos los
   componentes", "en los microservicios", "garantizando", "entre microservicios", "escalable".
5. **README, evidencia y código dicen lo mismo.** Una cifra del README que no coincide con la
   evidencia ya es un error.
6. **Sin regresiones del S5.** Si algo que funcionaba en el S5 aparece roto, cuenta como error.

---

## 3. Punto de partida

**HECHO**, verificado en el repo `backend-3-bastian-semana-2`:

- Cinco módulos Maven: `core-service`, `bff-web`, `bff-mobile`, `bff-atm` y `plataforma-comun`.
- Spring Boot 3.3.5, Java 21 y 192 pruebas.
- Cada BFF valida JWT con Spring Security, pero **los emite él mismo**, con su propia clave
  (`EmisorToken`, en `plataforma-comun`).
- El core se protege con una cabecera fija, `X-Service-Token`.
- Los datos se cargan de los CSV a memoria al arrancar.

Lo que usa cada BFF del core (verificado en el código) fija los permisos mínimos de OAuth2 (D2):

| BFF | Operaciones del core que usa |
|---|---|
| `bff-web` | cuenta, movimientos, calidad de datos y transacciones no conciliadas (panel del ejecutivo) |
| `bff-mobile` | cuenta |
| `bff-atm` | saldo y retiro |

### 3.1 Lista de no regresión

Comportamientos del S5 que deben seguir siendo verdad al final. Entre paréntesis, su número de
evidencia en el S5.

| Comportamiento | S5 |
|---|---|
| Sin token, los tres canales responden 401 | 12 |
| Vigencia del token por canal: 1800, 3600 y 180 s | 13 |
| Matriz 3x3: el token de un canal no sirve en otro | 15 |
| Titularidad: un token de la cuenta 116 pidiendo la 105 recibe 403 | 16 |
| Permisos distintos dentro del mismo canal (cliente y ejecutivo) | 17 |
| Móvil: el token queda atado al dispositivo | 18 |
| Cajero: solo autentican los terminales autorizados | 19 |
| HTTPS en los tres BFF, cada uno con su propia identidad | 07, 09, 10 |
| Optimización por canal: tamaños medidos, gzip, caché y ETag | 21 |
| Retiro atómico e idempotente | 23 |
| Carga del dataset: 50 cuentas, 686 movimientos y descartes informados | 04 |
| Casos borde: la cuenta 130 sin movimientos y una cuenta inexistente | 24, 25 |

---

## 4. Arquitectura objetivo

```mermaid
flowchart LR
  subgraph Host
    NAV[Navegador]
    APP[App móvil]
    ATM[Cajero ATM-SCL-001]
  end
  subgraph Borde["Red borde: puertos publicados"]
    AS[auth-server 9000 HTTPS]
    W[bff-web 8443]
    M[bff-mobile 8444]
    A[bff-atm 8445]
    EU[eureka-server 8761]
    KUI[kafka-ui 8090]
  end
  subgraph Interna["Red interna: internal true"]
    CS[config-server 8888]
    CORE[core-service x2]
    PG[(PostgreSQL)]
    K[(Kafka KRaft)]
    N[notificaciones-service x2]
    AU[auditoria-service]
  end
  NAV -->|authorization_code + PKCE| AS
  APP -->|authorization_code + PKCE| AS
  ATM -->|tarjeta y PIN: grant de extensión| AS
  NAV -->|Bearer| W
  APP -->|Bearer| M
  ATM -->|Bearer| A
  W -->|client_credentials + Resilience4j| CORE
  M -->|client_credentials + Resilience4j| CORE
  A -->|client_credentials + Resilience4j| CORE
  W -->|client_credentials| AU
  CORE --> PG
  CORE -->|outbox y relay| K
  AS -->|eventos de seguridad| K
  K --> N
  K --> AU
  N --> PG
  AU --> PG
```

| Componente | Tipo | Publicado al host | Réplicas | Datos |
|---|---|---|---|---|
| `secretos-init` | tarea única: genera los secretos al primer arranque | no | 1, y termina | volúmenes de secretos |
| `postgres` | infraestructura | no | 1 | bases `core`, `auditoria` y `notificaciones` |
| `kafka` | infraestructura (KRaft) | no | 1 | volumen propio |
| `kafka-ui` | observabilidad | 127.0.0.1:8090 | 1 | ninguno |
| `config-server` | Spring Cloud Config | no | 1 | `config-repo/` |
| `eureka-server` | Spring Cloud Netflix | 127.0.0.1:8761 (dashboard) | 1 | ninguno |
| `auth-server` | Spring Authorization Server | 9000, HTTPS | 1 | clave de firma persistente |
| `core-service` | dominio | no | 2 | base `core` |
| `bff-web` | BFF | 8443, HTTPS | 1 | caché local |
| `bff-mobile` | BFF | 8444, HTTPS | 1 | caché local |
| `bff-atm` | BFF | 8445, HTTPS | 1 | ninguno |
| `notificaciones-service` | consumidor de eventos | no | 2 | base `notificaciones` |
| `auditoria-service` | consumidor de eventos y API protegida | no | 1 | base `auditoria` |

Son nueve microservicios propios, cada uno con su imagen (C2): config, eureka, auth, core, los tres
BFF, notificaciones y auditoría.

---

## 5. Decisiones de diseño

### D1. Versiones

- **HECHO.**
  - Spring Boot 3.3 perdió el soporte OSS el 30-06-2025, y el tren Spring Cloud 2023.0.x está en
    fin de vida.
  - Boot 3.3.13 gestiona estas versiones: Spring Authorization Server 1.3.7, Spring Security 6.3.10,
    spring-kafka 3.2.10 (kafka-clients 3.7.2), Flyway 10.10.0 y Testcontainers 1.19.8.
  - Spring Cloud CircuitBreaker 3.1.5 (del tren 2023.0.6) usa Resilience4j 2.2.0.
- **RECOMENDACIÓN:** Boot 3.3.13 + Spring Cloud 2023.0.6 + `resilience4j-spring-boot3` 2.2.0.
- **Razón:** la base del S5 ya funciona en 3.3 y la pauta no evalúa versiones. Migrar a Boot 4
  (Jackson 3, Spring Security 7) arriesga regresiones sin dar puntos. El fin de soporte se declara
  como limitación en el README.

### D2. OAuth2: un solo emisor para todo (delegación completa)

El `auth-server` es el **único** que emite tokens. Ningún BFF firma nada.

| Cliente | Quién es | Tipo | Grant | Permisos | Audiencia | Vigencia |
|---|---|---|---|---|---|---|
| `web-app` | navegador del cliente web | público, PKCE | `authorization_code` | los del usuario en el canal web | `bff-web` | 30 min, como el S5 |
| `mobile-app` | app del teléfono | público, PKCE | `authorization_code` | los del usuario en el canal móvil | `bff-mobile` | 60 min, como el S5 |
| `atm-scl-001` | terminal registrado | confidencial | extensión "tarjeta + PIN" | los de la tarjeta | `bff-atm` | 3 min, como el S5 |
| `bff-web` | servicio | confidencial | `client_credentials` | `cuentas:leer`, `movimientos:leer`, `auditoria:leer` | `core-service`, `auditoria-service` | 5 min |
| `bff-mobile` | servicio | confidencial | `client_credentials` | `cuentas:leer` | `core-service` | 5 min |
| `bff-atm` | servicio | confidencial | `client_credentials` | `saldo:leer`, `retiros:ejecutar` | `core-service` | 5 min |

**Por qué este diseño:**

- **La matriz 3x3 del S5 sobrevive.** Antes, cada canal tenía su propia clave de firma. Ahora hay una
  sola firma confiable, y la barrera entre canales es la **audiencia**: `bff-mobile` rechaza un token
  cuya audiencia sea `bff-web`.
- **Mínimo privilegio entre servicios.** Si alguien compromete el BFF web, su token no sirve para
  retirar dinero.
- **El cajero usa un grant de extensión** porque no tiene navegador. Ese grant reemplaza la lista
  blanca de terminales del S5 por una autenticación real del terminal (con su secreto), y la
  política de PIN (3 intentos, bloqueo de 15 min) pasa al servidor de autorización, que es donde
  vive la autenticación. El grant `password` no se usa: la RFC 9700 lo prohíbe y Spring
  Authorization Server no lo implementa.
- **Usuarios y contraseñas.** Hay un usuario con una sola contraseña, y sus autoridades dependen del
  canal que pide el token. Los tokens llevan los mismos claims que hoy leen los BFF, para no
  reescribir su autorización.

### D3. TLS con una CA interna y emisor fijo

- `secretos-init` crea una **CA interna** y firma con ella los certificados de los tres BFF y del
  `auth-server`. El archivo `certs/ca.crt` queda en el host, así que el evaluador usa
  `curl --cacert certs/ca.crt` en lugar de `-k`, que desactiva la verificación.
- **Emisor fijo, `https://localhost:9000`.** Las claves públicas (JWKS) se leen por la dirección
  interna, `https://auth-server:9000/oauth2/jwks`. Esto evita la trampa clásica de Docker: el token
  dice un emisor y el servicio espera otro, y lo rechaza.
- Los tramos internos (BFF a core, consumidores, config, eureka) van por HTTP dentro de la red
  interna, que no es alcanzable desde el host. Se declara como limitación, con mTLS como trabajo
  futuro.

### D4. Persistencia en PostgreSQL

- PostgreSQL 16, con versión fija. Una base por servicio, cada una con su propio usuario y
  privilegios mínimos: ningún servicio puede leer los datos de otro.
- Flyway para el esquema.
- **Carga inicial del dataset, una sola vez**, reutilizando la ingesta del S5 como migración Java de
  Flyway. El lock de Flyway impide que dos réplicas carguen a la vez.
- Alternativa descartada para el plan base: un job de Spring Batch dedicado (alinearía con la "capa
  de datos" de la guía y con la Exp1). La pauta no lo evalúa y es un componente más que puede
  fallar. Queda como extensión posible.

### D5. Kafka

- Imagen oficial **`apache/kafka` en modo KRaft**, con versión fija.
- **No se copia el ejemplo de la guía** (HECHO):
  - `wurstmeister/kafka` y `wurstmeister/zookeeper` se actualizaron por última vez en 2022 y 2019;
  - Kafka 4.0 eliminó ZooKeeper;
  - `version:` es obsoleta en Compose v2.

  El README lo explica, para que no parezca que se ignoró la guía.
- **Tópicos:** `bancoxyz.retiros.v1` y `bancoxyz.seguridad.v1`, con 3 particiones y la cuenta (o el
  usuario) como clave, para conservar el orden por cuenta.
- **Outbox en el core**, con **un solo relay activo** (lock consultivo de PostgreSQL). Con dos réplicas
  publicando a la vez se perdería el orden por cuenta.
- **Productor:** idempotente (`acks=all`), con compresión y lotes.
- **Consumidores:** idempotentes, con reintentos no bloqueantes y una DLT (dead letter topic: el
  tópico donde terminan los mensajes que no se pudieron procesar).
- Kafka y no JMS porque lo "escalable" se demuestra con particiones y grupos de consumidores.

### D6. Resilience4j, llamada por llamada

| Llamada | Timeout | Retry | Circuit breaker | Bulkhead | Respaldo (fallback) |
|---|---|---|---|---|---|
| `bff-web` a core | conexión 1 s, lectura 2 s | 3 intentos con backoff, solo GET | sí | 20 simultáneas | caché marcada como desactualizada; si no hay caché, 503 |
| `bff-mobile` a core | igual | igual | sí | 20 | caché o ETag marcada; si no, 503 |
| `bff-atm` a core | igual | GET, y retiro con su `Idempotency-Key` | sí | 5 | 503: falla cerrada, nunca un saldo inventado |
| BFF a `auth-server` (token) | 2 s | 2 intentos | sí | no | sigue con el token vigente en caché; si venció, 503 |
| `bff-web` a auditoría | igual | solo GET | sí | 10 | el panel sale sin esa sección, avisándolo |
| relay del core a Kafka | 5 s | sí | sí | no | el evento queda en el outbox hasta que Kafka vuelva |
| notificaciones a la pasarela simulada | 1 s | 3 | sí | 10 | reintento por tópico y luego DLT |

Son valores iniciales. Se ajustan midiendo en F6, y cada valor final lleva su razón en el README.

### D7. Secretos

- No se versionan.
- `secretos-init` los genera la primera vez: CA, keystores, truststore, clave de firma del
  `auth-server`, secretos de los clientes y contraseñas de las bases.
- Quedan en un volumen por servicio, de modo que cada uno monta solo lo suyo.
- Las credenciales de los usuarios de demostración (por ejemplo `cliente116` y las tarjetas) sí se
  publican, como en el S5, porque el evaluador las necesita para probar.

### D8. Config Server con backend nativo

La carpeta `config-repo/` va montada en el contenedor. Un cambio ahí se aplica con
`/actuator/refresh`, sin reconstruir imágenes. Lo aprovecha la demo de latencia de F6.

### D9. Sin API Gateway

La arquitectura de referencia de la guía trae un gateway, pero con el patrón BFF cada BFF ya es la
puerta de entrada de su canal. Un gateway delante volvería a centralizar lo que el S5 separó a
propósito. La pauta no lo pide, y el README lo justifica.

### D10. Nombres exactos

El archivo se llama `docker-compose.yaml`, como lo escribe la pauta, y no lleva la clave `version`.

### D11. Puerto de gestión separado

Actuator va en un puerto HTTP interno (8081) que no se publica. Los healthchecks usan ese puerto.
Nunca se exponen `env`, `configprops` ni `heapdump`.

### D12. Nota sobre "Spring Cloud Security"

**HECHO:** el artefacto `spring-cloud-starter-security` publicó su última versión (2.2.5) en 2021 y
no forma parte de los trenes actuales de Spring Cloud. Hoy esa función la cumplen Spring Security
OAuth2 (Resource Server y Client) y Spring Authorization Server, que es lo que recomienda la propia
guía. El README lo dice explícitamente.

---

## 6. Orden de las fases y por qué

```
F0 base ─> F1 Spring Cloud ─> F2 contenedores ─> F3 PostgreSQL ─> F4 OAuth2 entre servicios
                                                                    └─> F5 OAuth2 para usuarios
F3 + F4 ─> F6 Resilience4j ─> F7 Kafka ─> F8 calidad del despliegue ─> F9 verificación ─> F10 entrega
```

1. **Contenedores temprano (F2).** C2 y C3 suman 40 puntos y dependen de que todo lo demás funcione
   dentro de Docker. Integrar desde el principio evita el fallo clásico de "funciona en mi máquina".
   Desde F2, cada fase termina funcionando en Compose.
2. **PostgreSQL antes que resiliencia y eventos (F3).** El reintento sobre otra réplica (F6) y el
   outbox (F7) necesitan un core sin estado en memoria. Además, F3 es la fase que más toca el
   dominio del S5: conviene que los problemas aparezcan pronto.
3. **OAuth2 en dos pasos (F4, F5).** Primero entre servicios, que es acotado. Después los usuarios,
   que cambia la seguridad de los tres BFF.
4. **Kafka después de Resilience4j (F7).** La resiliencia de la mensajería reutiliza lo construido en
   F6.

**Cómo se trabaja cada fase:**

1. Se comprueban sus puntos A VERIFICAR.
2. Se implementa y se prueba.
3. Se ejecuta en Compose y se captura su evidencia.
4. Se hace commit.
5. Te explico qué cambió y por qué.
6. Avanzamos con tu visto bueno.

En cada fase siempre queda una versión entregable.

**Tamaño:** esfuerzo relativo, no horas. S es pequeño, M es mediano y L es grande.

---

## 7. Fases

### F0. Línea base del proyecto (S)

**Objetivo:** el S5 compila y pasa sus 192 pruebas dentro del repo nuevo, con las versiones y las
reglas de trabajo fijadas.

**Tareas**
- Importar el S5 con su historial (unión de historias no relacionadas) y etiquetarlo `s5-base`. Así
  el repo muestra la evolución.
- Sacar del árbol lo que es solo del S5: su plan, sus guías y sus evidencias quedan en el historial.
- Subir Spring Boot de 3.3.5 a 3.3.13 e importar el BOM de Spring Cloud 2023.0.6 en el POM padre.
- `.gitignore` para el enunciado, los secretos, los certificados y `target/`.
- `CLAUDE.md` con las convenciones del proyecto, para que cualquier sesión futura trabaje igual.
  Incluye la regla del S5 de ejecutar `unset JAVA_TOOL_OPTIONS` antes de capturar evidencia.
- Trabajar en una rama; `main` recibe el resultado al final (F10).

**Terminado cuando:** `./mvnw verify` pasa las 192 pruebas, y los 4 servicios arrancan como en el S5.

**Evidencia:** compilación y pruebas.

**Debes poder explicar:**
- por qué se parte del S5 y no de cero;
- qué es un BOM y por qué Spring Cloud se alinea con una versión de Boot.

### F1. Plataforma Spring Cloud: Config Server y Eureka (M)

**Objetivo:** configuración centralizada y descubrimiento de servicios. Ningún servicio conoce la
dirección de otro.

**Tareas**
- Módulo `config-server` (perfil `native`) y carpeta `config-repo/`, con:
  - un archivo por servicio y perfil (`local`, `docker`);
  - un `application.yml` común (Actuator, Eureka, logging).
- Módulo `eureka-server`.
- Core y BFF como clientes de config (`spring.config.import`) y de Eureka, con `prefer-ip-address`
  para que funcione en contenedores.
- `CoreClient` con `@LoadBalanced RestClient.Builder`: el BFF llama a `http://core-service` y no a
  `localhost:8080`. **HECHO:** está documentado en Spring Cloud Commons 4.1.
- Actuator en el puerto de gestión (D11).
- En el perfil de pruebas, config y Eureka quedan desactivados: las pruebas no dependen de servidores
  externos.

**Terminado cuando:**
- Eureka muestra el core y los 3 BFF.
- `config-server` entrega la configuración de cada servicio.
- Un valor cambiado en `config-repo`, más un refresh, se aplica sin recompilar.

**Evidencia:** dashboard de Eureka, respuesta del config-server para cada servicio y la misma
petición antes y después del refresh.

**Alimenta:** la base que asumen las instrucciones, C3 y C4.

**Trampas**
- Si `config-server` no está arriba, los demás no arrancan. Se resuelve con orden de arranque y
  reintento, no con `optional:`: arrancar sin configuración sería peor.
- Eureka tarda en olvidar una instancia muerta. Por eso existe el retry de F6.

**Debes poder explicar:**
- qué problema resuelve cada uno;
- qué pasa si cae Eureka: los clientes siguen con la última lista conocida;
- en qué se diferencia del DNS de Docker.

### F2. Contenedores desde temprano (M)

**Objetivo:** lo existente corre con un solo comando desde un clon limpio. Desde aquí, cada fase se
prueba en Docker.

**Tareas**
- Un `Dockerfile` por microservicio, con:
  - una etapa de compilación con Maven y caché de dependencias (BuildKit);
  - extracción en capas con `java -Djarmode=tools -jar application.jar extract --layers`
    (**HECHO:** así lo documenta Boot 3.3);
  - una imagen final que solo lleva el JRE;
  - usuario no root con UID fijo;
  - `HEALTHCHECK` contra el puerto de gestión;
  - memoria relativa al límite del contenedor.
- `.dockerignore`.
- `secretos-init` (D7) y la CA interna (D3). `certs/ca.crt` queda en el host.
- `docker-compose.yaml` con config-server, eureka-server, core-service y los 3 BFF:
  - redes `borde` e `interna`;
  - el core sin puertos publicados;
  - healthchecks, y `depends_on` con `service_healthy` y `service_completed_successfully`;
  - `restart: unless-stopped`.
- Adaptar los scripts de verificación del S5 para que corran contra los contenedores.

**Terminado cuando:**
- Desde un clon limpio, `docker compose up -d --build` deja todo healthy.
- La lista de no regresión (3.1) pasa contra los contenedores.
- `curl --cacert certs/ca.crt` funciona, y sin ese archivo falla.

**Evidencia:** `docker compose ps`, tiempos de arranque y HTTPS verificado con la CA.

**Alimenta:** C2 y C3.

**Trampas**
- Archivos de secretos que el usuario no root no puede leer. Se evita con UID fijo y `chown` en el
  init.
- Dentro de un contenedor, `localhost` es el propio contenedor.
- Un `start_period` corto marca como unhealthy a un servicio que todavía está arrancando.
- **Maven Central limita las descargas:** respondió HTTP 429 en este entorno al verificar versiones.
  La caché de BuildKit evita descargar todo en cada construcción.
- **A VERIFICAR:** que `docker compose up --wait` tolere las tareas únicas ya terminadas. Si no, el
  script espera por su cuenta.

**Debes poder explicar:**
- imagen versus contenedor;
- por qué se construye en dos etapas y para qué sirven las capas;
- healthcheck versus `depends_on`;
- por qué no root y por qué dos redes.

### F3. Persistencia con PostgreSQL (L)

**Objetivo:** el core deja de guardar estado en memoria. Los datos sobreviven a los reinicios y el
core corre en dos réplicas sin inconsistencias.

**Tareas**
- PostgreSQL (versión fija) en el compose, con volumen.
- Bases `core`, `auditoria` y `notificaciones`, cada una con su usuario y privilegios mínimos.
- Flyway con su módulo `flyway-database-postgresql` (**HECHO:** Flyway 10 separa el soporte por
  motor, y el artefacto existe para la versión 10.10.0).
- Carga inicial del dataset, una sola vez (D4).
- Adaptadores JDBC para los puertos que el S5 ya define (`CuentaRepository`, `RegistroIdempotencia`,
  `LoteNoConciliadoRepository`). El dominio no cambia.
- Retiro atómico: `UPDATE ... WHERE saldo >= monto` y el movimiento, en la misma transacción.
- Idempotencia: restricción única sobre la clave de idempotencia.
- Tabla `outbox`, que se usa en F7.
- `core-service` con 2 réplicas.
- Pruebas de repositorio con Testcontainers.

**Terminado cuando:**
- La carga da los mismos números del S5.
- Diez retiros simultáneos, repartidos entre las dos réplicas, dan cinco éxitos y saldo cero.
- Reiniciar el core conserva los retiros.
- Eureka muestra dos instancias del core, y el balanceo reparte las peticiones.

**Evidencia:** reporte de carga, prueba de concurrencia entre réplicas, reinicio y reparto de
peticiones por instancia.

**Alimenta:**
- C3 y C4: reintentar sobre otra réplica.
- C5: habilita el outbox.
- C1: cada base tiene su propio usuario.

**Trampas**
- Dos réplicas cargando el dataset a la vez. Lo evita el lock de Flyway.
- Números de carga distintos a los del S5. Lo detecta la prueba de regresión.

**Debes poder explicar:**
- por qué el estado en memoria no sirve en contenedores;
- por qué el `UPDATE` condicional basta, sin locks explícitos;
- cómo la restricción única vuelve idempotente el retiro.

### F4. OAuth2 entre servicios (M)

**Objetivo:** ningún servicio interno responde sin un token válido del `auth-server`, y cada cliente
solo puede hacer lo que necesita.

**Tareas**
- Módulo `auth-server` con Spring Authorization Server 1.3.7: clave de firma persistente (D7), emisor
  fijo (D3) y HTTPS.
- Clientes `bff-web`, `bff-mobile` y `bff-atm`:
  - grant `client_credentials`;
  - secretos generados y guardados con hash;
  - permisos mínimos (D2) y audiencia `core-service`.
- El core como resource server: valida la firma (por JWKS), el emisor, la audiencia, la expiración y
  el permiso de cada endpoint.
- Los BFF como clientes OAuth2: obtienen el token, lo guardan en caché y lo renuevan antes de que
  venza. **HECHO:** Spring Security 6.3.10 no trae `OAuth2ClientHttpRequestInterceptor` (lo revisé
  en el jar), así que se escribe un interceptor corto sobre `OAuth2AuthorizedClientManager`.
- Eliminar `X-Service-Token` y su filtro.
- Pruebas de la matriz con tokens de prueba.

**Terminado cuando:**
- Sin token, 401. Con token vencido, 401. Con otra audiencia, 401.
- Con permiso insuficiente, 403: `bff-web` intentando un retiro.
- Con token válido, 200.
- No queda ninguna referencia a `X-Service-Token` en el código.

**Evidencia:** matriz de seguridad del core, claims de un token decodificados y descubrimiento OIDC
del `auth-server`.

**Alimenta:** C1.

**Trampas**
- Emisor distinto dentro y fuera de Docker (D3).
- **A VERIFICAR:** que el resource server, configurado con `jwk-set-uri` e `issuer-uri`, valide el
  emisor sin intentar el descubrimiento.

**Debes poder explicar:**
- los cuatro roles de OAuth2;
- el flujo `client_credentials` paso a paso;
- qué valida el core en un JWT, y en qué orden;
- scope versus autoridad, y para qué sirve la audiencia.

### F5. OAuth2 para usuarios: delegación completa (L)

**Objetivo:** los usuarios de los tres canales se autentican en el `auth-server`, y ningún BFF emite
tokens. Las reglas propias de cada canal se conservan.

**Tareas**
- Usuarios, autoridades y tarjetas del S5 pasan al `auth-server`.
- `web-app` y `mobile-app` como clientes públicos con `authorization_code` + PKCE.
- Cajero: grant de extensión "tarjeta + PIN" para el terminal registrado `atm-scl-001`.
  **HECHO:** Spring Authorization Server 1.3 documenta cómo implementar un grant de extensión, con
  un `AuthenticationConverter` y un `AuthenticationProvider` registrados en el endpoint de tokens.
- Política de PIN en el `auth-server`: 3 intentos y bloqueo de 15 minutos.
- Personalización de los tokens con `OAuth2TokenCustomizer`:
  - audiencia por canal, cuenta y permisos;
  - las vigencias del S5: 30, 60 y 3 minutos;
  - `device_id` en el móvil.
- Los BFF validan los tokens del `auth-server`. Se eliminan sus endpoints de login, sus claves y
  `EmisorToken`.
- Titularidad, permisos, dispositivo y terminal se siguen aplicando en cada BFF.
- Scripts de login:
  - PKCE con curl, incluidos el formulario y el token CSRF;
  - tarjeta + PIN.

**Terminado cuando:**
- La matriz 3x3 se mantiene, ahora por audiencia.
- La titularidad sigue dando 403.
- Se cumplen la regla del móvil y la del cajero.
- El tercer PIN errado bloquea la tarjeta.
- No hay `JwtEncoder` fuera del `auth-server` y de las pruebas.

**Evidencia:** login en los tres canales, claims de los tres tokens, matriz 3x3 y bloqueo por PIN.

**Alimenta:** C1. Cierra el riesgo de que el evaluador vea "OAuth2 solo a medias".

**Trampas**
- **A VERIFICAR:** que el `device_id` enviado en la autorización llegue al token por el contexto del
  customizer. Si no, la alternativa es un registro de dispositivos por usuario en el BFF.
- Automatizar el login con formulario y CSRF.

**Debes poder explicar:**
- `authorization_code` + PKCE paso a paso, y qué ataque evita PKCE;
- por qué el cajero usa un grant de extensión y no `password`;
- cómo sobrevive la matriz 3x3 con un solo emisor.

### F6. Resiliencia con Resilience4j (M)

**Objetivo:** el sistema se degrada con criterio y se recupera solo ante caídas, lentitud y
sobrecarga.

**Tareas**
- En los 3 BFF: timeouts del cliente HTTP, Retry, CircuitBreaker y Bulkhead, con los valores de D6
  ajustados midiendo.
- Respaldo (fallback) distinto por canal.
- Resiliencia en la obtención del token.
- Configuración de Resilience4j centralizada en `config-repo`.
- Endpoints de Actuator de Resilience4j en el puerto de gestión.
- Scripts de caos:
  - core caído;
  - core lento (latencia inyectada por configuración + refresh);
  - ráfaga contra el bulkhead;
  - una réplica que muere a mitad del tráfico;
  - un contenedor que se reinicia solo.

**Terminado cuando:** cada mecanismo queda demostrado con números:
- el circuito pasa por CLOSED, OPEN, HALF_OPEN y CLOSED;
- el bulkhead rechaza lo que sobra;
- 100 de 100 peticiones salen bien mientras muere una réplica del core;
- Docker reinicia un contenedor caído y el servicio vuelve a Eureka.

**Evidencia:** eventos de los circuit breakers, conteos por escenario y logs del reinicio.

**Alimenta:** C4, y C3 por el reinicio automático.

**Trampas**
- El TimeLimiter de Resilience4j solo aplica a llamadas asíncronas. Con un RestClient bloqueante, el
  timeout es el del cliente HTTP.
- Reintentar una operación que no es idempotente duplica sus efectos.
- **A VERIFICAR:** qué forma de detener el proceso activa la política de reinicio. Un `docker stop`
  manual no la activa.

**Debes poder explicar:**
- los estados del circuit breaker y sus umbrales;
- por qué el retry envuelve al circuit breaker;
- bulkhead versus rate limiter;
- por qué el cajero falla cerrado.

### F7. Mensajería con Kafka (L)

**Objetivo:** comunicación asíncrona entre microservicios que sea confiable, eficiente y escalable.

**Tareas**
- Kafka en modo KRaft (D5), con tópicos de 3 particiones.
- Core: relay del outbox con líder único y productor idempotente.
- `auth-server`: eventos de seguridad (PIN errado, tarjeta bloqueada).
- `notificaciones-service`, con 2 réplicas en el mismo grupo:
  - consumidor idempotente, que registra lo procesado en su base;
  - pasarela de envío simulada, protegida con Resilience4j;
  - reintentos no bloqueantes y DLT.
- `auditoria-service`, con su propio grupo:
  - guarda los eventos;
  - expone una API protegida por OAuth2 (`auditoria:leer`), que consume el panel del ejecutivo en
    `bff-web`.
- `kafka-ui` para inspeccionar tópicos y grupos.
- Contrato de eventos versionado y diagrama de la arquitectura de eventos.
- Medición del escalado: el mismo lote procesado con 1 y con 3 consumidores, y con 4 para mostrar
  que uno queda ocioso.

**Terminado cuando:**
- Un retiro llega a ambos grupos.
- Con Kafka detenido, los retiros siguen funcionando, y los eventos se entregan cuando vuelve.
- Un mensaje inválido termina en la DLT sin bloquear la partición.
- El escalado queda medido.

**Evidencia:** reparto de particiones, lag en cero, el caso que termina en la DLT, tabla de escalado y
diagrama.

**Alimenta:** C5 y C4.

**Trampas**
- Doble escritura: guardar el retiro y publicar el evento son dos operaciones que pueden fallar por
  separado. La resuelve el outbox.
- Orden roto con dos relays. Lo evita el líder único.
- Kafka entrega "al menos una vez": un evento puede llegar repetido. Se resuelve con idempotencia
  por id de evento.

**Debes poder explicar:**
- tópico, partición, offset y grupo;
- por qué la clave es la cuenta;
- outbox y doble escritura;
- reintentos bloqueantes versus no bloqueantes;
- Kafka versus JMS.

### F8. Despliegue con calidad de producción (S)

**Objetivo:** imágenes y compose eficientes, portables y sin secretos, con mediciones que lo prueben.

**Tareas**
- Tabla con el tamaño de imagen, el tiempo de arranque y la memoria de cada servicio.
- Límites de recursos en el compose.
- Comprobar el usuario no root y que no haya secretos en las capas (`docker history`).
- Imágenes base multiarquitectura. **HECHO:** las bases elegidas (temurin 21 JRE alpine, postgres 16
  alpine, apache/kafka, kafbat/kafka-ui y maven) publican amd64 y arm64, así que corren también en
  equipos Apple Silicon.
- `docker compose config` sin advertencias.
- CDS (Class Data Sharing, una técnica de la JVM para arrancar más rápido) es opcional: solo se
  agrega si mejora el arranque de forma medible.

**Terminado cuando:** la tabla está completa y medida, y no hay ninguna advertencia.

**Evidencia:** tabla de mediciones.

**Alimenta:** C2 ("despliegue eficiente", "portabilidad") y C3 ("correctamente").

### F9. Verificación integral y evidencias (M)

**Objetivo:** un comando reproduce todo y dice PASS o FAIL por criterio.

**Tareas**
- `scripts/verificar.sh` levanta el sistema, ejecuta todas las comprobaciones y escribe
  `evidencias/salidas/NN-*.txt` con el comando y su salida literal.
- `evidencias/INDICE.md` indica qué criterio prueba cada archivo.
- Capturas con un navegador headless: dashboard de Eureka, Kafka UI y login del `auth-server`.
- Evidencia por microservicio, como piden las instrucciones: arranque, salud y un resultado de cada
  uno.
- Sin CI en GitHub Actions: lo descartó el usuario el 3 de octubre (no lo pidió, y en un
  repositorio privado cada corrida gasta minutos de su cuota). La verificación es local.
- Ensayo en frío desde un clon limpio: aquí y después en tu computador.

**Terminado cuando:** todo da PASS en un clon limpio, y la evidencia coincide con el README.

**Alimenta:** C6, y respalda a todos los demás.

### F10. Documentación y entrega (M)

**Objetivo:** el evaluador entiende y verifica el sistema en minutos.

**Tareas**
- README con: objetivo, arquitectura, estructura del código, ejecución paso a paso, endpoints,
  seguridad, resiliencia, eventos, despliegue, trazabilidad con la pauta, decisiones y
  limitaciones.
- `docs/propuesta-tecnica.md`, que la entrega pide.
- Diagrama de eventos.
- Guía de estudio con preguntas y respuestas para explicar cada decisión.
- Fusionar en `main`, que es lo que va a ver el evaluador.
- Zip `Exp3_S8_Nombres_Apellidos` con código, README y evidencias en una misma carpeta.
- Checklist final (sección 10).

**Alimenta:** C6.

---

## 8. Trazabilidad: criterio, fases y evidencia

| Criterio | Pts | Fases | Evidencia clave |
|---|---|---|---|
| 1 OAuth2 | 20 | F4, F5 | matriz del core, login por canal, matriz 3x3, bloqueo por PIN |
| 2 Imágenes | 20 | F2, F8 | construcción limpia, tabla de mediciones, usuario no root |
| 3 Compose | 20 | F1, F2, F3, F7, F8 | arranque en frío, todo healthy, reinicio automático, escalado |
| 4 Resilience4j | 20 | F6, F7 | transiciones del circuito, bulkhead, réplica caída, outbox con Kafka detenido |
| 5 Kafka | 15 | F7 | difusión a dos grupos, DLT, tabla de escalado |
| 6 Entrega | 5 | F9, F10 | README, propuesta técnica, índice de evidencias |

---

## 9. Riesgos y mitigaciones

| Riesgo | Afecta | Mitigación |
|---|---|---|
| Emisor del token distinto dentro y fuera de Docker | C1 | Emisor fijo y JWKS interno (D3) |
| Secretos que el usuario no root no puede leer | C2, C3 | UID fijo, `chown` en el init, volumen por servicio |
| Un servicio arranca antes que su dependencia | C3 | Healthchecks, `depends_on` con condición y reintentos de config y Eureka |
| Orden de eventos roto con 2 réplicas | C5 | Relay con líder único |
| La carga en PostgreSQL no reproduce los números del S5 | regresión | Prueba de regresión con los números del S5 |
| El `device_id` no llega al token | C1 | Alternativa: registro de dispositivos por usuario (A VERIFICAR en F5) |
| El login con PKCE es difícil de automatizar | evidencia C1 | Script con curl y cookies, más captura con navegador headless |
| Docker Desktop antiguo, sin funciones recientes de compose | C3 | Versión mínima en el README, comprobada al inicio del script |
| Construcción lenta o límite de descargas de Maven Central (429 visto aquí) | C2 | Caché de BuildKit y no repetir descargas en frío |
| Kafka caído al arrancar deja servicios sin levantar | C3, C4 | El core no depende de Kafka para arrancar; los consumidores reintentan |

---

## 10. Checklist final

- [ ] `git clone` y `docker compose up -d --build` en una carpeta nueva, sin pasos manuales.
- [ ] Todos los servicios healthy, y `scripts/verificar.sh` con todo PASS.
- [ ] Los 9 microservicios tienen su Dockerfile y su evidencia de ejecución.
- [ ] El compose incluye todos los componentes del diagrama.
- [ ] Ningún secreto versionado; `docker history` limpio.
- [ ] Ningún BFF emite tokens, y `X-Service-Token` ya no existe.
- [ ] La lista de no regresión del S5 pasa completa.
- [ ] Cada cifra del README coincide con su evidencia.
- [ ] El README tiene objetivo, estructura e instrucciones; la propuesta técnica está presente.
- [ ] `main` contiene la entrega final.
- [ ] El zip tiene el nombre correcto, y todo va en una carpeta.
- [ ] El ensayo en tu computador está hecho.

---

## 11. Pendientes y supuestos

- **Nombre completo para el zip:** pendiente.
- **Sistema operativo del evaluador:** desconocido. Supuesto: Docker Desktop reciente, con Compose
  v2, en Windows o macOS. El camino principal (`docker compose up`) es igual en todos. Los scripts
  de evidencia son bash: Linux, macOS, Git Bash o WSL.
- **Formativas S6 y S7:** no se entregaron en estos repos. Su contenido (Config Server, Eureka,
  Resilience4j, Kafka) se construye aquí.
- **Extensiones posibles fuera del plan base:** migración con Spring Batch (D4), mTLS interno (D3) y
  trazas distribuidas. Solo si todo lo anterior está cerrado con evidencia.
