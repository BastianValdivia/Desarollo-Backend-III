package cl.duoc.bancoxyz.auth;

import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.EMISOR;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;

/**
 * El descubrimiento OIDC y el JWKS son publicos, llevan el emisor FIJO y no filtran la clave privada.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class DescubrimientoOidcTest {

    @DynamicPropertySource
    static void material(DynamicPropertyRegistry registro) {
        MaterialDePrueba.registrar(registro);
    }

    @Autowired
    private TestRestTemplate http;

    @Test
    @DisplayName("El descubrimiento responde sin credenciales y declara el emisor fijo")
    @SuppressWarnings("unchecked")
    void descubrimiento() {
        ResponseEntity<Map> respuesta = http.getForEntity("/.well-known/openid-configuration", Map.class);

        assertThat(respuesta.getStatusCode().value()).isEqualTo(200);
        Map<String, Object> doc = respuesta.getBody();
        // Fijo: no depende del nombre ni del puerto con que se hizo la peticion (aqui, http://localhost:<aleatorio>).
        assertThat(doc.get("issuer")).isEqualTo(EMISOR);
        assertThat(doc.get("token_endpoint")).isEqualTo(EMISOR + "/oauth2/token");
        assertThat(doc.get("jwks_uri")).isEqualTo(EMISOR + "/oauth2/jwks");
        assertThat((List<String>) doc.get("grant_types_supported")).contains("client_credentials");
        assertThat((List<String>) doc.get("token_endpoint_auth_methods_supported")).contains("client_secret_basic");
    }

    @Test
    @DisplayName("El JWKS publica una sola clave RSA con kid y sin ningun componente privado")
    @SuppressWarnings("unchecked")
    void jwks() {
        ResponseEntity<Map> respuesta = http.getForEntity("/oauth2/jwks", Map.class);

        assertThat(respuesta.getStatusCode().value()).isEqualTo(200);
        List<Map<String, Object>> claves = (List<Map<String, Object>>) respuesta.getBody().get("keys");
        assertThat(claves).hasSize(1);
        Map<String, Object> clave = claves.get(0);
        assertThat(clave).containsEntry("kty", "RSA").containsEntry("use", "sig").containsEntry("alg", "RS256");
        assertThat(clave).containsKeys("kid", "n", "e");
        // Componentes privados de una clave RSA JWK (RFC 7518, 6.3.2): ninguno puede estar publicado.
        assertThat(clave).doesNotContainKeys("d", "p", "q", "dp", "dq", "qi");
    }

    @Test
    @DisplayName("Una ruta cualquiera exige autenticacion: sin sesion no se ve nada y se manda al formulario de login")
    void rutaDesconocidaExigeAutenticacion() {
        // Desde F5 la cadena de respaldo tiene formulario de login: quien no tiene sesion recibe 302 a /login
        // (antes, sin login posible, recibia 401). Lo que no cambia es que NINGUNA ruta se sirve sin autenticar.
        for (String ruta : List.of("/cualquier-cosa", "/actuator/health", "/userinfo", "/oauth2/introspect")) {
            ResponseEntity<String> respuesta = http.getForEntity(ruta, String.class);
            assertThat(respuesta.getStatusCode().value()).as(ruta).isIn(302, 401, 405);
            assertThat(respuesta.getBody() == null || !respuesta.getBody().contains("UP")).as(ruta).isTrue();
        }
        ResponseEntity<String> sinSesion = http.getForEntity("/cualquier-cosa", String.class);
        assertThat(sinSesion.getHeaders().getLocation()).isNotNull();
        assertThat(sinSesion.getHeaders().getLocation().getPath()).isEqualTo("/login");
    }
}
