package cl.duoc.bancoxyz.auth;

import static cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode.desafio;
import static cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode.nuevoVerifier;
import static cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode.parametroDeLaRedireccion;
import static cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode.solicitud;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.EMISOR;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode;
import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;
import cl.duoc.bancoxyz.auth.usuarios.RegistroIntentosClave;

/**
 * Los flujos {@code authorization_code} con PKCE de {@code web-app} y {@code mobile-app}, de punta a punta
 * contra el servidor real (sus cadenas de seguridad, su formulario de login, sus clientes y su
 * personalizador de tokens), con la configuracion de {@code config-repo}.
 *
 * <p>Lo que se prueba, agrupado por la pregunta que responde:
 * <ul>
 *   <li>Que lleva el token: audiencia, canal, cuenta, autoridades, vigencia, {@code device_id}.</li>
 *   <li>Que protege el flujo: PKCE obligatorio y solo S256, codigo de un solo uso, redirect URI exacta,
 *       CSRF en el formulario, clave incorrecta, cliente publico sin otros grants.</li>
 *   <li>Que decide el banco: el movil exige dispositivo y no admite a quien no tiene canal movil.</li>
 * </ul>
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
class LoginWebYMovilTest {

    private static final String WEB = "web-app";
    private static final String MOVIL = "mobile-app";
    private static final String REDIRECT_WEB = "http://127.0.0.1:3000/callback";
    private static final String REDIRECT_MOVIL = "http://127.0.0.1:3001/callback";
    private static final String CLAVE_CLIENTE = "Cliente.2026";
    private static final String CLAVE_EJECUTIVO = "Exec.2026";
    private static final ObjectMapper JSON = new ObjectMapper();

    @DynamicPropertySource
    static void material(DynamicPropertyRegistry registro) {
        MaterialDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;

    @Autowired
    private RegistroIntentosClave intentos;

    private FlujoAuthorizationCode flujo;

    /**
     * Las pruebas comparten UN contexto y por lo tanto UN registro de intentos de clave: varias fallan la clave a
     * proposito y, sumadas, bloquearian a cliente116 para las que vengan despues. Cada una parte con los
     * contadores en cero con la misma operacion que el servidor ejecuta tras una clave correcta. El bloqueo en
     * si se prueba en {@code BloqueoDeClaveTest}.
     */
    @BeforeEach
    void preparar() {
        flujo = new FlujoAuthorizationCode(mvc);
        List.of("cliente116", "cliente105", "ejecutivo1").forEach(intentos::registrarExito);
    }

    // ------------------------------------------------------------------ lo que lleva el token

    @Test
    @DisplayName("Web: el cliente116 inicia sesion con PKCE y recibe un token de 30 minutos para bff-web con sus claims")
    void tokenWebDelCliente() throws Exception {
        JsonNode tokens = flujo.obtenerTokens(WEB, REDIRECT_WEB, "cliente116", CLAVE_CLIENTE, Map.of());

        assertThat(tokens.get("token_type").asText()).isEqualTo("Bearer");
        assertThat(tokens.get("expires_in").asLong()).isBetween(1795L, 1800L);
        assertThat(tokens.has("refresh_token")).as("sin refresh token").isFalse();
        assertThat(tokens.has("id_token")).as("sin id_token: no se pidio openid").isFalse();

        Jwt jwt = flujo.decodificar(tokens.get("access_token").asText(), EMISOR);
        assertThat(jwt.getSubject()).isEqualTo("cliente116");
        assertThat(jwt.getAudience()).containsExactly("bff-web");
        assertThat(jwt.getClaimAsString("canal")).isEqualTo("WEB");
        assertThat(((Number) jwt.getClaim("cuentaId")).intValue()).isEqualTo(116);
        assertThat(jwt.getClaimAsStringList("authorities")).containsExactly(
                "ROLE_CLIENTE_WEB", "PERM_cuenta:leer", "PERM_movimientos:leer", "PERM_resumen:leer");
        assertThat(jwt.getClaimAsString("client_id")).isEqualTo(WEB);
        assertThat(jwt.hasClaim("device_id")).as("el canal web no lleva dispositivo").isFalse();
        assertThat(Duration.between(jwt.getIssuedAt(), jwt.getExpiresAt())).isEqualTo(Duration.ofMinutes(30));
        assertThat(jwt.getHeaders()).containsEntry("alg", "RS256").containsKey("kid");
    }

    @Test
    @DisplayName("Web: el ejecutivo recibe rol y permiso de auditoria y NINGUN claim de cuenta")
    void tokenWebDelEjecutivo() throws Exception {
        JsonNode tokens = flujo.obtenerTokens(WEB, REDIRECT_WEB, "ejecutivo1", CLAVE_EJECUTIVO, Map.of());
        Jwt jwt = flujo.decodificar(tokens.get("access_token").asText(), EMISOR);

        assertThat(jwt.getSubject()).isEqualTo("ejecutivo1");
        assertThat(jwt.getAudience()).containsExactly("bff-web");
        assertThat(jwt.getClaimAsStringList("authorities")).containsExactly("ROLE_EJECUTIVO", "PERM_auditoria:leer");
        assertThat(jwt.hasClaim("cuentaId")).as("el ejecutivo no tiene cuenta").isFalse();
    }

    @Test
    @DisplayName("Web: cliente105 y cliente116 comparten permisos y se distinguen por la cuenta del token")
    void tokenWebDelOtroCliente() throws Exception {
        Jwt jwt = flujo.decodificar(flujo.obtenerTokens(WEB, REDIRECT_WEB, "cliente105", CLAVE_CLIENTE, Map.of())
                .get("access_token").asText(), EMISOR);
        assertThat(((Number) jwt.getClaim("cuentaId")).intValue()).isEqualTo(105);
        assertThat(jwt.getSubject()).isEqualTo("cliente105");
    }

    @Test
    @DisplayName("Movil: el token dura 60 minutos, es para bff-mobile, lleva sus autoridades moviles y el device_id")
    void tokenMovil() throws Exception {
        JsonNode tokens = flujo.obtenerTokens(MOVIL, REDIRECT_MOVIL, "cliente116", CLAVE_CLIENTE,
                Map.of("device_id", "dispositivo-demo-01"));
        assertThat(tokens.get("expires_in").asLong()).isBetween(3595L, 3600L);

        Jwt jwt = flujo.decodificar(tokens.get("access_token").asText(), EMISOR);
        assertThat(jwt.getSubject()).isEqualTo("cliente116");
        assertThat(jwt.getAudience()).containsExactly("bff-mobile");
        assertThat(jwt.getClaimAsString("canal")).isEqualTo("MOVIL");
        assertThat(((Number) jwt.getClaim("cuentaId")).intValue()).isEqualTo(116);
        assertThat(jwt.getClaimAsStringList("authorities")).containsExactly(
                "ROLE_CLIENTE_MOVIL", "PERM_saldo:leer", "PERM_dispositivo:gestionar");
        assertThat(jwt.getClaimAsString("device_id")).isEqualTo("dispositivo-demo-01");
        assertThat(Duration.between(jwt.getIssuedAt(), jwt.getExpiresAt())).isEqualTo(Duration.ofMinutes(60));
    }

    @Test
    @DisplayName("A VERIFICAR del plan: el device_id de la solicitud de autorizacion llega al token por el contexto del "
            + "personalizador, y cada inicio de sesion lleva el suyo")
    void deviceIdLlegaAlToken() throws Exception {
        Jwt a = flujo.decodificar(flujo.obtenerTokens(MOVIL, REDIRECT_MOVIL, "cliente116", CLAVE_CLIENTE,
                Map.of("device_id", "telefono-A")).get("access_token").asText(), EMISOR);
        Jwt b = flujo.decodificar(flujo.obtenerTokens(MOVIL, REDIRECT_MOVIL, "cliente116", CLAVE_CLIENTE,
                Map.of("device_id", "telefono-B")).get("access_token").asText(), EMISOR);
        assertThat(a.getClaimAsString("device_id")).isEqualTo("telefono-A");
        assertThat(b.getClaimAsString("device_id")).isEqualTo("telefono-B");
    }

    @Test
    @DisplayName("Un token web y uno movil del mismo usuario NO son intercambiables: audiencia y canal distintos")
    void tokensDeCanalesDistintos() throws Exception {
        Jwt web = flujo.decodificar(flujo.obtenerTokens(WEB, REDIRECT_WEB, "cliente116", CLAVE_CLIENTE, Map.of())
                .get("access_token").asText(), EMISOR);
        Jwt movil = flujo.decodificar(flujo.obtenerTokens(MOVIL, REDIRECT_MOVIL, "cliente116", CLAVE_CLIENTE,
                Map.of("device_id", "telefono-A")).get("access_token").asText(), EMISOR);
        assertThat(web.getAudience()).isNotEqualTo(movil.getAudience());
        assertThat(web.getClaimAsStringList("authorities")).isNotEqualTo(movil.getClaimAsStringList("authorities"));
        // Una sola clave de firma para todo: la barrera entre canales es la audiencia (D2).
        assertThat(web.getHeaders().get("kid")).isEqualTo(movil.getHeaders().get("kid"));
    }

    // ------------------------------------------------------------------ lo que protege el flujo

    @Test
    @DisplayName("Sin sesion, /oauth2/authorize manda al formulario de login y no entrega ningun codigo")
    void sinSesionVaAlLogin() throws Exception {
        MvcResult r = flujo.autorizar(solicitud(WEB, REDIRECT_WEB, nuevoVerifier()), null);
        assertThat(r.getResponse().getStatus()).isEqualTo(302);
        assertThat(r.getResponse().getRedirectedUrl()).endsWith("/login");
        assertThat(parametroDeLaRedireccion(r, "code")).isNull();
    }

    @Test
    @DisplayName("El formulario es HTML con campo _csrf, en espanol, y se sirve sin sesion previa")
    void formularioDeLogin() throws Exception {
        String html = mvc.perform(get("/login")).andReturn().getResponse().getContentAsString();
        assertThat(html).contains("name=\"username\"", "name=\"password\"", "name=\"_csrf\"")
                .contains("Iniciar sesión").doesNotContain("http://", "https://", "<script");
    }

    @Test
    @DisplayName("La pagina de login lleva una Content-Security-Policy restrictiva: no carga nada, no se incrusta, y no limita form-action")
    void formularioDeLoginConPoliticaDeContenido() throws Exception {
        String politica = mvc.perform(get("/login")).andReturn().getResponse().getHeader("Content-Security-Policy");
        assertThat(politica).contains("default-src 'none'", "frame-ancestors 'none'", "base-uri 'none'")
                .doesNotContain("script-src", "*");
        // form-action 'self' bloquearia en Chrome la redireccion a la redirect_uri de la aplicacion tras el login.
        assertThat(politica).doesNotContain("form-action");
    }

    @ParameterizedTest
    @ValueSource(strings = {"bff-web", "bff-mobile", "bff-atm", "atm-scl-001"})
    @DisplayName("Un cliente sin authorization_code que pide autorizacion recibe 400 (no 500), sin redireccion aunque traiga redirect_uri")
    void clienteSinAuthorizationCodeNoPuedePedirAutorizacion(String clienteId) throws Exception {
        // El conversor de Spring lee la cadena de consulta de la URL (no los parametros que .param() agrega), asi que
        // la solicitud se arma como la haria un navegador.
        MvcResult simple = mvc.perform(get("/oauth2/authorize?response_type=code&client_id=" + clienteId)).andReturn();
        assertThat(simple.getResponse().getStatus()).isEqualTo(400);
        assertThat(simple.getResponse().getErrorMessage()).contains("unauthorized_client");

        MvcResult conRedireccion = mvc.perform(get("/oauth2/authorize?response_type=code&client_id=" + clienteId
                + "&redirect_uri=http://evil.example/cb&scope=cuentas:leer")).andReturn();
        assertThat(conRedireccion.getResponse().getStatus()).isEqualTo(400);
        assertThat(conRedireccion.getResponse().getErrorMessage()).contains("unauthorized_client");
        assertThat(conRedireccion.getResponse().getRedirectedUrl()).isNull();
        assertThat(conRedireccion.getResponse().getHeader("Location")).isNull();
    }

    @Test
    @DisplayName("Login CSRF: un POST a /login sin el token de la sesion se rechaza con 403")
    void loginSinCsrf() throws Exception {
        MvcResult r = mvc.perform(post("/login").param("username", "cliente116").param("password", CLAVE_CLIENTE))
                .andReturn();
        assertThat(r.getResponse().getStatus()).isEqualTo(403);
    }

    @Test
    @DisplayName("Una clave incorrecta vuelve al formulario con error y no entrega codigo; usuario inexistente da lo mismo")
    void claveIncorrecta() throws Exception {
        for (String usuario : List.of("cliente116", "nadie")) {
            MvcResult r = flujo.autorizarConLogin(solicitud(WEB, REDIRECT_WEB, nuevoVerifier()), usuario, "mala-clave");
            assertThat(r.getResponse().getRedirectedUrl()).as(usuario).isEqualTo("/login?error");
        }
    }

    @Test
    @DisplayName("Una credencial incompleta (usuario o clave vacios) se rechaza igual que una incorrecta, sin 500")
    void credencialIncompleta() throws Exception {
        MvcResult sinSesion = flujo.autorizar(solicitud(WEB, REDIRECT_WEB, nuevoVerifier()), null);
        MockHttpSession sesion = (MockHttpSession) sinSesion.getRequest().getSession(false);
        for (String[] par : new String[][] {{"", ""}, {"cliente116", ""}, {"", CLAVE_CLIENTE}}) {
            MvcResult r = flujo.iniciarSesion(sesion, par[0], par[1]);
            assertThat(r.getResponse().getStatus()).isEqualTo(302);
            assertThat(r.getResponse().getRedirectedUrl()).isEqualTo("/login?error");
        }
    }

    @Test
    @DisplayName("PKCE es obligatorio: sin code_challenge el servidor rechaza la solicitud y no entrega codigo")
    void pkceObligatorio() throws Exception {
        Map<String, String> sinPkce = solicitud(WEB, REDIRECT_WEB, nuevoVerifier());
        sinPkce.remove("code_challenge");
        sinPkce.remove("code_challenge_method");
        MvcResult r = flujo.autorizarConLogin(sinPkce, "cliente116", CLAVE_CLIENTE);
        assertThat(parametroDeLaRedireccion(r, "code")).isNull();
        assertThat(parametroDeLaRedireccion(r, "error")).isEqualTo("invalid_request");
    }

    @Test
    @DisplayName("Solo se admite el metodo S256: plain (el desafio en claro) se rechaza")
    void soloS256() throws Exception {
        String verifier = nuevoVerifier();
        Map<String, String> plain = solicitud(WEB, REDIRECT_WEB, verifier);
        plain.put("code_challenge", verifier);
        plain.put("code_challenge_method", "plain");
        MvcResult r = flujo.autorizarConLogin(plain, "cliente116", CLAVE_CLIENTE);
        assertThat(parametroDeLaRedireccion(r, "code")).isNull();
        assertThat(parametroDeLaRedireccion(r, "error")).isEqualTo("invalid_request");
    }

    @Test
    @DisplayName("Canje sin code_verifier, o con uno que no corresponde al desafio, no entrega token")
    void canjeSinVerifierCorrecto() throws Exception {
        String verifier = nuevoVerifier();
        MvcResult fin = flujo.autorizarConLogin(solicitud(WEB, REDIRECT_WEB, verifier), "cliente116", CLAVE_CLIENTE);
        String codigo = parametroDeLaRedireccion(fin, "code");
        assertThat(codigo).isNotBlank();

        MvcResult sinVerifier = flujo.canjear(WEB, REDIRECT_WEB, codigo, null);
        assertThat(sinVerifier.getResponse().getStatus()).isBetween(400, 401);
        assertThat(sinVerifier.getResponse().getContentAsString()).doesNotContain("access_token");

        MvcResult otroVerifier = flujo.canjear(WEB, REDIRECT_WEB, codigo, nuevoVerifier());
        assertThat(otroVerifier.getResponse().getStatus()).isEqualTo(400);
        assertThat(otroVerifier.getResponse().getContentAsString())
                .contains("invalid_grant").doesNotContain("access_token");
    }

    @Test
    @DisplayName("El codigo es de un solo uso: canjearlo dos veces falla la segunda")
    void codigoDeUnSoloUso() throws Exception {
        String verifier = nuevoVerifier();
        MvcResult fin = flujo.autorizarConLogin(solicitud(WEB, REDIRECT_WEB, verifier), "cliente116", CLAVE_CLIENTE);
        String codigo = parametroDeLaRedireccion(fin, "code");

        MvcResult primero = flujo.canjear(WEB, REDIRECT_WEB, codigo, verifier);
        assertThat(primero.getResponse().getStatus()).isEqualTo(200);
        MvcResult segundo = flujo.canjear(WEB, REDIRECT_WEB, codigo, verifier);
        assertThat(segundo.getResponse().getStatus()).isEqualTo(400);
        assertThat(segundo.getResponse().getContentAsString()).contains("invalid_grant");
    }

    @Test
    @DisplayName("El codigo emitido para web-app no se canjea como mobile-app (queda atado a su cliente)")
    void codigoAtadoAlCliente() throws Exception {
        String verifier = nuevoVerifier();
        MvcResult fin = flujo.autorizarConLogin(solicitud(WEB, REDIRECT_WEB, verifier), "cliente116", CLAVE_CLIENTE);
        MvcResult robado = flujo.canjear(MOVIL, REDIRECT_MOVIL, parametroDeLaRedireccion(fin, "code"), verifier);
        assertThat(robado.getResponse().getStatus()).isEqualTo(400);
        assertThat(robado.getResponse().getContentAsString()).contains("invalid_grant").doesNotContain("access_token");
    }

    @ParameterizedTest(name = "redirect URI no registrada: {0}")
    @ValueSource(strings = {
            "http://127.0.0.1:3000/otra-ruta",
            "http://127.0.0.1:3000/callback/",
            "http://127.0.0.1:3000/callback/../callback",
            "http://localhost:3000/callback",
            "http://127.0.0.2:3000/callback",
            "https://127.0.0.1:3000/callback",
            "http://evil.example.com/callback",
            "http://127.0.0.1@evil.example.com/callback",
    })
    @DisplayName("La redirect URI debe coincidir con la registrada (host y ruta exactos): la rechazada no recibe el codigo")
    void redirectUriExacta(String intento) throws Exception {
        MvcResult r = flujo.autorizarConLogin(solicitud(WEB, intento, nuevoVerifier()), "cliente116", CLAVE_CLIENTE);
        // Error SIN redireccion: devolver el error a una direccion no confiable seria otra fuga.
        assertThat(parametroDeLaRedireccion(r, "code")).isNull();
        String destino = r.getResponse().getRedirectedUrl();
        assertThat(destino == null || !destino.startsWith(intento)).as("no redirige a " + intento).isTrue();
    }

    @Test
    @DisplayName("En loopback el puerto es libre (RFC 8252, 7.3): un puerto efimero distinto del registrado se acepta")
    void puertoLibreEnLoopback() throws Exception {
        MvcResult r = flujo.autorizarConLogin(solicitud(WEB, "http://127.0.0.1:54321/callback", nuevoVerifier()),
                "cliente116", CLAVE_CLIENTE);
        assertThat(r.getResponse().getRedirectedUrl()).startsWith("http://127.0.0.1:54321/callback?code=");
    }

    @Test
    @DisplayName("El parametro state vuelve intacto en la redireccion")
    void stateVuelve() throws Exception {
        Map<String, String> parametros = solicitud(WEB, REDIRECT_WEB, nuevoVerifier());
        MvcResult fin = flujo.autorizarConLogin(parametros, "cliente116", CLAVE_CLIENTE);
        assertThat(parametroDeLaRedireccion(fin, "state")).isEqualTo(parametros.get("state"));
    }

    @Test
    @DisplayName("Un cliente publico no puede usar client_credentials, password ni refresh: solo authorization_code")
    void clientePublicoSoloAuthorizationCode() throws Exception {
        for (String grant : List.of("client_credentials", "password", "refresh_token")) {
            MvcResult r = mvc.perform(post("/oauth2/token").contentType("application/x-www-form-urlencoded")
                    .param("grant_type", grant).param("client_id", WEB)
                    .param("username", "cliente116").param("password", CLAVE_CLIENTE).param("refresh_token", "x"))
                    .andReturn();
            assertThat(r.getResponse().getStatus()).as(grant).isBetween(400, 401);
            assertThat(r.getResponse().getContentAsString()).as(grant).doesNotContain("access_token");
        }
    }

    @Test
    @DisplayName("Las aplicaciones no piden consentimiento: del login se pasa directo al codigo")
    void sinConsentimiento() throws Exception {
        MvcResult fin = flujo.autorizarConLogin(solicitud(WEB, REDIRECT_WEB, nuevoVerifier()), "cliente116", CLAVE_CLIENTE);
        assertThat(fin.getResponse().getRedirectedUrl()).startsWith(REDIRECT_WEB + "?code=");
        assertThat(fin.getResponse().getContentAsString()).doesNotContain("consent");
    }

    // ------------------------------------------------------------------ lo que decide el banco

    @Test
    @DisplayName("Movil sin device_id: el servidor rechaza la solicitud (invalid_request) y no entrega codigo")
    void movilSinDispositivo() throws Exception {
        MvcResult r = flujo.autorizarConLogin(solicitud(MOVIL, REDIRECT_MOVIL, nuevoVerifier()),
                "cliente116", CLAVE_CLIENTE);
        assertThat(parametroDeLaRedireccion(r, "code")).isNull();
        assertThat(parametroDeLaRedireccion(r, "error")).isEqualTo("invalid_request");
    }

    @ParameterizedTest(name = "device_id invalido: [{0}]")
    @ValueSource(strings = {" ", "con espacios", "<script>alert(1)</script>", "../../etc/passwd", "a;b", "x\ny"})
    @DisplayName("El device_id solo admite letras, digitos y . _ : - ; cualquier otro texto se rechaza")
    void dispositivoConFormatoInvalido(String malo) throws Exception {
        Map<String, String> parametros = solicitud(MOVIL, REDIRECT_MOVIL, nuevoVerifier());
        parametros.put("device_id", malo);
        MvcResult r = flujo.autorizarConLogin(parametros, "cliente116", CLAVE_CLIENTE);
        assertThat(parametroDeLaRedireccion(r, "code")).isNull();
        assertThat(parametroDeLaRedireccion(r, "error")).isEqualTo("invalid_request");
    }

    @Test
    @DisplayName("device_id de mas de 100 caracteres se rechaza; de exactamente 100 se acepta")
    void largoDelDispositivo() throws Exception {
        Map<String, String> largo = solicitud(MOVIL, REDIRECT_MOVIL, nuevoVerifier());
        largo.put("device_id", "d".repeat(101));
        assertThat(parametroDeLaRedireccion(flujo.autorizarConLogin(largo, "cliente116", CLAVE_CLIENTE), "error"))
                .isEqualTo("invalid_request");
        Map<String, String> justo = solicitud(MOVIL, REDIRECT_MOVIL, nuevoVerifier());
        justo.put("device_id", "d".repeat(100));
        assertThat(parametroDeLaRedireccion(flujo.autorizarConLogin(justo, "cliente116", CLAVE_CLIENTE), "code"))
                .isNotBlank();
    }

    @Test
    @DisplayName("El ejecutivo (sin canal movil) y cliente105 (tampoco) no reciben codigo en mobile-app: access_denied")
    void usuariosSinCanalMovil() throws Exception {
        for (Map.Entry<String, String> u : Map.of("ejecutivo1", CLAVE_EJECUTIVO, "cliente105", CLAVE_CLIENTE).entrySet()) {
            Map<String, String> parametros = solicitud(MOVIL, REDIRECT_MOVIL, nuevoVerifier());
            parametros.put("device_id", "telefono-A");
            MvcResult r = flujo.autorizarConLogin(parametros, u.getKey(), u.getValue());
            assertThat(parametroDeLaRedireccion(r, "code")).as(u.getKey()).isNull();
            assertThat(parametroDeLaRedireccion(r, "error")).as(u.getKey()).isEqualTo("access_denied");
        }
    }

    @Test
    @DisplayName("Una sesion abierta en el canal web no sirve para sacar un token movil con otros permisos: el canal lo decide el cliente")
    void lasAutoridadesSalenDelCanalDelCliente() throws Exception {
        // Mismo usuario, dos clientes: las autoridades cambian con el canal del cliente, no con la sesion.
        MvcResult primero = flujo.autorizar(solicitud(WEB, REDIRECT_WEB, nuevoVerifier()), null);
        MockHttpSession sesion = (MockHttpSession) primero.getRequest().getSession(false);
        MvcResult login = flujo.iniciarSesion(sesion, "ejecutivo1", CLAVE_EJECUTIVO);
        MockHttpSession autenticada = (MockHttpSession) login.getRequest().getSession(false);

        Map<String, String> movil = solicitud(MOVIL, REDIRECT_MOVIL, nuevoVerifier());
        movil.put("device_id", "telefono-A");
        MvcResult r = flujo.autorizar(movil, autenticada);
        assertThat(parametroDeLaRedireccion(r, "code")).isNull();
        assertThat(parametroDeLaRedireccion(r, "error")).isEqualTo("access_denied");
    }

    @Test
    @DisplayName("El desafio PKCE de la prueba coincide con el ejemplo de la RFC 7636 (apendice B)")
    void desafioS256DeLaRfc() {
        assertThat(desafio("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"))
                .isEqualTo("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM");
    }
}
