package cl.duoc.bancoxyz.auth.soporte;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;

/**
 * Ayudante de las pruebas del flujo {@code authorization_code} con PKCE: hace con MockMvc lo mismo que
 * {@code scripts/login-web.sh} hace con curl (pedir autorizacion, iniciar sesion en el formulario con su
 * token CSRF, recibir el codigo en la redireccion y canjearlo con el {@code code_verifier}).
 *
 * <p>Cada metodo es un paso del flujo y devuelve el resultado crudo, para que la prueba pueda mirar tanto
 * el camino feliz como el punto exacto donde un caso malo se corta.
 */
public final class FlujoAuthorizationCode {

    private static final ObjectMapper JSON = new ObjectMapper();
    private static final SecureRandom ALEATORIO = new SecureRandom();

    private final MockMvc mvc;

    public FlujoAuthorizationCode(MockMvc mvc) {
        this.mvc = mvc;
    }

    /** Un {@code code_verifier} valido (43 caracteres, RFC 7636). */
    public static String nuevoVerifier() {
        byte[] bytes = new byte[32];
        ALEATORIO.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    /** {@code code_challenge} con el metodo S256: base64url(SHA-256(verifier)). */
    public static String desafio(String verifier) {
        try {
            byte[] huella = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(huella);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Parametros de una solicitud de autorizacion correcta; la prueba agrega o quita lo que quiera romper. */
    public static Map<String, String> solicitud(String clientId, String redirectUri, String verifier) {
        Map<String, String> parametros = new LinkedHashMap<>();
        parametros.put("response_type", "code");
        parametros.put("client_id", clientId);
        parametros.put("redirect_uri", redirectUri);
        parametros.put("state", "estado-" + Long.toHexString(ALEATORIO.nextLong()));
        parametros.put("code_challenge", desafio(verifier));
        parametros.put("code_challenge_method", "S256");
        return parametros;
    }

    /** Paso 1: pide autorizacion SIN sesion (o con la que se entregue). */
    public MvcResult autorizar(Map<String, String> parametros, MockHttpSession sesion) throws Exception {
        // Spring Authorization Server lee los parametros de /oauth2/authorize de la QUERY STRING: con
        // MockMvc hay que armarla en la URL (param(...) no la escribe) y codificarla como lo haria un navegador.
        UriComponentsBuilder url = UriComponentsBuilder.fromPath("/oauth2/authorize");
        parametros.forEach(url::queryParam);
        var peticion = get(url.build().encode().toUri());
        if (sesion != null) {
            peticion.session(sesion);
        }
        return mvc.perform(peticion).andReturn();
    }

    /** Paso 2: envia el formulario de login (con su CSRF) en la sesion donde quedo guardada la solicitud. */
    public MvcResult iniciarSesion(MockHttpSession sesion, String usuario, String clave) throws Exception {
        return mvc.perform(post("/login").param("username", usuario).param("password", clave)
                .with(csrf()).session(sesion)).andReturn();
    }

    /**
     * Pasos 1 y 2 y el regreso a {@code /oauth2/authorize}: devuelve el resultado FINAL de la autorizacion,
     * normalmente la redireccion a la redirect URI con el codigo (o con el error).
     */
    public MvcResult autorizarConLogin(Map<String, String> parametros, String usuario, String clave) throws Exception {
        MvcResult sinSesion = autorizar(parametros, null);
        String primero = sinSesion.getResponse().getRedirectedUrl();
        if (primero == null || !primero.endsWith("/login")) {
            // La solicitud se rechazo ANTES de pedir login (PKCE ausente, device_id invalido, redirect URI
            // no registrada...): ese es el resultado que la prueba quiere ver.
            return sinSesion;
        }
        MockHttpSession sesion = (MockHttpSession) sinSesion.getRequest().getSession(false);
        MvcResult login = iniciarSesion(sesion, usuario, clave);
        String destino = login.getResponse().getRedirectedUrl();
        if (destino == null || !destino.contains("/oauth2/authorize")) {
            return login; // el login fallo: la prueba mira a donde redirigio
        }
        MockHttpSession autenticada = (MockHttpSession) login.getRequest().getSession(false);
        URI uri = URI.create(destino);
        return mvc.perform(get(uri.getRawPath() + "?" + uri.getRawQuery()).session(autenticada)).andReturn();
    }

    /** Paso 4: canjea el codigo en {@code /oauth2/token} con el {@code code_verifier}. */
    public MvcResult canjear(String clientId, String redirectUri, String codigo, String verifier) throws Exception {
        var peticion = post("/oauth2/token")
                .contentType("application/x-www-form-urlencoded")
                .param("grant_type", "authorization_code")
                .param("client_id", clientId)
                .param("redirect_uri", redirectUri)
                .param("code", codigo);
        if (verifier != null) {
            peticion.param("code_verifier", verifier);
        }
        return mvc.perform(peticion).andReturn();
    }

    /** Extrae un parametro de la redireccion (en la query), o {@code null} si no esta. */
    public static String parametroDeLaRedireccion(MvcResult resultado, String nombre) {
        String ubicacion = resultado.getResponse().getRedirectedUrl();
        if (ubicacion == null) {
            return null;
        }
        return UriComponentsBuilder.fromUriString(ubicacion).build().getQueryParams().getFirst(nombre);
    }

    /** Camino feliz completo: devuelve el cuerpo JSON de la respuesta del endpoint de tokens. */
    public JsonNode obtenerTokens(String clientId, String redirectUri, String usuario, String clave,
                                  Map<String, String> extra) throws Exception {
        String verifier = nuevoVerifier();
        Map<String, String> parametros = solicitud(clientId, redirectUri, verifier);
        parametros.putAll(extra);
        MvcResult fin = autorizarConLogin(parametros, usuario, clave);
        String codigo = parametroDeLaRedireccion(fin, "code");
        if (codigo == null) {
            throw new IllegalStateException("No hubo codigo: " + fin.getResponse().getRedirectedUrl()
                    + " status=" + fin.getResponse().getStatus());
        }
        return JSON.readTree(canjear(clientId, redirectUri, codigo, verifier).getResponse().getContentAsString());
    }

    /** Valida firma y emisor del token contra el JWKS que publica el propio servidor, y lo decodifica. */
    public Jwt decodificar(String token, String emisor) throws Exception {
        String jwks = mvc.perform(get("/oauth2/jwks")).andReturn().getResponse().getContentAsString();
        RSAKey clave = (RSAKey) JWKSet.parse(jwks).getKeys().get(0);
        NimbusJwtDecoder decodificador = NimbusJwtDecoder.withPublicKey(clave.toRSAPublicKey()).build();
        decodificador.setJwtValidator(JwtValidators.createDefaultWithIssuer(emisor));
        return decodificador.decode(token);
    }
}
