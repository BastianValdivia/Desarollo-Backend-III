package cl.duoc.bancoxyz.auth;

import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.SECRETO_TERMINAL;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.TERMINAL;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.time.Duration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;
import cl.duoc.bancoxyz.auth.soporte.RelojMutable;
import cl.duoc.bancoxyz.auth.tarjeta.RegistroIntentosPin;

/**
 * El bloqueo de 15 minutos de una tarjeta, con un reloj que se adelanta a voluntad: esperar quince minutos reales
 * en una prueba no es una opcion.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@Import(BloqueoDePinTest.RelojAjustable.class)
class BloqueoDePinTest {

    @TestConfiguration
    static class RelojAjustable {
        @Bean
        @Primary
        RelojMutable relojDePrueba() {
            return new RelojMutable();
        }
    }

    @DynamicPropertySource
    static void material(DynamicPropertyRegistry registro) {
        MaterialDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private RelojMutable reloj;
    @Autowired
    private RegistroIntentosPin intentos;

    /** Cada prueba parte con la tarjeta sin fallos acumulados, sea cual sea el orden en que corran. */
    @BeforeEach
    void tarjetaSinFallos() {
        intentos.registrarExito("4000000000000116");
    }

    private String descripcion(String pin) throws Exception {
        String cuerpo = mvc.perform(post("/oauth2/token").with(httpBasic(TERMINAL, SECRETO_TERMINAL))
                        .contentType("application/x-www-form-urlencoded")
                        .param("grant_type", "urn:bancoxyz:params:oauth:grant-type:tarjeta-pin")
                        .param("numero_tarjeta", "4000000000000116").param("pin", pin))
                .andReturn().getResponse().getContentAsString();
        var json = new ObjectMapper().readTree(cuerpo);
        return json.has("error_description") ? json.get("error_description").asText() : "OK";
    }

    @Test
    @DisplayName("El bloqueo dura 15 minutos desde el ultimo fallo: a los 14 sigue bloqueada, pasados los 15 vuelve a autenticar")
    void elBloqueoVenceALosQuinceMinutos() throws Exception {
        assertThat(descripcion("0001")).isEqualTo("credenciales_invalidas");
        assertThat(descripcion("0002")).isEqualTo("credenciales_invalidas");
        assertThat(descripcion("0003")).isEqualTo("pin_bloqueado");

        reloj.avanzar(Duration.ofMinutes(14));
        assertThat(descripcion("1234")).as("a los 14 minutos el PIN correcto sigue sin servir").isEqualTo("pin_bloqueado");

        // Un intento durante el bloqueo no lo extiende: pasados 15 minutos desde el TERCER fallo, se libera.
        reloj.avanzar(Duration.ofMinutes(2));
        assertThat(descripcion("1234")).as("pasados los 15 minutos desde el tercer fallo").isEqualTo("OK");
    }

    @Test
    @DisplayName("Tras liberarse, la tarjeta cuenta de nuevo desde cero: hacen falta otros tres fallos para bloquearla")
    void tras15MinutosElContadorEmpiezaDeCero() throws Exception {
        for (String pin : new String[] {"0001", "0002", "0003"}) {
            descripcion(pin);
        }
        reloj.avanzar(Duration.ofMinutes(16));
        assertThat(descripcion("0004")).isEqualTo("credenciales_invalidas");
        assertThat(descripcion("0005")).isEqualTo("credenciales_invalidas");
        assertThat(descripcion("0006")).isEqualTo("pin_bloqueado");
    }

    @Test
    @DisplayName("Dos fallos separados por mas de la ventana no suman: el segundo ya cuenta como el primero")
    void fallosSeparadosPorLaVentanaNoSuman() throws Exception {
        assertThat(descripcion("0001")).isEqualTo("credenciales_invalidas");
        assertThat(descripcion("0002")).isEqualTo("credenciales_invalidas");
        reloj.avanzar(Duration.ofMinutes(16));
        // Si los fallos viejos sumaran, este seria el tercero y bloquearia. No suman: es el primero de una cuenta nueva.
        assertThat(descripcion("0003")).isEqualTo("credenciales_invalidas");
        assertThat(descripcion("0004")).isEqualTo("credenciales_invalidas");
        assertThat(descripcion("1234")).isEqualTo("OK");
    }
}
