package cl.duoc.bancoxyz.auth.soporte;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;

import org.springframework.test.context.DynamicPropertyRegistry;

/**
 * Claves de firma y secretos de cliente GENERADOS al correr la prueba.
 *
 * <p>Regla del proyecto: ninguna clave ni secreto de cliente vive en git, tampoco en las pruebas. Por eso
 * el par RSA se crea en cada ejecucion en una carpeta temporal (con el mismo formato PEM que deja
 * {@code secretos-init}: PKCS#8 la privada y X.509 la publica) y los secretos son UUID aleatorios. Los
 * valores se registran como propiedades de Spring con el mismo nombre que usan en operacion.
 */
public final class MaterialDePrueba {

    /** Los tres clientes de servicio, con la forma del config-repo. */
    public static final String WEB = "bff-web";
    public static final String MOVIL = "bff-mobile";
    public static final String ATM = "bff-atm";

    /** Secretos de esta ejecucion, por client_id. */
    public static final Map<String, String> SECRETOS = Map.of(
            WEB, UUID.randomUUID().toString(),
            MOVIL, UUID.randomUUID().toString(),
            ATM, UUID.randomUUID().toString());

    /** El terminal del cajero (cliente confidencial del grant tarjeta y PIN) y su secreto generado en el momento. */
    public static final String TERMINAL = "atm-scl-001";
    public static final String SECRETO_TERMINAL = UUID.randomUUID().toString();

    public static final String EMISOR = "https://localhost:9000";

    private static final Path CARPETA;
    private static final Path PRIVADA;
    private static final Path PUBLICA;

    static {
        try {
            CARPETA = Files.createTempDirectory("auth-server-prueba");
            KeyPair par = parRsa();
            PRIVADA = escribirPem(CARPETA.resolve("firma-private.pem"), "PRIVATE KEY", par.getPrivate().getEncoded());
            PUBLICA = escribirPem(CARPETA.resolve("firma-public.pem"), "PUBLIC KEY", par.getPublic().getEncoded());
            CARPETA.toFile().deleteOnExit();
            PRIVADA.toFile().deleteOnExit();
            PUBLICA.toFile().deleteOnExit();
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo preparar el material de prueba", e);
        }
    }

    private MaterialDePrueba() {
    }

    public static KeyPair parRsa() {
        try {
            KeyPairGenerator generador = KeyPairGenerator.getInstance("RSA");
            generador.initialize(2048);
            return generador.generateKeyPair();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static Path escribirPem(Path destino, String etiqueta, byte[] der) throws IOException {
        String pem = "-----BEGIN " + etiqueta + "-----\n"
                + Base64.getMimeEncoder(64, new byte[] {'\n'}).encodeToString(der)
                + "\n-----END " + etiqueta + "-----\n";
        return Files.writeString(destino, pem, StandardCharsets.US_ASCII);
    }

    public static Path privada() {
        return PRIVADA;
    }

    public static Path publica() {
        return PUBLICA;
    }

    /** Registra emisor, firma y secretos con los nombres que usa el servicio en operacion. */
    public static void registrar(DynamicPropertyRegistry registro) {
        registro.add("autorizacion.emisor", () -> EMISOR);
        registro.add("autorizacion.firma.clave-privada", () -> "file:" + PRIVADA);
        registro.add("autorizacion.firma.clave-publica", () -> "file:" + PUBLICA);
        SECRETOS.forEach((cliente, secreto) ->
                registro.add("autorizacion.clientes." + cliente + ".secreto", () -> secreto));
        registro.add("autorizacion.terminales." + TERMINAL + ".secreto", () -> SECRETO_TERMINAL);
    }
}
