package cl.duoc.bancoxyz.auth;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.TestingAuthenticationToken;

import cl.duoc.bancoxyz.auth.tarjeta.TarjetaPinAuthenticationToken;

/**
 * Una credencial no se escribe en un log por descuido: el {@code toString} del token de autenticacion del grant
 * (que una traza o un mensaje de depuracion puede imprimir) no lleva el PIN ni el numero de tarjeta completo.
 */
class TarjetaPinAuthenticationTokenTest {

    @Test
    @DisplayName("El toString no imprime el PIN y enmascara el numero de tarjeta")
    void laCredencialNoSeFiltraPorElToString() {
        TarjetaPinAuthenticationToken token = new TarjetaPinAuthenticationToken("4000000000000116", "1234",
                new TestingAuthenticationToken("atm-scl-001", "x"), Map.of());
        assertThat(token.toString())
                .contains("400000******0116").contains("pin=****")
                .doesNotContain("1234").doesNotContain("4000000000000116");
        assertThat(token.getNumeroTarjeta()).isEqualTo("4000000000000116");
    }
}
