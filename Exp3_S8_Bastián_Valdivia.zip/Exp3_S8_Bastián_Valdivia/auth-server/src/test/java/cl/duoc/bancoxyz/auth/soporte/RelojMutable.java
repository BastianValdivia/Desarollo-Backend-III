package cl.duoc.bancoxyz.auth.soporte;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Reloj cuya hora se mueve a mano: los bloqueos duran 15 minutos y esperarlos de verdad en una prueba no es una
 * opcion. Reemplaza al reloj del sistema solo en los contextos de prueba que lo declaran como {@code @Primary}
 * (ver {@code BloqueoDePinTest} y {@code BloqueoDeClaveTest}).
 */
public final class RelojMutable extends Clock {

    private final AtomicReference<Instant> ahora = new AtomicReference<>(Instant.parse("2026-01-01T10:00:00Z"));

    public void avanzar(Duration d) {
        ahora.updateAndGet(i -> i.plus(d));
    }

    @Override
    public ZoneId getZone() {
        return ZoneOffset.UTC;
    }

    @Override
    public Clock withZone(ZoneId zona) {
        return this;
    }

    @Override
    public Instant instant() {
        return ahora.get();
    }
}
