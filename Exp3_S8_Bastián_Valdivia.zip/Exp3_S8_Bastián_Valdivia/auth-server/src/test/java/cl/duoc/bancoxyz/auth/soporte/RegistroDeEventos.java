package cl.duoc.bancoxyz.auth.soporte;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cl.duoc.bancoxyz.auth.eventos.EventosDeSeguridad;
import cl.duoc.bancoxyz.eventos.DatosSeguridad;

/** Un {@link EventosDeSeguridad} de pruebas que anota lo que le publican, para comprobar que eventos salen de cada flujo. */
public class RegistroDeEventos implements EventosDeSeguridad {

    /** Un evento publicado. */
    public record Publicado(String tipo, String clave, DatosSeguridad datos) {
    }

    private final List<Publicado> publicados = Collections.synchronizedList(new ArrayList<>());

    @Override
    public void publicar(String tipo, String clave, DatosSeguridad datos) {
        publicados.add(new Publicado(tipo, clave, datos));
    }

    public List<Publicado> publicados() {
        synchronized (publicados) {
            return List.copyOf(publicados);
        }
    }

    public void limpiar() {
        publicados.clear();
    }
}
