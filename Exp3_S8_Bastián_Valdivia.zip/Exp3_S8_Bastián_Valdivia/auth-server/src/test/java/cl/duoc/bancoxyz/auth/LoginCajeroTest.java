package cl.duoc.bancoxyz.auth;

import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.ATM;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.EMISOR;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.SECRETOS;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.SECRETO_TERMINAL;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.TERMINAL;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.WEB;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;

import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;
import cl.duoc.bancoxyz.auth.tarjeta.RegistroIntentosPin;

/**
 * El grant de extension del cajero ({@code urn:bancoxyz:params:oauth:grant-type:tarjeta-pin}) de punta a punta,
 * con las tarjetas, el PIN y la politica reales de {@code config-repo}.
 *
 * <p>Las pruebas comparten UN contexto de Spring y por lo tanto UN registro de intentos de PIN en memoria; por eso
 * cada una parte con los contadores en cero ({@link #tarjetasSinFallos()}). El vencimiento de los 15 minutos,
 * que necesita adelantar el reloj, esta en {@code BloqueoDePinTest}.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@ExtendWith(OutputCaptureExtension.class)
class LoginCajeroTest {

    private static final String GRANT = "urn:bancoxyz:params:oauth:grant-type:tarjeta-pin";
    private static final String T116 = "4000000000000116";
    private static final String T106 = "4000000000000106";
    private static final String T105 = "4000000000000105";
    private static final String T150 = "4000000000000150";
    private static final ObjectMapper JSON = new ObjectMapper();

    @DynamicPropertySource
    static void material(DynamicPropertyRegistry registro) {
        MaterialDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private RegistroIntentosPin intentos;

    /**
     * Cada prueba parte con las cuatro tarjetas sin fallos acumulados. Se usa la misma operacion que el servidor
     * ejecuta tras un PIN correcto (registrarExito), asi que no hay API de pruebas en el codigo de produccion.
     */
    @BeforeEach
    void tarjetasSinFallos() {
        List.of(T116, T106, T105, T150).forEach(intentos::registrarExito);
    }

    private MockHttpServletRequestBuilder pedido(String cliente, String secreto, String tarjeta, String pin) {
        var peticion = post("/oauth2/token").contentType("application/x-www-form-urlencoded")
                .param("grant_type", GRANT);
        if (tarjeta != null) {
            peticion.param("numero_tarjeta", tarjeta);
        }
        if (pin != null) {
            peticion.param("pin", pin);
        }
        return cliente == null ? peticion : peticion.with(httpBasic(cliente, secreto));
    }

    private MvcResult login(String tarjeta, String pin) throws Exception {
        return mvc.perform(pedido(TERMINAL, SECRETO_TERMINAL, tarjeta, pin)).andReturn();
    }

    private static JsonNode cuerpo(MvcResult resultado) throws Exception {
        return JSON.readTree(resultado.getResponse().getContentAsString());
    }

    private Jwt decodificar(String token) throws Exception {
        String jwks = mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get("/oauth2/jwks"))
                .andReturn().getResponse().getContentAsString();
        RSAKey clave = (RSAKey) JWKSet.parse(jwks).getKeys().get(0);
        NimbusJwtDecoder decodificador = NimbusJwtDecoder.withPublicKey(clave.toRSAPublicKey()).build();
        decodificador.setJwtValidator(JwtValidators.createDefaultWithIssuer(EMISOR));
        return decodificador.decode(token);
    }

    // ------------------------------------------------------------------ exito y contenido del token

    @Test
    @DisplayName("Exito: la tarjeta 116 con su PIN recibe un token de 3 minutos para bff-atm con cuenta, autoridades y terminal")
    void exito() throws Exception {
        MvcResult r = login(T116, "1234");
        assertThat(r.getResponse().getStatus()).isEqualTo(200);
        JsonNode tokens = cuerpo(r);
        assertThat(tokens.get("token_type").asText()).isEqualTo("Bearer");
        assertThat(tokens.get("expires_in").asLong()).isBetween(175L, 180L);
        assertThat(tokens.has("refresh_token")).isFalse();

        Jwt jwt = decodificar(tokens.get("access_token").asText());
        assertThat(jwt.getAudience()).containsExactly("bff-atm");
        assertThat(jwt.getClaimAsString("canal")).isEqualTo("ATM");
        assertThat(((Number) jwt.getClaim("cuentaId")).intValue()).isEqualTo(116);
        assertThat(jwt.getClaimAsStringList("authorities"))
                .containsExactly("ROLE_CLIENTE_ATM", "PERM_saldo:leer", "PERM_retiro:ejecutar");
        assertThat(jwt.getClaimAsString("terminal")).isEqualTo("ATM-SCL-001");
        assertThat(jwt.getClaimAsString("client_id")).isEqualTo(TERMINAL);
        assertThat(Duration.between(jwt.getIssuedAt(), jwt.getExpiresAt())).isEqualTo(Duration.ofMinutes(3));
        assertThat(jwt.getHeaders()).containsEntry("alg", "RS256").containsKey("kid");
        // El numero de tarjeta completo no viaja en el token: solo seis primeros y cuatro ultimos.
        assertThat(jwt.getSubject()).isEqualTo("400000******0116");
        assertThat(tokens.get("access_token").asText()).doesNotContain(T116);
        assertThat(jwt.getClaims().toString()).doesNotContain(T116).doesNotContain("1234");
    }

    @Test
    @DisplayName("La tarjeta 105 (la del S5 sin permiso de retiro) autentica pero su token NO lleva PERM_retiro:ejecutar")
    void tarjetaSinPermisoDeRetiro() throws Exception {
        MvcResult r = login(T105, "4321");
        assertThat(r.getResponse().getStatus()).isEqualTo(200);
        Jwt jwt = decodificar(cuerpo(r).get("access_token").asText());
        assertThat(jwt.getClaimAsStringList("authorities")).containsExactly("ROLE_CLIENTE_ATM", "PERM_saldo:leer");
        assertThat(jwt.getClaimAsStringList("authorities")).doesNotContain("PERM_retiro:ejecutar");
        assertThat(((Number) jwt.getClaim("cuentaId")).intValue()).isEqualTo(105);
    }

    @Test
    @DisplayName("Las cuatro tarjetas del S5 autentican con su PIN y llevan su cuenta")
    void lasCuatroTarjetas() throws Exception {
        record Caso(String tarjeta, String pin, int cuenta, boolean retira) { }
        for (Caso c : List.of(new Caso(T116, "1234", 116, true), new Caso(T106, "5678", 106, true),
                new Caso(T105, "4321", 105, false), new Caso(T150, "9999", 150, false))) {
            Jwt jwt = decodificar(cuerpo(login(c.tarjeta(), c.pin())).get("access_token").asText());
            assertThat(((Number) jwt.getClaim("cuentaId")).intValue()).as(c.tarjeta()).isEqualTo(c.cuenta());
            assertThat(jwt.getClaimAsStringList("authorities").contains("PERM_retiro:ejecutar"))
                    .as(c.tarjeta()).isEqualTo(c.retira());
        }
    }

    // ------------------------------------------------------------------ PIN errado y bloqueo

    @Test
    @DisplayName("PIN errado: 400 invalid_grant credenciales_invalidas, sin token; tarjeta inexistente responde IGUAL")
    void pinErrado() throws Exception {
        MvcResult malPin = login(T116, "0000");
        MvcResult noExiste = login("4999999999999999", "1234");
        assertThat(malPin.getResponse().getStatus()).isEqualTo(400);
        JsonNode e = cuerpo(malPin);
        assertThat(e.get("error").asText()).isEqualTo("invalid_grant");
        assertThat(e.get("error_description").asText()).isEqualTo("credenciales_invalidas");
        assertThat(e.has("access_token")).isFalse();
        // Indistinguibles: quien prueba numeros no aprende cuales existen.
        assertThat(noExiste.getResponse().getStatus()).isEqualTo(400);
        assertThat(noExiste.getResponse().getContentAsString()).isEqualTo(malPin.getResponse().getContentAsString());
        // Y un exito posterior borra el contador: no se acumulan fallos dispersos para siempre.
        assertThat(login(T116, "1234").getResponse().getStatus()).isEqualTo(200);
    }

    @Test
    @DisplayName("El tercer PIN errado bloquea la tarjeta (el PIN correcto ya no sirve) y no afecta a las demas")
    void tercerFalloBloquea() throws Exception {
        assertThat(cuerpo(login(T106, "0001")).get("error_description").asText()).isEqualTo("credenciales_invalidas");
        assertThat(cuerpo(login(T106, "0002")).get("error_description").asText()).isEqualTo("credenciales_invalidas");
        MvcResult tercero = login(T106, "0003");
        assertThat(tercero.getResponse().getStatus()).isEqualTo(400);
        assertThat(cuerpo(tercero).get("error").asText()).isEqualTo("invalid_grant");
        assertThat(cuerpo(tercero).get("error_description").asText()).isEqualTo("pin_bloqueado");

        // Bloqueada: ni el PIN correcto da acceso.
        MvcResult correcto = login(T106, "5678");
        assertThat(correcto.getResponse().getStatus()).isEqualTo(400);
        assertThat(cuerpo(correcto).get("error_description").asText()).isEqualTo("pin_bloqueado");
        assertThat(cuerpo(correcto).has("access_token")).isFalse();

        // El bloqueo es por tarjeta: la 116 sigue autenticando.
        assertThat(login(T116, "1234").getResponse().getStatus()).isEqualTo(200);
    }

    @Test
    @DisplayName("Un PIN correcto antes del tercer fallo borra el contador: dos fallos, un acierto y dos fallos mas no bloquean")
    void exitoBorraElContador() throws Exception {
        // Tarjeta 105: la usan tambien otras pruebas, pero solo con el PIN correcto, que deja el contador en cero.
        login(T105, "1111");
        login(T105, "2222");
        assertThat(login(T105, "4321").getResponse().getStatus()).isEqualTo(200);
        login(T105, "1111");
        login(T105, "2222");
        assertThat(login(T105, "4321").getResponse().getStatus()).as("no quedo bloqueada").isEqualTo(200);
    }

    @Test
    @DisplayName("Concurrencia: 24 intentos simultaneos con PIN distintos verifican solo 3 PIN y bloquean 21 (el candado por tarjeta)")
    void intentosSimultaneos(CapturedOutput salida) throws Exception {
        int hilos = 24;
        ExecutorService pool = Executors.newFixedThreadPool(hilos);
        CountDownLatch largada = new CountDownLatch(1);
        List<Future<String>> futuros = new ArrayList<>();
        for (int i = 0; i < hilos; i++) {
            String pin = String.format("%04d", 1000 + i);
            Callable<String> intento = () -> {
                largada.await();
                return cuerpo(login(T150, pin)).get("error_description").asText();
            };
            futuros.add(pool.submit(intento));
        }
        largada.countDown();
        List<String> resultados = new ArrayList<>();
        for (Future<String> f : futuros) {
            resultados.add(f.get());
        }
        pool.shutdown();
        assertThat(resultados.stream().filter("credenciales_invalidas"::equals).count())
                .as("sin el candado, mas de dos intentos pasarian la comprobacion de bloqueo antes de registrar su fallo")
                .isEqualTo(2);
        assertThat(resultados.stream().filter("pin_bloqueado"::equals).count()).isEqualTo(hilos - 2);
        // Lo que de verdad distingue "con candado" de "sin candado": cuantos PIN se llegaron a COMPARAR. Sin el
        // candado, las 24 peticiones pasan la comprobacion de bloqueo antes de que ninguna registre su fallo y
        // las 24 se comparan (el atacante probaria 24 PIN, no 3); con el, solo se comparan 3 y 21 ni se miran.
        assertThat(contar(salida.getAll(), "PIN incorrecto para la tarjeta")).isEqualTo(2);
        assertThat(contar(salida.getAll(), "bloqueada tras agotar los intentos")).isEqualTo(1);
        assertThat(contar(salida.getAll(), "esta bloqueada")).isEqualTo(hilos - 3);
        assertThat(cuerpo(login(T150, "9999")).get("error_description").asText()).isEqualTo("pin_bloqueado");
    }

    private static long contar(String texto, String fragmento) {
        return texto.lines().filter(linea -> linea.contains(fragmento)).count();
    }

    // ------------------------------------------------------------------ el terminal

    @Test
    @DisplayName("Un terminal NO registrado es rechazado con 401: cliente desconocido y secreto equivocado dan invalid_client, y sin credenciales no hay token")
    void terminalNoRegistrado() throws Exception {
        for (MockHttpServletRequestBuilder p : List.of(
                pedido("atm-scl-999", "cualquiera", T116, "1234"),
                pedido(TERMINAL, "secreto-equivocado", T116, "1234"),
                pedido(null, null, T116, "1234"))) {
            MvcResult r = mvc.perform(p).andReturn();
            assertThat(r.getResponse().getStatus()).isEqualTo(401);
            assertThat(r.getResponse().getContentAsString()).doesNotContain("access_token");
        }
        assertThat(mvc.perform(pedido("atm-scl-999", "cualquiera", T116, "1234")).andReturn().getResponse().getContentAsString())
                .contains("invalid_client");
        assertThat(mvc.perform(pedido(TERMINAL, "secreto-equivocado", T116, "1234")).andReturn().getResponse().getContentAsString())
                .contains("invalid_client");
    }

    @Test
    @DisplayName("Otros clientes registrados (un BFF, una aplicacion) no pueden usar el grant de tarjeta y PIN")
    void soloElTerminalPuedeUsarElGrant() throws Exception {
        for (String cliente : List.of(WEB, ATM)) {
            MvcResult r = mvc.perform(pedido(cliente, SECRETOS.get(cliente), T116, "1234")).andReturn();
            assertThat(r.getResponse().getStatus()).as(cliente).isEqualTo(400);
            assertThat(cuerpo(r).get("error").asText()).as(cliente).isEqualTo("unauthorized_client");
            assertThat(cuerpo(r).has("access_token")).isFalse();
        }
        // Una aplicacion publica (web-app) no se autentica en el endpoint de tokens sin PKCE: ni llega al grant.
        MvcResult publico = mvc.perform(post("/oauth2/token").contentType("application/x-www-form-urlencoded")
                .param("grant_type", GRANT).param("client_id", "web-app")
                .param("numero_tarjeta", T116).param("pin", "1234")).andReturn();
        assertThat(publico.getResponse().getStatus()).isBetween(400, 401);
        assertThat(publico.getResponse().getContentAsString()).doesNotContain("access_token");
    }

    @Test
    @DisplayName("El terminal no puede usar otros grants: client_credentials y authorization_code se rechazan")
    void elTerminalSoloTieneSuGrant() throws Exception {
        MvcResult cc = mvc.perform(post("/oauth2/token").with(httpBasic(TERMINAL, SECRETO_TERMINAL))
                .contentType("application/x-www-form-urlencoded").param("grant_type", "client_credentials")).andReturn();
        assertThat(cc.getResponse().getStatus()).isEqualTo(400);
        assertThat(cc.getResponse().getContentAsString()).contains("unauthorized_client").doesNotContain("access_token");
    }

    @Test
    @DisplayName("El secreto del terminal viaja en la cabecera Basic: en el cuerpo (client_secret_post) no se acepta")
    void secretoDelTerminalSoloPorBasic() throws Exception {
        MvcResult r = mvc.perform(post("/oauth2/token").contentType("application/x-www-form-urlencoded")
                .param("grant_type", GRANT).param("client_id", TERMINAL).param("client_secret", SECRETO_TERMINAL)
                .param("numero_tarjeta", T116).param("pin", "1234")).andReturn();
        assertThat(r.getResponse().getStatus()).isEqualTo(401);
    }

    @Test
    @DisplayName("El secreto del terminal se guarda con hash BCrypt, no en claro")
    void secretoConHash(@Autowired org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository clientes) {
        var terminal = clientes.findByClientId(TERMINAL);
        assertThat(terminal).isNotNull();
        assertThat(terminal.getClientSecret()).startsWith("{bcrypt}$2").doesNotContain(SECRETO_TERMINAL);
        assertThat(terminal.getAuthorizationGrantTypes()).extracting("value").containsExactly(GRANT);
    }

    // ------------------------------------------------------------------ forma de la peticion y logs

    @Test
    @DisplayName("Sin numero de tarjeta, sin PIN o con un parametro repetido: 400 invalid_request")
    void peticionMalFormada() throws Exception {
        assertThat(cuerpo(mvc.perform(pedido(TERMINAL, SECRETO_TERMINAL, null, "1234")).andReturn()).get("error").asText())
                .isEqualTo("invalid_request");
        assertThat(cuerpo(mvc.perform(pedido(TERMINAL, SECRETO_TERMINAL, T116, null)).andReturn()).get("error").asText())
                .isEqualTo("invalid_request");
        MvcResult repetido = mvc.perform(pedido(TERMINAL, SECRETO_TERMINAL, T116, "1234").param("pin", "0000")).andReturn();
        assertThat(repetido.getResponse().getStatus()).isEqualTo(400);
        assertThat(cuerpo(repetido).get("error").asText()).isEqualTo("invalid_request");
    }

    @Test
    @DisplayName("Ningun log escribe el PIN ni el numero de tarjeta completo; solo el numero enmascarado")
    void logsSinCredenciales(CapturedOutput salida) throws Exception {
        login(T116, "7391");   // PIN incorrecto: el servidor lo registra como advertencia
        login(T116, "1234");   // acierto: el servidor registra la emision
        assertThat(salida.getAll()).contains("400000******0116");
        assertThat(salida.getAll()).doesNotContain("7391").doesNotContain(T116);
    }
}
