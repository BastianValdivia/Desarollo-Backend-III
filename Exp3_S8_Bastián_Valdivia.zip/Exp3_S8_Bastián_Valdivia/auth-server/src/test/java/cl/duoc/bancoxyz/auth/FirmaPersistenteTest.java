package cl.duoc.bancoxyz.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.core.io.FileSystemResource;

import com.nimbusds.jose.jwk.RSAKey;

import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;
import cl.duoc.bancoxyz.auth.token.FirmaTokens;

/**
 * La clave de firma se LEE de archivos: la misma clave da siempre el mismo {@code kid}, y un par cruzado
 * o un archivo ausente impiden arrancar en vez de firmar tokens que nadie puede verificar.
 */
class FirmaPersistenteTest {

    @Test
    @DisplayName("Cargar dos veces los mismos archivos da la misma clave y el mismo kid (sobrevive a un reinicio)")
    void mismaClaveTrasReiniciar() throws Exception {
        RSAKey antes = FirmaTokens.cargar(new FileSystemResource(MaterialDePrueba.privada()),
                new FileSystemResource(MaterialDePrueba.publica()));
        RSAKey despues = FirmaTokens.cargar(new FileSystemResource(MaterialDePrueba.privada()),
                new FileSystemResource(MaterialDePrueba.publica()));

        assertThat(antes.getKeyID()).isNotBlank().isEqualTo(despues.getKeyID());
        assertThat(antes.toRSAPublicKey()).isEqualTo(despues.toRSAPublicKey());
        assertThat(antes.isPrivate()).isTrue();
    }

    @Test
    @DisplayName("Una clave publica que no es pareja de la privada se rechaza al arrancar")
    void parCruzado(@TempDir Path carpeta) throws Exception {
        KeyPair otro = MaterialDePrueba.parRsa();
        Path publicaAjena = MaterialDePrueba.escribirPem(carpeta.resolve("otra-public.pem"), "PUBLIC KEY",
                otro.getPublic().getEncoded());

        assertThatThrownBy(() -> FirmaTokens.cargar(new FileSystemResource(MaterialDePrueba.privada()),
                new FileSystemResource(publicaAjena)))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("no corresponde");
    }

    @Test
    @DisplayName("Si el archivo de la clave privada no existe, el error dice que secretos-init no corrio")
    void archivoAusente(@TempDir Path carpeta) {
        assertThatThrownBy(() -> FirmaTokens.cargar(new FileSystemResource(carpeta.resolve("no-existe.pem")),
                new FileSystemResource(MaterialDePrueba.publica())))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("secretos-init");
    }

    @Test
    @DisplayName("Un archivo con contenido que no es PEM se rechaza")
    void archivoBasura(@TempDir Path carpeta) throws Exception {
        Path basura = Files.writeString(carpeta.resolve("basura.pem"), "esto no es una clave");

        assertThatThrownBy(() -> FirmaTokens.cargar(new FileSystemResource(basura),
                new FileSystemResource(MaterialDePrueba.publica())))
                .isInstanceOf(IllegalStateException.class);
    }
}
