package cl.duoc.bancoxyz.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.FileSystemResource;

import cl.duoc.bancoxyz.auth.config.AutorizacionProperties;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Aplicacion;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Clave;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Cliente;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Firma;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Pin;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Tarjeta;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Terminal;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Usuario;
import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;

/**
 * Un servidor de autorizacion a medio configurar no arranca: es preferible un error de arranque que
 * dice que falta a un servidor "UP" que no puede emitir tokens utiles.
 */
class ConfiguracionDeClientesTest {

    private static final String HASH = "{bcrypt}$2a$10$NIkoIjb8UlefdjZQdZB4Lu3NfFrwcXE2KWv6htDjIJX96TdhYJSQe";

    private static Firma firma() {
        return new Firma(new FileSystemResource(MaterialDePrueba.privada()),
                new FileSystemResource(MaterialDePrueba.publica()));
    }

    private static Cliente cliente(String secreto) {
        return new Cliente(secreto, List.of("cuentas:leer"), List.of("core-service"));
    }

    private static Aplicacion web(String uri) {
        return new Aplicacion("web", "bff-web", Duration.ofMinutes(30), List.of(uri));
    }

    private static Usuario usuario(String hash, Map<String, List<String>> canales) {
        return new Usuario(hash, 116, canales);
    }

    private static final Tarjeta TARJETA = new Tarjeta("4000000000000116", HASH, 116, List.of("ROLE_CLIENTE_ATM"));
    private static final Map<String, Terminal> TERMINALES =
            Map.of("atm-scl-001", new Terminal("secreto", "bff-atm", Duration.ofMinutes(3)));

    /** Una configuracion valida, con un solo punto que cada prueba puede romper. */
    private static AutorizacionProperties props(String emisor, Firma firma, Map<String, Cliente> clientes,
                                                Map<String, Aplicacion> aplicaciones, Map<String, Usuario> usuarios) {
        return completa(emisor, firma, clientes, aplicaciones, TERMINALES, usuarios, List.of(TARJETA),
                new Pin(3, Duration.ofMinutes(15)));
    }

    private static AutorizacionProperties completa(String emisor, Firma firma, Map<String, Cliente> clientes,
                                                   Map<String, Aplicacion> aplicaciones,
                                                   Map<String, Terminal> terminales, Map<String, Usuario> usuarios,
                                                   List<Tarjeta> tarjetas, Pin pin) {
        return new AutorizacionProperties(emisor, Duration.ofMinutes(5), firma, clientes, aplicaciones, terminales,
                usuarios, tarjetas, pin, new Clave(3, Duration.ofMinutes(15)));
    }

    private static AutorizacionProperties valida() {
        return props("https://localhost:9000", firma(), Map.of("a", cliente("x")),
                Map.of("web-app", web("http://127.0.0.1:3000/callback")),
                Map.of("cliente116", usuario(HASH, Map.of("web", List.of("ROLE_CLIENTE_WEB")))));
    }

    @Test
    @DisplayName("Un cliente sin secreto impide arrancar y el mensaje dice donde se entrega")
    void sinSecreto() {
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), Map.of("bff-web", cliente(null)),
                valida().aplicaciones(), valida().usuarios()))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("autorizacion.clientes.bff-web.secreto")
                .hasMessageContaining("secretos-init");
    }

    @Test
    @DisplayName("Sin emisor, sin firma, sin clientes, sin scopes o sin audiencias tampoco arranca")
    void configuracionIncompleta() {
        AutorizacionProperties ok = valida();
        assertThatThrownBy(() -> props(" ", firma(), ok.clientes(), ok.aplicaciones(), ok.usuarios()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("emisor");
        assertThatThrownBy(() -> props("https://localhost:9000", new Firma(null, null), ok.clientes(),
                ok.aplicaciones(), ok.usuarios()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("clave-privada");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), Map.of(), ok.aplicaciones(), ok.usuarios()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("ningun cliente");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(),
                Map.of("a", new Cliente("x", List.of(), List.of("core-service"))), ok.aplicaciones(), ok.usuarios()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("scopes");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(),
                Map.of("a", new Cliente("x", List.of("cuentas:leer"), List.of())), ok.aplicaciones(), ok.usuarios()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("audiencias");
        assertThat(ok.clientes()).hasSize(1);
    }

    @Test
    @DisplayName("Una aplicacion solo admite redirect URI de loopback con IP literal, ruta y sin comodines")
    void redirectUriDeLoopback() {
        AutorizacionProperties ok = valida();
        for (String mala : List.of("https://127.0.0.1:3000/callback", "http://localhost:3000/callback",
                "http://example.com/callback", "http://127.0.0.1:3000", "http://127.0.0.1:3000/*",
                "http://127.0.0.1:3000/callback#frag", "com.banco.app:/callback")) {
            assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(),
                    Map.of("web-app", web(mala)), ok.usuarios()))
                    .as(mala)
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("http://127.0.0.1");
        }
        assertThat(props("https://localhost:9000", firma(), ok.clientes(),
                Map.of("web-app", web("http://[::1]:3000/callback")), ok.usuarios()).aplicaciones()).hasSize(1);
    }

    @Test
    @DisplayName("Una aplicacion con canal desconocido, sin vigencia o sin audiencia no arranca")
    void aplicacionIncompleta() {
        AutorizacionProperties ok = valida();
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(),
                Map.of("x", new Aplicacion("atm", "bff-atm", Duration.ofMinutes(3), List.of("http://127.0.0.1:1/c"))),
                ok.usuarios()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("web o movil");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(),
                Map.of("x", new Aplicacion("web", "bff-web", null, List.of("http://127.0.0.1:1/c"))), ok.usuarios()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("vigencia");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(),
                Map.of("x", new Aplicacion("web", " ", Duration.ofMinutes(1), List.of("http://127.0.0.1:1/c"))),
                ok.usuarios()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("audiencia");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(), Map.of(), ok.usuarios()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("aplicacion");
    }

    @Test
    @DisplayName("Una clave que no es un hash BCrypt con prefijo, o un usuario sin canales, impide arrancar")
    void usuariosInvalidos() {
        AutorizacionProperties ok = valida();
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(),
                Map.of("u", usuario("Cliente.2026", Map.of("web", List.of("ROLE_X"))))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("nunca se guardan en claro");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(),
                Map.of("u", usuario(HASH, Map.of()))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("no declara canales");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(),
                Map.of("u", usuario(HASH, Map.of("web", List.of())))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("autoridades");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(),
                Map.of("u", usuario(HASH, Map.of("WEB", List.of("ROLE_X"))))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("minuscula");
        assertThatThrownBy(() -> props("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(), Map.of()))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("ningun usuario");
    }

    @Test
    @DisplayName("Un terminal sin secreto, sin audiencia o sin vigencia, o ningun terminal, impide arrancar")
    void terminalesInvalidos() {
        AutorizacionProperties ok = valida();
        assertThatThrownBy(() -> completa("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(),
                Map.of("atm-scl-001", new Terminal(" ", "bff-atm", Duration.ofMinutes(3))), ok.usuarios(),
                List.of(TARJETA), new Pin(3, Duration.ofMinutes(15))))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("autorizacion.terminales.atm-scl-001.secreto").hasMessageContaining("secretos-init");
        assertThatThrownBy(() -> completa("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(),
                Map.of("atm-scl-001", new Terminal("s", "", Duration.ofMinutes(3))), ok.usuarios(),
                List.of(TARJETA), new Pin(3, Duration.ofMinutes(15))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("audiencia");
        assertThatThrownBy(() -> completa("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(),
                Map.of("atm-scl-001", new Terminal("s", "bff-atm", Duration.ZERO)), ok.usuarios(),
                List.of(TARJETA), new Pin(3, Duration.ofMinutes(15))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("vigencia");
        assertThatThrownBy(() -> completa("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(),
                Map.of(), ok.usuarios(), List.of(TARJETA), new Pin(3, Duration.ofMinutes(15))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("ningun terminal");
    }

    @Test
    @DisplayName("Una tarjeta con PIN en claro, sin cuenta, sin autoridades, mal numerada o repetida impide arrancar; sin tarjetas tampoco")
    void tarjetasInvalidas() {
        AutorizacionProperties ok = valida();
        assertThatThrownBy(() -> tarjetas(ok, new Tarjeta("4000000000000116", "1234", 116, List.of("ROLE_X"))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("nunca se guardan en claro")
                .hasMessageNotContaining("4000000000000116");
        assertThatThrownBy(() -> tarjetas(ok, new Tarjeta("4000000000000116", HASH, null, List.of("ROLE_X"))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("cuenta-id");
        assertThatThrownBy(() -> tarjetas(ok, new Tarjeta("4000000000000116", HASH, 116, List.of())))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("autoridades");
        assertThatThrownBy(() -> tarjetas(ok, new Tarjeta("12AB", HASH, 116, List.of("ROLE_X"))))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("13 y 19 digitos");
        assertThatThrownBy(() -> tarjetas(ok, TARJETA, TARJETA))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("dos veces");
        assertThatThrownBy(() -> tarjetas(ok))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("ninguna tarjeta");
    }

    private static AutorizacionProperties tarjetas(AutorizacionProperties ok, Tarjeta... tarjetas) {
        return completa("https://localhost:9000", firma(), ok.clientes(), ok.aplicaciones(), TERMINALES, ok.usuarios(),
                List.of(tarjetas), new Pin(3, Duration.ofMinutes(15)));
    }

    @Test
    @DisplayName("La politica de clave de usuario exige al menos 1 intento y un bloqueo positivo; por defecto es 3 intentos y 15 minutos")
    void politicaDeClave() {
        assertThatThrownBy(() -> new Clave(0, Duration.ofMinutes(15))).isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("autorizacion.clave.intentos-maximos");
        assertThatThrownBy(() -> new Clave(3, Duration.ZERO)).isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("no bloquea nada");
        assertThat(valida().clave()).isEqualTo(new Clave(3, Duration.ofMinutes(15)));
    }

    @Test
    @DisplayName("La politica de PIN exige al menos 1 intento y un bloqueo positivo; por defecto es 3 intentos y 15 minutos")
    void politicaDePin() {
        assertThatThrownBy(() -> new Pin(0, Duration.ofMinutes(15))).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new Pin(3, Duration.ZERO)).isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("no bloquea nada");
        assertThat(valida().pin()).isEqualTo(new Pin(3, Duration.ofMinutes(15)));
    }

    @Test
    @DisplayName("El numero de tarjeta se enmascara como PCI DSS: seis primeros y cuatro ultimos")
    void enmascarado() {
        assertThat(AutorizacionProperties.enmascarar("4000000000000116")).isEqualTo("400000******0116");
        assertThat(AutorizacionProperties.enmascarar("1234")).isEqualTo("****");
        assertThat(AutorizacionProperties.enmascarar(null)).isEqualTo("****");
    }

    @Test
    @DisplayName("Lo que no puede ser un numero de tarjeta (muy largo, con letras o con caracteres de control) no se "
            + "refleja: el resultado tiene cota y no depende del largo recibido")
    void enmascaradoConCota() {
        assertThat(AutorizacionProperties.enmascarar("4".repeat(19))).isEqualTo("444444*********4444");
        assertThat(AutorizacionProperties.enmascarar("4".repeat(20))).isEqualTo("****");
        assertThat(AutorizacionProperties.enmascarar("4".repeat(2_000_000))).isEqualTo("****");
        assertThat(AutorizacionProperties.enmascarar("40000000000a0116")).isEqualTo("****");
        assertThat(AutorizacionProperties.enmascarar("4000000000\n000116")).isEqualTo("****");
    }
}
