package cl.duoc.bancoxyz.auth;

import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.SECRETO_TERMINAL;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.TERMINAL;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import cl.duoc.bancoxyz.auth.eventos.EnvioKafka;
import cl.duoc.bancoxyz.auth.eventos.EventoRechazadoException;
import cl.duoc.bancoxyz.auth.eventos.EventoSaliente;
import cl.duoc.bancoxyz.auth.eventos.PublicadorEventosSeguridad;
import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;
import cl.duoc.bancoxyz.auth.tarjeta.RegistroIntentosPin;
import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.DatosSeguridad;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.TiposEvento;
import cl.duoc.bancoxyz.eventos.Topicos;
import cl.duoc.bancoxyz.eventos.soporte.KafkaDePrueba;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * La entrega real de los eventos de seguridad: el publicador con Resilience4j y el productor de config-repo
 * contra un Kafka de verdad, que se CONGELA (docker pause) para emular una caida.
 *
 * <p>La promesa que se comprueba es la del encargo: <strong>el login no se bloquea si Kafka no esta</strong>. Los
 * eventos esperan en una cola en memoria y se entregan, en orden, cuando Kafka vuelve; y una cola acotada
 * descarta (contando) lo que excede su capacidad en vez de crecer sin limite.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK, properties = {
        "eventos.seguridad.habilitado=true",
        "eventos.seguridad.cola=6",
        "eventos.seguridad.espera-tras-fallo-ms=200",
        // Un limite de 30 KB en el productor: un evento de 40 KB (bajo el tope del publicador) lo rechaza el cliente
        // de Kafka con RecordTooLargeException, igual que haria el broker con uno de mas de 1 MB.
        "spring.kafka.producer.properties.max.request.size=30000",
        "resilience4j.circuitbreaker.instances.kafka.wait-duration-in-open-state=2s"})
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class PublicadorEventosSeguridadTest {

    private static final String TARJETA = "4000000000000116";

    @DynamicPropertySource
    static void propiedades(DynamicPropertyRegistry registro) {
        MaterialDePrueba.registrar(registro);
        registro.add("spring.kafka.bootstrap-servers", KafkaDePrueba::bootstrap);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private PublicadorEventosSeguridad publicador;
    @Autowired
    private RegistroIntentosPin intentosPin;
    @Autowired
    private MeterRegistry metricas;
    @Autowired
    private EnvioKafka envio;
    @Autowired
    private CircuitBreakerRegistry circuitos;

    @AfterEach
    void kafkaSano() {
        KafkaDePrueba.reanudar();
        intentosPin.registrarExito(TARJETA);
    }

    private static DatosSeguridad datos(String sujeto) {
        return new DatosSeguridad(sujeto, TERMINAL, "pin_incorrecto", 1, 2, null);
    }

    private List<ConsumerRecord<String, String>> delTopico(String sujeto, int cuantos) {
        return KafkaDePrueba.leerHasta(Topicos.SEGURIDAD,
                leidos -> leidos.stream().filter(r -> sujeto.equals(r.key())).count() >= cuantos,
                Duration.ofSeconds(30)).stream().filter(r -> sujeto.equals(r.key())).toList();
    }

    @Test
    @DisplayName("Con Kafka sano, el evento llega a bancoxyz.seguridad.v1 con el sujeto como clave y el sobre del contrato")
    void llegaAKafka() {
        publicador.publicar(TiposEvento.PIN_INCORRECTO, "tarjeta-llegada", datos("tarjeta-llegada"));

        List<ConsumerRecord<String, String>> registros = delTopico("tarjeta-llegada", 1);
        assertThat(registros).hasSize(1);
        SobreEvento sobre = CodecEventos.leer(registros.get(0).value());
        assertThat(sobre.tipo()).isEqualTo(TiposEvento.PIN_INCORRECTO);
        assertThat(sobre.origen()).isEqualTo("auth-server");
        assertThat(sobre.datosComo(DatosSeguridad.class).sujeto()).isEqualTo("tarjeta-llegada");
        assertThat(new String(registros.get(0).headers().lastHeader("eventId").value())).isEqualTo(sobre.eventId());
    }

    @Test
    @DisplayName("Con Kafka caido el login NO se bloquea (un PIN errado responde en menos de 1 s); los eventos esperan y "
            + "se entregan en orden cuando Kafka vuelve")
    void conKafkaCaidoElLoginNoSeBloquea() throws Exception {
        // Se calienta el productor (conecta y trae los metadatos) para que la caida se note como caida.
        publicador.publicar(TiposEvento.PIN_INCORRECTO, "tarjeta-calentamiento", datos("tarjeta-calentamiento"));
        delTopico("tarjeta-calentamiento", 1);

        KafkaDePrueba.pausar();
        long inicio = System.nanoTime();
        mvc.perform(post("/oauth2/token").with(httpBasic(TERMINAL, SECRETO_TERMINAL))
                .contentType("application/x-www-form-urlencoded")
                .param("grant_type", "urn:bancoxyz:params:oauth:grant-type:tarjeta-pin")
                .param("numero_tarjeta", TARJETA).param("pin", "0001")).andReturn();
        long milisegundos = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - inicio);
        assertThat(milisegundos).as("el login con Kafka caido no espera a Kafka").isLessThan(1000);

        // Eventos en orden mientras Kafka esta caido: caben en la cola y esperan.
        for (int i = 1; i <= 3; i++) {
            long antes = System.nanoTime();
            publicador.publicar(TiposEvento.PIN_INCORRECTO, "tarjeta-orden",
                    new DatosSeguridad("tarjeta-orden", TERMINAL, "pin_incorrecto", i, 3 - i, null));
            assertThat(TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - antes))
                    .as("publicar con Kafka caido es instantaneo").isLessThan(50);
        }
        assertThat(publicador.pendientes()).as("los eventos esperan en la cola").isGreaterThanOrEqualTo(3);

        KafkaDePrueba.reanudar();

        Awaitility.await().atMost(60, TimeUnit.SECONDS).until(() -> publicador.pendientes() == 0);
        List<ConsumerRecord<String, String>> registros = delTopico("tarjeta-orden", 3);
        List<Integer> fallos = registros.stream()
                .map(r -> CodecEventos.leer(r.value()).datosComo(DatosSeguridad.class).intentosFallidos()).toList();
        // Al menos una vez y en orden: la primera aparicion de cada evento respeta el orden en que ocurrieron.
        assertThat(fallos.stream().distinct().toList()).containsExactly(1, 2, 3);
    }

    @Test
    @DisplayName("Con Kafka caido y la cola llena, el evento sobrante se descarta (y se cuenta): la cola no crece sin limite")
    void colaLlenaDescarta() {
        KafkaDePrueba.pausar();
        double antes = metricas.counter("eventos.seguridad.descartados").count();

        // Capacidad 6, mas el que el hilo de fondo ya sacó para intentar enviarlo: caben 7 de los 20. publicar() nunca
        // espera ni lanza.
        for (int i = 0; i < 20; i++) {
            publicador.publicar(TiposEvento.PIN_INCORRECTO, "tarjeta-desborde", datos("tarjeta-desborde"));
        }

        assertThat(publicador.pendientes()).isLessThanOrEqualTo(6);
        assertThat(metricas.counter("eventos.seguridad.descartados").count() - antes)
                .as("lo que no cupo se descarto y quedo contado").isGreaterThanOrEqualTo(13);
    }

    @Test
    @DisplayName("Un evento que Kafka rechaza para siempre (demasiado grande) se descarta: no abre el circuito ni "
            + "detiene a los eventos legitimos que le siguen")
    void eventoRechazadoNoBloqueaLaCola() {
        double antes = metricas.counter("eventos.seguridad.rechazados").count();

        // 40.000 caracteres: pasa el tope del publicador (64 KiB) pero el productor (30 KB) lo rechaza.
        String motivo = "x".repeat(40_000);
        publicador.publicar(TiposEvento.PIN_INCORRECTO, "tarjeta-enorme",
                new DatosSeguridad("tarjeta-enorme", TERMINAL, motivo, 1, 2, null));
        publicador.publicar(TiposEvento.PIN_INCORRECTO, "tarjeta-legitima", datos("tarjeta-legitima"));

        // El legitimo llega aunque el enorme iba delante, y la cola queda vacia (el enorme no volvio al frente).
        List<ConsumerRecord<String, String>> leidos = KafkaDePrueba.leerHasta(Topicos.SEGURIDAD,
                todos -> todos.stream().anyMatch(r -> "tarjeta-legitima".equals(r.key())), Duration.ofSeconds(30));
        assertThat(leidos).anyMatch(r -> "tarjeta-legitima".equals(r.key()));
        assertThat(leidos).noneMatch(r -> "tarjeta-enorme".equals(r.key()));
        Awaitility.await().atMost(10, TimeUnit.SECONDS).until(() -> publicador.pendientes() == 0);
        assertThat(metricas.counter("eventos.seguridad.rechazados").count() - antes).isEqualTo(1.0);
        assertThat(circuitos.circuitBreaker("kafka").getState()).isEqualTo(CircuitBreaker.State.CLOSED);
    }

    @Test
    @DisplayName("EnvioKafka distingue un rechazo permanente (EventoRechazadoException) de una caida de Kafka")
    void envioDistingueRechazoPermanente() {
        EventoSaliente enorme = new EventoSaliente("evt-enorme", Topicos.SEGURIDAD, "tarjeta-enorme", "x".repeat(40_000));

        assertThatThrownBy(() -> envio.enviar(enorme)).isInstanceOf(EventoRechazadoException.class);
        assertThat(circuitos.circuitBreaker("kafka").getState()).isEqualTo(CircuitBreaker.State.CLOSED);
    }

    @Test
    @DisplayName("Un evento anormalmente grande ni siquiera entra en la cola: se descarta y se cuenta")
    void eventoSobredimensionadoNoEntraEnLaCola() {
        double antes = metricas.counter("eventos.seguridad.rechazados").count();

        publicador.publicar(TiposEvento.PIN_INCORRECTO, "tarjeta-gigante",
                new DatosSeguridad("tarjeta-gigante", TERMINAL, "x".repeat(100_000), 1, 2, null));

        assertThat(publicador.pendientes()).isZero();
        assertThat(metricas.counter("eventos.seguridad.rechazados").count() - antes).isEqualTo(1.0);
    }
}
