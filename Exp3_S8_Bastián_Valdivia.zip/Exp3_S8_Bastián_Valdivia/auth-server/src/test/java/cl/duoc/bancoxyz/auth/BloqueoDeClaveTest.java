package cl.duoc.bancoxyz.auth;

import static cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode.nuevoVerifier;
import static cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode.parametroDeLaRedireccion;
import static cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode.solicitud;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode;
import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;
import cl.duoc.bancoxyz.auth.soporte.RelojMutable;
import cl.duoc.bancoxyz.auth.usuarios.RegistroIntentosClave;

/**
 * El limite de intentos de la CLAVE de los usuarios web y movil (formulario de login), con la politica real de
 * {@code config-repo} (3 intentos, 15 minutos) y un reloj que se adelanta a voluntad.
 *
 * <p>Cierra el hallazgo de la verificacion de F5: el puerto 9000 esta publicado y la clave de {@code cliente116}
 * o {@code ejecutivo1} se podia probar sin limite, mientras la tarjeta del cajero se bloqueaba a los 3 PIN
 * errados. Aqui se comprueba que las dos credenciales tienen el mismo trato, y que el bloqueo no depende de que
 * la clave correcta llegue tarde: una vez bloqueado, ni la correcta inicia sesion.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@ExtendWith(OutputCaptureExtension.class)
@Import(BloqueoDeClaveTest.RelojAjustable.class)
class BloqueoDeClaveTest {

    private static final String WEB = "web-app";
    private static final String MOVIL = "mobile-app";
    private static final String REDIRECT_WEB = "http://127.0.0.1:3000/callback";
    private static final String REDIRECT_MOVIL = "http://127.0.0.1:3001/callback";
    private static final String CLAVE = "Cliente.2026";
    private static final String ERROR = "/login?error";
    private static final List<String> USUARIOS = List.of("cliente116", "cliente105", "ejecutivo1");

    @TestConfiguration
    static class RelojAjustable {
        @Bean
        @Primary
        RelojMutable relojDePrueba() {
            return new RelojMutable();
        }
    }

    @DynamicPropertySource
    static void material(DynamicPropertyRegistry registro) {
        MaterialDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private RelojMutable reloj;
    @Autowired
    private RegistroIntentosClave intentos;

    private FlujoAuthorizationCode flujo;

    /** Cada prueba parte con los usuarios sin fallos acumulados, sea cual sea el orden en que corran. */
    @BeforeEach
    void usuariosSinFallos() {
        flujo = new FlujoAuthorizationCode(mvc);
        USUARIOS.forEach(intentos::registrarExito);
    }

    /** Un intento de login completo (solicitud de autorizacion, formulario con CSRF) y el resultado del POST. */
    private MvcResult intento(String usuario, String clave) throws Exception {
        MvcResult sinSesion = flujo.autorizar(solicitud(WEB, REDIRECT_WEB, nuevoVerifier()), null);
        return flujo.iniciarSesion(
                (org.springframework.mock.web.MockHttpSession) sinSesion.getRequest().getSession(false), usuario, clave);
    }

    /** {@code true} si el intento inicio sesion: el login devuelve a {@code /oauth2/authorize} y no a {@code /login?error}. */
    private boolean inicioSesion(String usuario, String clave) throws Exception {
        String destino = intento(usuario, clave).getResponse().getRedirectedUrl();
        return destino != null && destino.contains("/oauth2/authorize");
    }

    @Test
    @DisplayName("Tres claves erradas bloquean al usuario: la cuarta, aunque sea la CORRECTA, no inicia sesion ni entrega codigo")
    void tresFallosBloquean() throws Exception {
        for (String mala : List.of("mala-1", "mala-2", "mala-3")) {
            assertThat(intento("cliente116", mala).getResponse().getRedirectedUrl()).isEqualTo(ERROR);
        }
        assertThat(intentos.estaBloqueada("cliente116")).isTrue();

        MvcResult correcta = flujo.autorizarConLogin(solicitud(WEB, REDIRECT_WEB, nuevoVerifier()), "cliente116", CLAVE);
        assertThat(correcta.getResponse().getRedirectedUrl()).as("la clave correcta no sirve con el usuario bloqueado")
                .isEqualTo(ERROR);
        assertThat(parametroDeLaRedireccion(correcta, "code")).isNull();
    }

    @Test
    @DisplayName("El bloqueo vale tambien para la aplicacion movil: el formulario y el contador son los mismos")
    void elBloqueoVaTambienEnElMovil() throws Exception {
        for (int i = 0; i < 3; i++) {
            intento("cliente116", "mala-" + i);
        }
        Map<String, String> movil = solicitud(MOVIL, REDIRECT_MOVIL, nuevoVerifier());
        movil.put("device_id", "telefono-A");
        MvcResult r = flujo.autorizarConLogin(movil, "cliente116", CLAVE);
        assertThat(r.getResponse().getRedirectedUrl()).isEqualTo(ERROR);
        assertThat(parametroDeLaRedireccion(r, "code")).isNull();
    }

    @Test
    @DisplayName("No delata nada: el bloqueo responde igual que una clave incorrecta y que un usuario inexistente")
    void laRespuestaNoDistingueElBloqueo() throws Exception {
        String incorrecta = intento("cliente116", "mala-1").getResponse().getRedirectedUrl();
        String inexistente = intento("nadie", "mala-1").getResponse().getRedirectedUrl();
        intento("cliente116", "mala-2");
        intento("cliente116", "mala-3");
        MvcResult bloqueado = intento("cliente116", CLAVE);

        assertThat(bloqueado.getResponse().getStatus()).isEqualTo(302);
        assertThat(bloqueado.getResponse().getRedirectedUrl()).isEqualTo(incorrecta).isEqualTo(inexistente).isEqualTo(ERROR);
    }

    @Test
    @DisplayName("El bloqueo dura 15 minutos desde el ultimo fallo: a los 14 sigue bloqueado, pasados los 15 vuelve a iniciar sesion")
    void elBloqueoVenceALosQuinceMinutos() throws Exception {
        for (int i = 0; i < 3; i++) {
            intento("cliente116", "mala-" + i);
        }
        reloj.avanzar(Duration.ofMinutes(14));
        assertThat(inicioSesion("cliente116", CLAVE)).as("a los 14 minutos la clave correcta sigue sin servir").isFalse();

        // Un intento durante el bloqueo no lo extiende: se cuenta desde el TERCER fallo, no desde el cuarto intento.
        reloj.avanzar(Duration.ofMinutes(2));
        assertThat(inicioSesion("cliente116", CLAVE)).as("pasados los 15 minutos desde el tercer fallo").isTrue();
    }

    @Test
    @DisplayName("Tras liberarse, el usuario cuenta de nuevo desde cero: hacen falta otros tres fallos para bloquearlo")
    void tras15MinutosElContadorEmpiezaDeCero() throws Exception {
        for (int i = 0; i < 3; i++) {
            intento("cliente116", "mala-" + i);
        }
        reloj.avanzar(Duration.ofMinutes(16));
        intento("cliente116", "mala-4");
        intento("cliente116", "mala-5");
        assertThat(intentos.estaBloqueada("cliente116")).as("dos fallos de la cuenta nueva no bloquean").isFalse();
        intento("cliente116", "mala-6");
        assertThat(intentos.estaBloqueada("cliente116")).isTrue();
    }

    @Test
    @DisplayName("Dos fallos separados por mas de la ventana no suman: el siguiente cuenta como el primero")
    void fallosSeparadosPorLaVentanaNoSuman() throws Exception {
        intento("cliente116", "mala-1");
        intento("cliente116", "mala-2");
        reloj.avanzar(Duration.ofMinutes(16));
        intento("cliente116", "mala-3");
        intento("cliente116", "mala-4");
        assertThat(inicioSesion("cliente116", CLAVE)).as("solo van dos fallos de la ventana vigente").isTrue();
    }

    @Test
    @DisplayName("Una clave correcta antes de agotar los intentos borra el contador: dos fallos, un acierto y dos fallos no bloquean")
    void unAciertoReiniciaElContador() throws Exception {
        intento("cliente116", "mala-1");
        intento("cliente116", "mala-2");
        assertThat(inicioSesion("cliente116", CLAVE)).isTrue();
        intento("cliente116", "mala-3");
        intento("cliente116", "mala-4");
        assertThat(intentos.estaBloqueada("cliente116")).isFalse();
        assertThat(inicioSesion("cliente116", CLAVE)).isTrue();
    }

    @Test
    @DisplayName("El bloqueo es por usuario: bloquear a cliente116 no afecta a cliente105 ni a ejecutivo1")
    void elBloqueoEsPorUsuario() throws Exception {
        for (int i = 0; i < 3; i++) {
            intento("cliente116", "mala-" + i);
        }
        assertThat(intentos.estaBloqueada("cliente116")).isTrue();
        assertThat(inicioSesion("cliente105", CLAVE)).isTrue();
        assertThat(inicioSesion("ejecutivo1", "Exec.2026")).isTrue();
    }

    @Test
    @DisplayName("Los nombres inexistentes no se cuentan ni se bloquean: ni crean estado ni delatan que usuarios existen")
    void usuariosInexistentesNoCreanEstado() throws Exception {
        for (int i = 0; i < 10; i++) {
            assertThat(intento("nadie", "mala-" + i).getResponse().getRedirectedUrl()).isEqualTo(ERROR);
        }
        assertThat(intentos.estaBloqueada("nadie")).isFalse();
    }

    @Test
    @DisplayName("Nombre con otra capitalizacion o espacios no es el usuario real: no cuenta contra el y no evita su bloqueo")
    void variantesDelNombreNoEvitanElBloqueo() throws Exception {
        for (int i = 0; i < 3; i++) {
            intento("cliente116", "mala-" + i);
        }
        // Las variantes no son usuarios: ni se autentican (la busqueda es exacta) ni reinician el contador del real.
        assertThat(inicioSesion("CLIENTE116", CLAVE)).isFalse();
        assertThat(intentos.estaBloqueada("cliente116")).isTrue();
    }

    @Test
    @DisplayName("Concurrencia: 24 intentos simultaneos con claves distintas verifican solo 3 claves y bloquean 21 (el candado por usuario)")
    void intentosSimultaneos(CapturedOutput salida) throws Exception {
        int hilos = 24;
        ExecutorService pool = Executors.newFixedThreadPool(hilos);
        CountDownLatch largada = new CountDownLatch(1);
        List<Future<String>> futuros = new ArrayList<>();
        for (int i = 0; i < hilos; i++) {
            String clave = "clave-" + i;
            Callable<String> intento = () -> {
                largada.await();
                return mvc.perform(post("/login").param("username", "ejecutivo1").param("password", clave).with(csrf()))
                        .andReturn().getResponse().getRedirectedUrl();
            };
            futuros.add(pool.submit(intento));
        }
        largada.countDown();
        for (Future<String> f : futuros) {
            assertThat(f.get()).isEqualTo(ERROR);
        }
        pool.shutdown();

        // Lo que de verdad distingue "con candado" de "sin candado": cuantas claves se llegaron a COMPARAR. Sin el
        // candado las 24 peticiones pasan la comprobacion de bloqueo antes de que ninguna registre su fallo y las
        // 24 se comparan; con el, solo se comparan 3 y 21 ni se miran.
        assertThat(contar(salida.getAll(), "Clave incorrecta para el usuario ejecutivo1")).isEqualTo(2);
        assertThat(contar(salida.getAll(), "Usuario ejecutivo1 bloqueado tras agotar los intentos")).isEqualTo(1);
        assertThat(contar(salida.getAll(), "Intento de inicio de sesion del usuario ejecutivo1: esta bloqueado"))
                .isEqualTo(hilos - 3);
        assertThat(inicioSesion("ejecutivo1", "Exec.2026")).as("bloqueado: ni la clave correcta sirve").isFalse();
    }

    private static long contar(String texto, String fragmento) {
        return texto.lines().filter(linea -> linea.contains(fragmento)).count();
    }
}
