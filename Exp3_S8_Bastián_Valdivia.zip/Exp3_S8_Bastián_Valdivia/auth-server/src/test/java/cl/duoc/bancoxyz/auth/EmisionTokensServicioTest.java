package cl.duoc.bancoxyz.auth;

import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.ATM;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.EMISOR;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.MOVIL;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.SECRETOS;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.WEB;
import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;

/**
 * El servidor de autorizacion emite tokens de servicio con minimo privilegio, y solo a quien se
 * autentica.
 *
 * <p>Se prueba contra un servidor real (puerto aleatorio) y por HTTP, exactamente como lo llamaria un BFF:
 * {@code POST /oauth2/token} con el secreto en la cabecera {@code Authorization: Basic}. Lo que se
 * comprueba es lo que un servidor de recursos necesita poder confiar: que el token traiga el emisor
 * fijo, los scopes exactos del cliente, la audiencia correcta y una vigencia de cinco minutos, y que su
 * firma se verifique con la clave publica que el propio servidor publica.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class EmisionTokensServicioTest {

    @DynamicPropertySource
    static void material(DynamicPropertyRegistry registro) {
        MaterialDePrueba.registrar(registro);
    }

    @LocalServerPort
    private int puerto;

    @Autowired
    private TestRestTemplate http;

    @Autowired
    private RegisteredClientRepository clientes;

    @Autowired
    private PasswordEncoder codificador;

    private ResponseEntity<java.util.Map<String, Object>> pedirToken(String cliente, String secreto, String scope) {
        HttpHeaders cabeceras = new HttpHeaders();
        cabeceras.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        if (cliente != null) {
            cabeceras.setBasicAuth(cliente, secreto);
        }
        MultiValueMap<String, String> cuerpo = new LinkedMultiValueMap<>();
        cuerpo.add("grant_type", "client_credentials");
        if (scope != null) {
            cuerpo.add("scope", scope);
        }
        return http.exchange("/oauth2/token", HttpMethod.POST, new HttpEntity<>(cuerpo, cabeceras),
                new ParameterizedTypeReference<>() { });
    }

    private Jwt decodificar(String token) {
        NimbusJwtDecoder decodificador = NimbusJwtDecoder
                .withJwkSetUri("http://127.0.0.1:" + puerto + "/oauth2/jwks").build();
        decodificador.setJwtValidator(JwtValidators.createDefaultWithIssuer(EMISOR));
        return decodificador.decode(token);
    }

    @Test
    @DisplayName("bff-web recibe sus tres scopes, audiencia core y auditoria, y 5 minutos de vigencia")
    void tokenDelBffWeb() {
        ResponseEntity<java.util.Map<String, Object>> respuesta =
                pedirToken(WEB, SECRETOS.get(WEB), "cuentas:leer movimientos:leer auditoria:leer");

        assertThat(respuesta.getStatusCode().value()).isEqualTo(200);
        assertThat(respuesta.getBody()).containsEntry("token_type", "Bearer");
        assertThat(((Number) respuesta.getBody().get("expires_in")).longValue())
                .as("expires_in").isBetween(295L, 300L);

        Jwt jwt = decodificar((String) respuesta.getBody().get("access_token"));
        assertThat(jwt.getIssuer().toString()).isEqualTo(EMISOR);
        assertThat(jwt.getSubject()).isEqualTo(WEB);
        assertThat(jwt.getClaimAsString("client_id")).isEqualTo(WEB);
        assertThat(jwt.getAudience()).containsExactlyInAnyOrder("core-service", "auditoria-service");
        assertThat(Set.copyOf(jwt.getClaimAsStringList("scope")))
                .containsExactlyInAnyOrder("cuentas:leer", "movimientos:leer", "auditoria:leer");
        assertThat(Duration.between(jwt.getIssuedAt(), jwt.getExpiresAt())).isEqualTo(Duration.ofMinutes(5));
        assertThat(jwt.getExpiresAt()).isAfter(Instant.now());
        assertThat(jwt.getId()).isNotBlank();
        assertThat(jwt.getHeaders()).containsEntry("alg", "RS256").containsKey("kid");
    }

    @Test
    @DisplayName("bff-mobile solo recibe cuentas:leer y bff-atm solo saldo:leer y retiros:ejecutar")
    void scopesExactosDeMovilYCajero() {
        Jwt movil = decodificar((String) pedirToken(MOVIL, SECRETOS.get(MOVIL), "cuentas:leer")
                .getBody().get("access_token"));
        assertThat(movil.getClaimAsStringList("scope")).containsExactly("cuentas:leer");
        assertThat(movil.getAudience()).containsExactly("core-service");

        Jwt cajero = decodificar((String) pedirToken(ATM, SECRETOS.get(ATM), "saldo:leer retiros:ejecutar")
                .getBody().get("access_token"));
        assertThat(Set.copyOf(cajero.getClaimAsStringList("scope")))
                .containsExactlyInAnyOrder("saldo:leer", "retiros:ejecutar");
        assertThat(cajero.getAudience()).containsExactly("core-service");
    }

    @Test
    @DisplayName("Un secreto incorrecto se rechaza con 401 invalid_client y no entrega token")
    void secretoIncorrecto() {
        ResponseEntity<java.util.Map<String, Object>> respuesta =
                pedirToken(WEB, "secreto-equivocado", "cuentas:leer");

        assertThat(respuesta.getStatusCode().value()).isEqualTo(401);
        assertThat(respuesta.getBody()).containsEntry("error", "invalid_client").doesNotContainKey("access_token");
    }

    @Test
    @DisplayName("Un cliente desconocido y una peticion sin credenciales tambien dan 401")
    void clienteDesconocidoOSinCredenciales() {
        assertThat(pedirToken("bff-inexistente", "x", "cuentas:leer").getStatusCode().value()).isEqualTo(401);
        assertThat(pedirToken(null, null, "cuentas:leer").getStatusCode().value()).isEqualTo(401);
    }

    @Test
    @DisplayName("El secreto de un cliente no sirve para otro (cada uno tiene el suyo)")
    void secretoDeOtroCliente() {
        assertThat(pedirToken(MOVIL, SECRETOS.get(WEB), "cuentas:leer").getStatusCode().value()).isEqualTo(401);
    }

    @Test
    @DisplayName("Minimo privilegio: pedir un scope que el cliente no tiene da invalid_scope")
    void scopeFueraDeLoRegistrado() {
        ResponseEntity<java.util.Map<String, Object>> movil =
                pedirToken(MOVIL, SECRETOS.get(MOVIL), "cuentas:leer retiros:ejecutar");
        assertThat(movil.getStatusCode().value()).isEqualTo(400);
        assertThat(movil.getBody()).containsEntry("error", "invalid_scope");

        // El token del BFF web nunca puede incluir retiros: aunque lo pida, no se le concede.
        ResponseEntity<java.util.Map<String, Object>> web = pedirToken(WEB, SECRETOS.get(WEB), "retiros:ejecutar");
        assertThat(web.getStatusCode().value()).isEqualTo(400);
        assertThat(web.getBody()).containsEntry("error", "invalid_scope").doesNotContainKey("access_token");
    }

    @Test
    @DisplayName("Los clientes solo admiten client_credentials: ningun otro grant")
    void otrosGrantsNoSeAceptan() {
        HttpHeaders cabeceras = new HttpHeaders();
        cabeceras.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        cabeceras.setBasicAuth(WEB, SECRETOS.get(WEB));
        MultiValueMap<String, String> cuerpo = new LinkedMultiValueMap<>();
        cuerpo.add("grant_type", "password");
        cuerpo.add("username", "cliente116");
        cuerpo.add("password", "x");
        ResponseEntity<java.util.Map<String, Object>> respuesta = http.exchange("/oauth2/token", HttpMethod.POST,
                new HttpEntity<>(cuerpo, cabeceras), new ParameterizedTypeReference<>() { });

        assertThat(respuesta.getStatusCode().is4xxClientError()).isTrue();
        assertThat(respuesta.getBody()).doesNotContainKey("access_token");
    }

    @Test
    @DisplayName("El secreto va solo en la cabecera Basic: en el cuerpo (client_secret_post) no se acepta")
    void secretoEnElCuerpoNoSeAcepta() {
        MultiValueMap<String, String> cuerpo = new LinkedMultiValueMap<>();
        cuerpo.add("grant_type", "client_credentials");
        cuerpo.add("client_id", WEB);
        cuerpo.add("client_secret", SECRETOS.get(WEB));
        cuerpo.add("scope", "cuentas:leer");
        HttpHeaders cabeceras = new HttpHeaders();
        cabeceras.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        ResponseEntity<java.util.Map<String, Object>> respuesta = http.exchange("/oauth2/token", HttpMethod.POST,
                new HttpEntity<>(cuerpo, cabeceras), new ParameterizedTypeReference<>() { });

        assertThat(respuesta.getStatusCode().value()).isEqualTo(401);
    }

    @Test
    @DisplayName("Los secretos se guardan con hash BCrypt: el repositorio no conoce el valor en claro")
    void secretosConHash() {
        for (String cliente : List.of(WEB, MOVIL, ATM)) {
            RegisteredClient registrado = clientes.findByClientId(cliente);
            assertThat(registrado).as(cliente).isNotNull();
            assertThat(registrado.getClientSecret())
                    .startsWith("{bcrypt}$2")
                    .doesNotContain(SECRETOS.get(cliente));
            assertThat(codificador.matches(SECRETOS.get(cliente), registrado.getClientSecret())).isTrue();
        }
    }

    @Test
    @DisplayName("Dos tokens del mismo cliente son distintos (jti) pero con el mismo kid y la misma firma valida")
    void mismaClaveDeFirma() {
        Jwt a = decodificar((String) pedirToken(MOVIL, SECRETOS.get(MOVIL), "cuentas:leer").getBody().get("access_token"));
        Jwt b = decodificar((String) pedirToken(MOVIL, SECRETOS.get(MOVIL), "cuentas:leer").getBody().get("access_token"));

        assertThat(a.getId()).isNotEqualTo(b.getId());
        assertThat(a.getHeaders().get("kid")).isEqualTo(b.getHeaders().get("kid"));
    }
}
