package cl.duoc.bancoxyz.auth;

import static cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode.nuevoVerifier;
import static cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode.solicitud;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.SECRETO_TERMINAL;
import static cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba.TERMINAL;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import cl.duoc.bancoxyz.auth.soporte.FlujoAuthorizationCode;
import cl.duoc.bancoxyz.auth.soporte.MaterialDePrueba;
import cl.duoc.bancoxyz.auth.soporte.RegistroDeEventos;
import cl.duoc.bancoxyz.auth.soporte.RegistroDeEventos.Publicado;
import cl.duoc.bancoxyz.auth.tarjeta.RegistroIntentosPin;
import cl.duoc.bancoxyz.auth.usuarios.RegistroIntentosClave;
import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.TiposEvento;

/**
 * Que eventos de seguridad salen de cada flujo real del auth-server (PIN del cajero y clave del formulario web), con
 * un registro de pruebas en lugar de Kafka. La entrega a Kafka tiene su propia prueba:
 * {@link PublicadorEventosSeguridadTest}.
 *
 * <p>Comprueba tambien lo que NUNCA debe viajar: ni el PIN, ni la clave, ni el numero de tarjeta completo.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@Import(EventosDeSeguridadTest.Registro.class)
class EventosDeSeguridadTest {

    private static final String TARJETA = "4000000000000116";
    private static final String TARJETA_ENMASCARADA = "400000******0116";

    @TestConfiguration
    static class Registro {
        @Bean
        @Primary
        RegistroDeEventos registroDeEventos() {
            return new RegistroDeEventos();
        }
    }

    @DynamicPropertySource
    static void material(DynamicPropertyRegistry registro) {
        MaterialDePrueba.registrar(registro);
    }

    @Autowired
    private MockMvc mvc;
    @Autowired
    private RegistroDeEventos eventos;
    @Autowired
    private RegistroIntentosPin intentosPin;
    @Autowired
    private RegistroIntentosClave intentosClave;

    @BeforeEach
    void limpio() {
        intentosPin.registrarExito(TARJETA);
        List.of("cliente116", "cliente105", "ejecutivo1").forEach(intentosClave::registrarExito);
        eventos.limpiar();
    }

    private String pin(String tarjeta, String pin) throws Exception {
        return mvc.perform(post("/oauth2/token").with(httpBasic(TERMINAL, SECRETO_TERMINAL))
                        .contentType("application/x-www-form-urlencoded")
                        .param("grant_type", "urn:bancoxyz:params:oauth:grant-type:tarjeta-pin")
                        .param("numero_tarjeta", tarjeta).param("pin", pin))
                .andReturn().getResponse().getContentAsString();
    }

    private void iniciarSesion(String usuario, String clave) throws Exception {
        FlujoAuthorizationCode flujo = new FlujoAuthorizationCode(mvc);
        MvcResult sinSesion = flujo.autorizar(solicitud("web-app", "http://127.0.0.1:3000/callback",
                nuevoVerifier()), null);
        flujo.iniciarSesion((MockHttpSession) sinSesion.getRequest().getSession(false), usuario, clave);
    }

    // ------------------------------------------------------------------------------------------
    // Cajero: PIN errado y tarjeta bloqueada
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Un PIN errado publica PIN_INCORRECTO con la tarjeta enmascarada, el terminal y los intentos que quedan")
    void pinErradoPublicaPinIncorrecto() throws Exception {
        pin(TARJETA, "0001");
        pin(TARJETA, "0002");

        List<Publicado> publicados = eventos.publicados();
        assertThat(publicados).hasSize(2);
        assertThat(publicados).allSatisfy(p -> {
            assertThat(p.tipo()).isEqualTo(TiposEvento.PIN_INCORRECTO);
            assertThat(p.clave()).as("la clave del registro es la tarjeta enmascarada").isEqualTo(TARJETA_ENMASCARADA);
            assertThat(p.datos().sujeto()).isEqualTo(TARJETA_ENMASCARADA);
            assertThat(p.datos().terminal()).isEqualTo(TERMINAL);
            assertThat(p.datos().motivo()).isEqualTo("pin_incorrecto");
        });
        assertThat(publicados.get(0).datos().intentosFallidos()).isEqualTo(1);
        assertThat(publicados.get(0).datos().intentosRestantes()).isEqualTo(2);
        assertThat(publicados.get(1).datos().intentosFallidos()).isEqualTo(2);
        assertThat(publicados.get(1).datos().intentosRestantes()).isEqualTo(1);
    }

    @Test
    @DisplayName("El tercer PIN errado publica PIN_INCORRECTO y TARJETA_BLOQUEADA (con la hora en que se libera); "
            + "un intento posterior publica de nuevo TARJETA_BLOQUEADA")
    void tarjetaBloqueada() throws Exception {
        pin(TARJETA, "0001");
        pin(TARJETA, "0002");
        pin(TARJETA, "0003");

        List<Publicado> publicados = eventos.publicados();
        assertThat(publicados).extracting(Publicado::tipo).containsExactly(
                TiposEvento.PIN_INCORRECTO, TiposEvento.PIN_INCORRECTO, TiposEvento.PIN_INCORRECTO,
                TiposEvento.TARJETA_BLOQUEADA);
        Publicado bloqueo = publicados.get(3);
        assertThat(bloqueo.datos().motivo()).isEqualTo("intentos_agotados");
        assertThat(bloqueo.datos().intentosFallidos()).isEqualTo(3);
        assertThat(bloqueo.datos().bloqueadoHasta()).as("el bloqueo dura 15 minutos").isNotNull();

        // Intentar con la tarjeta ya bloqueada (aunque el PIN sea el correcto) es otro hecho de seguridad.
        pin(TARJETA, "1234");
        Publicado intento = eventos.publicados().get(4);
        assertThat(intento.tipo()).isEqualTo(TiposEvento.TARJETA_BLOQUEADA);
        assertThat(intento.datos().motivo()).isEqualTo("intento_con_tarjeta_bloqueada");
    }

    @Test
    @DisplayName("Una tarjeta que no existe publica PIN_INCORRECTO con motivo tarjeta_desconocida, tambien enmascarada")
    void tarjetaDesconocida() throws Exception {
        pin("4999999999999999", "0000");

        assertThat(eventos.publicados()).hasSize(1);
        Publicado p = eventos.publicados().get(0);
        assertThat(p.tipo()).isEqualTo(TiposEvento.PIN_INCORRECTO);
        assertThat(p.datos().motivo()).isEqualTo("tarjeta_desconocida");
        assertThat(p.datos().sujeto()).isEqualTo("499999******9999");
    }

    @Test
    @DisplayName("Un numero de tarjeta sobredimensionado o con basura no se refleja en el evento: el sujeto queda "
            + "acotado a ****")
    void tarjetaDesconocidaSobredimensionada() throws Exception {
        pin("9".repeat(1_200_000), "0000");
        pin("tarjeta\nfalsa", "0000");

        assertThat(eventos.publicados()).hasSize(2);
        eventos.publicados().forEach(p -> {
            assertThat(p.clave()).isEqualTo("****");
            assertThat(p.datos().sujeto()).isEqualTo("****");
            assertThat(p.datos().motivo()).isEqualTo("tarjeta_desconocida");
        });
    }

    @Test
    @DisplayName("Un PIN correcto no publica nada")
    void pinCorrectoNoPublica() throws Exception {
        pin(TARJETA, "1234");

        assertThat(eventos.publicados()).isEmpty();
    }

    // ------------------------------------------------------------------------------------------
    // Formulario web y movil: login fallido
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Una clave errada publica LOGIN_FALLIDO con el usuario y los intentos que quedan")
    void claveErrada() throws Exception {
        iniciarSesion("cliente116", "mala-1");

        assertThat(eventos.publicados()).hasSize(1);
        Publicado p = eventos.publicados().get(0);
        assertThat(p.tipo()).isEqualTo(TiposEvento.LOGIN_FALLIDO);
        assertThat(p.clave()).isEqualTo("cliente116");
        assertThat(p.datos().motivo()).isEqualTo("clave_incorrecta");
        assertThat(p.datos().intentosFallidos()).isEqualTo(1);
        assertThat(p.datos().intentosRestantes()).isEqualTo(2);
    }

    @Test
    @DisplayName("La tercera clave errada publica LOGIN_FALLIDO y USUARIO_BLOQUEADO; el intento siguiente, LOGIN_FALLIDO por usuario bloqueado")
    void usuarioBloqueado() throws Exception {
        iniciarSesion("cliente116", "mala-1");
        iniciarSesion("cliente116", "mala-2");
        iniciarSesion("cliente116", "mala-3");

        assertThat(eventos.publicados()).extracting(Publicado::tipo).containsExactly(
                TiposEvento.LOGIN_FALLIDO, TiposEvento.LOGIN_FALLIDO, TiposEvento.LOGIN_FALLIDO,
                TiposEvento.USUARIO_BLOQUEADO);
        assertThat(eventos.publicados().get(3).datos().bloqueadoHasta()).isNotNull();

        iniciarSesion("cliente116", "Cliente.2026");   // la clave correcta, con el usuario bloqueado
        Publicado intento = eventos.publicados().get(4);
        assertThat(intento.tipo()).isEqualTo(TiposEvento.LOGIN_FALLIDO);
        assertThat(intento.datos().motivo()).isEqualTo("usuario_bloqueado");
    }

    @Test
    @DisplayName("Un usuario que no existe publica LOGIN_FALLIDO con motivo usuario_desconocido, con el nombre acotado y limpio")
    void usuarioDesconocido() throws Exception {
        iniciarSesion("nadie", "x");
        iniciarSesion("a".repeat(500), "x");
        iniciarSesion("con\tcontrol", "x");

        assertThat(eventos.publicados()).hasSize(3);
        assertThat(eventos.publicados()).allSatisfy(p -> {
            assertThat(p.tipo()).isEqualTo(TiposEvento.LOGIN_FALLIDO);
            assertThat(p.datos().motivo()).isEqualTo("usuario_desconocido");
        });
        assertThat(eventos.publicados().get(1).datos().sujeto()).hasSize(64);
        assertThat(eventos.publicados().get(2).datos().sujeto()).doesNotContain("\t");
    }

    @Test
    @DisplayName("Un inicio de sesion correcto no publica nada")
    void loginCorrectoNoPublica() throws Exception {
        iniciarSesion("cliente116", "Cliente.2026");

        assertThat(eventos.publicados()).isEmpty();
    }

    // ------------------------------------------------------------------------------------------
    // Lo que nunca viaja
    // ------------------------------------------------------------------------------------------

    @Test
    @DisplayName("Ningun evento lleva el PIN, la clave ni el numero de tarjeta completo")
    void nuncaViajanSecretos() throws Exception {
        pin(TARJETA, "0001");
        pin(TARJETA, "0002");
        pin(TARJETA, "0003");
        pin(TARJETA, "1234");
        iniciarSesion("cliente105", "clave-secreta-errada-1");
        iniciarSesion("cliente105", "clave-secreta-errada-2");
        iniciarSesion("cliente105", "clave-secreta-errada-3");

        assertThat(eventos.publicados()).isNotEmpty();
        for (Publicado p : eventos.publicados()) {
            SobreEvento sobre = SobreEvento.nuevo(p.tipo(), 1, java.time.Instant.now(), "auth-server", p.datos());
            // Textos largos que solo podrian estar ahi si se filtrara el secreto (un PIN de 4 digitos se confundiria
            // con cualquier hora o identificador, asi que para el PIN se comprueba la FORMA del contenido).
            String json = CodecEventos.escribir(sobre) + p.clave();
            assertThat(json).doesNotContain(TARJETA, "clave-secreta-errada", "Cliente.2026");
            // Los unicos campos que existen en los datos: no hay uno donde pudiera viajar un PIN o una clave.
            var campos = new java.util.TreeSet<String>();
            sobre.datos().fieldNames().forEachRemaining(campos::add);
            assertThat(campos).isSubsetOf("sujeto", "terminal", "motivo", "intentosFallidos", "intentosRestantes",
                    "bloqueadoHasta");
        }
    }
}
