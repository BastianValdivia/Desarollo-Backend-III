package cl.duoc.bancoxyz.auth.intentos;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Contador de fallos consecutivos de una credencial, con bloqueo temporal: la politica "N intentos, M minutos"
 * que comparten el PIN de las tarjetas del cajero y la clave de los usuarios web y movil.
 *
 * <p>Se extrae a una base comun para que las dos credenciales cumplan EXACTAMENTE el mismo criterio. En el S5
 * solo el PIN tenia limite (y vivia en el BFF); la clave de usuario no, y por eso el formulario de login
 * permitia probar claves sin limite contra {@code cliente116} o {@code ejecutivo1}. Dos politicas escritas por
 * separado terminan divergiendo; una sola clase no.
 *
 * <p><strong>Como se cuenta.</strong> Por sujeto (la tarjeta, el usuario), no por origen de la peticion: intentar
 * desde otro cajero o desde otra IP no reinicia el contador. El bloqueo dura {@code bloqueo} desde el ULTIMO
 * fallo; mientras el sujeto esta bloqueado, un intento no se cuenta ni extiende el bloqueo (no se llega a mirar
 * la credencial). Una credencial correcta antes de agotar los intentos borra el contador. Pasado el tiempo, el
 * siguiente fallo empieza de cero, y lo mismo vale para fallos sueltos separados por mas que la ventana.
 *
 * <p><strong>Un candado por sujeto.</strong> Contar fallos con un {@code ConcurrentHashMap} es seguro por
 * operacion, pero "comprobar que no esta bloqueado, verificar la credencial, registrar el fallo" son tres pasos:
 * sin un candado, veinte peticiones simultaneas con credenciales distintas pasarian todas la primera comprobacion
 * antes de que ninguna registre su fallo, y un atacante probaria veinte en lugar de tres. {@link #candado(String)}
 * entrega un objeto por sujeto para serializar esos tres pasos. Quien use esta clase debe crear candados SOLO para
 * sujetos que existen, para que el mapa no crezca con nombres inventados.
 *
 * <p>El estado esta en memoria: un reinicio del servidor libera los bloqueos. Con varias instancias del
 * auth-server habria que moverlo a la base de datos (limitacion declarada en la bitacora).
 */
public abstract class RegistroIntentos {

    private record Intentos(int fallos, Instant ultimoFallo) {
    }

    private final int intentosMaximos;
    private final Duration bloqueo;
    private final Clock reloj;
    private final Map<String, Intentos> porSujeto = new ConcurrentHashMap<>();
    private final Map<String, Object> candados = new ConcurrentHashMap<>();

    protected RegistroIntentos(int intentosMaximos, Duration bloqueo, Clock reloj) {
        this.intentosMaximos = intentosMaximos;
        this.bloqueo = bloqueo;
        this.reloj = reloj;
    }

    /** Objeto sobre el que sincronizar los pasos "comprobar, verificar, registrar" de UN sujeto. */
    public Object candado(String sujeto) {
        return candados.computeIfAbsent(sujeto, n -> new Object());
    }

    /** {@code true} si el sujeto esta bloqueado AHORA. */
    public boolean estaBloqueada(String sujeto) {
        Intentos intentos = porSujeto.get(sujeto);
        return intentos != null
                && intentos.fallos() >= intentosMaximos
                && !bloqueoVencido(intentos, reloj.instant());
    }

    /**
     * Registra una credencial incorrecta.
     *
     * @return {@code true} si con este fallo el sujeto quedo bloqueado
     */
    public boolean registrarFallo(String sujeto) {
        Instant ahora = reloj.instant();
        Intentos actualizado = porSujeto.compute(sujeto, (clave, previo) -> {
            boolean empiezaDeCero = previo == null || bloqueoVencido(previo, ahora);
            return new Intentos(empiezaDeCero ? 1 : previo.fallos() + 1, ahora);
        });
        return actualizado.fallos() >= intentosMaximos;
    }

    /** Una credencial correcta borra el contador de fallos. */
    /**
     * Cuantos fallos seguidos lleva el sujeto (0 si no tiene o si su bloqueo ya vencio). Lo usan los eventos de
     * seguridad para decir "intento 2 de 3".
     */
    public int fallos(String sujeto) {
        Intentos intentos = porSujeto.get(sujeto);
        return intentos == null || bloqueoVencido(intentos, reloj.instant()) ? 0 : intentos.fallos();
    }

    /** Cuantos fallos seguidos bloquean al sujeto (la politica). */
    public int intentosMaximos() {
        return intentosMaximos;
    }

    /**
     * Hasta cuando dura el bloqueo del sujeto: el instante del ultimo fallo mas la duracion del bloqueo.
     * Solo tiene sentido si {@link #estaBloqueada} es verdadero; sin fallos devuelve {@code null}.
     */
    public Instant bloqueadoHasta(String sujeto) {
        Intentos intentos = porSujeto.get(sujeto);
        return intentos == null ? null : intentos.ultimoFallo().plus(bloqueo);
    }

    public void registrarExito(String sujeto) {
        porSujeto.remove(sujeto);
    }

    private boolean bloqueoVencido(Intentos intentos, Instant ahora) {
        return intentos.ultimoFallo().plus(bloqueo).isBefore(ahora);
    }
}
