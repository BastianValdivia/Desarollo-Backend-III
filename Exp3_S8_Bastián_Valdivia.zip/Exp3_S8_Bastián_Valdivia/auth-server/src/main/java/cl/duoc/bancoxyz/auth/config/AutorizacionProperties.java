package cl.duoc.bancoxyz.auth.config;

import java.net.URI;
import java.time.Duration;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.core.io.Resource;

/**
 * Configuracion del servidor de autorizacion, enlazada bajo el prefijo {@code autorizacion}.
 *
 * <p>Rol en la arquitectura: separa lo que es POLITICA (que scopes y que audiencia recibe cada
 * cliente, cuanto dura un token, que usuarios existen y con que autoridades en cada canal), que vive en
 * {@code config-repo/auth-server.yml} y se puede revisar y cambiar sin recompilar, de lo que es SECRETO
 * (el secreto de cada cliente confidencial), que nunca esta en ese repositorio: llega por archivo desde
 * el volumen que genera {@code secretos-init} ({@code configtree}, propiedad
 * {@code autorizacion.clientes.<id>.secreto} o {@code autorizacion.terminales.<id>.secreto}).
 *
 * <p>Que NO es un secreto: los hashes BCrypt de las claves de los usuarios de demostracion y de los PIN
 * de las tarjetas. Son publicos como en el S5 (el evaluador necesita las credenciales para probar) y un
 * hash BCrypt con sal no permite recuperar la clave. Se guardan con el prefijo {@code {bcrypt}} que
 * entiende el codificador delegante de Spring Security.
 *
 * <p>Los {@code record} se enlazan por constructor, asi que una vez arrancado el servicio nadie puede
 * cambiar en caliente los permisos de un cliente: ampliar un permiso exige tocar la configuracion y
 * reiniciar, que es lo que se quiere de una politica de seguridad.
 *
 * @param emisor          valor FIJO del claim {@code iss} y de las direcciones del descubrimiento
 *                        OIDC. Es fijo a proposito (decision D3): si dependiera del nombre con que
 *                        llega la peticion, un token pedido por {@code auth-server:9000} diria un
 *                        emisor y uno pedido por {@code localhost:9000} otro, y el core rechazaria
 *                        uno de los dos
 * @param vigenciaAcceso  cuanto vive un token de servicio (5 minutos, decision D2)
 * @param firma           par de claves RSA con que se firman los tokens
 * @param clientes        los clientes de SERVICIO (los BFF, {@code client_credentials}), por su
 *                        {@code client_id}
 * @param aplicaciones    los clientes PUBLICOS de usuario (web y movil, {@code authorization_code} con
 *                        PKCE), por su {@code client_id}
 * @param terminales      los cajeros registrados (clientes confidenciales del grant tarjeta y PIN), por su
 *                        {@code client_id}
 * @param usuarios        los usuarios web y movil, por nombre de usuario
 * @param tarjetas        las tarjetas del cajero
 * @param pin             la politica de intentos de PIN
 * @param clave           la politica de intentos de la clave de los usuarios web y movil
 */
@ConfigurationProperties(prefix = "autorizacion")
public record AutorizacionProperties(
        String emisor,
        @DefaultValue("5m") Duration vigenciaAcceso,
        @DefaultValue Firma firma,
        @DefaultValue Map<String, Cliente> clientes,
        @DefaultValue Map<String, Aplicacion> aplicaciones,
        @DefaultValue Map<String, Terminal> terminales,
        @DefaultValue Map<String, Usuario> usuarios,
        @DefaultValue List<Tarjeta> tarjetas,
        @DefaultValue Pin pin,
        @DefaultValue Clave clave) {

    /** Canales que un usuario o una aplicacion pueden nombrar (el del cajero no es de aplicacion). */
    private static final Set<String> CANALES_DE_APLICACION = Set.of("web", "movil");

    /**
     * Archivos del par de claves de firma. Son rutas (por ejemplo
     * {@code file:/run/secrets/firma/auth-server-private.pem}), no el contenido: la clave privada
     * nunca viaja en la configuracion. La clave es PERSISTENTE: vive en el volumen de secretos del
     * servicio y sobrevive a los reinicios (decision D7). Una clave generada en memoria en cada arranque
     * invalidaria de golpe todos los tokens vigentes en cada reinicio.
     *
     * @param clavePrivada PEM en formato PKCS#8
     * @param clavePublica PEM en formato X.509 (SubjectPublicKeyInfo)
     */
    public record Firma(Resource clavePrivada, Resource clavePublica) {
    }

    /**
     * Un cliente confidencial de servicio.
     *
     * @param secreto    secreto en claro, tal como lo entrega el volumen. Se convierte a hash BCrypt al
     *                   registrar el cliente y el valor en claro no se conserva en ningun bean
     * @param scopes     permisos que el cliente puede pedir (minimo privilegio, decision D2)
     * @param audiencias servicios para los que el token sirve: el claim {@code aud}. Un servicio
     *                   rechaza los tokens cuya audiencia no es la suya
     */
    public record Cliente(String secreto, List<String> scopes, List<String> audiencias) {
    }

    /**
     * Una aplicacion de usuario: cliente PUBLICO (no puede guardar un secreto) con
     * {@code authorization_code} y PKCE obligatorio. Son aplicaciones propias del banco, por eso no hay
     * pantalla de consentimiento: el usuario no esta delegando nada a un tercero.
     *
     * @param canal        {@code web} o {@code movil}: de que canal es la aplicacion. Decide las
     *                     autoridades que lleva el token y el claim {@code canal}
     * @param audiencia    BFF para el que sirve el token ({@code bff-web} o {@code bff-mobile})
     * @param vigencia     vigencia del token de acceso (30 minutos en web, 60 en movil, como en el S5)
     * @param redirectUris direcciones de retorno registradas. Solo de loopback (RFC 8252, 7.3): la
     *                     coincidencia con la registrada es exacta salvo el puerto, que Spring
     *                     Authorization Server deja libre para esas direcciones
     */
    public record Aplicacion(String canal, String audiencia, Duration vigencia, List<String> redirectUris) {
    }

    /**
     * Un cajero registrado: cliente CONFIDENCIAL que se autentica con su secreto y es el unico que puede
     * usar el grant de tarjeta y PIN. Reemplaza la lista blanca de terminales del S5 por una
     * autenticacion real del terminal.
     *
     * @param secreto   secreto en claro del volumen (se guarda con hash BCrypt al registrarlo)
     * @param audiencia BFF para el que sirve el token ({@code bff-atm})
     * @param vigencia  vigencia del token (3 minutos, como en el S5)
     */
    public record Terminal(String secreto, String audiencia, Duration vigencia) {
    }

    /**
     * Un usuario de los canales web y movil. Tiene UNA sola clave; lo que cambia segun el canal que pide
     * el token son sus autoridades.
     *
     * @param claveHash hash BCrypt con prefijo {@code {bcrypt}}
     * @param cuentaId  cuenta de la que es titular; {@code null} para quien no tiene cuenta propia (el
     *                  ejecutivo, que audita y no consulta su saldo)
     * @param canales   autoridades por canal ({@code web}, {@code movil}). Un canal ausente significa que
     *                  el usuario NO puede iniciar sesion en el
     */
    public record Usuario(String claveHash, Integer cuentaId, Map<String, List<String>> canales) {
    }

    /**
     * Una tarjeta del cajero.
     *
     * @param numero      numero de tarjeta (solo digitos)
     * @param pinHash     hash BCrypt con prefijo {@code {bcrypt}}
     * @param cuentaId    cuenta de la tarjeta (obligatoria: sin ella no hay contra que comparar la
     *                    titularidad)
     * @param autoridades autoridades del canal cajero. La tarjeta 105 no incluye el retiro
     */
    public record Tarjeta(String numero, String pinHash, Integer cuentaId, List<String> autoridades) {
    }

    /**
     * Politica de PIN, movida desde el BFF del cajero (S5): el servidor de autorizacion es donde vive la
     * autenticacion.
     *
     * @param intentosMaximos fallos consecutivos tras los cuales la tarjeta se bloquea (3)
     * @param bloqueo         cuanto dura el bloqueo (15 minutos)
     */
    public record Pin(@DefaultValue("3") int intentosMaximos, @DefaultValue("15m") Duration bloqueo) {
        public Pin {
            if (intentosMaximos < 1) {
                throw new IllegalArgumentException("autorizacion.pin.intentos-maximos debe ser al menos 1.");
            }
            if (bloqueo == null || bloqueo.isZero() || bloqueo.isNegative()) {
                throw new IllegalArgumentException(
                        "autorizacion.pin.bloqueo debe ser positivo: un bloqueo de cero no bloquea nada.");
            }
        }
    }

    /**
     * Politica de intentos de la clave del formulario de login (usuarios web y movil). Es la misma que la del
     * PIN y se declara aparte para poder ajustarlas por separado sin tocar la otra.
     *
     * @param intentosMaximos fallos consecutivos tras los cuales el usuario se bloquea (3)
     * @param bloqueo         cuanto dura el bloqueo (15 minutos)
     */
    public record Clave(@DefaultValue("3") int intentosMaximos, @DefaultValue("15m") Duration bloqueo) {
        public Clave {
            if (intentosMaximos < 1) {
                throw new IllegalArgumentException("autorizacion.clave.intentos-maximos debe ser al menos 1.");
            }
            if (bloqueo == null || bloqueo.isZero() || bloqueo.isNegative()) {
                throw new IllegalArgumentException(
                        "autorizacion.clave.bloqueo debe ser positivo: un bloqueo de cero no bloquea nada.");
            }
        }
    }

    /**
     * Comprueba al arrancar lo que de otro modo se descubriria cuando alguien no pueda iniciar sesion.
     * Un servidor de autorizacion sin firma, sin emisor o con un cliente a medio configurar no debe
     * levantarse: arrancaria, responderia {@code UP} y fallaria en la primera peticion.
     */
    public AutorizacionProperties {
        if (emisor == null || emisor.isBlank()) {
            throw new IllegalArgumentException(
                    "Falta autorizacion.emisor. Es el valor fijo del claim iss (por ejemplo https://localhost:9000).");
        }
        if (vigenciaAcceso.isZero() || vigenciaAcceso.isNegative()) {
            throw new IllegalArgumentException("autorizacion.vigencia-acceso debe ser positiva.");
        }
        if (firma.clavePrivada() == null || firma.clavePublica() == null) {
            throw new IllegalArgumentException(
                    "Faltan autorizacion.firma.clave-privada y autorizacion.firma.clave-publica. "
                            + "Las genera secretos-init en el volumen del servicio; sin ellas no hay con que firmar.");
        }
        if (clientes.isEmpty()) {
            throw new IllegalArgumentException("No hay ningun cliente en autorizacion.clientes.");
        }
        clientes.forEach((id, cliente) -> {
            if (cliente.secreto() == null || cliente.secreto().isBlank()) {
                throw new IllegalArgumentException("Falta autorizacion.clientes." + id + ".secreto. "
                        + "No va en config-repo: lo entrega secretos-init por archivo (configtree).");
            }
            if (cliente.scopes() == null || cliente.scopes().isEmpty()) {
                throw new IllegalArgumentException("El cliente " + id + " no declara scopes.");
            }
            if (cliente.audiencias() == null || cliente.audiencias().isEmpty()) {
                throw new IllegalArgumentException("El cliente " + id + " no declara audiencias.");
            }
        });
        if (aplicaciones.isEmpty()) {
            throw new IllegalArgumentException(
                    "No hay ninguna aplicacion en autorizacion.aplicaciones: sin web-app y mobile-app nadie "
                            + "puede iniciar sesion.");
        }
        aplicaciones.forEach(AutorizacionProperties::validarAplicacion);
        if (terminales.isEmpty()) {
            throw new IllegalArgumentException(
                    "No hay ningun terminal en autorizacion.terminales: sin un cajero registrado el grant de "
                            + "tarjeta y PIN no lo puede usar nadie.");
        }
        terminales.forEach((id, terminal) -> {
            if (terminal.secreto() == null || terminal.secreto().isBlank()) {
                throw new IllegalArgumentException("Falta autorizacion.terminales." + id + ".secreto. "
                        + "No va en config-repo: lo entrega secretos-init por archivo (configtree).");
            }
            exigirTexto(terminal.audiencia(), "autorizacion.terminales." + id + ".audiencia");
            exigirVigencia(terminal.vigencia(), "autorizacion.terminales." + id + ".vigencia");
        });
        if (usuarios.isEmpty()) {
            throw new IllegalArgumentException("No hay ningun usuario en autorizacion.usuarios.");
        }
        usuarios.forEach(AutorizacionProperties::validarUsuario);
        if (tarjetas.isEmpty()) {
            throw new IllegalArgumentException("No hay ninguna tarjeta en autorizacion.tarjetas.");
        }
        tarjetas.forEach(AutorizacionProperties::validarTarjeta);
        if (tarjetas.stream().map(Tarjeta::numero).distinct().count() != tarjetas.size()) {
            throw new IllegalArgumentException(
                    "Hay una tarjeta declarada dos veces en autorizacion.tarjetas: la segunda quedaria inalcanzable.");
        }
    }

    private static void validarAplicacion(String id, Aplicacion app) {
        String canal = app.canal() == null ? "" : app.canal().toLowerCase(Locale.ROOT);
        if (!CANALES_DE_APLICACION.contains(canal)) {
            throw new IllegalArgumentException(
                    "autorizacion.aplicaciones." + id + ".canal debe ser web o movil (se recibio " + app.canal() + ").");
        }
        exigirTexto(app.audiencia(), "autorizacion.aplicaciones." + id + ".audiencia");
        exigirVigencia(app.vigencia(), "autorizacion.aplicaciones." + id + ".vigencia");
        if (app.redirectUris() == null || app.redirectUris().isEmpty()) {
            throw new IllegalArgumentException("La aplicacion " + id + " no declara redirect-uris.");
        }
        app.redirectUris().forEach(uri -> exigirLoopback(id, uri));
    }

    /**
     * Una redirect URI de una aplicacion propia debe ser de loopback con IP literal ({@code 127.0.0.1} o
     * {@code [::1]}), con ruta y sin fragmento ni comodines: el codigo de autorizacion solo puede volver al
     * dispositivo de quien lo pidio.
     */
    private static void exigirLoopback(String id, String uri) {
        try {
            URI u = URI.create(uri);
            boolean ip = "127.0.0.1".equals(u.getHost()) || "[::1]".equals(u.getHost());
            if (!"http".equals(u.getScheme()) || !ip || u.getPath() == null || u.getPath().length() < 2
                    || u.getFragment() != null || uri.contains("*")) {
                throw new IllegalArgumentException("no es de loopback exacta");
            }
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("La redirect URI '" + uri + "' de la aplicacion " + id
                    + " no es valida: debe ser http://127.0.0.1:<puerto>/<ruta> (o [::1]), sin comodines ni "
                    + "fragmento (RFC 8252, 7.3).", e);
        }
    }

    private static void validarUsuario(String nombre, Usuario usuario) {
        if (usuario.claveHash() == null || !usuario.claveHash().startsWith("{bcrypt}$2")) {
            throw new IllegalArgumentException("La clave del usuario " + nombre
                    + " no es un hash BCrypt con prefijo {bcrypt}: las claves nunca se guardan en claro.");
        }
        if (usuario.canales() == null || usuario.canales().isEmpty()) {
            throw new IllegalArgumentException("El usuario " + nombre + " no declara canales.");
        }
        usuario.canales().forEach((canal, autoridades) -> {
            if (!CANALES_DE_APLICACION.contains(canal)) {
                throw new IllegalArgumentException("El usuario " + nombre + " declara el canal " + canal
                        + ": solo existen web y movil, escritos en minuscula.");
            }
            if (autoridades == null || autoridades.isEmpty()) {
                throw new IllegalArgumentException("El usuario " + nombre + " no declara autoridades en el canal "
                        + canal + ". Un token sin autoridades es valido pero inservible (siempre 403).");
            }
        });
    }

    private static void validarTarjeta(Tarjeta tarjeta) {
        if (tarjeta.numero() == null || !tarjeta.numero().matches("\\d{13,19}")) {
            throw new IllegalArgumentException("El numero de una tarjeta debe tener entre 13 y 19 digitos.");
        }
        if (tarjeta.pinHash() == null || !tarjeta.pinHash().startsWith("{bcrypt}$2")) {
            throw new IllegalArgumentException("El PIN de la tarjeta " + enmascarar(tarjeta.numero())
                    + " no es un hash BCrypt con prefijo {bcrypt}: los PIN nunca se guardan en claro.");
        }
        if (tarjeta.cuentaId() == null) {
            throw new IllegalArgumentException("La tarjeta " + enmascarar(tarjeta.numero())
                    + " no declara cuenta-id: sin ella el token no acredita titularidad.");
        }
        if (tarjeta.autoridades() == null || tarjeta.autoridades().isEmpty()) {
            throw new IllegalArgumentException("La tarjeta " + enmascarar(tarjeta.numero())
                    + " no declara autoridades: su portador recibiria 403 en cada peticion.");
        }
    }

    private static void exigirTexto(String valor, String propiedad) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException("Falta " + propiedad + ".");
        }
    }

    private static void exigirVigencia(Duration vigencia, String propiedad) {
        if (vigencia == null || vigencia.isZero() || vigencia.isNegative()) {
            throw new IllegalArgumentException(propiedad + " debe ser positiva y declararse de forma explicita: "
                    + "no existe un valor por defecto sensato (3 minutos serian absurdos en el movil y 60 "
                    + "peligrosos en un cajero).");
        }
    }

    /** Largo maximo de un numero de tarjeta (PAN, ISO/IEC 7812): 19 digitos. */
    private static final int LARGO_MAXIMO_TARJETA = 19;

    /**
     * Numero de tarjeta truncado como pide PCI DSS: seis primeros y cuatro ultimos digitos, el resto asteriscos
     * ({@code 400000******0116}). Es lo unico que se escribe en mensajes, logs y en el claim {@code sub}: el
     * numero completo solo existe en la peticion del terminal y en la configuracion.
     *
     * <p>Solo enmascara lo que PUEDE ser un numero de tarjeta (de 11 a 19 digitos). Cualquier otra cosa (un valor
     * de otro largo, con letras o con caracteres de control) devuelve {@code ****}: el numero que llega en la
     * peticion lo controla quien llama, y este resultado acaba como clave y sujeto de un evento de Kafka, de modo
     * que debe tener una cota. Sin ella, un {@code numero_tarjeta} de 1 MB produciria un sujeto de 1 MB.
     */
    public static String enmascarar(String numero) {
        if (numero == null || numero.length() < 11 || numero.length() > LARGO_MAXIMO_TARJETA
                || !numero.chars().allMatch(c -> c >= '0' && c <= '9')) {
            return "****";
        }
        return numero.substring(0, 6) + "*".repeat(numero.length() - 10) + numero.substring(numero.length() - 4);
    }
}
