package cl.duoc.bancoxyz.auth.usuarios;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;

import cl.duoc.bancoxyz.auth.eventos.EventosDeSeguridad;
import cl.duoc.bancoxyz.eventos.DatosSeguridad;
import cl.duoc.bancoxyz.eventos.TiposEvento;

/**
 * Verificacion de la clave del formulario de login con limite de intentos: envuelve a
 * {@link DaoAuthenticationProvider} (que sigue siendo quien compara con BCrypt) y le agrega el bloqueo.
 *
 * <p><strong>Por que un proveedor y no un manejador de fallos.</strong> Un {@code AuthenticationFailureHandler}
 * corre DESPUES de verificar la clave: puede contar fallos, pero no puede impedir que el cuarto intento, con la
 * clave correcta, inicie sesion. El bloqueo tiene que decidirse antes de mirar la clave. Ademas, "comprobar,
 * verificar, registrar" debe ser un solo paso por usuario ({@link RegistroIntentosClave}, candado por sujeto);
 * repartido entre un filtro y un manejador, veinte peticiones simultaneas probarian veinte claves.
 *
 * <p><strong>Lo que NO delata.</strong> Un bloqueo se responde con la misma redireccion {@code /login?error} que
 * una clave incorrecta (el formulario muestra un solo mensaje), de modo que quien prueba nombres no aprende cuales
 * existen por el hecho de que se bloqueen. Para que tampoco lo delate el tiempo, un intento sobre un usuario
 * bloqueado paga un BCrypt contra un hash falso, como el que paga cualquier otro intento. Los nombres inexistentes
 * no se cuentan ni crean estado: el mapa de contadores no crece con nombres inventados y no hay con que agotar la
 * memoria desde fuera.
 *
 * <p><strong>Costo asumido.</strong> Quien conozca un nombre de usuario puede bloquearlo tres veces seguidas cada
 * quince minutos (negacion de servicio dirigida). Es el mismo trato que ya tiene la tarjeta del cajero desde el S5
 * y es el precio habitual de limitar intentos por cuenta; se declara en la bitacora.
 */
public class ProveedorDeClaveConBloqueo implements AuthenticationProvider {

    private static final Logger log = LoggerFactory.getLogger(ProveedorDeClaveConBloqueo.class);

    private final UsuariosBanco usuarios;
    private final RegistroIntentosClave intentos;
    private final PasswordEncoder codificador;
    private final DaoAuthenticationProvider verificador;
    /** Hash BCrypt de un texto cualquiera, calculado al arrancar: no hay un hash fijo que mantener ni filtrar. */
    private final String senuelo;
    private final EventosDeSeguridad eventos;

    public ProveedorDeClaveConBloqueo(UsuariosBanco usuarios, PasswordEncoder codificador,
                                      RegistroIntentosClave intentos, EventosDeSeguridad eventos) {
        this.usuarios = usuarios;
        this.codificador = codificador;
        this.intentos = intentos;
        this.eventos = eventos;
        this.verificador = new DaoAuthenticationProvider();
        this.verificador.setUserDetailsService(usuarios);
        this.verificador.setPasswordEncoder(codificador);
        this.senuelo = codificador.encode("senuelo-sin-uso");
    }

    @Override
    public boolean supports(Class<?> autenticacion) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(autenticacion);
    }

    @Override
    public Authentication authenticate(Authentication autenticacion) throws AuthenticationException {
        String nombre = autenticacion.getName();
        if (!usuarios.existe(nombre)) {
            // Sin contador ni candado. El verificador ya compara contra un hash falso para no delatar el nombre.
            try {
                return verificador.authenticate(autenticacion);
            } catch (BadCredentialsException e) {
                // Un nombre inexistente tambien es una senal de seguridad (relleno de credenciales, adivinanza de
                // usuarios). El nombre lo escribe quien ataca: se acota y se limpia antes de publicarlo.
                String sujeto = nombreSeguro(nombre);
                eventos.publicar(TiposEvento.LOGIN_FALLIDO, sujeto,
                        new DatosSeguridad(sujeto, null, "usuario_desconocido", null, null, null));
                throw e;
            }
        }
        synchronized (intentos.candado(nombre)) {
            if (intentos.estaBloqueada(nombre)) {
                codificador.matches(String.valueOf(autenticacion.getCredentials()), senuelo);
                log.warn("Intento de inicio de sesion del usuario {}: esta bloqueado", nombre);
                eventos.publicar(TiposEvento.LOGIN_FALLIDO, nombre, new DatosSeguridad(nombre, null,
                        "usuario_bloqueado", intentos.fallos(nombre), 0, intentos.bloqueadoHasta(nombre)));
                throw new LockedException("Usuario bloqueado temporalmente");
            }
            try {
                Authentication autenticada = verificador.authenticate(autenticacion);
                intentos.registrarExito(nombre);
                return autenticada;
            } catch (BadCredentialsException e) {
                boolean bloqueado = intentos.registrarFallo(nombre);
                int fallos = intentos.fallos(nombre);
                eventos.publicar(TiposEvento.LOGIN_FALLIDO, nombre, new DatosSeguridad(nombre, null,
                        "clave_incorrecta", fallos, Math.max(0, intentos.intentosMaximos() - fallos), null));
                if (bloqueado) {
                    log.warn("Usuario {} bloqueado tras agotar los intentos de clave", nombre);
                    eventos.publicar(TiposEvento.USUARIO_BLOQUEADO, nombre, new DatosSeguridad(nombre, null,
                            "intentos_agotados", fallos, 0, intentos.bloqueadoHasta(nombre)));
                } else {
                    log.warn("Clave incorrecta para el usuario {}", nombre);
                }
                throw e;
            }
        }
    }

    /** El nombre que escribio quien intenta entrar: recortado y sin caracteres de control, antes de publicarlo. */
    static String nombreSeguro(String nombre) {
        String limpio = nombre == null ? "" : nombre.replaceAll("\\p{Cntrl}", "?");
        return limpio.length() > 64 ? limpio.substring(0, 64) : limpio;
    }
}
