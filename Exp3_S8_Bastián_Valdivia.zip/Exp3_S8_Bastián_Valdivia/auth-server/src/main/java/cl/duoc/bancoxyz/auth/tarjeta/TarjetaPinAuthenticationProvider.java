package cl.duoc.bancoxyz.auth.tarjeta;

import java.security.Principal;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2ErrorCodes;
import org.springframework.security.oauth2.core.OAuth2Token;
import org.springframework.security.oauth2.server.authorization.OAuth2Authorization;
import org.springframework.security.oauth2.server.authorization.OAuth2AuthorizationService;
import org.springframework.security.oauth2.server.authorization.OAuth2TokenType;
import org.springframework.security.oauth2.server.authorization.authentication.OAuth2AccessTokenAuthenticationToken;
import org.springframework.security.oauth2.server.authorization.authentication.OAuth2ClientAuthenticationToken;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.context.AuthorizationServerContextHolder;
import org.springframework.security.oauth2.server.authorization.token.DefaultOAuth2TokenContext;
import org.springframework.security.oauth2.server.authorization.token.OAuth2TokenContext;
import org.springframework.security.oauth2.server.authorization.token.OAuth2TokenGenerator;

import cl.duoc.bancoxyz.auth.config.AutorizacionProperties;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Tarjeta;
import cl.duoc.bancoxyz.auth.eventos.EventosDeSeguridad;
import cl.duoc.bancoxyz.eventos.DatosSeguridad;
import cl.duoc.bancoxyz.eventos.TiposEvento;

/**
 * Segundo paso del grant de extension: verifica al terminal, la tarjeta y el PIN, aplica la politica de intentos
 * y entrega el token. Sigue la guia oficial de Spring Authorization Server, "How-to: Implement an Extension
 * Authorization Grant Type" (version 1.3): usa {@link OAuth2TokenGenerator} para generar el token (el mismo,
 * con el mismo personalizador, que el resto de los grants) y {@link OAuth2AuthorizationService} para dejar
 * registrada la autorizacion.
 *
 * <p>El orden de las comprobaciones es parte del diseno:
 * <ol>
 *   <li><b>El terminal.</b> El cliente ya se autentico con su secreto antes de llegar aqui (si no, el filtro
 *       del protocolo respondio {@code invalid_client}). Falta comprobar que su registro declara ESTE grant:
 *       si no, {@code unauthorized_client}. Es lo que hace que solo un terminal registrado pueda usarlo.</li>
 *   <li><b>La tarjeta bloqueada, ANTES de mirar el PIN.</b> Una tarjeta bloqueada no verifica ningun PIN: ni el
 *       correcto da acceso, ni el incorrecto extiende el bloqueo.</li>
 *   <li><b>El PIN.</b> Se compara con BCrypt contra el hash. Si la tarjeta no existe se compara igual contra un
 *       hash falso: sin eso, "tarjeta inexistente" responderia en microsegundos y "PIN incorrecto" en los ~70 ms
 *       de BCrypt, y esa diferencia mediria desde fuera que numeros de tarjeta existen.</li>
 *   <li><b>El resultado.</b> Un fallo es {@code invalid_grant} con {@code error_description}
 *       {@value GrantTarjetaPin#CREDENCIALES_INVALIDAS} (tarjeta inexistente y PIN incorrecto son
 *       indistinguibles) o {@value GrantTarjetaPin#PIN_BLOQUEADO} (cuando la tarjeta esta bloqueada o con este
 *       fallo se agotaron los intentos).</li>
 * </ol>
 *
 * <p>Los pasos 2 a 4 se ejecutan bajo el candado de la tarjeta ({@link RegistroIntentosPin#candado(String)}).
 *
 * <p>Nada de esto escribe un PIN en un log: solo el numero enmascarado.
 */
public class TarjetaPinAuthenticationProvider implements AuthenticationProvider {

    private static final Logger log = LoggerFactory.getLogger(TarjetaPinAuthenticationProvider.class);

    /** Hash BCrypt (del PIN de una tarjeta de prueba) contra el que se compara cuando la tarjeta no existe. */
    private static final String HASH_SENUELO = "{bcrypt}$2a$10$lsSoj9yllS9Z74rJyY0uzOsBkfV14bS/f0BsQP5c.q7zHDDEP2gmW";

    private final Map<String, Tarjeta> tarjetas;
    private final PasswordEncoder codificador;
    private final RegistroIntentosPin intentos;
    private final OAuth2AuthorizationService servicioDeAutorizaciones;
    private final OAuth2TokenGenerator<? extends OAuth2Token> generadorDeTokens;
    private final EventosDeSeguridad eventos;

    public TarjetaPinAuthenticationProvider(AutorizacionProperties propiedades,
                                            PasswordEncoder codificador,
                                            RegistroIntentosPin intentos,
                                            OAuth2AuthorizationService servicioDeAutorizaciones,
                                            OAuth2TokenGenerator<? extends OAuth2Token> generadorDeTokens,
                                            EventosDeSeguridad eventos) {
        this.tarjetas = propiedades.tarjetas().stream().collect(Collectors.toUnmodifiableMap(Tarjeta::numero, t -> t));
        this.codificador = codificador;
        this.intentos = intentos;
        this.servicioDeAutorizaciones = servicioDeAutorizaciones;
        this.generadorDeTokens = generadorDeTokens;
        this.eventos = eventos;
    }

    @Override
    public boolean supports(Class<?> autenticacion) {
        return TarjetaPinAuthenticationToken.class.isAssignableFrom(autenticacion);
    }

    @Override
    public Authentication authenticate(Authentication autenticacion) throws OAuth2AuthenticationException {
        TarjetaPinAuthenticationToken solicitud = (TarjetaPinAuthenticationToken) autenticacion;

        // 1. El terminal: debe ser un cliente ya autenticado que declara este grant.
        OAuth2ClientAuthenticationToken terminal = clienteAutenticado(solicitud);
        RegisteredClient registrado = terminal.getRegisteredClient();
        if (!registrado.getAuthorizationGrantTypes().contains(GrantTarjetaPin.TIPO)) {
            log.warn("El cliente {} intento el grant de tarjeta y PIN sin tener permiso", registrado.getClientId());
            throw new OAuth2AuthenticationException(OAuth2ErrorCodes.UNAUTHORIZED_CLIENT);
        }

        // 2 a 4. Tarjeta, bloqueo y PIN, serializados por tarjeta.
        String numero = solicitud.getNumeroTarjeta();
        Tarjeta tarjeta = tarjetas.get(numero);
        if (tarjeta == null) {
            codificador.matches(solicitud.getPin(), HASH_SENUELO);
            String desconocida = AutorizacionProperties.enmascarar(numero);
            eventos.publicar(TiposEvento.PIN_INCORRECTO, desconocida, new DatosSeguridad(desconocida,
                    registrado.getClientId(), "tarjeta_desconocida", null, null, null));
            throw rechazo(GrantTarjetaPin.CREDENCIALES_INVALIDAS);
        }
        String enmascarada = AutorizacionProperties.enmascarar(numero);
        synchronized (intentos.candado(numero)) {
            if (intentos.estaBloqueada(numero)) {
                log.warn("Intento sobre la tarjeta {} desde {}: esta bloqueada", enmascarada, registrado.getClientId());
                eventos.publicar(TiposEvento.TARJETA_BLOQUEADA, enmascarada, new DatosSeguridad(enmascarada,
                        registrado.getClientId(), "intento_con_tarjeta_bloqueada", intentos.fallos(numero), 0,
                        intentos.bloqueadoHasta(numero)));
                throw rechazo(GrantTarjetaPin.PIN_BLOQUEADO);
            }
            if (!codificador.matches(solicitud.getPin(), tarjeta.pinHash())) {
                boolean bloqueada = intentos.registrarFallo(numero);
                int fallos = intentos.fallos(numero);
                eventos.publicar(TiposEvento.PIN_INCORRECTO, enmascarada, new DatosSeguridad(enmascarada,
                        registrado.getClientId(), "pin_incorrecto", fallos,
                        Math.max(0, intentos.intentosMaximos() - fallos), null));
                if (bloqueada) {
                    eventos.publicar(TiposEvento.TARJETA_BLOQUEADA, enmascarada, new DatosSeguridad(enmascarada,
                            registrado.getClientId(), "intentos_agotados", fallos, 0, intentos.bloqueadoHasta(numero)));
                    log.warn("Tarjeta {} bloqueada tras agotar los intentos de PIN (terminal {})",
                            enmascarada, registrado.getClientId());
                    throw rechazo(GrantTarjetaPin.PIN_BLOQUEADO);
                }
                log.warn("PIN incorrecto para la tarjeta {} (terminal {})", enmascarada, registrado.getClientId());
                throw rechazo(GrantTarjetaPin.CREDENCIALES_INVALIDAS);
            }
            intentos.registrarExito(numero);
        }

        // 5. El token. El terminal es el cliente que se autentico, en mayusculas (ATM-SCL-001).
        TarjetaAutenticada principal = new TarjetaAutenticada(enmascarada, tarjeta.cuentaId(),
                tarjeta.autoridades(), registrado.getClientId().toUpperCase(java.util.Locale.ROOT));
        Set<String> scopes = Collections.emptySet();
        OAuth2TokenContext contexto = DefaultOAuth2TokenContext.builder()
                .registeredClient(registrado)
                .principal(principal)
                .authorizationServerContext(AuthorizationServerContextHolder.getContext())
                .authorizedScopes(scopes)
                .tokenType(OAuth2TokenType.ACCESS_TOKEN)
                .authorizationGrantType(GrantTarjetaPin.TIPO)
                .authorizationGrant(solicitud)
                .build();
        OAuth2Token generado = generadorDeTokens.generate(contexto);
        if (generado == null) {
            throw new OAuth2AuthenticationException(new OAuth2Error(OAuth2ErrorCodes.SERVER_ERROR,
                    "El generador de tokens no devolvio un token de acceso", null));
        }
        OAuth2AccessToken accesso = new OAuth2AccessToken(OAuth2AccessToken.TokenType.BEARER,
                generado.getTokenValue(), generado.getIssuedAt(), generado.getExpiresAt(), scopes);

        OAuth2Authorization.Builder autorizacion = OAuth2Authorization.withRegisteredClient(registrado)
                .principalName(principal.getName())
                .authorizationGrantType(GrantTarjetaPin.TIPO)
                .authorizedScopes(scopes)
                .attribute(Principal.class.getName(), principal);
        if (generado instanceof org.springframework.security.oauth2.core.ClaimAccessor claims) {
            autorizacion.token(accesso, metadatos ->
                    metadatos.put(OAuth2Authorization.Token.CLAIMS_METADATA_NAME, claims.getClaims()));
        } else {
            autorizacion.accessToken(accesso);
        }
        servicioDeAutorizaciones.save(autorizacion.build());

        log.info("Token emitido a la tarjeta {} (cuenta {}) por el terminal {}, vigente hasta {}",
                enmascarada, tarjeta.cuentaId(), registrado.getClientId(), accesso.getExpiresAt());
        return new OAuth2AccessTokenAuthenticationToken(registrado, terminal, accesso);
    }

    private static OAuth2ClientAuthenticationToken clienteAutenticado(TarjetaPinAuthenticationToken solicitud) {
        if (solicitud.getPrincipal() instanceof OAuth2ClientAuthenticationToken cliente && cliente.isAuthenticated()) {
            return cliente;
        }
        throw new OAuth2AuthenticationException(OAuth2ErrorCodes.INVALID_CLIENT);
    }

    private static OAuth2AuthenticationException rechazo(String descripcion) {
        return new OAuth2AuthenticationException(new OAuth2Error(OAuth2ErrorCodes.INVALID_GRANT, descripcion, null));
    }
}
