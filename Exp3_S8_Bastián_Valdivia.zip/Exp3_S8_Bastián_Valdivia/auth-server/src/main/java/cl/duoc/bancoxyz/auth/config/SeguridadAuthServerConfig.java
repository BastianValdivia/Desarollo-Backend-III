package cl.duoc.bancoxyz.auth.config;

import java.time.Clock;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.jwt.NimbusJwtEncoder;
import org.springframework.security.oauth2.server.authorization.InMemoryOAuth2AuthorizationService;
import org.springframework.security.oauth2.server.authorization.OAuth2AuthorizationService;
import org.springframework.security.oauth2.server.authorization.authentication.OAuth2AuthorizationCodeRequestAuthenticationProvider;
import org.springframework.security.oauth2.server.authorization.token.DelegatingOAuth2TokenGenerator;
import org.springframework.security.oauth2.server.authorization.token.JwtEncodingContext;
import org.springframework.security.oauth2.server.authorization.token.JwtGenerator;
import org.springframework.security.oauth2.server.authorization.token.OAuth2AccessTokenGenerator;
import org.springframework.security.oauth2.server.authorization.token.OAuth2RefreshTokenGenerator;
import org.springframework.security.oauth2.server.authorization.token.OAuth2TokenCustomizer;
import org.springframework.security.oauth2.server.authorization.token.OAuth2TokenGenerator;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository;
import org.springframework.security.oauth2.server.authorization.config.annotation.web.configuration.OAuth2AuthorizationServerConfiguration;
import org.springframework.security.oauth2.server.authorization.config.annotation.web.configurers.OAuth2AuthorizationServerConfigurer;
import org.springframework.security.oauth2.server.authorization.settings.AuthorizationServerSettings;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;

import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.SecurityContext;

import cl.duoc.bancoxyz.auth.clientes.RegistroDeClientes;
import cl.duoc.bancoxyz.auth.clientes.ValidadorSolicitudAutorizacion;
import cl.duoc.bancoxyz.auth.eventos.EventosDeSeguridad;
import cl.duoc.bancoxyz.auth.tarjeta.RegistroIntentosPin;
import cl.duoc.bancoxyz.auth.tarjeta.TarjetaPinAuthenticationConverter;
import cl.duoc.bancoxyz.auth.tarjeta.TarjetaPinAuthenticationProvider;
import cl.duoc.bancoxyz.auth.token.FirmaTokens;
import cl.duoc.bancoxyz.auth.token.PersonalizadorDeTokens;
import cl.duoc.bancoxyz.auth.usuarios.ProveedorDeClaveConBloqueo;
import cl.duoc.bancoxyz.auth.usuarios.RegistroIntentosClave;
import cl.duoc.bancoxyz.auth.usuarios.UsuariosBanco;

/**
 * Cableado del servidor de autorizacion: cadenas de seguridad, emisor fijo, clave de firma, clientes y
 * personalizacion del token.
 *
 * <p>Son dos cadenas de filtros, en este orden (la del puerto de gestion, que aporta la libreria
 * compartida, va antes que ambas):
 * <ol>
 *   <li>La del <strong>protocolo</strong>: atiende solo los endpoints de OAuth 2.0 y OpenID Connect
 *       ({@code /oauth2/authorize}, {@code /oauth2/token}, {@code /oauth2/jwks},
 *       {@code /.well-known/openid-configuration} y compania). Los clientes se autentican con su secreto
 *       (los de servicio y los terminales) o con PKCE (las aplicaciones), sin sesion propia. La unica ruta de
 *       esta cadena que puede pedir a una PERSONA que inicie sesion es {@code /oauth2/authorize}: ahi, quien
 *       no tiene sesion se redirige al formulario.</li>
 *   <li>La de <strong>inicio de sesion</strong>: el formulario ({@code /login}) y todo lo demas, que exige
 *       autenticacion. Es la unica cadena con sesion (cookie {@code JSESSIONID}) y con proteccion CSRF,
 *       porque es la unica que habla con un navegador.</li>
 * </ol>
 *
 * <p>El formulario limita los intentos de clave por usuario (ver {@link ProveedorDeClaveConBloqueo}); el
 * cajero limita los de PIN por tarjeta. Las dos credenciales tienen el mismo trato.
 *
 * <p>El descubrimiento y el JWKS son publicos a proposito: son informacion que cualquier servidor de
 * recursos necesita para validar tokens y no contienen nada secreto (el JWKS lleva solo la parte publica
 * de la clave).
 */
@Configuration(proxyBeanMethods = false)
public class SeguridadAuthServerConfig {

    @Bean
    @Order(1)
    public SecurityFilterChain cadenaDelProtocolo(HttpSecurity http,
                                                  UsuariosBanco usuarios,
                                                  AutorizacionProperties propiedades,
                                                  PasswordEncoder codificador,
                                                  RegistroIntentosPin intentosPin,
                                                  OAuth2AuthorizationService servicioDeAutorizaciones,
                                                  OAuth2TokenGenerator<?> generadorDeTokens,
                                                  EventosDeSeguridad eventos) throws Exception {
        OAuth2AuthorizationServerConfiguration.applyDefaultSecurity(http);
        ValidadorSolicitudAutorizacion validador = new ValidadorSolicitudAutorizacion(propiedades, usuarios);
        http.getConfigurer(OAuth2AuthorizationServerConfigurer.class)
                // OpenID Connect: habilita /.well-known/openid-configuration y el JWKS discoverable.
                .oidc(Customizer.withDefaults())
                // Reglas del banco sobre la solicitud de autorizacion (dispositivo del movil, acceso al canal).
                .authorizationEndpoint(autorizacion -> autorizacion.authenticationProviders(proveedores ->
                        proveedores.forEach(proveedor -> {
                            if (proveedor instanceof OAuth2AuthorizationCodeRequestAuthenticationProvider codigo) {
                                codigo.setAuthenticationValidator(validador);
                            }
                        })))
                // Grant de extension del cajero (tarjeta y PIN): se agrega un conversor y un proveedor a los que
                // ya trae Spring Authorization Server, sin reemplazarlos (guia oficial, "Implement an Extension
                // Authorization Grant Type").
                .tokenEndpoint(token -> token
                        .accessTokenRequestConverter(new TarjetaPinAuthenticationConverter())
                        .authenticationProvider(new TarjetaPinAuthenticationProvider(propiedades, codificador,
                                intentosPin, servicioDeAutorizaciones, generadorDeTokens, eventos)));
        http.exceptionHandling(excepciones -> excepciones
                // Quien pide autorizacion sin sesion va al formulario de login (y vuelve aqui al terminar,
                // gracias a la solicitud guardada). Es la unica ruta de esta cadena que habla con personas.
                .defaultAuthenticationEntryPointFor(new LoginUrlAuthenticationEntryPoint("/login"),
                        new AntPathRequestMatcher("/oauth2/authorize"))
                // Todo lo demas (por ejemplo un endpoint protegido sin credenciales) responde 401, no una
                // redireccion. Va DESPUES de la anterior: gana la primera que coincide. No se usa
                // authenticationEntryPoint(...) porque anularia los defaultAuthenticationEntryPointFor.
                .defaultAuthenticationEntryPointFor(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED),
                        AnyRequestMatcher.INSTANCE));
        return http.build();
    }

    @Bean
    @Order(2)
    public SecurityFilterChain cadenaDeInicioDeSesion(HttpSecurity http,
                                                      UsuariosBanco usuarios,
                                                      PasswordEncoder codificador,
                                                      RegistroIntentosClave intentosClave,
                                                      EventosDeSeguridad eventos) throws Exception {
        http
                // Administrador de autenticacion explicito y SIN padre: si dejara el global, un fallo de clave
                // (BadCredentialsException) pasaria al proveedor por defecto, que la verificaria otra vez sin
                // el limite de intentos. Aqui el unico camino para validar una clave es el proveedor con bloqueo.
                .authenticationManager(new ProviderManager(
                        new ProveedorDeClaveConBloqueo(usuarios, codificador, intentosClave, eventos)))
                .authorizeHttpRequests(reglas -> reglas
                        // El formulario y su pagina de error tienen que poder verse sin sesion.
                        .requestMatchers("/login", "/error").permitAll()
                        .anyRequest().authenticated())
                // Formulario propio (en espanol y sin recursos externos): ver PaginasController. CSRF queda
                // activo: el POST de /login sin el token de la sesion se rechaza con 403.
                .formLogin(login -> login
                        .loginPage("/login")
                        .loginProcessingUrl("/login")
                        .failureUrl("/login?error"));
        return http.build();
    }

    /** Reloj del sistema. Es un bean para que las pruebas del bloqueo de PIN puedan adelantar el tiempo. */
    @Bean
    public Clock reloj() {
        return Clock.systemUTC();
    }

    /** La politica de PIN (3 intentos, 15 minutos): ver {@link RegistroIntentosPin}. */
    @Bean
    public RegistroIntentosPin registroIntentosPin(AutorizacionProperties propiedades, Clock reloj) {
        return new RegistroIntentosPin(propiedades.pin(), reloj);
    }

    /** La politica de clave de usuario (3 intentos, 15 minutos): ver {@link RegistroIntentosClave}. */
    @Bean
    public RegistroIntentosClave registroIntentosClave(AutorizacionProperties propiedades, Clock reloj) {
        return new RegistroIntentosClave(propiedades.clave(), reloj);
    }

    /** Los usuarios de los canales web y movil: lo que consulta el formulario de login. */
    @Bean
    public UsuariosBanco usuariosBanco(AutorizacionProperties propiedades) {
        return new UsuariosBanco(propiedades);
    }

    /**
     * Autorizaciones en memoria (codigos de un solo uso y tokens emitidos). Se declara como bean para que el
     * protocolo y los grants propios compartan UNA instancia. En memoria porque hay un solo auth-server y
     * un reinicio solo invalida codigos de segundos de vida; con varias instancias se usaria la variante
     * JDBC (limitacion declarada en la bitacora).
     */
    @Bean
    public OAuth2AuthorizationService servicioDeAutorizaciones() {
        return new InMemoryOAuth2AuthorizationService();
    }

    /**
     * Generador de tokens: JWT firmado con la clave persistente, mas un token opaco y uno de refresco por si
     * algun cliente los pidiera (ninguno los tiene registrados). Es el mismo que usa el protocolo y que usara
     * el grant del cajero, para que TODOS los tokens pasen por el mismo personalizador.
     */
    @Bean
    public OAuth2TokenGenerator<?> generadorDeTokens(JWKSource<SecurityContext> fuenteDeClaves,
                                                     OAuth2TokenCustomizer<JwtEncodingContext> personalizador) {
        JwtGenerator jwt = new JwtGenerator(new NimbusJwtEncoder(fuenteDeClaves));
        jwt.setJwtCustomizer(personalizador);
        return new DelegatingOAuth2TokenGenerator(jwt, new OAuth2AccessTokenGenerator(), new OAuth2RefreshTokenGenerator());
    }

    /**
     * Emisor FIJO (decision D3). Con {@code issuer} configurado, Spring Authorization Server escribe ese
     * valor en {@code iss} y en las direcciones del descubrimiento, sin mirar el nombre con que llego la
     * peticion. Asi el token es el mismo pidiendolo por {@code auth-server:9000} (red interna) o por
     * {@code localhost:9000} (host).
     */
    @Bean
    public AuthorizationServerSettings configuracionDelServidor(AutorizacionProperties propiedades) {
        return AuthorizationServerSettings.builder().issuer(propiedades.emisor()).build();
    }

    /** Clave de firma persistente, leida de los archivos del volumen de secretos (ver {@link FirmaTokens}). */
    @Bean
    public JWKSource<SecurityContext> fuenteDeClaves(AutorizacionProperties propiedades) {
        return FirmaTokens.fuenteDeClaves(propiedades.firma().clavePrivada(), propiedades.firma().clavePublica());
    }

    /**
     * Decodificador de los tokens propios, que Spring Authorization Server necesita para sus endpoints de
     * usuario (userinfo, en F5). Usa la misma fuente de claves: no hay segunda clave ni segunda verdad.
     */
    @Bean
    public JwtDecoder decodificadorPropio(JWKSource<SecurityContext> fuenteDeClaves) {
        return OAuth2AuthorizationServerConfiguration.jwtDecoder(fuenteDeClaves);
    }

    /** BCrypt con sal (prefijo {@code {bcrypt}}): el formato en que se guardan los secretos de cliente. */
    @Bean
    public PasswordEncoder codificadorDeSecretos() {
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

    @Bean
    public RegisteredClientRepository repositorioDeClientes(AutorizacionProperties propiedades,
                                                            PasswordEncoder codificadorDeSecretos) {
        return RegistroDeClientes.construir(propiedades, codificadorDeSecretos);
    }

    @Bean
    public OAuth2TokenCustomizer<JwtEncodingContext> personalizadorDeTokens(AutorizacionProperties propiedades,
                                                                            UsuariosBanco usuarios) {
        return new PersonalizadorDeTokens(propiedades, usuarios);
    }
}
