package cl.duoc.bancoxyz.auth.tarjeta;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2ErrorCodes;
import org.springframework.security.web.authentication.AuthenticationConverter;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Primer paso del grant de extension (segun la guia oficial de Spring Authorization Server, "How-to: Implement
 * an Extension Authorization Grant Type"): lee la peticion al endpoint de tokens y, si es de este grant, la
 * convierte en un {@link TarjetaPinAuthenticationToken}.
 *
 * <p>Si el {@code grant_type} es otro devuelve {@code null}, que es la senal para que el siguiente conversor
 * de la cadena (los de Spring Authorization Server) lo atienda: este conversor se agrega a los existentes, no
 * los reemplaza.
 *
 * <p>Solo valida la FORMA de la peticion: que esten el numero de tarjeta y el PIN, una sola vez cada uno. Un
 * parametro repetido se rechaza porque seria ambiguo cual cuenta (y es un truco clasico para confundir a dos
 * capas que leen valores distintos). La verificacion de la credencial es del proveedor.
 */
public class TarjetaPinAuthenticationConverter implements AuthenticationConverter {

    /** Parametros que el protocolo ya consume y que no son "adicionales". */
    private static final Set<String> PARAMETROS_PROPIOS = Set.of(
            "grant_type", GrantTarjetaPin.PARAMETRO_TARJETA, GrantTarjetaPin.PARAMETRO_PIN);

    @Override
    public Authentication convert(HttpServletRequest peticion) {
        if (!GrantTarjetaPin.URI.equals(peticion.getParameter("grant_type"))) {
            return null;
        }
        String tarjeta = unico(peticion, GrantTarjetaPin.PARAMETRO_TARJETA);
        String pin = unico(peticion, GrantTarjetaPin.PARAMETRO_PIN);

        // El cliente (el terminal) ya se autentico en OAuth2ClientAuthenticationFilter, que va antes.
        Authentication cliente = SecurityContextHolder.getContext().getAuthentication();
        Map<String, Object> adicionales = new HashMap<>();
        peticion.getParameterMap().forEach((nombre, valores) -> {
            if (!PARAMETROS_PROPIOS.contains(nombre)) {
                adicionales.put(nombre, valores.length == 1 ? valores[0] : List.of(valores));
            }
        });
        return new TarjetaPinAuthenticationToken(tarjeta, pin, cliente, adicionales);
    }

    private static String unico(HttpServletRequest peticion, String nombre) {
        String[] valores = peticion.getParameterValues(nombre);
        if (valores == null || valores.length != 1 || valores[0].isBlank()) {
            throw new OAuth2AuthenticationException(new OAuth2Error(OAuth2ErrorCodes.INVALID_REQUEST,
                    "Falta el parametro " + nombre + " o esta repetido", null));
        }
        return valores[0];
    }
}
