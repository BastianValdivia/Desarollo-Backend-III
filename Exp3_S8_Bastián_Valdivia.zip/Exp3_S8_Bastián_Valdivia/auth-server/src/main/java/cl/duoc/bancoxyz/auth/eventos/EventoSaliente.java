package cl.duoc.bancoxyz.auth.eventos;

/**
 * Un evento listo para publicar: el sobre ya serializado y su destino.
 *
 * @param eventId identificador del evento (el del sobre)
 * @param topico  topico de destino
 * @param clave   clave del registro
 * @param payload el sobre en JSON
 */
public record EventoSaliente(String eventId, String topico, String clave, String payload) {
}
