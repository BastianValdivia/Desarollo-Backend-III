package cl.duoc.bancoxyz.auth.eventos;

/**
 * Kafka respondio, pero rechazo ESTE evento de forma permanente: es demasiado grande para el broker
 * ({@code RecordTooLargeException}) o no se pudo serializar. Reintentarlo daria siempre el mismo resultado.
 *
 * <p>Se distingue a proposito de {@link KafkaNoDisponibleException}: no es una caida de Kafka, de modo que ni
 * cuenta como fallo del circuito {@code kafka} ni se reintenta, y el publicador lo descarta (con log y metrica) en
 * lugar de devolverlo al frente de la cola, donde bloquearia para siempre a los eventos legitimos que le siguen.
 */
public class EventoRechazadoException extends RuntimeException {

    public EventoRechazadoException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
