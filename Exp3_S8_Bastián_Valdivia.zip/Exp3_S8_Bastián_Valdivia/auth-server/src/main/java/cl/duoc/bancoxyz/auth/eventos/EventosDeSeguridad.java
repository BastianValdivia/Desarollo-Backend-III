package cl.duoc.bancoxyz.auth.eventos;

import cl.duoc.bancoxyz.eventos.DatosSeguridad;

/**
 * Puerto por el que el servidor de autorizacion anuncia hechos de seguridad (PIN errado, tarjeta bloqueada,
 * login fallido) sin saber como viajan.
 *
 * <p><strong>Contrato: no bloquea y no falla.</strong> Se llama en pleno camino del inicio de sesion (incluso
 * dentro de la seccion critica que serializa los intentos de una tarjeta), asi que una implementacion nunca
 * puede esperar a Kafka ni lanzar una excepcion: el login de una persona no puede depender de que la
 * mensajeria funcione. Si no puede entregar el evento, lo descarta y lo dice en el log y en una metrica.
 */
public interface EventosDeSeguridad {

    /**
     * Anuncia un hecho de seguridad.
     *
     * @param tipo  uno de los tipos de seguridad de {@code TiposEvento}
     * @param clave clave del registro de Kafka (usuario o tarjeta enmascarada): decide la particion
     * @param datos el contenido (nunca una clave, un PIN ni un numero de tarjeta completo)
     */
    void publicar(String tipo, String clave, DatosSeguridad datos);

    /** Una implementacion que no hace nada: el servicio sin mensajeria (pruebas y JVM sin Kafka). */
    EventosDeSeguridad NINGUNO = (tipo, clave, datos) -> {
    };
}
