package cl.duoc.bancoxyz.auth.clientes;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import java.util.regex.Pattern;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2ErrorCodes;
import org.springframework.security.oauth2.server.authorization.authentication.OAuth2AuthorizationCodeRequestAuthenticationContext;
import org.springframework.security.oauth2.server.authorization.authentication.OAuth2AuthorizationCodeRequestAuthenticationException;
import org.springframework.security.oauth2.server.authorization.authentication.OAuth2AuthorizationCodeRequestAuthenticationToken;
import org.springframework.security.oauth2.server.authorization.authentication.OAuth2AuthorizationCodeRequestAuthenticationValidator;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;

import cl.duoc.bancoxyz.auth.config.AutorizacionProperties;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Aplicacion;
import cl.duoc.bancoxyz.auth.token.PersonalizadorDeTokens;
import cl.duoc.bancoxyz.auth.usuarios.UsuariosBanco;

/**
 * Reglas propias del banco sobre la solicitud de autorizacion ({@code /oauth2/authorize}), aplicadas
 * DESPUES de las que Spring Authorization Server ya trae (cliente registrado, redirect URI, PKCE).
 *
 * <p>Se rechaza aqui, antes de entregar un codigo, lo que de otro modo se descubriria al canjearlo o, peor,
 * en el BFF:
 * <ol>
 *   <li><b>Movil sin dispositivo.</b> El token del movil queda atado a un dispositivo (claim
 *       {@code device_id}), y ese valor sale del parametro {@code device_id} de esta solicitud. Sin el, el
 *       token seria inservible (el BFF lo rechazaria en cada peticion) o, peor, quedaria atado a nada.
 *       Se exige con un formato acotado (letras, digitos y {@code . _ : -}, hasta 100 caracteres): el valor
 *       viaja a un claim, a los logs y a un registro de bajas, asi que no se acepta cualquier texto.</li>
 *   <li><b>Usuario sin acceso al canal.</b> {@code ejecutivo1} no tiene canal movil: aunque su clave sea
 *       correcta, el movil no le entrega codigo ({@code access_denied}). Se decide una vez el usuario ya
 *       inicio sesion; antes de eso no se sabe quien es.</li>
 * </ol>
 *
 * <p>Antes de todo eso se descarta, sin redirigir a ninguna parte, a un cliente que no usa
 * {@code authorization_code} (por ejemplo {@code bff-web}, que solo tiene {@code client_credentials}):
 * esos clientes no tienen redirect URIs registradas, y la validacion estandar, al intentar devolver su
 * error por una redireccion, fallaba con {@code NoSuchElementException}: una peticion anonima producia un
 * 500 con traza completa en el registro (y cualquiera podia llenarlo de errores). Ahora es un 400
 * {@code unauthorized_client} sin traza, y sin redireccion aunque la solicitud traiga una
 * {@code redirect_uri} propia (devolver el error por una direccion que el cliente nunca registro seria
 * una redireccion abierta).
 *
 * <p>Los errores se devuelven al cliente en la redireccion ({@code error=...&error_description=...}), como
 * pide la RFC 6749, porque la redirect URI ya fue validada por la regla anterior.
 */
public class ValidadorSolicitudAutorizacion implements Consumer<OAuth2AuthorizationCodeRequestAuthenticationContext> {

    /** Letras, digitos y . _ : - ; entre 1 y 100 caracteres. */
    private static final Pattern FORMATO_DISPOSITIVO = Pattern.compile("^[A-Za-z0-9._:-]{1,100}$");

    private final Consumer<OAuth2AuthorizationCodeRequestAuthenticationContext> reglasEstandar =
            new OAuth2AuthorizationCodeRequestAuthenticationValidator();
    private final Map<String, Aplicacion> aplicaciones;
    private final UsuariosBanco usuarios;

    public ValidadorSolicitudAutorizacion(AutorizacionProperties propiedades, UsuariosBanco usuarios) {
        this.aplicaciones = Map.copyOf(propiedades.aplicaciones());
        this.usuarios = usuarios;
    }

    @Override
    public void accept(OAuth2AuthorizationCodeRequestAuthenticationContext contexto) {
        rechazarClienteSinAuthorizationCode(contexto);

        // Primero las reglas estandar: validan el cliente, el scope y la redirect URI. Las propias se apoyan en
        // que la redirect URI ya es de confianza para poder devolver el error por ella.
        reglasEstandar.accept(contexto);

        Aplicacion app = aplicaciones.get(contexto.getRegisteredClient().getClientId());
        if (app == null) {
            return;
        }
        OAuth2AuthorizationCodeRequestAuthenticationToken solicitud = contexto.getAuthentication();
        String canal = app.canal().toLowerCase(Locale.ROOT);

        if ("movil".equals(canal)) {
            Object dispositivo = solicitud.getAdditionalParameters().get(PersonalizadorDeTokens.PARAMETRO_DISPOSITIVO);
            if (!(dispositivo instanceof String texto) || !FORMATO_DISPOSITIVO.matcher(texto).matches()) {
                throw rechazo(solicitud, OAuth2ErrorCodes.INVALID_REQUEST,
                        "device_id es obligatorio en el canal movil (letras, digitos y . _ : -, hasta 100 caracteres)");
            }
        }

        Authentication usuario = solicitud.getPrincipal() instanceof Authentication a ? a : null;
        boolean identificado = usuario != null && usuario.isAuthenticated()
                && !(usuario instanceof AnonymousAuthenticationToken);
        if (identificado && !usuarios.tieneAcceso(usuario.getName(), canal)) {
            throw rechazo(solicitud, OAuth2ErrorCodes.ACCESS_DENIED, "El usuario no tiene acceso a este canal");
        }
    }

    /**
     * Un cliente que no tiene el grant {@code authorization_code} no puede pedir autorizacion. El error no se
     * devuelve por redireccion: el token de la excepcion se arma SIN {@code redirect_uri} para que Spring
     * responda 400 directamente, en vez de redirigir a una direccion que viene en la solicitud.
     */
    private static void rechazarClienteSinAuthorizationCode(OAuth2AuthorizationCodeRequestAuthenticationContext contexto) {
        RegisteredClient cliente = contexto.getRegisteredClient();
        if (cliente.getAuthorizationGrantTypes().contains(AuthorizationGrantType.AUTHORIZATION_CODE)) {
            return;
        }
        OAuth2AuthorizationCodeRequestAuthenticationToken s = contexto.getAuthentication();
        Authentication principal = s.getPrincipal() instanceof Authentication a ? a
                : new AnonymousAuthenticationToken("anonimo", "anonimo", List.of(new SimpleGrantedAuthority("ROLE_ANONYMOUS")));
        throw new OAuth2AuthorizationCodeRequestAuthenticationException(
                new OAuth2Error(OAuth2ErrorCodes.UNAUTHORIZED_CLIENT, "El cliente no usa authorization_code", null),
                new OAuth2AuthorizationCodeRequestAuthenticationToken(s.getAuthorizationUri(), s.getClientId(),
                        principal, null, null, s.getScopes(), s.getAdditionalParameters()));
    }

    private static OAuth2AuthorizationCodeRequestAuthenticationException rechazo(
            OAuth2AuthorizationCodeRequestAuthenticationToken solicitud, String codigo, String descripcion) {
        return new OAuth2AuthorizationCodeRequestAuthenticationException(
                new OAuth2Error(codigo, descripcion, null), solicitud);
    }
}
