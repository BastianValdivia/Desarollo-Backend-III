package cl.duoc.bancoxyz.auth.eventos;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Deja siempre un {@link EventosDeSeguridad} disponible: el publicador real cuando
 * {@code eventos.seguridad.habilitado=true} (perfiles {@code docker} y {@code local}) y uno que no hace nada
 * cuando no (pruebas, o un despliegue sin Kafka). El resto del servicio nunca pregunta cual es.
 */
@Configuration(proxyBeanMethods = false)
public class EventosSeguridadConfig {

    @Bean
    @ConditionalOnProperty(name = "eventos.seguridad.habilitado", havingValue = "false", matchIfMissing = true)
    public EventosDeSeguridad eventosDeSeguridadInactivo() {
        return EventosDeSeguridad.NINGUNO;
    }
}
