package cl.duoc.bancoxyz.auth.token;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2ErrorCodes;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
import org.springframework.security.oauth2.server.authorization.OAuth2Authorization;
import org.springframework.security.oauth2.server.authorization.OAuth2TokenType;
import org.springframework.security.oauth2.server.authorization.token.JwtEncodingContext;
import org.springframework.security.oauth2.server.authorization.token.OAuth2TokenCustomizer;

import cl.duoc.bancoxyz.auth.config.AutorizacionProperties;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Aplicacion;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Terminal;
import cl.duoc.bancoxyz.auth.tarjeta.GrantTarjetaPin;
import cl.duoc.bancoxyz.auth.tarjeta.TarjetaAutenticada;
import cl.duoc.bancoxyz.auth.usuarios.UsuariosBanco;
import cl.duoc.bancoxyz.comun.token.ClaimsToken;

/**
 * Escribe en cada token de acceso lo que lo hace servir para su destino: la AUDIENCIA, el canal, la cuenta,
 * las autoridades y, en el movil, el dispositivo.
 *
 * <p><strong>Que es la audiencia y por que importa mas que el scope en este diseno.</strong> El claim
 * {@code aud} dice "para quien es este token". Con un solo emisor y una sola clave de firma para todo el
 * sistema, el unico muro entre servicios es la audiencia: {@code bff-mobile} rechaza un token cuya
 * audiencia sea {@code bff-web} aunque este bien firmado, y el core rechaza los que no nombran
 * {@code core-service}. Spring Authorization Server pone por defecto el {@code client_id} como audiencia,
 * que no sirve a ningun servidor de recursos; por eso se reemplaza siempre.
 *
 * <p>Segun el grant que origino el token:
 * <ul>
 *   <li><b>{@code client_credentials}</b> (un BFF pidiendo su token de servicio): audiencias de su
 *       configuracion ({@code core-service}, y {@code auditoria-service} para el BFF web) y
 *       {@code client_id}.</li>
 *   <li><b>{@code authorization_code}</b> (una persona en {@code web-app} o {@code mobile-app}): audiencia
 *       del BFF de su canal, {@code canal}, {@code cuentaId} (salvo el ejecutivo, que no tiene cuenta) y
 *       {@code authorities} con las autoridades DEL USUARIO EN ESE CANAL. Los nombres de estos claims son
 *       los que los BFF ya leian cuando emitian sus propios tokens ({@link ClaimsToken}), de modo que su
 *       autorizacion no se reescribe. En el movil agrega {@code device_id}.</li>
 *   <li><b>tarjeta y PIN</b> (el cajero): audiencia {@code bff-atm}, {@code canal} {@code ATM},
 *       {@code cuentaId} y {@code authorities} de la tarjeta, y {@code terminal} (el cajero registrado que la
 *       autentico). Un BFF del cajero solo atiende tokens que traen un terminal.</li>
 * </ul>
 *
 * <p><strong>Como llega {@code device_id} al token.</strong> La app movil agrega el parametro
 * {@code device_id} a la solicitud de autorizacion ({@code /oauth2/authorize?...&device_id=...}). Spring
 * Authorization Server guarda esa solicitud completa en la autorizacion
 * ({@link OAuth2AuthorizationRequest}, con sus parametros adicionales) y la entrega al personalizador al
 * canjear el codigo. Una prueba lo comprueba de punta a punta. El dispositivo queda asi atado a la sesion:
 * lo declaro quien inicio el login, no quien presenta el token despues.
 *
 * <p>Una configuracion que no se pueda resolver falla CERRADA: lanza una excepcion antes de emitir un
 * token con una audiencia o autoridades que nadie decidio.
 */
public class PersonalizadorDeTokens implements OAuth2TokenCustomizer<JwtEncodingContext> {

    /** Nombre del parametro adicional de la solicitud de autorizacion que lleva el dispositivo del movil. */
    public static final String PARAMETRO_DISPOSITIVO = "device_id";

    private final Map<String, List<String>> audienciasPorCliente;
    private final Map<String, Aplicacion> aplicaciones;
    private final Map<String, Terminal> terminales;
    private final UsuariosBanco usuarios;

    public PersonalizadorDeTokens(AutorizacionProperties propiedades, UsuariosBanco usuarios) {
        // Copias inmutables: la politica queda fijada al arrancar y no depende del objeto de propiedades.
        this.audienciasPorCliente = Map.copyOf(propiedades.clientes().entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, e -> List.copyOf(e.getValue().audiencias()))));
        this.aplicaciones = Map.copyOf(propiedades.aplicaciones());
        this.terminales = Map.copyOf(propiedades.terminales());
        this.usuarios = usuarios;
    }

    @Override
    public void customize(JwtEncodingContext contexto) {
        if (!OAuth2TokenType.ACCESS_TOKEN.equals(contexto.getTokenType())) {
            return;
        }
        AuthorizationGrantType grant = contexto.getAuthorizationGrantType();
        if (AuthorizationGrantType.CLIENT_CREDENTIALS.equals(grant)) {
            deServicio(contexto);
        } else if (AuthorizationGrantType.AUTHORIZATION_CODE.equals(grant)) {
            deUsuario(contexto);
        } else if (GrantTarjetaPin.TIPO.equals(grant)) {
            deTarjeta(contexto);
        }
    }

    private void deTarjeta(JwtEncodingContext contexto) {
        String clienteId = contexto.getRegisteredClient().getClientId();
        Terminal terminal = terminales.get(clienteId);
        Authentication principal = contexto.getPrincipal();
        if (terminal == null || !(principal instanceof TarjetaAutenticada tarjeta)) {
            // Falla cerrada: nunca se emite un token del cajero sin terminal registrado y tarjeta verificada.
            throw new IllegalStateException("El grant de tarjeta y PIN solo se emite a un terminal registrado");
        }
        contexto.getClaims()
                .audience(List.of(terminal.audiencia()))
                .claim("client_id", clienteId)
                .claim(ClaimsToken.CANAL, ClaimsToken.CANAL_ATM)
                .claim(ClaimsToken.CUENTA_ID, tarjeta.cuentaId())
                .claim(ClaimsToken.AUTORIDADES, tarjeta.autoridadesDelCanal())
                .claim(ClaimsToken.TERMINAL, tarjeta.terminal());
    }

    private void deServicio(JwtEncodingContext contexto) {
        String clienteId = contexto.getRegisteredClient().getClientId();
        List<String> audiencias = audienciasPorCliente.get(clienteId);
        if (audiencias == null) {
            // No deberia ocurrir: el repositorio se construye con la misma lista. Si ocurre, se prefiere
            // fallar a emitir un token con una audiencia que no se decidio.
            throw new IllegalStateException("El cliente " + clienteId + " no tiene audiencias configuradas");
        }
        contexto.getClaims()
                .audience(audiencias)
                .claim("client_id", clienteId);
    }

    private void deUsuario(JwtEncodingContext contexto) {
        String clienteId = contexto.getRegisteredClient().getClientId();
        Aplicacion app = aplicaciones.get(clienteId);
        if (app == null) {
            throw new IllegalStateException("El cliente " + clienteId + " no es una aplicacion de usuario");
        }
        String usuario = contexto.getPrincipal().getName();
        String canal = app.canal().toLowerCase(Locale.ROOT);
        List<String> autoridades = usuarios.autoridades(usuario, canal);
        if (autoridades.isEmpty()) {
            // Defensa en profundidad: ValidadorSolicitudAutorizacion ya lo rechazo al pedir el codigo.
            throw new OAuth2AuthenticationException(new OAuth2Error(OAuth2ErrorCodes.ACCESS_DENIED,
                    "El usuario no tiene acceso a este canal", null));
        }
        var claims = contexto.getClaims()
                .audience(List.of(app.audiencia()))
                .claim("client_id", clienteId)
                .claim(ClaimsToken.CANAL, canal.toUpperCase(Locale.ROOT))
                .claim(ClaimsToken.AUTORIDADES, autoridades);
        // El ejecutivo no tiene cuenta: omitir el claim es mas honesto que escribir un cero, que una
        // comprobacion de titularidad podria comparar por accidente contra una cuenta real.
        usuarios.cuentaId(usuario).ifPresent(cuenta -> claims.claim(ClaimsToken.CUENTA_ID, cuenta));
        if (ClaimsToken.CANAL_MOVIL.equalsIgnoreCase(canal)) {
            claims.claim(ClaimsToken.DEVICE_ID, dispositivoDeLaSolicitud(contexto));
        }
    }

    private static String dispositivoDeLaSolicitud(JwtEncodingContext contexto) {
        OAuth2Authorization autorizacion = contexto.getAuthorization();
        OAuth2AuthorizationRequest solicitud = autorizacion == null ? null
                : autorizacion.getAttribute(OAuth2AuthorizationRequest.class.getName());
        Object dispositivo = solicitud == null ? null : solicitud.getAdditionalParameters().get(PARAMETRO_DISPOSITIVO);
        if (!(dispositivo instanceof String texto) || texto.isBlank()) {
            // ValidadorSolicitudAutorizacion lo exige al pedir el codigo; llegar aqui sin el es un defecto.
            throw new OAuth2AuthenticationException(new OAuth2Error(OAuth2ErrorCodes.INVALID_REQUEST,
                    "Falta el parametro device_id de la solicitud de autorizacion", null));
        }
        return texto;
    }
}
