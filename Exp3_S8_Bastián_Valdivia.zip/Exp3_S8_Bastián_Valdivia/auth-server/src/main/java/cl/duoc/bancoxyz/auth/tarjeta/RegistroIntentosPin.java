package cl.duoc.bancoxyz.auth.tarjeta;

import java.time.Clock;

import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Pin;
import cl.duoc.bancoxyz.auth.intentos.RegistroIntentos;

/**
 * La politica de PIN: tres intentos fallidos bloquean la tarjeta durante quince minutos.
 *
 * <p>Viene del BFF del cajero del S5 ({@code RegistroIntentosPin}): el servidor de autorizacion es donde vive la
 * autenticacion, y por eso es donde se cuentan los fallos. Un BFF no puede ser quien bloquea la tarjeta si ya
 * no es quien comprueba el PIN.
 *
 * <p>El sujeto que se cuenta es el numero de tarjeta (no el terminal: intentar el mismo PIN desde otro cajero no
 * reinicia el contador). El detalle de como se cuenta y por que hace falta un candado por tarjeta esta en
 * {@link RegistroIntentos}. Es un tipo propio, y no una instancia suelta de la base, para que los contadores del
 * PIN y de la clave sean beans distintos que Spring no confunda.
 */
public class RegistroIntentosPin extends RegistroIntentos {

    public RegistroIntentosPin(Pin politica, Clock reloj) {
        super(politica.intentosMaximos(), politica.bloqueo(), reloj);
    }
}
