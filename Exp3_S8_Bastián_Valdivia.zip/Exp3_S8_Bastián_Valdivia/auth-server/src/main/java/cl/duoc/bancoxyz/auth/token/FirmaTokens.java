package cl.duoc.bancoxyz.auth.token;

import java.io.IOException;
import java.io.InputStream;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import org.springframework.core.io.Resource;
import org.springframework.security.converter.RsaKeyConverters;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.KeyUse;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.SecurityContext;

/**
 * Carga la clave de firma de los tokens desde dos archivos PEM del volumen de secretos.
 *
 * <p><strong>Por que la clave se LEE y no se genera.</strong> El ejemplo mas corto de Spring
 * Authorization Server genera un par RSA nuevo en memoria cada vez que arranca. Es comodo y es un
 * defecto en cuanto hay un reinicio: todos los tokens vigentes quedan firmados con una clave que ya no
 * existe, y cada servicio que habia descargado la clave publica la rechaza. Aqui el par lo crea una vez
 * {@code secretos-init} en el volumen del servicio y el servidor solo lo lee, de modo que reiniciarlo
 * (o recrear el contenedor) no invalida nada.
 *
 * <p><strong>El identificador de clave ({@code kid}).</strong> Se deriva de la huella (SHA-256, RFC 7638)
 * de la clave publica y no se inventa: la misma clave da siempre el mismo {@code kid}, asi que tras un
 * reinicio los servicios que guardaron el JWKS en cache siguen reconociendo la clave.
 *
 * <p>Se comprueba que la clave publica corresponda a la privada. Un par cruzado (por ejemplo un volumen
 * a medio regenerar) produciria tokens que ningun servicio puede verificar, con un sintoma lejano a la
 * causa (401 en el core); aqui se convierte en un error de arranque que dice lo que pasa.
 */
public final class FirmaTokens {

    private FirmaTokens() {
    }

    /**
     * @param clavePrivada PEM PKCS#8
     * @param clavePublica PEM X.509
     * @return una fuente de claves inmutable con ese unico par, que es la que SAS usa para firmar y
     *         para publicar el JWKS (solo la parte publica)
     */
    public static JWKSource<SecurityContext> fuenteDeClaves(Resource clavePrivada, Resource clavePublica) {
        return new ImmutableJWKSet<>(new JWKSet(cargar(clavePrivada, clavePublica)));
    }

    /** Construye la {@link RSAKey} completa (con la parte privada) a partir de los dos archivos. */
    public static RSAKey cargar(Resource clavePrivada, Resource clavePublica) {
        RSAPrivateKey privada = leerPrivada(clavePrivada);
        RSAPublicKey publica = leerPublica(clavePublica);
        // El exponente publico y el modulo salen de la privada CRT: si el modulo difiere, no son pareja.
        if (!(privada instanceof RSAPrivateCrtKey crt) || !crt.getModulus().equals(publica.getModulus())
                || !crt.getPublicExponent().equals(publica.getPublicExponent())) {
            throw new IllegalStateException("La clave publica de firma no corresponde a la clave privada ("
                    + clavePublica.getDescription() + " y " + clavePrivada.getDescription() + "). "
                    + "Regenere el par juntos: un par cruzado firma tokens que nadie puede verificar.");
        }
        try {
            RSAKey sinId = new RSAKey.Builder(publica).build();
            return new RSAKey.Builder(publica)
                    .privateKey(privada)
                    .keyUse(KeyUse.SIGNATURE)
                    .algorithm(JWSAlgorithm.RS256)
                    .keyID(sinId.computeThumbprint().toString())
                    .build();
        } catch (JOSEException e) {
            throw new IllegalStateException("No se pudo calcular la huella de la clave de firma", e);
        }
    }

    private static RSAPrivateKey leerPrivada(Resource recurso) {
        try (InputStream entrada = recurso.getInputStream()) {
            return RsaKeyConverters.pkcs8().convert(entrada);
        } catch (IOException | RuntimeException e) {
            throw new IllegalStateException("No se pudo leer la clave privada de firma " + recurso.getDescription()
                    + " (se espera PEM PKCS#8). Si el archivo no existe, secretos-init no corrio.", e);
        }
    }

    private static RSAPublicKey leerPublica(Resource recurso) {
        try (InputStream entrada = recurso.getInputStream()) {
            return RsaKeyConverters.x509().convert(entrada);
        } catch (IOException | RuntimeException e) {
            throw new IllegalStateException("No se pudo leer la clave publica de firma " + recurso.getDescription()
                    + " (se espera PEM X.509).", e);
        }
    }
}
