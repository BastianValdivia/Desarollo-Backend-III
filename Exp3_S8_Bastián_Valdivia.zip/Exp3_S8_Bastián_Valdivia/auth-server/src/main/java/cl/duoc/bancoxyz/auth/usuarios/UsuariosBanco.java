package cl.duoc.bancoxyz.auth.usuarios;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import cl.duoc.bancoxyz.auth.config.AutorizacionProperties;
import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Usuario;

/**
 * Los usuarios de los canales web y movil: quien inicia sesion en el formulario del servidor de
 * autorizacion y con que autoridades queda en cada canal.
 *
 * <p><strong>Un usuario, una sola clave.</strong> En el S5 cada BFF tenia su propio padron, y
 * {@code cliente116} tenia una clave en el canal web y otra en el movil: dos identidades con el mismo
 * nombre. Con un servidor de autorizacion central eso no tiene sentido (la identidad es de la persona, no
 * del canal), asi que hay un solo registro por usuario con una sola clave. Lo que si depende del canal
 * son las <em>autoridades</em>: {@code cliente116} puede ver su ficha en la web y consultar el resumen en el
 * movil, y {@code ejecutivo1} solo existe en la web.
 *
 * <p><strong>Por que la sesion de login no lleva las autoridades del canal.</strong> El usuario inicia
 * sesion una vez, ANTES de saber para que canal sera el token: el canal lo decide el cliente que pidio la
 * autorizacion ({@code web-app} o {@code mobile-app}). Por eso el {@link UserDetails} de la sesion lleva
 * solo una autoridad generica y las autoridades del canal se resuelven despues, al emitir el token
 * ({@link #autoridades(String, String)}). Asi una sesion abierta desde la web no puede reutilizarse para
 * obtener un token movil con permisos que el usuario no tiene en ese canal.
 *
 * <p>La comprobacion de la clave no la hace esta clase: la hace {@code DaoAuthenticationProvider} de Spring
 * Security, que ademas compara contra un hash falso cuando el usuario no existe (para que "usuario
 * inexistente" y "clave equivocada" tarden lo mismo y no revelen que nombres existen).
 */
public class UsuariosBanco implements UserDetailsService {

    /** Autoridad de la sesion de login. No concede nada: los permisos reales viajan en el token. */
    static final String AUTORIDAD_DE_SESION = "USUARIO_BANCO";

    private final Map<String, Usuario> usuarios;

    public UsuariosBanco(AutorizacionProperties propiedades) {
        this.usuarios = Map.copyOf(propiedades.usuarios());
    }

    @Override
    public UserDetails loadUserByUsername(String nombre) throws UsernameNotFoundException {
        Usuario usuario = nombre == null ? null : usuarios.get(nombre);
        if (usuario == null) {
            // El mensaje no llega al cliente: DaoAuthenticationProvider lo convierte en "credenciales incorrectas".
            throw new UsernameNotFoundException("Usuario desconocido");
        }
        return User.withUsername(nombre)
                .password(usuario.claveHash())
                .authorities(AuthorityUtils.createAuthorityList(AUTORIDAD_DE_SESION))
                .build();
    }

    /** {@code true} si el nombre es exactamente el de un usuario configurado (distingue mayusculas). */
    public boolean existe(String nombre) {
        return nombre != null && usuarios.containsKey(nombre);
    }

    /** Cuenta de la que el usuario es titular, o vacio si no tiene (el ejecutivo). */
    public Optional<Integer> cuentaId(String nombre) {
        return Optional.ofNullable(usuarios.get(nombre)).map(Usuario::cuentaId);
    }

    /**
     * Autoridades del usuario en un canal.
     *
     * @param nombre nombre de usuario
     * @param canal  {@code web} o {@code movil} (sin distinguir mayusculas)
     * @return las autoridades, o una lista vacia si el usuario no existe o no tiene acceso a ese canal
     */
    public List<String> autoridades(String nombre, String canal) {
        Usuario usuario = nombre == null ? null : usuarios.get(nombre);
        if (usuario == null || canal == null) {
            return List.of();
        }
        List<String> autoridades = usuario.canales().get(canal.toLowerCase(Locale.ROOT));
        return autoridades == null ? List.of() : List.copyOf(autoridades);
    }

    /** {@code true} si el usuario puede iniciar sesion en ese canal. */
    public boolean tieneAcceso(String nombre, String canal) {
        return !autoridades(nombre, canal).isEmpty();
    }
}
