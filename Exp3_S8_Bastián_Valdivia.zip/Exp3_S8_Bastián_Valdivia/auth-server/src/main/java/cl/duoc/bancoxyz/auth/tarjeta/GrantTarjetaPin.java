package cl.duoc.bancoxyz.auth.tarjeta;

import org.springframework.security.oauth2.core.AuthorizationGrantType;

/**
 * El grant de extension del cajero: tarjeta y PIN.
 *
 * <p><strong>Por que un grant de extension y no {@code password}.</strong> Un cajero no tiene navegador, asi
 * que {@code authorization_code} no sirve. El grant {@code password} (el cliente le entrega al servidor el
 * usuario y la clave del titular) existia para este caso, pero la RFC 9700 (mejores practicas de seguridad de
 * OAuth 2.0) lo prohibe y Spring Authorization Server no lo implementa. La RFC 6749, apartado 4.5, preve los
 * grants de extension, identificados por un URI absoluto. Este lo es: {@code urn:bancoxyz:params:oauth:grant-type:tarjeta-pin}.
 *
 * <p><strong>Lo que lo hace distinto de {@code password}</strong> en este diseno es que quien lo usa tiene que
 * ser, ademas, un TERMINAL REGISTRADO: el cliente {@code atm-scl-001} se autentica con su propio secreto
 * ({@code client_secret_basic}) y solo los clientes que declaran este grant pueden usarlo. Una aplicacion web o
 * movil, o un BFF, que presente una tarjeta y un PIN recibe {@code unauthorized_client}. Eso reemplaza la
 * lista blanca de terminales del S5 (una cabecera {@code X-Terminal-Id} que cualquiera podia escribir) por una
 * autenticacion real del terminal.
 */
public final class GrantTarjetaPin {

    /** Valor del parametro {@code grant_type}. */
    public static final String URI = "urn:bancoxyz:params:oauth:grant-type:tarjeta-pin";

    /** Tipo de grant, para registrarlo en los clientes que pueden usarlo y para reconocerlo en el personalizador. */
    public static final AuthorizationGrantType TIPO = new AuthorizationGrantType(URI);

    /** Parametro con el numero de la tarjeta (solo digitos). */
    public static final String PARAMETRO_TARJETA = "numero_tarjeta";

    /** Parametro con el PIN. Viaja solo en el cuerpo de un POST por HTTPS y nunca se escribe en un log. */
    public static final String PARAMETRO_PIN = "pin";

    /** Codigo de {@code error_description} cuando la tarjeta no existe o el PIN no coincide (indistinguibles a proposito). */
    public static final String CREDENCIALES_INVALIDAS = "credenciales_invalidas";

    /** Codigo de {@code error_description} cuando la tarjeta esta bloqueada por intentos fallidos. */
    public static final String PIN_BLOQUEADO = "pin_bloqueado";

    private GrantTarjetaPin() {
    }
}
