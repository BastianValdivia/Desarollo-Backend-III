package cl.duoc.bancoxyz.auth.web;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.HtmlUtils;

/**
 * Las dos paginas del servidor de autorizacion: el formulario de inicio de sesion y la pagina a la que cae
 * quien entra directo (sin venir de una aplicacion).
 *
 * <p>El formulario es HTML plano, sin plantillas ni recursos externos: no hay JavaScript, ni fuentes, ni
 * hojas de estilo remotas que un tercero pueda alterar en una pagina que recibe contrasenas. La unica parte
 * dinamica es el token CSRF, que el formulario devuelve en el campo oculto {@code _csrf}. Ese token es lo
 * que impide que otra pagina haga iniciar sesion al navegador de la victima con las credenciales del
 * atacante ("login CSRF"): Spring Security rechaza con 403 un POST a {@code /login} sin el token de la
 * sesion. Los scripts de login lo extraen de este mismo HTML.
 *
 * <p>El formulario no dice a que aplicacion se va a entregar la sesion ni muestra mensajes que distingan
 * "usuario inexistente" de "clave incorrecta" ni de "usuario bloqueado por demasiados intentos": el unico
 * error posible es uno solo, para que el bloqueo no sirva para averiguar que usuarios existen.
 *
 * <p>Las dos paginas viajan con una {@code Content-Security-Policy} restrictiva: {@code default-src 'none'}
 * (la pagina no carga nada de ninguna parte), solo estilos en linea, sin {@code <base>} y sin poder
 * incrustarse en el marco de otra pagina ({@code frame-ancestors 'none'}, que refuerza el
 * {@code X-Frame-Options: DENY} de Spring Security). Deliberadamente <strong>no</strong> lleva
 * {@code form-action}: Chrome aplica esa directiva tambien a las redirecciones que siguen al envio del
 * formulario, y tras el login el servidor redirige a la {@code redirect_uri} de la aplicacion (por ejemplo
 * {@code http://127.0.0.1:3000/callback}); con {@code form-action 'self'} el navegador bloquearia justo el
 * ultimo paso del flujo.
 */
@Controller
public class PaginasController {

    private static final String ESTILO =
            "body{font-family:sans-serif;max-width:22rem;margin:4rem auto;padding:0 1rem}"
                    + "label{display:block;margin-top:1rem}input{width:100%;padding:.5rem;box-sizing:border-box}"
                    + "button{margin-top:1.5rem;padding:.6rem 1.2rem}.error{color:#b00020}";

    /** Politica de contenido de las dos paginas: ver la nota de la clase sobre por que no hay {@code form-action}. */
    static final String POLITICA_DE_CONTENIDO =
            "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'";

    @GetMapping(path = "/login", produces = MediaType.TEXT_HTML_VALUE + ";charset=UTF-8")
    @ResponseBody
    public String login(CsrfToken csrf, @RequestParam(name = "error", required = false) String error,
                        HttpServletResponse respuesta) {
        respuesta.setHeader("Content-Security-Policy", POLITICA_DE_CONTENIDO);
        String aviso = error == null ? "" : "<p class=\"error\" role=\"alert\">Usuario o clave incorrectos, o acceso bloqueado temporalmente.</p>";
        return """
                <!DOCTYPE html>
                <html lang="es">
                <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
                <title>Banco XYZ: iniciar sesión</title><style>%s</style></head>
                <body>
                <h1>Banco XYZ</h1>
                <h2>Iniciar sesión</h2>
                %s
                <form method="post" action="/login">
                  <label for="username">Usuario</label>
                  <input id="username" name="username" type="text" autocomplete="username" required autofocus>
                  <label for="password">Clave</label>
                  <input id="password" name="password" type="password" autocomplete="current-password" required>
                  <input type="hidden" name="%s" value="%s">
                  <button type="submit">Entrar</button>
                </form>
                </body>
                </html>
                """.formatted(ESTILO, aviso,
                HtmlUtils.htmlEscape(csrf.getParameterName()), HtmlUtils.htmlEscape(csrf.getToken()));
    }

    /** Destino por defecto tras iniciar sesion sin una solicitud pendiente: quien llego directo. */
    @GetMapping(path = "/", produces = MediaType.TEXT_HTML_VALUE + ";charset=UTF-8")
    @ResponseBody
    public String inicio(HttpServletResponse respuesta) {
        respuesta.setHeader("Content-Security-Policy", POLITICA_DE_CONTENIDO);
        return """
                <!DOCTYPE html>
                <html lang="es"><head><meta charset="UTF-8"><title>Banco XYZ</title><style>%s</style></head>
                <body><h1>Banco XYZ</h1>
                <p>Sesión iniciada. Vuelva a la aplicación del banco para continuar.</p></body></html>
                """.formatted(ESTILO);
    }
}
