package cl.duoc.bancoxyz.auth.tarjeta;

import java.util.Map;

import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.server.authorization.authentication.OAuth2AuthorizationGrantAuthenticationToken;

import cl.duoc.bancoxyz.auth.config.AutorizacionProperties;

/**
 * La solicitud de token del grant tarjeta y PIN, ya leida del cuerpo del POST y todavia SIN verificar: lo que
 * {@link TarjetaPinAuthenticationConverter} entrega a {@link TarjetaPinAuthenticationProvider}.
 *
 * <p>El PIN viaja aqui en memoria solo el tiempo que dura la verificacion. {@code toString} no lo muestra, para
 * que una traza o un log de depuracion que imprima el objeto no filtre una credencial.
 */
public class TarjetaPinAuthenticationToken extends OAuth2AuthorizationGrantAuthenticationToken {

    private final String numeroTarjeta;
    private final transient String pin;

    public TarjetaPinAuthenticationToken(String numeroTarjeta, String pin, Authentication clientePrincipal,
                                         Map<String, Object> parametrosAdicionales) {
        super(GrantTarjetaPin.TIPO, clientePrincipal, parametrosAdicionales);
        this.numeroTarjeta = numeroTarjeta;
        this.pin = pin;
    }

    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }

    public String getPin() {
        return pin;
    }

    @Override
    public String toString() {
        return "TarjetaPinAuthenticationToken[tarjeta=" + AutorizacionProperties.enmascarar(numeroTarjeta)
                + ", pin=****]";
    }
}
