package cl.duoc.bancoxyz.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Import;

import cl.duoc.bancoxyz.comun.gestion.SeguridadPuertoGestionConfig;

/**
 * Punto de entrada del <strong>auth-server</strong>, el servidor de autorizacion del Banco XYZ.
 *
 * <p>Es el unico emisor de tokens del sistema (plan, decision D2). Los demas servicios no firman
 * nada: los BFF le piden un token de servicio con el flujo {@code client_credentials} y el core
 * valida su firma con la clave publica que este servidor publica en {@code /oauth2/jwks}. Esa
 * separacion es lo que en la guia de aprendizaje se llama "delegacion de seguridad": ningun
 * servicio implementa su propia autenticacion.
 *
 * <p><strong>Por que se importa {@link SeguridadPuertoGestionConfig} a mano y no se escanea
 * {@code cl.duoc.bancoxyz.comun}.</strong> La libreria compartida trae tambien el cliente HTTP
 * del core y el balanceador, que este servicio no usa. Importar solo la cadena del puerto de
 * gestion deja el contexto con lo estrictamente necesario, y una clase que falte falla de forma
 * ruidosa al arrancar.
 */
@SpringBootApplication
@ConfigurationPropertiesScan("cl.duoc.bancoxyz.auth")
@Import(SeguridadPuertoGestionConfig.class)
public class AuthServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuthServerApplication.class, args);
    }
}
