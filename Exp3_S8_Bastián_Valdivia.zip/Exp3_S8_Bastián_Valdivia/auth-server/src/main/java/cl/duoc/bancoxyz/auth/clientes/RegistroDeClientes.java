package cl.duoc.bancoxyz.auth.clientes;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;
import org.springframework.security.oauth2.server.authorization.client.InMemoryRegisteredClientRepository;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository;
import org.springframework.security.oauth2.server.authorization.settings.ClientSettings;
import org.springframework.security.oauth2.server.authorization.settings.OAuth2TokenFormat;
import org.springframework.security.oauth2.server.authorization.settings.TokenSettings;

import cl.duoc.bancoxyz.auth.config.AutorizacionProperties;
import cl.duoc.bancoxyz.auth.tarjeta.GrantTarjetaPin;

/**
 * Construye el repositorio de clientes OAuth2 a partir de la configuracion. Hay tres familias, y cada una
 * tiene su propio flujo y su propio nivel de confianza:
 *
 * <table border="1">
 *   <caption>Clientes registrados</caption>
 *   <tr><th>Familia</th><th>Quien es</th><th>Tipo</th><th>Grant</th></tr>
 *   <tr><td>servicio</td><td>{@code bff-web}, {@code bff-mobile}, {@code bff-atm}</td>
 *       <td>confidencial, {@code client_secret_basic}</td><td>{@code client_credentials}</td></tr>
 *   <tr><td>aplicacion</td><td>{@code web-app}, {@code mobile-app}</td>
 *       <td>PUBLICO, sin secreto</td><td>{@code authorization_code} con PKCE obligatorio</td></tr>
 *   <tr><td>terminal</td><td>{@code atm-scl-001}</td>
 *       <td>confidencial, {@code client_secret_basic}</td><td>extension tarjeta y PIN</td></tr>
 * </table>
 *
 * <p><strong>Los clientes de servicio</strong> usan un unico flujo y se autentican con la cabecera
 * {@code Authorization: Basic}, nunca con el secreto en la URL ni en el cuerpo. No tienen ningun otro
 * grant: un BFF comprometido no puede pedir tokens de usuario.
 *
 * <p><strong>Las aplicaciones</strong> (navegador y app movil) son clientes publicos: el codigo de una
 * aplicacion que corre en el equipo del usuario no puede guardar un secreto, y uno incrustado seria publico
 * para cualquiera que la desarme. Lo que protege el flujo no es un secreto sino PKCE (RFC 7636): la
 * aplicacion inventa un secreto de un solo uso por cada inicio de sesion, entrega su huella al pedir el
 * codigo y la prueba al canjearlo, de modo que un codigo interceptado no sirve a quien lo robo. Por eso
 * {@code requireProofKey(true)}: sin PKCE el servidor rechaza la solicitud. Tampoco hay pantalla de
 * consentimiento ({@code requireAuthorizationConsent(false)}): son aplicaciones propias del banco, el
 * usuario no esta delegando su cuenta en un tercero, asi que pedirle "autoriza a esta aplicacion" no aporta
 * seguridad y si friccion.
 *
 * <p><strong>El terminal</strong> es confidencial porque el cajero es una maquina del banco que si puede
 * guardar un secreto. Ese secreto reemplaza la lista blanca de terminales del S5: solo quien lo tiene puede
 * usar el grant de tarjeta y PIN.
 *
 * <p><strong>Los secretos se guardan con hash.</strong> El secreto en claro llega de un archivo del volumen
 * de secretos y aqui se transforma, antes de crear el {@link RegisteredClient}, en un hash BCrypt con sal
 * (prefijo {@code {bcrypt}}). El repositorio solo conoce ese hash. BCrypt es lenta a proposito (unos 70
 * ms), lo que aqui no importa: un BFF pide un token cada cuatro minutos y lo reutiliza.
 */
public final class RegistroDeClientes {

    /** Cuanto vive el codigo de autorizacion: lo justo para que la aplicacion lo canjee. */
    private static final Duration VIGENCIA_DEL_CODIGO = Duration.ofMinutes(2);

    private RegistroDeClientes() {
    }

    public static RegisteredClientRepository construir(AutorizacionProperties propiedades, PasswordEncoder codificador) {
        List<RegisteredClient> todos = new ArrayList<>();
        propiedades.clientes().forEach((id, cliente) -> todos.add(RegisteredClient
                .withId(identificador(id))
                .clientId(id)
                .clientSecret(codificador.encode(cliente.secreto()))
                .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_BASIC)
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .scopes(scopes -> scopes.addAll(cliente.scopes()))
                .tokenSettings(tokenSettings(propiedades.vigenciaAcceso()).build())
                .clientSettings(ClientSettings.builder().requireAuthorizationConsent(false).build())
                .build()));
        propiedades.aplicaciones().forEach((id, app) -> todos.add(RegisteredClient
                .withId(identificador(id))
                .clientId(id)
                // Sin secreto: cliente publico. La barrera es PKCE.
                .clientAuthenticationMethod(ClientAuthenticationMethod.NONE)
                .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
                .redirectUris(uris -> uris.addAll(app.redirectUris()))
                .tokenSettings(tokenSettings(app.vigencia()).authorizationCodeTimeToLive(VIGENCIA_DEL_CODIGO).build())
                .clientSettings(ClientSettings.builder()
                        .requireProofKey(true)
                        .requireAuthorizationConsent(false)
                        .build())
                .build()));
        propiedades.terminales().forEach((id, terminal) -> todos.add(RegisteredClient
                .withId(identificador(id))
                .clientId(id)
                .clientSecret(codificador.encode(terminal.secreto()))
                .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_BASIC)
                // Su unico grant es el de extension: no puede pedir tokens de servicio ni de usuario.
                .authorizationGrantType(GrantTarjetaPin.TIPO)
                .tokenSettings(tokenSettings(terminal.vigencia()).build())
                .clientSettings(ClientSettings.builder().requireAuthorizationConsent(false).build())
                .build()));
        return new InMemoryRegisteredClientRepository(todos);
    }

    /** JWT autocontenido: el BFF lo valida con la clave publica, sin llamar de vuelta al servidor. */
    private static TokenSettings.Builder tokenSettings(Duration vigencia) {
        return TokenSettings.builder()
                .accessTokenTimeToLive(vigencia)
                .accessTokenFormat(OAuth2TokenFormat.SELF_CONTAINED);
    }

    /** Identificador interno estable: el mismo client_id da siempre el mismo id. */
    private static String identificador(String clientId) {
        return UUID.nameUUIDFromBytes(clientId.getBytes(StandardCharsets.UTF_8)).toString();
    }
}
