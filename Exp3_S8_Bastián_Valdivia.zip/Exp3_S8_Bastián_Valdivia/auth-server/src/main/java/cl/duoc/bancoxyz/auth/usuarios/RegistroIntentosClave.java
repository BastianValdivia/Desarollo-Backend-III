package cl.duoc.bancoxyz.auth.usuarios;

import java.time.Clock;

import cl.duoc.bancoxyz.auth.config.AutorizacionProperties.Clave;
import cl.duoc.bancoxyz.auth.intentos.RegistroIntentos;

/**
 * La politica de intentos de la clave de los usuarios web y movil: tres fallos bloquean al usuario quince
 * minutos (valores de {@code autorizacion.clave}).
 *
 * <p>Cierra una asimetria: el auth-server esta publicado en el puerto 9000 y su formulario de login recibe claves
 * de cualquiera, pero solo el PIN de la tarjeta tenia limite. Sin esta clase, un atacante podia probar claves sin
 * fin contra {@code cliente116} o {@code ejecutivo1}.
 *
 * <p>El sujeto que se cuenta es el nombre de usuario, y solo el de usuarios que existen (lo decide
 * {@link ProveedorDeClaveConBloqueo}). Es el mismo mecanismo que el del PIN ({@link RegistroIntentos}), con su
 * propio contador: fallar la clave de {@code cliente116} no bloquea su tarjeta ni al reves.
 */
public class RegistroIntentosClave extends RegistroIntentos {

    public RegistroIntentosClave(Clave politica, Clock reloj) {
        super(politica.intentosMaximos(), politica.bloqueo(), reloj);
    }
}
