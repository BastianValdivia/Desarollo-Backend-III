package cl.duoc.bancoxyz.auth.eventos;

/**
 * Kafka no confirmo la recepcion de un evento de seguridad: esta caido, inalcanzable o demasiado lento.
 *
 * <p>La unica excepcion que Resilience4j cuenta como fallo del circuito {@code kafka} del auth-server. Nunca
 * llega al login: la captura el hilo que publica en segundo plano.
 */
public class KafkaNoDisponibleException extends RuntimeException {

    public KafkaNoDisponibleException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
