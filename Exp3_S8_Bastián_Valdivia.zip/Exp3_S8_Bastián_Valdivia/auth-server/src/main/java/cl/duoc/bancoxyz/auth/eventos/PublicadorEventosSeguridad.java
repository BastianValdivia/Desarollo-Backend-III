package cl.duoc.bancoxyz.auth.eventos;

import java.time.Clock;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import cl.duoc.bancoxyz.eventos.CodecEventos;
import cl.duoc.bancoxyz.eventos.DatosSeguridad;
import cl.duoc.bancoxyz.eventos.SobreEvento;
import cl.duoc.bancoxyz.eventos.Topicos;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * Publica los eventos de seguridad en {@code bancoxyz.seguridad.v1} SIN bloquear nunca el inicio de sesion.
 *
 * <h2>El problema</h2>
 *
 * <p>Los eventos se originan en pleno login (un PIN errado, una clave rechazada). Enviarlos a Kafka desde ese
 * mismo hilo haria que, con Kafka caido, cada intento de login esperara el plazo del envio (2 a 5 s) y que el
 * usuario viera lentitud por una falla de mensajeria que no le concierne.
 *
 * <h2>La solucion: una cola en memoria y un hilo de fondo</h2>
 *
 * <ul>
 *   <li>{@link #publicar} arma el evento y lo deja en una cola acotada con {@code offer}, que NUNCA espera.
 *       Cuesta microsegundos y no puede fallar: si la cola esta llena, descarta el evento y lo cuenta.</li>
 *   <li>Un hilo daemon saca de la cola, en orden, y entrega cada evento con {@link EnvioKafka} (protegido
 *       con Resilience4j). Si Kafka no responde, deja el evento AL FRENTE de la cola (no pierde el orden),
 *       espera un segundo y reintenta: los eventos sobreviven a una caida de Kafka mientras quepan en la cola.</li>
 * </ul>
 *
 * <h2>El limite, dicho con honestidad</h2>
 *
 * <p>El core garantiza que no pierde eventos con un outbox en su base. El auth-server NO tiene base de datos
 * (es un servidor de tokens sin estado propio), asi que su respaldo es memoria: se pierde lo que haya en la
 * cola si el proceso muere, y se descarta lo que exceda su capacidad durante una caida larga de Kafka. Es una
 * decision consciente: estos eventos son de observabilidad de seguridad, no de dinero, y un outbox aqui
 * obligaria a darle una base al unico servicio que no la necesita. Lo descartado queda en el log y en la
 * metrica {@code eventos.seguridad.descartados}.
 *
 * <p>Los eventos que Kafka rechaza para siempre (demasiado grandes, no serializables) NO se reintentan: se
 * descartan con su log y la metrica {@code eventos.seguridad.rechazados}. Si volvieran al frente de la cola como
 * una caida de Kafka, detendrian para siempre a los eventos legitimos que les siguen.
 */
@Component
@ConditionalOnProperty(name = "eventos.seguridad.habilitado", havingValue = "true")
public class PublicadorEventosSeguridad implements EventosDeSeguridad, DisposableBean {

    private static final Logger log = LoggerFactory.getLogger(PublicadorEventosSeguridad.class);

    private static final String ORIGEN = "auth-server";

    /**
     * Tamano maximo (en caracteres) del sobre serializado. Un evento legitimo pesa menos de 1 KiB; el tope (64 KiB, muy por debajo
     * del limite de 1 MiB del broker) corta de raiz cualquier evento anormal antes de que ocupe la cola.
     */
    static final int TAMANO_MAXIMO_CARACTERES = 64 * 1024;

    private final EnvioKafka envio;
    private final Clock reloj;
    private final LinkedBlockingDeque<EventoSaliente> cola;
    private final long esperaTrasFallo;
    private final Counter enviados;
    private final Counter descartados;
    private final Counter rechazados;
    private final Thread hilo;
    private volatile boolean activo = true;
    private volatile boolean kafkaCaido;

    public PublicadorEventosSeguridad(EnvioKafka envio, Clock reloj, MeterRegistry metricas,
                                      @Value("${eventos.seguridad.cola:1000}") int capacidad,
                                      @Value("${eventos.seguridad.espera-tras-fallo-ms:1000}") long esperaTrasFallo) {
        this.envio = envio;
        this.reloj = reloj;
        this.cola = new LinkedBlockingDeque<>(capacidad);
        this.esperaTrasFallo = esperaTrasFallo;
        this.enviados = Counter.builder("eventos.seguridad.enviados")
                .description("Eventos de seguridad confirmados por Kafka").register(metricas);
        this.descartados = Counter.builder("eventos.seguridad.descartados")
                .description("Eventos de seguridad descartados porque la cola estaba llena").register(metricas);
        this.rechazados = Counter.builder("eventos.seguridad.rechazados")
                .description("Eventos de seguridad descartados por anormales (tamano) o porque Kafka los rechazo de forma permanente")
                .register(metricas);
        Gauge.builder("eventos.seguridad.pendientes", cola, LinkedBlockingDeque::size)
                .description("Eventos de seguridad en cola esperando a Kafka").register(metricas);
        this.hilo = new Thread(this::bucle, "eventos-seguridad");
        this.hilo.setDaemon(true);
        this.hilo.start();
    }

    @Override
    public void publicar(String tipo, String clave, DatosSeguridad datos) {
        try {
            SobreEvento evento = SobreEvento.nuevo(tipo, 1, reloj.instant(), ORIGEN, datos);
            String payload = CodecEventos.escribir(evento);
            if (payload.length() > TAMANO_MAXIMO_CARACTERES) {
                rechazados.increment();
                log.warn("Evento de seguridad {} ({}) descartado: pesa {} caracteres y el maximo es {}.",
                        evento.eventId(), tipo, payload.length(), TAMANO_MAXIMO_CARACTERES);
                return;
            }
            EventoSaliente saliente = new EventoSaliente(evento.eventId(), Topicos.SEGURIDAD, clave, payload);
            if (!cola.offerLast(saliente)) {
                descartados.increment();
                log.warn("Cola de eventos de seguridad llena ({}): se descarta el evento {} ({}).",
                        cola.size(), evento.eventId(), tipo);
            }
        } catch (RuntimeException e) {
            // El contrato del puerto: jamas rompe el login.
            descartados.increment();
            log.warn("No se pudo preparar el evento de seguridad {}: {}", tipo, e.toString());
        }
    }

    /** El hilo de fondo: saca del frente, entrega, y ante un fallo deja el evento donde estaba y espera. */
    private void bucle() {
        while (activo || !cola.isEmpty() && kafkaSano()) {
            EventoSaliente evento = null;
            try {
                evento = cola.pollFirst(500, TimeUnit.MILLISECONDS);
                if (evento == null) {
                    if (!activo) {
                        return;
                    }
                    continue;
                }
                envio.enviar(evento);
                enviados.increment();
                avisarSiKafkaVolvio();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                if (evento != null) {
                    cola.offerFirst(evento);
                }
                return;
            } catch (EventoRechazadoException e) {
                // El broker lo rechaza para siempre: se descarta (no vuelve a la cola) y los que siguen no se detienen.
                rechazados.increment();
                log.warn("Evento de seguridad {} descartado: {}", evento == null ? "?" : evento.eventId(),
                        e.getCause() == null ? e.getMessage() : e.getCause().toString());
            } catch (RuntimeException e) {
                // Kafka no responde (o el circuito esta abierto): el evento vuelve al FRENTE para no perder el orden.
                if (evento != null) {
                    cola.offerFirst(evento);
                }
                avisarSiKafkaCayo(e);
                if (!activo) {
                    return;
                }
                dormir(esperaTrasFallo);
            }
        }
    }

    private boolean kafkaSano() {
        return !kafkaCaido;
    }

    private void avisarSiKafkaCayo(RuntimeException e) {
        if (!kafkaCaido) {
            kafkaCaido = true;
            log.warn("Eventos de seguridad: Kafka no responde ({}). Quedan en cola ({} pendientes) y se entregaran "
                    + "cuando vuelva; el inicio de sesion no se ve afectado.", e.getClass().getSimpleName(), cola.size());
        }
    }

    private void avisarSiKafkaVolvio() {
        if (kafkaCaido) {
            kafkaCaido = false;
            log.info("Eventos de seguridad: Kafka volvio; se entregan los pendientes ({} en cola).", cola.size());
        }
    }

    private static void dormir(long milisegundos) {
        try {
            Thread.sleep(milisegundos);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /** Cuantos eventos esperan a Kafka (para las pruebas y la metrica). */
    public int pendientes() {
        return cola.size();
    }

    /** Al apagar el servicio: intenta vaciar la cola unos segundos y se detiene. */
    @Override
    public void destroy() throws InterruptedException {
        activo = false;
        hilo.join(3000);
        if (hilo.isAlive()) {
            hilo.interrupt();
        }
        if (!cola.isEmpty()) {
            log.warn("Eventos de seguridad: al apagar quedaron {} sin entregar (el auth-server no tiene base de "
                    + "datos donde guardarlos).", cola.size());
        }
    }
}
