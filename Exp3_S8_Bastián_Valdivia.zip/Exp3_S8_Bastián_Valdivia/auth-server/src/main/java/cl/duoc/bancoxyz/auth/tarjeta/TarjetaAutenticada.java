package cl.duoc.bancoxyz.auth.tarjeta;

import java.util.List;

import org.springframework.security.authentication.AbstractAuthenticationToken;

/**
 * El resultado de verificar tarjeta y PIN: quien es el portador (para el token), ya autenticado.
 *
 * <p>Es el {@code principal} del contexto con que se genera el token. El personalizador de tokens lo lee para
 * escribir la cuenta, las autoridades y el terminal. El nombre ({@code getName()}, que acaba en el claim
 * {@code sub}) es el numero de tarjeta ENMASCARADO (seis primeros y cuatro ultimos digitos, como en el
 * formato de truncamiento de PCI DSS): el token viaja por muchos servicios y se registra en logs, y no
 * necesita llevar el numero completo para nada.
 */
public class TarjetaAutenticada extends AbstractAuthenticationToken {

    private final String tarjetaEnmascarada;
    private final int cuentaId;
    private final List<String> autoridadesDelCanal;
    private final String terminal;

    public TarjetaAutenticada(String tarjetaEnmascarada, int cuentaId, List<String> autoridadesDelCanal, String terminal) {
        super(List.of());
        this.tarjetaEnmascarada = tarjetaEnmascarada;
        this.cuentaId = cuentaId;
        this.autoridadesDelCanal = List.copyOf(autoridadesDelCanal);
        this.terminal = terminal;
        setAuthenticated(true);
    }

    @Override
    public Object getPrincipal() {
        return tarjetaEnmascarada;
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    public int cuentaId() {
        return cuentaId;
    }

    public List<String> autoridadesDelCanal() {
        return autoridadesDelCanal;
    }

    public String terminal() {
        return terminal;
    }
}
