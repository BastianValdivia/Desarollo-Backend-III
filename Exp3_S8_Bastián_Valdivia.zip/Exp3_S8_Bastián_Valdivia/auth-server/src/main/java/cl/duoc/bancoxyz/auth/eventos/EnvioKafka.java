package cl.duoc.bancoxyz.auth.eventos;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.RecordTooLargeException;
import org.apache.kafka.common.errors.SerializationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

/**
 * Entrega UN evento a Kafka y espera la confirmacion. Es la frontera con Kafka del auth-server y por eso lleva
 * la proteccion de Resilience4j (instancia {@code kafka}, en {@code config-repo/auth-server.yml}):
 *
 * <ul>
 *   <li><strong>Retry</strong>: un fallo pasajero se reintenta de inmediato.</li>
 *   <li><strong>CircuitBreaker</strong>: con Kafka caido, cada intento esperaria varios segundos. Tras unos fallos
 *       el circuito se abre y los intentos siguientes se rechazan al instante hasta que una llamada de prueba
 *       confirme que Kafka volvio.</li>
 * </ul>
 *
 * <p>No todo fallo es una caida: si el broker rechaza ESTE evento de forma permanente (demasiado grande, no
 * serializable), se lanza {@link EventoRechazadoException}, que ni se reintenta ni cuenta para el circuito, y el
 * publicador lo descarta. Tratarlo como "Kafka caido" abriria el circuito y dejaria el evento al frente de la
 * cola para siempre.
 *
 * <p>Esta clase se llama desde el hilo de fondo de {@link PublicadorEventosSeguridad}, NUNCA desde el del
 * login: por eso puede esperar. Las excepciones (incluida {@code CallNotPermittedException} del circuito
 * abierto) las maneja ese hilo.
 */
@Component
@ConditionalOnProperty(name = "eventos.seguridad.habilitado", havingValue = "true")
public class EnvioKafka {

    private final KafkaTemplate<String, String> kafka;
    private final long plazoMilisegundos;

    public EnvioKafka(KafkaTemplate<String, String> kafka,
                      @Value("${eventos.seguridad.plazo-envio-ms:5000}") long plazoMilisegundos) {
        this.kafka = kafka;
        this.plazoMilisegundos = plazoMilisegundos;
    }

    @Retry(name = "kafka")
    @CircuitBreaker(name = "kafka")
    public void enviar(EventoSaliente evento) {
        try {
            ProducerRecord<String, String> registro =
                    new ProducerRecord<>(evento.topico(), evento.clave(), evento.payload());
            registro.headers().add("eventId", evento.eventId().getBytes(StandardCharsets.UTF_8));
            kafka.send(registro).get(plazoMilisegundos, TimeUnit.MILLISECONDS);
        } catch (ExecutionException | TimeoutException | RuntimeException e) {
            if (esRechazoPermanente(e)) {
                throw new EventoRechazadoException("Kafka rechazo de forma permanente el evento " + evento.eventId(), e);
            }
            throw new KafkaNoDisponibleException("Kafka no confirmo el evento " + evento.eventId(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new KafkaNoDisponibleException("Envio interrumpido del evento " + evento.eventId(), e);
        }
    }

    /**
     * Si en la cadena de causas hay un error que no cambiara al reintentar. Se recorre la cadena porque, segun
     * por donde falle el envio, el productor lo entrega envuelto en {@code ExecutionException} o en una
     * excepcion de Spring Kafka.
     */
    static boolean esRechazoPermanente(Throwable error) {
        for (Throwable causa = error; causa != null; causa = causa.getCause() == causa ? null : causa.getCause()) {
            if (causa instanceof RecordTooLargeException || causa instanceof SerializationException) {
                return true;
            }
        }
        return false;
    }
}
