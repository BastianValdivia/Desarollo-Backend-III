package cl.duoc.bancoxyz.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Pruebas del config-server contra la carpeta REAL {@code config-repo/} del repositorio.
 *
 * <p>Maven ejecuta las pruebas con el directorio del modulo como directorio de trabajo, asi que
 * la carpeta se alcanza como {@code ../config-repo/}. No se usa una copia de prueba a proposito:
 * lo que se valida es lo que de verdad se entregara a los servicios.
 *
 * <p>Se activa el perfil {@code test} para no heredar el perfil por defecto ({@code local}), que
 * fija puertos concretos (el de gestion, 8085) y chocaria con un servidor ya levantado.
 */
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = "spring.cloud.config.server.native.search-locations=file:../config-repo/")
@ActiveProfiles("test")
class ConfigServerTest {

    private static final ObjectMapper JSON = new ObjectMapper();

    /**
     * Patron de nombres de propiedad que delatan un secreto. Se aplica a las CLAVES, no a los
     * valores: {@code token.clave-privada} apunta a una ruta de archivo y es legitima, pero una
     * clave {@code ...password} o {@code ...secret} con un valor dentro de config-repo no lo es.
     */
    private static final Pattern CLAVE_DE_SECRETO = Pattern.compile(
            "(?i)(password|passwd|secret|api[-_.]?key|private[-_.]?key|token-servicio|credential|contrasena|secreto|clave-bcrypt)");

    /** Cabecera de una clave privada PEM: si aparece en un valor, alguien pego una clave. */
    private static final Pattern CLAVE_PEM = Pattern.compile("-----BEGIN [A-Z ]*PRIVATE KEY-----");

    @Autowired
    private TestRestTemplate http;

    private JsonNode pedir(String servicio, String perfiles) throws Exception {
        ResponseEntity<String> respuesta = http.getForEntity("/" + servicio + "/" + perfiles, String.class);
        assertThat(respuesta.getStatusCode().value())
                .as("GET /%s/%s", servicio, perfiles).isEqualTo(200);
        return JSON.readTree(respuesta.getBody());
    }

    /** Aplana las fuentes de propiedades en el orden de precedencia (la primera gana). */
    private Map<String, Object> aplanar(JsonNode entorno) {
        Map<String, Object> efectivo = new LinkedHashMap<>();
        for (JsonNode fuente : entorno.get("propertySources")) {
            fuente.get("source").fields().forEachRemaining(e -> efectivo.putIfAbsent(e.getKey(),
                    e.getValue().isNumber() ? e.getValue().numberValue() : e.getValue().asText()));
        }
        return efectivo;
    }

    @ParameterizedTest(name = "{0} con perfil {1} recibe su archivo de servicio y el comun")
    @CsvSource({
            "core-service,local",
            "core-service,docker",
            "auth-server,local",
            "auth-server,docker",
            "bff-web,local",
            "bff-web,docker",
            "bff-mobile,local",
            "bff-mobile,docker",
            "bff-atm,local",
            "bff-atm,docker"
    })
    @DisplayName("Cada servicio y perfil recibe configuracion de su propio archivo y del comun")
    void entregaLaConfiguracionDeCadaServicioYPerfil(String servicio, String perfil) throws Exception {
        JsonNode entorno = pedir(servicio, perfil);

        List<String> origenes = new ArrayList<>();
        entorno.get("propertySources").forEach(f -> origenes.add(f.get("name").asText()));

        assertThat(origenes).anyMatch(n -> n.endsWith("/" + servicio + ".yml"));
        assertThat(origenes).anyMatch(n -> n.endsWith("/" + servicio + "-" + perfil + ".yml"));
        assertThat(origenes).anyMatch(n -> n.endsWith("/application.yml"));
        assertThat(origenes).anyMatch(n -> n.endsWith("/application-" + perfil + ".yml"));
        assertThat(entorno.get("name").asText()).isEqualTo(servicio);
    }

    /**
     * Fija el orden real de precedencia, que es el que documentan los encabezados de
     * {@code config-repo/*.yml} y la bitacora F1. Contra la intuicion, el archivo comun POR PERFIL
     * gana al archivo del servicio SIN perfil: lo decide el perfil primero y el servicio despues.
     * Si el config-server cambiara de criterio al actualizar Spring Cloud, esta prueba lo avisa
     * antes de que alguien edite el archivo equivocado y no vea efecto.
     */
    @Test
    @DisplayName("La precedencia es application, servicio, y por cada perfil comun y luego servicio-perfil")
    void ordenDePrecedenciaDeLosArchivos() throws Exception {
        assertThat(nombresDeArchivo(pedir("bff-web", "local,demo"))).containsExactly(
                "application-demo.yml", "bff-web-local.yml", "application-local.yml",
                "bff-web.yml", "application.yml");
        // Con los perfiles al reves gana el ultimo de la lista: demo pasa a ser el de menor peso.
        assertThat(nombresDeArchivo(pedir("bff-web", "demo,local"))).containsExactly(
                "bff-web-local.yml", "application-local.yml", "application-demo.yml",
                "bff-web.yml", "application.yml");
    }

    /**
     * El cliente de Eureka no debe reconstruirse con {@code POST /actuator/refresh}: si lo hace,
     * el balanceador se queda sin instancias unos segundos y los BFF responden 503.
     */
    @ParameterizedTest(name = "{0} recibe eureka.client.refresh.enable=false")
    @CsvSource({"core-service", "auth-server", "bff-web", "bff-mobile", "bff-atm"})
    @DisplayName("Todos los servicios reciben eureka.client.refresh.enable=false")
    void todosRecibenElRefreshDeEurekaDesactivado(String servicio) throws Exception {
        assertThat(aplanar(pedir(servicio, "local,demo")).get("eureka.client.refresh.enable"))
                .as(servicio).isEqualTo("false");
    }

    /** Nombres de archivo (sin ruta) de las fuentes, de mayor a menor precedencia. */
    private List<String> nombresDeArchivo(JsonNode entorno) {
        List<String> nombres = new ArrayList<>();
        entorno.get("propertySources").forEach(f -> {
            String nombre = f.get("name").asText();
            nombres.add(nombre.substring(nombre.lastIndexOf('/') + 1));
        });
        return nombres;
    }

    @Test
    @DisplayName("Los BFF reciben el nombre logico del core y no una direccion fija")
    void losBffLlamanAlCorePorNombreLogico() throws Exception {
        for (String bff : List.of("bff-web", "bff-mobile", "bff-atm")) {
            Map<String, Object> efectivo = aplanar(pedir(bff, "local,demo"));
            assertThat(efectivo.get("core.base-url")).as(bff).isEqualTo("http://core-service");
        }
    }

    @Test
    @DisplayName("En local cada servicio tiene su propio puerto de gestion distinto del de servicio")
    void cadaServicioLocalTieneSuPuertoDeGestion() throws Exception {
        Map<String, Integer> esperados = Map.of(
                "core-service", 8081, "bff-web", 8082, "bff-mobile", 8083, "bff-atm", 8084, "auth-server", 8087);
        List<Object> usados = new ArrayList<>();
        for (Map.Entry<String, Integer> e : esperados.entrySet()) {
            Map<String, Object> efectivo = aplanar(pedir(e.getKey(), "local,demo"));
            assertThat(efectivo.get("management.server.port")).as(e.getKey()).isEqualTo(e.getValue());
            assertThat(efectivo.get("management.server.port")).isNotEqualTo(efectivo.get("server.port"));
            usados.add(efectivo.get("management.server.port"));
        }
        assertThat(usados).doesNotHaveDuplicates();
    }

    @Test
    @DisplayName("El perfil docker del core escucha en todas las interfaces y el local solo en el bucle local")
    void direccionDeEscuchaDelCoreSegunEntorno() throws Exception {
        assertThat(aplanar(pedir("core-service", "local")).get("server.address")).isEqualTo("127.0.0.1");
        assertThat(aplanar(pedir("core-service", "docker")).get("server.address")).isEqualTo("0.0.0.0");
    }

    @Test
    @DisplayName("Actuator expone solo health, info, metrics, refresh y los de Resilience4j, y nunca env, configprops ni heapdump")
    void actuatorNoExponeEndpointsSensibles() throws Exception {
        Map<String, Object> efectivo = aplanar(pedir("bff-web", "local"));
        String incluidos = String.valueOf(efectivo.get("management.endpoints.web.exposure.include"));
        String excluidos = String.valueOf(efectivo.get("management.endpoints.web.exposure.exclude"));

        assertThat(List.of(incluidos.split(","))).containsExactlyInAnyOrder("health", "info", "metrics", "refresh",
                "circuitbreakers", "circuitbreakerevents", "retries", "retryevents", "bulkheads", "bulkheadevents");
        assertThat(incluidos).doesNotContain("*").doesNotContain("env")
                .doesNotContain("configprops").doesNotContain("heapdump");
        assertThat(excluidos).contains("env").contains("configprops").contains("heapdump");
    }

    @Test
    @DisplayName("El perfil demo acorta los arriendos de Eureka")
    void elPerfilDemoAcortaLosArriendos() throws Exception {
        Map<String, Object> efectivo = aplanar(pedir("core-service", "local,demo"));
        assertThat(efectivo.get("eureka.instance.lease-renewal-interval-in-seconds")).isEqualTo(5);
        assertThat(efectivo.get("eureka.instance.lease-expiration-duration-in-seconds")).isEqualTo(15);
    }

    @Test
    @DisplayName("Existe la propiedad info.* de la demostracion de refresh")
    void existeLaPropiedadInfoDeLaDemostracion() throws Exception {
        assertThat(aplanar(pedir("bff-atm", "local")).get("info.demostracion.mensaje")).isNotNull();
    }

    /**
     * La politica de OAuth2 de cada cliente de servicio (decision D2 del plan) vive en config-repo: es lo
     * que el auth-server concede. Se fija aqui para que un cambio de scopes o de audiencia sea un cambio
     * visible y no un descuido.
     */
    @Test
    @DisplayName("El auth-server recibe los scopes y audiencias exactos de cada cliente y un emisor fijo")
    void elAuthServerRecibeLaPoliticaDeSusClientes() throws Exception {
        Map<String, Object> docker = aplanar(pedir("auth-server", "docker,demo"));

        assertThat(docker.get("autorizacion.emisor")).isEqualTo("https://localhost:9000");
        assertThat(docker.get("autorizacion.vigencia-acceso")).isEqualTo("5m");
        assertThat(docker.get("server.port")).isEqualTo(9000);
        assertThat(docker.get("server.ssl.enabled")).isEqualTo("true");
        assertThat(lista(docker, "autorizacion.clientes.bff-web.scopes"))
                .containsExactly("cuentas:leer", "movimientos:leer", "auditoria:leer");
        assertThat(lista(docker, "autorizacion.clientes.bff-web.audiencias"))
                .containsExactly("core-service", "auditoria-service");
        assertThat(lista(docker, "autorizacion.clientes.bff-mobile.scopes")).containsExactly("cuentas:leer");
        assertThat(lista(docker, "autorizacion.clientes.bff-mobile.audiencias")).containsExactly("core-service");
        assertThat(lista(docker, "autorizacion.clientes.bff-atm.scopes")).containsExactly("saldo:leer", "retiros:ejecutar");
        assertThat(lista(docker, "autorizacion.clientes.bff-atm.audiencias")).containsExactly("core-service");
    }

    /**
     * La politica de los usuarios (F5): las aplicaciones web y movil, sus vigencias (las del S5) y los usuarios con
     * sus autoridades por canal. Los hashes de clave NO son un secreto (BCrypt con sal) y no se comparan aqui.
     */
    @Test
    @DisplayName("El auth-server recibe las aplicaciones web y movil (30 y 60 min, loopback) y los usuarios con sus canales")
    void elAuthServerRecibeLasAplicacionesYLosUsuarios() throws Exception {
        Map<String, Object> docker = aplanar(pedir("auth-server", "docker,demo"));

        assertThat(docker.get("autorizacion.aplicaciones.web-app.canal")).isEqualTo("web");
        assertThat(docker.get("autorizacion.aplicaciones.web-app.audiencia")).isEqualTo("bff-web");
        assertThat(docker.get("autorizacion.aplicaciones.web-app.vigencia")).isEqualTo("30m");
        assertThat(lista(docker, "autorizacion.aplicaciones.web-app.redirect-uris"))
                .containsExactly("http://127.0.0.1:3000/callback");
        assertThat(docker.get("autorizacion.aplicaciones.mobile-app.canal")).isEqualTo("movil");
        assertThat(docker.get("autorizacion.aplicaciones.mobile-app.audiencia")).isEqualTo("bff-mobile");
        assertThat(docker.get("autorizacion.aplicaciones.mobile-app.vigencia")).isEqualTo("60m");
        assertThat(lista(docker, "autorizacion.aplicaciones.mobile-app.redirect-uris"))
                .containsExactly("http://127.0.0.1:3001/callback");

        assertThat(docker.get("autorizacion.usuarios.cliente116.cuenta-id")).isEqualTo(116);
        assertThat(lista(docker, "autorizacion.usuarios.cliente116.canales.web"))
                .containsExactly("ROLE_CLIENTE_WEB", "PERM_cuenta:leer", "PERM_movimientos:leer", "PERM_resumen:leer");
        assertThat(lista(docker, "autorizacion.usuarios.cliente116.canales.movil"))
                .containsExactly("ROLE_CLIENTE_MOVIL", "PERM_saldo:leer", "PERM_dispositivo:gestionar");
        assertThat(docker.get("autorizacion.usuarios.cliente105.cuenta-id")).isEqualTo(105);
        assertThat(docker).doesNotContainKey("autorizacion.usuarios.cliente105.canales.movil[0]");
        assertThat(docker).doesNotContainKey("autorizacion.usuarios.ejecutivo1.cuenta-id");
        assertThat(lista(docker, "autorizacion.usuarios.ejecutivo1.canales.web"))
                .containsExactly("ROLE_EJECUTIVO", "PERM_auditoria:leer");
        assertThat(docker).doesNotContainKey("autorizacion.usuarios.ejecutivo1.canales.movil[0]");
        // Cliente y ejecutivo no comparten ninguna autoridad: la autorizacion es por permiso, no solo por canal.
        assertThat(lista(docker, "autorizacion.usuarios.cliente116.canales.web"))
                .doesNotContainAnyElementsOf(lista(docker, "autorizacion.usuarios.ejecutivo1.canales.web"));
        // Nunca una clave en claro: solo hashes BCrypt con el prefijo del codificador delegante.
        for (String usuario : List.of("cliente116", "cliente105", "ejecutivo1")) {
            assertThat(String.valueOf(docker.get("autorizacion.usuarios." + usuario + ".clave-hash")))
                    .startsWith("{bcrypt}$2");
        }
    }

    /**
     * La politica del cajero (F5): el terminal registrado, las cuatro tarjetas del S5 con sus autoridades y la politica
     * de PIN. Los hashes de PIN son BCrypt (no un secreto); el secreto del terminal no esta aqui, llega por archivo.
     */
    @Test
    @DisplayName("El auth-server recibe el terminal atm-scl-001, las cuatro tarjetas (la 105 y la 150 sin retiro) y 3 intentos de PIN con 15 min de bloqueo")
    void elAuthServerRecibeLaPoliticaDelCajero() throws Exception {
        Map<String, Object> docker = aplanar(pedir("auth-server", "docker,demo"));

        assertThat(docker.get("autorizacion.terminales.atm-scl-001.audiencia")).isEqualTo("bff-atm");
        assertThat(docker.get("autorizacion.terminales.atm-scl-001.vigencia")).isEqualTo("3m");
        assertThat(docker).as("el secreto del terminal no esta en config-repo")
                .doesNotContainKey("autorizacion.terminales.atm-scl-001.secreto");
        assertThat(docker.get("autorizacion.pin.intentos-maximos")).isEqualTo(3);
        assertThat(docker.get("autorizacion.pin.bloqueo")).isEqualTo("15m");

        Map<String, List<String>> autoridadesPorTarjeta = new java.util.LinkedHashMap<>();
        Map<String, Object> cuentas = new java.util.LinkedHashMap<>();
        for (int i = 0; docker.containsKey("autorizacion.tarjetas[" + i + "].numero"); i++) {
            String numero = String.valueOf(docker.get("autorizacion.tarjetas[" + i + "].numero"));
            autoridadesPorTarjeta.put(numero, lista(docker, "autorizacion.tarjetas[" + i + "].autoridades"));
            cuentas.put(numero, docker.get("autorizacion.tarjetas[" + i + "].cuenta-id"));
            assertThat(String.valueOf(docker.get("autorizacion.tarjetas[" + i + "].pin-hash")))
                    .as("PIN de %s", numero).startsWith("{bcrypt}$2");
        }
        assertThat(cuentas).containsExactly(
                org.assertj.core.api.Assertions.entry("4000000000000116", 116),
                org.assertj.core.api.Assertions.entry("4000000000000106", 106),
                org.assertj.core.api.Assertions.entry("4000000000000105", 105),
                org.assertj.core.api.Assertions.entry("4000000000000150", 150));
        assertThat(autoridadesPorTarjeta.get("4000000000000116")).contains("PERM_retiro:ejecutar");
        assertThat(autoridadesPorTarjeta.get("4000000000000106")).contains("PERM_retiro:ejecutar");
        assertThat(autoridadesPorTarjeta.get("4000000000000105")).containsExactly("ROLE_CLIENTE_ATM", "PERM_saldo:leer");
        assertThat(autoridadesPorTarjeta.get("4000000000000150")).containsExactly("ROLE_CLIENTE_ATM", "PERM_saldo:leer");
    }

    /** Elementos de una lista YAML aplanada como {@code clave[0]}, {@code clave[1]}, en orden. */
    private List<String> lista(Map<String, Object> efectivo, String clave) {
        List<String> elementos = new ArrayList<>();
        for (int i = 0; efectivo.containsKey(clave + "[" + i + "]"); i++) {
            elementos.add(String.valueOf(efectivo.get(clave + "[" + i + "]")));
        }
        return elementos;
    }

    @Test
    @DisplayName("config-repo no contiene secretos: ni claves con nombre de secreto ni claves privadas PEM")
    void configRepoNoLlevaSecretos() throws Exception {
        for (String servicio : List.of("core-service", "auth-server", "bff-web", "bff-mobile", "bff-atm")) {
            for (String perfiles : List.of("local,demo", "docker,demo")) {
                for (Map.Entry<String, Object> e : aplanar(pedir(servicio, perfiles)).entrySet()) {
                    assertThat(CLAVE_DE_SECRETO.matcher(e.getKey()).find())
                            .as("la clave '%s' (%s) parece un secreto y no debe estar en config-repo", e.getKey(), servicio)
                            .isFalse();
                    assertThat(CLAVE_PEM.matcher(String.valueOf(e.getValue())).find())
                            .as("el valor de '%s' (%s) contiene una clave privada", e.getKey(), servicio)
                            .isFalse();
                }
            }
        }
    }
}
