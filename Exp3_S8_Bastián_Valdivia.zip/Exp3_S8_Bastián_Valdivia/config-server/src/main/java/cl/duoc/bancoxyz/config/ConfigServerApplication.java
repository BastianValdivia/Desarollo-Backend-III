package cl.duoc.bancoxyz.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

/**
 * Servidor de configuracion centralizada del Banco XYZ.
 *
 * <p>{@link EnableConfigServer} publica la API REST de Spring Cloud Config
 * ({@code GET /{servicio}/{perfil}}) sobre la carpeta {@code config-repo/}. Cada microservicio
 * la consulta al arrancar mediante {@code spring.config.import=configserver:...} y recibe asi
 * lo que antes llevaba dentro de su propio {@code application.yml}.
 *
 * <p>Se usa el backend {@code native} (archivos del sistema de archivos) y no Git porque la
 * carpeta viaja dentro del mismo repositorio que el codigo, se monta como volumen en los
 * contenedores y se relee en cada peticion: editar un archivo y llamar a {@code /actuator/refresh}
 * en el cliente basta, sin reiniciar este servidor ni reconstruir ninguna imagen.
 *
 * <p>Los datos de {@code config-repo/} no llevan secretos (claves, contrasenas, secretos de
 * clientes): este servidor los entrega por HTTP sin autenticacion dentro de la red interna, de
 * modo que solo sirve configuracion que pueda ser publica. Lo comprueba una prueba automatica.
 */
@SpringBootApplication
@EnableConfigServer
public class ConfigServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfigServerApplication.class, args);
    }
}
